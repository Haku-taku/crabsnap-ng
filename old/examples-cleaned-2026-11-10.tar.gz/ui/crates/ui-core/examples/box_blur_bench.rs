//! Timing harness for the box-blur passes, so an optimisation has a baseline to beat.

use std::time::Instant;

fn main() {
    // A frost-sized region at the demo's 2x scale, and one large enough to be bandwidth bound.
    for (w, h) in [(520usize, 240usize), (1040, 480)] {
        let mut rgba = vec![0u8; w * h * 4];
        for (i, b) in rgba.iter_mut().enumerate() {
            *b = ((i * 37) % 251) as u8;
        }
        for radius in [6u32, 14, 24] {
            let mut best = f64::MAX;
            for _ in 0..7 {
                let mut buf = rgba.clone();
                let start = Instant::now();
                for _ in 0..ui_core::boxblur::BOX_PASSES {
                    ui_core::boxblur::box_h(&mut buf, w, 0, 0, w, h, radius);
                    ui_core::boxblur::box_v(&mut buf, w, 0, 0, w, h, radius);
                }
                best = best.min(start.elapsed().as_secs_f64());
                std::hint::black_box(&buf);
            }
            let px = (w * h) as f64;
            println!(
                "{w}x{h} radius {radius:>2}: {:.3} ms  ({:.1} ns/px)",
                best * 1e3,
                best * 1e9 / px
            );
        }
    }
}
