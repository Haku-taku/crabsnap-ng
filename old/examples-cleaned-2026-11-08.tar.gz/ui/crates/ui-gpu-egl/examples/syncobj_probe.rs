//! Probe: does `SyncTimeline::wait` report a reached point and a timeout correctly?
//!
//! The kernel takes an absolute deadline and rejects an unsubmitted point unless the call
//! asks to wait for it; both facts came from this probe, so it stays runnable.

use std::os::fd::{AsRawFd, FromRawFd, OwnedFd};
use std::time::{Duration, Instant};

use ui_gpu_egl::SyncTimeline;

fn main() {
    let file = std::fs::OpenOptions::new()
        .read(true)
        .write(true)
        .open("/dev/dri/renderD128")
        .expect("render node");
    let fd = file.as_raw_fd();
    let timeline = SyncTimeline::new(fd).expect("timeline");
    // An already signalled binary syncobj exports a sync_file whose fence has passed.
    let sync_file = unsafe {
        let lib = libc::dlopen(c"libdrm.so.2".as_ptr(), libc::RTLD_NOW);
        let create: unsafe extern "system" fn(i32, u32, *mut u32) -> i32 =
            std::mem::transmute(libc::dlsym(lib, c"drmSyncobjCreate".as_ptr()));
        let export: unsafe extern "system" fn(i32, u32, *mut i32) -> i32 =
            std::mem::transmute(libc::dlsym(lib, c"drmSyncobjExportSyncFile".as_ptr()));
        let mut handle: u32 = 0;
        assert_eq!(create(fd, 1, &mut handle), 0, "signalled syncobj");
        let mut sfd: i32 = -1;
        assert_eq!(export(fd, handle, &mut sfd), 0, "export sync_file");
        OwnedFd::from_raw_fd(sfd)
    };
    timeline
        .import_fence_at(&sync_file, 1)
        .expect("import point 1");
    // Point 1 is reached, so the wait returns at once with `true`.
    let t = Instant::now();
    let reached = timeline.wait(1, Duration::from_millis(50));
    println!("point 1 -> {reached} in {:?}", t.elapsed());
    // Point 2 was never reached: the wait spends its timeout and answers `false`.
    let t = Instant::now();
    let reached = timeline.wait(2, Duration::from_millis(50));
    println!("point 2 -> {reached} in {:?}", t.elapsed());
    assert!(
        t.elapsed() >= Duration::from_millis(45),
        "the second wait used its timeout"
    );
}
