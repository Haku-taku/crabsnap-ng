//! Report which system fonts the platform provider finds.
//!
//! Run on Linux: `cargo run -p ui-text-fontique --example windows_fonts --features system`
//! Run on Windows (or under Wine): same, with `--target x86_64-pc-windows-gnu`.

use ui_text::{FontProvider, FontRequest, GenericFamily, Script};

fn main() {
    let p = ui_text_fontique::system_or_isolated();
    let names = p.family_names();
    println!("provider: {}", p.name());
    println!("families found: {}", names.len());
    for name in names.iter().take(8) {
        println!("  {name}");
    }

    for (label, generic) in [
        ("SansSerif", GenericFamily::SansSerif),
        ("Serif", GenericFamily::Serif),
        ("Monospace", GenericFamily::Monospace),
    ] {
        match p.resolve(&FontRequest::new(generic)) {
            Some(id) => {
                let style = p.family_names();
                let _ = style;
                println!("{label:10} -> resolved face {id:?}");
            }
            None => println!("{label:10} -> NOT FOUND"),
        }
    }

    for script in [Script::LATIN, Script::HAN, Script::ARABIC] {
        let chain = p.fallback_chain(script);
        println!("fallback[{script:?}] -> {} faces", chain.len());
    }
}
