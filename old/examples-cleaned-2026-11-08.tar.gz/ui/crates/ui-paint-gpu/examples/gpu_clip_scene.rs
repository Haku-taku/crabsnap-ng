//! Compares CPU and GPU rendering of clipped content.
//!
//! Clips are placed at several heights on purpose: GL's scissor origin is the framebuffer
//! bottom while this renderer's projection is top-down, so a Y flip here is invisible
//! until something is actually clipped — and then it clips the wrong band.
//!
//! Run: `cargo run -p ui-paint-gpu --example gpu_clip_scene`

use ui_core::NodeId;
use ui_core::draw::{DrawList, RectPrim};
use ui_core::geom::{Color, Corners, Rect};
use ui_paint::{CpuRenderer, Pixels};
use ui_paint_gpu::{EglContext, GpuRenderer, OffscreenFbo};

const W: u32 = 240;
const H: u32 = 320;

/// Parent rects, each with a child that spills well past it.
const PARENTS: [(f32, f32); 4] = [(10.0, 8.0), (10.0, 88.0), (10.0, 168.0), (10.0, 248.0)];
const PARENT: f32 = 60.0;

/// A rounded clip placed to the right of the plain ones.
const ROUNDED: (f32, f32, f32) = (150.0, 8.0, 72.0);

/// A narrow clip whose far edge lands mid-pixel, so its last row is only partly covered.
const FRACTIONAL: (f32, f32, f32) = (150.0, 96.4, 20.0);

fn scene() -> DrawList {
    let mut list = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    list.push_rect(
        NodeId::from_raw(1, 0),
        RectPrim {
            rect: Rect::new(0.0, 0.0, W as f32, H as f32),
            radius: Corners::ZERO,
            fill: Color::from_rgba8(18, 20, 26, 255),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    // A rounded clip: the corner must follow the curve, not the bounding box.
    list.push_clip(
        Rect::new(ROUNDED.0, ROUNDED.1, ROUNDED.2, ROUNDED.2),
        Corners::all(ROUNDED.2 * 0.5).squircle(),
    );
    list.push_rect(
        NodeId::from_raw(2, 0),
        RectPrim {
            rect: Rect::new(ROUNDED.0, ROUNDED.1, ROUNDED.2, ROUNDED.2),
            radius: Corners::ZERO,
            fill: Color::from_rgba8(90, 200, 255, 255),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    list.pop_clip();

    // Content reaches its own far edge, so the last row the clip covers is the one a scissor
    // rounded from the *size* would drop.
    let (fx, fy, fs) = FRACTIONAL;
    list.push_clip(Rect::new(fx, fy, fs, fs), Corners::ZERO);
    list.push_rect(
        NodeId::from_raw(30, 0),
        RectPrim {
            rect: Rect::new(fx, fy, fs * 2.0, fs * 2.0),
            radius: Corners::ZERO,
            // Not the orange: check [1] counts orange pixels outside the parent bands.
            fill: Color::from_rgba8(90, 200, 255, 255),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    list.pop_clip();

    for (i, (x, y)) in PARENTS.into_iter().enumerate() {
        let clip = Rect::new(x, y, PARENT, PARENT);
        list.push_clip(clip, Corners::ZERO);
        list.push_rect(
            NodeId::from_raw(10 + i as u32, 0),
            RectPrim {
                rect: Rect::new(x, y, PARENT * 2.0, PARENT * 2.0),
                radius: Corners::ZERO,
                fill: Color::from_rgba8(255, 90, 40, 255),
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
        list.pop_clip();
    }
    list
}

/// Normalise both backends to straight RGBA so the comparison is about clipping.
///
/// `Pixels` is premultiplied BGRA; `read_pixels` returns straight RGBA.
fn straight_rgba(data: &[u8], premultiplied_bgra: bool) -> Vec<[u8; 4]> {
    data.as_chunks::<4>()
        .0
        .iter()
        .map(|p| {
            if premultiplied_bgra {
                let a = p[3] as u32;
                if a == 0 {
                    [0, 0, 0, 0]
                } else {
                    [
                        ((p[2] as u32 * 255) / a).min(255) as u8,
                        ((p[1] as u32 * 255) / a).min(255) as u8,
                        ((p[0] as u32 * 255) / a).min(255) as u8,
                        p[3],
                    ]
                }
            } else {
                [p[0], p[1], p[2], p[3]]
            }
        })
        .collect()
}

fn report(name: &str, value: f64, limit: f64, unit: &str, failures: &mut u32) {
    let ok = value <= limit;
    println!(
        "{name:30} {value:9.4}{unit}  (limit {limit}{unit})  {}",
        if ok { "OK" } else { "FAIL" }
    );
    if !ok {
        *failures += 1;
    }
}

fn main() {
    let list = scene();

    let mut cpu = CpuRenderer::new();
    let mut pixels = Pixels::new(W, H);
    cpu.render(&list, &mut pixels, &ui_core::damage::Damage::Full);
    let cpu_data = pixels.data.clone();
    let cpu_rgba = straight_rgba(&cpu_data, true);

    let node = std::env::args()
        .nth(1)
        .or_else(ui_paint_gpu::output_render_node)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node.clone()).expect("node path");
    let ctx = EglContext::new(cnode.as_c_str()).expect("EGL context");
    println!("GPU: {} ({node})", ctx.renderer());

    let target = OffscreenFbo::new(ctx.gl(), W, H).expect("target");
    let mut gpu = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    gpu.clear(ctx.gl(), &target, [0.0, 0.0, 0.0, 0.0]);
    gpu.render(ctx.gl(), &target, &list).expect("render");
    let gpu_data = gpu.read_pixels(ctx.gl(), &target).expect("readback");
    let gpu_rgba = straight_rgba(&gpu_data, false);

    let mut failures = 0;

    // [1] Every parent band is clipped to its own box: no orange outside any parent.
    let outside = (0..H)
        .flat_map(|y| (0..W).map(move |x| (x, y)))
        .filter(|(x, y)| {
            let inside = PARENTS.iter().any(|(px, py)| {
                *x as f32 >= *px
                    && (*x as f32) < px + PARENT
                    && *y as f32 >= *py
                    && (*y as f32) < py + PARENT
            });
            // Orange is (255, 90, 40); the background is (18, 20, 26).
            !inside && gpu_rgba[(y * W + x) as usize][0] > 128
        })
        .count();
    report(
        "[1] gpu content outside clips",
        outside as f64,
        0.0,
        "",
        &mut failures,
    );

    // [2] The clip lands on the same band on both backends.
    let differing = cpu_rgba
        .iter()
        .zip(gpu_rgba.iter())
        .filter(|(c, g)| (0..4).any(|ch| (c[ch] as i32 - g[ch] as i32).abs() > 2))
        .count();
    report(
        "[2] cpu/gpu differing pixels",
        differing as f64 / (W * H) as f64 * 100.0,
        0.2,
        "%",
        &mut failures,
    );

    // [3] Each band is filled, which proves the clip did not wipe the content entirely.
    let filled = PARENTS
        .iter()
        .map(|(x, y)| {
            let cx = (*x + PARENT / 2.0) as u32;
            let cy = (*y + PARENT / 2.0) as u32;
            gpu_rgba[(cy * W + cx) as usize][0]
        })
        .collect::<Vec<_>>();
    println!("  band centre red: {filled:?}");
    let all_filled = filled.iter().all(|v| *v > 200);
    report(
        "[3] every band has content",
        if all_filled { 0.0 } else { 1.0 },
        0.0,
        "",
        &mut failures,
    );

    // [4] The rounded clip cuts its corners: the bounding-box corner stays background.
    let (rx, ry, rs) = ROUNDED;
    let corner = gpu_rgba[((ry as u32 + 1) * W + rx as u32 + 1) as usize];
    let centre = gpu_rgba[(((ry + rs / 2.0) as u32) * W + (rx + rs / 2.0) as u32) as usize];
    println!("  rounded corner {corner:?} centre {centre:?}");
    report(
        "[4] rounded corner is cut",
        if corner[2] > 128 { 1.0 } else { 0.0 },
        0.0,
        "",
        &mut failures,
    );
    report(
        "[5] rounded centre is painted",
        if centre[2] > 200 { 0.0 } else { 1.0 },
        0.0,
        "",
        &mut failures,
    );

    // [6] The row the clip's far edge only partly covers is still painted. A scissor rounded
    // from the clip's size (`ceil(20)` from `floor(96.4)`) stops one row short of 116.4 and
    // drops it, which is how a 1dp divider under a fractional box vanishes on the GPU only.
    let last = (FRACTIONAL.1 + FRACTIONAL.2).ceil() as u32 - 1;
    let px = FRACTIONAL.0 as u32 + 1;
    let cpu_row = cpu_rgba[(last * W + px) as usize];
    let gpu_row = gpu_rgba[(last * W + px) as usize];
    println!("  row {last} of the fractional clip: cpu {cpu_row:?} gpu {gpu_row:?}");
    report(
        "[6] last row of a fractional clip",
        if cpu_row[2] > 100 && gpu_row[2] > 100 {
            0.0
        } else {
            1.0
        },
        0.0,
        "",
        &mut failures,
    );

    if std::env::var("DUMP_CLIP").is_ok() {
        for (name, data) in [("cpu", &cpu_data), ("gpu", &gpu_data)] {
            use std::io::Write;
            let mut f = std::fs::File::create(format!("/tmp/clip_{name}.ppm")).expect("ppm");
            write!(f, "P6\n{W} {H}\n255\n").expect("hdr");
            //  returns straight RGBA already; write it in that order.
            for p in data.as_chunks::<4>().0 {
                let _ = f.write_all(&p[0..3]);
            }
        }
        println!("dumped /tmp/clip_{{cpu,gpu}}.ppm");
    }

    gpu.release(ctx.gl());
    target.release(ctx.gl());

    if failures > 0 {
        eprintln!("\n{failures} invariant(s) violated");
        std::process::exit(1);
    }
    println!("\nclipping agrees on both backends");
}
