//! LiquidGlassKit's material over stripes: the only backdrop that shows its refraction.

use ui_core::NodeId;
use ui_core::draw::DrawList;
use ui_core::draw::{BackdropEntry, BackdropMaterial, LiquidGlass, RectPrim};
use ui_core::geom::{Color, Corners, Rect};
use ui_paint_gpu::{EglContext, GpuRenderer, OffscreenFbo};

/// Logical frame; the offscreen target is twice this, as a 2× display would be.
const W: f32 = 240.0;
const H: f32 = 140.0;
const SCALE: f32 = 2.0;
/// Stripe period in dp, coarse enough that a few dp of refraction crosses a boundary.
const STRIPE: f32 = 10.0;

/// The switch thumb's expanded size and preset magnification.
fn thumb() -> Rect {
    Rect::new(92.5, 56.75, 55.0, 26.5)
}

fn scene(material: Option<BackdropMaterial>) -> DrawList {
    let mut list = DrawList::new(Rect::new(0.0, 0.0, W, H));
    let mut x = 0.0;
    let mut id = 1;
    while x < W {
        let lit = ((x / STRIPE) as i32) % 2 == 0;
        let fill = if lit {
            Color::from_rgba8(236, 236, 236, 255)
        } else {
            Color::from_rgba8(28, 28, 28, 255)
        };
        list.push_rect(
            NodeId::from_raw(id, 0),
            RectPrim {
                rect: Rect::new(x, 0.0, STRIPE.min(W - x), H),
                radius: Corners::ZERO,
                fill,
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
        x += STRIPE;
        id += 1;
    }
    if let Some(material) = material {
        list.push_backdrop(BackdropEntry {
            rect: thumb(),
            clip: thumb(),
            corners: Corners::all(thumb().size.h * 0.5),
            radius: 8,
            sigma: 0.0,
            material,
        });
    }
    list
}

fn kit() -> LiquidGlass {
    use ui_widgets_glass::material::{Control, glass_recipe};
    let kit = glass_recipe(&ui_widgets_glass::pack(), Control::Switch);
    LiquidGlass {
        blend: [ui_core::draw::BlendShape::NONE; ui_core::draw::BLEND_SHAPES],
        blend_count: 0,
        blend_k: 0.0,
        ..kit
    }
}

fn render(
    ctx: &EglContext,
    target: &OffscreenFbo,
    gpu: &mut GpuRenderer,
    material: Option<BackdropMaterial>,
) -> Vec<u8> {
    gpu.set_backdrop_material(material);
    gpu.clear(ctx.gl(), target, [0.0, 0.0, 0.0, 1.0]);
    gpu.render(ctx.gl(), target, &scene(material))
        .expect("render");
    gpu.read_pixels(ctx.gl(), target).expect("readback")
}

fn main() {
    let node = std::env::args()
        .nth(1)
        .or_else(ui_paint_gpu::output_render_node)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node.clone()).expect("node path");
    let ctx = EglContext::new(cnode.as_c_str()).expect("EGL context");
    let (w, h) = ((W * SCALE) as u32, (H * SCALE) as u32);
    let target = OffscreenFbo::new(ctx.gl(), w, h).expect("target");
    let mut gpu = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    gpu.set_scale(SCALE);

    let frames = [
        ("plain", None),
        ("kit", Some(BackdropMaterial::LiquidGlass(kit()))),
    ];
    let out = std::env::args()
        .nth(2)
        .unwrap_or_else(|| "/tmp".to_string());
    for (name, material) in frames {
        let data = render(&ctx, &target, &mut gpu, material);
        let path = format!("{out}/liquid_{name}.ppm");
        use std::io::Write;
        let mut f = std::fs::File::create(&path).expect("ppm");
        write!(f, "P6\n{w} {h}\n255\n").expect("hdr");
        for p in data.as_chunks::<4>().0 {
            f.write_all(&[p[0], p[1], p[2]]).expect("write");
        }
        println!("dumped {path}");
    }
}
