//! Backdrop blur must soften the backdrop and write back without punching a hole.
//!
//! Run: `cargo run -p ui-paint-gpu --example gpu_backdrop_scene`

use ui_core::NodeId;
use ui_core::draw::{BackdropEntry, BackdropMaterial, DrawList, RectPrim};
use ui_core::geom::{Color, Corners, Rect};
use ui_paint_gpu::{EglContext, GpuRenderer, OffscreenFbo};

const W: u32 = 160;
const H: u32 = 120;

fn fail(failures: &mut u32, name: &str, ok: bool, detail: &str) {
    if ok {
        println!("  ok   {name} ({detail})");
    } else {
        println!("  FAIL {name} ({detail})");
        *failures += 1;
    }
}

fn alpha_at(data: &[u8], x: u32, y: u32) -> u8 {
    data[((y * W + x) * 4 + 3) as usize]
}

fn px(data: &[u8], x: u32, y: u32) -> [u8; 4] {
    let i = ((y * W + x) * 4) as usize;
    [data[i], data[i + 1], data[i + 2], data[i + 3]]
}

/// Opaque background with a bright square, then a backdrop blur over a region inside it.
fn scene(rect: Rect, radius: u32, sigma: f32) -> DrawList {
    scene_with_panel(rect, radius, sigma, true)
}

/// The same scene with rounded corners on the panel: corner coverage is sub-pixel there.
fn rounded(rect: Rect, radius: u32, sigma: f32) -> DrawList {
    let mut list = scene(rect, radius, sigma);
    if let Some(last) = list.prims.rects.last_mut() {
        last.radius = Corners::all(12.0);
    }
    if let Some(entry) = list.backdrops.last_mut() {
        entry.corners = Corners::all(12.0);
    }
    let _ = W;
    list
}

fn scene_with_panel(rect: Rect, radius: u32, sigma: f32, panel: bool) -> DrawList {
    let mut list = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    // Fill the whole canvas: anything transparent afterwards is a bug the blur caused.
    list.push_rect(
        NodeId::from_raw(1, 0),
        RectPrim {
            rect: Rect::new(0.0, 0.0, W as f32, H as f32),
            radius: Corners::ZERO,
            fill: Color::from_rgba8(40, 90, 200, 255),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    list.push_rect(
        NodeId::from_raw(2, 0),
        RectPrim {
            rect: Rect::new(60.0, 40.0, 20.0, 20.0),
            radius: Corners::ZERO,
            fill: Color::WHITE,
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    list.push_backdrop(BackdropEntry {
        rect,
        clip: rect,
        corners: Corners::ZERO,
        radius,
        sigma,
        material: BackdropMaterial::PLAIN,
    });
    // The frosted panel itself: translucent, drawn after the blur, like the demo.
    if panel {
        list.push_rect(
            NodeId::from_raw(3, 0),
            RectPrim {
                rect,
                radius: Corners::ZERO,
                fill: Color::from_rgba8(255, 255, 255, 40),
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
    }
    list
}

fn main() {
    let node = std::env::args()
        .nth(1)
        .or_else(ui_paint_gpu::output_render_node)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node.clone()).expect("node path");
    let ctx = EglContext::new(cnode.as_c_str()).expect("EGL context");

    let inc = OffscreenFbo::new(ctx.gl(), W, H).expect("target");
    let mut g = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    g.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);

    let region = Rect::new(50.0, 30.0, 60.0, 60.0);
    // Rounded, because corner coverage is what a plain overwrite corrupts.
    g.render(ctx.gl(), &inc, &rounded(region, 18, 6.0))
        .expect("render");
    let data =
        GpuRenderer::to_premultiplied_bgra(&g.read_pixels(ctx.gl(), &inc).expect("readback"));

    let mut failures = 0u32;

    // 1. The blur must not punch a hole: every pixel inside the painted area stays opaque.
    let mut transparent = 0u32;
    for y in 0..H {
        for x in 0..W {
            if alpha_at(&data, x, y) < 250 {
                transparent += 1;
            }
        }
    }
    fail(
        &mut failures,
        "the backdrop leaves no transparent pixels",
        transparent == 0,
        &format!("{transparent} pixels below alpha 250"),
    );

    // 2. Corners of the blurred region must not fall off toward transparent.
    let corner = px(&data, 51, 31);
    fail(
        &mut failures,
        "the region corner stays fully opaque",
        corner[3] == 255,
        &format!("corner alpha {}", corner[3]),
    );

    // 3. The blur must move pixels in a wide band around the square. Comparing against the
    //    same scene drawn sharp isolates the filter: the translucent panel appears in both.
    let mut sharp_renderer = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    sharp_renderer.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    let mut sharp_list = rounded(region, 18, 6.0);
    // Drop the backdrop op so the identical scene renders sharp.
    sharp_list
        .ops
        .retain(|op| !matches!(op, ui_core::draw::Op::Backdrop(_)));
    sharp_renderer
        .render(ctx.gl(), &inc, &sharp_list)
        .expect("render sharp");
    let sharp = GpuRenderer::to_premultiplied_bgra(
        &sharp_renderer
            .read_pixels(ctx.gl(), &inc)
            .expect("readback"),
    );

    // Probe a point on the square's border, where a Gaussian must show its strongest
    // change: far-field probes cannot distinguish "weak blur" from "no blur".
    let i = ((50 * W + 79) * 4) as usize;
    let diff = (data[i + 1] as i32 - sharp[i + 1] as i32).abs()
        + (data[i + 2] as i32 - sharp[i + 2] as i32).abs();
    fail(
        &mut failures,
        "the blur mixes the square's edge with its surroundings",
        diff > 20,
        &format!(
            "blurred {:?} vs sharp {:?}",
            &data[i..i + 4],
            &sharp[i..i + 4]
        ),
    );

    // 4. Outside the region nothing changes: the scissor must hold.
    let outside = px(&data, 20, 20);
    // 5. Text-like high-frequency content under the panel must be smeared, not preserved:
    //    a sharp white pixel inside the region means the fill was drawn before the blur.
    let mut sharp_white = 0u32;
    for y in 42..58 {
        for x in 62..78 {
            let p = px(&data, x, y);
            if p[0] > 250 && p[1] > 250 && p[2] > 250 {
                sharp_white += 1;
            }
        }
    }
    fail(
        &mut failures,
        "no sharp white survives inside the region",
        sharp_white == 0,
        &format!("{sharp_white} pure-white pixels inside the blurred square"),
    );

    fail(
        &mut failures,
        "pixels outside the region are untouched",
        outside == [200, 90, 40, 255],
        &format!("got {:?}", outside),
    );

    // 6. Edge sharpness: the largest luminance step across the blurred boundary must be
    //    far smaller than the same step in an unblurred render. Counting colour breaks
    //    is unreliable here (the panel's own text contributes); the step size is not.
    let max_step = |data: &[u8], y: u32, x0: u32, x1: u32| -> i32 {
        let mut m = 0i32;
        let mut prev: Option<i32> = None;
        for x in x0..x1 {
            let p = px(data, x, y);
            let v = (p[0] as i32 + p[1] as i32 + p[2] as i32) / 3;
            if let Some(q) = prev {
                m = m.max((v - q).abs());
            }
            prev = Some(v);
        }
        m
    };
    let sharp_step = max_step(&sharp, 50, 60, 90);
    let blurred_step = max_step(&data, 50, 60, 90);
    fail(
        &mut failures,
        "blurring reduces the boundary step substantially",
        blurred_step * 2 < sharp_step,
        &format!("blurred {blurred_step} vs sharp {sharp_step}"),
    );

    // 7. A wider sigma must produce a gentler slope at the edge. A kernel capped by an
    //    array length makes both identical, which is the failure this catches.
    let mut slope = |list: &ui_core::draw::DrawList| -> i32 {
        g.render(ctx.gl(), &inc, list).expect("render");
        let buf = g.read_pixels(ctx.gl(), &inc).expect("readback");
        // Largest single-pixel step along the row that crosses the square's edges.
        let mut m = 0i32;
        let mut prev: Option<i32> = None;
        for x in 50..92 {
            let v = px(&buf, x, 50)[1] as i32;
            if let Some(q) = prev {
                m = m.max((v - q).abs());
            }
            prev = Some(v);
        }
        m
    };
    let narrow = slope(&rounded(region, 18, 4.0));
    let wide = slope(&rounded(region, 18, 24.0));
    fail(
        &mut failures,
        "a larger sigma produces a gentler edge instead of being capped",
        wide < narrow,
        &format!("sigma 4 steps {narrow}, sigma 24 steps {wide}"),
    );

    // 8. A sigma comparable to the region itself must flatten it: the square's interior
    //    and its surroundings converge. A 16px-capped kernel cannot do this, so the check
    //    separates "really blurred" from "blurred as far as the array allows".
    let mut flatness = |sigma: f32| -> i32 {
        g.render(ctx.gl(), &inc, &rounded(region, 18, sigma))
            .expect("render");
        let buf = g.read_pixels(ctx.gl(), &inc).expect("readback");
        let mut lo = 255i32;
        let mut hi = 0i32;
        for y in 35..85 {
            for x in 55..105 {
                let v = px(&buf, x, y)[1] as i32;
                lo = lo.min(v);
                hi = hi.max(v);
            }
        }
        hi - lo
    };
    let at_cap = flatness(5.0);
    let beyond_cap = flatness(30.0);
    fail(
        &mut failures,
        "a sigma past the kernel cap still flattens the region",
        beyond_cap < at_cap / 2,
        &format!("sigma 5 spread {at_cap}, sigma 30 spread {beyond_cap}"),
    );

    // 9. A hard edge under the panel must become a long ramp. Counting pixels whose
    //    neighbours differ is the direct test: a sharp edge yields one change, a blurred
    //    one yields a run of them.
    let ramp = |data: &[u8], y: u32, x0: u32, x1: u32| -> u32 {
        let mut n = 0u32;
        let mut prev: Option<[u8; 4]> = None;
        for x in x0..x1 {
            let p = px(data, x, y);
            if let Some(q) = prev
                && p != q
            {
                n += 1;
            }
            prev = Some(p);
        }
        n
    };
    // The square's left edge is at x=60; scan a window centred on it.
    let blurred_ramp = ramp(&data, 50, 40, 80);
    let sharp_ramp = ramp(&sharp, 50, 40, 80);
    fail(
        &mut failures,
        "a hard edge becomes a ramp under the blur",
        blurred_ramp > sharp_ramp * 3,
        &format!("blurred {blurred_ramp} changing pixels vs sharp {sharp_ramp}"),
    );

    // 10. Repeating the same frame must be idempotent. A frost that is re-blended over
    //     its own output drifts toward the backdrop colour frame by frame, which is the
    //     symptom this pins down.
    let mut repeat = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    repeat.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    let scene_list = rounded(region, 18, 6.0);
    repeat.render(ctx.gl(), &inc, &scene_list).expect("render");
    let first =
        GpuRenderer::to_premultiplied_bgra(&repeat.read_pixels(ctx.gl(), &inc).expect("readback"));
    for _ in 0..6 {
        repeat.render(ctx.gl(), &inc, &scene_list).expect("render");
    }
    let later =
        GpuRenderer::to_premultiplied_bgra(&repeat.read_pixels(ctx.gl(), &inc).expect("readback"));
    let drift = first
        .iter()
        .zip(later.iter())
        .map(|(a, b)| (*a as i32 - *b as i32).abs())
        .max()
        .unwrap_or(0);
    fail(
        &mut failures,
        "repeating a still frame does not drift",
        drift <= 1,
        &format!("largest channel drift after 6 repeats: {drift}"),
    );

    // 11. `damage` must not influence the pixels any more. A frame that reports a small
    //     damaged rect has to look exactly like one that reports everything, because the
    //     renderer repaints the whole surface either way. If damage ever leaks back into
    //     content, this is the check that says so.
    let mut full_repaint = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    full_repaint.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    full_repaint
        .render(ctx.gl(), &inc, &scene_list)
        .expect("render");
    let reference = GpuRenderer::to_premultiplied_bgra(
        &full_repaint.read_pixels(ctx.gl(), &inc).expect("readback"),
    );
    // The marked rect sits inside the square, which the frost reads.
    let mut same = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    same.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    same.render(ctx.gl(), &inc, &scene_list).expect("render");
    let after =
        GpuRenderer::to_premultiplied_bgra(&same.read_pixels(ctx.gl(), &inc).expect("readback"));
    let diff: u64 = reference
        .iter()
        .zip(after.iter())
        .map(|(a, b)| (*a as i64 - *b as i64).unsigned_abs())
        .sum();
    fail(
        &mut failures,
        "a repeated frame is byte-identical",
        diff == 0,
        &format!("{diff} bytes differ"),
    );
    let transparent = after
        .as_chunks::<4>()
        .0
        .iter()
        .filter(|p| p[3] < 250)
        .count();
    fail(
        &mut failures,
        "the frost leaves no transparent pixels",
        transparent == 0,
        &format!("{transparent} pixels below alpha 250"),
    );

    // 12. Content straddling the frost's edge must blur with the *outside* pixels too.
    //     A snapshot that stops at the frost boundary makes the outermost band read clamped
    //     values, which shows up as a plateau along the edge instead of a gradient.
    let straddling = |list: &mut DrawList| {
        list.push_rect(
            NodeId::from_raw(9, 0),
            RectPrim {
                // Half inside the frost (x 50..110), half outside to the left.
                rect: Rect::new(20.0, 40.0, 40.0, 20.0),
                radius: Corners::ZERO,
                fill: Color::WHITE,
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
    };
    let mut edge_list = rounded(region, 18, 6.0);
    straddling(&mut edge_list);
    let mut edge_renderer = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    edge_renderer.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    edge_renderer
        .render(ctx.gl(), &inc, &edge_list)
        .expect("render");
    let edge_buf = GpuRenderer::to_premultiplied_bgra(
        &edge_renderer.read_pixels(ctx.gl(), &inc).expect("readback"),
    );
    // Walk the row through the white band and count distinct values just inside the frost.
    let row_changes = {
        let mut n = 0;
        let mut prev: Option<[u8; 4]> = None;
        for x in 50..80 {
            let i = ((60 * W + x) * 4) as usize;
            let p = [
                edge_buf[i],
                edge_buf[i + 1],
                edge_buf[i + 2],
                edge_buf[i + 3],
            ];
            if prev.is_some_and(|q| q != p) {
                n += 1;
            }
            prev = Some(p);
        }
        n
    };
    fail(
        &mut failures,
        "content straddling the frost edge still produces a gradient",
        row_changes > 3,
        &format!("{row_changes} distinct steps along the inner edge"),
    );

    // 13. A translucent frost panel over an opaque backdrop must stay opaque. The blur
    //     averages premultiplied values, so if the panel's own fill leaks into the result
    //     the area gets more transparent than the fill alone would make it.
    let mut alpha_probe = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    alpha_probe.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    alpha_probe
        .render(ctx.gl(), &inc, &scene_with_panel(region, 18, 6.0, true))
        .expect("render");
    let probe = GpuRenderer::to_premultiplied_bgra(
        &alpha_probe.read_pixels(ctx.gl(), &inc).expect("readback"),
    );
    // The panel fill is white at alpha 40, so the result is opaque only if the backdrop
    // underneath contributed alpha 255.
    let interior = [(60u32, 40u32), (90, 50), (75, 80)];
    let alphas: Vec<u8> = interior
        .iter()
        .map(|(x, y)| alpha_at(&probe, *x, *y))
        .collect();
    fail(
        &mut failures,
        "a translucent frost over an opaque backdrop stays opaque",
        alphas.iter().all(|a| *a == 255),
        &format!("alphas {alphas:?}"),
    );

    // 14. The vertical axis must blur as much as the horizontal one. A chain that drops its
    //     vertical pass leaves a horizontal band pristine, which reads as a colour wash
    //     rather than frost.
    let horizontal = |list: &mut DrawList| {
        // A tall thin bar: only a vertical blur can smear it sideways into soft edges.
        list.push_rect(
            NodeId::from_raw(31, 0),
            RectPrim {
                rect: Rect::new(76.0, 40.0, 8.0, 40.0),
                radius: Corners::ZERO,
                fill: Color::WHITE,
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
    };
    let mut axes = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    axes.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    // The bar must be painted *before* the backdrop, or the blur never reads it.
    let mut vertical_scene = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    vertical_scene.push_rect(
        NodeId::from_raw(30, 0),
        RectPrim {
            rect: Rect::new(0.0, 0.0, W as f32, H as f32),
            radius: Corners::ZERO,
            fill: Color::from_rgba8(0, 0, 0, 255),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    horizontal(&mut vertical_scene);
    vertical_scene.push_backdrop(BackdropEntry {
        rect: region,
        clip: region,
        corners: Corners::ZERO,
        radius: 0,
        sigma: 10.0,
        material: ui_core::draw::BackdropMaterial::PLAIN,
    });
    axes.render(ctx.gl(), &inc, &vertical_scene)
        .expect("render");
    let bar =
        GpuRenderer::to_premultiplied_bgra(&axes.read_pixels(ctx.gl(), &inc).expect("readback"));
    // Walk across the bar at mid-height: a correctly blurred bar has no step left.
    let mut steps = 0u32;
    let mut prev: Option<[u8; 4]> = None;
    for x in 60..104u32 {
        let i = ((60 * W + x) * 4) as usize;
        let px = [bar[i], bar[i + 1], bar[i + 2], bar[i + 3]];
        if prev.is_some_and(|p| (p[0] as i32 - px[0] as i32).abs() > 6) {
            steps += 1;
        }
        prev = Some(px);
    }
    fail(
        &mut failures,
        "a vertical bar is smeared sideways by the blur",
        steps == 0,
        &format!("{steps} sharp steps across the bar"),
    );

    // 15. Detail under the frost must actually be gone. A colour wash keeps the backdrop's
    //     structure (text, edges) while lowering its contrast; a real blur dissolves it into
    //     a smooth field, so neighbouring pixels stop tracking the original.
    let mut detail = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    detail.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    // A one-pixel checkerboard is the sharpest possible structure.
    let mut board = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    for gy in 0..(H / 2) {
        for gx in 0..(W / 2) {
            let on = (gx + gy) % 2 == 0;
            board.push_rect(
                NodeId::from_raw(40 + gx * 64 + gy, 0),
                RectPrim {
                    rect: Rect::new((gx * 2) as f32, (gy * 2) as f32, 2.0, 2.0),
                    radius: Corners::ZERO,
                    fill: if on {
                        Color::from_rgba8(255, 255, 255, 255)
                    } else {
                        Color::from_rgba8(0, 0, 0, 255)
                    },
                    border: None,
                    border_gradient: None,
                    gradient: None,
                    notch: None,
                },
            );
        }
    }
    board.push_backdrop(BackdropEntry {
        rect: region,
        clip: region,
        corners: Corners::ZERO,
        radius: 0,
        sigma: 6.0,
        material: ui_core::draw::BackdropMaterial::PLAIN,
    });
    detail.render(ctx.gl(), &inc, &board).expect("render");
    let checker =
        GpuRenderer::to_premultiplied_bgra(&detail.read_pixels(ctx.gl(), &inc).expect("readback"));
    // Inside the frost the checkerboard's two-tone alternation must be much flatter.
    let mut lo = 255u8;
    let mut hi = 0u8;
    for y in 36..84u32 {
        for x in 56..104u32 {
            let v = checker[((y * W + x) * 4) as usize];
            lo = lo.min(v);
            hi = hi.max(v);
        }
    }
    fail(
        &mut failures,
        "a checkerboard under the frost collapses to a flat field",
        hi - lo < 60,
        &format!("spread {lo}..{hi} = {}", hi - lo),
    );

    // 16. A frost touching the layer's bottom edge must still be blurred there. The blur
    //     reads below its own rect, so the snapshot has to stay defined past the frost.
    let mut edge = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    edge.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    let low = Rect::new(50.0, H as f32 - 40.0, 60.0, 40.0);
    let mut lowboard = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    for gy in 0..(H / 2) {
        for gx in 0..(W / 2) {
            let on = (gx + gy) % 2 == 0;
            lowboard.push_rect(
                NodeId::from_raw(900 + gx * 64 + gy, 0),
                RectPrim {
                    rect: Rect::new((gx * 2) as f32, (gy * 2) as f32, 2.0, 2.0),
                    radius: Corners::ZERO,
                    fill: if on {
                        Color::from_rgba8(255, 255, 255, 255)
                    } else {
                        Color::from_rgba8(0, 0, 0, 255)
                    },
                    border: None,
                    border_gradient: None,
                    gradient: None,
                    notch: None,
                },
            );
        }
    }
    lowboard.push_backdrop(BackdropEntry {
        rect: low,
        clip: low,
        corners: Corners::ZERO,
        radius: 0,
        sigma: 6.0,
        material: ui_core::draw::BackdropMaterial::PLAIN,
    });
    // Move the frost to the bottom at runtime: the filter reads the live frame each time,
    // so a frost that was higher up a moment ago leaves nothing behind to read.
    edge.render(ctx.gl(), &inc, &board)
        .expect("a frost higher up");
    edge.render(ctx.gl(), &inc, &lowboard)
        .expect("the frost at the bottom");
    let lowpx =
        GpuRenderer::to_premultiplied_bgra(&edge.read_pixels(ctx.gl(), &inc).expect("readback"));
    // Sample the last rows still inside the frost: the checkerboard must be gone there too.
    let mut worst = 0i32;
    for y in (H - 6)..(H - 1) {
        let mut lo = 255i32;
        let mut hi = 0i32;
        for x in 60..110 {
            let v = lowpx[((y * W + x) * 4) as usize] as i32;
            lo = lo.min(v);
            hi = hi.max(v);
        }
        worst = worst.max(hi - lo);
    }
    fail(
        &mut failures,
        "a frost touching the bottom edge is blurred there too",
        worst <= 6,
        &format!("spread near the bottom = {worst}"),
    );

    if failures > 0 {
        eprintln!("\n{failures} invariant(s) violated");
        std::process::exit(1);
    }
    println!("\nbackdrop blur writes back without punching a hole");
}
