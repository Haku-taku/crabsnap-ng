//! Fluent acrylic on the GPU: blur, then a luminosity wash, a tint and grain.
//!
//! Run: `cargo run -p ui-paint-gpu --example gpu_acrylic_scene`

use ui_core::NodeId;
use ui_core::draw::{BackdropEntry, BackdropMaterial, DrawList, RectPrim};
use ui_core::geom::{Color, Corners, Rect};
use ui_paint_gpu::{Acrylic, EglContext, GpuRenderer, OffscreenFbo};
use ui_widgets_fluent::material::{AcrylicRecipe, acrylic_dark, acrylic_light};

const W: u32 = 200;
const H: u32 = 140;
const SIGMA: f32 = 6.0;
const RADIUS: f32 = 16.0;

fn panel() -> Rect {
    Rect::new(40.0, 30.0, 120.0, 80.0)
}

fn canvas() -> Rect {
    Rect::new(0.0, 0.0, W as f32, H as f32)
}

fn solid(rect: Rect, fill: Color) -> RectPrim {
    RectPrim {
        rect,
        radius: Corners::ZERO,
        fill,
        border: None,
        border_gradient: None,
        gradient: None,
        notch: None,
    }
}

/// Two solid halves plus a white square on the seam, so the blur has real edges to soften.
fn scene(backdrop: bool) -> DrawList {
    let mut list = DrawList::new(canvas());
    list.push_rect(
        NodeId::from_raw(1, 0),
        solid(
            Rect::new(0.0, 0.0, W as f32 / 2.0, H as f32),
            Color::from_rgba8(40, 90, 200, 255),
        ),
    );
    list.push_rect(
        NodeId::from_raw(2, 0),
        solid(
            Rect::new(W as f32 / 2.0, 0.0, W as f32 / 2.0, H as f32),
            Color::from_rgba8(230, 200, 60, 255),
        ),
    );
    list.push_rect(
        NodeId::from_raw(3, 0),
        solid(Rect::new(90.0, 60.0, 20.0, 20.0), Color::WHITE),
    );
    if backdrop {
        list.push_backdrop(BackdropEntry {
            rect: panel(),
            clip: panel(),
            corners: Corners::all(RADIUS),
            radius: 12,
            sigma: SIGMA,
            material: BackdropMaterial::PLAIN,
        });
    }
    list
}

fn px(data: &[u8], x: u32, y: u32) -> [u8; 4] {
    let i = ((y * W + x) * 4) as usize;
    [data[i], data[i + 1], data[i + 2], data[i + 3]]
}

fn luma(p: [u8; 4]) -> f32 {
    (0.2126 * p[0] as f32 + 0.7152 * p[1] as f32 + 0.0722 * p[2] as f32) / 255.0
}

/// Interior sample points: inside the panel and clear of its rounded corners.
fn interior() -> Vec<(u32, u32)> {
    let mut out = Vec::new();
    for y in (46..94).step_by(4) {
        for x in (56..144).step_by(4) {
            out.push((x, y));
        }
    }
    out
}

fn max_delta(a: &[u8], b: &[u8]) -> u32 {
    a.iter()
        .zip(b.iter())
        .map(|(x, y)| (*x as i32 - *y as i32).unsigned_abs())
        .max()
        .unwrap_or(0)
}

fn mean_delta(a: &[u8], b: &[u8]) -> f64 {
    let total: u64 = a
        .iter()
        .zip(b.iter())
        .map(|(x, y)| (*x as i32 - *y as i32).unsigned_abs() as u64)
        .sum();
    total as f64 / a.len() as f64
}

fn report(name: &str, ok: bool, detail: &str, failures: &mut u32) {
    println!("{name:44} {detail:>26}  {}", if ok { "OK" } else { "FAIL" });
    if !ok {
        *failures += 1;
    }
}

/// Render one frame with `material` installed, or with the plain blit when `None`.
fn render(
    ctx: &EglContext,
    target: &OffscreenFbo,
    renderer: &mut GpuRenderer,
    material: Option<BackdropMaterial>,
    backdrop: bool,
) -> Vec<u8> {
    renderer.set_backdrop_material(material);
    renderer.clear(ctx.gl(), target, [0.0, 0.0, 0.0, 0.0]);
    renderer
        .render(ctx.gl(), target, &scene(backdrop))
        .expect("render");
    renderer.read_pixels(ctx.gl(), target).expect("readback")
}

fn acrylic(recipe: AcrylicRecipe) -> BackdropMaterial {
    BackdropMaterial::Acrylic(Acrylic {
        tint: recipe.tint,
        luminosity: recipe.luminosity,
        noise: recipe.noise,
    })
}

fn main() {
    let node = std::env::args()
        .nth(1)
        .or_else(ui_paint_gpu::output_render_node)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node.clone()).expect("node path");
    let ctx = EglContext::new(cnode.as_c_str()).expect("EGL context");
    println!("GPU: {} ({node})", ctx.renderer());
    let target = OffscreenFbo::new(ctx.gl(), W, H).expect("target");
    let mut gpu = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");

    // Reference renders: the scene without a backdrop, and with the plain blur blit.
    let sharp = render(&ctx, &target, &mut gpu, None, false);
    let plain = render(&ctx, &target, &mut gpu, None, true);

    let mut failures = 0u32;

    // 1. The material may only touch the panel: everything else stays byte-identical.
    let mut outside_delta = 0;
    for y in 0..H {
        for x in 0..W {
            let p = (x as f32, y as f32);
            let inside = p.0 >= panel().origin.x
                && p.0 < panel().origin.x + panel().size.w
                && p.1 >= panel().origin.y
                && p.1 < panel().origin.y + panel().size.h;
            if !inside {
                outside_delta = outside_delta.max(max_delta(&px(&sharp, x, y), &px(&plain, x, y)));
            }
        }
    }
    report(
        "1 plain blit leaves the frame outside the panel",
        outside_delta == 0,
        &format!("max delta {outside_delta}"),
        &mut failures,
    );

    // 2. A material with every stage off must reproduce the plain blit.
    let off = render(
        &ctx,
        &target,
        &mut gpu,
        Some(acrylic(AcrylicRecipe {
            tint: Color::rgba(0.0, 0.0, 0.0, 0.0),
            luminosity: Color::rgba(0.0, 0.0, 0.0, 0.0),
            noise: 0.0,
            blur_sigma: SIGMA,
            fallback: Color::BLACK,
        })),
        true,
    );
    let off_delta = max_delta(&off, &plain);
    report(
        "2 stages off == plain blur blit",
        off_delta <= 1,
        &format!("max delta {off_delta}"),
        &mut failures,
    );

    // 3. BlendMode.luminosity: the result's luma is the luminosity colour's luma.
    let wash = Color::from_rgba8(0xFC, 0xFC, 0xFC, 255);
    let washed = render(
        &ctx,
        &target,
        &mut gpu,
        Some(acrylic(AcrylicRecipe {
            tint: Color::rgba(0.0, 0.0, 0.0, 0.0),
            luminosity: wash,
            noise: 0.0,
            blur_sigma: SIGMA,
            fallback: Color::BLACK,
        })),
        true,
    );
    let want = luma([0xFC, 0xFC, 0xFC, 255]);
    let worst = interior()
        .into_iter()
        .map(|(x, y)| (luma(px(&washed, x, y)) - want).abs())
        .fold(0.0f32, f32::max);
    report(
        "3 luminosity stage lands on the wash's luma",
        worst <= 2.0 / 255.0,
        &format!("worst {:.4} vs {want:.4}", worst),
        &mut failures,
    );

    // 4. BlendMode.color keeps the destination's luma, so a half tint cannot brighten.
    let tinted = render(
        &ctx,
        &target,
        &mut gpu,
        Some(acrylic(AcrylicRecipe {
            tint: Color::from_rgba8(200, 40, 40, 128),
            luminosity: Color::rgba(0.0, 0.0, 0.0, 0.0),
            noise: 0.0,
            blur_sigma: SIGMA,
            fallback: Color::BLACK,
        })),
        true,
    );
    let worst = interior()
        .into_iter()
        .map(|(x, y)| (luma(px(&tinted, x, y)) - luma(px(&plain, x, y))).abs())
        .fold(0.0f32, f32::max);
    report(
        "4 half tint keeps the backdrop's luma",
        worst <= 2.0 / 255.0,
        &format!("worst {:.4}", worst),
        &mut failures,
    );
    // The same stage must still change the colour, or it did nothing at all.
    let chroma = interior()
        .into_iter()
        .map(|(x, y)| {
            let (a, b) = (px(&tinted, x, y), px(&plain, x, y));
            (a[0] as i32 - b[0] as i32)
                .abs()
                .max((a[2] as i32 - b[2] as i32).abs()) as u32
        })
        .max()
        .unwrap_or(0);
    report(
        "4b half tint does change the chroma",
        chroma >= 8,
        &format!("max channel shift {chroma}"),
        &mut failures,
    );

    // 5. Grain: off is a no-op, on perturbs neighbouring pixels by a few levels only.
    let grain = render(
        &ctx,
        &target,
        &mut gpu,
        Some(acrylic(AcrylicRecipe {
            tint: Color::rgba(0.0, 0.0, 0.0, 0.0),
            luminosity: Color::rgba(0.0, 0.0, 0.0, 0.0),
            noise: 0.02,
            blur_sigma: SIGMA,
            fallback: Color::BLACK,
        })),
        true,
    );
    let moved = interior()
        .into_iter()
        .filter(|(x, y)| px(&grain, *x, *y) != px(&off, *x, *y))
        .count();
    let shift = mean_delta(&grain, &off);
    report(
        "5 grain moves interior pixels",
        moved * 4 > interior().len(),
        &format!("{moved} of {} moved", interior().len()),
        &mut failures,
    );
    report(
        "5b grain stays at a couple of levels",
        shift < 2.0,
        &format!("mean {shift:.3}/255"),
        &mut failures,
    );
    // A still frame must not shimmer: the same scene twice is byte-identical.
    let again = render(
        &ctx,
        &target,
        &mut gpu,
        Some(acrylic(AcrylicRecipe {
            tint: Color::rgba(0.0, 0.0, 0.0, 0.0),
            luminosity: Color::rgba(0.0, 0.0, 0.0, 0.0),
            noise: 0.02,
            blur_sigma: SIGMA,
            fallback: Color::BLACK,
        })),
        true,
    );
    report(
        "5c grain is deterministic across frames",
        max_delta(&grain, &again) == 0,
        &format!(
            "{} bytes differ",
            grain
                .iter()
                .zip(again.iter())
                .filter(|(a, b)| a != b)
                .count()
        ),
        &mut failures,
    );

    // 6. The pack's recipe must differ from the plain blur, and light from dark.
    let light = render(
        &ctx,
        &target,
        &mut gpu,
        Some(acrylic(acrylic_light())),
        true,
    );
    let dark = render(&ctx, &target, &mut gpu, Some(acrylic(acrylic_dark())), true);
    let light_shift = mean_delta(&light, &plain);
    report(
        "6 the pack's light acrylic changes the panel",
        light_shift > 1.0,
        &format!("mean {light_shift:.3}/255"),
        &mut failures,
    );
    report(
        "6b light and dark acrylic differ",
        mean_delta(&light, &dark) > 1.0,
        &format!("mean {:.3}/255", mean_delta(&light, &dark)),
        &mut failures,
    );

    // 7. The pass must be accounted for, not silently skipped.
    let stats = gpu.stats();
    report(
        "7 the material pass ran and was counted",
        stats.material_passes == 1 && stats.frosts == 1,
        &format!("{} material, {} frost", stats.material_passes, stats.frosts),
        &mut failures,
    );

    if std::env::var("DUMP_ACRYLIC").is_ok() {
        use std::io::Write;
        for (name, data) in [("plain", &plain), ("light", &light), ("dark", &dark)] {
            let path = format!("/tmp/acrylic_{name}.ppm");
            let mut f = std::fs::File::create(&path).expect("ppm");
            write!(f, "P6\n{} {}\n255\n", W, H).expect("hdr");
            for p in data.as_chunks::<4>().0 {
                let _ = f.write_all(&[p[0], p[1], p[2]]);
            }
            println!("dumped {path}");
        }
    }

    println!("\nFAIL={failures}");
    if failures > 0 {
        std::process::exit(1);
    }
}
