//! Compares CPU and GPU rendering of the *same* real-glyph draw list.
//!
//! `gpu_scene` proves the rect path with a synthetic atlas; this one proves that text
//! resolved by `TextPass` goes through both backends identically.
//!
//! Run: `cargo run -p ui-paint-gpu --example gpu_text_scene --features ""`

use ui_core::geom::{Color, Corners, Insets};
use ui_core::{AxisSize, Decl, Grow, Id, NodeData, NodeKind, SizeClass};
use ui_paint::{CoverageAtlas, CpuRenderer, Pixels};
use ui_paint_gpu::{AtlasUpload, EglContext, GpuRenderer, OffscreenFbo};
use ui_platform::{App, AppLoop};

const W: u32 = 520;
const H: u32 = 140;

struct Demo;

fn line(id: &'static str, body: &str, size: f32, color: Color) -> Decl {
    Decl {
        id: Id::str(id),
        kind: NodeKind::Text,
        shapes: Vec::new(),
        data: NodeData::Text {
            ink: color,
            block: ui_core::TextBlock {
                runs: vec![ui_core::TextRun::new(body, ui_core::TextStyle::new(size))],
                align: ui_core::TextAlign::Start,
                max_lines: None,
                line_gap: 0.0,
                indent: 0.0,
                hanging: 0.0,
                atoms: Vec::new(),
                input_base: None,
                line_numbers: None,
                structures: Vec::new(),
            },
            caret: None,
            selection: None,
            composing: None,
            nowrap: false,
        },
        size_class: SizeClass {
            width: AxisSize::hug(0.0, 500.0),
            height: AxisSize::hug(size, size * 1.4),
            grow_x: Grow::No,
            grow_y: Grow::No,
        },
        ink_margin: Insets::ZERO,
        box_model: Default::default(),
        offset: ui_core::geom::Point::new(0.0, 0.0),
        cursor: None,
        sense: ui_core::Sense::NONE,
        disabled: false,
        grid: Default::default(),
        placement: Default::default(),
        env: None,
        children: Vec::new(),
    }
}

impl App for Demo {
    fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn ui_platform::Element> {
        let decl = {
            Decl::container(Id::str("root"), NodeKind::Column)
                .background(Color::from_rgba8(20, 22, 28, 255), Corners::ZERO)
                .child(line(
                    "a",
                    "Glyphs must match between backends",
                    20.0,
                    Color::WHITE,
                ))
                .child(line(
                    "b",
                    "中日韩字形",
                    18.0,
                    Color::from_rgba8(255, 220, 150, 255),
                ))
        };
        ui_platform::from_decl(decl)
    }
}

/// Both sides are top-down already; only the channel order and premultiplication differ.
fn to_rgb(data: &[u8], premultiplied_bgra: bool) -> Vec<[u8; 3]> {
    data.as_chunks::<4>()
        .0
        .iter()
        .map(|p| {
            if premultiplied_bgra {
                let a = p[3] as u32;
                if a == 0 {
                    [0, 0, 0]
                } else {
                    let un = |c: u8| ((c as u32 * 255 + a / 2) / a).min(255) as u8;
                    [un(p[2]), un(p[1]), un(p[0])]
                }
            } else {
                [p[0], p[1], p[2]]
            }
        })
        .collect()
}

/// Ink above the background, so glyph coverage dominates the metric.
fn ink(rgb: &[[u8; 3]]) -> f64 {
    rgb.iter()
        .map(|p| (p[0] as f64 - 20.0).max(0.0) / 255.0)
        .sum()
}

fn centroid(rgb: &[[u8; 3]]) -> (f64, f64) {
    let mut sx = 0.0;
    let mut sy = 0.0;
    let mut sw = 0.0;
    for y in 0..H as usize {
        for x in 0..W as usize {
            let w = (rgb[y * W as usize + x][0] as f64 - 20.0).max(0.0);
            sx += w * x as f64;
            sy += w * y as f64;
            sw += w;
        }
    }
    if sw == 0.0 {
        (0.0, 0.0)
    } else {
        (sx / sw, sy / sw)
    }
}

fn report(name: &str, value: f64, limit: f64, unit: &str, failures: &mut u32) {
    let ok = value <= limit;
    println!(
        "{name:30} {value:8.4}{unit}  (limit {limit}{unit})  {}",
        if ok { "OK" } else { "FAIL" }
    );
    if !ok {
        *failures += 1;
    }
}

fn main() {
    // Build once through the shared pipeline.
    let mut app = AppLoop::with_stack(Demo, &["MiSans VF", "Tahoma"]);
    app.build((W, H), None);
    if !app.text_pass().has_face() {
        eprintln!("no font available; nothing to compare");
        std::process::exit(1);
    }
    let glyphs = app.draw_list().prims.glyphs.len();
    let unresolved = app.text_pass().unresolved();
    println!("resolved list: glyphs={glyphs} unresolved={unresolved}");
    if unresolved > 0 {
        eprintln!("text left unresolved; comparison would be meaningless");
        std::process::exit(1);
    }

    let (aw, ah) = app.text_pass().dimensions();
    let atlas = app.text_pass().atlas().to_vec();

    let mut cpu = CpuRenderer::new();
    cpu.set_atlas(CoverageAtlas {
        width: aw,
        height: ah,
        data: atlas.clone(),
    });
    let mut pixels = Pixels::new(W, H);
    cpu.render(app.draw_list(), &mut pixels, &ui_core::damage::Damage::Full);
    let cpu_rgb = to_rgb(pixels.as_bytes(), true);

    let node = std::env::args()
        .nth(1)
        .or_else(ui_paint_gpu::output_render_node)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node.clone()).expect("node path");
    let ctx = EglContext::new(cnode.as_c_str()).expect("EGL context");
    println!("GPU: {} ({node})", ctx.renderer());

    let target = OffscreenFbo::new(ctx.gl(), W, H).expect("target");
    let mut gpu = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    gpu.set_atlas(
        ctx.gl(),
        AtlasUpload {
            width: aw,
            height: ah,
            data: atlas,
        },
    )
    .expect("atlas");
    gpu.clear(
        ctx.gl(),
        &target,
        [20.0 / 255.0, 22.0 / 255.0, 28.0 / 255.0, 1.0],
    );
    let stats = gpu
        .render(ctx.gl(), &target, app.draw_list())
        .expect("render");
    let raw = gpu.read_pixels(ctx.gl(), &target).expect("readback");
    let gpu_rgb = to_rgb(&raw, false);
    println!("stats: {stats:?}");

    let mut failures = 0;

    // [1] Total ink: the same glyphs must lay down the same amount of coverage.
    let (i_cpu, i_gpu) = (ink(&cpu_rgb), ink(&gpu_rgb));
    report(
        "[1] glyph ink",
        ((i_gpu - i_cpu).abs() / i_cpu.max(1.0)) * 100.0,
        0.5,
        "%",
        &mut failures,
    );

    // [2] No wraparound: an overflow shows up as the GPU being far darker than the CPU
    // exactly where the CPU is bright.
    let overflow = gpu_rgb
        .iter()
        .zip(&cpu_rgb)
        .filter(|(g, c)| g[0] as i32 + 40 < c[0] as i32 && c[0] > 200)
        .count();
    report(
        "[2] overflow pixels",
        overflow as f64 / (W * H) as f64 * 100.0,
        0.05,
        "%",
        &mut failures,
    );

    // [3] Position: the ink centroid must sit at the same place.
    let (cx_c, cy_c) = centroid(&cpu_rgb);
    let (cx_g, cy_g) = centroid(&gpu_rgb);
    let shift = ((cx_g - cx_c).powi(2) + (cy_g - cy_c).powi(2)).sqrt();
    report("[3] centroid shift", shift, 0.5, "px", &mut failures);

    // [4] Per-pixel agreement outside antialiased edges.
    let mut big = 0u32;
    for (g, c) in gpu_rgb.iter().zip(&cpu_rgb) {
        for ch in 0..3 {
            if (g[ch] as i32 - c[ch] as i32).abs() > 8 {
                big += 1;
                break;
            }
        }
    }
    report(
        "[4] differing pixels",
        big as f64 / (W * H) as f64 * 100.0,
        0.2,
        "%",
        &mut failures,
    );

    gpu.release(ctx.gl());
    target.release(ctx.gl());

    if failures > 0 {
        eprintln!("\n{failures} invariant(s) violated");
        std::process::exit(1);
    }
    println!("\ntext invariants hold on both backends");
}
