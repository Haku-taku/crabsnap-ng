//! A partial frame must reproduce the full render of the same scene, frosts included.

use ui_core::NodeId;
use ui_core::damage::Damage;
use ui_core::draw::DrawList;
use ui_core::draw::{BackdropEntry, BackdropMaterial, LiquidGlass, RectPrim};
use ui_core::geom::{Color, Corners, Rect};
use ui_paint_gpu::{EglContext, GpuRenderer, OffscreenFbo};

const W: f32 = 240.0;
const H: f32 = 140.0;
const SCALE: f32 = 2.0;
const STRIPE: f32 = 10.0;

fn glass_rect() -> Rect {
    Rect::new(120.0, 60.0, 90.0, 50.0)
}

/// Stripes over the whole frame; `recolour` paints one stripe bright red instead.
fn scene(material: Option<BackdropMaterial>, recolour: Option<usize>) -> DrawList {
    let mut list = DrawList::new(Rect::new(0.0, 0.0, W, H));
    let mut x = 0.0;
    let mut id = 1;
    while x < W {
        let k = (x / STRIPE) as usize;
        let fill = if Some(k) == recolour {
            Color::from_rgba8(255, 0, 0, 255)
        } else if k.is_multiple_of(2) {
            Color::from_rgba8(236, 236, 236, 255)
        } else {
            Color::from_rgba8(28, 28, 28, 255)
        };
        list.push_rect(
            NodeId::from_raw(id, 0),
            RectPrim {
                rect: Rect::new(x, 0.0, STRIPE.min(W - x), H),
                radius: Corners::ZERO,
                fill,
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
        x += STRIPE;
        id += 1;
    }
    if let Some(material) = material {
        let r = glass_rect();
        list.push_backdrop(BackdropEntry {
            rect: r,
            clip: r,
            corners: Corners::all(16.0),
            radius: 16,
            sigma: 0.0,
            material,
        });
    }
    list
}

fn kit() -> LiquidGlass {
    use ui_widgets_glass::material::{Control, glass_recipe};
    let kit = glass_recipe(&ui_widgets_glass::pack(), Control::Switch);
    LiquidGlass {
        blend: [ui_core::draw::BlendShape::NONE; ui_core::draw::BLEND_SHAPES],
        blend_count: 0,
        blend_k: 0.0,
        ..kit
    }
}

fn device(r: Rect) -> [i32; 4] {
    [
        (r.origin.x * SCALE) as i32,
        (r.origin.y * SCALE) as i32,
        (r.size.w * SCALE) as i32,
        (r.size.h * SCALE) as i32,
    ]
}

/// Pixels that differ, so a failure prints a number instead of two megabyte buffers.
fn differing(a: &[u8], b: &[u8]) -> u64 {
    a.as_chunks::<4>()
        .0
        .iter()
        .zip(b.as_chunks::<4>().0)
        .filter(|(p, q)| p != q)
        .count() as u64
}

fn main() {
    let node = std::env::args()
        .nth(1)
        .or_else(ui_paint_gpu::output_render_node)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node).expect("node path");
    let ctx = EglContext::new(cnode.as_c_str()).expect("EGL context");
    let (w, h) = ((W * SCALE) as u32, (H * SCALE) as u32);
    let target = OffscreenFbo::new(ctx.gl(), w, h).expect("target");
    let mut gpu = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    gpu.set_scale(SCALE);
    let material = Some(BackdropMaterial::LiquidGlass(kit()));
    let glass = device(glass_rect());

    // Reference frames: the whole surface, so the glass is composited exactly once.
    let full_of = |gpu: &mut GpuRenderer, recolour: Option<usize>| {
        gpu.render(ctx.gl(), &target, &scene(material, recolour))
            .expect("full frame");
        gpu.frame_pixels(ctx.gl()).expect("frame pixels").2
    };
    let base = full_of(&mut gpu, None);
    let red = full_of(&mut gpu, Some(13));

    // A partial frame over a static scene must reproduce the reference exactly, and the
    // band must grow over the glass whenever it reaches the glass's read box.
    let cases: [(&str, Rect, bool); 3] = [
        ("far", Rect::new(4.0, 4.0, 12.0, 12.0), false),
        ("inside", Rect::new(150.0, 80.0, 10.0, 10.0), true),
        (
            "beside",
            Rect::new(glass_rect().origin.x - 24.0, 80.0, 8.0, 8.0),
            true,
        ),
    ];
    for (name, rect, touches_glass) in cases {
        gpu.render(ctx.gl(), &target, &scene(material, None))
            .expect("reset");
        let stats = gpu
            .render_frame(
                ctx.gl(),
                &target,
                &scene(material, None),
                &Damage::Rects(vec![rect]),
            )
            .expect("partial frame");
        let (_, _, now) = gpu.frame_pixels(ctx.gl()).expect("frame pixels");
        let band = stats.band.expect("partial frame expected");
        let covers = band[0] <= glass[0]
            && band[1] <= glass[1]
            && band[0] + band[2] >= glass[0] + glass[2]
            && band[1] + band[3] >= glass[1] + glass[3];
        let off = differing(&now, &base);
        println!(
            "{name}: band={band:?} frosts={} covers_glass={covers} differing={off}",
            stats.frosts
        );
        assert_eq!(
            off, 0,
            "{name}: partial frame diverged from the full render"
        );
        assert_eq!(
            covers, touches_glass,
            "{name}: band growth over the glass is wrong"
        );
        assert_eq!(
            stats.frosts,
            u32::from(touches_glass),
            "{name}: wrong recomposite count"
        );
    }

    // Repeated partial frames must not accumulate: each one recomposites over pixels this
    // frame cleared, never over the frost's own output.
    gpu.render(ctx.gl(), &target, &scene(material, None))
        .expect("reset");
    for rect in [
        Rect::new(4.0, 4.0, 12.0, 12.0),
        Rect::new(150.0, 80.0, 10.0, 10.0),
        Rect::new(4.0, 4.0, 12.0, 12.0),
        Rect::new(glass_rect().origin.x - 24.0, 80.0, 8.0, 8.0),
        Rect::new(4.0, 4.0, 12.0, 12.0),
    ] {
        gpu.render_frame(
            ctx.gl(),
            &target,
            &scene(material, None),
            &Damage::Rects(vec![rect]),
        )
        .expect("partial frame");
    }
    let (_, _, now) = gpu.frame_pixels(ctx.gl()).expect("frame pixels");
    let off = differing(&now, &base);
    println!("sequence: differing={off}");
    assert_eq!(off, 0, "partial frames accumulated a difference");

    // The real test: repaint a stripe the glass reads. Only a band that grew over the
    // glass can match the full render of the recoloured scene.
    gpu.render(ctx.gl(), &target, &scene(material, None))
        .expect("reset");
    let stripe = Rect::new(13.0 * STRIPE, 0.0, STRIPE, H);
    let stats = gpu
        .render_frame(
            ctx.gl(),
            &target,
            &scene(material, Some(13)),
            &Damage::Rects(vec![stripe]),
        )
        .expect("partial frame");
    let (_, _, now) = gpu.frame_pixels(ctx.gl()).expect("frame pixels");
    let off = differing(&now, &red);
    println!(
        "recolour: band={:?} frosts={} differing={off}",
        stats.band, stats.frosts
    );
    assert_eq!(
        off, 0,
        "a repainted stripe under the glass did not reach the frost"
    );
    println!("ok");
}
