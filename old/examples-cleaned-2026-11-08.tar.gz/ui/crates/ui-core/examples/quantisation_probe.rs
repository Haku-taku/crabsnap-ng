fn main() {
    use ui_core::colour::TransferFunction as T;
    let ramp: Vec<f32> = (0..64).map(|i| 0.0002 + i as f32 * 0.00002).collect();
    let count = |tf: T, bits: u8| {
        let levels = ((1u32 << bits) - 1) as f32;
        let mut v: Vec<u16> = ramp
            .iter()
            .map(|&l| (tf.encode(l) * levels).round() as u16)
            .collect();
        v.sort_unstable();
        v.dedup();
        v.len()
    };
    println!("暗部渐变 64 级，不同编码数：");
    println!("  sRGB 8-bit : {}", count(T::Srgb, 8));
    println!("  sRGB 10-bit: {}", count(T::Srgb, 10));
    println!("  PQ   10-bit: {}", count(T::Pq, 10));
    println!("  PQ   12-bit: {}", count(T::Pq, 12));
}
