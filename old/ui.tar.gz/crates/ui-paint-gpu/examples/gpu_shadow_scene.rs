//! Elevation: a soft shadow is drawn under its shape, not through it.
//! 立面：柔和阴影画在形状之下，不会穿到形状上。
//!
//! Run: `WAYLAND_DISPLAY=wayland-2 cargo run -p ui-paint-gpu --example gpu_shadow_scene`

use ui_core::draw::{DrawList, PrimKind, RectPrim, ShadowPrim};
use ui_core::geom::{Color, Corners, Rect};
use ui_core::NodeId;
use ui_paint_gpu::{EglContext, GpuRenderer, OffscreenFbo};

const W: u32 = 300;
const H: u32 = 220;
const ROUND: Rect = Rect {
    origin: ui_core::geom::Point { x: 80.0, y: 60.0 },
    size: ui_core::geom::Size { w: 140.0, h: 100.0 },
};
const BLUR: f32 = 10.0;
const ALPHA: f32 = 0.5;

fn scene() -> DrawList {
    let mut list = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    // A white page, so shadow pixels are measurable as "less than white".
    // 白色底，因此阴影像素可以直接量成「低于白」。
    list.push_rect(
        NodeId::from_raw(0, 0),
        RectPrim {
            rect: Rect::new(0.0, 0.0, W as f32, H as f32),
            radius: Corners::ZERO,
            fill: Color::WHITE,
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    list.push_shadow(
        NodeId::from_raw(0, 1),
        ShadowPrim {
            rect: ROUND,
            corners: Corners::all(12.0),
            colour: Color::rgba(0.0, 0.0, 0.0, ALPHA),
            blur: BLUR,
            dy: 0.0,
            ring: 0.0,
        },
    );
    // The surface itself: opaque, and must stay untinted by its own shadow.
    // 表面本身：不透明，且不得被自己的阴影染色。
    list.push_rect(
        NodeId::from_raw(0, 2),
        RectPrim {
            rect: ROUND,
            radius: Corners::all(12.0),
            fill: Color::WHITE,
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    list
}

fn main() {
    let node = std::env::args()
        .nth(1)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node.clone()).expect("node path");
    let egl = EglContext::new(cnode.as_c_str()).expect("EGL");
    let target = OffscreenFbo::new(egl.gl(), W, H).expect("target");
    let mut gpu = GpuRenderer::new(egl.gl(), egl.is_gles()).expect("renderer");
    let list = scene();
    gpu.clear(egl.gl(), &target, [0.0, 0.0, 0.0, 1.0]);
    let stats = gpu.render(egl.gl(), &target, &list).expect("render");
    let out = gpu.read_pixels(egl.gl(), &target).expect("readback");

    let mut fail = 0;
    let mut check = |name: &str, got: f32, limit: f32, want_below: bool| {
        let ok = if want_below { got <= limit } else { got >= limit };
        println!(
            "  {} {:>8.3}  ({} {:>5.2})  {}",
            if ok { "ok  " } else { "FAIL" },
            got,
            if want_below { "limit" } else { "floor" },
            limit,
            name
        );
        if !ok {
            fail += 1;
        }
    };

    // Readback is raw RGBA8 rows; these frames are opaque, so luma is enough.
    // 读回的是原始 RGBA8 行；这些帧不透明，用亮度即可。
    let luma = |x: u32, y: u32| -> f32 {
        let i = (y as usize * W as usize + x as usize) * 4;
        let p = &out[i..i + 3];
        (0.2126 * p[0] as f32 + 0.7152 * p[1] as f32 + 0.0722 * p[2] as f32) / 255.0
    };

    // 1. Directly under the middle of the shape: covered by the surface, so pure white.
    // 1. 形状正中下方：被表面遮住，应当是纯白。
    check("the surface hides its own shadow", luma(150, 110), 0.995, false);

    // 2. Just outside the left edge, inside the falloff: darker than the page.
    // 2. 左边缘外一点、仍在衰减内：比页面暗。
    let outside = luma(74, 110);
    check(
        "the shadow darkens the page just outside the edge",
        1.0 - outside,
        0.10,
        false,
    );

    // 3. The falloff is monotone: the further from the edge, the closer to the page.
    // 3. 衰减是单调的：离边缘越远越接近页面本色。
    let near = 1.0 - luma(78, 110);
    let far = 1.0 - luma(70, 110);
    check("the shadow is stronger nearer the edge", near - far, 0.02, false);
    check("the shadow ends inside its falloff", 1.0 - luma(66, 110), 0.01, true);

    // 4. The shadow never reaches a pixel further than `blur` from the shape.
    // 4. 阴影不会出现在离形状超过 `blur` 的像素上。
    let beyond = luma((80.0 - BLUR) as u32 - 2, 110);
    check("nothing casts beyond the falloff", 1.0 - beyond, 0.002, true);

    // 5. The rounded corner keeps the shadow out of its notch.
    // 5. 圆角处阴影不该进入缺角。
    check("no shadow in the corner notch", 1.0 - luma(84, 64), 0.10, true);

    println!(
        "  stats: rects {} shadows_drawn {} draw_calls {}",
        stats.rects, stats.shadows_drawn, stats.draw_calls
    );
    check(
        "the shadow primitive was drawn",
        stats.shadows_drawn as f32,
        1.0,
        false,
    );
    let kinds = list.prims.len_of(PrimKind::Shadow);
    check("one shadow primitive in the list", kinds as f32, 1.0, false);

    println!("\nFAIL={fail}");
    std::process::exit(if fail == 0 { 0 } else { 1 });
}
