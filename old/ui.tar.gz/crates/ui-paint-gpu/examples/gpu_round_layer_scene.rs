//! Check that a layer's corner radius is honoured by both backends.
//! 验证两个后端都遵守层的圆角半径。
//!
//! A layer's radius was carried in the draw list but unused by either rasteriser; these
//! invariants fail if it stops being applied, and distinguish "cut" from "never drawn".
//! 层的半径一直存在于绘制列表里但两个光栅化器都没用；这些不变量在它失效时变红，
//! 并区分「被切掉」与「根本没画」。
//!
//! Run: `cargo run -p ui-paint-gpu --example gpu_round_layer_scene`

use ui_core::damage::Damage;
use ui_core::draw::{DrawList, RectPrim};
use ui_core::geom::{Color, Corners, Rect};
use ui_core::NodeId;
use ui_paint::{CpuRenderer, Pixels};
use ui_paint_gpu::{EglContext, GpuRenderer, OffscreenFbo};

const W: u32 = 64;
const H: u32 = 64;
const PAD: f32 = 8.0;
const RADIUS: f32 = 16.0;

/// A layer whose content fills the layer bounds, so the corner is the only thing that
/// can make it transparent.
/// 层内容填满层边界，因此只有圆角能让角落透明。
fn scene(radius: f32) -> DrawList {
    let mut list = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    list.push_layer(
        Rect::new(PAD, PAD, W as f32 - PAD * 2.0, H as f32 - PAD * 2.0),
        Vec::new(),
        Corners::all(radius),
    );
    list.push_rect(
        NodeId::from_raw(1, 0),
        RectPrim {
            rect: Rect::new(PAD, PAD, W as f32 - PAD * 2.0, H as f32 - PAD * 2.0),
            radius: Corners::all(0.0),
            fill: Color::WHITE,
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    list.pop_layer();
    list
}

fn alpha_at(data: &[u8], x: u32, y: u32) -> u8 {
    data[((y * W + x) * 4 + 3) as usize]
}

fn main() {
    let node = std::env::args()
        .nth(1)
        .or_else(ui_paint_gpu::output_render_node)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node.clone()).expect("node path");
    let ctx = EglContext::new(cnode.as_c_str()).expect("EGL context");
    println!("GPU: {} ({node})", ctx.renderer());
    let target = OffscreenFbo::new(ctx.gl(), W, H).expect("target");
    let mut gpu = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    let mut cpu = CpuRenderer::new();

    let mut failures = 0;
    let mut report = |name: &str, ok: bool, detail: String| {
        println!("  {name}: {} ({detail})", if ok { "ok" } else { "FAIL" });
        if !ok {
            failures += 1;
        }
    };

    // [1] A rounded layer has a transparent corner and an opaque centre, on both backends.
    // [1] 圆角层的角落透明、中心不透明，两个后端都是。
    let rounded = scene(RADIUS);
    let mut cpu_px = Pixels::new(W, H);
    cpu.render(&rounded, &mut cpu_px, &Damage::Full);
    gpu.clear(ctx.gl(), &target, [0.0, 0.0, 0.0, 0.0]);
    gpu.render(ctx.gl(), &target, &rounded).expect("render");
    let gpu_px = gpu.read_pixels(ctx.gl(), &target).expect("readback");
    // The corner pixel sits at the layer's own top-left; the centre is far from any arc.
    // 角落像素位于层自身的左上角，中心远离任何弧线。
    let (cx, cy) = (PAD as u32, PAD as u32);
    let (mx, my) = (W / 2, H / 2);
    let cpu_corner = alpha_at(&cpu_px.data, cx, cy);
    let gpu_corner = alpha_at(&gpu_px, cx, cy);
    report(
        "[1] rounded corner is cut",
        cpu_corner == 0 && gpu_corner == 0,
        format!("cpu={cpu_corner} gpu={gpu_corner}"),
    );
    report(
        "[2] centre stays opaque",
        alpha_at(&cpu_px.data, mx, my) == 255 && alpha_at(&gpu_px, mx, my) == 255,
        format!(
            "cpu={} gpu={}",
            alpha_at(&cpu_px.data, mx, my),
            alpha_at(&gpu_px, mx, my)
        ),
    );

    // [3] Without a radius the same corner is opaque: the cut comes from the radius,
    // not from the layer being empty.
    // [3] 没有半径时同一角落不透明：切角来自半径，而不是层本身是空的。
    let square = scene(0.0);
    let mut cpu_sq = Pixels::new(W, H);
    cpu.render(&square, &mut cpu_sq, &Damage::Full);
    gpu.clear(ctx.gl(), &target, [0.0, 0.0, 0.0, 0.0]);
    gpu.render(ctx.gl(), &target, &square).expect("render");
    let gpu_sq = gpu.read_pixels(ctx.gl(), &target).expect("readback");
    report(
        "[3] zero radius keeps the corner",
        alpha_at(&cpu_sq.data, cx, cy) == 255 && alpha_at(&gpu_sq, cx, cy) == 255,
        format!(
            "cpu={} gpu={}",
            alpha_at(&cpu_sq.data, cx, cy),
            alpha_at(&gpu_sq, cx, cy)
        ),
    );

    // [4] Both backends agree on how much the radius removed. Coverage AA is
    // implementation-defined, so this compares totals, not individual pixels.
    // [4] 两后端对被半径去掉的量达成一致。覆盖率 AA 是实现定义的，
    // 因此比较总量而不是逐像素。
    let mass = |data: &[u8]| -> u64 {
        (0..H)
            .flat_map(|y| (0..W).map(move |x| (x, y)))
            .map(|(x, y)| alpha_at(data, x, y) as u64)
            .sum()
    };
    let (cm, gm) = (mass(&cpu_px.data), mass(&gpu_px));
    let diff = cm.abs_diff(gm);
    report(
        "[4] backends agree on cut area",
        diff * 100 <= cm.max(1) * 2,
        format!("cpu={cm} gpu={gm} diff={diff}"),
    );

    println!("\nFAIL={failures}");
    if failures > 0 {
        std::process::exit(1);
    }
}
