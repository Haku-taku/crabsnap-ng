//! Compares CPU and GPU compositing of offscreen layers.
//! 比较 CPU 与 GPU 的离屏层合成。
//!
//! The invariant that matters is not "both produce the same pixels" but that the
//! *group* composites once: two overlapping opaque children inside a 50% layer must
//! read 50% everywhere, not 75% in the overlap.
//! 关键不变量不是"两边像素相同"，而是**整组只合成一次**：
//! 50% 层内两个重叠的不透明子节点处处都应是 50%，重叠处不能变成 75%。
//!
//! Run: `cargo run -p ui-paint-gpu --example gpu_layer_scene`

use ui_core::damage::Damage;
use ui_core::draw::{DrawList, RectPrim};
use ui_core::geom::{Color, Corners, Rect};
use ui_core::NodeId;
use ui_paint::{CpuRenderer, Pixels};
use ui_paint_gpu::{EglContext, GpuRenderer, OffscreenFbo};

const W: u32 = 120;
const H: u32 = 60;
const OPACITY: f32 = 0.5;

fn square(_owner: u32, x: f32, y: f32) -> RectPrim {
    RectPrim {
        rect: Rect::new(x, y, 24.0, 24.0),
        radius: Corners::ZERO,
        fill: Color::WHITE,
        gradient: None,
        border: None,
        border_gradient: None,
        notch: None,
    }
}

/// Two overlapping opaque squares inside a 50% layer, plus one outside it.
/// 50% 层内两个重叠的不透明方块，另加一个在层外。
fn scene() -> DrawList {
    let mut list = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    list.push_layer(
        Rect::new(0.0, 0.0, W as f32, H as f32),
        vec![ui_core::Effect::opacity(OPACITY)],
        Corners::ZERO,
    );
    list.push_rect(NodeId::from_raw(1, 0), square(1, 10.0, 10.0));
    list.push_rect(NodeId::from_raw(2, 0), square(2, 22.0, 10.0));
    list.pop_layer();
    list.push_rect(NodeId::from_raw(3, 0), square(3, 70.0, 10.0));
    list
}

/// Alpha channel at a point, from premultiplied BGRA.
/// 从预乘 BGRA 取某点的 alpha。
fn alpha_at(data: &[u8], x: u32, y: u32) -> u8 {
    data[((y * W + x) * 4 + 3) as usize]
}

fn report(name: &str, value: f64, limit: f64, unit: &str, failures: &mut u32) {
    let ok = value <= limit;
    println!(
        "{name:32} {value:8.4}{unit}  (limit {limit}{unit})  {}",
        if ok { "OK" } else { "FAIL" }
    );
    if !ok {
        *failures += 1;
    }
}

fn main() {
    let list = scene();

    let mut cpu = CpuRenderer::new();
    let mut pixels = Pixels::new(W, H);
    cpu.render(&list, &mut pixels, &Damage::Full);
    let cpu_data = pixels.data.clone();
    // `Pixels` holds premultiplied BGRA; comparisons below want straight RGBA.
    // `Pixels` 是预乘 BGRA；下面的比较需要非预乘 RGBA。
    let cpu_straight = unpremultiply_bgra(&cpu_data);

    let node = std::env::args()
        .nth(1)
        .or_else(ui_paint_gpu::output_render_node)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node.clone()).expect("node path");
    let ctx = EglContext::new(cnode.as_c_str()).expect("EGL context");
    println!("GPU: {} ({node})", ctx.renderer());

    let target = OffscreenFbo::new(ctx.gl(), W, H).expect("target");
    let mut gpu = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    gpu.clear(ctx.gl(), &target, [0.0, 0.0, 0.0, 0.0]);
    let stats = gpu.render(ctx.gl(), &target, &list).expect("render");
    let gpu_data = gpu.read_pixels(ctx.gl(), &target).expect("readback");
    println!("stats: {stats:?}");

    let mut failures = 0;

    // Sample points: inside the first square, inside the second, and in the overlap.
    // 采样点：第一个方块内、第二个方块内、重叠处。
    let single_cpu = alpha_at(&cpu_data, 15, 20);
    let overlap_cpu = alpha_at(&cpu_data, 25, 20);
    let outside_cpu = alpha_at(&cpu_data, 75, 20);

    println!(
        "  cpu: single={single_cpu} overlap={overlap_cpu} outside={outside_cpu}"
    );
    println!(
        "  gpu: single={} overlap={} outside={}",
        alpha_at(&gpu_data, 15, 20),
        alpha_at(&gpu_data, 25, 20),
        alpha_at(&gpu_data, 75, 20)
    );

    // [1] The group composites once: the overlap must equal a single child.
    // [1] 整组只合成一次：重叠处必须等于单个子节点。
    let delta = (overlap_cpu as i32 - single_cpu as i32).abs();
    report("[1] cpu overlap uniform", delta as f64, 0.0, "", &mut failures);
    let delta = (alpha_at(&gpu_data, 25, 20) as i32 - alpha_at(&gpu_data, 15, 20) as i32).abs();
    report("[2] gpu overlap uniform", delta as f64, 0.0, "", &mut failures);

    // [3] The layer's opacity is actually applied.
    // [3] 层的不透明度确实被应用。
    let expected = (OPACITY * 255.0) as i32;
    let err = (single_cpu as i32 - expected).abs();
    report("[3] cpu opacity accuracy", err as f64, 2.0, "/255", &mut failures);
    let err = (alpha_at(&gpu_data, 15, 20) as i32 - expected).abs();
    report("[4] gpu opacity accuracy", err as f64, 2.0, "/255", &mut failures);

    // [5] Content outside the layer keeps full alpha.
    // [5] 层外内容保持完全不透明。
    report(
        "[5] cpu outside untouched",
        (255 - outside_cpu) as f64,
        1.0,
        "/255",
        &mut failures,
    );
    report(
        "[6] gpu outside untouched",
        (255 - alpha_at(&gpu_data, 75, 20)) as f64,
        1.0,
        "/255",
        &mut failures,
    );

    // [7] Backends agree pixel for pixel.
    // [7] 两个后端逐像素一致。
    if std::env::var("DIFF").is_ok() {
        let mut shown = 0;
        for y in 0..H {
            for x in 0..W {
                let i = ((y * W + x) * 4) as usize;
                let (c, g) = (&cpu_straight[i..i + 4], &gpu_data[i..i + 4]);
                if (0..4).any(|ch| (c[ch] as i32 - g[ch] as i32).abs() > 2)
                    && shown < 12 {
                        println!("  diff at ({x},{y}) cpu={c:?} gpu={g:?}");
                        shown += 1;
                    }
            }
        }
    }
    let differing = cpu_straight
        .as_chunks::<4>().0.iter()
        .zip(gpu_data.chunks_exact(4))
        .filter(|(c, g)| {
            (0..4).any(|ch| (c[ch] as i32 - g[ch] as i32).abs() > 2)
        })
        .count();
    report(
        "[7] cpu/gpu differing pixels",
        differing as f64 / (W * H) as f64 * 100.0,
        0.2,
        "%",
        &mut failures,
    );

    // [8] A layer must not keep content from an earlier frame: draw the same square at
    // two different x positions and check the vacated area came back empty.
    // [8] 层不得保留上一帧内容：把同一方块画在两个不同的 x，检查腾出的位置已清空。
    let mut first = scene();
    first.ops.clear();
    first.prims.rects.clear();
    first.owners.rects.clear();
    first.layers.clear();
    first.push_layer(Rect::new(0.0, 0.0, W as f32, H as f32), Vec::new(), Corners::ZERO);
    first.push_rect(NodeId::from_raw(9, 0), square(9, 10.0, 10.0));
    first.pop_layer();

    gpu.clear(ctx.gl(), &target, [0.0, 0.0, 0.0, 0.0]);
    gpu.render(ctx.gl(), &target, &first).expect("render first");
    gpu.clear(ctx.gl(), &target, [0.0, 0.0, 0.0, 0.0]);
    let mut second = scene();
    second.ops.clear();
    second.prims.rects.clear();
    second.owners.rects.clear();
    second.layers.clear();
    second.push_layer(Rect::new(0.0, 0.0, W as f32, H as f32), Vec::new(), Corners::ZERO);
    second.push_rect(NodeId::from_raw(9, 0), square(9, 60.0, 10.0));
    second.pop_layer();
    gpu.render(ctx.gl(), &target, &second).expect("render second");
    let after = gpu.read_pixels(ctx.gl(), &target).expect("readback");
    report(
        "[8] stale layer content",
        alpha_at(&after, 15, 20) as f64,
        0.0,
        "",
        &mut failures,
    );

    if std::env::var("DUMP_LAYER").is_ok() {
        for (name, data) in [("cpu", &cpu_data), ("gpu", &gpu_data)] {
            use std::io::Write;
            let mut f = std::fs::File::create(format!("/tmp/layer_{name}.ppm")).expect("ppm");
            write!(f, "P6\n{W} {H}\n255\n").expect("hdr");
            for p in data.as_chunks::<4>().0 {
                let _ = f.write_all(&[p[3], p[3], p[3]]);
            }
        }
        println!("dumped /tmp/layer_{{cpu,gpu}}.ppm (alpha as grey)");
    }

    gpu.release(ctx.gl());
    target.release(ctx.gl());

    if failures > 0 {
        eprintln!("\n{failures} invariant(s) violated");
        std::process::exit(1);
    }
    println!("\nlayer invariants hold on both backends");
}

/// Premultiplied BGRA to straight RGBA, matching what `read_pixels` returns.
/// 预乘 BGRA 转非预乘 RGBA，与 `read_pixels` 的输出对齐。
fn unpremultiply_bgra(data: &[u8]) -> Vec<u8> {
    let mut out = Vec::with_capacity(data.len());
    for p in data.as_chunks::<4>().0 {
        let a = p[3] as u32;
        let un = |c: u8| {
            if a == 0 {
                0
            } else {
                ((c as u32 * 255 + a / 2) / a).min(255) as u8
            }
        };
        out.extend_from_slice(&[un(p[2]), un(p[1]), un(p[0]), p[3]]);
    }
    out
}
