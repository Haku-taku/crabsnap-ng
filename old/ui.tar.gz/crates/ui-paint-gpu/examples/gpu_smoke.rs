//! Smoke test: EGL context, dma-buf backed target, clear, read back.
//! 冒烟测试：EGL 上下文、dma-buf 支撑的目标、清屏、读回。
//!
//! Run: `cargo run -p ui-paint-gpu --example gpu_smoke`

use ui_paint_gpu::{EglContext, GpuRenderer, GpuTarget};

fn try_node(node: &std::ffi::CStr) {
    println!("\n=== {node:?} ===");
    let ctx = match EglContext::new(node) {
        Ok(c) => c,
        Err(e) => {
            println!("  context failed: {e}");
            return;
        }
    };
    println!("  renderer: {}", ctx.renderer());
    println!("  version:  {}", ctx.version());

    let target = match GpuTarget::new(&ctx, 64, 40) {
        Ok(t) => t,
        Err(e) => {
            println!("  target failed: {e}");
            return;
        }
    };
    let d = target.desc();
    println!(
        "  target: fd={} stride={} offset={} format={:#x} modifier={:#x}",
        d.fd, d.stride, d.offset, d.format, d.modifier
    );

    let mut renderer = match GpuRenderer::new(ctx.gl(), ctx.is_gles()) {
        Ok(r) => r,
        Err(e) => {
            println!("  renderer failed: {e}");
            return;
        }
    };

    renderer.clear(ctx.gl(), &target, [0.0, 1.0, 0.0, 1.0]);
    match renderer.read_pixels(ctx.gl(), &target) {
        Ok(px) => {
            let mid = (40 / 2 * 64 + 32) * 4;
            println!(
                "  readback centre RGBA: [{}, {}, {}, {}] (expect ~[0,255,0,255])",
                px[mid], px[mid + 1], px[mid + 2], px[mid + 3]
            );
            let ok = px[mid + 1] > 200 && px[mid] < 50;
            println!("  {}", if ok { ">>> OK" } else { ">>> MISMATCH" });
        }
        Err(e) => println!("  readback failed: {e}"),
    }

    renderer.release(ctx.gl());
    target.release(&ctx);
}

fn main() {
    for node in [c"/dev/dri/renderD128", c"/dev/dri/renderD129"] {
        try_node(node);
    }
}
