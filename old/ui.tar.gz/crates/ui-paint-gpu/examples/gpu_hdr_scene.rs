//! Check the PQ output transform against the CPU formula by reading the buffer back.
//! 用读回缓冲的方式，核对 PQ 输出变换与 CPU 公式是否一致。
//!
//! The screen cannot judge this (a compositor may tone-map HDR content), so the check
//! compares our own buffer against `encode_for_pq_output` for known sRGB inputs.
//! 屏幕无法判定这件事（compositor 可能对 HDR 内容做色调映射），因此改为把已知 sRGB
//! 输入经输出趟写入缓冲后读回，与 `encode_for_pq_output` 对比。
//!
//! Run: `cargo run -p ui-paint-gpu --example gpu_hdr_scene`

use ui_core::colour::{encode_for_pq_output, TransferFunction};
use ui_core::draw::{DrawList, RectPrim};
use ui_core::geom::{Color, Rect};
use ui_core::NodeId;
use ui_paint_gpu::{EglContext, GpuRenderer, OffscreenFbo};

const WIDTH: u32 = 64;
const HEIGHT: u32 = 64;
const REFERENCE_NITS: f32 = 203.0;
const MIN_NITS: f32 = 0.0;

/// sRGB codes to test: black, dark, mid, bright, white.
/// 待测的 sRGB 编码：黑、暗、中、亮、白。
const CODES: [u8; 5] = [0, 32, 128, 192, 255];

fn scene(code: u8) -> DrawList {
    let v = code as f32 / 255.0;
    let mut list = DrawList::new(Rect::new(0.0, 0.0, WIDTH as f32, HEIGHT as f32));
    list.push_rect(
        NodeId::from_raw(1, 0),
        RectPrim {
            rect: Rect::new(0.0, 0.0, WIDTH as f32, HEIGHT as f32),
            radius: ui_core::geom::Corners::all(0.0),
            fill: Color::rgba(v, v, v, 1.0),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    list
}

fn main() {
    let node = std::env::args()
        .nth(1)
        .or_else(ui_paint_gpu::output_render_node)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node.clone()).expect("node path");
    let ctx = EglContext::new(cnode.as_c_str()).expect("EGL context");
    println!("GPU: {} ({node})", ctx.renderer());
    println!("reference {REFERENCE_NITS} nits, min {MIN_NITS} nits");

    let target = OffscreenFbo::new(ctx.gl(), WIDTH, HEIGHT).expect("target");
    let mut gpu = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    gpu.set_hdr(Some((REFERENCE_NITS, MIN_NITS)));

    let mut failures = 0;
    println!("  sRGB  expected  actual  delta");
    for code in CODES {
        let list = scene(code);
        gpu.render(ctx.gl(), &target, &list).expect("render");
        let data = gpu.read_pixels(ctx.gl(), &target).expect("readback");

        // Centre pixel, straight RGBA after readback.
        // 中心像素，读回后是直通 RGBA。
        let i = ((HEIGHT / 2) * WIDTH + WIDTH / 2) as usize * 4;
        let actual = data[i] as f32 / 255.0;

        let linear = TransferFunction::Srgb.decode(code as f32 / 255.0);
        let expected = encode_for_pq_output(linear, REFERENCE_NITS, MIN_NITS);

        // One 8-bit step plus a little slack for the shader's own rounding.
        // 允许一个 8-bit 步长，另加着色器自身的舍入余量。
        let delta = (actual - expected).abs();
        let ok = delta <= 2.5 / 255.0;
        if !ok {
            failures += 1;
        }
        println!(
            "  {code:5}  {expected:8.4}  {actual:6.4}  {:+.4}  {}",
            actual - expected,
            if ok { "ok" } else { "FAIL" }
        );
    }

    // A transform that did nothing would pass every "same as input" check, so pin the
    // opposite: white must move well away from 1.0 under PQ.
    // 什么都不做的变换会通过所有「与输入相同」的检查，因此反向钉住：
    // 白色在 PQ 下必须明显偏离 1.0。
    let white = TransferFunction::Srgb.decode(1.0);
    let white_code = encode_for_pq_output(white, REFERENCE_NITS, MIN_NITS);
    let moved = white_code < 0.9;
    if !moved {
        failures += 1;
    }
    println!(
        "[2] white encodes away from 1.0: {white_code:.4} {}",
        if moved { "ok" } else { "FAIL" }
    );

    println!("\nFAIL={failures}");
    if failures > 0 {
        std::process::exit(1);
    }
}
