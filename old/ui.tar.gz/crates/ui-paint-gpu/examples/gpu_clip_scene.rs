//! Compares CPU and GPU rendering of clipped content.
//! 比较 CPU 与 GPU 对裁剪内容的渲染。
//!
//! Clips are placed at several heights on purpose: GL's scissor origin is the framebuffer
//! bottom while this renderer's projection is top-down, so a Y flip here is invisible
//! until something is actually clipped — and then it clips the wrong band.
//! 裁剪框刻意放在多个高度：GL 的 scissor 原点在帧缓冲底部，而本渲染器的投影是自上而下，
//! 因此这里的 Y 翻转在真有裁剪之前完全不可见——一旦有，就会裁到错误的位置。
//!
//! Run: `cargo run -p ui-paint-gpu --example gpu_clip_scene`

use ui_core::draw::{DrawList, RectPrim};
use ui_core::geom::{Color, Corners, Rect};
use ui_core::NodeId;
use ui_paint::{CpuRenderer, Pixels};
use ui_paint_gpu::{EglContext, GpuRenderer, OffscreenFbo};

const W: u32 = 240;
const H: u32 = 320;

/// Parent rects, each with a child that spills well past it.
/// 每个父矩形里都有一个远超其边界的子节点。
const PARENTS: [(f32, f32); 4] = [(10.0, 8.0), (10.0, 88.0), (10.0, 168.0), (10.0, 248.0)];
const PARENT: f32 = 60.0;

/// A rounded clip placed to the right of the plain ones.
/// 放在普通裁剪右侧的一个圆角裁剪。
const ROUNDED: (f32, f32, f32) = (150.0, 8.0, 72.0);

/// A narrow clip whose far edge lands mid-pixel, so its last row is only partly covered.
/// 远边落在像素中间的一条窄裁剪，其最后一行只被部分覆盖。
const FRACTIONAL: (f32, f32, f32) = (150.0, 96.4, 20.0);

fn scene() -> DrawList {
    let mut list = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    list.push_rect(
        NodeId::from_raw(1, 0),
        RectPrim {
            rect: Rect::new(0.0, 0.0, W as f32, H as f32),
            radius: Corners::ZERO,
            fill: Color::from_rgba8(18, 20, 26, 255),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    // A rounded clip: the corner must follow the curve, not the bounding box.
    // 圆角裁剪：角部必须跟随曲线，而不是包围盒。
    list.push_clip(
        Rect::new(ROUNDED.0, ROUNDED.1, ROUNDED.2, ROUNDED.2),
        Corners::all(ROUNDED.2 * 0.5).squircle(),
    );
    list.push_rect(
        NodeId::from_raw(2, 0),
        RectPrim {
            rect: Rect::new(ROUNDED.0, ROUNDED.1, ROUNDED.2, ROUNDED.2),
            radius: Corners::ZERO,
            fill: Color::from_rgba8(90, 200, 255, 255),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    list.pop_clip();

    // Content reaches its own far edge, so the last row the clip covers is the one a scissor
    // rounded from the *size* would drop.
    // 内容铺到自己的远边，因此裁剪覆盖的最后一行正是「按尺寸取整」的裁剪框会丢掉的那行。
    let (fx, fy, fs) = FRACTIONAL;
    list.push_clip(Rect::new(fx, fy, fs, fs), Corners::ZERO);
    list.push_rect(
        NodeId::from_raw(30, 0),
        RectPrim {
            rect: Rect::new(fx, fy, fs * 2.0, fs * 2.0),
            radius: Corners::ZERO,
            // Not the orange: check [1] counts orange pixels outside the parent bands.
            // 不用橙色：检查 [1] 统计的是父带之外的橙色像素。
            fill: Color::from_rgba8(90, 200, 255, 255),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    list.pop_clip();

    for (i, (x, y)) in PARENTS.into_iter().enumerate() {
        let clip = Rect::new(x, y, PARENT, PARENT);
        list.push_clip(clip, Corners::ZERO);
        list.push_rect(
            NodeId::from_raw(10 + i as u32, 0),
            RectPrim {
                rect: Rect::new(x, y, PARENT * 2.0, PARENT * 2.0),
                radius: Corners::ZERO,
                fill: Color::from_rgba8(255, 90, 40, 255),
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
        list.pop_clip();
    }
    list
}

/// Normalise both backends to straight RGBA so the comparison is about clipping.
/// 把两个后端统一成直通 RGBA，使比较只反映裁剪差异。
///
/// `Pixels` is premultiplied BGRA; `read_pixels` returns straight RGBA.
/// `Pixels` 是预乘 BGRA；`read_pixels` 返回直通 RGBA。
fn straight_rgba(data: &[u8], premultiplied_bgra: bool) -> Vec<[u8; 4]> {
    data.as_chunks::<4>().0.iter()
        .map(|p| {
            if premultiplied_bgra {
                let a = p[3] as u32;
                if a == 0 {
                    [0, 0, 0, 0]
                } else {
                    [
                        ((p[2] as u32 * 255) / a).min(255) as u8,
                        ((p[1] as u32 * 255) / a).min(255) as u8,
                        ((p[0] as u32 * 255) / a).min(255) as u8,
                        p[3],
                    ]
                }
            } else {
                [p[0], p[1], p[2], p[3]]
            }
        })
        .collect()
}

fn report(name: &str, value: f64, limit: f64, unit: &str, failures: &mut u32) {
    let ok = value <= limit;
    println!(
        "{name:30} {value:9.4}{unit}  (limit {limit}{unit})  {}",
        if ok { "OK" } else { "FAIL" }
    );
    if !ok {
        *failures += 1;
    }
}

fn main() {
    let list = scene();

    let mut cpu = CpuRenderer::new();
    let mut pixels = Pixels::new(W, H);
    cpu.render(&list, &mut pixels, &ui_core::damage::Damage::Full);
    let cpu_data = pixels.data.clone();
    let cpu_rgba = straight_rgba(&cpu_data, true);

    let node = std::env::args()
        .nth(1)
        .or_else(ui_paint_gpu::output_render_node)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node.clone()).expect("node path");
    let ctx = EglContext::new(cnode.as_c_str()).expect("EGL context");
    println!("GPU: {} ({node})", ctx.renderer());

    let target = OffscreenFbo::new(ctx.gl(), W, H).expect("target");
    let mut gpu = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    gpu.clear(ctx.gl(), &target, [0.0, 0.0, 0.0, 0.0]);
    gpu.render(ctx.gl(), &target, &list).expect("render");
    let gpu_data = gpu.read_pixels(ctx.gl(), &target).expect("readback");
    let gpu_rgba = straight_rgba(&gpu_data, false);

    let mut failures = 0;

    // [1] Every parent band is clipped to its own box: no orange outside any parent.
    // [1] 每条父带都被裁到自己的盒子内：任何父盒之外都没有橙色。
    let outside = (0..H)
        .flat_map(|y| (0..W).map(move |x| (x, y)))
        .filter(|(x, y)| {
            let inside = PARENTS.iter().any(|(px, py)| {
                *x as f32 >= *px
                    && (*x as f32) < px + PARENT
                    && *y as f32 >= *py
                    && (*y as f32) < py + PARENT
            });
            // Orange is (255, 90, 40); the background is (18, 20, 26).
            // 橙色是 (255, 90, 40)，背景是 (18, 20, 26)。
            !inside && gpu_rgba[(y * W + x) as usize][0] > 128
        })
        .count();
    report(
        "[1] gpu content outside clips",
        outside as f64,
        0.0,
        "",
        &mut failures,
    );

    // [2] The clip lands on the same band on both backends.
    // [2] 裁剪在两个后端落在同一条带上。
    let differing = cpu_rgba
        .iter()
        .zip(gpu_rgba.iter())
        .filter(|(c, g)| (0..4).any(|ch| (c[ch] as i32 - g[ch] as i32).abs() > 2))
        .count();
    report(
        "[2] cpu/gpu differing pixels",
        differing as f64 / (W * H) as f64 * 100.0,
        0.2,
        "%",
        &mut failures,
    );

    // [3] Each band is filled, which proves the clip did not wipe the content entirely.
    // [3] 每条带都被填满，证明裁剪没有把内容整个擦掉。
    let filled = PARENTS
        .iter()
        .map(|(x, y)| {
            let cx = (*x + PARENT / 2.0) as u32;
            let cy = (*y + PARENT / 2.0) as u32;
            gpu_rgba[(cy * W + cx) as usize][0]
        })
        .collect::<Vec<_>>();
    println!("  band centre red: {filled:?}");
    let all_filled = filled.iter().all(|v| *v > 200);
    report(
        "[3] every band has content",
        if all_filled { 0.0 } else { 1.0 },
        0.0,
        "",
        &mut failures,
    );

    // [4] The rounded clip cuts its corners: the bounding-box corner stays background.
    // [4] 圆角裁剪切掉了角：包围盒的角仍是背景色。
    let (rx, ry, rs) = ROUNDED;
    let corner = gpu_rgba[((ry as u32 + 1) * W + rx as u32 + 1) as usize];
    let centre = gpu_rgba[(((ry + rs / 2.0) as u32) * W + (rx + rs / 2.0) as u32) as usize];
    println!("  rounded corner {corner:?} centre {centre:?}");
    report(
        "[4] rounded corner is cut",
        if corner[2] > 128 { 1.0 } else { 0.0 },
        0.0,
        "",
        &mut failures,
    );
    report(
        "[5] rounded centre is painted",
        if centre[2] > 200 { 0.0 } else { 1.0 },
        0.0,
        "",
        &mut failures,
    );

    // [6] The row the clip's far edge only partly covers is still painted. A scissor rounded
    // from the clip's size (`ceil(20)` from `floor(96.4)`) stops one row short of 116.4 and
    // drops it, which is how a 1dp divider under a fractional box vanishes on the GPU only.
    // [6] 裁剪远边只部分覆盖的那一行仍被画出。按尺寸取整的裁剪框（`floor(96.4)` 起
    // `ceil(20)`）止于 116.4 之前，把这行丢掉——分数盒下方的 1dp 分隔线就是这样只在 GPU 上消失。
    let last = (FRACTIONAL.1 + FRACTIONAL.2).ceil() as u32 - 1;
    let px = FRACTIONAL.0 as u32 + 1;
    let cpu_row = cpu_rgba[(last * W + px) as usize];
    let gpu_row = gpu_rgba[(last * W + px) as usize];
    println!("  row {last} of the fractional clip: cpu {cpu_row:?} gpu {gpu_row:?}");
    report(
        "[6] last row of a fractional clip",
        if cpu_row[2] > 100 && gpu_row[2] > 100 { 0.0 } else { 1.0 },
        0.0,
        "",
        &mut failures,
    );

    if std::env::var("DUMP_CLIP").is_ok() {
        for (name, data) in [("cpu", &cpu_data), ("gpu", &gpu_data)] {
            use std::io::Write;
            let mut f = std::fs::File::create(format!("/tmp/clip_{name}.ppm")).expect("ppm");
            write!(f, "P6\n{W} {H}\n255\n").expect("hdr");
            //  returns straight RGBA already; write it in that order.
            //  已返回直通 RGBA，按该顺序写出。
            for p in data.as_chunks::<4>().0 {
                let _ = f.write_all(&p[0..3]);
            }
        }
        println!("dumped /tmp/clip_{{cpu,gpu}}.ppm");
    }

    gpu.release(ctx.gl());
    target.release(ctx.gl());

    if failures > 0 {
        eprintln!("\n{failures} invariant(s) violated");
        std::process::exit(1);
    }
    println!("\nclipping agrees on both backends");
}
