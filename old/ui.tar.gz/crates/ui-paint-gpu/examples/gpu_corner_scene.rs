//! Compares CPU and GPU rendering of every corner curve family.
//! 比较 CPU 与 GPU 对每种圆角曲线族的渲染。
//!
//! Two claims are checked: both backends agree pixel for pixel, and the shapes are
//! genuinely different from each other (a backend ignoring the exponent would make
//! them identical while still agreeing with itself).
//! 验证两点：两后端逐像素一致；且各形状确实互不相同
//! （忽略指数的后端会自洽但形状全同）。
//!
//! Run: `cargo run -p ui-paint-gpu --example gpu_corner_scene`

use ui_core::damage::Damage;
use ui_core::draw::{DrawList, RectPrim};
use ui_core::geom::{Color, CornerShape, Corners, Rect};
use ui_core::NodeId;
use ui_paint::{CpuRenderer, Pixels};
use ui_paint_gpu::{EglContext, GpuRenderer, OffscreenFbo};

const CELL: u32 = 48;
const RADIUS: f32 = 20.0;
const GAP: f32 = 4.0;

fn shapes() -> Vec<(&'static str, CornerShape)> {
    vec![
        ("bevel", CornerShape::BEVEL),
        ("round", CornerShape::ROUND),
        ("squircle", CornerShape::SQUIRCLE),
        ("k=3", CornerShape::from_k(3.0)),
        ("square", CornerShape::SQUARE),
    ]
}

/// Cells whose four radii differ, so a backend that picks the wrong corner per quadrant
/// shows up as a diagonal instead of a corner.
/// 四角半径互不相同的格子：按象限取错角的后端会画成对角而不是圆角。
fn asymmetric() -> Vec<(&'static str, [f32; 4])> {
    vec![
        ("tl+br round", [RADIUS, 0.0, RADIUS, 0.0]),
        ("tr+bl round", [0.0, RADIUS, 0.0, RADIUS]),
        ("left round", [RADIUS, 0.0, 0.0, RADIUS]),
    ]
}

fn width() -> u32 {
    shapes().len() as u32 * CELL
}

const HEIGHT: u32 = CELL * 2;

fn scene() -> DrawList {
    let mut list = DrawList::new(Rect::new(0.0, 0.0, width() as f32, HEIGHT as f32));
    for (i, (_, shape)) in shapes().into_iter().enumerate() {
        let x = i as f32 * CELL as f32;
        list.push_rect(
            NodeId::from_raw(i as u32 + 1, 0),
            RectPrim {
                rect: Rect::new(
                    x + GAP,
                    GAP,
                    CELL as f32 - GAP * 2.0,
                    CELL as f32 - GAP * 2.0,
                ),
                radius: Corners::all(RADIUS).with_shape(shape),
                fill: Color::WHITE,
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
    }
    for (i, (_, [tl, tr, br, bl])) in asymmetric().into_iter().enumerate() {
        let x = i as f32 * CELL as f32;
        list.push_rect(
            NodeId::from_raw(100 + i as u32, 0),
            RectPrim {
                rect: Rect::new(
                    x + GAP,
                    CELL as f32 + GAP,
                    CELL as f32 - GAP * 2.0,
                    CELL as f32 - GAP * 2.0,
                ),
                radius: Corners { tl, tr, br, bl, shape: CornerShape::ROUND },
                fill: Color::WHITE,
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
    }
    list
}

fn alpha_at(data: &[u8], x: u32, y: u32) -> u8 {
    data[((y * width() + x) * 4 + 3) as usize]
}

/// Total alpha inside one cell, a proxy for how much of the corner is filled.
/// 单格内的 alpha 总和，作为圆角填充量的代理。
fn cell_mass(data: &[u8], index: usize, y0: u32) -> u64 {
    let x0 = index as u32 * CELL;
    (y0..y0 + CELL)
        .map(|y| {
            (x0..x0 + CELL)
                .map(|x| alpha_at(data, x, y) as u64)
                .sum::<u64>()
        })
        .sum()
}

fn report(name: &str, value: f64, limit: f64, unit: &str, failures: &mut u32) {
    let ok = value <= limit;
    println!(
        "{name:30} {value:9.4}{unit}  (limit {limit}{unit})  {}",
        if ok { "OK" } else { "FAIL" }
    );
    if !ok {
        *failures += 1;
    }
}

fn main() {
    let list = scene();

    let mut cpu = CpuRenderer::new();
    let mut pixels = Pixels::new(width(), HEIGHT);
    cpu.render(&list, &mut pixels, &Damage::Full);
    let cpu_data = pixels.data.clone();

    let node = std::env::args()
        .nth(1)
        .or_else(ui_paint_gpu::output_render_node)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node.clone()).expect("node path");
    let ctx = EglContext::new(cnode.as_c_str()).expect("EGL context");
    println!("GPU: {} ({node})", ctx.renderer());

    let target = OffscreenFbo::new(ctx.gl(), width(), HEIGHT).expect("target");
    let mut gpu = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    gpu.clear(ctx.gl(), &target, [0.0, 0.0, 0.0, 0.0]);
    gpu.render(ctx.gl(), &target, &list).expect("render");
    let gpu_data = gpu.read_pixels(ctx.gl(), &target).expect("readback");

    let mut failures = 0;

    // [1] Each shape fills a different amount of its cell, on both backends.
    // [1] 每种形状填充量不同，两个后端都是。
    let cpu_mass: Vec<u64> = (0..shapes().len()).map(|i| cell_mass(&cpu_data, i, 0)).collect();
    let gpu_mass: Vec<u64> = (0..shapes().len()).map(|i| cell_mass(&gpu_data, i, 0)).collect();
    println!("  cpu mass: {cpu_mass:?}");
    println!("  gpu mass: {gpu_mass:?}");
    let cpu_monotonic = cpu_mass.windows(2).all(|w| w[0] < w[1]);
    let gpu_monotonic = gpu_mass.windows(2).all(|w| w[0] < w[1]);
    report(
        "[1] cpu shapes differ",
        if cpu_monotonic { 0.0 } else { 1.0 },
        0.0,
        "",
        &mut failures,
    );
    report(
        "[2] gpu shapes differ",
        if gpu_monotonic { 0.0 } else { 1.0 },
        0.0,
        "",
        &mut failures,
    );

    // [3] Both backends land on the same mass per shape.
    // [3] 两后端每种形状的总量相同。
    let worst = cpu_mass
        .iter()
        .zip(&gpu_mass)
        .map(|(c, g)| (*c as f64 - *g as f64).abs() / (*c).max(1) as f64)
        .fold(0.0f64, f64::max);
    report("[3] per-shape mass", worst * 100.0, 0.5, "%", &mut failures);

    // [4] Pixel agreement across the whole strip.
    // [4] 整条上的逐像素一致性。
    let differing = cpu_data
        .as_chunks::<4>().0.iter()
        .zip(gpu_data.chunks_exact(4))
        .filter(|(c, g)| (0..4).any(|ch| (c[ch] as i32 - g[ch] as i32).abs() > 2))
        .count();
    report(
        "[4] cpu/gpu differing pixels",
        differing as f64 / (width() * HEIGHT) as f64 * 100.0,
        0.2,
        "%",
        &mut failures,
    );

    // [5] Each asymmetric cell cuts exactly the corners it asked for. The SDF picks one
    // radius per quadrant; a packing mismatch swaps tl with br and paints a diagonal.
    // [5] 每个不对称格子只切它要求的角。SDF 每象限取一个半径；打包顺序不符会把
    // tl 与 br 对调，画成对角。
    let mut misplaced = 0.0;
    for (i, (name, [tl, tr, br, bl])) in asymmetric().into_iter().enumerate() {
        let x0 = i as u32 * CELL;
        let y0 = CELL;
        // One pixel in from each cell corner, at the depth a radius-20 corner has already
        // cut away; `0.0` means the corner is square and the pixel is inside.
        let probe = |dx: u32, dy: u32| (x0 + GAP as u32 + dx, y0 + GAP as u32 + dy);
        let corners = [
            ("tl", tl, probe(2, 2)),
            ("tr", tr, probe(CELL - GAP as u32 * 2 - 3, 2)),
            ("br", br, probe(CELL - GAP as u32 * 2 - 3, CELL - GAP as u32 * 2 - 3)),
            ("bl", bl, probe(2, CELL - GAP as u32 * 2 - 3)),
        ];
        for (label, radius, (px, py)) in corners {
            let want_clear = radius > 0.0;
            for (backend, data) in [("cpu", &cpu_data), ("gpu", &gpu_data)] {
                let a = alpha_at(data, px, py);
                if (a < 128) != want_clear {
                    println!(
                        "  {name} {label} ({backend}): alpha {a} at ({px},{py}), radius {radius}"
                    );
                    misplaced += 1.0;
                }
            }
        }
    }
    report("[5] asymmetric corners misplaced", misplaced, 0.0, "", &mut failures);

    if std::env::var("DUMP_CORNERS").is_ok() {
        for (name, data) in [("cpu", &cpu_data), ("gpu", &gpu_data)] {
            use std::io::Write;
            let mut f = std::fs::File::create(format!("/tmp/corners_{name}.ppm")).expect("ppm");
            write!(f, "P6\n{} {}\n255\n", width(), HEIGHT).expect("hdr");
            for p in data.as_chunks::<4>().0 {
                let _ = f.write_all(&[p[3], p[3], p[3]]);
            }
        }
        println!("dumped /tmp/corners_{{cpu,gpu}}.ppm (alpha as grey)");
    }

    gpu.release(ctx.gl());
    target.release(ctx.gl());

    if failures > 0 {
        eprintln!("\n{failures} invariant(s) violated");
        std::process::exit(1);
    }
    println!("\ncorner shapes agree on both backends");
}
