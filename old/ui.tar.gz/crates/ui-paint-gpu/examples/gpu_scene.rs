//! Check the four dual-backend invariants by rendering one scene twice.
//! 通过两次渲染同一场景，检查双后端四条不变量。
//!
//! Run: `cargo run -p ui-paint-gpu --example gpu_scene [render-node]`
//! Exits non-zero if an invariant is violated.

use std::io::Write;

use ui_core::damage::Damage;
use ui_core::draw::{DrawList, GlyphPrim, RectPrim};
use ui_core::geom::{Color, Corners, Rect};
use ui_core::NodeId;
use ui_paint::{CoverageAtlas, CpuRenderer, Pixels};
use ui_paint_gpu::{AtlasUpload, EglContext, GpuRenderer, OffscreenFbo};

const W: u32 = 240;
const H: u32 = 160;
const ATLAS: u32 = 64;
const TILE: u32 = 16;

/// Build a synthetic coverage atlas with three distinguishable tiles.
/// 造一个带三个可区分图块的合成覆盖率图集。
fn atlas() -> Vec<u8> {
    let mut data = vec![0u8; (ATLAS * ATLAS) as usize];
    for ty in 0..3u32 {
        for y in 0..TILE {
            for x in 0..TILE {
                let inside = match ty {
                    // A filled disc.
                    // 实心圆。
                    0 => {
                        let dx = x as f32 - 7.5;
                        let dy = y as f32 - 7.5;
                        dx * dx + dy * dy <= 56.0
                    }
                    // A diagonal wedge: its edge is where the monotonicity probe looks.
                    // 对角楔形：单调性探针看它的斜边。
                    1 => (x as f32) < (y as f32) * 0.8 + 2.0,
                    // Vertical bars.
                    // 竖条。
                    _ => x % 4 < 2,
                };
                let v = if inside { 255u8 } else { 0 };
                let px = ty * TILE + x;
                let py = y;
                data[(py * ATLAS + px) as usize] = v;
            }
        }
    }
    data
}

fn scene() -> DrawList {
    let owner = NodeId::from_raw(0, 0);
    let mut list = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    list.push_rect(
        owner,
        RectPrim {
            rect: Rect::new(0.0, 0.0, W as f32, H as f32),
            radius: Corners::ZERO,
            fill: Color::from_rgba8(20, 22, 28, 255),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    // Opaque square: area conservation.
    // 不透明方块：面积守恒。
    list.push_rect(
        owner,
        RectPrim {
            rect: Rect::new(30.0, 20.0, 100.0, 100.0),
            radius: Corners::ZERO,
            fill: Color::from_rgba8(240, 240, 240, 255),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    // Rounded box with border: the SDF path. The border is deliberately not white: a white
    // ring saturates and hides a shader that scales the border colour by its width.
    // 带边框的圆角盒：SDF 路径。边框刻意不用白色：白环会饱和，掩盖按宽度缩放边框色的着色器。
    list.push_rect(
        owner,
        RectPrim {
            rect: Rect::new(150.0, 20.0, 70.0, 50.0),
            radius: Corners::all(12.0),
            fill: Color::from_rgba8(60, 130, 220, 255),
            border: Some((Color::from_rgba8(200, 120, 40, 255), 3.0)),
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    // Vertical gradient: the shader must sample per pixel, and must agree with the CPU
    // rasteriser sample for sample. A shader that ignored `a_grad` would draw `fill`.
    // 竖向渐变：着色器必须逐像素采样，且与 CPU 光栅器逐样本一致。
    // 忽略 `a_grad` 的着色器只会画出 `fill`。
    list.push_rect(
        owner,
        RectPrim {
            rect: Rect::new(140.0, 90.0, 80.0, 60.0),
            radius: Corners::all(10.0),
            fill: Color::from_rgba8(255, 255, 255, 255),
            border: None,
            border_gradient: None,
            gradient: Some(ui_core::draw::Gradient::new(
                Color::from_rgba8(255, 255, 255, 255),
                Color::from_rgba8(0, 0, 0, 255),
                ui_core::draw::GradientAxis::Vertical,
            )),
            notch: None,
        },
    );
    // Half-transparent overlays: overflow probe.
    // 半透明叠加：溢出探针。
    for i in 0..8 {
        list.push_rect(
            owner,
            RectPrim {
                rect: Rect::new(160.0 + i as f32 * 6.0, 80.0, 30.0, 20.0),
                radius: Corners::all(4.0),
                fill: Color::from_rgba8(255, 200, 40, 64),
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
    }
    // Staircase: edge-position probe.
    // 阶梯：边缘位置探针。
    for i in 0..20 {
        list.push_rect(
            owner,
            RectPrim {
                rect: Rect::new(30.0 + i as f32 * 5.0, 130.0, 5.0, 24.0 - i as f32),
                radius: Corners::ZERO,
                fill: Color::from_rgba8(200, 80, 90, 255),
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
    }
    // Glyphs from the synthetic atlas.
    // 来自合成图集的字形。
    for i in 0..3u32 {
        list.push_glyph(
            owner,
            GlyphPrim {
                rect: Rect::new(150.0 + i as f32 * 20.0, 110.0, 16.0, 16.0),
                atlas: Rect::new((i * TILE) as f32, 0.0, TILE as f32, TILE as f32),
                alpha: 1.0,
                color: Color::from_rgba8(120, 255, 160, 255),
                kind: ui_core::draw::GlyphKind::Coverage,
            },
        );
    }
    list
}

/// `Pixels` stores premultiplied BGRA; GL readback is straight RGBA.
/// `Pixels` 存的是预乘 BGRA；GL 读回是直通 RGBA。
fn to_rgb(data: &[u8], premultiplied_bgra: bool) -> Vec<[u8; 3]> {
    data.as_chunks::<4>().0.iter()
        .map(|p| {
            if premultiplied_bgra {
                let a = p[3] as u32;
                if a == 0 {
                    [0, 0, 0]
                } else if a == 255 {
                    [p[2], p[1], p[0]]
                } else {
                    let un = |c: u8| ((c as u32 * 255 + a / 2) / a).min(255) as u8;
                    [un(p[2]), un(p[1]), un(p[0])]
                }
            } else {
                [p[0], p[1], p[2]]
            }
        })
        .collect()
}

fn write_ppm(path: &str, rgb: &[[u8; 3]]) -> std::io::Result<()> {
    let mut f = std::fs::File::create(path)?;
    write!(f, "P6\n{W} {H}\n255\n")?;
    let mut raw = Vec::with_capacity(rgb.len() * 3);
    for p in rgb {
        raw.extend_from_slice(p);
    }
    f.write_all(&raw)
}

fn main() {
    let list = scene();
    let mut cpu = CpuRenderer::new();
    cpu.set_atlas(CoverageAtlas {
        width: ATLAS,
        height: ATLAS,
        data: atlas(),
    });
    let mut pixels = Pixels::new(W, H);
    cpu.render(&list, &mut pixels, &Damage::Full);
    let cpu_rgb = to_rgb(pixels.as_bytes(), true);
    write_ppm("gpu_scene_cpu.ppm", &cpu_rgb).expect("write cpu ppm");

    let node = std::env::args()
        .nth(1)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node.clone()).expect("node path");
    let ctx = EglContext::new(cnode.as_c_str()).expect("EGL context");
    println!("GPU: {} ({node})", ctx.renderer());

    let target = OffscreenFbo::new(ctx.gl(), W, H).expect("target");
    let mut gpu = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    gpu.set_atlas(
        ctx.gl(),
        AtlasUpload {
            width: ATLAS,
            height: ATLAS,
            data: atlas(),
        },
    )
    .expect("atlas");
    gpu.clear(ctx.gl(), &target, [0.0, 0.0, 0.0, 1.0]);
    let stats = gpu.render(ctx.gl(), &target, &list).expect("render");
    let raw = gpu.read_pixels(ctx.gl(), &target).expect("readback");
    if std::env::var("GPU_RAW").is_ok() {
        // Un-premultiplied already; print a few overlay pixels to see the truth.
        // 已还原非预乘；打印几个叠加层像素看真实值。
        for x in [165usize, 175, 185, 195] {
            let i = 90 * W as usize + x;
            println!("  raw x={x} y=90 -> {:?}", &raw[i * 4..i * 4 + 4]);
        }
    }
    let gpu_rgb = to_rgb(&raw, false);
    write_ppm("gpu_scene_gpu.ppm", &gpu_rgb).expect("write gpu ppm");
    println!("stats: {stats:?}");

    let mut failures = 0;

    // [0] Gradient: the shader must sample per pixel and match the CPU rasteriser. A
    // shader ignoring `a_grad` draws the flat `fill` (255 everywhere) and fails both parts.
    // [0] 渐变：着色器必须逐像素采样并与 CPU 光栅器一致。忽略 `a_grad` 的着色器会画出
    // 平面 `fill`（处处 255），两部分都会失败。
    {
        let col = |rgb: &[[u8; 3]], y: usize| rgb[y * W as usize + 180][0] as i32;
        let ys = [95usize, 110, 125, 140];
        let ramp: Vec<i32> = ys.iter().map(|y| col(&gpu_rgb, *y)).collect();
        let monotone = ramp.windows(2).all(|w| w[1] < w[0]);
        report(
            "gradient ramps down the box",
            if monotone { 0.0 } else { 1.0 },
            0.0,
            "0 = monotone",
            &mut failures,
        );
        let worst = ys
            .iter()
            .map(|y| (col(&cpu_rgb, *y) - col(&gpu_rgb, *y)).abs())
            .max()
            .unwrap_or(0);
        report(
            "gradient matches the cpu rasteriser",
            worst as f64,
            3.0,
            "LSB",
            &mut failures,
        );
    }

    // [1] Area conservation: an opaque 100x100 square must cover the same area.
    // [1] 面积守恒：不透明 100x100 方块必须覆盖相同面积。
    let sq = |rgb: &[[u8; 3]]| -> f64 {
        let mut s = 0.0;
        for y in 20..120usize {
            for x in 30..130usize {
                s += rgb[y * W as usize + x][0] as f64 / 255.0;
            }
        }
        s
    };
    let (a_cpu, a_gpu) = (sq(&cpu_rgb), sq(&gpu_rgb));
    let rel = (a_gpu - a_cpu).abs() / a_cpu.max(1.0);
    report("[1] area conservation", rel * 100.0, 0.5, "%", &mut failures);

    // [2] No overflow: every channel stays within [0,255] with no wraparound.
    // [2] 无溢出：每个通道都在 [0,255] 内且无回绕。
    let overflow = gpu_rgb
        .iter()
        .zip(&cpu_rgb)
        .filter(|(g, c)| {
            // A wraparound shows up as the GPU being far darker where the CPU is bright.
            // 回绕表现为 GPU 在 CPU 很亮的地方远更暗。
            g[0] as i32 + 40 < c[0] as i32 && c[0] > 200
        })
        .count();
    let overflow_pct = overflow as f64 / (W * H) as f64 * 100.0;
    report("[2] overflow pixels", overflow_pct, 0.05, "%", &mut failures);

    // [3] Total ink: the whole frame's coverage sum.
    // [3] 总墨量：整帧的覆盖度之和。
    let ink = |rgb: &[[u8; 3]]| -> f64 {
        rgb.iter()
            .map(|p| {
                let d = |a: u8, b: u8| (a as f64 - b as f64).abs();
                (d(p[0], 20) + d(p[1], 22) + d(p[2], 28)) / 3.0
            })
            .sum()
    };
    let (i_cpu, i_gpu) = (ink(&cpu_rgb), ink(&gpu_rgb));
    let rel = (i_gpu - i_cpu).abs() / i_cpu.max(1.0);
    report("[3] total ink", rel * 100.0, 0.5, "%", &mut failures);

    // [4] Edge position: the staircase's left boundary must agree within 1 px.
    // [4] 边缘位置：阶梯的左边界误差必须在 1 像素内。
    let mut max_shift = 0i32;
    for y in 132..150usize {
        let edge = |rgb: &[[u8; 3]]| -> Option<usize> {
            (25..150).find(|&x| rgb[y * W as usize + x][0] > 120)
        };
        if let (Some(c), Some(g)) = (edge(&cpu_rgb), edge(&gpu_rgb)) {
            max_shift = max_shift.max((c as i32 - g as i32).abs());
        }
    }
    report("[4] edge shift", max_shift as f64, 1.0, "px", &mut failures);

    // [5] Border ring: ring and fill are one area-weighted mix, so a pixel fully inside the
    // 3px ring must be the border colour. A width folded into the alpha slot turns it into
    // `2 * border - fill`, which the CPU path never produces.
    // [5] 边框环：环与填充是一次面积加权混合，故完全落在 3px 环内的像素必须是边框色。
    // 宽度折进 alpha 槽会把它变成 `2 * border - fill`，CPU 路径不会产出这种颜色。
    {
        let probes = [(185usize, 21usize), (152, 45), (185, 68)];
        let worst = probes
            .iter()
            .map(|&(x, y)| {
                let i = y * W as usize + x;
                (0..3)
                    .map(|k| (cpu_rgb[i][k] as i32 - gpu_rgb[i][k] as i32).abs())
                    .max()
                    .unwrap_or(0)
            })
            .max()
            .unwrap_or(0);
        report("[5] border ring colour", worst as f64, 3.0, "LSB", &mut failures);
    }

    gpu.release(ctx.gl());
    target.release(ctx.gl());

    if failures > 0 {
        eprintln!("\n{failures} invariant(s) violated");
        std::process::exit(1);
    }
    println!("\nall invariants hold; wrote gpu_scene_cpu.ppm / gpu_scene_gpu.ppm");
}

fn report(name: &str, value: f64, limit: f64, unit: &str, failures: &mut u32) {
    let ok = value <= limit;
    println!(
        "{name:28} {value:8.4}{unit}  (limit {limit}{unit})  {}",
        if ok { "OK" } else { "FAIL" }
    );
    if !ok {
        *failures += 1;
    }
}
