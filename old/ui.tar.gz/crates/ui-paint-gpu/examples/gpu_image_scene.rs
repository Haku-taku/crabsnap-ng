//! Checks the GPU image primitive: source sub-rect sampling, rounded corners, texture cache.
//! 检查 GPU 图像图元：源子矩形采样、圆角、纹理缓存。
//!
//! The texture is a 2x2 grid of saturated colours, so a sampler that ignores `src`, flips y,
//! or tiles the source is visible as the wrong colour in a named region.
//! 纹理是 2x2 的饱和色块：忽略 `src`、翻转 y 或平铺源的采样器都会在指定区域显出错误颜色。
//!
//! Run: `cargo run -p ui-paint-gpu --example gpu_image_scene`

use std::sync::Arc;

use ui_core::draw::{DrawList, ImageEntry, ImagePrim, RectPrim};
use ui_core::geom::{Color, Corners, Rect};
use ui_core::NodeId;
use ui_paint_gpu::{EglContext, GpuRenderer, OffscreenFbo, RenderStats};

const W: u32 = 320;
const H: u32 = 240;
const BG: [u8; 3] = [20, 22, 28];

/// Side of the square test texture, and of one quadrant.
/// 方形测试纹理的边长，以及单个象限的边长。
const TEX: u32 = 64;
const QUAD: u32 = TEX / 2;

const RED: [u8; 3] = [255, 0, 0];
const GREEN: [u8; 3] = [0, 255, 0];
const BLUE: [u8; 3] = [0, 0, 255];
const YELLOW: [u8; 3] = [255, 255, 0];

const ID_A: u64 = 0xA1;
const ID_B: u64 = 0xB2;

fn texture() -> Vec<u8> {
    let mut data = Vec::with_capacity((TEX * TEX * 4) as usize);
    for y in 0..TEX {
        for x in 0..TEX {
            let top = y < QUAD;
            let left = x < QUAD;
            let c = match (top, left) {
                (true, true) => RED,
                (true, false) => GREEN,
                (false, true) => BLUE,
                (false, false) => YELLOW,
            };
            data.extend_from_slice(&[c[0], c[1], c[2], 255]);
        }
    }
    data
}

fn canvas() -> DrawList {
    let mut list = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    // The frame is blitted over the target, so the background has to be a primitive.
    // 帧是覆盖写到目标上的，因此背景必须是一个图元。
    list.push_rect(
        NodeId::from_raw(1, 0),
        RectPrim {
            rect: Rect::new(0.0, 0.0, W as f32, H as f32),
            radius: Corners::ZERO,
            fill: Color::from_rgba8(BG[0], BG[1], BG[2], 255),
            gradient: None,
            border: None,
            border_gradient: None,
            notch: None,
        },
    );
    list
}

fn add_image(
    list: &mut DrawList,
    id: u64,
    data: &Arc<Vec<u8>>,
    rect: Rect,
    src: Rect,
    corners: Corners,
) {
    let texture = list.push_image(ImageEntry {
        id,
        width: TEX,
        height: TEX,
        data: Arc::clone(data),
    });
    list.push_image_prim(
        NodeId::from_raw(2, 0),
        ImagePrim {
            rect,
            corners,
            texture,
            src,
        },
    );
}

fn draw(
    gpu: &mut GpuRenderer,
    ctx: &EglContext,
    target: &OffscreenFbo,
    list: &DrawList,
) -> (Vec<u8>, RenderStats) {
    gpu.clear(ctx.gl(), target, [0.0, 0.0, 0.0, 0.0]);
    let stats = gpu.render(ctx.gl(), target, list).expect("render");
    let pixels = gpu.read_pixels(ctx.gl(), target).expect("readback");
    (pixels, stats)
}

fn at(data: &[u8], x: u32, y: u32) -> [u8; 3] {
    let i = ((y * W + x) * 4) as usize;
    [data[i], data[i + 1], data[i + 2]]
}

/// Mean colour of an inclusive-exclusive rectangle.
/// 一个左闭右开矩形的平均颜色。
fn mean(data: &[u8], x0: u32, y0: u32, x1: u32, y1: u32) -> [f64; 3] {
    let mut sum = [0.0f64; 3];
    let mut n = 0.0f64;
    for y in y0..y1 {
        for x in x0..x1 {
            let p = at(data, x, y);
            for c in 0..3 {
                sum[c] += p[c] as f64;
            }
            n += 1.0;
        }
    }
    [sum[0] / n, sum[1] / n, sum[2] / n]
}

fn worst_channel(a: [f64; 3], b: [u8; 3]) -> f64 {
    (0..3)
        .map(|c| (a[c] - b[c] as f64).abs())
        .fold(0.0, f64::max)
}

/// Pixels in a region whose colour is further than `tol` from `want` on any channel.
/// 区域中任一通道与 `want` 相差超过 `tol` 的像素数。
fn foreign(data: &[u8], x0: u32, y0: u32, x1: u32, y1: u32, want: [u8; 3], tol: i32) -> u32 {
    let mut n = 0;
    for y in y0..y1 {
        for x in x0..x1 {
            let p = at(data, x, y);
            if (0..3).any(|c| (p[c] as i32 - want[c] as i32).abs() > tol) {
                n += 1;
            }
        }
    }
    n
}

fn report(name: &str, value: f64, limit: f64, unit: &str, failures: &mut u32) {
    let ok = value <= limit;
    println!(
        "{name:34} {value:9.4}{unit}  (limit {limit}{unit})  {}",
        if ok { "OK" } else { "FAIL" }
    );
    if !ok {
        *failures += 1;
    }
}

fn report_min(name: &str, value: f64, floor: f64, unit: &str, failures: &mut u32) {
    let ok = value >= floor;
    println!(
        "{name:34} {value:9.4}{unit}  (floor {floor}{unit})  {}",
        if ok { "OK" } else { "FAIL" }
    );
    if !ok {
        *failures += 1;
    }
}

fn report_eq(name: &str, got: i64, want: i64, failures: &mut u32) {
    let ok = got == want;
    println!(
        "{name:34} {got:9}       (want {want})   {}",
        if ok { "OK" } else { "FAIL" }
    );
    if !ok {
        *failures += 1;
    }
}
fn main() {
    let node = std::env::args()
        .nth(1)
        .or_else(ui_paint_gpu::output_render_node)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node.clone()).expect("node path");
    let ctx = EglContext::new(cnode.as_c_str()).expect("EGL context");
    println!("GPU: {} ({node})", ctx.renderer());

    let target = OffscreenFbo::new(ctx.gl(), W, H).expect("target");
    let mut gpu = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    let data = Arc::new(texture());
    let mut failures = 0;

    // [1][2] The whole texture lands in the rect, upright: four quadrant centres keep their colour.
    // [1][2] 整张纹理落进矩形且方向正确：四个象限中心保持各自颜色。
    let mut full = canvas();
    let full_rect = Rect::new(16.0, 16.0, 140.0, 140.0);
    add_image(
        &mut full,
        ID_A,
        &data,
        full_rect,
        Rect::new(0.0, 0.0, TEX as f32, TEX as f32),
        Corners::ZERO,
    );
    let (pixels, stats_full) = draw(&mut gpu, &ctx, &target, &full);
    println!("stats: {stats_full:?}");

    let interior = mean(&pixels, 24, 24, 148, 148);
    report_min(
        "[1] rect interior vs background",
        worst_channel(interior, BG),
        40.0,
        "",
        &mut failures,
    );

    // Quadrant centres are half of a destination quadrant, not half of a texture quadrant.
    // 象限中心取目标象限的一半，而不是纹理象限的一半。
    let half = full_rect.size.w / 2.0;
    let mut worst = 0.0f64;
    for (dx, dy, want) in [
        (half * 0.5, half * 0.5, RED),
        (half * 1.5, half * 0.5, GREEN),
        (half * 0.5, half * 1.5, BLUE),
        (half * 1.5, half * 1.5, YELLOW),
    ] {
        let p = at(
            &pixels,
            (full_rect.origin.x + dx) as u32,
            (full_rect.origin.y + dy) as u32,
        );
        let err = (0..3)
            .map(|c| (p[c] as f64 - want[c] as f64).abs())
            .fold(0.0, f64::max);
        worst = worst.max(err);
    }
    report("[2] quadrant centres", worst, 6.0, "", &mut failures);

    // [3][4] A 32x32 source sub-rect scaled up 4x: tiling or whole-texture sampling shows green.
    // [3][4] 32x32 的源子矩形放大 4 倍：平铺或采样整张纹理都会显出绿色。
    let mut crop = canvas();
    let crop_rect = Rect::new(170.0, 16.0, 130.0, 130.0);
    add_image(
        &mut crop,
        ID_A,
        &data,
        crop_rect,
        Rect::new(0.0, 0.0, QUAD as f32, QUAD as f32),
        Corners::ZERO,
    );
    let (pixels, _) = draw(&mut gpu, &ctx, &target, &crop);
    let left = mean(&pixels, 175, 21, 235, 141);
    let right = mean(&pixels, 235, 21, 295, 141);
    report(
        "[3] cropped source, left half",
        worst_channel(left, RED),
        6.0,
        "",
        &mut failures,
    );
    report(
        "[4] cropped source, right half",
        worst_channel(right, RED),
        6.0,
        "",
        &mut failures,
    );
    report_eq(
        "[4b] foreign pixels in right half",
        foreign(&pixels, 235, 21, 295, 141, RED, 60) as i64,
        0,
        &mut failures,
    );

    // [5][6] Rounded corners cut the corner pixel but leave the straight edge filled.
    // [5][6] 圆角切掉角上的像素，但保留直边处的填充。
    let mut round = canvas();
    let round_rect = Rect::new(100.0, 160.0, 120.0, 60.0);
    add_image(
        &mut round,
        ID_A,
        &data,
        round_rect,
        Rect::new(0.0, 0.0, QUAD as f32, QUAD as f32),
        Corners::all(24.0),
    );
    let (pixels, _) = draw(&mut gpu, &ctx, &target, &round);
    let corner = at(&pixels, 102, 162);
    report(
        "[5] pixel outside the corner radius",
        worst_channel([corner[0] as f64, corner[1] as f64, corner[2] as f64], BG),
        2.0,
        "",
        &mut failures,
    );
    let edge = at(&pixels, 160, 162);
    report(
        "[6] pixel on the straight top edge",
        worst_channel([edge[0] as f64, edge[1] as f64, edge[2] as f64], RED),
        6.0,
        "",
        &mut failures,
    );

    // [7][8][9] One upload per `ImageEntry::id`: a second frame with the same id reuses it.
    // [7][8][9] 每个 `ImageEntry::id` 只上传一次：同一 id 的第二帧复用它。
    let (_, again) = draw(&mut gpu, &ctx, &target, &full);
    let mut other = canvas();
    add_image(
        &mut other,
        ID_B,
        &data,
        full_rect,
        Rect::new(0.0, 0.0, TEX as f32, TEX as f32),
        Corners::ZERO,
    );
    let (_, fresh) = draw(&mut gpu, &ctx, &target, &other);
    report_eq(
        "[7] uploads on first use",
        stats_full.image_uploads as i64,
        1,
        &mut failures,
    );
    report_eq(
        "[8] uploads on a repeated id",
        again.image_uploads as i64,
        0,
        &mut failures,
    );
    report_eq(
        "[9] uploads after an id change",
        fresh.image_uploads as i64,
        1,
        &mut failures,
    );
    report_eq(
        "[10] image primitives drawn",
        stats_full.images_drawn as i64,
        1,
        &mut failures,
    );

    // [11] With `src` inside [0,1] the wrap mode is invisible in pixels, so query the sampler.
    // [11] `src` 落在 [0,1] 内时环绕模式在像素上看不出来，只能直接查采样器状态。
    let clamp = glow::CLAMP_TO_EDGE as i32;
    match gpu.image_wrap(ctx.gl(), ID_B) {
        Some((s, t)) => {
            let bad = i64::from(s != clamp) + i64::from(t != clamp);
            report_eq("[11] wrap mode is CLAMP_TO_EDGE", bad, 0, &mut failures);
        }
        None => {
            println!("[11] wrap mode is CLAMP_TO_EDGE   texture missing  FAIL");
            failures += 1;
        }
    }

    gpu.release(ctx.gl());
    target.release(ctx.gl());

    println!("\nFAIL={failures}");
    if failures > 0 {
        std::process::exit(1);
    }
}
