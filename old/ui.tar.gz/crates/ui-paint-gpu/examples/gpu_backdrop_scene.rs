//! Backdrop blur must soften the backdrop and write back without punching a hole.
//! 背景模糊必须柔化背景，且写回时不得在帧上打洞。
//!
//! Run: `cargo run -p ui-paint-gpu --example gpu_backdrop_scene`

use ui_core::draw::{BackdropEntry, BackdropMaterial, DrawList, RectPrim};
use ui_core::geom::{Color, Corners, Rect};
use ui_core::NodeId;
use ui_paint_gpu::{EglContext, GpuRenderer, OffscreenFbo};

const W: u32 = 160;
const H: u32 = 120;

fn fail(failures: &mut u32, name: &str, ok: bool, detail: &str) {
    if ok {
        println!("  ok   {name} ({detail})");
    } else {
        println!("  FAIL {name} ({detail})");
        *failures += 1;
    }
}

fn alpha_at(data: &[u8], x: u32, y: u32) -> u8 {
    data[((y * W + x) * 4 + 3) as usize]
}

fn px(data: &[u8], x: u32, y: u32) -> [u8; 4] {
    let i = ((y * W + x) * 4) as usize;
    [data[i], data[i + 1], data[i + 2], data[i + 3]]
}

/// Opaque background with a bright square, then a backdrop blur over a region inside it.
/// 不透明背景 + 一块亮方块，然后在背景内部的一块区域上做背景模糊。
fn scene(rect: Rect, radius: u32, sigma: f32) -> DrawList {
    scene_with_panel(rect, radius, sigma, true)
}

/// The same scene with rounded corners on the panel: corner coverage is sub-pixel there.
/// 同一场景但面板带圆角：那里的角落覆盖率是亚像素的。
fn rounded(rect: Rect, radius: u32, sigma: f32) -> DrawList {
    let mut list = scene(rect, radius, sigma);
    if let Some(last) = list.prims.rects.last_mut() {
        last.radius = Corners::all(12.0);
    }
    if let Some(entry) = list.backdrops.last_mut() {
        entry.corners = Corners::all(12.0);
    }
    let _ = W;
    list
}

fn scene_with_panel(rect: Rect, radius: u32, sigma: f32, panel: bool) -> DrawList {
    let mut list = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    // Fill the whole canvas: anything transparent afterwards is a bug the blur caused.
    // 铺满整块画布：之后任何透明都是模糊导致的缺陷。
    list.push_rect(
        NodeId::from_raw(1, 0),
        RectPrim {
            rect: Rect::new(0.0, 0.0, W as f32, H as f32),
            radius: Corners::ZERO,
            fill: Color::from_rgba8(40, 90, 200, 255),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    list.push_rect(
        NodeId::from_raw(2, 0),
        RectPrim {
            rect: Rect::new(60.0, 40.0, 20.0, 20.0),
            radius: Corners::ZERO,
            fill: Color::WHITE,
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    list.push_backdrop(BackdropEntry {
        rect,
        clip: rect,
        corners: Corners::ZERO,
        radius,
        sigma,
        material: BackdropMaterial::PLAIN,
    });
    // The frosted panel itself: translucent, drawn after the blur, like the demo.
    // 磨砂面板本体：半透明，模糊之后绘制，与 demo 一致。
    if panel {
        list.push_rect(
            NodeId::from_raw(3, 0),
            RectPrim {
                rect,
                radius: Corners::ZERO,
                fill: Color::from_rgba8(255, 255, 255, 40),
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
    }
    list
}

fn main() {
    let node = std::env::args()
        .nth(1)
        .or_else(ui_paint_gpu::output_render_node)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node.clone()).expect("node path");
    let ctx = EglContext::new(cnode.as_c_str()).expect("EGL context");

    let inc = OffscreenFbo::new(ctx.gl(), W, H).expect("target");
    let mut g = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    g.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);

    let region = Rect::new(50.0, 30.0, 60.0, 60.0);
    // Rounded, because corner coverage is what a plain overwrite corrupts.
    // 用圆角，因为覆盖率正是直接覆盖会弄坏的地方。
    g.render(ctx.gl(), &inc, &rounded(region, 18, 6.0)).expect("render");
    let data = GpuRenderer::to_premultiplied_bgra(
        &g.read_pixels(ctx.gl(), &inc).expect("readback"),
    );

    let mut failures = 0u32;

    // 1. The blur must not punch a hole: every pixel inside the painted area stays opaque.
    // 1. 模糊不得打洞：已绘制区域内每个像素都保持不透明。
    let mut transparent = 0u32;
    for y in 0..H {
        for x in 0..W {
            if alpha_at(&data, x, y) < 250 {
                transparent += 1;
            }
        }
    }
    fail(
        &mut failures,
        "the backdrop leaves no transparent pixels",
        transparent == 0,
        &format!("{transparent} pixels below alpha 250"),
    );

    // 2. Corners of the blurred region must not fall off toward transparent.
    // 2. 模糊区域的角落不得朝透明衰减。
    let corner = px(&data, 51, 31);
    fail(
        &mut failures,
        "the region corner stays fully opaque",
        corner[3] == 255,
        &format!("corner alpha {}", corner[3]),
    );

    // 3. The blur must move pixels in a wide band around the square. Comparing against the
    //    same scene drawn sharp isolates the filter: the translucent panel appears in both.
    // 3. 模糊必须在方块周围的宽带上改变像素。与同一场景的清晰版本对比可隔离滤波器：
    //    半透明面板在两张图里都有。
    let mut sharp_renderer = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    sharp_renderer.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    let mut sharp_list = rounded(region, 18, 6.0);
    // Drop the backdrop op so the identical scene renders sharp.
    // 去掉背景模糊指令，使同一场景以清晰方式绘制。
    sharp_list.ops.retain(|op| !matches!(op, ui_core::draw::Op::Backdrop(_)));
    sharp_renderer
        .render(ctx.gl(), &inc, &sharp_list)
        .expect("render sharp");
    let sharp = GpuRenderer::to_premultiplied_bgra(
        &sharp_renderer.read_pixels(ctx.gl(), &inc).expect("readback"),
    );

    // Probe a point on the square's border, where a Gaussian must show its strongest
    // change: far-field probes cannot distinguish "weak blur" from "no blur".
    // 在方块边界上取样，高斯在这里的变化最明显：远处取样分不清「模糊很弱」与「没有模糊」。
    let i = ((50 * W + 79) * 4) as usize;
    let diff = (data[i + 1] as i32 - sharp[i + 1] as i32).abs()
        + (data[i + 2] as i32 - sharp[i + 2] as i32).abs();
    fail(
        &mut failures,
        "the blur mixes the square's edge with its surroundings",
        diff > 20,
        &format!("blurred {:?} vs sharp {:?}", &data[i..i + 4], &sharp[i..i + 4]),
    );

    // 4. Outside the region nothing changes: the scissor must hold.
    // 4. 区域外不变：scissor 必须生效。
    let outside = px(&data, 20, 20);
    // 5. Text-like high-frequency content under the panel must be smeared, not preserved:
    //    a sharp white pixel inside the region means the fill was drawn before the blur.
    // 5. 面板下的高频内容必须被抹开而不是保留：区域内出现锐利白像素，
    //    说明填充在模糊之前就画上了。
    let mut sharp_white = 0u32;
    for y in 42..58 {
        for x in 62..78 {
            let p = px(&data, x, y);
            if p[0] > 250 && p[1] > 250 && p[2] > 250 {
                sharp_white += 1;
            }
        }
    }
    fail(
        &mut failures,
        "no sharp white survives inside the region",
        sharp_white == 0,
        &format!("{sharp_white} pure-white pixels inside the blurred square"),
    );

    fail(
        &mut failures,
        "pixels outside the region are untouched",
        outside == [200, 90, 40, 255],
        &format!("got {:?}", outside),
    );

    // 6. Edge sharpness: the largest luminance step across the blurred boundary must be
    //    far smaller than the same step in an unblurred render. Counting colour breaks
    //    is unreliable here (the panel's own text contributes); the step size is not.
    // 6. 边缘锐度：模糊边界上的最大亮度跳变必须远小于未模糊时的同一跳变。
    //    这里数颜色断点并不可靠（面板自身文字也会计数），而跳变幅度可靠。
    let max_step = |data: &[u8], y: u32, x0: u32, x1: u32| -> i32 {
        let mut m = 0i32;
        let mut prev: Option<i32> = None;
        for x in x0..x1 {
            let p = px(data, x, y);
            let v = (p[0] as i32 + p[1] as i32 + p[2] as i32) / 3;
            if let Some(q) = prev {
                m = m.max((v - q).abs());
            }
            prev = Some(v);
        }
        m
    };
    let sharp_step = max_step(&sharp, 50, 60, 90);
    let blurred_step = max_step(&data, 50, 60, 90);
    fail(
        &mut failures,
        "blurring reduces the boundary step substantially",
        blurred_step * 2 < sharp_step,
        &format!("blurred {blurred_step} vs sharp {sharp_step}"),
    );

    // 7. A wider sigma must produce a gentler slope at the edge. A kernel capped by an
    //    array length makes both identical, which is the failure this catches.
    // 7. 更大的 sigma 必须让边缘更平缓。被数组长度截断的核会让两者完全相同，
    //    这正是本条要抓的失败。
    let mut slope = |list: &ui_core::draw::DrawList| -> i32 {
        g.render(ctx.gl(), &inc, list).expect("render");
        let buf = g.read_pixels(ctx.gl(), &inc).expect("readback");
        // Largest single-pixel step along the row that crosses the square's edges.
        // 跨过方块边缘那一行上，相邻像素间的最大跳变。
        let mut m = 0i32;
        let mut prev: Option<i32> = None;
        for x in 50..92 {
            let v = px(&buf, x, 50)[1] as i32;
            if let Some(q) = prev {
                m = m.max((v - q).abs());
            }
            prev = Some(v);
        }
        m
    };
    let narrow = slope(&rounded(region, 18, 4.0));
    let wide = slope(&rounded(region, 18, 24.0));
    fail(
        &mut failures,
        "a larger sigma produces a gentler edge instead of being capped",
        wide < narrow,
        &format!("sigma 4 steps {narrow}, sigma 24 steps {wide}"),
    );

    // 8. A sigma comparable to the region itself must flatten it: the square's interior
    //    and its surroundings converge. A 16px-capped kernel cannot do this, so the check
    //    separates "really blurred" from "blurred as far as the array allows".
    // 8. 与区域本身同量级的 sigma 必须把它抹平：方块内部与周围趋于一致。
    //    被钳到 16px 的核做不到这一点，因此本条能区分「真的模糊」与「只模糊到数组上限」。
    let mut flatness = |sigma: f32| -> i32 {
        g.render(ctx.gl(), &inc, &rounded(region, 18, sigma)).expect("render");
        let buf = g.read_pixels(ctx.gl(), &inc).expect("readback");
        let mut lo = 255i32;
        let mut hi = 0i32;
        for y in 35..85 {
            for x in 55..105 {
                let v = px(&buf, x, y)[1] as i32;
                lo = lo.min(v);
                hi = hi.max(v);
            }
        }
        hi - lo
    };
    let at_cap = flatness(5.0);
    let beyond_cap = flatness(30.0);
    fail(
        &mut failures,
        "a sigma past the kernel cap still flattens the region",
        beyond_cap < at_cap / 2,
        &format!("sigma 5 spread {at_cap}, sigma 30 spread {beyond_cap}"),
    );

    // 9. A hard edge under the panel must become a long ramp. Counting pixels whose
    //    neighbours differ is the direct test: a sharp edge yields one change, a blurred
    //    one yields a run of them.
    // 9. 面板下的硬边必须变成一条长斜坡。直接测法是数「与邻居不同的像素」：
    //    硬边只产生一次变化，模糊后会产生一整串。
    let ramp = |data: &[u8], y: u32, x0: u32, x1: u32| -> u32 {
        let mut n = 0u32;
        let mut prev: Option<[u8; 4]> = None;
        for x in x0..x1 {
            let p = px(data, x, y);
            if let Some(q) = prev
                && p != q {
                    n += 1;
                }
            prev = Some(p);
        }
        n
    };
    // The square's left edge is at x=60; scan a window centred on it.
    let blurred_ramp = ramp(&data, 50, 40, 80);
    let sharp_ramp = ramp(&sharp, 50, 40, 80);
    fail(
        &mut failures,
        "a hard edge becomes a ramp under the blur",
        blurred_ramp > sharp_ramp * 3,
        &format!("blurred {blurred_ramp} changing pixels vs sharp {sharp_ramp}"),
    );

    // 10. Repeating the same frame must be idempotent. A frost that is re-blended over
    //     its own output drifts toward the backdrop colour frame by frame, which is the
    //     symptom this pins down.
    // 10. 重复渲染同一帧必须幂等。把模糊结果反复混合到自身之上的实现在帧间会向背景色漂移，
    //     这正是本条要钉住的症状。
    let mut repeat = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    repeat.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    let scene_list = rounded(region, 18, 6.0);
    repeat.render(ctx.gl(), &inc, &scene_list).expect("render");
    let first = GpuRenderer::to_premultiplied_bgra(
        &repeat.read_pixels(ctx.gl(), &inc).expect("readback"),
    );
    for _ in 0..6 {
        repeat.render(ctx.gl(), &inc, &scene_list).expect("render");
    }
    let later = GpuRenderer::to_premultiplied_bgra(
        &repeat.read_pixels(ctx.gl(), &inc).expect("readback"),
    );
    let drift = first
        .iter()
        .zip(later.iter())
        .map(|(a, b)| (*a as i32 - *b as i32).abs())
        .max()
        .unwrap_or(0);
    fail(
        &mut failures,
        "repeating a still frame does not drift",
        drift <= 1,
        &format!("largest channel drift after 6 repeats: {drift}"),
    );

    // 11. `damage` must not influence the pixels any more. A frame that reports a small
    //     damaged rect has to look exactly like one that reports everything, because the
    //     renderer repaints the whole surface either way. If damage ever leaks back into
    //     content, this is the check that says so.
    // 11. `damage` 不得再影响像素。只上报一小块脏区的帧必须与上报全量的帧完全一致，
    //     因为渲染器无论如何都重画整个表面。若脏区又渗回内容，本条会指出它。
    let mut full_repaint = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    full_repaint.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    full_repaint.render(ctx.gl(), &inc, &scene_list).expect("render");
    let reference = GpuRenderer::to_premultiplied_bgra(
        &full_repaint.read_pixels(ctx.gl(), &inc).expect("readback"),
    );
    // The marked rect sits inside the square, which the frost reads.
    // 该矩形位于方块内部，正是磨砂读取的范围。
    let mut same = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    same.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    same.render(ctx.gl(), &inc, &scene_list).expect("render");
    let after = GpuRenderer::to_premultiplied_bgra(
        &same.read_pixels(ctx.gl(), &inc).expect("readback"),
    );
    let diff: u64 = reference
        .iter()
        .zip(after.iter())
        .map(|(a, b)| (*a as i64 - *b as i64).unsigned_abs())
        .sum();
    fail(
        &mut failures,
        "a repeated frame is byte-identical",
        diff == 0,
        &format!("{diff} bytes differ"),
    );
    let transparent = after.as_chunks::<4>().0.iter().filter(|p| p[3] < 250).count();
    fail(
        &mut failures,
        "the frost leaves no transparent pixels",
        transparent == 0,
        &format!("{transparent} pixels below alpha 250"),
    );

    // 12. Content straddling the frost's edge must blur with the *outside* pixels too.
    //     A snapshot that stops at the frost boundary makes the outermost band read clamped
    //     values, which shows up as a plateau along the edge instead of a gradient.
    // 12. 跨过磨砂边界的内容必须连**界外**像素一起参与模糊。只存到边界为止的快照会让最外侧
    //     一带读到夹取值，表现为边缘出现平台而不是渐变。
    let straddling = |list: &mut DrawList| {
        list.push_rect(
            NodeId::from_raw(9, 0),
            RectPrim {
                // Half inside the frost (x 50..110), half outside to the left.
                // 一半在磨砂内（x 50..110），一半在左侧界外。
                rect: Rect::new(20.0, 40.0, 40.0, 20.0),
                radius: Corners::ZERO,
                fill: Color::WHITE,
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
    };
    let mut edge_list = rounded(region, 18, 6.0);
    straddling(&mut edge_list);
    let mut edge_renderer = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    edge_renderer.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    edge_renderer
        .render(ctx.gl(), &inc, &edge_list)
        .expect("render");
    let edge_buf = GpuRenderer::to_premultiplied_bgra(
        &edge_renderer.read_pixels(ctx.gl(), &inc).expect("readback"),
    );
    // Walk the row through the white band and count distinct values just inside the frost.
    // 沿白带所在行、在磨砂内缘一带数不同取值。
    let row_changes = {
        let mut n = 0;
        let mut prev: Option<[u8; 4]> = None;
        for x in 50..80 {
            let i = ((60 * W + x) * 4) as usize;
            let p = [edge_buf[i], edge_buf[i + 1], edge_buf[i + 2], edge_buf[i + 3]];
            if prev.is_some_and(|q| q != p) {
                n += 1;
            }
            prev = Some(p);
        }
        n
    };
    fail(
        &mut failures,
        "content straddling the frost edge still produces a gradient",
        row_changes > 3,
        &format!("{row_changes} distinct steps along the inner edge"),
    );

    // 13. A translucent frost panel over an opaque backdrop must stay opaque. The blur
    //     averages premultiplied values, so if the panel's own fill leaks into the result
    //     the area gets more transparent than the fill alone would make it.
    // 13. 不透明背景上的半透明磨砂面板必须保持不透明。模糊平均的是预乘值，若面板自身
    //     填充渗进结果，该区域会比单靠填充更透明。
    let mut alpha_probe = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    alpha_probe.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    alpha_probe
        .render(ctx.gl(), &inc, &scene_with_panel(region, 18, 6.0, true))
        .expect("render");
    let probe = GpuRenderer::to_premultiplied_bgra(
        &alpha_probe.read_pixels(ctx.gl(), &inc).expect("readback"),
    );
    // The panel fill is white at alpha 40, so the result is opaque only if the backdrop
    // underneath contributed alpha 255.
    // 面板填充是 alpha 40 的白色，只有下方背景贡献了 alpha 255，结果才会不透明。
    let interior = [(60u32, 40u32), (90, 50), (75, 80)];
    let alphas: Vec<u8> = interior.iter().map(|(x, y)| alpha_at(&probe, *x, *y)).collect();
    fail(
        &mut failures,
        "a translucent frost over an opaque backdrop stays opaque",
        alphas.iter().all(|a| *a == 255),
        &format!("alphas {alphas:?}"),
    );

    // 14. The vertical axis must blur as much as the horizontal one. A chain that drops its
    //     vertical pass leaves a horizontal band pristine, which reads as a colour wash
    //     rather than frost.
    // 14. 纵向必须与横向同样模糊。丢掉纵向趟次的链路会让水平条带保持清晰，
    //     看起来像一层色罩而不是磨砂。
    let horizontal = |list: &mut DrawList| {
        // A tall thin bar: only a vertical blur can smear it sideways into soft edges.
        // 一根细高的竖条：只有纵向模糊才能把它向左右抹开。
        list.push_rect(
            NodeId::from_raw(31, 0),
            RectPrim {
                rect: Rect::new(76.0, 40.0, 8.0, 40.0),
                radius: Corners::ZERO,
                fill: Color::WHITE,
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
    };
    let mut axes = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    axes.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    // The bar must be painted *before* the backdrop, or the blur never reads it.
    // 竖条必须在 backdrop 之前绘制，否则模糊根本读不到它。
    let mut vertical_scene = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    vertical_scene.push_rect(
        NodeId::from_raw(30, 0),
        RectPrim {
            rect: Rect::new(0.0, 0.0, W as f32, H as f32),
            radius: Corners::ZERO,
            fill: Color::from_rgba8(0, 0, 0, 255),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    horizontal(&mut vertical_scene);
    vertical_scene.push_backdrop(BackdropEntry {
        rect: region,
        clip: region,
        corners: Corners::ZERO,
        radius: 0,
        sigma: 10.0,
        material: ui_core::draw::BackdropMaterial::PLAIN,
    });
    axes.render(ctx.gl(), &inc, &vertical_scene).expect("render");
    let bar = GpuRenderer::to_premultiplied_bgra(
        &axes.read_pixels(ctx.gl(), &inc).expect("readback"),
    );
    // Walk across the bar at mid-height: a correctly blurred bar has no step left.
    // 在竖条中部横向扫一行：正确模糊后不应再有台阶。
    let mut steps = 0u32;
    let mut prev: Option<[u8; 4]> = None;
    for x in 60..104u32 {
        let i = ((60 * W + x) * 4) as usize;
        let px = [bar[i], bar[i + 1], bar[i + 2], bar[i + 3]];
        if prev.is_some_and(|p| {
            (p[0] as i32 - px[0] as i32).abs() > 6
        }) {
            steps += 1;
        }
        prev = Some(px);
    }
    fail(
        &mut failures,
        "a vertical bar is smeared sideways by the blur",
        steps == 0,
        &format!("{steps} sharp steps across the bar"),
    );

    // 15. Detail under the frost must actually be gone. A colour wash keeps the backdrop's
    //     structure (text, edges) while lowering its contrast; a real blur dissolves it into
    //     a smooth field, so neighbouring pixels stop tracking the original.
    // 15. 磨砂下方的细节必须真正消失。单纯的色罩会保留背景结构（文字、边缘）只是降低对比；
    //     真正的模糊会把它融成平滑场，相邻像素不再跟随原图。
    let mut detail = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    detail.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    // A one-pixel checkerboard is the sharpest possible structure.
    // 一像素棋盘格是最尖锐的结构。
    let mut board = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    for gy in 0..(H / 2) {
        for gx in 0..(W / 2) {
            let on = (gx + gy) % 2 == 0;
            board.push_rect(
                NodeId::from_raw(40 + gx * 64 + gy, 0),
                RectPrim {
                    rect: Rect::new((gx * 2) as f32, (gy * 2) as f32, 2.0, 2.0),
                    radius: Corners::ZERO,
                    fill: if on {
                        Color::from_rgba8(255, 255, 255, 255)
                    } else {
                        Color::from_rgba8(0, 0, 0, 255)
                    },
                    border: None,
                    border_gradient: None,
                    gradient: None,
                    notch: None,
                },
            );
        }
    }
    board.push_backdrop(BackdropEntry {
        rect: region,
        clip: region,
        corners: Corners::ZERO,
        radius: 0,
        sigma: 6.0,
        material: ui_core::draw::BackdropMaterial::PLAIN,
    });
    detail.render(ctx.gl(), &inc, &board).expect("render");
    let checker = GpuRenderer::to_premultiplied_bgra(
        &detail.read_pixels(ctx.gl(), &inc).expect("readback"),
    );
    // Inside the frost the checkerboard's two-tone alternation must be much flatter.
    // 磨砂内部，棋盘格的明暗交替必须被大幅压平。
    let mut lo = 255u8;
    let mut hi = 0u8;
    for y in 36..84u32 {
        for x in 56..104u32 {
            let v = checker[((y * W + x) * 4) as usize];
            lo = lo.min(v);
            hi = hi.max(v);
        }
    }
    fail(
        &mut failures,
        "a checkerboard under the frost collapses to a flat field",
        hi - lo < 60,
        &format!("spread {lo}..{hi} = {}", hi - lo),
    );

    // 16. A frost touching the layer's bottom edge must still be blurred there. The blur
    //     reads below its own rect, so the snapshot has to stay defined past the frost.
    // 16. 贴住层底边的磨砂在底部仍必须被模糊。模糊会读到自身矩形下方，因此快照在磨砂之外
    //     也必须保持有效。
    let mut edge = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    edge.clear(ctx.gl(), &inc, [0.0, 0.0, 0.0, 0.0]);
    let low = Rect::new(50.0, H as f32 - 40.0, 60.0, 40.0);
    let mut lowboard = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    for gy in 0..(H / 2) {
        for gx in 0..(W / 2) {
            let on = (gx + gy) % 2 == 0;
            lowboard.push_rect(
                NodeId::from_raw(900 + gx * 64 + gy, 0),
                RectPrim {
                    rect: Rect::new((gx * 2) as f32, (gy * 2) as f32, 2.0, 2.0),
                    radius: Corners::ZERO,
                    fill: if on {
                        Color::from_rgba8(255, 255, 255, 255)
                    } else {
                        Color::from_rgba8(0, 0, 0, 255)
                    },
                    border: None,
                    border_gradient: None,
                    gradient: None,
                    notch: None,
                },
            );
        }
    }
    lowboard.push_backdrop(BackdropEntry {
        rect: low,
        clip: low,
        corners: Corners::ZERO,
        radius: 0,
        sigma: 6.0,
        material: ui_core::draw::BackdropMaterial::PLAIN,
    });
    // Move the frost to the bottom at runtime: the filter reads the live frame each time,
    // so a frost that was higher up a moment ago leaves nothing behind to read.
    // 运行中把磨砂移到底部：滤波器每次都读当帧画面，因此刚才还在更高处的磨砂不会留下任何
    // 可被读到的残留。
    edge.render(ctx.gl(), &inc, &board).expect("a frost higher up");
    edge.render(ctx.gl(), &inc, &lowboard).expect("the frost at the bottom");
    let lowpx = GpuRenderer::to_premultiplied_bgra(
        &edge.read_pixels(ctx.gl(), &inc).expect("readback"),
    );
    // Sample the last rows still inside the frost: the checkerboard must be gone there too.
    // 取磨砂内部最后几行：那里棋盘格也必须消失。
    let mut worst = 0i32;
    for y in (H - 6)..(H - 1) {
        let mut lo = 255i32;
        let mut hi = 0i32;
        for x in 60..110 {
            let v = lowpx[((y * W + x) * 4) as usize] as i32;
            lo = lo.min(v);
            hi = hi.max(v);
        }
        worst = worst.max(hi - lo);
    }
    fail(
        &mut failures,
        "a frost touching the bottom edge is blurred there too",
        worst <= 6,
        &format!("spread near the bottom = {worst}"),
    );

    if failures > 0 {
        eprintln!("\n{failures} invariant(s) violated");
        std::process::exit(1);
    }
    println!("\nbackdrop blur writes back without punching a hole");
}
