//! Blur on both backends: same behaviour, different rounding.
//! 两个后端上的模糊：行为相同，舍入不同。
//!
//! Exact pixel equality is the wrong bar here — the CPU path truncates u8 and the GPU
//! path rounds float. What must match is the *behaviour*: ink is conserved, the peak
//! drops, ink spreads, and nothing beyond the radius moves.
//! 逐像素相等不是这里的目标——CPU 截断 u8，GPU 舍入浮点。必须一致的是**行为**：
//! 质量守恒、峰值下降、墨迹外扩、半径之外不动。
//!
//! Run: `cargo run -p ui-paint-gpu --example gpu_blur_scene`

use ui_core::damage::Damage;
use ui_core::draw::{DrawList, RectPrim};
use ui_core::effect::Effect;
use ui_core::geom::{Color, Corners, Rect};
use ui_core::NodeId;
use ui_paint::{CpuRenderer, Pixels};
use ui_paint_gpu::{EglContext, GpuRenderer, OffscreenFbo};

const W: u32 = 160;
const H: u32 = 120;
const RADIUS: u32 = 6;
const SIGMA: f32 = 2.5;
/// The blurred square: 24x24 at (48,48), so its last lit pixel is 71.
const DOT: f32 = 24.0;
const DOT_AT: f32 = 48.0;

fn scene(effects: Vec<Effect>) -> DrawList {
    let mut list = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    list.push_layer(
        // Tight bounds: a wrong scissor would clip the blur and fail the spread check.
        // 收紧边界：scissor 算错就会切断模糊，扩散判据会失败。
        Rect::new(
            DOT_AT - RADIUS as f32,
            DOT_AT - RADIUS as f32,
            DOT + 2.0 * RADIUS as f32,
            DOT + 2.0 * RADIUS as f32,
        ),
        effects,
        Corners::ZERO,
    );
    list.push_rect(
        NodeId::from_raw(1, 0),
        RectPrim {
            rect: Rect::new(DOT_AT, DOT_AT, DOT, DOT),
            radius: Corners::ZERO,
            fill: Color::WHITE,
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    list.pop_layer();
    list
}

fn alpha_at(data: &[u8], x: u32, y: u32) -> u8 {
    data[((y * W + x) * 4 + 3) as usize]
}

fn ink(data: &[u8]) -> u64 {
    data.as_chunks::<4>().0.iter()
        .map(|c| c[0] as u64 + c[1] as u64 + c[2] as u64)
        .sum()
}

fn report(name: &str, ok: bool, detail: &str, failures: &mut u32) {
    println!("{name:30} {detail:>22}  {}", if ok { "OK" } else { "FAIL" });
    if !ok {
        *failures += 1;
    }
}

fn main() {
    // CPU reference and GPU, both with the same chain.
    let mut cpu = CpuRenderer::new();
    let mut pixels = Pixels::new(W, H);
    cpu.render(&scene(vec![Effect::blur(RADIUS, SIGMA)]), &mut pixels, &Damage::Full);
    let cpu_blur = pixels.data.clone();

    let mut sharp_pixels = Pixels::new(W, H);
    cpu.render(&scene(vec![Effect::none()]), &mut sharp_pixels, &Damage::Full);
    let cpu_sharp = sharp_pixels.data.clone();

    let node = std::env::args()
        .nth(1)
        .or_else(ui_paint_gpu::output_render_node)
        .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
    let cnode = std::ffi::CString::new(node.clone()).expect("node path");
    let ctx = EglContext::new(cnode.as_c_str()).expect("EGL context");
    println!("GPU: {} ({node})", ctx.renderer());
    let target = OffscreenFbo::new(ctx.gl(), W, H).expect("target");
    let mut gpu = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
    gpu.clear(ctx.gl(), &target, [0.0, 0.0, 0.0, 0.0]);
    gpu.render(ctx.gl(), &target, &scene(vec![Effect::blur(RADIUS, SIGMA)]))
        .expect("render");
    // `read_pixels` is straight RGBA; `Pixels` is premultiplied BGRA. Convert once, here.
    // `read_pixels` 是直通 RGBA，`Pixels` 是预乘 BGRA。只在这里转换一次。
    let gpu_blur = GpuRenderer::to_premultiplied_bgra(&gpu.read_pixels(ctx.gl(), &target).expect("readback"));

    let mut failures = 0;

    // 1. Both backends conserve ink: a normalised kernel moves it, never creates it.
    // 1. 两个后端都守恒：归一化核只搬运墨迹，不创造墨迹。
    let (c_ink, g_ink) = (ink(&cpu_blur), ink(&gpu_blur));
    let sharp_ink = ink(&cpu_sharp);
    for (name, value) in [("cpu", c_ink), ("gpu", g_ink)] {
        let drift = (sharp_ink as i64 - value as i64).abs();
        report(
            &format!("1 {name} ink drift"),
            drift * 50 <= sharp_ink as i64,
            &format!("{drift} of {sharp_ink}"),
            &mut failures,
        );
    }

    // 2. The edge softens. The *centre* stays saturated for a spot larger than the kernel,
    //    so "peak drops" is not a property of blur — the edge is.
    // 2. 边缘变软。色块比核大时**中心**本就保持饱和，所以"峰值下降"不是模糊的性质，边缘才是。
    let centre = (DOT_AT + DOT / 2.0) as u32;
    let edge = (DOT_AT + DOT) as u32 - 1;
    let sharp_edge = alpha_at(&cpu_sharp, edge, centre);
    for (name, data) in [("cpu", &cpu_blur), ("gpu", &gpu_blur)] {
        let value = alpha_at(data, edge, centre);
        report(
            &format!("2 {name} edge softens"),
            value + 40 < sharp_edge,
            &format!("{sharp_edge} -> {value}"),
            &mut failures,
        );
    }

    // 3. Ink reaches a pixel just outside the square.
    // 3. 墨迹到达方块外侧紧邻的像素。
    let outside = (DOT_AT - 2.0) as u32;
    for (name, data) in [("cpu", &cpu_blur), ("gpu", &gpu_blur)] {
        let value = alpha_at(data, outside, centre);
        report(
            &format!("3 {name} ink spreads"),
            value > alpha_at(&cpu_sharp, outside, centre) + 8,
            &format!("-> {value}"),
            &mut failures,
        );
    }

    // 4. Nothing beyond the radius moved.
    // 4. 半径之外没有任何变化。
    let far = (DOT_AT + DOT) as u32 + RADIUS;
    for (name, data) in [("cpu", &cpu_blur), ("gpu", &gpu_blur)] {
        let same = (0..H).all(|y| alpha_at(data, far, y) == 0);
        report(
            &format!("4 {name} reach bounded"),
            same,
            &format!("x={far} clear"),
            &mut failures,
        );
    }

    // 5. The two backends agree within rounding, not exactly.
    // 5. 两个后端在舍入范围内一致，而不是逐像素相等。
    let total: u64 = cpu_blur
        .iter()
        .zip(gpu_blur.iter())
        .map(|(a, b)| (*a as i64 - *b as i64).unsigned_abs())
        .sum();
    let mean = total as f64 / cpu_blur.len() as f64;
    report(
        "5 cpu/gpu mean channel delta",
        mean <= 3.0,
        &format!("{mean:.3}/255"),
        &mut failures,
    );

    if std::env::var("DUMP_BLUR").is_ok() {
        use std::io::Write;
        for (name, data) in [("cpu", &cpu_blur), ("gpu", &gpu_blur)] {
            let path = format!("/tmp/blur_{name}.ppm");
            let mut f = std::fs::File::create(&path).expect("ppm");
            write!(f, "P6\n{} {}\n255\n", W, H).expect("hdr");
            for p in data.as_chunks::<4>().0 {
                let _ = f.write_all(&[p[2], p[1], p[0]]);
            }
            println!("dumped {path}");
        }
    }

    // 6. A renderer reused across different scenes must not carry anything over: paint a
    //    second scene, come back to the first, and the pixels must equal a single render by
    //    a renderer that has drawn nothing else. Cross-frame reuse was removed
    //    (docs/effect-cache-plan.md §11); this keeps it from creeping back through some
    //    intermediate texture. The reference must come from a *fresh* renderer — comparing
    //    two reused outputs would pass even when both are wrong the same way.
    // 6. 跨场景复用的渲染器不得携带任何残留：先画另一个场景，再回到原场景，像素必须等于
    //    一个「别的什么都没画过」的渲染器的单次渲染。跨帧复用已撤除
    //    （docs/effect-cache-plan.md §11）；本条防止它经由某个中间纹理偷偷回来。
    //    参考必须来自**全新**渲染器——比较两个都被复用过的输出，即便两者同样错也会通过。
    {
        let chain = vec![Effect::blur(RADIUS, SIGMA)];
        let fresh_target = OffscreenFbo::new(ctx.gl(), W, H).expect("target");
        let mut fresh = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
        fresh.clear(ctx.gl(), &fresh_target, [0.0, 0.0, 0.0, 0.0]);
        fresh
            .render(ctx.gl(), &fresh_target, &scene(chain.clone()))
            .expect("fresh render");
        let reference = GpuRenderer::to_premultiplied_bgra(
            &fresh.read_pixels(ctx.gl(), &fresh_target).expect("readback"),
        );

        let reused_target = OffscreenFbo::new(ctx.gl(), W, H).expect("target");
        let mut reused = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");
        reused.clear(ctx.gl(), &reused_target, [0.0, 0.0, 0.0, 0.0]);
        // A different chain and a different scene, so every scratch target holds foreign
        // pixels before the reference render runs.
        // 换一条链、换一个场景，使所有暂存目标在参考渲染之前都装着别的内容。
        let other = vec![Effect::blur(RADIUS + 2, SIGMA * 2.0)];
        let mut other_scene = scene(other);
        other_scene.push_rect(
            NodeId::from_raw(77, 0),
            RectPrim {
                rect: Rect::new(0.0, 0.0, W as f32, H as f32),
                radius: Corners::ZERO,
                fill: Color::from_rgba8(255, 255, 255, 255),
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
        reused.render(ctx.gl(), &reused_target, &other_scene).expect("other scene");
        reused.render(ctx.gl(), &reused_target, &scene(chain)).expect("reference");
        let px = GpuRenderer::to_premultiplied_bgra(
            &reused.read_pixels(ctx.gl(), &reused_target).expect("readback"),
        );
        let diff: u64 = reference
            .iter()
            .zip(px.iter())
            .map(|(a, b)| (*a as i64 - *b as i64).unsigned_abs())
            .sum();
        report(
            "6 reused renderer == single fresh render",
            diff == 0,
            &format!("{diff} bytes differ"),
            &mut failures,
        );
        // Equality alone is not enough: two renders that are wrong the same way are equal
        // too. The CPU result is the independent reference — it never reuses anything.
        // 仅相等还不够：以同样方式错两次也相等。CPU 结果是独立参考——它从不复用任何东西。
        let total: u64 = cpu_blur
            .iter()
            .zip(px.iter())
            .map(|(a, b)| (*a as i64 - *b as i64).unsigned_abs())
            .sum();
        let mean = total as f64 / cpu_blur.len() as f64;
        report(
            "6b reused renderer matches the CPU reference",
            mean <= 3.0,
            &format!("{mean:.3}/255"),
            &mut failures,
        );
    }

    if failures > 0 {
        eprintln!("\n{failures} invariant(s) violated");
        std::process::exit(1);
    }
    println!("\nblur behaves the same on both backends");
}
