//! GPU paint backend: EGL + OpenGL ES rendering into dma-buf backed targets.
//! GPU 绘制后端：EGL + OpenGL ES，渲染进 dma-buf 支撑的目标。
//!
//! Why not wgpu: it exposes no dma-buf export, so zero-copy presentation is
//! impossible with it. See `docs/gpu-backend.md` §1.
//! 为什么不用 wgpu：它没有 dma-buf 导出，无法做到零拷贝呈现。见 `docs/gpu-backend.md` §1。

mod effect_pass;
pub mod material;
pub mod node;
pub mod renderer;
pub mod shader;
pub mod offscreen;
pub use ui_gpu_egl::{DmaBufTarget as GpuTarget, GpuSurface, SyncTimeline};

pub use ui_gpu_egl::EglContext;
/// Compatibility path: existing `crate::context::…` references keep working.
/// 兼容路径：现有 `crate::context::…` 引用继续有效。
pub mod context {
    pub use ui_gpu_egl::context::*;
}
/// Same for the gbm bindings.
/// gbm 绑定同理。
pub mod ffi {
    pub use ui_gpu_egl::ffi::*;
}
pub use renderer::partial_frames;
pub use ui_gpu_egl::GpuError;
pub use node::{candidate_nodes, output_render_node};
pub use material::{Acrylic, BackdropMaterial, LiquidGlass};
pub use renderer::{AtlasUpload, GpuRenderer, RenderStats};
/// Storage precision of internal render targets.
/// 内部渲染目标的存储精度。
pub use effect_pass::TargetFormat;
pub use offscreen::OffscreenFbo;
