//! GLSL sources and the instance layout each program expects.
//! GLSL 源码，以及每个程序期望的实例数据布局。

/// Floats per rounded-rect instance: rect, radius, fill, border, shape, far stop, gradient,
/// border width, notch. Colour and width are separate slots: one slot cannot carry both.
/// 每个圆角矩形实例的浮点数：矩形、圆角、填充、边框、形状、远端色、渐变、边框宽、缺口。
/// 颜色与宽度各占一槽：同一槽不能兼任两者。
pub const RECT_STRIDE: i32 = 39;

/// Largest tap count the effect shader accepts; keep in sync with `u_weights[33]`.
/// 效果着色器接受的最大 tap 数；与 `u_weights[33]` 保持一致。
pub const MAX_TAPS: u32 = 33;

/// The SDF feather, in device pixels: coverage ramps over this width, and every quad reaches
/// this far past its shape so that no covered pixel centre falls outside it.
/// SDF 羽化宽度（设备像素）：覆盖率在此宽度内渐变，每个四边形也向外伸出同样距离，
/// 使任何有覆盖的像素中心都落在其内。
pub const AA_GLSL: &str = include_str!("shaders/aa.glsl");

/// Clip uniforms and the coverage test shared by every fragment program.
/// 所有片元程序共用的裁剪 uniform 与覆盖度判定。
///
/// Composed into the sources rather than duplicated, so the two programs cannot drift.
/// 组合进源串而非复制，避免两个程序各自漂移。
pub const CLIP_GLSL: &str = include_str!("shaders/clip.glsl");

/// Rounded-shape coverage plus the uniforms it reads, shared by every backdrop program.
/// 圆角形状覆盖度及其读取的 uniform，所有背景程序共用。
pub const COVERAGE_GLSL: &str = include_str!("shaders/coverage.glsl");

/// Rounded-box signed distance, shared by the rect and the glass programs.
/// 圆角矩形有符号距离，矩形与玻璃程序共用。
pub const SDF_GLSL: &str = include_str!("shaders/sdf.glsl");

/// Floats per glyph instance: dest rect, atlas rect, colour, kind.
/// 每个字形实例的浮点数：目标矩形、图集矩形、颜色、种类。
pub const GLYPH_STRIDE: i32 = 13;

/// Floats per image instance: dest rect, radius, uv rect, shape exponent.
/// 每个图像实例的浮点数：目标矩形、圆角、uv 矩形、形状指数。
pub const IMAGE_STRIDE: i32 = 13;

/// Unit quad shared by both programs; scaled per instance.
/// 两个程序共用的单位四边形，按实例缩放。
pub const UNIT_QUAD: [f32; 12] = [
    0.0, 0.0, 1.0, 0.0, 1.0, 1.0, //
    0.0, 0.0, 1.0, 1.0, 0.0, 1.0,
];

/// Floats per shadow instance: rect, radius, colour, blur, dy, shape.
/// 每个阴影实例的浮点数：矩形、圆角、颜色、衰减宽度、垂直偏移、指数。
pub const SHADOW_STRIDE: i32 = 16;

pub const SHADOW_VERTEX: &str = include_str!("shaders/shadow.vert.glsl");

/// Flat ±100 px shift for diagnosis: a displaced wash proves the quad is drawn at all.
/// 诊断用的 +100px 平移：能把色块挪出来就证明四边形确实被画了。
pub const SHADOW_FRAGMENT: &str = include_str!("shaders/shadow.frag.glsl");

pub const RECT_VERTEX: &str = include_str!("shaders/rect.vert.glsl");

pub const RECT_FRAGMENT: &str = include_str!("shaders/rect.frag.glsl");

pub const GLYPH_VERTEX: &str = include_str!("shaders/glyph.vert.glsl");

pub const GLYPH_FRAGMENT: &str = include_str!("shaders/glyph.frag.glsl");

/// Samples one RGBA8 texture through a rounded rect, stride is `IMAGE_STRIDE`.
/// 在一个圆角矩形内采样一张 RGBA8 纹理，步长为 `IMAGE_STRIDE`。
pub const IMAGE_VERTEX: &str = include_str!("shaders/image.vert.glsl");

pub const IMAGE_FRAGMENT: &str = include_str!("shaders/image.frag.glsl");

/// Instanced quad for compositing a layer texture, stride is `RECT_STRIDE`.
/// 用于合成层纹理的实例化四边形，步长为 `RECT_STRIDE`。
pub const LAYER_VERTEX: &str = include_str!("shaders/layer.vert.glsl");

pub const LAYER_FRAGMENT: &str = include_str!("shaders/layer.frag.glsl");

/// Composite a blurred backdrop as WinUI acrylic: luminosity, tint, then grain.
/// 把模糊后的背景按 WinUI acrylic 合成：亮度、着色、噪点。
pub const ACRYLIC_FRAGMENT: &str = include_str!("shaders/acrylic.frag.glsl");

/// LiquidGlassKit's material, ported whole (`LiquidGlassFragment.metal:435-540`): the face
/// shows a capture of the backdrop, the rim bends by a thin prism, then Fresnel and glare
/// are added in LCH.
/// LiquidGlassKit 的整套材质（`LiquidGlassFragment.metal:435-540`）：面下是捕获的背景，
/// 边缘按薄棱镜偏角弯折，再在 LCH 空间里叠加菲涅尔与眩光。
pub const LIQUID_GLASS_FRAGMENT: &str = include_str!("shaders/liquid_glass.frag.glsl");

/// Full-screen pass: one separable convolution tap row plus a colour matrix.
/// 全屏一趟：一行可分离卷积加上一个颜色矩阵。
///
/// `u_dir` picks the axis, so the same program runs the horizontal and the vertical pass;
/// `u_color` is the category's second operation, applied after the convolution.
/// `u_dir` 选择方向，因此同一个程序跑横向与纵向两趟；`u_color` 是类别的第二个操作，
/// 在卷积之后应用。
pub const EFFECT_FRAGMENT: &str = include_str!("shaders/effect.frag.glsl");

/// Full-screen pass: one sliding-window box average along `u_dir`.
/// 全屏一趟：沿 `u_dir` 的一趟滑动窗口箱式平均。
///
/// GLSL cannot carry a running sum across pixels, so the window is summed per fragment.
/// The cost is therefore O(radius) in the shader rather than O(1); three such passes still
/// beat an explicit 85-tap kernel and, more importantly, are not limited by `u_weights`.
/// GLSL 无法跨像素携带运行和，因此窗口在每个片元内求和。着色器里的代价是 O(radius)
/// 而非 O(1)；但三趟仍优于显式 85-tap 核，更重要的是不受 `u_weights` 长度限制。
pub const BOX_FRAGMENT: &str = include_str!("shaders/box.frag.glsl");

/// Fragment source with the shared clip block spliced in after `precision`.
/// 把共享裁剪块插到 `precision` 之后的片元源串。
///
/// `precision` must come first: GLSL ES fragment shaders have no default float precision.
/// `precision` 必须最先出现：GLSL ES 片元着色器没有默认 float 精度。
pub(crate) fn splice(body: &str, block: &str) -> String {
    body.replacen(
        "precision highp float;",
        &format!("precision highp float;\n{block}"),
        1,
    )
}

fn with_clip(body: &str) -> String {
    splice(body, CLIP_GLSL)
}

fn with_coverage(body: &str) -> String {
    splice(body, COVERAGE_GLSL)
}

fn with_sdf(body: &str) -> String {
    splice(body, SDF_GLSL)
}

pub fn rect_fragment() -> String {
    with_sdf(&with_clip(RECT_FRAGMENT))
}

/// Floats per arc instance: centre, geometry, fill, caps.
/// 每段弧实例的浮点数：圆心、几何、填充、帽。
pub const SECTOR_STRIDE: i32 = 11;

pub const SECTOR_VERTEX: &str = include_str!("shaders/sector.vert.glsl");

pub const SECTOR_FRAGMENT: &str = include_str!("shaders/sector.frag.glsl");

pub fn sector_fragment() -> String {
    with_clip(SECTOR_FRAGMENT)
}

pub fn glyph_fragment() -> String {
    with_clip(GLYPH_FRAGMENT)
}

pub fn shadow_fragment() -> String {
    with_sdf(&with_clip(SHADOW_FRAGMENT))
}

pub fn image_fragment() -> String {
    with_sdf(&with_clip(IMAGE_FRAGMENT))
}

pub fn layer_fragment() -> String {
    with_coverage(LAYER_FRAGMENT)
}

pub fn acrylic_fragment() -> String {
    with_coverage(ACRYLIC_FRAGMENT)
}

pub fn liquid_glass_fragment() -> String {
    with_coverage(&with_sdf(LIQUID_GLASS_FRAGMENT))
}

/// Output transform: sRGB-encoded premultiplied in, PQ-encoded premultiplied out.
/// 输出变换：输入是 sRGB 编码的预乘值，输出是 PQ 编码的预乘值。
pub const OUTPUT_FRAGMENT: &str = include_str!("shaders/output.frag.glsl");

/// Supersample resolve: the N×N box average one destination pixel covers.
/// 超采样解析：一个目标像素覆盖的 N×N 箱式平均。
pub const RESOLVE_FRAGMENT: &str = include_str!("shaders/resolve.frag.glsl");

/// The lens's own backdrop capture: one region of the frame, resampled into its own texture.
/// 透镜自己的背景捕获：把帧中的一个区域重采进它自己的纹理。
pub const CAPTURE_FRAGMENT: &str = include_str!("shaders/capture.frag.glsl");
