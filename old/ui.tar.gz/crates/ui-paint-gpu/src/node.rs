//! Pick the GPU that drives a connected output.
//! 选择驱动已连接输出的那块 GPU。

use std::path::{Path, PathBuf};

/// The GPU behind a connected output, e.g. `/dev/dri/renderD129`.
/// 已连接输出背后的 GPU，例如 `/dev/dri/renderD129`。
///
/// Zero-copy only works when the GPU that renders is the one the compositor
/// scans out from: rendering on the other device yields a buffer the compositor
/// imports successfully but shows as black.
/// 只有渲染 GPU 与 compositor 扫描输出的 GPU 一致，零拷贝才成立：
/// 在另一块设备上渲染，compositor 能成功导入缓冲，但显示为黑。
pub fn output_render_node() -> Option<String> {
    let mut renders: Vec<(String, PathBuf)> = Vec::new();
    let mut connected: Vec<PathBuf> = Vec::new();
    for entry in std::fs::read_dir("/sys/class/drm").ok()?.flatten() {
        let path = entry.path();
        let Some(name) = path.file_name().and_then(|n| n.to_str()) else {
            continue;
        };
        if let Some(rest) = name.strip_prefix("renderD") {
            if rest.chars().all(|c| c.is_ascii_digit())
                && let Ok(dev) = std::fs::canonicalize(path.join("device")) {
                    renders.push((format!("/dev/dri/{name}"), dev));
                }
        } else if name.starts_with("card") && !name.contains('-') {
            let has_port = std::fs::read_dir(&path).ok().is_some_and(|entries| {
                entries.flatten().any(|connector| {
                    let connector = connector.path();
                    let is_port = connector
                        .file_name()
                        .and_then(|n| n.to_str())
                        .is_some_and(|n| n.contains('-'));
                    is_port
                        && std::fs::read_to_string(connector.join("status"))
                            .is_ok_and(|s| s.trim() == "connected")
                })
            });
            if has_port
                && let Ok(dev) = std::fs::canonicalize(path.join("device")) {
                    connected.push(dev);
                }
        }
    }
    renders
        .into_iter()
        .find(|(_, dev)| connected.contains(dev))
        .map(|(node, _)| node)
}

/// Candidate render nodes, most likely first.
/// 候选 render 节点，最可能的在前。
pub fn candidate_nodes() -> Vec<String> {
    let mut nodes = Vec::new();
    if let Some(node) = output_render_node() {
        nodes.push(node);
    }
    for fallback in ["/dev/dri/renderD128", "/dev/dri/renderD129"] {
        if Path::new(fallback).exists() && !nodes.iter().any(|n| n == fallback) {
            nodes.push(fallback.to_string());
        }
    }
    nodes
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn candidate_nodes_are_unique_and_exist() {
        let nodes = candidate_nodes();
        let mut seen = nodes.clone();
        seen.sort();
        seen.dedup();
        assert_eq!(seen.len(), nodes.len(), "duplicate candidate node");
        for node in &nodes {
            assert!(Path::new(node).exists(), "{node} was listed but does not exist");
        }
    }
}
