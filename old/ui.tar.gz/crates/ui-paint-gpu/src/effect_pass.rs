//! Full-screen passes that turn an effect chain into pixels.
//! 把效果链变成像素的全屏趟。
//!
//! The renderer has no `match` on effect kinds: a pass is a separable convolution plus a
//! colour matrix, and every effect is expressed with those two.
//! 渲染器不对效果种类做 `match`：一趟就是可分离卷积加一个颜色矩阵，
//! 所有效果都由这两者表达。

use glow::HasContext;
use ui_core::effect::{ColorMatrix, Effect};

use crate::renderer::{LayerTarget, Program};
use crate::shader;
use crate::GpuError;

/// Create or resize one ping-pong slot, returning its framebuffer and texture.
/// 创建或调整一个乒乓槽，返回其帧缓冲与纹理。
/// Storage precision of an internal render target.
/// 内部渲染目标的存储精度。
///
/// This is a property of the *pipeline*, not of the presented buffer: an f16 frame
/// keeps gradients and blurred edges from quantising before they reach the output.
/// 这是**管线**的属性，不是被呈现缓冲的属性：f16 帧让渐变与模糊边缘在到达输出前
/// 不发生量化。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TargetFormat {
    Rgba8,
    Rgba16F,
}

impl TargetFormat {
    pub(crate) fn internal(self) -> i32 {
        match self {
            TargetFormat::Rgba8 => glow::RGBA8 as i32,
            TargetFormat::Rgba16F => glow::RGBA16F as i32,
        }
    }
    /// Bytes per pixel, for sizing readbacks and expectations in tests.
    /// 每像素字节数，用于估算读回与测试期望。
    pub fn bytes_per_pixel(self) -> u32 {
        match self {
            TargetFormat::Rgba8 => 4,
            TargetFormat::Rgba16F => 8,
        }
    }
}

pub(crate) fn ensure_target(
    slot: &mut Option<LayerTarget>,
    gl: &glow::Context,
    width: u32,
    height: u32,
    format: TargetFormat,
) -> Result<(glow::Framebuffer, glow::Texture), GpuError> {
    if slot.is_none() {
        // A new target carries no storage; the resize branch below allocates it.
        // 新目标不带存储，由下面的调整分支分配。
        *slot = Some(new_target(gl)?);
    }
    let target = slot.as_mut().expect("just created");
    if target.width != width || target.height != height || target.format != format {
        resize_target(gl, target, width, height, format);
    }
    Ok((target.fbo, target.tex))
}

/// A render target the backdrop path will sample: linear, so a warp may land between texels.
/// 背景路径要取样的渲染目标：线性过滤，扭曲因此能落在纹素之间。
pub(crate) fn new_target(gl: &glow::Context) -> Result<LayerTarget, GpuError> {
    let tex = unsafe { gl.create_texture()? };
    let fbo = unsafe { gl.create_framebuffer()? };
    unsafe {
        gl.bind_texture(glow::TEXTURE_2D, Some(tex));
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_MIN_FILTER, glow::LINEAR as i32);
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_MAG_FILTER, glow::LINEAR as i32);
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_WRAP_S, glow::CLAMP_TO_EDGE as i32);
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_WRAP_T, glow::CLAMP_TO_EDGE as i32);
        gl.bind_framebuffer(glow::FRAMEBUFFER, Some(fbo));
        gl.framebuffer_texture_2d(
            glow::FRAMEBUFFER,
            glow::COLOR_ATTACHMENT0,
            glow::TEXTURE_2D,
            Some(tex),
            0,
        );
        gl.bind_framebuffer(glow::FRAMEBUFFER, None);
    }
    Ok(LayerTarget {
        fbo,
        tex,
        width: 0,
        height: 0,
        format: TargetFormat::Rgba8,
    })
}

/// (Re)allocate storage; the filtering `new_target` set outlives it, as the spec requires.
/// （重新）分配存储；`new_target` 设好的过滤状态按规范在其后依然有效。
pub(crate) fn resize_target(
    gl: &glow::Context,
    target: &mut LayerTarget,
    width: u32,
    height: u32,
    format: TargetFormat,
) {
    unsafe {
        gl.bind_texture(glow::TEXTURE_2D, Some(target.tex));
        gl.tex_image_2d(
            glow::TEXTURE_2D,
            0,
            format.internal(),
            width as i32,
            height as i32,
            0,
            glow::RGBA,
            glow::UNSIGNED_BYTE,
            glow::PixelUnpackData::Slice(None),
        );
        // The reallocation drops the mip chain, and a mipmap filter over a missing chain makes
        // the texture incomplete: every read returns black.
        // 重分配会丢掉 mip 链，而需要 mip 的过滤配着缺失的链会让纹理不完整：每次读取都返回黑色。
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_MIN_FILTER, glow::LINEAR as i32);
    }
    target.width = width;
    target.height = height;
    target.format = format;
}

/// Run one sliding-window box average from `src` into `dest`.
/// 从 `src` 到 `dest` 跑一趟滑动窗口箱式平均。
#[allow(clippy::too_many_arguments)]
fn box_pass(
    gl: &glow::Context,
    program: &Program,
    dest: (glow::Framebuffer, glow::Texture),
    src: glow::Texture,
    width: u32,
    height: u32,
    dir: [f32; 2],
    radius: u32,
    scissor: [i32; 4],
) -> Result<(), GpuError> {
    let m = ColorMatrix::IDENTITY.0;
    let mut column_major = [0.0f32; 16];
    for row in 0..4 {
        for col in 0..4 {
            column_major[col * 4 + row] = m[row * 4 + col];
        }
    }
    unsafe {
        gl.bind_framebuffer(glow::FRAMEBUFFER, Some(dest.0));
        gl.viewport(0, 0, width as i32, height as i32);
        gl.enable(glow::SCISSOR_TEST);
        gl.scissor(scissor[0], scissor[1], scissor[2], scissor[3]);
        gl.use_program(Some(program.program));
        if let Some(u) = program.uniforms.viewport {
            gl.uniform_2_f32(Some(&u), width as f32, height as f32);
        }
        if let Some(u) = program.uniforms.src {
            gl.active_texture(glow::TEXTURE0);
            gl.bind_texture(glow::TEXTURE_2D, Some(src));
            gl.uniform_1_i32(Some(&u), 0);
        }
        if let Some(u) = program.uniforms.texel {
            gl.uniform_2_f32(Some(&u), 1.0 / width as f32, 1.0 / height as f32);
        }
        if let Some(u) = program.uniforms.dir {
            gl.uniform_2_f32(Some(&u), dir[0], dir[1]);
        }
        if let Some(u) = program.uniforms.radius {
            gl.uniform_1_i32(Some(&u), radius as i32);
        }
        if let Some(u) = program.uniforms.color {
            gl.uniform_matrix_4_f32_slice(Some(&u), false, &column_major);
        }
        let rect = [0.0f32, 0.0, width as f32, height as f32];
        gl.bind_vertex_array(Some(program.vao));
        gl.bind_buffer(glow::ARRAY_BUFFER, Some(program.instance_vbo));
        gl.buffer_data_u8_slice(
            glow::ARRAY_BUFFER,
            crate::renderer::as_bytes(&rect),
            glow::DYNAMIC_DRAW,
        );
        gl.draw_arrays_instanced(glow::TRIANGLES, 0, shader::UNIT_QUAD.len() as i32 / 2, 1);
    }
    Ok(())
}

/// Run one full-screen convolution/colour pass from `src` into `dest`.
/// 从 `src` 到 `dest` 跑一趟全屏卷积/颜色变换。
#[allow(clippy::too_many_arguments)]
fn effect_pass(
    gl: &glow::Context,
    program: &Program,
    dest: (glow::Framebuffer, glow::Texture),
    src: glow::Texture,
    width: u32,
    height: u32,
    dir: [f32; 2],
    weights: &[f32],
    color: &ColorMatrix,
    scissor: [i32; 4],
) -> Result<(), GpuError> {
    // Row-major on our side, column-major in GLSL: transpose here rather than rely on
    // `transpose = true`, which GLES rejects.
    // 我们这边是行主序、GLSL 是列主序：在此手工转置，而不是依赖 GLES 会拒绝的 `transpose`。
    let m = color.0;
    let mut column_major = [0.0f32; 16];
    for row in 0..4 {
        for col in 0..4 {
            column_major[col * 4 + row] = m[row * 4 + col];
        }
    }

    unsafe {
        gl.bind_framebuffer(glow::FRAMEBUFFER, Some(dest.0));
        gl.viewport(0, 0, width as i32, height as i32);
        // Only the layer's own region is worth filtering; the rest is transparent.
        // 只有层自己的区域值得滤波，其余都是透明的。
        gl.enable(glow::SCISSOR_TEST);
        gl.scissor(scissor[0], scissor[1], scissor[2], scissor[3]);
        gl.use_program(Some(program.program));
        if let Some(u) = program.uniforms.viewport {
            gl.uniform_2_f32(Some(&u), width as f32, height as f32);
        }
        if let Some(u) = program.uniforms.src {
            gl.active_texture(glow::TEXTURE0);
            gl.bind_texture(glow::TEXTURE_2D, Some(src));
            gl.uniform_1_i32(Some(&u), 0);
        }
        if let Some(u) = program.uniforms.texel {
            gl.uniform_2_f32(Some(&u), 1.0 / width as f32, 1.0 / height as f32);
        }
        if let Some(u) = program.uniforms.dir {
            gl.uniform_2_f32(Some(&u), dir[0], dir[1]);
        }
        // The shader declares `u_weights[33]`; uploading more silently drops the tail and
        // leaves the kernel un-normalized, which dims the image instead of blurring it.
        // 着色器声明 `u_weights[33]`；多上传的部分会被静默丢弃，核因此不再归一化，
        // 结果是画面整体变暗而不是模糊。
        let taps = weights.len().min(crate::shader::MAX_TAPS as usize);
        let weights = &weights[..taps];
        if let Some(u) = program.uniforms.taps {
            gl.uniform_1_i32(Some(&u), weights.len() as i32);
        }
        if let Some(u) = program.uniforms.weights {
            gl.uniform_1_f32_slice(Some(&u), weights);
        }
        if let Some(u) = program.uniforms.color {
            gl.uniform_matrix_4_f32_slice(Some(&u), false, &column_major);
        }
        let rect = [0.0f32, 0.0, width as f32, height as f32];
        gl.bind_vertex_array(Some(program.vao));
        gl.bind_buffer(glow::ARRAY_BUFFER, Some(program.instance_vbo));
        gl.buffer_data_u8_slice(
            glow::ARRAY_BUFFER,
            crate::renderer::as_bytes(&rect),
            glow::DYNAMIC_DRAW,
        );
        gl.draw_arrays_instanced(glow::TRIANGLES, 0, shader::UNIT_QUAD.len() as i32 / 2, 1);
    }
    Ok(())
}

/// Targets kept alive across frames purely as scratch space: the ping-pong textures the
/// passes write into. They hold nothing meaningful between frames — every call recomputes
/// `src -> output` in full, which is what Flutter/Skia/Haze all do. Reusing filtered pixels
/// across frames was tried and removed (docs/effect-cache-plan.md §11): every bookkeeping
/// variant produced a new flavour of "edges show an old frame".
/// 仅作乒乓暂存用途跨帧保留的纹理：各趟写进去的中间目标。帧与帧之间它们不含任何有意义内容
/// ——每次调用都从 `src` 全量重算到输出，这正是 Flutter/Skia/Haze 的做法。跨帧复用滤波像素
/// 曾实现过并已撤除（docs/effect-cache-plan.md §11）：每种记账变体都会造出新一类
/// 「边缘显示旧帧」的 bug。
#[derive(Default)]
pub(crate) struct Scratch {
    /// Filtered image; compositing reads this.
    /// 滤波后的图；合成读的就是它。
    pub output: Option<LayerTarget>,
    /// Intermediate of the horizontal pass only.
    /// 仅横向趟的中间结果。
    pub scratch: Option<LayerTarget>,
    /// Second intermediate, so a multi-pass chain never reads a target it writes.
    /// 第二个中间结果，使多趟链路永远不会读到它正在写的那个目标。
    pub band: Option<LayerTarget>,
}

/// Give `tex` a mip chain and let it be filtered across levels: the lens compresses tens of
/// texels into one pixel, and only the chain can average that footprint.
/// 给 `tex` 生成 mip 链并允许跨级过滤：透镜把几十个纹素压进一个像素，只有 mip 链能平均这片足迹。
fn enable_mips(gl: &glow::Context, tex: glow::Texture) {
    unsafe {
        gl.bind_texture(glow::TEXTURE_2D, Some(tex));
        gl.tex_parameter_i32(
            glow::TEXTURE_2D,
            glow::TEXTURE_MIN_FILTER,
            glow::LINEAR_MIPMAP_LINEAR as i32,
        );
        gl.generate_mipmap(glow::TEXTURE_2D);
    }
}

/// Drop back to single-level filtering: target textures are shared between effects, so one
/// that stops needing mips must not keep reading a chain nobody regenerates.
/// 退回单层过滤：目标纹理在效果之间共用，不再需要 mip 的那个不能继续读一条没人重生成的链。
fn disable_mips(gl: &glow::Context, tex: glow::Texture) {
    unsafe {
        gl.bind_texture(glow::TEXTURE_2D, Some(tex));
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_MIN_FILTER, glow::LINEAR as i32);
    }
}

/// Apply the whole `effects` chain over `src` into `scratch`, recomputing every pixel.
/// 把整条 `effects` 链在 `src` 上应用进 `scratch`，每个像素都重新计算。
#[allow(clippy::too_many_arguments)]
/// The same effect on the render grid: kernels are authored per logical dp, scale widens them.
/// 同一效果在渲染网格上的样子：核按逻辑 dp 撰写，`scale` 把它按比例放大。
pub(crate) fn on_grid(effect: Effect, scale: f32) -> Effect {
    // Scale one is the authored grid; rebuilding a kernel there would only re-round it.
    // 倍率为一时就是作者所在的网格；重建核只会把它重新取整一次。
    if scale == 1.0 {
        return effect;
    }
    let kernel = effect.kernel.clone();
    let scaled = if kernel.boxes > 0 {
        Effect::box_blur(kernel.sigma * scale)
    } else if kernel.is_identity() {
        return effect;
    } else {
        Effect::blur(
            (kernel.radius as f32 * scale).round() as u32,
            kernel.sigma * scale,
        )
    };
    Effect {
        color: effect.color,
        ..scaled
    }
}

pub(crate) fn run(
    scratch: &mut Scratch,
    gl: &glow::Context,
    program: &Program,
    boxpass: &Program,
    src: glow::Texture,
    width: u32,
    height: u32,
    bounds: ui_core::geom::Rect,
    format: TargetFormat,
    effects: &[Effect],
    mips: bool,
) -> Result<glow::Texture, GpuError> {
    if effects.is_empty() {
        return Ok(src);
    }
    // A zero-radius blur is a chain of full-frame copies that change nothing; a lens that
    // frosts nothing must not pay for six passes over the frame.
    // 零半径模糊是一串什么都不改的全帧拷贝：不磨砂的透镜不该为此付六趟全帧的代价。
    if !mips && effects.iter().all(|e| e.is_noop()) {
        return Ok(src);
    }
    let dest = ensure_target(&mut scratch.output, gl, width, height, format)?;
    let to_i32 = |r: ui_core::geom::Rect| crate::renderer::device_scissor(r, 1.0);
    // Filtering and compositing stop at the layer bounds; the rest must stay transparent.
    // The destination is cleared first: a shrunk layer must not keep texels outside `bounds`.
    // 滤波与合成止于层边界，其余保持透明。目标先清空：层缩小时不得留下 `bounds` 外的纹素。
    let area = to_i32(bounds);
    unsafe {
        gl.disable(glow::BLEND);
        gl.bind_framebuffer(glow::FRAMEBUFFER, Some(dest.0));
        gl.enable(glow::SCISSOR_TEST);
        gl.scissor(area[0], area[1], area[2], area[3]);
        gl.clear_color(0.0, 0.0, 0.0, 0.0);
        gl.clear(glow::COLOR_BUFFER_BIT);
    }
    const UNIT: [f32; 1] = [1.0];
    for effect in effects {
        if effect.is_box() {
            // Six passes h,v,h,v,h,v alternate two targets, so no pass samples its output.
            // Each pass covers the whole bounds: with full recomputation there is no
            // "region no earlier pass wrote this frame" for a pass to read.
            // 六趟 h,v,h,v,h,v 在两个目标间交替，没有一趟会采样自己的输出。
            // 每趟覆盖整个边界：全量重算之下，不存在「本帧没有前趟写过这块区域」可读的问题。
            let passes = effect.kernel.boxes.max(1) as usize * 2;
            let mut from = src;
            for pass in 0..passes {
                let horizontal = pass % 2 == 0;
                let dir = if horizontal { [1.0, 0.0] } else { [0.0, 1.0] };
                let last = pass + 1 == passes;
                // Alternate two intermediates: a pass must never read the target it writes.
                // 在两个中间目标间交替：任何一趟都不得读写同一目标。
                let slot = if pass % 2 == 0 { &mut scratch.scratch } else { &mut scratch.band };
                let out = if last {
                    dest
                } else {
                    ensure_target(slot, gl, width, height, format)?
                };
                // Writing into the last destination must blend nothing: the pass replaces it.
                // 写最后一个目标时不得混合：这一趟就是替换它。
                box_pass(
                    gl, boxpass, out, from, width, height, dir,
                    effect.kernel.radius, area,
                )?;
                from = out.1;
            }
        } else if !effect.kernel.is_identity() {
            let mid = ensure_target(&mut scratch.scratch, gl, width, height, format)?;
            effect_pass(
                gl, program, mid, src, width, height, [1.0, 0.0],
                &effect.kernel.weights[..], &ColorMatrix::IDENTITY,
                area,
            )?;
            effect_pass(
                gl, program, dest, mid.1, width, height, [0.0, 1.0],
                &effect.kernel.weights[..], &effect.color,
                area,
            )?;
        } else if !effect.color.is_identity() {
            effect_pass(
                gl, program, dest, src, width, height, [0.0, 0.0],
                &UNIT[..], &effect.color,
                area,
            )?;
        }
    }
    unsafe { gl.enable(glow::BLEND) };
    if mips {
        enable_mips(gl, dest.1);
    } else {
        disable_mips(gl, dest.1);
    }
    Ok(dest.1)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A blur declared per logical dp keeps its visual radius on a finer grid.
    /// 按逻辑 dp 声明的模糊在更细的网格上保持视觉半径。
    #[test]
    fn a_blur_widens_with_the_render_grid() {
        let plain = Effect::box_blur(2.0);
        let dense = on_grid(plain.clone(), 2.0);
        assert!(
            (dense.kernel.sigma - 2.0 * plain.kernel.sigma).abs() < 0.6,
            "sigma tracks the grid: {} vs {}",
            plain.kernel.sigma,
            dense.kernel.sigma
        );
        let taps = Effect::blur(4, 1.5);
        let wide = on_grid(taps.clone(), 2.0);
        assert_eq!(wide.kernel.radius, 8, "a tap-limited kernel widens too");
        assert_eq!(wide.kernel.sigma, 3.0);
        assert_eq!(on_grid(taps, 1.0).kernel.radius, 4, "scale one is a no-op");
    }
}
