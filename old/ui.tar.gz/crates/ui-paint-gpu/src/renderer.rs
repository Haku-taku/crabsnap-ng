//! Draws a `ui_core::DrawList` with OpenGL ES.
//! 用 OpenGL ES 绘制 `ui_core::DrawList`。
//!
//! Rectangles use an instanced signed-distance shader; glyphs sample a coverage
//! atlas. Both emit premultiplied alpha so one blend equation covers both.
//! 矩形用实例化的有符号距离着色器；字形采样覆盖率图集。两者都输出预乘 alpha，
//! 因此一个混合方程即可覆盖两者。

use glow::HasContext;
use std::collections::{HashMap, HashSet};
use ui_core::draw::{DrawList, GlyphPrim, ImageEntry, ImagePrim, PrimKind, RectPrim, ShadowPrim};
use ui_core::effect::Effect;
use ui_core::geom::Color;

use crate::material::BackdropMaterial;

/// Which program shades a blurred backdrop.
/// 用哪个程序给模糊后的背景着色。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum Shade {
    Plain,
    Acrylic,
    /// LiquidGlassKit's material: the one glass program.
    /// LiquidGlassKit 的材质：唯一的玻璃程序。
    Liquid,
}

/// Which material a backdrop entry is shaded with: its own if it names one, else the
/// renderer-wide default.
/// 背景条目用哪种材质着色：自己指定的优先，否则用渲染器级的默认值。
pub(crate) fn resolve(
    entry: BackdropMaterial,
    default: Option<BackdropMaterial>,
) -> Option<BackdropMaterial> {
    match entry {
        BackdropMaterial::Plain => default,
        named => Some(named),
    }
}

impl Shade {
    /// The plain blit is the fallback for "no material" and for an explicit `Plain`.
    /// 纯写回既是「没有材质」的退路，也是显式 `Plain` 的结果。
    pub(crate) fn of(material: Option<BackdropMaterial>) -> Self {
        match material {
            None | Some(BackdropMaterial::Plain) => Shade::Plain,
            Some(BackdropMaterial::Acrylic(_)) => Shade::Acrylic,
            Some(BackdropMaterial::LiquidGlass(_)) => Shade::Liquid,
        }
    }
}
/// Whether a backdrop entry has to run the composite pass. A plain blit only changes the
/// frame when the blur did; a shaded material is all there is to draw.
/// 背景条目是否必须跑合成趟。纯写回只在模糊改动了帧时才有效果；有着色的材质本身就是内容。
pub(crate) fn composites(material: Option<BackdropMaterial>, blurred: bool) -> bool {
    blurred || !matches!(material, None | Some(BackdropMaterial::Plain))
}

use crate::shader;
use ui_gpu_egl::GpuSurface;
use crate::GpuError;

/// Fused shapes arrive in the node's logical space; the shader works in device pixels, so
/// each is offset by the node's origin and scaled once.
/// 融合形状以节点的逻辑坐标传入；着色器按设备像素工作，因此按节点原点偏移并统一缩放。
fn upload_shapes(
    gl: &glow::Context,
    p: &Program,
    blend: &[ui_core::draw::BlendShape],
    count: u8,
    device: ui_core::geom::Rect,
    s: f32,
) {
    if count == 0 {
        return;
    }
    let mut boxes = [0.0f32; 16];
    let mut radii = [0.0f32; 16];
    for (i, shape) in blend.iter().take(count as usize).enumerate() {
        let hw = shape.rect.size.w.abs() * 0.5 * s;
        let hh = shape.rect.size.h.abs() * 0.5 * s;
        boxes[i * 4] = device.origin.x + shape.rect.origin.x * s + hw;
        boxes[i * 4 + 1] = device.origin.y + shape.rect.origin.y * s + hh;
        boxes[i * 4 + 2] = hw;
        boxes[i * 4 + 3] = hh;
        let cap = hw.min(hh);
        radii[i * 4] = (shape.corners.tl * s).min(cap);
        radii[i * 4 + 1] = (shape.corners.tr * s).min(cap);
        radii[i * 4 + 2] = (shape.corners.br * s).min(cap);
        radii[i * 4 + 3] = (shape.corners.bl * s).min(cap);
    }
    if let Some(u) = p.uniforms.shapes {
        unsafe { gl.uniform_4_f32_slice(Some(&u), &boxes) };
    }
    if let Some(u) = p.uniforms.shape_radius {
        unsafe { gl.uniform_4_f32_slice(Some(&u), &radii) };
    }
}

/// Counters for one frame.
/// 单帧的计数器。
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct RenderStats {
    pub rects: u32,
    pub glyphs: u32,
    pub draw_calls: u32,
    /// Frosts executed this frame.
    /// 本帧执行的磨砂次数。
    pub frosts: u32,
    /// Backdrop passes that also shaded a material (acrylic or glass) after the blur.
    /// 模糊之后又跑了材质（acrylic 或玻璃）的背景趟数。
    pub material_passes: u32,
    /// Image textures uploaded this frame; a cached `ImageEntry::id` does not count.
    /// 本帧上传的图像纹理数；命中缓存的 `ImageEntry::id` 不计。
    pub image_uploads: u32,
    /// Soft shadows drawn this frame.
    /// 本帧绘制的柔和阴影数。
    pub shadows_drawn: u32,
    /// Image primitives drawn this frame.
    /// 本帧绘制的图像图元数。
    pub images_drawn: u32,
    /// Batches skipped because the cached subtree they belong to did not change.
    /// 因所属缓存子树未变化而跳过的批次数。
    pub cached_skips: u32,
    /// Batches skipped because they miss the redraw band and could write no pixel.
    /// 因不与重绘带相交、写不了任何像素而跳过的批次数。
    pub band_culls: u32,
    /// The device rect this frame redrew, or `None` when it redrew everything.
    /// 本帧重绘的设备矩形；`None` 表示重画了整面。
    pub band: Option<[i32; 4]>,
}

/// A coverage atlas uploaded to the GPU.
/// 已上传到 GPU 的覆盖率图集。
pub struct AtlasUpload {
    pub width: u32,
    pub height: u32,
    /// Single-channel coverage.
    /// 单通道覆盖率。
    pub data: Vec<u8>,
}

pub(crate) struct Program {
    pub(crate) program: glow::Program,
    pub(crate) vao: glow::VertexArray,
    unit_vbo: glow::Buffer,
    pub(crate) instance_vbo: glow::Buffer,
    pub(crate) uniforms: Uniforms,
}

pub(crate) struct Uniforms {
    pub(crate) viewport: Option<glow::UniformLocation>,
    atlas_size: Option<glow::UniformLocation>,
    atlas: Option<glow::UniformLocation>,
    color_atlas_size: Option<glow::UniformLocation>,
    color_atlas: Option<glow::UniformLocation>,
    image: Option<glow::UniformLocation>,
    opacity: Option<glow::UniformLocation>,
    /// Sampler name differs per program: glyphs use `u_atlas`, layers `u_layer`.
    /// 采样器名随程序不同：字形用 `u_atlas`，层用 `u_layer`。
    layer_tex: Option<glow::UniformLocation>,
    clip_rect: Option<glow::UniformLocation>,
    clip_radius: Option<glow::UniformLocation>,
    clip_shape: Option<glow::UniformLocation>,
    clip_on: Option<glow::UniformLocation>,
    /// Effect pass inputs; `None` for programs that do not run one.
    /// 效果趟的输入；不跑效果的程序为 `None`。
    pub(crate) src: Option<glow::UniformLocation>,
    pub(crate) texel: Option<glow::UniformLocation>,
    pub(crate) dir: Option<glow::UniformLocation>,
    pub(crate) taps: Option<glow::UniformLocation>,
    /// Sliding-window radius, used by the box program instead of `u_weights`.
    /// 滑动窗口半径，由箱式程序使用，代替 `u_weights`。
    pub(crate) radius: Option<glow::UniformLocation>,
    /// Supersample factor, used by the resolve program.
    /// 超采样倍数，由解析程序使用。
    pub(crate) supersample: Option<glow::UniformLocation>,
    /// The lens capture in device pixels, read by the kit shader; the capture pass takes the
    /// same region in frame uv under `u_region`.
    /// 透镜捕获（设备像素），由 kit 着色器读取；捕获趟以 `u_region` 收同一区域的帧 uv。
    pub(crate) capture: Option<glow::UniformLocation>,
    pub(crate) region: Option<glow::UniformLocation>,
    pub(crate) weights: Option<glow::UniformLocation>,
    pub(crate) color: Option<glow::UniformLocation>,
    /// Output transform inputs; `None` for programs that do not encode.
    /// 输出变换的输入；不编码的程序为 `None`。
    pub(crate) scale: Option<glow::UniformLocation>,
    pub(crate) offset: Option<glow::UniformLocation>,
    pub(crate) gamut: Option<glow::UniformLocation>,
    layer_rect: Option<glow::UniformLocation>,
    layer_radius: Option<glow::UniformLocation>,
    layer_exp: Option<glow::UniformLocation>,
    layer_skip_empty: Option<glow::UniformLocation>,
    /// Material uniforms; `None` for programs that shade no backdrop.
    /// 材质 uniform；不着色背景的程序为 `None`。
    tint: Option<glow::UniformLocation>,
    luminosity: Option<glow::UniformLocation>,
    noise: Option<glow::UniformLocation>,
    /// Glass: the neutral body transfer.
    /// 玻璃：中性本体变换。
    body: Option<glow::UniformLocation>,
    glass: Option<glow::UniformLocation>,
    light: Option<glow::UniformLocation>,
    /// Glass: refractive index, dispersion, thickness, capture density.
    /// 玻璃：折射率、色散、厚度、捕获密度。
    optical: Option<glow::UniformLocation>,
    /// Blend group: live shape count and smooth-union radius.
    /// 融合组：有效形状数与平滑并集半径。
    blend: Option<glow::UniformLocation>,
    /// Kit lens: Fresnel intensity, distance, sharpness, glare convergence.
    /// kit 透镜：菲涅尔强度、距离、锐度，眩光聚拢。
    kit: Option<glow::UniformLocation>,
    /// Blend group: each shape's centre and half size, device pixels.
    /// 融合组：每个形状的中心与半尺寸，设备像素。
    shapes: Option<glow::UniformLocation>,
    /// Blend group: each shape's four corner radii, device pixels.
    /// 融合组：每个形状的四个圆角半径，设备像素。
    shape_radius: Option<glow::UniformLocation>,
}

/// GPU painter.
/// GPU 绘制器。
/// One offscreen render target for a layer, reused across frames by depth.
/// 离屏层渲染目标，按深度跨帧复用。
pub(crate) struct LayerTarget {
    pub(crate) fbo: glow::Framebuffer,
    pub(crate) tex: glow::Texture,
    pub(crate) width: u32,
    pub(crate) height: u32,
    /// Storage precision, so a format change reallocates instead of silently reusing.
    /// 存储精度；格式变化时会重新分配而不是静默复用。
    pub(crate) format: crate::effect_pass::TargetFormat,
}

/// What every layer push has to know about the frame being drawn.
/// 每次压入层都需要知道的、关于本帧重画范围的信息。
struct FrameTargets<'a> {
    /// Regions that changed; a cached subtree outside them keeps its pixels.
    /// 变化的区域；其外的缓存子树保留原有像素。
    damage: &'a ui_core::damage::Damage,
    /// The redraw band in render pixels; `None` means the whole frame was cleared.
    /// 重绘带的渲染像素范围；`None` 表示整帧都清空过。
    band: Option<[i32; 4]>,
    viewport: (f32, f32),
}

/// What a popped layer needs to know to finish this frame.
/// 弹出层完成本帧时需要的选择。
#[derive(Clone, Copy)]
struct Finish {
    /// The subtree target to keep the pixels in, if this layer has one.
    /// 保留像素的子树目标；该层没有缓存时为 `None`。
    cache: Option<u64>,
    /// Nothing inside the layer was drawn: it kept the pixels of its last composite.
    /// 层内什么都没画：它保留了上一次合成图的像素。
    clean: bool,
    /// The parent region was repainted, so the layer has to be composited into it.
    /// 父级区域被重画过，因此该层必须合成进去。
    composite: bool,
}

/// The active target chain, and per level whether this frame needs it at all.
/// 活动目标链，以及每层在本帧是否需要处理。
#[derive(Default)]
struct Chain {
    stack: Vec<u32>,
    /// `true` when the level kept its pixels and neither it nor its parent needs work.
    /// 该层保留了像素、且它与其父级都无需处理时为 `true`。
    clean: Vec<bool>,
}

/// A device-space band as a rect.
/// 设备空间的重绘带转成矩形。
fn rect_of([x, y, w, h]: [i32; 4]) -> ui_core::geom::Rect {
    ui_core::geom::Rect::new(x as f32, y as f32, w as f32, h as f32)
}

/// The band as a device-space rect, for comparing against layer bounds.
/// 把重绘带表示为设备空间的矩形，以便与层边界比较。
fn band_rect(band: Option<[i32; 4]>) -> Option<ui_core::geom::Rect> {
    band.map(rect_of)
}

/// Whether this frame cleared the frame target over a device-space `bounds`.
/// 本帧是否清空过帧目标上 `bounds`（设备空间）所在的范围。
fn frame_cleared_over(band: Option<[i32; 4]>, bounds: Option<ui_core::geom::Rect>) -> bool {
    match band_rect(band) {
        None => true,
        Some(b) => bounds.is_none_or(|r| b.intersects(r)),
    }
}

/// A subtree target that outlives the frame, keyed by `LayerEntry::cache_key`.
/// 跨帧保留的子树目标，按 `LayerEntry::cache_key` 索引。
pub(crate) struct CachedTarget {
    pub(crate) target: LayerTarget,
    /// Whether `target` holds a finished composite of the subtree.
    /// `target` 中是否已有一张完成的子树合成图。
    pub(crate) valid: bool,
    /// Frame number this target was last asked for, so vanished canvases are freed.
    /// 最近一次被请求的帧号，用于释放已消失的画布。
    pub(crate) last_used: u64,
}

/// One cached image texture; `id` and size decide whether the upload is reused.
/// 一张缓存的图像纹理；`id` 与尺寸决定是否复用已有上传。
struct ImageTexture {
    tex: glow::Texture,
    width: u32,
    height: u32,
}

/// The texture one `ImagePrim` samples, resolved for the current frame.
/// 一个 `ImagePrim` 采样的纹理，已在本帧解析好。
#[derive(Clone, Copy)]
struct FrameImage {
    tex: glow::Texture,
    width: u32,
    height: u32,
}

pub struct GpuRenderer {
    rects: Program,
    /// Stroked circular arcs, shaped analytically in the fragment.
    /// 描边圆弧，在片元中解析成形。
    sectors: Program,
    glyphs: Program,
    /// Rounded-rect texture sampling, one draw per run of primitives sharing a texture.
    /// 圆角矩形纹理采样，每段共享同一纹理的图元一次绘制。
    images: Program,
    /// Analytic soft shadows; no blur pass, so a shadow costs one draw.
    /// 解析柔和阴影；无模糊趟，因此一个阴影只花一次绘制。
    shadows: Program,
    layers: Program,
    /// Full-screen pass shared by every effect in the chain.
    /// 效果链中每个效果共用的全屏趟。
    effects: Program,
    /// Output transform into PQ, used only when HDR is declared.
    /// 输出变换为 PQ，仅在声明 HDR 时使用。
    output: Program,
    /// Box average from the supersampled frame down to the presented buffer.
    /// 从超采样帧到呈现缓冲的箱式平均。
    resolve: Program,
    resolve_scratch: Option<LayerTarget>,
    /// Resample one region of the frame into a lens's own capture.
    /// 把帧的一个区域重采进透镜自己的捕获。
    capture: Program,
    capture_target: Option<LayerTarget>,
    /// Rendering resolution multiplier: every internal target is `ss²` times the surface.
    /// 渲染分辨率倍数：所有内部目标是表面的 `ss²` 倍。
    supersample: u32,
    /// (scale, offset) for the PQ output transform; `None` keeps the buffer as sRGB.
    /// PQ 输出变换的（缩放、偏移）；`None` 表示缓冲保持 sRGB。
    hdr: Option<[f32; 2]>,
    /// Internal storage precision for the frame and every layer target.
    /// 帧与所有层目标的内部存储精度。
    target_format: crate::effect_pass::TargetFormat,
    /// sRGB -> output gamut, row-major; identity until a description is read.
    /// sRGB -> 输出色域，行主序；读到描述前是单位矩阵。
    gamut: [[f32; 3]; 3],
    output_scratch: Option<LayerTarget>,
    /// Device-space bounds per nesting depth: the only region worth filtering or compositing.
    /// 每层嵌套深度的设备空间边界：唯一值得滤波与合成的区域。
    layer_bounds: Vec<ui_core::geom::Rect>,
    /// Device-space corner radii per depth, mirroring `layer_bounds`.
    /// 每层深度的设备空间圆角半径，与 `layer_bounds` 对应。
    layer_radius: Vec<ui_core::geom::Corners>,
    /// Persistent frame buffer: the target rotates, so the accumulated frame lives here.
    /// 持久帧缓冲：目标会轮转，因此累积的画面放在这里。
    frame: Option<LayerTarget>,
    /// Root of the active layer chain; `end_layer` composites depth 0 here.
    /// 当前层链的根；`end_layer` 把深度 0 合成到这里。
    root_fbo: Option<glow::Framebuffer>,
    /// Domain every intermediate is allocated in; follows the output description.
    /// 所有中间产物分配时所用的域；跟随输出描述。
    working: ui_core::colour::Encoding,
    /// Ping-pong scratch per nesting depth. These hold no meaningful content between
    /// frames: each frame recomputes every stage from the live scene.
    /// 每个嵌套深度的乒乓暂存。帧间不含任何有意义内容：每帧都从当帧场景重算每个阶段。
    effect_scratch: Vec<crate::effect_pass::Scratch>,
    /// Sliding-window box pass, used for blurs whose radius exceeds the kernel array.
    /// 滑动窗口箱式趟，用于半径超出核数组长度的模糊。
    boxpass: Program,
    /// Acrylic composite over the blurred backdrop.
    /// 模糊背景之上的 acrylic 合成。
    acrylic: Program,
    /// LiquidGlassKit's material: the captured face and the thin-prism rim.
    /// LiquidGlassKit 的材质：捕获的面与薄棱镜边缘。
    glass_kit: Program,
    /// Style-level backdrop material; `None` keeps the plain blur blit.
    /// 风格级背景材质；`None` 保留纯模糊写回。
    material: Option<BackdropMaterial>,
    /// Scratch for backdrop blurs; kept apart from the layer scratch so a frost and a
    /// layer effect in the same frame cannot overwrite each other's intermediates.
    /// 背景模糊的暂存；与层暂存分开，使同帧的磨砂与层效果不会互相覆盖中间结果。
    backdrop_scratch: crate::effect_pass::Scratch,
    /// Offscreen targets indexed by nesting depth.
    /// 按嵌套深度索引的离屏目标。
    layer_targets: Vec<LayerTarget>,
    /// Subtree targets that persist across frames, keyed by the layer's cache key.
    /// 跨帧保留的子树目标，按层的缓存键索引。
    cached_targets: HashMap<u64, CachedTarget>,
    /// Frame counter, so a canvas absent this frame can be freed.
    /// 帧计数，用于释放本帧已缺席的画布。
    frame_serial: u64,
    atlas_tex: Option<glow::Texture>,
    atlas_size: (u32, u32),
    color_atlas_tex: Option<glow::Texture>,
    color_atlas_size: (u32, u32),
    /// Uploaded image textures keyed by `ImageEntry::id`; ids absent from a frame are freed.
    /// 按 `ImageEntry::id` 缓存的图像纹理；某帧不再出现的 id 会被释放。
    image_textures: HashMap<u64, ImageTexture>,
    /// Textures resolved for the frame being drawn, parallel to `DrawList::images`.
    /// 正在绘制的那一帧解析出的纹理，与 `DrawList::images` 平行。
    frame_images: Vec<FrameImage>,
    scale: f32,
    stats: RenderStats,
}

impl GpuRenderer {
    /// Compile both programs and set up vertex arrays.
    /// 编译两个程序并配置顶点数组。
    pub fn new(gl: &glow::Context, is_gles: bool) -> Result<Self, GpuError> {
                let layers = Program::new(
            gl,
            is_gles,
            shader::LAYER_VERTEX,
            &shader::layer_fragment(),
            shader::RECT_STRIDE,
            &[("a_rect", 4)],
            &[
                "u_viewport",
                "u_opacity",
                "u_layer",
                "u_rect",
                "u_radius",
                "u_exp",
                "u_skip_empty",
            ],
        )?;
        let effects = Program::new(
            gl,
            is_gles,
            shader::LAYER_VERTEX,
            shader::EFFECT_FRAGMENT,
            shader::RECT_STRIDE,
            &[("a_rect", 4)],
            &["u_viewport", "u_src", "u_texel", "u_dir", "u_taps", "u_weights", "u_color"],
        )?;
        let boxpass = Program::new(
            gl,
            is_gles,
            shader::LAYER_VERTEX,
            shader::BOX_FRAGMENT,
            shader::RECT_STRIDE,
            &[("a_rect", 4)],
            &["u_viewport", "u_src", "u_texel", "u_dir", "u_radius", "u_color"],
        )?;
        let output = Program::new(
            gl,
            is_gles,
            shader::LAYER_VERTEX,
            shader::OUTPUT_FRAGMENT,
            shader::RECT_STRIDE,
            &[("a_rect", 4)],
            &["u_viewport", "u_src", "u_scale", "u_offset", "u_gamut"],
        )?;
        let resolve = Program::new(
            gl,
            is_gles,
            shader::LAYER_VERTEX,
            shader::RESOLVE_FRAGMENT,
            shader::RECT_STRIDE,
            &[("a_rect", 4)],
            &["u_viewport", "u_src", "u_ss"],
        )?;
        let capture = Program::new(
            gl,
            is_gles,
            shader::LAYER_VERTEX,
            shader::CAPTURE_FRAGMENT,
            shader::RECT_STRIDE,
            &[("a_rect", 4)],
            &["u_viewport", "u_src", "u_region"],
        )?;
        let rects = Program::new(
            gl,
            is_gles,
            shader::RECT_VERTEX,
            &shader::rect_fragment(),
            shader::RECT_STRIDE,
            &[
                ("a_rect", 4),
                ("a_radius", 4),
                ("a_fill", 4),
                ("a_border", 4),
                ("a_border2", 4),
                ("a_border_g", 1),
                ("a_shape", 1),
                ("a_fill2", 4),
                ("a_grad", 2),
                ("a_stops", 4),
                ("a_extent", 2),
                ("a_border_w", 1),
                ("a_notch", 2),
                ("a_flip", 2),
            ],
            &[
                "u_viewport",
                "u_clip_rect",
                "u_clip_radius",
                "u_clip_shape",
                "u_clip_on",
            ],
        )?;
        let sectors = Program::new(
            gl,
            is_gles,
            shader::SECTOR_VERTEX,
            &shader::sector_fragment(),
            shader::SECTOR_STRIDE,
            &[
                ("a_centre", 2),
                ("a_geom", 4),
                ("a_fill", 4),
                ("a_caps", 1),
            ],
            &[
                "u_viewport",
                "u_clip_rect",
                "u_clip_radius",
                "u_clip_shape",
                "u_clip_on",
            ],
        )?;
        let glyphs = Program::new(
            gl,
            is_gles,
            shader::GLYPH_VERTEX,
            &shader::glyph_fragment(),
            shader::GLYPH_STRIDE,
            &[("a_rect", 4), ("a_atlas", 4), ("a_color", 4), ("a_kind", 1)],
            &[
                "u_viewport",
                "u_atlas_size",
                "u_atlas",
                "u_color_atlas_size",
                "u_color_atlas",
                "u_clip_rect",
                "u_clip_radius",
                "u_clip_shape",
                "u_clip_on",
            ],
        )?;
        let shadows = Program::new(
            gl,
            is_gles,
            shader::SHADOW_VERTEX,
            &shader::shadow_fragment(),
            shader::SHADOW_STRIDE,
            &[
                ("a_rect", 4),
                ("a_radius", 4),
                ("a_colour", 4),
                ("a_soft", 2),
                ("a_shape", 1),
                ("a_ring", 1),
            ],
            &[
                "u_viewport",
                "u_clip_rect",
                "u_clip_radius",
                "u_clip_shape",
                "u_clip_on",
            ],
        )?;
        let images = Program::new(
            gl,
            is_gles,
            shader::IMAGE_VERTEX,
            &shader::image_fragment(),
            shader::IMAGE_STRIDE,
            &[
                ("a_rect", 4),
                ("a_radius", 4),
                ("a_uv", 4),
                ("a_shape", 1),
            ],
            &[
                "u_viewport",
                "u_image",
                "u_clip_rect",
                "u_clip_radius",
                "u_clip_shape",
                "u_clip_on",
            ],
        )?;
        let acrylic = Program::new(
            gl,
            is_gles,
            shader::LAYER_VERTEX,
            &shader::acrylic_fragment(),
            shader::RECT_STRIDE,
            &[("a_rect", 4)],
            &[
                "u_viewport",
                "u_src",
                "u_rect",
                "u_radius",
                "u_exp",
                "u_tint",
                "u_luminosity",
                "u_noise",
            ],
        )?;
        let glass_kit = Program::new(
            gl,
            is_gles,
            shader::LAYER_VERTEX,
            &shader::liquid_glass_fragment(),
            shader::RECT_STRIDE,
            &[("a_rect", 4)],
            &[
                "u_viewport",
                "u_src",
                "u_rect",
                "u_radius",
                "u_exp",
                "u_glass",
                "u_optical",
                "u_light",
                "u_kit",
                "u_blend",
                "u_capture",
                "u_shape[0]",
                "u_shape_radius[0]",
            ],
        )?;
        Ok(Self {
            rects,
            sectors,
            glyphs,
            images,
            shadows,
            layers,
            effects,
            boxpass,
            acrylic,
            glass_kit,
            material: None,
            output,
            resolve,
            resolve_scratch: None,
            capture,
            capture_target: None,
            supersample: 1,
            layer_bounds: Vec::new(),
            layer_radius: Vec::new(),
            hdr: None,
            target_format: crate::effect_pass::TargetFormat::Rgba8,
            gamut: [[1.0, 0.0, 0.0], [0.0, 1.0, 0.0], [0.0, 0.0, 1.0]],
            output_scratch: None,
            frame: None,
            root_fbo: None,
            working: ui_core::colour::Encoding::SDR_PREMULTIPLIED,
            effect_scratch: Vec::new(),
            backdrop_scratch: Default::default(),
            layer_targets: Vec::new(),
            cached_targets: HashMap::new(),
            frame_serial: 0,
            atlas_tex: None,
            atlas_size: (1, 1),
            color_atlas_tex: None,
            color_atlas_size: (1, 1),
            image_textures: HashMap::new(),
            frame_images: Vec::new(),
            scale: 1.0,
            stats: RenderStats::default(),
        })
    }

    /// Every frame now repaints the whole surface, so a presenter must treat the damage
    /// as full. This reports it explicitly instead of letting callers guess.
    /// 现在每帧都重画整个表面，因此呈现方必须按全量脏区处理。此方法显式报告这一点，
    /// 而不是让调用方去猜。
    pub fn repaints_everything(&self) -> bool {
        true
    }

    /// Device pixels per logical point.
    /// 每逻辑点对应的设备像素。
    /// Change the working domain; every cached intermediate becomes invalid.
    /// 切换工作域；所有缓存的中间产物随之失效。
    /// Turn on the PQ output transform; `None` writes sRGB straight through.
    /// 打开 PQ 输出变换；`None` 表示直接写 sRGB。
    pub fn set_hdr(&mut self, reference_nits: Option<(f32, f32)>) {
        self.hdr = reference_nits.map(|(reference, min)| {
            [
                ui_core::colour::reference_scale(reference),
                ui_core::colour::min_offset(min),
            ]
        });
    }

    /// Choose the internal storage precision; targets reallocate on the next frame.
    /// 选择内部存储精度；下一帧会重新分配目标。
    pub fn set_target_format(&mut self, format: crate::effect_pass::TargetFormat) {
        self.target_format = format;
    }

    /// Set the sRGB -> output gamut matrix, row-major.
    /// 设置 sRGB -> 输出色域的矩阵，行主序。
    pub fn set_gamut(&mut self, gamut: [[f32; 3]; 3]) {
        self.gamut = gamut;
    }

    pub fn set_working(&mut self, working: ui_core::colour::Encoding) {
        self.working = working;
    }

    pub fn set_scale(&mut self, scale: f32) {
        self.scale = if scale.is_finite() && scale > 0.0 {
            scale
        } else {
            1.0
        };
    }

    pub fn scale(&self) -> f32 {
        self.scale
    }

    /// Render `ss` times finer than the surface, then box-average down on present: the lens
    /// magnifies what earlier batches painted, and a rasterized 1× frame holds no more detail.
    /// 以表面的 `ss` 倍分辨率渲染，呈现时箱式平均下来：透镜放大的是更早批次画下的内容，
    /// 已光栅好的 1× 帧不含更多细节。
    pub fn set_supersample(&mut self, ss: u32) {
        self.supersample = ss.clamp(1, 4);
    }

    pub fn supersample(&self) -> u32 {
        self.supersample
    }

    pub fn stats(&self) -> RenderStats {
        self.stats
    }

    /// Install the style's backdrop material; `None` keeps the plain blur blit.
    /// 装入风格的背景材质；`None` 保留纯模糊写回。
    pub fn set_backdrop_material(&mut self, material: Option<BackdropMaterial>) {
        self.material = material;
    }

    /// Upload (or replace) the coverage atlas.
    /// 上传（或替换）覆盖率图集。
    pub fn set_atlas(&mut self, gl: &glow::Context, atlas: AtlasUpload) -> Result<(), GpuError> {
        upload_atlas(
            gl,
            &mut self.atlas_tex,
            atlas.width,
            atlas.height,
            glow::R8,
            glow::RED,
            &atlas.data,
        )?;
        self.atlas_size = (atlas.width, atlas.height);
        Ok(())
    }

    /// Upload (or replace) the colour atlas: premultiplied RGBA8.
    /// 上传（或替换）颜色图集：预乘 RGBA8。
    pub fn set_color_atlas(
        &mut self,
        gl: &glow::Context,
        atlas: AtlasUpload,
    ) -> Result<(), GpuError> {
        upload_atlas(
            gl,
            &mut self.color_atlas_tex,
            atlas.width,
            atlas.height,
            glow::RGBA8,
            glow::RGBA,
            &atlas.data,
        )?;
        self.color_atlas_size = (atlas.width, atlas.height);
        Ok(())
    }

    /// Clear `target` to `color` (straight alpha, 0..=1).
    /// 把 `target` 清屏为 `color`（直通 alpha，0..=1）。
    pub fn clear(&mut self, gl: &glow::Context, target: &dyn GpuSurface, color: [f32; 4]) {
        target.bind(gl);
                unsafe {
            gl.disable(glow::SCISSOR_TEST);
            gl.clear_color(color[0], color[1], color[2], color[3]);
            gl.clear(glow::COLOR_BUFFER_BIT);
        }
    }

    /// Render `list` into `target`.
    /// 把 `list` 渲染进 `target`。
    ///
    /// Every frame clears the persistent frame buffer and repaints the whole scene. That is
    /// what Flutter, Skia-backed toolkits and Haze all do, and it is the reason they do not
    /// have the class of bug we kept hitting: no stage can read a pixel that nobody wrote
    /// this frame. Cross-frame reuse of filtered pixels was tried and removed — see
    /// `docs/effect-cache-plan.md` §11.
    /// 每帧清空持久帧缓冲并重画整个场景。Flutter、Skia 系工具包与 Haze 都是如此，这也正是
    /// 它们不会遇到我们反复踩到的那类 bug 的原因：任何阶段都读不到本帧没人写过的像素。
    /// 跨帧复用滤波像素曾实现过并已撤除，见 `docs/effect-cache-plan.md` §11。
    pub fn render(
        &mut self,
        gl: &glow::Context,
        target: &dyn GpuSurface,
        list: &DrawList,
    ) -> Result<RenderStats, GpuError> {
        self.render_frame(gl, target, list, &ui_core::damage::Damage::Full)
    }

    /// Render only `damage` into the persistent frame, then hand that band to `target`.
    /// 只把 `damage` 渲染进持久帧，再把这一带交给 `target`。
    ///
    /// The band is one rect: every pixel inside it is cleared and redrawn, so no blend
    /// surface is drawn twice; a frost widens the band over itself instead.
    /// 重绘带是单个矩形：带内每个像素都先清后画，因此没有混合面被画两次；
    /// 磨砂则把重绘带长到盖住自己。
    pub fn render_frame(
        &mut self,
        gl: &glow::Context,
        target: &dyn GpuSurface,
        list: &DrawList,
        damage: &ui_core::damage::Damage,
    ) -> Result<RenderStats, GpuError> {
        self.render_frame_into(gl, target, list, damage, &[])
    }

    /// The same, also copying `carry` to `target`: the rects it is still missing.
    /// 同上，并把 `carry` 也复制给 `target`：它仍然缺少的那些矩形。
    ///
    /// A buffer that is reused round-robin holds the bands drawn on the frames it was
    /// assigned to, so everything drawn since then has to travel with this frame's band.
    /// 轮转复用的缓冲只带它被分配到的那些帧上画过的重绘带，因此那之后画的内容必须随本帧
    /// 的重绘带一起搬过去。
    pub fn render_frame_into(
        &mut self,
        gl: &glow::Context,
        target: &dyn GpuSurface,
        list: &DrawList,
        damage: &ui_core::damage::Damage,
        carry: &[[i32; 4]],
    ) -> Result<RenderStats, GpuError> {
        self.stats = RenderStats::default();
        // Everything below is measured in render pixels: the surface times `ss`. Geometry
        // and scissor conversion ride the same factor, so the scene is simply drawn finer.
        // 以下一律以渲染像素计，即表面尺寸乘 `ss`。几何与裁剪换算走同一系数，
        // 场景因此只是被更精细地画了一遍。
        let surface = (target.size().0, target.size().1);
        let ss = self.supersample;
        let size = (surface.0 * ss, surface.1 * ss);
        let scale = self.scale;
        self.scale = scale * ss as f32;
        let (frame_fbo, frame_tex) = crate::effect_pass::ensure_target(
            &mut self.frame,
            gl,
            size.0,
            size.1,
            self.target_format,
        )?;
        // Only the redraw band is cleared: everything outside it still holds the pixels the
        // previous frame left there, and that is exactly what the band promises.
        // 只清重绘带：带外的像素仍是上一帧留下的内容，重绘带承诺的正是这一点。
        let band = self.damage_band(damage, surface, list);
        self.stats.band = band;
        match band {
            Some(_) => PARTIAL_FRAMES.fetch_add(1, std::sync::atomic::Ordering::Relaxed),
            None => FULL_FRAMES.fetch_add(1, std::sync::atomic::Ordering::Relaxed),
        };
        unsafe {
            gl.bind_framebuffer(glow::FRAMEBUFFER, Some(frame_fbo));
            gl.clear_color(0.0, 0.0, 0.0, 0.0);
            match band {
                Some(b) => {
                    gl.enable(glow::SCISSOR_TEST);
                    gl.scissor(b[0], b[1], b[2], b[3]);
                }
                None => gl.disable(glow::SCISSOR_TEST),
            }
            gl.clear(glow::COLOR_BUFFER_BIT);
        }
        self.root_fbo = Some(frame_fbo);
        unsafe {
            gl.bind_framebuffer(glow::FRAMEBUFFER, Some(frame_fbo));
            gl.viewport(0, 0, size.0 as i32, size.1 as i32);
        }
        let viewport = (size.0 as f32, size.1 as f32);
        unsafe {
            gl.enable(glow::BLEND);
            // Premultiplied source over destination.
            // 预乘源覆盖目标。
            gl.blend_func(glow::ONE, glow::ONE_MINUS_SRC_ALPHA);
            gl.disable(glow::DEPTH_TEST);
            gl.enable(glow::SCISSOR_TEST);
        }

        let mut rect_data: Vec<f32> = Vec::new();
        let mut glyph_data: Vec<f32> = Vec::new();
        // Active layer chain; depth `d` renders into `layer_targets[d]`.
        // 当前层链；深度 `d` 渲染进 `layer_targets[d]`。
        let mut chain = Chain::default();
        self.frame_serial += 1;
        let frame = FrameTargets {
            damage,
            band,
            viewport,
        };

        // A layer starts empty, so a frosted surface inside one samples its parent: the
        // layer is composited back over that same parent, so it is what the surface covers.
        // 层初始为空，因此层内的磨砂面采样它的父目标：层随后又合成回这个父目标，
        // 它覆盖的正是那里的像素。
        let backdrops = list.backdrop_order();
        let mut done = 0usize;
        self.sync_images(gl, list)?;
        // Probe: `CRABSNAP_NO_CULL=1` draws every batch, so an A/B can price the culling.
        // 探针：`CRABSNAP_NO_CULL=1` 画每个批次，A/B 才能给裁剪定价。
        let cull = std::env::var_os("CRABSNAP_NO_CULL").is_none();

        for batch in list.plan_batches() {
            self.sync_layers(gl, list, &frame, &mut chain, &batch.layers)?;
            // A cached subtree that did not change keeps the pixels the frame already has;
            // rebuilding its vertices and submitting them would write nothing new.
            // 未变化的缓存子树直接沿用帧里已有的像素；重建顶点并提交只会白写一遍。
            if chain.clean.last() == Some(&true) {
                self.stats.cached_skips += 1;
                continue;
            }
            while done < backdrops.len() && backdrops[done].0 <= batch.epoch {
                let (_, entry) = backdrops[done];
                done += 1;
                // Run here, before the frost node's own fill: everything the kernel reads
                // was painted by earlier batches, and running later would smear its text.
                // 在此执行，早于磨砂节点自己的填充：核读取的内容都由更早的批次画好，
                // 放到后面会把它的文字一起抹掉。
                if std::env::var("CRABSNAP_NO_BACKDROP").is_err() {
                    let (src, dst) = self.backdrop_pair(frame_tex, frame_fbo, &chain.stack);
                    self.apply_backdrop(gl, size, dst, src, entry, band)?;
                }
            }
            // A batch that misses the band can write no pixel: its scissor would be empty.
            // Skipping it saves the draw call, which the driver prices per call, not per pixel.
            // 与重绘带不相交的批次写不了任何像素：它的裁剪会是空集。
            // 跳过它省下一次绘制，而驱动按次计价，不按像素。
            if let Some(b) = band.filter(|_| cull) {
                let s = self.scale.max(f32::EPSILON);
                let area = ui_core::geom::Rect::new(
                    b[0] as f32 / s,
                    b[1] as f32 / s,
                    b[2] as f32 / s,
                    b[3] as f32 / s,
                );
                let hits = batch.bounds.is_some_and(|r| area.intersection(r).is_some());
                if !hits {
                    self.stats.band_culls += 1;
                    continue;
                }
            }
            match batch.kind {
                PrimKind::Shadow => {
                    // One analytic draw for the whole run: no pass, no temporary texture.
                    // 整段一次解析绘制：没有趟，也没有临时纹理。
                    let mut data: Vec<f32> = Vec::new();
                    for i in batch.range.start..batch.range.end {
                        if let Some(p) = list.prims.shadows.get(i as usize) {
                            push_shadow(&mut data, p, self.scale);
                        }
                    }
                    if !data.is_empty() {
                        set_scissor(gl, batch.clip.map(|c| c.rect), self.scale, viewport, band);
                        self.draw_shadows(gl, viewport, &data, batch.clip)?;
                    }
                }
                PrimKind::Image => {
                    // Consecutive primitives on one texture share a draw; a batch may mix them.
                    // 同一纹理上连续的图元共用一次绘制；一个批次里可能混有多张纹理。
                    let mut start = batch.range.start;
                    while start < batch.range.end {
                        let Some(first) = list.prims.images.get(start as usize) else {
                            return Err(GpuError::from(format!(
                                "image batch names prim {start} of {}",
                                list.prims.images.len()
                            )));
                        };
                        let mut end = start + 1;
                        while end < batch.range.end
                            && list
                                .prims
                                .images
                                .get(end as usize)
                                .is_some_and(|p| p.texture == first.texture)
                        {
                            end += 1;
                        }
                        let Some(img) = self.frame_images.get(first.texture as usize).copied()
                        else {
                            return Err(GpuError::from(format!(
                                "image prim {start} samples texture {} of {}",
                                first.texture,
                                self.frame_images.len()
                            )));
                        };
                        let mut data: Vec<f32> = Vec::new();
                        for i in start..end {
                            if let Some(p) = list.prims.images.get(i as usize) {
                                push_image(&mut data, p, self.scale, (img.width, img.height));
                            }
                        }
                        if !data.is_empty() {
                            set_scissor(gl, batch.clip.map(|c| c.rect), self.scale, viewport, band);
                            self.draw_images(gl, viewport, &data, img.tex, batch.clip)?;
                        }
                        start = end;
                    }
                }
                PrimKind::Rect => {
                    for i in batch.range.start..batch.range.end {
                        if let Some(p) = list.prims.rects.get(i as usize) {
                            push_rect(&mut rect_data, p, self.scale);
                        }
                    }
                    if !rect_data.is_empty() {
                        set_scissor(gl, batch.clip.map(|c| c.rect), self.scale, viewport, band);
                        self.draw_rects(gl, viewport, &rect_data, batch.clip)?;
                        rect_data.clear();
                    }
                }
                PrimKind::Sector => {
                    let mut data: Vec<f32> = Vec::new();
                    for i in batch.range.start..batch.range.end {
                        if let Some(p) = list.prims.sectors.get(i as usize) {
                            push_sector(&mut data, p, self.scale);
                        }
                    }
                    if !data.is_empty() {
                        set_scissor(gl, batch.clip.map(|c| c.rect), self.scale, viewport, band);
                        self.draw_sectors(gl, viewport, &data, batch.clip)?;
                    }
                }
                PrimKind::Glyph => {
                    // A glyph wholly outside the batch's clip would only be scissored away;
                    // dropping it here leaves a long line in a narrow field as layout only.
                    // 完全落在批次裁剪框外的字形只会被剪掉；在此丢弃，
                    // 窄字段里的长行便只付排版代价。
                    let scissor = batch.clip.map(|c| device_scissor(c.rect, self.scale));
                    for i in batch.range.start..batch.range.end {
                        if let Some(p) = list.prims.glyphs.get(i as usize) {
                            if scissor.is_some_and(|s| !glyph_hits_scissor(p, self.scale, s)) {
                                continue;
                            }
                            push_glyph(&mut glyph_data, p, self.scale);
                        }
                    }
                    if !glyph_data.is_empty() {
                        set_scissor(gl, batch.clip.map(|c| c.rect), self.scale, viewport, band);
                        self.draw_glyphs(gl, viewport, &glyph_data, batch.clip)?;
                        glyph_data.clear();
                    }
                }
                // Raw text without a pre-rasterized atlas has no GPU path yet.
                // 没有预光栅图集的原始文本暂时没有 GPU 路径。
                PrimKind::Text => {}
            }
        }

        // A backdrop with no batch after it would otherwise never run: the loop only
        // advances the queue when it sees a later epoch.
        // 后面没有批次的 backdrop 否则永远不会执行：循环只在遇到更晚的世代时才推进队列。
        while done < backdrops.len() {
            let (_, entry) = backdrops[done];
            done += 1;
            if std::env::var("CRABSNAP_NO_BACKDROP").is_err() {
                let (src, dst) = self.backdrop_pair(frame_tex, frame_fbo, &chain.stack);
                self.apply_backdrop(gl, size, dst, src, entry, band)?;
            }
        }
        while let Some(index) = chain.stack.pop() {
            let depth = chain.stack.len();
            let was_clean = chain.clean.pop().unwrap_or(false);
            let entry = list.layers.get(index as usize);
            let effects = entry.map_or(&[][..], |l| &l.effects[..]);
            let cache = entry.and_then(|l| l.cache_key);
            // A layer is composited only into a parent this frame repainted: compositing
            // again over pixels that already show it would blend a translucent layer twice.
            // 层只合成进本帧重画过的父级：在已显示它的像素上再合成一次，
            // 半透明层会被混合两遍。
            let composite = match chain.clean.last() {
                Some(&parent_clean) => !parent_clean,
                None => frame_cleared_over(band, self.layer_bounds.get(depth).copied()),
            };
            self.end_layer(
                gl,
                depth,
                effects,
                viewport,
                band,
                Finish {
                    cache,
                    clean: was_clean,
                    composite,
                },
            )?;
        }
        self.cached_targets
            .retain(|_, c| c.last_used == self.frame_serial);
        // The target must end up equal to the frame: this frame's band plus whatever it
        // missed on the frames it was not handed. A full band copies everything anyway.
        // 目标必须与持久帧一致：本帧的重绘带，加上它没被交付的那些帧上错过的部分。
        // 整帧本身就是复制整面。
        let copy = band.map(|b| carry.iter().fold(b, |acc, c| union_device(acc, *c, size)));
        let blitted = self.blit_frame(gl, target, surface, frame_fbo, frame_tex, copy);
        self.scale = scale;
        blitted?;
        Ok(self.stats)
    }

    /// Bind the target that layer `depth` renders into, creating it on demand.
    /// 绑定第 `depth` 层渲染用的目标，按需创建。
    fn begin_layer(
        &mut self,
        gl: &glow::Context,
        depth: usize,
        width: u32,
        height: u32,
    ) -> Result<(), GpuError> {
        while self.layer_targets.len() <= depth {
            self.layer_targets.push(crate::effect_pass::new_target(gl)?);
        }

        let slot = &mut self.layer_targets[depth];
        if slot.width != width || slot.height != height || slot.format != self.target_format {
            crate::effect_pass::resize_target(gl, slot, width, height, self.target_format);
        }

        let fbo = slot.fbo;
        unsafe {
            gl.bind_framebuffer(glow::FRAMEBUFFER, Some(fbo));
            gl.viewport(0, 0, width as i32, height as i32);
            // A layer starts fully transparent; leftovers would leak through.
            // 层从全透明开始；残留会渗进来。
            gl.disable(glow::SCISSOR_TEST);
            gl.clear_color(0.0, 0.0, 0.0, 0.0);
            gl.clear(glow::COLOR_BUFFER_BIT);
            gl.enable(glow::SCISSOR_TEST);
        }
        Ok(())
    }

    /// Composite layer `depth` into its parent with `opacity`.
    /// 把第 `depth` 层按 `opacity` 合成到父级。
    /// The device rect this frame redraws, or `None` for the whole surface.
    /// 本帧重绘的设备矩形；`None` 表示整面。
    fn damage_band(
        &self,
        damage: &ui_core::damage::Damage,
        surface: (u32, u32),
        list: &DrawList,
    ) -> Option<[i32; 4]> {
        if std::env::var_os("CRABSNAP_NO_PARTIAL").is_some() {
            return None;
        }
        if self.supersample > 1 || self.hdr.is_some() {
            return None;
        }
        let full = ui_core::geom::Rect::new(
            0.0,
            0.0,
            surface.0 as f32 / self.scale.max(f32::EPSILON),
            surface.1 as f32 / self.scale.max(f32::EPSILON),
        );
        let rects = damage.rects(full);
        let (&first, rest) = rects.split_first()?;
        let bbox = rest.iter().fold(first, |acc, r| acc.union(*r));
        // A layer effect rewrites its whole layer, so any of them forces a full frame.
        // 层效果会重写整层，因此任何一个都退回整帧。
        if list.layers.iter().any(|l| !l.effects.is_empty()) {
            return None;
        }
        let full_dev = ui_core::geom::Rect::new(0.0, 0.0, surface.0 as f32, surface.1 as f32);
        // A frost re-reads the frame around its box, so a band reaching it must repaint it too;
        // `cover_frosts` grows the band over the chain of frosts that follows.
        // 磨砂会重读盒子四周的画面，因此碰到它的带必须把它也重画；长出来的链由
        // `cover_frosts` 逐块盖住。
        let frosts: Vec<(ui_core::geom::Rect, ui_core::geom::Rect)> = list
            .backdrop_order()
            .iter()
            .filter_map(|(_, e)| {
                let vis = self.backdrop_visible(e)?.intersection(full_dev)?;
                Some((self.backdrop_read(e), vis))
            })
            .collect();
        let b = cover_frosts(device_scissor(bbox, self.scale), &frosts);
        let area = b[2] as f64 * b[3] as f64;
        let all = surface.0 as f64 * surface.1 as f64;
        // Past this share the band is most of the frame, and a full frame is cheaper.
        // 超过这个比例时重绘带已是整帧的大半，整帧反而更便宜。
        (area < all * 0.7).then_some(b)
    }

    /// Hand the persistent frame to the rotating target, applying the output transform.
    /// 把持久帧交给轮转目标，并施加输出变换。
    ///
    /// Both the static path and the redraw path go through here: skipping it on a static
    /// frame leaves sRGB values in a surface declared as PQ, which reads as washed out.
    /// 静止帧与重绘帧都必须走这里：静止帧跳过它会让声明为 PQ 的 surface 里留着 sRGB 值，
    /// 表现为发白发亮。
    fn blit_frame(
        &mut self,
        gl: &glow::Context,
        target: &dyn GpuSurface,
        size: (u32, u32),
        frame_fbo: glow::Framebuffer,
        frame_tex: glow::Texture,
        band: Option<[i32; 4]>,
    ) -> Result<(), GpuError> {
        // Resolve before the output transform: the transform must encode averaged pixels,
        // not one sample per destination pixel taken from the supersampled frame.
        // 先解析再走输出变换：变换编码的必须是平均后的像素，
        // 而不是从超采样帧里每目标像素点采一个。
        let mut from = frame_fbo;
        let mut source = frame_tex;
        if self.supersample > 1 {
            let scratch = crate::effect_pass::ensure_target(
                &mut self.resolve_scratch,
                gl,
                size.0,
                size.1,
                self.target_format,
            )?;
            self.resolve_frame(gl, scratch.0, source, size)?;
            from = scratch.0;
            source = scratch.1;
        }
        if let Some([scale, offset]) = self.hdr {
            let scratch =
                crate::effect_pass::ensure_target(
                &mut self.output_scratch,
                gl,
                size.0,
                size.1,
                self.target_format,
            )?;
            let p = &self.output;
            unsafe {
                gl.bind_framebuffer(glow::FRAMEBUFFER, Some(scratch.0));
                gl.viewport(0, 0, size.0 as i32, size.1 as i32);
                gl.disable(glow::BLEND);
                gl.disable(glow::SCISSOR_TEST);
                gl.use_program(Some(p.program));
                if let Some(u) = &p.uniforms.viewport {
                    gl.uniform_2_f32(Some(u), size.0 as f32, size.1 as f32);
                }
                if let Some(u) = &p.uniforms.src {
                    gl.active_texture(glow::TEXTURE0);
                    gl.bind_texture(glow::TEXTURE_2D, Some(source));
                    gl.uniform_1_i32(Some(u), 0);
                }
                if let Some(u) = &p.uniforms.scale {
                    gl.uniform_1_f32(Some(u), scale);
                }
                if let Some(u) = &p.uniforms.offset {
                    gl.uniform_1_f32(Some(u), offset);
                }
                if let Some(u) = &p.uniforms.gamut {
                    // GLSL reads mat3 column-major, so transpose on the way out.
                    // GLSL 按列主序读 mat3，因此传出时转置。
                    let g = &self.gamut;
                    let cols = [
                        g[0][0], g[1][0], g[2][0], g[0][1], g[1][1], g[2][1], g[0][2], g[1][2],
                        g[2][2],
                    ];
                    gl.uniform_matrix_3_f32_slice(Some(u), false, &cols);
                }
                gl.bind_vertex_array(Some(p.vao));
                let quad: [f32; 4] = [0.0, 0.0, size.0 as f32, size.1 as f32];
                gl.bind_buffer(glow::ARRAY_BUFFER, Some(p.instance_vbo));
                gl.buffer_data_u8_slice(glow::ARRAY_BUFFER, as_bytes(&quad), glow::DYNAMIC_DRAW);
                gl.draw_arrays_instanced(glow::TRIANGLES, 0, 6, 1);
                gl.enable(glow::BLEND);
            }
            from = scratch.0;
        }
        unsafe {
            gl.disable(glow::SCISSOR_TEST);
            target.bind(gl);
            gl.bind_framebuffer(glow::READ_FRAMEBUFFER, Some(from));
            let [x, y, w, h] = band.unwrap_or([0, 0, size.0 as i32, size.1 as i32]);
            gl.blit_framebuffer(
                x,
                y,
                x + w,
                y + h,
                x,
                y,
                x + w,
                y + h,
                glow::COLOR_BUFFER_BIT,
                glow::NEAREST,
            );
            gl.bind_framebuffer(glow::READ_FRAMEBUFFER, None);
        }
        Ok(())
    }

    /// Box-average the supersampled frame into `dest`, one destination pixel per quad pixel.
    /// 把超采样帧箱式平均进 `dest`，每个目标像素对应一个四边形像素。
    fn resolve_frame(
        &self,
        gl: &glow::Context,
        dest: glow::Framebuffer,
        src: glow::Texture,
        size: (u32, u32),
    ) -> Result<(), GpuError> {
        let p = &self.resolve;
        unsafe {
            gl.bind_framebuffer(glow::FRAMEBUFFER, Some(dest));
            gl.viewport(0, 0, size.0 as i32, size.1 as i32);
            gl.disable(glow::BLEND);
            gl.disable(glow::SCISSOR_TEST);
            gl.use_program(Some(p.program));
            if let Some(u) = &p.uniforms.viewport {
                gl.uniform_2_f32(Some(u), size.0 as f32, size.1 as f32);
            }
            if let Some(u) = &p.uniforms.src {
                gl.active_texture(glow::TEXTURE0);
                gl.bind_texture(glow::TEXTURE_2D, Some(src));
                gl.uniform_1_i32(Some(u), 0);
            }
            if let Some(u) = &p.uniforms.supersample {
                gl.uniform_1_i32(Some(u), self.supersample as i32);
            }
            gl.bind_vertex_array(Some(p.vao));
            let quad: [f32; 4] = [0.0, 0.0, size.0 as f32, size.1 as f32];
            gl.bind_buffer(glow::ARRAY_BUFFER, Some(p.instance_vbo));
            gl.buffer_data_u8_slice(glow::ARRAY_BUFFER, as_bytes(&quad), glow::DYNAMIC_DRAW);
            gl.draw_arrays_instanced(glow::TRIANGLES, 0, 6, 1);
            gl.enable(glow::BLEND);
        }
        Ok(())
    }

    fn end_layer(
        &mut self,
        gl: &glow::Context,
        depth: usize,
        effects: &[Effect],
        viewport: (f32, f32),
        band: Option<[i32; 4]>,
        finish: Finish,
    ) -> Result<(), GpuError> {
        let Finish {
            cache,
            clean,
            composite,
        } = finish;
        // Depth 0 lands in the frame, which this frame cleared only inside the band.
        // 深度 0 落在帧上，而帧本帧只清空了重绘带内。
        let cleared = if depth == 0 { band_rect(band) } else { None };

        // A cached layer nobody changed still has its last composite, and its depth target may
        // never have been allocated: this runs before the lookup and draws nothing.
        // 无人改动的缓存层仍留有上一次的合成图，且该深度的目标可能从未分配：
        // 此段在查目标之前，什么也不画。
        if clean {
            if let (true, Some(key)) = (composite, cache)
                && let Some(cached) = self.cached_targets.get(&key)
            {
                let tex = cached.target.tex;
                self.composite_layer(gl, depth, tex, viewport, cleared);
            } else if !composite {
                self.bind_parent(gl, depth, viewport);
            }
            return Ok(());
        }

        let Some(slot) = self.layer_targets.get(depth) else {
            return Ok(());
        };
        let (layer_w, layer_h, layer_tex) = (slot.width, slot.height, slot.tex);

        // Effects and compositing both stop at the layer's bounds; the rest is transparent.
        // 效果与合成都到层边界为止，其余是透明的。
        let full = ui_core::geom::Rect::new(0.0, 0.0, viewport.0, viewport.1);
        let bounds = self.layer_bounds.get(depth).copied().unwrap_or(full);

        // The layer was painted in full this frame, so its effects are recomputed in full:
        // nothing here may depend on what a previous frame left in these textures.
        // 层在本帧被整层画好，因此其效果也整层重算：这里任何东西都不得依赖上一帧留在这
        // 些纹理里的内容。
        if self.effect_scratch.len() <= depth {
            self.effect_scratch.resize_with(depth + 1, Default::default);
        }
        // Kernels are authored per logical dp; the layer grid is `scale` times finer.
        // 核按逻辑 dp 撰写；层网格比它细 `scale` 倍。
        let scaled: Vec<Effect> = effects
            .iter()
            .cloned()
            .map(|e| crate::effect_pass::on_grid(e, self.scale))
            .collect();
        let tex = crate::effect_pass::run(
            &mut self.effect_scratch[depth],
            gl,
            &self.effects,
            &self.boxpass,
            layer_tex,
            layer_w,
            layer_h,
            bounds,
            self.target_format,
            &scaled,
            false,
        )?;

        // Keep the finished pixels for the frames this subtree does not change in.
        // 把画好的像素留给这棵子树不再变化的那些帧。
        if let Some(key) = cache {
            self.store_cache(gl, key, tex, viewport)?;
        }

        if composite {
            self.composite_layer(gl, depth, tex, viewport, cleared);
        } else {
            self.bind_parent(gl, depth, viewport);
        }
        Ok(())
    }

    /// Bind the target a layer at `depth` composites into: the frame at depth 0, else its
    /// outer layer.
    /// 绑定第 `depth` 层合成进的父级：深度 0 是帧，否则是外层。
    fn bind_parent(&self, gl: &glow::Context, depth: usize, viewport: (f32, f32)) {
        if depth == 0 {
            if let Some(root) = self.root_fbo {
                unsafe {
                    gl.bind_framebuffer(glow::FRAMEBUFFER, Some(root));
                    gl.viewport(0, 0, viewport.0 as i32, viewport.1 as i32);
                }
            }
        } else if let Some(parent) = self.layer_targets.get(depth - 1) {
            unsafe {
                gl.bind_framebuffer(glow::FRAMEBUFFER, Some(parent.fbo));
                gl.viewport(0, 0, parent.width as i32, parent.height as i32);
            }
        }
    }

    /// Composite layer `depth` from `tex` into its parent, inside `cleared` (the region the
    /// parent repainted; `None` = all of it), clipped and rounded to the layer.
    /// 把第 `depth` 层由 `tex` 合成进父级，限于 `cleared`（父级重画过的范围，`None` 表示全部），
    /// 并按该层裁剪、切圆角。
    fn composite_layer(
        &mut self,
        gl: &glow::Context,
        depth: usize,
        tex: glow::Texture,
        viewport: (f32, f32),
        cleared: Option<ui_core::geom::Rect>,
    ) {
        let full = ui_core::geom::Rect::new(0.0, 0.0, viewport.0, viewport.1);
        let bounds = self.layer_bounds.get(depth).copied().unwrap_or(full);
        self.bind_parent(gl, depth, viewport);
        let cut = bounds
            .intersection(full)
            .and_then(|b| match cleared {
                Some(c) => b.intersection(c),
                None => Some(b),
            });
        let Some(cut) = cut else {
            return;
        };
        let scissor = device_scissor(cut, 1.0);
        let corners = self
            .layer_radius
            .get(depth)
            .copied()
            .unwrap_or(ui_core::geom::Corners::all(0.0));
        unsafe {
            gl.enable(glow::SCISSOR_TEST);
            gl.scissor(scissor[0], scissor[1], scissor[2], scissor[3]);
        }
        self.draw_layer_quad(
            gl,
            tex,
            viewport,
            [bounds.origin.x, bounds.origin.y, bounds.size.w, bounds.size.h],
            corners,
        );
        self.stats.draw_calls += 1;
    }

    /// Draw `tex` as one quad with the layer program: a layer composited into its parent, and
    /// the copy that keeps a cached layer's pixels.
    /// 用层程序把 `tex` 画成一个四边形：层合成进父级，以及缓存层像素的拷贝。
    fn draw_layer_quad(
        &self,
        gl: &glow::Context,
        tex: glow::Texture,
        viewport: (f32, f32),
        rect: [f32; 4],
        corners: ui_core::geom::Corners,
    ) {
        unsafe {
            let p = &self.layers;
            gl.use_program(Some(p.program));
            if let Some(u) = p.uniforms.viewport {
                gl.uniform_2_f32(Some(&u), viewport.0, viewport.1);
            }
            if let Some(u) = p.uniforms.opacity {
                gl.uniform_1_f32(Some(&u), 1.0);
            }
            // Rounded corners are a property of the layer, not of this pass.
            // 圆角是层的属性，不是这一趟的。
            if let Some(u) = &p.uniforms.layer_rect {
                gl.uniform_4_f32(Some(u), rect[0], rect[1], rect[2], rect[3]);
            }
            if let Some(u) = &p.uniforms.layer_radius {
                gl.uniform_4_f32(Some(u), corners.tl, corners.tr, corners.br, corners.bl);
            }
            if let Some(u) = &p.uniforms.layer_exp {
                gl.uniform_1_f32(Some(u), corners.shape.exponent());
            }
            if let Some(u) = &p.uniforms.layer_skip_empty {
                gl.uniform_1_f32(Some(u), 0.0);
            }
            if let Some(u) = p.uniforms.layer_tex {
                gl.active_texture(glow::TEXTURE0);
                gl.bind_texture(glow::TEXTURE_2D, Some(tex));
                gl.uniform_1_i32(Some(&u), 0);
            }
            let data = [0.0f32, 0.0, viewport.0, viewport.1];
            gl.bind_vertex_array(Some(p.vao));
            gl.bind_buffer(glow::ARRAY_BUFFER, Some(p.instance_vbo));
            gl.buffer_data_u8_slice(glow::ARRAY_BUFFER, as_bytes(&data), glow::DYNAMIC_DRAW);
            gl.draw_arrays_instanced(
                glow::TRIANGLES,
                0,
                shader::UNIT_QUAD.len() as i32 / 2,
                1,
            );
            gl.enable(glow::SCISSOR_TEST);
        }
    }

    /// Copy a finished layer into its cache target, unmasked: the mask is the layer's, and it
    /// is reapplied whenever the cache is composited.
    /// 把完成的层不加遮罩地拷进缓存目标：遮罩属于层，在合成缓存时再施加。
    fn store_cache(
        &mut self,
        gl: &glow::Context,
        key: u64,
        tex: glow::Texture,
        viewport: (f32, f32),
    ) -> Result<(), GpuError> {
        let (w, h) = (viewport.0 as u32, viewport.1 as u32);
        if !self.cached_targets.contains_key(&key) {
            let target = crate::effect_pass::new_target(gl)?;
            self.cached_targets.insert(
                key,
                CachedTarget {
                    target,
                    valid: false,
                    last_used: self.frame_serial,
                },
            );
        }
        let Some(slot) = self.cached_targets.get_mut(&key) else {
            return Ok(());
        };
        slot.last_used = self.frame_serial;
        if slot.target.width != w || slot.target.height != h || slot.target.format != self.target_format
        {
            crate::effect_pass::resize_target(gl, &mut slot.target, w, h, self.target_format);
        }
        slot.valid = true;
        let fbo = slot.target.fbo;
        unsafe {
            gl.bind_framebuffer(glow::FRAMEBUFFER, Some(fbo));
            gl.viewport(0, 0, w as i32, h as i32);
            gl.disable(glow::SCISSOR_TEST);
            gl.clear_color(0.0, 0.0, 0.0, 0.0);
            gl.clear(glow::COLOR_BUFFER_BIT);
        }
        self.draw_layer_quad(
            gl,
            tex,
            viewport,
            [0.0, 0.0, viewport.0, viewport.1],
            ui_core::geom::Corners::all(0.0),
        );
        self.stats.draw_calls += 1;
        Ok(())
    }

    /// Blur what is already painted inside `entry`, in place on the frame target.
    /// 在帧目标上就地模糊 `entry` 矩形内已画好的内容。
    ///
    /// The filter reads the live frame and runs over all of it: everything the kernel needs
    /// was painted by earlier batches this frame, so no tap can reach a pixel from an earlier
    /// frame, and edge taps meet real neighbours instead of a cropped copy's transparent
    /// border. The result is written back over the node's own rect with corner coverage,
    /// which is what keeps the frost's rounded shape.
    /// 滤波器读当帧画面并跑整帧：核需要的一切都由本帧更早的批次画好，因此没有 tap 能触到
    /// 上一帧的像素，边缘 tap 遇到的也是真实邻居而非裁剪副本的透明边界。结果按节点自身
    /// 矩形加圆角覆盖率写回，磨砂因此保留圆角。
    /// The texture a backdrop reads and the target it lands in, for the layer in force.
    /// 背景模糊读取的纹理与落点，按当前生效的层决定。
    fn backdrop_pair(
        &self,
        frame_tex: glow::Texture,
        frame_fbo: glow::Framebuffer,
        stack: &[u32],
    ) -> (glow::Texture, glow::Framebuffer) {
        match stack.len() {
            0 => (frame_tex, frame_fbo),
            n => {
                let src = if n >= 2 {
                    self.layer_targets[n - 2].tex
                } else {
                    frame_tex
                };
                (src, self.layer_targets[n - 1].fbo)
            }
        }
    }

    /// A dp rect on the render grid.
    /// dp 矩形换算到渲染网格。
    fn on_device(&self, r: ui_core::geom::Rect) -> ui_core::geom::Rect {
        let s = self.scale;
        ui_core::geom::Rect::new(
            r.origin.x * s,
            r.origin.y * s,
            r.size.w * s,
            r.size.h * s,
        )
    }

    /// The device area a backdrop may write: its box narrowed by the node's own clip.
    /// 背景模糊可以写入的设备区域：自身盒子按节点自己的裁剪收窄。
    fn backdrop_visible(&self, entry: &ui_core::draw::BackdropEntry) -> Option<ui_core::geom::Rect> {
        self.on_device(entry.rect)
            .intersection(self.on_device(entry.clip))
    }

    /// The device box a backdrop reads: its own rect grown by the kernel's reach.
    /// 背景模糊读取的设备盒子：自身矩形按核的触及范围外扩。
    fn backdrop_read(&self, entry: &ui_core::draw::BackdropEntry) -> ui_core::geom::Rect {
        let s = self.scale;
        let device = self.on_device(entry.rect);
        let effect = crate::effect_pass::on_grid(
            ui_core::effect::Effect::box_blur(entry.sigma),
            self.scale,
        );
        // The kit lens shows a margin beyond its box; a plain blur reads only its kernel.
        // kit 透镜在盒外还显示一圈余量；纯模糊只读它的核。
        let margin = match resolve(entry.material, self.material) {
            Some(ui_core::draw::BackdropMaterial::LiquidGlass(k)) => {
                (k.capture_size - 1.0).max(0.0) * 0.5 * device.size.w.max(device.size.h)
            }
            _ => 0.0,
        };
        let reach = effect.kernel.radius as f32 * 3.0 + margin + 2.0 * s;
        ui_core::geom::Rect::new(
            device.origin.x - reach,
            device.origin.y - reach,
            device.size.w + reach * 2.0,
            device.size.h + reach * 2.0,
        )
    }

    fn apply_backdrop(
        &mut self,
        gl: &glow::Context,
        size: (u32, u32),
        dst_fbo: glow::Framebuffer,
        src_tex: glow::Texture,
        entry: ui_core::draw::BackdropEntry,
        band: Option<[i32; 4]>,
    ) -> Result<(), GpuError> {
        let full = ui_core::geom::Rect::new(0.0, 0.0, size.0 as f32, size.1 as f32);
        let device = self.on_device(entry.rect);
        // Only the region this frame cleared may be composited: blending over the frost's
        // own output would apply it twice, and `damage_band` already grew the band over
        // every frost it reaches, so a frost outside it has nothing to redraw.
        // 只有本帧清空过的区域才能合成：在磨砂自己的旧输出上混合会把它叠两遍，而
        // `damage_band` 已把带长到盖住它触及的每一块磨砂，落在带外的磨砂因此无事可做。
        let Some(clip) = self.backdrop_visible(&entry).and_then(|r| r.intersection(full)) else {
            return Ok(());
        };
        let Some(clip) = (match band_rect(band) {
            Some(b) => clip.intersection(b),
            None => Some(clip),
        }) else {
            return Ok(());
        };
        let scissor = device_scissor(clip, 1.0);
        if scissor[2] <= 0 || scissor[3] <= 0 {
            return Ok(());
        }

        let material = resolve(entry.material, self.material);
        // The kit lens carries its own mip chain on its capture, so no material reads this
        // frame below level 0 any more; every one of them samples it at level 0.
        // kit 透镜的 mip 链长在它自己的捕获上，因此没有材质再从这一帧读 0 级以下，
        // 它们都只在 0 级取样。
        // Sigma is a visual radius: on the finer grid it must widen with the whole grid,
        // which is the display scale times the supersample.
        // sigma 是视觉半径：网格变细，它必须按整个网格的倍数变宽，即显示倍率乘超采样。
        let effect = crate::effect_pass::on_grid(ui_core::effect::Effect::box_blur(entry.sigma), self.scale);
        let bounds = self
            .backdrop_read(&entry)
            .intersection(full)
            .unwrap_or(ui_core::geom::Rect::ZERO);
        let filtered = crate::effect_pass::run(
            &mut self.backdrop_scratch,
            gl,
            &self.effects,
            &self.boxpass,
            src_tex,
            size.0,
            size.1,
            bounds,
            self.target_format,
            &[effect],
            false,
        )?;
        if !composites(material, filtered != src_tex) {
            return Ok(());
        }
        self.stats.frosts += 1;
        self.composite_backdrop(gl, size, dst_fbo, device, scissor, entry, filtered)
    }

    /// Resample the region a lens reads into a texture of its own: `size` times the node's
    /// area at `scale` texels per dp. The shader addresses it by position, not by stretching
    /// the node over it, so the margin is headroom the rim may read — not a zoom.
    /// 把透镜要读的区域重采进它自己的纹理：节点面积的 `size` 倍，每 dp `scale` 个纹素。着色器
    /// 按位置寻址而非把节点铺满纹理，多出的边因此是边缘可读的余量，不是缩放。
    fn lens_capture(
        &mut self,
        gl: &glow::Context,
        src: glow::Texture,
        viewport: (u32, u32),
        device: ui_core::geom::Rect,
        size: f32,
        scale: f32,
    ) -> Result<(glow::Texture, ui_core::geom::Rect), GpuError> {
        let size = size.clamp(0.1, 4.0);
        let scale = scale.clamp(0.02, 4.0);
        let region = ui_core::geom::Rect::new(
            device.origin.x + device.size.w * (1.0 - size) * 0.5,
            device.origin.y + device.size.h * (1.0 - size) * 0.5,
            device.size.w * size,
            device.size.h * size,
        );
        let w = (region.size.w * scale).round().max(1.0) as u32;
        let h = (region.size.h * scale).round().max(1.0) as u32;
        let (fbo, tex) = crate::effect_pass::ensure_target(
            &mut self.capture_target,
            gl,
            w,
            h,
            self.target_format,
        )?;
        let p = &self.capture;
        unsafe {
            gl.bind_framebuffer(glow::FRAMEBUFFER, Some(fbo));
            gl.viewport(0, 0, w as i32, h as i32);
            gl.disable(glow::BLEND);
            gl.disable(glow::SCISSOR_TEST);
            gl.use_program(Some(p.program));
            if let Some(u) = &p.uniforms.viewport {
                gl.uniform_2_f32(Some(u), w as f32, h as f32);
            }
            if let Some(u) = &p.uniforms.src {
                gl.active_texture(glow::TEXTURE0);
                gl.bind_texture(glow::TEXTURE_2D, Some(src));
                gl.uniform_1_i32(Some(u), 0);
            }
            if let Some(u) = &p.uniforms.region {
                gl.uniform_4_f32(
                    Some(u),
                    region.origin.x / viewport.0 as f32,
                    region.origin.y / viewport.1 as f32,
                    region.size.w / viewport.0 as f32,
                    region.size.h / viewport.1 as f32,
                );
            }
            gl.bind_vertex_array(Some(p.vao));
            let quad: [f32; 4] = [0.0, 0.0, w as f32, h as f32];
            gl.bind_buffer(glow::ARRAY_BUFFER, Some(p.instance_vbo));
            gl.buffer_data_u8_slice(glow::ARRAY_BUFFER, as_bytes(&quad), glow::DYNAMIC_DRAW);
            gl.draw_arrays_instanced(glow::TRIANGLES, 0, 6, 1);
            // The rim compresses many capture texels into one pixel, so the capture carries a
            // chain: the face still reads level 0, where the tap is already exact.
            // 边缘把许多捕获纹素压进一个像素，捕获因此自带 mip 链；面仍读 0 级，那里的取样本就精确。
            // The chain is built with the capture's framebuffer released: GL leaves the result
            // undefined while the texture is still attached to the bound draw framebuffer.
            // 建链前先解绑捕获的帧缓冲：纹理仍挂在已绑定的绘制帧缓冲上时，GL 规定结果未定义。
            gl.bind_framebuffer(glow::FRAMEBUFFER, None);
            gl.bind_texture(glow::TEXTURE_2D, Some(tex));
            gl.tex_parameter_i32(
                glow::TEXTURE_2D,
                glow::TEXTURE_MIN_FILTER,
                glow::LINEAR_MIPMAP_LINEAR as i32,
            );
            gl.generate_mipmap(glow::TEXTURE_2D);
        }
        Ok((tex, region))
    }

    /// Write the filtered backdrop back over the node's rect, shaded as the style asks.
    /// 把滤波后的背景写回节点矩形，并按风格要求着色。
    fn composite_backdrop(
        &mut self,
        gl: &glow::Context,
        size: (u32, u32),
        dst_fbo: glow::Framebuffer,
        device: ui_core::geom::Rect,
        scissor: [i32; 4],
        entry: ui_core::draw::BackdropEntry,
        filtered: glow::Texture,
    ) -> Result<(), GpuError> {
        let s = self.scale;
        // A node may name its own material; the renderer-wide one is the default for nodes
        // that only asked for a blur.
        // 节点可以自带材质；渲染器级的那份只作为「只要求模糊」的节点的默认值。
        let material = resolve(entry.material, self.material);
        let shade = Shade::of(material);
        // Without a material this is the plain blit: one texture read with corner coverage.
        // 未装材质时就是纯写回：一次纹理采样加圆角覆盖。
        // The glass reads its own capture, never the live frame: the region it shows,
        // rendered at the density it shows it.
        // 玻璃读自己的捕获而非当帧画面：它显示的区域，按它显示的密度。
        let lens = match material {
            Some(BackdropMaterial::LiquidGlass(k)) => Some(self.lens_capture(
                gl,
                filtered,
                size,
                device,
                k.capture_size,
                k.capture_scale,
            )?),
            _ => None,
        };
        let p = match shade {
            Shade::Plain => &self.layers,
            Shade::Acrylic => &self.acrylic,
            Shade::Liquid => &self.glass_kit,
        };
        unsafe {
            gl.bind_framebuffer(glow::FRAMEBUFFER, Some(dst_fbo));
            gl.viewport(0, 0, size.0 as i32, size.1 as i32);
            gl.enable(glow::SCISSOR_TEST);
            gl.scissor(scissor[0], scissor[1], scissor[2], scissor[3]);
            // Premultiplied blend against the frame: corner coverage is below 1 there, and
            // overwriting would replace opaque pixels with partially transparent ones.
            // 对帧做预乘混合：圆角处覆盖率小于 1，覆盖会把不透明像素换成半透明。
            gl.enable(glow::BLEND);
            gl.blend_func(glow::ONE, glow::ONE_MINUS_SRC_ALPHA);
            gl.use_program(Some(p.program));
            if let Some(u) = p.uniforms.viewport {
                gl.uniform_2_f32(Some(&u), size.0 as f32, size.1 as f32);
            }
            if let Some(u) = p.uniforms.opacity {
                gl.uniform_1_f32(Some(&u), 1.0);
            }
            if let Some(u) = &p.uniforms.layer_rect {
                gl.uniform_4_f32(
                    Some(u),
                    device.origin.x,
                    device.origin.y,
                    device.size.w,
                    device.size.h,
                );
            }
            if let Some(u) = &p.uniforms.layer_radius {
                gl.uniform_4_f32(
                    Some(u),
                    entry.corners.tl * s,
                    entry.corners.tr * s,
                    entry.corners.br * s,
                    entry.corners.bl * s,
                );
            }
            if let Some(u) = &p.uniforms.layer_exp {
                gl.uniform_1_f32(Some(u), entry.corners.shape.exponent());
            }
            if let Some(u) = &p.uniforms.layer_skip_empty {
                gl.uniform_1_f32(Some(u), 0.0);
            }
            if let Some(u) = p.uniforms.layer_tex {
                gl.active_texture(glow::TEXTURE0);
                gl.bind_texture(glow::TEXTURE_2D, Some(filtered));
                gl.uniform_1_i32(Some(&u), 0);
            }
            if let Some(u) = p.uniforms.src {
                gl.active_texture(glow::TEXTURE0);
                gl.bind_texture(glow::TEXTURE_2D, Some(filtered));
                gl.uniform_1_i32(Some(&u), 0);
            }
            match material {
                None | Some(BackdropMaterial::Plain) => {}
                Some(BackdropMaterial::Acrylic(a)) => {
                    if let Some(u) = p.uniforms.tint {
                        gl.uniform_4_f32(Some(&u), a.tint.r, a.tint.g, a.tint.b, a.tint.a);
                    }
                    if let Some(u) = p.uniforms.luminosity {
                        gl.uniform_4_f32(
                            Some(&u),
                            a.luminosity.r,
                            a.luminosity.g,
                            a.luminosity.b,
                            a.luminosity.a,
                        );
                    }
                    if let Some(u) = p.uniforms.noise {
                        gl.uniform_1_f32(Some(&u), a.noise);
                    }
                }
                Some(BackdropMaterial::LiquidGlass(k)) => {
                    if let Some(u) = p.uniforms.body {
                        gl.uniform_4_f32(
                            Some(&u),
                            k.body.mix,
                            k.body.pole,
                            k.body.chroma,
                            k.body.tone,
                        );
                    }
                    if let Some(u) = p.uniforms.glass {
                        gl.uniform_4_f32(Some(&u), k.tint.r, k.tint.g, k.tint.b, k.tint.a);
                    }
                    // The glass measures its thickness in dp, as the reference does.
                    // 玻璃的厚度按 dp 计量，与参考一致。
                    if let Some(u) = p.uniforms.optical {
                        gl.uniform_4_f32(
                            Some(&u),
                            k.refractive_index,
                            k.dispersion,
                            k.thickness,
                            k.magnification,
                        );
                    }
                    if let Some(u) = p.uniforms.light {
                        gl.uniform_4_f32(
                            Some(&u),
                            k.glare_intensity,
                            k.glare_distance,
                            k.glare_sharpness,
                            k.glare_offset,
                        );
                    }
                    if let Some(u) = p.uniforms.kit {
                        gl.uniform_4_f32(
                            Some(&u),
                            k.fresnel_intensity,
                            k.fresnel_distance,
                            k.fresnel_sharpness,
                            k.glare_convergence,
                        );
                    }
                    if let Some(u) = p.uniforms.blend {
                        gl.uniform_4_f32(
                            Some(&u),
                            k.blend_count as f32,
                            k.blend_k * s,
                            k.glare_bias,
                            s,
                        );
                    }
                    if let Some((tex, rect)) = lens {
                        if let Some(u) = p.uniforms.src {
                            gl.active_texture(glow::TEXTURE0);
                            gl.bind_texture(glow::TEXTURE_2D, Some(tex));
                            gl.uniform_1_i32(Some(&u), 0);
                        }
                        if let Some(u) = p.uniforms.capture {
                            gl.uniform_4_f32(
                                Some(&u),
                                rect.origin.x,
                                rect.origin.y,
                                rect.size.w,
                                rect.size.h,
                            );
                        }
                    }
                    upload_shapes(gl, p, &k.blend, k.blend_count, device, s);
                }
            }
            // `a_rect.y` is the top in device space, and the quad runs down from there, so
            // the instance must cover the whole frame; coverage() then cuts the node's shape.
            // `a_rect.y` 是设备空间顶部，四边形由此向下延伸，因此实例要覆盖整帧；
            // 再由 coverage() 切出节点形状。
            let data = [0.0f32, 0.0, size.0 as f32, size.1 as f32];
            gl.bind_vertex_array(Some(p.vao));
            gl.bind_buffer(glow::ARRAY_BUFFER, Some(p.instance_vbo));
            gl.buffer_data_u8_slice(glow::ARRAY_BUFFER, as_bytes(&data), glow::DYNAMIC_DRAW);
            gl.draw_arrays_instanced(
                glow::TRIANGLES,
                0,
                crate::shader::UNIT_QUAD.len() as i32 / 2,
                1,
            );
        }
        self.stats.draw_calls += 1;
        if material.is_some() {
            self.stats.material_passes += 1;
        }
        Ok(())
    }

    /// Pop and push layers so the active chain equals `want`.
    /// 弹入弹出层，使活动层链等于 `want`。
    fn sync_layers(
        &mut self,
        gl: &glow::Context,
        list: &DrawList,
        frame: &FrameTargets<'_>,
        chain: &mut Chain,
        want: &[u32],
    ) -> Result<(), GpuError> {
        let viewport = frame.viewport;
        let stack = &mut chain.stack;
        let mut common = 0;
        while common < stack.len() && common < want.len() && stack[common] == want[common] {
            common += 1;
        }
        while stack.len() > common {
            let index = stack.pop().expect("non-empty");
            let depth = stack.len();
            let was_clean = chain.clean.pop().unwrap_or(false);
            let entry = list.layers.get(index as usize);
            let effects = entry.map_or(&[][..], |l| &l.effects[..]);
            let cache = entry.and_then(|l| l.cache_key);
            let composite = match chain.clean.last() {
                Some(&parent_clean) => !parent_clean,
                None => frame_cleared_over(frame.band, self.layer_bounds.get(depth).copied()),
            };
            self.end_layer(
                gl,
                depth,
                effects,
                frame.viewport,
                frame.band,
                Finish {
                    cache,
                    clean: was_clean,
                    composite,
                },
            )?;
        }
        for &index in &want[common..] {
            let depth = stack.len();
            let (w, h) = (viewport.0 as u32, viewport.1 as u32);
            let entry = list.layers.get(index as usize);
            let cache = entry.and_then(|l| l.cache_key);
            let bounds = entry.map_or(ui_core::geom::Rect::new(0.0, 0.0, 0.0, 0.0), |l| l.bounds);
            let corners = entry.map_or(ui_core::geom::Corners::all(0.0), |l| l.radius);
            let s = self.scale;
            // Record the layer's device-space bounds: effects and compositing stop there.
            // 记下层的设备空间边界：效果与合成都到此为止。
            let device = ui_core::geom::Rect::new(
                bounds.origin.x * s,
                bounds.origin.y * s,
                bounds.size.w * s,
                bounds.size.h * s,
            );
            if self.layer_bounds.len() <= depth {
                self.layer_bounds
                    .resize(depth + 1, ui_core::geom::Rect::new(0.0, 0.0, 0.0, 0.0));
            }
            self.layer_bounds[depth] = device;
            if self.layer_radius.len() <= depth {
                self.layer_radius
                    .resize(depth + 1, ui_core::geom::Corners::all(0.0));
            }
            self.layer_radius[depth] = ui_core::geom::Corners {
                tl: corners.tl * s,
                tr: corners.tr * s,
                br: corners.br * s,
                bl: corners.bl * s,
                ..corners
            }
            // A layer is clipped to its own bounds, so the same half-side limit applies.
            // 层会被裁到自身边界，因此同样适用短边一半的上限。
            .clamp_to(device.size);

            // A layer beneath a skipped one is skipped too: its parent holds no pixels this
            // frame, so redrawing it would only land in a target nobody composites.
            // 被跳过的层之下的层也跳过：它父级本帧不含像素，重画只会落进无人合成的目标。
            let parent_clean = chain.clean.last().copied().unwrap_or(false);
            // Asked unconditionally: the lookup also marks the target as used this frame, and
            // a skipped one would otherwise be freed while its canvas is still in the tree.
            // 无条件查询：这次查找同时标记目标本帧被用过，
            // 否则被跳过的目标会在画布仍在树里时被释放。
            let own_clean =
                cache.is_some_and(|key| self.cached_is_clean(gl, key, frame.damage, device, w, h));
            let clean = parent_clean || own_clean;
            if !clean {
                self.begin_layer(gl, depth, w, h)?;
            }
            chain.clean.push(clean);
            stack.push(index);
        }
        Ok(())
    }

    /// Whether the cached target under `key` still holds the pixels `bounds` should show:
    /// it exists, was finished, and no damage landed inside it.
    /// 键 `key` 下的缓存目标是否仍持有 `bounds` 该显示的像素：存在、已完成、且无脏区落入。
    fn cached_is_clean(
        &mut self,
        gl: &glow::Context,
        key: u64,
        damage: &ui_core::damage::Damage,
        bounds: ui_core::geom::Rect,
        width: u32,
        height: u32,
    ) -> bool {
        if !self.cached_targets.contains_key(&key) {
            let Ok(target) = crate::effect_pass::new_target(gl) else {
                return false;
            };
            self.cached_targets.insert(
                key,
                CachedTarget {
                    target,
                    valid: false,
                    last_used: self.frame_serial,
                },
            );
        }
        let Some(slot) = self.cached_targets.get_mut(&key) else {
            return false;
        };
        slot.last_used = self.frame_serial;
        if slot.target.width != width
            || slot.target.height != height
            || slot.target.format != self.target_format
        {
            crate::effect_pass::resize_target(gl, &mut slot.target, width, height, self.target_format);
            slot.valid = false;
        }
        if !slot.valid {
            return false;
        }
        let damaged = match damage {
            ui_core::damage::Damage::None => false,
            ui_core::damage::Damage::Full => true,
            ui_core::damage::Damage::Rects(rects) => rects.iter().any(|r| r.intersects(bounds)),
        };
        !damaged
    }

    fn draw_rects(
        &mut self,
        gl: &glow::Context,
        viewport: (f32, f32),
        data: &[f32],
        clip: Option<ui_core::draw::ClipEntry>,
    ) -> Result<(), GpuError> {
                let p = &self.rects;
        unsafe {
            gl.use_program(Some(p.program));
            if let Some(u) = p.uniforms.viewport {
                gl.uniform_2_f32(Some(&u), viewport.0, viewport.1);
            }
            set_clip_uniforms(gl, p, clip, self.scale);
            gl.bind_vertex_array(Some(p.vao));
            gl.bind_buffer(glow::ARRAY_BUFFER, Some(p.instance_vbo));
            gl.buffer_data_u8_slice(
                glow::ARRAY_BUFFER,
                as_bytes(data),
                glow::DYNAMIC_DRAW,
            );
            gl.draw_arrays_instanced(
                glow::TRIANGLES,
                0,
                shader::UNIT_QUAD.len() as i32 / 2,
                (data.len() / shader::RECT_STRIDE as usize) as i32,
            );
        }
        self.stats.rects += (data.len() / shader::RECT_STRIDE as usize) as u32;
        self.stats.draw_calls += 1;
        Ok(())
    }

    fn draw_sectors(
        &mut self,
        gl: &glow::Context,
        viewport: (f32, f32),
        data: &[f32],
        clip: Option<ui_core::draw::ClipEntry>,
    ) -> Result<(), GpuError> {
        let p = &self.sectors;
        unsafe {
            gl.use_program(Some(p.program));
            if let Some(u) = p.uniforms.viewport {
                gl.uniform_2_f32(Some(&u), viewport.0, viewport.1);
            }
            set_clip_uniforms(gl, p, clip, self.scale);
            gl.bind_vertex_array(Some(p.vao));
            gl.bind_buffer(glow::ARRAY_BUFFER, Some(p.instance_vbo));
            gl.buffer_data_u8_slice(glow::ARRAY_BUFFER, as_bytes(data), glow::DYNAMIC_DRAW);
            gl.draw_arrays_instanced(
                glow::TRIANGLES,
                0,
                shader::UNIT_QUAD.len() as i32 / 2,
                (data.len() / shader::SECTOR_STRIDE as usize) as i32,
            );
        }
        self.stats.draw_calls += 1;
        Ok(())
    }

    fn draw_glyphs(
        &mut self,
        gl: &glow::Context,
        viewport: (f32, f32),
        data: &[f32],
        clip: Option<ui_core::draw::ClipEntry>,
    ) -> Result<(), GpuError> {
        let Some(atlas_tex) = self.atlas_tex else {
            return Ok(());
        };
                let p = &self.glyphs;
        unsafe {
            gl.use_program(Some(p.program));
            if let Some(u) = p.uniforms.viewport {
                gl.uniform_2_f32(Some(&u), viewport.0, viewport.1);
            }
            if let Some(u) = p.uniforms.atlas_size {
                gl.uniform_2_f32(Some(&u), self.atlas_size.0 as f32, self.atlas_size.1 as f32);
            }
            if let Some(u) = p.uniforms.color_atlas_size {
                gl.uniform_2_f32(
                    Some(&u),
                    self.color_atlas_size.0 as f32,
                    self.color_atlas_size.1 as f32,
                );
            }
            if let Some(u) = p.uniforms.atlas {
                gl.active_texture(glow::TEXTURE0);
                gl.bind_texture(glow::TEXTURE_2D, Some(atlas_tex));
                gl.uniform_1_i32(Some(&u), 0);
            }
            if let Some(u) = p.uniforms.color_atlas {
                gl.active_texture(glow::TEXTURE1);
                gl.bind_texture(
                    glow::TEXTURE_2D,
                    Some(self.color_atlas_tex.unwrap_or(atlas_tex)),
                );
                gl.uniform_1_i32(Some(&u), 1);
            }
            set_clip_uniforms(gl, p, clip, self.scale);
            gl.bind_vertex_array(Some(p.vao));
            gl.bind_buffer(glow::ARRAY_BUFFER, Some(p.instance_vbo));
            gl.buffer_data_u8_slice(glow::ARRAY_BUFFER, as_bytes(data), glow::DYNAMIC_DRAW);
            gl.draw_arrays_instanced(
                glow::TRIANGLES,
                0,
                shader::UNIT_QUAD.len() as i32 / 2,
                (data.len() / shader::GLYPH_STRIDE as usize) as i32,
            );
        }
        self.stats.glyphs += (data.len() / shader::GLYPH_STRIDE as usize) as u32;
        self.stats.draw_calls += 1;
        Ok(())
    }

    /// Upload the frame's textures, reusing one GL texture per `ImageEntry::id`.
    /// 上传本帧的纹理，每个 `ImageEntry::id` 复用一个 GL 纹理。
    fn sync_images(&mut self, gl: &glow::Context, list: &DrawList) -> Result<(), GpuError> {
        self.frame_images.clear();
        for entry in &list.images {
            let cached = self.image_textures.get(&entry.id);
            let sized = cached.filter(|c| c.width == entry.width && c.height == entry.height);
            let img = match sized {
                Some(c) => FrameImage {
                    tex: c.tex,
                    width: c.width,
                    height: c.height,
                },
                None => {
                    let tex = match cached {
                        Some(c) => c.tex,
                        None => unsafe { gl.create_texture()? },
                    };
                    upload_image(gl, tex, entry)?;
                    self.image_textures.insert(
                        entry.id,
                        ImageTexture {
                            tex,
                            width: entry.width,
                            height: entry.height,
                        },
                    );
                    self.stats.image_uploads += 1;
                    FrameImage {
                        tex,
                        width: entry.width,
                        height: entry.height,
                    }
                }
            };
            self.frame_images.push(img);
        }
        // Free ids this frame does not name: an app that mints an id per frame must not leak.
        // 释放本帧未出现的 id：逐帧新建 id 的应用不得泄漏。
        let live: HashSet<u64> = list.images.iter().map(|e| e.id).collect();
        self.image_textures.retain(|id, t| {
            let keep = live.contains(id);
            if !keep {
                unsafe { gl.delete_texture(t.tex) };
            }
            keep
        });
        Ok(())
    }

    fn draw_images(
        &mut self,
        gl: &glow::Context,
        viewport: (f32, f32),
        data: &[f32],
        texture: glow::Texture,
        clip: Option<ui_core::draw::ClipEntry>,
    ) -> Result<(), GpuError> {
        let p = &self.images;
        unsafe {
            gl.use_program(Some(p.program));
            if let Some(u) = p.uniforms.viewport {
                gl.uniform_2_f32(Some(&u), viewport.0, viewport.1);
            }
            if let Some(u) = p.uniforms.image {
                gl.active_texture(glow::TEXTURE0);
                gl.bind_texture(glow::TEXTURE_2D, Some(texture));
                gl.uniform_1_i32(Some(&u), 0);
            }
            set_clip_uniforms(gl, p, clip, self.scale);
            gl.bind_vertex_array(Some(p.vao));
            gl.bind_buffer(glow::ARRAY_BUFFER, Some(p.instance_vbo));
            gl.buffer_data_u8_slice(glow::ARRAY_BUFFER, as_bytes(data), glow::DYNAMIC_DRAW);
            gl.draw_arrays_instanced(
                glow::TRIANGLES,
                0,
                shader::UNIT_QUAD.len() as i32 / 2,
                (data.len() / shader::IMAGE_STRIDE as usize) as i32,
            );
        }
        self.stats.images_drawn += (data.len() / shader::IMAGE_STRIDE as usize) as u32;
        self.stats.draw_calls += 1;
        Ok(())
    }

    fn draw_shadows(
        &mut self,
        gl: &glow::Context,
        viewport: (f32, f32),
        data: &[f32],
        clip: Option<ui_core::draw::ClipEntry>,
    ) -> Result<(), GpuError> {
        let p = &self.shadows;
        unsafe {
            gl.use_program(Some(p.program));
            if let Some(u) = p.uniforms.viewport {
                gl.uniform_2_f32(Some(&u), viewport.0, viewport.1);
            }
            set_clip_uniforms(gl, p, clip, self.scale);
            gl.bind_vertex_array(Some(p.vao));
            gl.bind_buffer(glow::ARRAY_BUFFER, Some(p.instance_vbo));
            gl.buffer_data_u8_slice(glow::ARRAY_BUFFER, as_bytes(data), glow::DYNAMIC_DRAW);
            gl.draw_arrays_instanced(
                glow::TRIANGLES,
                0,
                shader::UNIT_QUAD.len() as i32 / 2,
                (data.len() / shader::SHADOW_STRIDE as usize) as i32,
            );
        }
        self.stats.shadows_drawn += (data.len() / shader::SHADOW_STRIDE as usize) as u32;
        self.stats.draw_calls += 1;
        Ok(())
    }

    /// Wrap mode of the cached texture for `id`; `None` when it is not resident.
    /// 该 `id` 缓存纹理的环绕模式；不在缓存中时为 `None`。
    pub fn image_wrap(&self, gl: &glow::Context, id: u64) -> Option<(i32, i32)> {
        let t = self.image_textures.get(&id)?;
        unsafe {
            gl.bind_texture(glow::TEXTURE_2D, Some(t.tex));
            let s = gl.get_tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_WRAP_S);
            let v = gl.get_tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_WRAP_T);
            gl.bind_texture(glow::TEXTURE_2D, None);
            Some((s, v))
        }
    }

    /// Read layer `depth` back, for diagnosing compositing.
    /// 回读第 `depth` 层，用于诊断合成。
    pub fn read_layer(&self, gl: &glow::Context, depth: usize) -> Option<(u32, u32, Vec<u8>)> {
        let slot = self.layer_targets.get(depth)?;
                let (w, h) = (slot.width, slot.height);
        let mut buf = vec![0u8; (w as usize) * (h as usize) * 4];
        unsafe {
            gl.bind_framebuffer(glow::FRAMEBUFFER, Some(slot.fbo));
            gl.read_pixels(
                0,
                0,
                w as i32,
                h as i32,
                glow::RGBA,
                glow::UNSIGNED_BYTE,
                glow::PixelPackData::Slice(Some(&mut buf)),
            );
            gl.bind_framebuffer(glow::FRAMEBUFFER, None);
        }
        Some((w, h, buf))
    }

    /// The persistent frame's raw pixels, for comparing one frame against the next.
    /// 持久帧的原始像素，用于把一帧与下一帧相比。
    pub fn frame_pixels(&self, gl: &glow::Context) -> Option<(u32, u32, Vec<u8>)> {
        let frame = self.frame.as_ref()?;
        let (w, h) = (frame.width, frame.height);
        let mut buf = vec![0u8; (w as usize) * (h as usize) * 4];
        unsafe {
            gl.bind_framebuffer(glow::FRAMEBUFFER, Some(frame.fbo));
            gl.read_pixels(0, 0, w as i32, h as i32, glow::RGBA, glow::UNSIGNED_BYTE,
                glow::PixelPackData::Slice(Some(&mut buf)));
            gl.bind_framebuffer(glow::FRAMEBUFFER, None);
        }
        Some((w, h, buf))
    }

    /// Pixels where the persistent frame and `target` disagree, with their bounding box.
    /// 持久帧与 `target` 不一致的像素，以及它们的包围盒。
    ///
    /// A presented buffer promises the whole surface (`Damage::Full`), so it must match.
    /// 交出的缓冲承诺了整面内容（`Damage::Full`），因此必须与持久帧逐像素相同。
    pub fn diff_frame(
        &self,
        gl: &glow::Context,
        target: &dyn GpuSurface,
    ) -> Option<(u64, [u32; 4])> {
        let frame = self.frame.as_ref()?;
        let (w, h) = target.size();
        if (frame.width, frame.height) != (w, h) {
            return None;
        }
        let bytes = (w as usize) * (h as usize) * 4;
        let mut want = vec![0u8; bytes];
        let mut got = vec![0u8; bytes];
        unsafe {
            gl.bind_framebuffer(glow::FRAMEBUFFER, Some(frame.fbo));
            gl.read_pixels(0, 0, w as i32, h as i32, glow::RGBA, glow::UNSIGNED_BYTE,
                glow::PixelPackData::Slice(Some(&mut want)));
            target.bind(gl);
            gl.read_pixels(0, 0, w as i32, h as i32, glow::RGBA, glow::UNSIGNED_BYTE,
                glow::PixelPackData::Slice(Some(&mut got)));
            gl.bind_framebuffer(glow::FRAMEBUFFER, None);
        }
        let mut count = 0u64;
        let (mut x0, mut y0, mut x1, mut y1) = (u32::MAX, u32::MAX, 0u32, 0u32);
        for (i, (a, b)) in want.as_chunks::<4>().0.iter().zip(got.as_chunks::<4>().0).enumerate() {
            if a != b {
                count += 1;
                let (x, y) = (i as u32 % w, i as u32 / w);
                x0 = x0.min(x);
                y0 = y0.min(y);
                x1 = x1.max(x);
                y1 = y1.max(y);
            }
        }
        Some((count, [x0, y0, x1, y1]))
    }

    /// Block until the GPU has finished writing to the target.
    /// 阻塞到 GPU 完成对目标的写入。
    ///
    /// A dma-buf handed to another process needs the writes completed first;
    /// without this the compositor can sample the buffer before the GPU is done.
    /// 交给另一个进程的 dma-buf 必须先完成写入；否则 compositor 可能在 GPU 完成前采样。
    pub fn finish(&self, gl: &glow::Context) {
        unsafe { gl.finish() };
    }

    /// Convert straight-alpha RGBA8 into the premultiplied BGRA that `ui_paint::Pixels` holds.
    /// 把直通 alpha 的 RGBA8 转成 `ui_paint::Pixels` 使用的预乘 BGRA。
    ///
    /// `read_pixels` and `Pixels` disagree on *both* channel order and alpha convention;
    /// this function exists so callers stop re-deriving it wrongly.
    /// `read_pixels` 与 `Pixels` 在通道序和 alpha 约定上**都**不同；
    /// 这个函数的存在就是为了让调用方不必再各自推错一遍。
    pub fn to_premultiplied_bgra(straight_rgba: &[u8]) -> Vec<u8> {
        let mut out = Vec::with_capacity(straight_rgba.len());
        for p in straight_rgba.as_chunks::<4>().0 {
            let a = p[3] as u32;
            let pm = |c: u8| ((c as u32 * a + 127) / 255) as u8;
            out.extend_from_slice(&[pm(p[2]), pm(p[1]), pm(p[0]), p[3]]);
        }
        out
    }

    /// Read the target back as top-down straight-alpha RGBA8.
    /// 把目标读回为自顶向下、直通 alpha 的 RGBA8。
    pub fn read_pixels(&self, gl: &glow::Context, target: &dyn GpuSurface) -> Result<Vec<u8>, GpuError> {
        target.bind(gl);
                let w = target.size().0 as usize;
        let h = target.size().1 as usize;
        let mut buf = vec![0u8; w * h * 4];
        unsafe {
            gl.read_pixels(
                0,
                0,
                w as i32,
                h as i32,
                glow::RGBA,
                glow::UNSIGNED_BYTE,
                glow::PixelPackData::Slice(Some(&mut buf)),
            );
        }
        // Rendering already writes top-down rows, so only premultiplication has to
        // be undone here.
        // 渲染已按自顶向下行序写入，这里只需还原非预乘。
        let mut out = vec![0u8; w * h * 4];
        for y in 0..h {
            let src = y * w * 4;
            let dst = y * w * 4;
            for x in 0..w {
                let s = src + x * 4;
                let d = dst + x * 4;
                let a = buf[s + 3] as u32;
                if a == 0 {
                    continue;
                }
                if a == 255 {
                    out[d..d + 4].copy_from_slice(&buf[s..s + 4]);
                } else {
                    // Un-premultiply so callers see straight alpha.
                    // 还原非预乘，使调用方看到直通 alpha。
                    for c in 0..3 {
                        out[d + c] = ((buf[s + c] as u32 * 255 + a / 2) / a).min(255) as u8;
                    }
                    out[d + 3] = a as u8;
                }
            }
        }
        Ok(out)
    }

    /// Free GL objects. Must be called while `ctx` is current.
    /// 释放 GL 对象。必须在 `ctx` 为当前上下文时调用。
    pub fn release(&self, gl: &glow::Context) {
                unsafe {
            for p in [
                &self.rects,
                &self.sectors,
                &self.glyphs,
                &self.images,
                &self.shadows,
            ] {
                gl.delete_program(p.program);
                gl.delete_vertex_array(p.vao);
                gl.delete_buffer(p.unit_vbo);
                gl.delete_buffer(p.instance_vbo);
            }
            for t in self.image_textures.values() {
                gl.delete_texture(t.tex);
            }
            if let Some(t) = self.atlas_tex {
                gl.delete_texture(t);
            }
            if let Some(t) = self.color_atlas_tex {
                gl.delete_texture(t);
            }
        }
    }
}

impl Program {
    fn new(
        gl: &glow::Context,
        is_gles: bool,
        vertex: &str,
        fragment: &str,
        stride: i32,
        instance_attribs: &[(&str, i32)],
        required_uniforms: &[&str],
    ) -> Result<Self, GpuError> {
        let program = compile_program(gl, vertex, fragment, is_gles)?;
        unsafe {
            let vao = gl.create_vertex_array()?;
            gl.bind_vertex_array(Some(vao));

            let unit_vbo = gl.create_buffer()?;
            gl.bind_buffer(glow::ARRAY_BUFFER, Some(unit_vbo));
            gl.buffer_data_u8_slice(
                glow::ARRAY_BUFFER,
                as_bytes(&shader::UNIT_QUAD),
                glow::STATIC_DRAW,
            );
            let unit_loc = gl.get_attrib_location(program, "a_unit");
            if let Some(loc) = unit_loc {
                gl.enable_vertex_attrib_array(loc);
                gl.vertex_attrib_pointer_f32(loc, 2, glow::FLOAT, false, 8, 0);
            }

            let instance_vbo = gl.create_buffer()?;
            gl.bind_buffer(glow::ARRAY_BUFFER, Some(instance_vbo));
            gl.buffer_data_u8_slice(
                glow::ARRAY_BUFFER,
                as_bytes(&vec![0.0f32; stride as usize * 64]),
                glow::DYNAMIC_DRAW,
            );
            let mut offset = 0i32;
            for (name, size) in instance_attribs {
                if let Some(loc) = gl.get_attrib_location(program, name) {
                    gl.enable_vertex_attrib_array(loc);
                    gl.vertex_attrib_pointer_f32(
                        loc,
                        *size,
                        glow::FLOAT,
                        false,
                        stride * 4,
                        offset * 4,
                    );
                    gl.vertex_attrib_divisor(loc, 1);
                }
                offset += size;
            }

            // A mistyped uniform name yields `None` and then silently does nothing,
            // so a required uniform missing here is a startup error, not a warning.
            // 写错 uniform 名会得到 `None` 并静默失效，因此必需项缺失是启动错误而非警告。
            for name in required_uniforms {
                if gl.get_uniform_location(program, name).is_none() {
                    return Err(GpuError::from(format!(
                        "shader is missing required uniform `{name}`"
                    )));
                }
            }

            let uniforms = Uniforms {
                viewport: gl.get_uniform_location(program, "u_viewport"),
                atlas_size: gl.get_uniform_location(program, "u_atlas_size"),
                atlas: gl.get_uniform_location(program, "u_atlas"),
                color_atlas_size: gl.get_uniform_location(program, "u_color_atlas_size"),
                color_atlas: gl.get_uniform_location(program, "u_color_atlas"),
                image: gl.get_uniform_location(program, "u_image"),
                opacity: gl.get_uniform_location(program, "u_opacity"),
                layer_tex: gl.get_uniform_location(program, "u_layer"),
                clip_rect: gl.get_uniform_location(program, "u_clip_rect"),
                clip_radius: gl.get_uniform_location(program, "u_clip_radius"),
                clip_shape: gl.get_uniform_location(program, "u_clip_shape"),
                clip_on: gl.get_uniform_location(program, "u_clip_on"),
                src: gl.get_uniform_location(program, "u_src"),
                texel: gl.get_uniform_location(program, "u_texel"),
                dir: gl.get_uniform_location(program, "u_dir"),
                taps: gl.get_uniform_location(program, "u_taps"),
                radius: gl.get_uniform_location(program, "u_radius"),
                supersample: gl.get_uniform_location(program, "u_ss"),
                capture: gl.get_uniform_location(program, "u_capture"),
                region: gl.get_uniform_location(program, "u_region"),
                weights: gl.get_uniform_location(program, "u_weights"),
                color: gl.get_uniform_location(program, "u_color"),
                scale: gl.get_uniform_location(program, "u_scale"),
                offset: gl.get_uniform_location(program, "u_offset"),
                gamut: gl.get_uniform_location(program, "u_gamut"),
                layer_rect: gl.get_uniform_location(program, "u_rect"),
                layer_radius: gl.get_uniform_location(program, "u_radius"),
                layer_exp: gl.get_uniform_location(program, "u_exp"),
                layer_skip_empty: gl.get_uniform_location(program, "u_skip_empty"),
                tint: gl.get_uniform_location(program, "u_tint"),
                luminosity: gl.get_uniform_location(program, "u_luminosity"),
                noise: gl.get_uniform_location(program, "u_noise"),
                body: gl.get_uniform_location(program, "u_body"),
                glass: gl.get_uniform_location(program, "u_glass"),
                light: gl.get_uniform_location(program, "u_light"),
                optical: gl.get_uniform_location(program, "u_optical"),
                blend: gl.get_uniform_location(program, "u_blend"),
                kit: gl.get_uniform_location(program, "u_kit"),
                shapes: gl.get_uniform_location(program, "u_shape[0]"),
                shape_radius: gl.get_uniform_location(program, "u_shape_radius[0]"),
            };
            gl.bind_vertex_array(None);
            Ok(Self {
                program,
                vao,
                unit_vbo,
                instance_vbo,
                uniforms,
            })
        }
    }
}

/// Pack one shadow: rect, radius, colour, blur + dy, shape.
/// 打包一个阴影：矩形、圆角、颜色、衰减宽度与偏移、指数。
fn push_shadow(out: &mut Vec<f32>, p: &ShadowPrim, scale: f32) {
    let r = p.rect;
    let (rgb, a) = split_color(p.colour);
    let rad = [
        p.corners.tl * scale,
        p.corners.tr * scale,
        p.corners.br * scale,
        p.corners.bl * scale,
    ];
    // Corners may not exceed half the shorter side, or the SDF folds.
    // 圆角不得超过短边一半，否则 SDF 会折。
    let half = (r.size.w * scale).min(r.size.h * scale) * 0.5;
    let rad: Vec<f32> = rad.iter().map(|v| v.min(half).max(0.0)).collect();
    out.extend_from_slice(&[
        r.origin.x * scale,
        r.origin.y * scale,
        r.size.w * scale,
        r.size.h * scale,
        rad[0],
        rad[1],
        rad[2],
        rad[3],
        rgb[0],
        rgb[1],
        rgb[2],
        a,
        (p.blur * scale).max(0.5),
        p.dy * scale,
        p.corners.shape.exponent(),
        p.ring * scale,
    ]);
}

fn push_rect(out: &mut Vec<f32>, p: &RectPrim, scale: f32) {
    let r = p.rect;
    // Same clamp as the CPU path: a radius over half the short side folds the SDF.
    // 与 CPU 路径同样的夹取：圆角超过短边一半会让 SDF 折叠。
    let radius = p.radius.clamp_to(r.size);
    let (fill, alpha) = split_color(p.fill);
    // Gradient: the far stop plus (axis, enabled). Backends without the shader support
    // fall back to `fill`, which is why `fill` is always the near stop.
    // 渐变：远端色加上（轴，是否启用）。没有该着色器支持的后端回落到 `fill`，
    // 因此 `fill` 始终是近端色。
    let (far, axis, enabled) = match p.gradient {
        Some(g) => {
            let (c, a) = split_color(g.to);
            let axis = match g.axis {
                ui_core::draw::GradientAxis::Vertical => 0.0,
                ui_core::draw::GradientAxis::Horizontal => 1.0,
            };
            ([c[0], c[1], c[2], a], axis, 1.0)
        }
        None => ([0.0; 4], 0.0, 0.0),
    };
    let (border, width) = match p.border {
        Some((c, w)) => {
            let (br, ba) = split_color(c);
            ([br[0], br[1], br[2], ba], w * scale)
        }
        None => ([0.0; 4], 0.0),
    };
    // A stroke gradient reuses the fill's axis: every WinUI elevation border is vertical.
    // 描边渐变复用填充的轴：WinUI 的立面描边全是竖向。
    let (border_far, border_grad) = match p.border_gradient {
        Some(g) => {
            let (c, a) = split_color(g.to);
            ([c[0], c[1], c[2], a], 1.0)
        }
        None => ([0.0; 4], 0.0),
    };
    let fill_stops = p.gradient.map(|g| g.stops).unwrap_or((0.0, 1.0));
    let border_stops = p.border_gradient.map(|g| g.stops).unwrap_or((0.0, 1.0));
    let fill_extent = p.gradient.and_then(|g| g.extent).map(|e| e * scale).unwrap_or(0.0);
    let border_extent = p
        .border_gradient
        .and_then(|g| g.extent)
        .map(|e| e * scale)
        .unwrap_or(0.0);
    // An empty range (`x >= y`) is how the shader sees "no notch", so a missing one sends 0,0.
    let (notch_lo, notch_hi) = match p.notch {
        Some((from, to)) => (from * scale, to * scale),
        None => (0.0, 0.0),
    };
    // Light-theme elevation borders are mirrored; each brush states its own flip.
    let (fill_flip, border_flip) = (
        p.gradient.map(|g| f32::from(g.flip)).unwrap_or(0.0),
        p.border_gradient.map(|g| f32::from(g.flip)).unwrap_or(0.0),
    );
    out.extend_from_slice(&[
        r.origin.x * scale,
        r.origin.y * scale,
        r.size.w * scale,
        r.size.h * scale,
        radius.tl * scale,
        radius.tr * scale,
        radius.br * scale,
        radius.bl * scale,
        fill[0],
        fill[1],
        fill[2],
        alpha,
        border[0],
        border[1],
        border[2],
        border[3],
        border_far[0],
        border_far[1],
        border_far[2],
        border_far[3],
        border_grad,
        radius.shape.exponent(),
        far[0],
        far[1],
        far[2],
        far[3],
        axis,
        enabled,
        fill_stops.0,
        fill_stops.1,
        border_stops.0,
        border_stops.1,
        fill_extent,
        border_extent,
        width,
        notch_lo,
        notch_hi,
        fill_flip,
        border_flip,
    ]);
}

fn push_sector(out: &mut Vec<f32>, p: &ui_core::draw::SectorPrim, scale: f32) {
    let s = &p.sector;
    let (rgb, alpha) = split_color(p.colour);
    // The sweep is normalised here so the shader needs no negative-angle handling.
    // 扫动量在此归一，片元里便不必处理负角。
    let sweep = s.sweep();
    out.extend_from_slice(&[
        s.centre.x * scale,
        s.centre.y * scale,
        s.radius * scale,
        (s.radius - s.thickness).max(0.0) * scale,
        s.trim.0,
        sweep,
        rgb[0],
        rgb[1],
        rgb[2],
        alpha,
        f32::from(s.round_caps),
    ]);
}

fn upload_atlas(
    gl: &glow::Context,
    slot: &mut Option<glow::Texture>,
    width: u32,
    height: u32,
    internal: u32,
    format: u32,
    data: &[u8],
) -> Result<(), GpuError> {
    unsafe {
        let tex = match *slot {
            Some(t) => t,
            None => {
                let t = gl.create_texture()?;
                *slot = Some(t);
                t
            }
        };
        gl.bind_texture(glow::TEXTURE_2D, Some(tex));
        gl.pixel_store_i32(glow::UNPACK_ALIGNMENT, 1);
        gl.tex_image_2d(
            glow::TEXTURE_2D,
            0,
            internal as i32,
            width as i32,
            height as i32,
            0,
            format,
            glow::UNSIGNED_BYTE,
            glow::PixelUnpackData::Slice(Some(data)),
        );
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_MIN_FILTER, glow::NEAREST as i32);
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_MAG_FILTER, glow::NEAREST as i32);
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_WRAP_S, glow::CLAMP_TO_EDGE as i32);
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_WRAP_T, glow::CLAMP_TO_EDGE as i32);
    }
    Ok(())
}

fn push_glyph(out: &mut Vec<f32>, p: &GlyphPrim, scale: f32) {
    let (rgb, alpha) = split_color(p.color);
    out.extend_from_slice(&[
        p.rect.origin.x * scale,
        p.rect.origin.y * scale,
        p.rect.size.w * scale,
        p.rect.size.h * scale,
        p.atlas.origin.x,
        p.atlas.origin.y,
        p.atlas.size.w,
        p.atlas.size.h,
        rgb[0],
        rgb[1],
        rgb[2],
        alpha * p.alpha,
        match p.kind {
            ui_core::draw::GlyphKind::Coverage => 0.0,
            ui_core::draw::GlyphKind::Color => 1.0,
        },
    ]);
}

/// Whether a glyph's device rect touches a device scissor `[x, y, w, h]`.
/// 字形的设备矩形是否碰到设备裁剪框 `[x, y, w, h]`。
fn glyph_hits_scissor(p: &GlyphPrim, scale: f32, scissor: [i32; 4]) -> bool {
    let x0 = (p.rect.origin.x * scale).floor();
    let y0 = (p.rect.origin.y * scale).floor();
    let x1 = ((p.rect.origin.x + p.rect.size.w) * scale).ceil();
    let y1 = ((p.rect.origin.y + p.rect.size.h) * scale).ceil();
    x1 > scissor[0] as f32
        && y1 > scissor[1] as f32
        && x0 < (scissor[0] + scissor[2]) as f32
        && y0 < (scissor[1] + scissor[3]) as f32
}

fn push_image(out: &mut Vec<f32>, p: &ImagePrim, scale: f32, tex: (u32, u32)) {
    let r = p.rect;
    let corners = p.corners.clamp_to(r.size);
    // Normalised source rect; texels are never scaled, only the destination is.
    // 归一化的源矩形；纹素从不缩放，只有目标矩形会。
    let w = tex.0.max(1) as f32;
    let h = tex.1.max(1) as f32;
    let u0 = p.src.origin.x / w;
    let v0 = p.src.origin.y / h;
    let u1 = (p.src.origin.x + p.src.size.w) / w;
    let v1 = (p.src.origin.y + p.src.size.h) / h;
    out.extend_from_slice(&[
        r.origin.x * scale,
        r.origin.y * scale,
        r.size.w * scale,
        r.size.h * scale,
        corners.tl * scale,
        corners.tr * scale,
        corners.br * scale,
        corners.bl * scale,
        u0,
        v0,
        u1,
        v1,
        p.corners.shape.exponent(),
    ]);
}

/// Upload one RGBA8 image with `CLAMP_TO_EDGE`, so a small source sub-rect never tiles.
/// 上传一张 `CLAMP_TO_EDGE` 的 RGBA8 图像，使小的源子矩形绝不平铺。
fn upload_image(gl: &glow::Context, tex: glow::Texture, entry: &ImageEntry) -> Result<(), GpuError> {
    let needed = (entry.width as usize) * (entry.height as usize) * 4;
    if entry.width == 0 || entry.height == 0 || entry.data.len() < needed {
        return Err(GpuError::from(format!(
            "image {} is {}x{} but carries {} bytes (want {needed})",
            entry.id,
            entry.width,
            entry.height,
            entry.data.len()
        )));
    }
    unsafe {
        gl.bind_texture(glow::TEXTURE_2D, Some(tex));
        gl.pixel_store_i32(glow::UNPACK_ALIGNMENT, 1);
        gl.tex_image_2d(
            glow::TEXTURE_2D,
            0,
            glow::RGBA8 as i32,
            entry.width as i32,
            entry.height as i32,
            0,
            glow::RGBA,
            glow::UNSIGNED_BYTE,
            glow::PixelUnpackData::Slice(Some(entry.data.as_slice())),
        );
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_MIN_FILTER, glow::LINEAR as i32);
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_MAG_FILTER, glow::LINEAR as i32);
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_WRAP_S, glow::CLAMP_TO_EDGE as i32);
        gl.tex_parameter_i32(glow::TEXTURE_2D, glow::TEXTURE_WRAP_T, glow::CLAMP_TO_EDGE as i32);
    }
    Ok(())
}

fn split_color(c: Color) -> ([f32; 3], f32) {
    ([c.r, c.g, c.b], c.a)
}

/// Apply a clip: scissor bounds the rect cheaply, the shader handles the rounded shape.
/// 应用裁剪：scissor 廉价地限制矩形，圆角形状由着色器处理。
fn set_clip_uniforms(
    gl: &glow::Context,
    program: &Program,
    clip: Option<ui_core::draw::ClipEntry>,
    scale: f32,
) {
    unsafe {
        // Must run with `program` current: setting a uniform with no program bound is
        // GL_INVALID_OPERATION, and the error then surfaces at an unrelated call.
        // 必须在 `program` 为当前程序时调用：无当前程序时设 uniform 会报
        // GL_INVALID_OPERATION，而错误会在毫不相关的调用处才显现。
        let rounded = clip.is_some_and(|c| !c.corners.is_zero());
        if let Some(u) = program.uniforms.clip_on {
            gl.uniform_1_f32(Some(&u), if rounded { 1.0 } else { 0.0 });
        }
        let Some(c) = clip.filter(|_| rounded) else {
            return;
        };
        // The corners follow the uncut box (`shape`); the scissor still bounds `rect`.
        // 圆角跟随未裁切的盒子（`shape`）；scissor 仍按 `rect` 限制。
        let clamped = c.corners.clamp_to(c.shape.size);
        if let Some(u) = program.uniforms.clip_rect {
            gl.uniform_4_f32(
                Some(&u),
                c.shape.origin.x * scale,
                c.shape.origin.y * scale,
                c.shape.size.w * scale,
                c.shape.size.h * scale,
            );
        }
        if let Some(u) = program.uniforms.clip_radius {
            gl.uniform_4_f32(
                Some(&u),
                clamped.tl * scale,
                clamped.tr * scale,
                clamped.br * scale,
                clamped.bl * scale,
            );
        }
        if let Some(u) = program.uniforms.clip_shape {
            gl.uniform_1_f32(Some(&u), clamped.shape.exponent());
        }
    }
}

static PARTIAL_FRAMES: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
static FULL_FRAMES: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

/// How many frames took the partial path versus the full one.
/// 走局部路径与整帧路径的帧数。
pub fn partial_frames() -> (u64, u64) {
    (
        PARTIAL_FRAMES.load(std::sync::atomic::Ordering::Relaxed),
        FULL_FRAMES.load(std::sync::atomic::Ordering::Relaxed),
    )
}

fn set_scissor(
    gl: &glow::Context,
    clip: Option<ui_core::geom::Rect>,
    scale: f32,
    viewport: (f32, f32),
    band: Option<[i32; 4]>,
) {
    match batch_scissor(clip.map(|r| device_scissor(r, scale)), band) {
        Scissor::Off => unsafe { gl.disable(glow::SCISSOR_TEST) },
        Scissor::Empty => unsafe {
            gl.enable(glow::SCISSOR_TEST);
            gl.scissor(0, 0, 0, 0);
        },
        Scissor::Box(r) => {
            // No Y flip: this renderer maps device y=0 to GL's bottom, which is the same
            // memory row the compositor reads as the image top (see the vertex shader).
            // 不做 Y 翻转：本渲染器把设备 y=0 映射到 GL 底部，而那正是 compositor
            // 当作图像顶部的同一条内存行（见顶点着色器）。
            let _ = viewport;
            unsafe {
                gl.enable(glow::SCISSOR_TEST);
                gl.scissor(r[0], r[1], r[2], r[3]);
            }
        }
    }
}

/// A logical rect as a device scissor: round the *far edge* out, not the size, or a fractional
/// origin drops the last row the rect covers (CPU `clip_to` and Skia's `roundOut` do the same).
/// 逻辑矩形转设备裁剪框：对**远边**取上整而不是对尺寸取上整，否则分数原点会丢掉矩形覆盖的最后一行
/// （CPU 的 `clip_to` 与 Skia 的 `roundOut` 同理）。
/// Two device scissors as one, or `None` when they miss each other.
/// 两个设备裁剪框之交；不相交时为 `None`。
/// What a batch's scissor box has to be.
/// 一个批次的裁剪框应当是什么。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum Scissor {
    /// Clip to nothing.
    /// 不裁剪。
    Off,
    /// Clip to this device box.
    /// 裁到这个设备矩形。
    Box([i32; 4]),
    /// Draw nothing: the batch's clip and the redraw band do not overlap.
    /// 什么都不画：批次裁剪框与重绘带不相交。
    Empty,
}

/// Clip ∩ band. An empty intersection must mean "nothing visible", not "unclipped".
/// 裁剪框 ∩ 重绘带。空交集必须表示"什么都看不见"，而不是"不裁剪"。
pub(crate) fn batch_scissor(
    clip: Option<[i32; 4]>,
    band: Option<[i32; 4]>,
) -> Scissor {
    match (clip, band) {
        (Some(c), Some(b)) => match intersect_scissor(c, b) {
            Some(r) => Scissor::Box(r),
            None => Scissor::Empty,
        },
        (Some(c), None) => Scissor::Box(c),
        (None, Some(b)) => Scissor::Box(b),
        (None, None) => Scissor::Off,
    }
}

fn intersect_scissor(a: [i32; 4], b: [i32; 4]) -> Option<[i32; 4]> {
    let x0 = a[0].max(b[0]);
    let y0 = a[1].max(b[1]);
    let x1 = (a[0] + a[2]).min(b[0] + b[2]);
    let y1 = (a[1] + a[3]).min(b[1] + b[3]);
    (x1 > x0 && y1 > y0).then(|| [x0, y0, x1 - x0, y1 - y0])
}

/// Grow a repaint band until it covers every frost whose reach it touches.
/// 把重绘带长大到盖住它触及的每一块磨砂。
///
/// A union built from a band snapshot taken earlier in the pass can be *smaller* than the band
/// now, so two frosts reaching each other pull it back and forth for ever. Every union reads
/// the band as it stands, and the pass count is capped by the chain of frosts.
/// 用本趟开头取的带快照做并集，可能比此刻的带更小，互相触及的两块磨砂因此会把带来回拉扯
/// 到永远。每次并集都读当下的带，趟数由磨砂的链长封顶。
fn cover_frosts(
    mut b: [i32; 4],
    frosts: &[(ui_core::geom::Rect, ui_core::geom::Rect)],
) -> [i32; 4] {
    for _ in 0..=frosts.len() {
        let mut grew = false;
        for (read, vis) in frosts {
            let band = rect_of(b);
            if !read.intersects(band) {
                continue;
            }
            let merged = device_scissor(band.union(*vis), 1.0);
            if merged != b {
                b = merged;
                grew = true;
            }
        }
        if !grew {
            return b;
        }
    }
    debug_assert!(false, "a band must settle within one pass per frost");
    b
}

pub(crate) fn device_scissor(r: ui_core::geom::Rect, scale: f32) -> [i32; 4] {
    let x0 = (r.origin.x * scale).floor().max(0.0);
    let y0 = (r.origin.y * scale).floor().max(0.0);
    let x1 = ((r.origin.x + r.size.w) * scale).ceil().max(0.0);
    let y1 = ((r.origin.y + r.size.h) * scale).ceil().max(0.0);
    [x0 as i32, y0 as i32, (x1 - x0) as i32, (y1 - y0) as i32]
}

/// Union of two device rects, clamped to `size`.
/// 两个设备矩形的并集，并夹到 `size` 之内。
pub(crate) fn union_device(a: [i32; 4], b: [i32; 4], size: (u32, u32)) -> [i32; 4] {
    let x0 = a[0].min(b[0]);
    let y0 = a[1].min(b[1]);
    let x1 = (a[0] + a[2]).max(b[0] + b[2]).min(size.0 as i32);
    let y1 = (a[1] + a[3]).max(b[1] + b[3]).min(size.1 as i32);
    [x0, y0, (x1 - x0).max(0), (y1 - y0).max(0)]
}

pub(crate) fn as_bytes(data: &[f32]) -> &[u8] {
    unsafe { std::slice::from_raw_parts(data.as_ptr() as *const u8, std::mem::size_of_val(data)) }
}

fn compile_program(
    gl: &glow::Context,
    vertex: &str,
    fragment: &str,
    is_gles: bool,
) -> Result<glow::Program, GpuError> {
    let header = if is_gles { "#version 300 es\n" } else { "#version 330\n" };
    unsafe {
        let program = gl.create_program()?;
        let mut shaders = Vec::new();
        for (kind, src) in [
            (glow::VERTEX_SHADER, vertex),
            (glow::FRAGMENT_SHADER, fragment),
        ] {
            let shader = gl.create_shader(kind)?;
            // `AA` is spliced into every program from one definition, so the vertex
            // expansion and the fragment ramp cannot drift apart.
            // `AA` 由同一份定义拼进每个程序，顶点外扩与片元渐变因此不会走偏。
            gl.shader_source(shader, &format!("{header}{}", shader::splice(src, shader::AA_GLSL)));
            gl.compile_shader(shader);
            if !gl.get_shader_compile_status(shader) {
                let log = gl.get_shader_info_log(shader);
                gl.delete_shader(shader);
                return Err(GpuError::Gl(format!("shader compile: {log}")));
            }
            gl.attach_shader(program, shader);
            shaders.push(shader);
        }
        gl.link_program(program);
        if !gl.get_program_link_status(program) {
            let log = gl.get_program_info_log(program);
            return Err(GpuError::Gl(format!("program link: {log}")));
        }
        for shader in shaders {
            gl.detach_shader(program, shader);
            gl.delete_shader(shader);
        }
        Ok(program)
    }
}

#[cfg(test)]
mod tests {

    /// Two frosts that reach each other must settle, not pull the band back and forth.
    /// 互相触及的两块磨砂必须收敛，而不是把带来回拉扯。
    #[test]
    fn a_band_shared_by_two_reaching_frosts_settles() {
        let left = (ui_core::geom::Rect::new(722.0, 462.0, 350.0, 256.0),
                    ui_core::geom::Rect::new(772.0, 512.0, 250.0, 156.0));
        let right = (ui_core::geom::Rect::new(1020.0, 486.0, 302.0, 208.0),
                     ui_core::geom::Rect::new(1046.0, 512.0, 250.0, 156.0));
        assert_eq!(
            cover_frosts([1046, 512, 522, 342], &[left, right]),
            [772, 512, 796, 342]
        );
    }
    use super::*;
    use ui_core::geom::{Color, Corners, Rect};

    /// Slot offsets in a rect instance, in the order `push_rect` writes them.
    /// 矩形实例里的槽位偏移，顺序与 `push_rect` 的写入顺序一致。
    const RECT_BORDER: usize = 12;
    const RECT_BORDER_W: usize = 34;
    const RECT_NOTCH: usize = 35;

    fn rect_prim(fill: Color) -> RectPrim {
        RectPrim {
            rect: Rect::new(10.0, 20.0, 30.0, 40.0),
            radius: Corners::all(4.0),
            fill,
            gradient: None,
            border: None,
            border_gradient: None,
            notch: None,
        }
    }

    fn acrylic() -> ui_core::draw::Acrylic {
        ui_core::draw::Acrylic {
            tint: Color::from_rgba8(252, 252, 252, 0),
            luminosity: Color::from_rgba8(252, 252, 252, 217),
            noise: 0.02,
        }
    }

    fn glass() -> ui_core::draw::LiquidGlass {
        ui_core::draw::LiquidGlass {
            body: ui_core::draw::GlassBody::CLEAR,
            tint: Color::TRANSPARENT,
            refractive_index: 1.11,
            thickness: 10.0,
            capture_size: 1.0,
            capture_scale: 1.0,
            magnification: 1.0,
            frost: 0.0,
            dispersion: 5.0,
            fresnel_intensity: 0.0,
            fresnel_distance: 70.0,
            fresnel_sharpness: 0.0,
            glare_intensity: 0.01,
            glare_distance: 30.0,
            glare_sharpness: -0.2,
            glare_convergence: 0.0,
            glare_bias: 0.0,
            glare_offset: 0.0,
            blend: [ui_core::draw::BlendShape::NONE; ui_core::draw::BLEND_SHAPES],
            blend_count: 0,
            blend_k: 0.0,
        }
    }

    #[test]
    fn a_material_with_no_blur_still_composites() {
        // A clear lens frosts nothing, so the effect pass returns the frame untouched; the
        // lens is still the whole picture and skipping it erases the surface.
        // 通透透镜不磨砂，效果趟原样返回帧；透镜本身就是全部画面，跳过它等于抹掉表面。
        let lens = Some(BackdropMaterial::LiquidGlass(glass()));
        assert!(composites(lens, false), "a clear lens must still shade");
        assert!(composites(Some(BackdropMaterial::Plain), true), "a blur must land");
        assert!(!composites(Some(BackdropMaterial::Plain), false));
        assert!(!composites(None, false));
    }

    #[test]
    fn a_node_that_names_its_material_is_shaded_by_that_material() {
        // Per-node material is the point of `BackdropEntry::material`: a Fluent panel and a
        // glass pill in one frame must not have to share one choice.
        // 按节点选材质正是 `BackdropEntry::material` 的意义：同一帧里的 Fluent 面板与玻璃胶囊
        // 不必共用一种。
        let default = Some(BackdropMaterial::Acrylic(acrylic()));
        assert_eq!(
            Shade::of(resolve(BackdropMaterial::LiquidGlass(glass()), default)),
            Shade::Liquid,
            "the node's own material wins"
        );
        assert_eq!(
            Shade::of(resolve(BackdropMaterial::Plain, default)),
            Shade::Acrylic,
            "a plain entry takes the default"
        );
    }

    #[test]
    fn a_plain_entry_leaves_the_blur_untouched_when_no_default_is_set() {
        // `Plain` means "I only asked for a blur": the renderer-wide material applies if one
        // was set, otherwise the blur is written back as-is.
        // `Plain` 意为「我只要求模糊」：设了渲染器级材质就套用，否则模糊结果原样写回。
        assert_eq!(resolve(BackdropMaterial::Plain, None), None);
        assert_eq!(Shade::of(None), Shade::Plain);
        assert_eq!(Shade::of(Some(BackdropMaterial::Plain)), Shade::Plain);
    }

    #[test]
    fn rect_instance_matches_the_shader_stride() {
        let mut out = Vec::new();
        push_rect(&mut out, &rect_prim(Color::from_rgba8(255, 0, 0, 255)), 1.0);
        assert_eq!(
            out.len(),
            shader::RECT_STRIDE as usize,
            "shader declares {0} floats per instance",
            shader::RECT_STRIDE
        );
    }

    #[test]
    fn rect_instance_fields_land_at_the_shader_offsets() {
        let mut out = Vec::new();
        push_rect(
            &mut out,
            &rect_prim(Color::from_rgba8(51, 102, 153, 204)),
            1.0,
        );
        // Layout: rect(0..4), radius(4..8), fill(8..12), border(12..16).
        // 布局：矩形(0..4)、圆角(4..8)、填充(8..12)、边框(12..16)。
        assert_eq!(&out[0..4], &[10.0, 20.0, 30.0, 40.0]);
        assert_eq!(&out[4..8], &[4.0, 4.0, 4.0, 4.0]);
        let c = Color::from_rgba8(51, 102, 153, 204);
        assert_eq!(&out[8..12], &[c.r, c.g, c.b, c.a]);
    }

    fn sector_prim(trim: (f32, f32)) -> ui_core::draw::SectorPrim {
        ui_core::draw::SectorPrim {
            bounds: ui_core::geom::Rect::new(0.0, 0.0, 32.0, 32.0),
            colour: Color::from_rgba8(0, 120, 212, 255),
            sector: ui_core::draw::Sector {
                centre: ui_core::geom::Point::new(16.0, 16.0),
                radius: 14.0,
                thickness: 2.0,
                trim,
                round_caps: true,
            },
        }
    }

    #[test]
    fn sector_instance_matches_the_shader_stride_and_offsets() {
        let mut out = Vec::new();
        push_sector(&mut out, &sector_prim((0.0, 0.25)), 2.0);
        assert_eq!(
            out.len(),
            shader::SECTOR_STRIDE as usize,
            "shader declares {0} floats per instance",
            shader::SECTOR_STRIDE
        );
        // Layout: centre(0..2), geometry(2..6), fill(6..10), caps(10).
        // 布局：圆心(0..2)、几何(2..6)、填充(6..10)、帽(10)。
        assert_eq!(&out[0..2], &[32.0, 32.0], "centre and radius scale");
        assert_eq!(out[2], 28.0, "outer radius scales");
        assert_eq!(out[3], 24.0, "the stroke grows inwards");
        assert_eq!(&out[4..6], &[0.0, 0.25], "turns do not scale");
        assert_eq!(out[10], 1.0);
    }

    #[test]
    fn a_full_turn_reaches_the_shader_as_one_whole_sweep() {
        let mut out = Vec::new();
        push_sector(&mut out, &sector_prim((0.0, 1.0)), 1.0);
        assert_eq!(out[5], 1.0, "a full turn must not fold to zero");
    }

    #[test]
    fn a_wrapping_sweep_is_normalised_before_the_shader_sees_it() {
        let mut out = Vec::new();
        push_sector(&mut out, &sector_prim((0.75, 0.25)), 1.0);
        assert_eq!(out[5], 0.5, "a sweep across zero turns stays positive");
    }

    #[test]
    fn rect_instance_scales_geometry_but_not_colour() {
        let mut a = Vec::new();
        push_rect(&mut a, &rect_prim(Color::from_rgba8(255, 0, 0, 255)), 1.0);
        let mut b = Vec::new();
        push_rect(&mut b, &rect_prim(Color::from_rgba8(255, 0, 0, 255)), 2.0);
        // Geometry doubles.
        // 几何尺寸翻倍。
        assert_eq!(&b[0..4], &[20.0, 40.0, 60.0, 80.0]);
        // Colour is scale-invariant.
        // 颜色与缩放无关。
        assert_eq!(&a[8..12], &b[8..12]);
    }

    #[test]
    fn border_colour_and_width_land_in_separate_slots() {
        let mut out = Vec::new();
        let mut prim = rect_prim(Color::from_rgba8(0, 0, 0, 255));
        let border = Color::from_rgba8(255, 128, 0, 200);
        prim.border = Some((border, 3.0));
        push_rect(&mut out, &prim, 2.0);
        // A width folded into the alpha slot makes the shader read `rgb * width` as the colour.
        // 把宽度折进 alpha 槽会让着色器把 `rgb * width` 当作颜色。
        assert_eq!(&out[RECT_BORDER..RECT_BORDER + 4], &[border.r, border.g, border.b, border.a]);
        assert_eq!(out[RECT_BORDER_W], 3.0 * 2.0, "border width must be scaled");
    }

    #[test]
    fn the_notch_travels_scaled_and_absent_sends_an_empty_range() {
        let mut out = Vec::new();
        let mut prim = rect_prim(Color::WHITE);
        prim.notch = Some((4.0, 12.0));
        push_rect(&mut out, &prim, 2.0);
        assert_eq!(&out[RECT_NOTCH..RECT_NOTCH + 2], &[8.0, 24.0], "the gap is device-space geometry");
        // The shader reads `x >= y` as no notch, so a missing one must not be (0, w).
        // 着色器把 `x >= y` 读作无缺口，因此缺省值不能是 (0, w)。
        out.clear();
        prim.notch = None;
        push_rect(&mut out, &prim, 2.0);
        assert_eq!(&out[RECT_NOTCH..RECT_NOTCH + 2], &[0.0, 0.0]);
    }

    #[test]
    fn glyph_instance_matches_the_shader_stride() {
        let mut out = Vec::new();
        push_glyph(
            &mut out,
            &GlyphPrim {
                rect: Rect::new(1.0, 2.0, 3.0, 4.0),
                atlas: Rect::new(5.0, 6.0, 7.0, 8.0),
                alpha: 0.5,
                color: Color::from_rgba8(10, 20, 30, 255),
                kind: ui_core::draw::GlyphKind::Coverage,
            },
            1.0,
        );
        assert_eq!(out.len(), shader::GLYPH_STRIDE as usize);
        assert_eq!(&out[0..4], &[1.0, 2.0, 3.0, 4.0], "dest rect");
        assert_eq!(&out[4..8], &[5.0, 6.0, 7.0, 8.0], "atlas rect");
        assert_eq!(out[11], 0.5, "alpha multiplier goes in a_color.w");
        assert_eq!(out[12], 0.0, "coverage kind selects the R8 atlas");
    }

    #[test]
    fn glyph_culling_keeps_every_glyph_that_touches_the_clip() {
        // Culling an overflowing line must never eat a visible glyph: the predicate may
        // reject only what is wholly outside, including a glyph straddling the edge.
        // 裁剪溢出的一行绝不能吃掉可见字形：判据只能拒绝完全在外的字形，跨边缘的也要留下。
        let glyph = |x: f32| GlyphPrim {
            rect: Rect::new(x, 0.0, 10.0, 10.0),
            atlas: Rect::new(0.0, 0.0, 10.0, 10.0),
            alpha: 1.0,
            color: Color::BLACK,
            kind: ui_core::draw::GlyphKind::Coverage,
        };
        let scissor = device_scissor(Rect::new(10.0, 0.0, 20.0, 20.0), 2.0);
        assert_eq!(scissor, [20, 0, 40, 40]);
        assert!(!glyph_hits_scissor(&glyph(0.0), 2.0, scissor), "entirely left");
        assert!(!glyph_hits_scissor(&glyph(40.0), 2.0, scissor), "entirely right");
        assert!(glyph_hits_scissor(&glyph(5.0), 2.0, scissor), "straddling the left edge");
        assert!(glyph_hits_scissor(&glyph(20.0), 2.0, scissor), "inside");
    }

    #[test]
    fn glyph_atlas_coordinates_are_not_scaled() {
        let mut a = Vec::new();
        let prim = GlyphPrim {
            rect: Rect::new(1.0, 2.0, 3.0, 4.0),
            atlas: Rect::new(5.0, 6.0, 7.0, 8.0),
            alpha: 1.0,
            color: Color::from_rgba8(0, 0, 0, 255),
            kind: ui_core::draw::GlyphKind::Coverage,
        };
        push_glyph(&mut a, &prim, 1.0);
        let mut b = Vec::new();
        push_glyph(&mut b, &prim, 3.0);
        // Atlas texels are never scaled; only the destination is.
        // 图集纹素从不缩放；只有目标矩形会。
        assert_eq!(&a[4..8], &b[4..8]);
        assert_eq!(&b[0..4], &[3.0, 6.0, 9.0, 12.0]);
    }

    fn image_prim(src: Rect, corners: Corners) -> ImagePrim {
        ImagePrim {
            rect: Rect::new(10.0, 20.0, 30.0, 40.0),
            corners,
            texture: 0,
            src,
        }
    }

    #[test]
    fn image_instance_matches_the_shader_stride() {
        let mut out = Vec::new();
        push_image(
            &mut out,
            &image_prim(Rect::new(0.0, 0.0, 8.0, 8.0), Corners::ZERO),
            1.0,
            (64, 64),
        );
        assert_eq!(out.len(), shader::IMAGE_STRIDE as usize);
    }

    #[test]
    fn image_uv_covers_the_source_rect_rather_than_the_whole_texture() {
        // Sampling the whole texture instead of `src` is how a small source sub-rect ends up
        // tiled or showing the wrong quadrant; the uv rect must come from `src` alone.
        // 采样整张纹理而不是 `src`，正是小源子矩形被平铺或显示错象限的原因；
        // uv 矩形必须只由 `src` 决定。
        let mut out = Vec::new();
        push_image(
            &mut out,
            &image_prim(Rect::new(16.0, 8.0, 16.0, 16.0), Corners::ZERO),
            1.0,
            (64, 32),
        );
        assert_eq!(&out[8..12], &[0.25, 0.25, 0.5, 0.75]);
    }

    #[test]
    fn image_instance_scales_geometry_but_not_uv() {
        let prim = image_prim(Rect::new(0.0, 0.0, 32.0, 32.0), Corners::all(4.0));
        let mut a = Vec::new();
        push_image(&mut a, &prim, 1.0, (64, 64));
        let mut b = Vec::new();
        push_image(&mut b, &prim, 2.0, (64, 64));
        assert_eq!(&b[0..4], &[20.0, 40.0, 60.0, 80.0]);
        assert_eq!(&b[4..8], &[8.0, 8.0, 8.0, 8.0]);
        assert_eq!(&a[8..12], &b[8..12]);
    }

    #[test]
    fn image_corners_are_clamped_to_half_the_shorter_side() {
        // A radius beyond half the side has no shape to describe; the shader's SDF would
        // invert the corner instead of rounding it.
        // 超过短边一半的半径没有可描述的形状；着色器的 SDF 会把圆角翻转而不是切圆。
        let mut out = Vec::new();
        push_image(
            &mut out,
            &image_prim(Rect::new(0.0, 0.0, 8.0, 8.0), Corners::all(999.0)),
            1.0,
            (8, 8),
        );
        assert_eq!(&out[4..8], &[15.0, 15.0, 15.0, 15.0]);
    }

    #[test]
    fn rect_corners_are_clamped_to_half_the_shorter_side() {
        // A short track segment with a capsule radius would otherwise render as a crescent
        // on the GPU while the CPU path draws a capsule; both must agree.
        // 短轨道段带胶囊半径时，GPU 会画成月牙而 CPU 画成胶囊；两边必须一致。
        let mut out = Vec::new();
        let mut prim = rect_prim(Color::from_rgba8(255, 0, 0, 255));
        prim.rect = Rect::new(0.0, 0.0, 8.0, 40.0);
        prim.radius = Corners { tl: 20.0, tr: 2.0, br: 2.0, bl: 20.0, ..Corners::ZERO };
        push_rect(&mut out, &prim, 1.0);
        assert_eq!(&out[4..8], &[4.0, 2.0, 2.0, 4.0]);
    }

    #[test]
    fn a_scissor_keeps_the_row_its_far_edge_covers() {
        // 207.8..256.8 covers device row 256; `ceil(size)` from a floored origin stops at 255 and
        // silently drops the row, which is how a 1dp divider under a fractional box disappears.
        // 207.8..256.8 覆盖设备行 256；从取整原点起 `ceil(size)` 会止于 255 并静默丢掉该行，
        // 分数盒下方的 1dp 分隔线就是这样消失的。
        assert_eq!(device_scissor(Rect::new(0.0, 207.8, 10.0, 49.0), 1.0), [0, 207, 10, 50]);
        // The far edge rounds out in device space, not in logical space.
        // 远边在设备空间取上整，而不是逻辑空间。
        assert_eq!(device_scissor(Rect::new(0.0, 10.1, 4.0, 2.0), 1.5), [0, 15, 6, 4]);
        // An integral rect is untouched.
        // 整数矩形不受影响。
        assert_eq!(device_scissor(Rect::new(3.0, 4.0, 5.0, 6.0), 1.0), [3, 4, 5, 6]);
    }

    #[test]
    fn a_clip_that_misses_the_band_draws_nothing_instead_of_everything() {
        // A disjoint clip used to disable the scissor, painting the batch over the whole frame.
        // 与重绘带不相交的裁剪框过去会关掉裁剪，把整批画满持久帧。
        let band = Some([100, 100, 50, 50]);
        assert_eq!(batch_scissor(Some([0, 0, 40, 40]), band), Scissor::Empty);
        assert_eq!(
            batch_scissor(Some([120, 120, 10, 10]), band),
            Scissor::Box([120, 120, 10, 10])
        );
        // Without a band, a clip still clips — and nothing at all means no clipping.
        // 没有重绘带时裁剪框照常裁剪；两者都没有才是不裁剪。
        assert_eq!(
            batch_scissor(Some([0, 0, 40, 40]), None),
            Scissor::Box([0, 0, 40, 40])
        );
        assert_eq!(batch_scissor(None, None), Scissor::Off);
    }
}
