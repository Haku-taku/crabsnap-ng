//! Materials that shade the pixels behind a surface: Fluent acrylic and glass.
//! 给平面身后像素着色的材质：Fluent 的 acrylic 与玻璃。
//!
//! The blur amount stays on the node (`BackdropEntry`); a material only says how to
//! colour the blurred result, so changing style never changes geometry or cost shape.
//! 模糊量留在节点上（`BackdropEntry`）；材质只说如何给模糊结果着色，
//! 因此换风格既不改几何也不改代价形态。

pub use ui_core::draw::{Acrylic, BackdropMaterial, LiquidGlass};
