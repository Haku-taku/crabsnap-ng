
precision highp float;
in vec2 v_local;
in vec2 v_half;
in vec4 v_radius;
in vec4 v_colour;
in vec2 v_soft;
in float v_shape;
in float v_ring;
in vec2 v_device;
out vec4 frag;

// Standard normal CDF, Abramowitz & Stegun 7.1.26: |error| < 1.5e-7 for every x.
// 标准正态分布函数，Abramowitz & Stegun 7.1.26：对任意 x 误差小于 1.5e-7。
float normal_cdf(float x) {
    float z = x * 0.70710678118;
    float t = 1.0 / (1.0 + 0.3275911 * abs(z));
    float poly = t * (0.254829592 + t * (-0.284496736 + t * (1.421413741
               + t * (-1.453152027 + t * 1.061405429))));
    float erf = 1.0 - poly * exp(-z * z);
    return z >= 0.0 ? 0.5 * (1.0 + erf) : 0.5 * (1.0 - erf);
}

void main() {
    float d = sd_round_box(v_local, v_half, v_radius, v_shape);
    // A Gaussian cast of the silhouette: `blur` is its radius, which CSS and Skia define as
    // two sigma, so the shadow is still gone about `blur` past the edge.
    // 轮廓的高斯投影：`blur` 是它的半径，CSS 与 Skia 都把它定义为两个 sigma，
    // 阴影因此在边缘外约 `blur` 处才消失。
    float sigma = max(v_soft.x, 1e-4) * 0.5;
    // A ring caster is the band `ring` deep straddling the silhouette; the difference of the
    // two CDFs is that band blurred, and carries its sub-unit alpha on its own.
    // 环状投射体是横跨轮廓、深 `ring` 的带；两个分布函数之差就是模糊后的带，
    // 「窄于核的带到不了满值」那部分比例也自动落在里面。
    float band = v_ring * 0.5;
    float a = v_ring > 0.0
        ? v_colour.a * (normal_cdf((d + band) / sigma) - normal_cdf((d - band) / sigma))
        : v_colour.a * normal_cdf(-d / sigma);
    a *= clip_coverage(v_device);
    if (a <= 0.0) {
        discard;
    }
    frag = vec4(v_colour.rgb * a, a);
}
