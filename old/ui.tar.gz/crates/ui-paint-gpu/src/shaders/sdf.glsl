
// Superellipse norm of a non-negative pair; n = 2 is the circle, n = 1 a bevel.
// 非负数对的超椭圆范数；n = 2 为圆，n = 1 为直线斜切。
float lp_norm(vec2 q, float n) {
    if (n <= 1.0) {
        return q.x + q.y;
    }
    if (n >= 64.0) {
        return max(q.x, q.y);
    }
    return pow(pow(q.x, n) + pow(q.y, n), 1.0 / n);
}

// Signed distance to a rounded box; negative inside. `r` is (tl, tr, br, bl), y down, so the
// quadrant pick must take (tl,bl) on the left and (tr,br) on the right — iq's packing is not this one.
// 到圆角矩形的有符号距离；内部为负。`r` 是 (tl, tr, br, bl)，y 向下，
// 因此象限取值左侧取 (tl,bl)、右侧取 (tr,br)——iq 那份打包顺序不是这个。
float sd_round_box(vec2 p, vec2 b, vec4 r, float n) {
    r.xy = (p.x > 0.0) ? vec2(r.y, r.z) : vec2(r.x, r.w);
    r.x  = (p.y > 0.0) ? r.y : r.x;
    vec2 q = abs(p) - b + r.x;
    return min(max(q.x, q.y), 0.0) + lp_norm(max(q, vec2(0.0)), n) - r.x;
}
