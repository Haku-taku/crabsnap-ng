
precision highp float;
in vec2 v_local;
in vec2 v_half;
in vec4 v_radius;
in float v_shape;
in vec2 v_uv;
in vec2 v_device;
uniform sampler2D u_image;
out vec4 frag;
void main() {
    float d = sd_round_box(v_local, v_half, v_radius, v_shape);
    // One device pixel of feather; the SDF is already in pixel units.
    // 一个设备像素的羽化；SDF 本身就以像素为单位。
    float cov = clamp(AA - d, 0.0, 1.0);
    if (cov <= 0.0) {
        discard;
    }
    // The texture holds straight alpha; premultiply so the frame's blend equation applies.
    // 纹理是直通 alpha；先预乘，才能套用帧的混合方程。
    vec4 s = texture(u_image, v_uv);
    float a = s.a * cov * clip_coverage(v_device);
    if (a <= 0.0) {
        discard;
    }
    frag = vec4(s.rgb * a, a);
}
