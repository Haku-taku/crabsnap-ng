
precision highp float;
in vec2 a_unit;
in vec4 a_rect;      // the *shadowed* shape, device pixels, y down
in vec4 a_radius;
in vec4 a_colour;    // rgb + peak alpha
in vec2 a_soft;      // x: falloff width, y: dy
in float a_shape;
in float a_ring;     // casting band depth; 0 shadows the whole shape
uniform vec2 u_viewport;
out vec2 v_local;
out vec2 v_half;
out vec4 v_radius;
out vec4 v_colour;
out vec2 v_soft;
out float v_shape;
out float v_ring;
out vec2 v_device;
void main() {
    // Grow by the casting band, three sigma of the Gaussian, and the offset: the whole
    // gradient fits. 外扩带上投射带、高斯的三倍 sigma 与偏移，整个渐变才落在四边形内。
    vec2 pad = vec2(a_ring * 0.5 + a_soft.x * 1.5 + abs(a_soft.y));
    vec2 origin = a_rect.xy - pad;
    vec2 size = a_rect.zw + 2.0 * pad;
    // Reaches `AA` past the falloff so the outermost covered pixel is still rasterised.
    // 在衰减宽度之外再伸 `AA`，最外那圈有覆盖的像素因此仍会被光栅化。
    vec2 device = origin - AA + a_unit * (size + 2.0 * AA);
    vec2 ndc = vec2(
        device.x / u_viewport.x * 2.0 - 1.0,
        device.y / u_viewport.y * 2.0 - 1.0
    );
    gl_Position = vec4(ndc, 0.0, 1.0);
    // Evaluate the SDF in the caster's own space, from the real device position, with the
    // caster moved by `dy`: the offset has to reach the distance, not just the quad.
    // 在投射体自身的空间里求 SDF，取自真实设备位置，并把投射体按 `dy` 移开：
    // 偏移必须进到距离里，只扩大四边形是不够的。
    v_local = device - (a_rect.xy + a_rect.zw * 0.5 + vec2(0.0, a_soft.y));
    v_half = a_rect.zw * 0.5;
    v_radius = a_radius;
    v_colour = a_colour;
    v_soft = a_soft;
    v_shape = a_shape;
    v_ring = a_ring;
    v_device = device;
}
