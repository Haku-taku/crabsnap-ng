
precision highp float;
in vec2 v_local;
in vec2 v_half;
in vec4 v_radius;
in vec4 v_fill;
in vec4 v_border;
in vec4 v_border2;
in float v_border_g;
in float v_border_w;
in float v_shape;
in vec2 v_device;
in vec4 v_fill2;
in vec2 v_grad;
in vec4 v_stops;
in vec2 v_extent;
in vec2 v_notch;
in vec2 v_flip;
out vec4 frag;

// Coverage-weighted premultiplied colour so one blend equation covers rects
// and glyphs: rgb must be scaled by alpha, not just by coverage.
// 按覆盖度加权的预乘颜色，使一个混合方程同时覆盖矩形与字形：
// rgb 必须乘 alpha，而不只是乘覆盖度。
vec4 premul(vec4 straight, float coverage) {
    float a = straight.a * coverage;
    return vec4(straight.rgb * a, a);
}

// Map a gradient-space coordinate through a pair of stops.
// 把渐变空间坐标经一对停点重映射。
float remap(float u, float lo, float hi) {
    return clamp((u - lo) / max(hi - lo, 1e-5), 0.0, 1.0);
}

void main() {
    float d = sd_round_box(v_local, v_half, v_radius, v_shape);
    // One device pixel of feather; the SDF is already in pixel units.
    // 一个设备像素的羽化；SDF 本身就以像素为单位。
    float outer = clamp(AA - d, 0.0, 1.0);
    float width = v_border_w;
    // A gradient is sampled in the box's own space: v_local is centred, v_half is the
    // half extent, so t runs 0..1 across the box on the chosen axis.
    // 渐变在盒子自身空间里采样：v_local 居中、v_half 是半尺寸，故 t 沿选定轴跨过 0..1。
    // `along` is the distance from the box's near edge; `span` is either the box's own
    // extent or the brush's shorter run (WinUI's elevation borders cover only a few units).
    // `along` 是自盒子近缘起的距离；`span` 或是盒子自身长度，或是画刷更短的跨度
    // （WinUI 的立面描边只覆盖几个单位）。
    bool vertical = v_grad.x < 0.5;
    float along = vertical ? (v_local.y + v_half.y) : (v_local.x + v_half.x);
    float box = vertical ? 2.0 * v_half.y : 2.0 * v_half.x;
    // A mirrored brush measures the same run from the far edge; the box mirrors with it.
    // 镜像画刷从远缘度量同一段渐变；盒子随之镜像。
    float along_f = v_flip.x > 0.5 ? box - along : along;
    float along_b = v_flip.y > 0.5 ? box - along : along;
    vec4 fill = v_fill;
    if (v_grad.y > 0.5) {
        float span = v_extent.x > 0.0 ? v_extent.x : box;
        fill = mix(v_fill, v_fill2, remap(along_f / max(span, 1e-5), v_stops.x, v_stops.y));
    }
    // Ring and inner area are disjoint parts of one shape: weight them by area and scale
    // once. Two stacked blends count the feather twice and bleed fill into the ring.
    // 环与内部是同一形状的互斥面积：按面积加权后只缩放一次。
    // 叠加两次混合会把羽化算重，让填充渗进环里。
    vec4 fill_pm = premul(fill, 1.0);
    vec4 src = fill_pm;
    if (width > 0.0) {
        float inner = clamp(AA - (d + width), 0.0, 1.0);
        float ring = max(outer - inner, 0.0);
        // A notch cuts the stroke where it crosses the top edge; the fill survives, so a
        // transparent box shows the backdrop through the gap. The half-pixel is the stroke's
        // antialiased skirt, which reaches past the band and would otherwise survive as a line.
        // 缺口在描边穿过顶边处切掉它；填充仍在，因此透明盒子会透出背景。那半个像素是描边的
        // 抗锯齿边缘，它会越过带边界，否则会残留成一条细线。
        float local_x = v_local.x + v_half.x;
        if (v_notch.y > v_notch.x && local_x >= v_notch.x && local_x <= v_notch.y
            && v_local.y <= -v_half.y + width + 0.5) {
            ring = 0.0;
        }
        vec4 stroke = v_border;
        if (v_border_g > 0.5) {
            float span = v_extent.y > 0.0 ? v_extent.y : box;
            stroke = mix(v_border, v_border2, remap(along_b / max(span, 1e-5), v_stops.z, v_stops.w));
        }
        vec4 border_pm = premul(stroke, 1.0);
        vec4 over = border_pm + fill_pm * (1.0 - border_pm.a);
        src = mix(fill_pm, over, clamp(ring / max(outer, 1e-5), 0.0, 1.0));
    }
    vec4 colour = src * outer;
    // The clip attenuates premultiplied colour uniformly.
    // 裁剪按同一比例衰减预乘颜色。
    colour *= clip_coverage(v_device);
    if (colour.a <= 0.0) {
        discard;
    }
    frag = colour;
}
