//! EGL + gbm + dma-buf: the device and presentation layer.
//! EGL + gbm + dma-buf：设备与呈现层。
//!
//! Nothing here knows about layout, text or draw lists; the renderer depends on this,
//! never the other way round.
//! 这里不认识布局、文本或绘制列表；渲染器依赖它，反过来不成立。

pub mod context;
pub mod ffi;
pub mod syncobj;
pub mod target;

pub use context::{DmaBufDesc, EglContext, ExportedFence};
pub use syncobj::SyncTimeline;
pub use target::{DmaBufTarget, GpuSurface};

/// Why a GPU operation failed.
/// GPU 操作失败的原因。
#[derive(Debug)]
pub enum GpuError {
    /// The DRM render node could not be opened.
    /// 无法打开 DRM render 节点。
    OpenNode { path: String, errno: i32 },
    /// `libgbm` or one of its symbols was missing.
    /// `libgbm` 或其符号缺失。
    GbmUnavailable(&'static str),
    /// `gbm_create_device` or `gbm_bo_create` returned null.
    /// `gbm_create_device` 或 `gbm_bo_create` 返回空。
    Allocation(&'static str),
    Egl(String),
    Gl(String),
    /// A required EGL extension is absent on this display.
    /// 该显示缺少必需的 EGL 扩展。
    MissingExtension(&'static str),
    /// A DRM syncobj operation failed.
    /// DRM syncobj 操作失败。
    SyncObj(&'static str),
}

impl core::fmt::Display for GpuError {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::OpenNode { path, errno } => write!(f, "cannot open {path}: errno {errno}"),
            Self::GbmUnavailable(s) => write!(f, "libgbm unavailable: {s}"),
            Self::Allocation(s) => write!(f, "allocation failed: {s}"),
            Self::Egl(s) => write!(f, "EGL: {s}"),
            Self::Gl(s) => write!(f, "GL: {s}"),
            Self::MissingExtension(s) => write!(f, "missing EGL extension {s}"),
            Self::SyncObj(s) => write!(f, "syncobj: {s}"),
        }
    }
}

impl From<String> for GpuError {
    fn from(e: String) -> Self {
        Self::Gl(e)
    }
}

impl std::error::Error for GpuError {}
