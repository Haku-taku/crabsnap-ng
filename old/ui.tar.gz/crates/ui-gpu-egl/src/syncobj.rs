//! A DRM syncobj timeline: the kernel object explicit synchronization is built on.
//! DRM syncobj timeline：显式同步所依赖的内核对象。
//!
//! `libdrm` is loaded with `dlopen`, like `libgbm`, so a machine without it still builds.
//! `libdrm` 与 `libgbm` 一样用 `dlopen` 加载，没有它的机器仍可编译。

use std::ffi::{c_void, CStr};
use std::os::fd::{AsRawFd, FromRawFd, OwnedFd};

type SyncobjCreate = unsafe extern "system" fn(i32, u32, *mut u32) -> i32;
type SyncobjDestroy = unsafe extern "system" fn(i32, u32) -> i32;
type SyncobjHandleToFd = unsafe extern "system" fn(i32, u32, *mut i32) -> i32;
type SyncobjImportSyncFile = unsafe extern "system" fn(i32, u32, i32) -> i32;
type SyncobjTransfer =
    unsafe extern "system" fn(i32, u32, u64, u32, u64, u32) -> i32;
type SyncobjTimelineWait = unsafe extern "system" fn(
    i32,
    *const u32,
    *const u64,
    u32,
    i64,
    u32,
    *mut u32,
) -> i32;
type GetCap = unsafe extern "system" fn(i32, u64, *mut u64) -> i32;

/// `DRM_SYNCOBJ_WAIT_FLAGS_WAIT_FOR_SUBMIT`: wait for a point that is not submitted yet.
/// `DRM_SYNCOBJ_WAIT_FLAGS_WAIT_FOR_SUBMIT`：等待一个尚未提交的点。
const WAIT_FOR_SUBMIT: u32 = 1 << 1;

/// `DRM_CAP_SYNCOBJ_TIMELINE`: the kernel can hold a point timeline at all.
/// `DRM_CAP_SYNCOBJ_TIMELINE`：内核至少能承载点时间线。
const DRM_CAP_SYNCOBJ_TIMELINE: u64 = 0x14;

/// One timeline syncobj on one DRM device.
/// 单个 DRM 设备上的一个 timeline syncobj。
pub struct SyncTimeline {
    /// Dup of the device fd, so the timeline outlives a device handle swap.
    /// 设备 fd 的 dup，使 timeline 在设备句柄更换后仍有效。
    fd: OwnedFd,
    /// The syncobj's own fd, which is what `import_timeline` takes.
    /// syncobj 自身的 fd，`import_timeline` 要的正是它。
    syncobj_fd: OwnedFd,
    handle: u32,
    /// Binary syncobj that receives one fence before it is moved onto a point.
    /// 先接收一个 fence、再搬到某个点上的二值 syncobj。
    scratch: u32,
    destroy: SyncobjDestroy,
    import_sync_file: SyncobjImportSyncFile,
    transfer: SyncobjTransfer,
    timeline_wait: SyncobjTimelineWait,
}

impl SyncTimeline {
    /// Create a timeline on `device_fd`, e.g. the GBM device's DRM node.
    /// 在 `device_fd`（例如 GBM 设备的 DRM 节点）上创建 timeline。
    pub fn new(device_fd: i32) -> Result<Self, crate::GpuError> {
        // SAFETY: dlopen/dlsym with a NUL-terminated name; symbols are transmuted to the
        // signatures libdrm documents.
        // SAFETY: dlopen/dlsym 使用以 NUL 结尾的名字；符号按 libdrm 文档的签名转换。
        unsafe {
            let lib = libc::dlopen(c"libdrm.so.2".as_ptr(), libc::RTLD_NOW);
            if lib.is_null() {
                return Err(crate::GpuError::SyncObj("cannot dlopen libdrm.so.2"));
            }
            let sym = |name: &CStr| -> Result<*mut c_void, crate::GpuError> {
                let p = libc::dlsym(lib, name.as_ptr());
                if p.is_null() {
                    Err(crate::GpuError::SyncObj("libdrm symbol missing"))
                } else {
                    Ok(p)
                }
            };
            let create: SyncobjCreate = std::mem::transmute(sym(c"drmSyncobjCreate")?);
            let destroy: SyncobjDestroy = std::mem::transmute(sym(c"drmSyncobjDestroy")?);
            let handle_to_fd: SyncobjHandleToFd =
                std::mem::transmute(sym(c"drmSyncobjHandleToFD")?);
            let import_sync_file: SyncobjImportSyncFile =
                std::mem::transmute(sym(c"drmSyncobjImportSyncFile")?);
            let transfer: SyncobjTransfer = std::mem::transmute(sym(c"drmSyncobjTransfer")?);
            let timeline_wait: SyncobjTimelineWait =
                std::mem::transmute(sym(c"drmSyncobjTimelineWait")?);
            let get_cap: GetCap = std::mem::transmute(sym(c"drmGetCap")?);
            // Without the capability every transfer fails, so fall back before attaching.
            // 没有该能力时每次 transfer 都会失败，因此在挂接前就退回。
            let mut timeline: u64 = 0;
            if get_cap(device_fd, DRM_CAP_SYNCOBJ_TIMELINE, &mut timeline) != 0 || timeline == 0 {
                return Err(crate::GpuError::SyncObj("no timeline syncobj support"));
            }

            let dup = libc::dup(device_fd);
            if dup < 0 {
                return Err(crate::GpuError::SyncObj("dup device fd"));
            }
            let fd = OwnedFd::from_raw_fd(dup);
            let mut handle: u32 = 0;
            if create(fd.as_raw_fd(), 0, &mut handle) != 0 {
                return Err(crate::GpuError::SyncObj("drmSyncobjCreate"));
            }
            let mut scratch: u32 = 0;
            if create(fd.as_raw_fd(), 0, &mut scratch) != 0 {
                let _ = destroy(fd.as_raw_fd(), handle);
                return Err(crate::GpuError::SyncObj("drmSyncobjCreate"));
            }
            let mut obj_fd: i32 = -1;
            if handle_to_fd(fd.as_raw_fd(), handle, &mut obj_fd) != 0 || obj_fd < 0 {
                let _ = destroy(fd.as_raw_fd(), handle);
                let _ = destroy(fd.as_raw_fd(), scratch);
                return Err(crate::GpuError::SyncObj("drmSyncobjHandleToFD"));
            }
            Ok(Self {
                fd,
                syncobj_fd: OwnedFd::from_raw_fd(obj_fd),
                handle,
                scratch,
                destroy,
                import_sync_file,
                transfer,
                timeline_wait,
            })
        }
    }

    /// Duplicate the syncobj fd, so it can be handed to another process (the compositor).
    /// 复制 syncobj fd，以便交给另一个进程（compositor）。
    pub fn dup_fd(&self) -> Result<OwnedFd, crate::GpuError> {
        // SAFETY: the syncobj fd is a valid open descriptor; `dup` returns a new one or -1.
        // SAFETY: syncobj fd 是有效的打开描述符；`dup` 返回新描述符或 -1。
        let dup = unsafe { libc::dup(self.syncobj_fd.as_raw_fd()) };
        if dup < 0 {
            return Err(crate::GpuError::SyncObj("dup timeline fd"));
        }
        Ok(unsafe { OwnedFd::from_raw_fd(dup) })
    }

    /// Import `fence` as timeline point `point`, which must exceed every earlier point.
    /// 把 `fence` 作为 timeline 上的点 `point` 导入；它必须大于此前所有点。
    ///
    /// `drmSyncobjImportSyncFile` alone only replaces a binary fence; a timeline point
    /// comes only from `drmSyncobjTransfer`, so the fence is staged in a scratch syncobj.
    /// 单用 `drmSyncobjImportSyncFile` 只会替换二值 fence；timeline 点只由
    /// `drmSyncobjTransfer` 产生，因此 fence 先寄存在一个临时 syncobj 里。
    pub fn import_fence_at(&self, fence: &OwnedFd, point: u64) -> Result<(), crate::GpuError> {
        // SAFETY: both handles belong to this device and `fence` is a valid sync_file.
        // SAFETY: 两个句柄都属于本设备，`fence` 是有效的 sync_file。
        unsafe {
            let fd = self.fd.as_raw_fd();
            if (self.import_sync_file)(fd, self.scratch, fence.as_raw_fd()) != 0 {
                return Err(crate::GpuError::SyncObj("drmSyncobjImportSyncFile"));
            }
            if (self.transfer)(fd, self.handle, point, self.scratch, 0, 0) != 0 {
                return Err(crate::GpuError::SyncObj("drmSyncobjTransfer"));
            }
            Ok(())
        }
    }

    /// Whether the timeline has reached `point` within `timeout`.
    /// 时间线是否在 `timeout` 内到达 `point`。
    ///
    /// The compositor drives this timeline: it signals a point once it has stopped reading
    /// the buffer that carried it. An unsubmitted point waits instead of failing, and a
    /// timeout means "not yet", never an error the caller must handle.
    /// 这条时间线由 compositor 驱动：它读完携带该点的缓冲后就 signal 该点。
    /// 尚未提交的点会等着而不是报错，超时只表示「还没到」，不是调用方必须处理的错误。
    pub fn wait(&self, point: u64, timeout: std::time::Duration) -> bool {
        // The kernel takes an absolute CLOCK_MONOTONIC deadline, not a duration.
        // 内核要的是绝对的 CLOCK_MONOTONIC 期限，不是时长。
        let mut ts = libc::timespec { tv_sec: 0, tv_nsec: 0 };
        // SAFETY: `ts` is a valid timespec and CLOCK_MONOTONIC always exists.
        // SAFETY: `ts` 是有效的 timespec，CLOCK_MONOTONIC 必然存在。
        unsafe { libc::clock_gettime(libc::CLOCK_MONOTONIC, &mut ts) };
        let now = ts.tv_sec * 1_000_000_000 + ts.tv_nsec;
        let deadline = now.saturating_add(timeout.as_nanos().min(i64::MAX as u128) as i64);
        // SAFETY: the handle belongs to this timeline, and both arrays outlive the call.
        // SAFETY: 句柄属于本时间线，两个数组都活过这次调用。
        unsafe {
            let mut signaled: u32 = 0;
            let rc = (self.timeline_wait)(
                self.fd.as_raw_fd(),
                &self.handle,
                &point,
                1,
                deadline,
                WAIT_FOR_SUBMIT,
                &mut signaled,
            );
            rc == 0
        }
    }
}

impl Drop for SyncTimeline {
    fn drop(&mut self) {
        // SAFETY: both handles were created on this fd and are destroyed exactly once.
        // SAFETY: 两个句柄都在本 fd 上创建，且各自只销毁一次。
        unsafe {
            let _ = (self.destroy)(self.fd.as_raw_fd(), self.handle);
            let _ = (self.destroy)(self.fd.as_raw_fd(), self.scratch);
        }
    }
}
