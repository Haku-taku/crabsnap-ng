//! EGL display and OpenGL ES context bound to a DRM render node.
//! 绑定到 DRM render 节点的 EGL 显示与 OpenGL ES 上下文。

use std::ffi::CStr;

use glow::HasContext;
use khronos_egl as egl;

use crate::ffi::{
    self, CreateImage, DestroyImage, EGL_PLATFORM_GBM_KHR, GbmDevice, ImageTargetTexture,
};
use crate::GpuError;

const EGL_NONE: egl::Int = 0x3038;

/// A sync_file exported from the GL queue: it signals when the queued work lands.
/// 从 GL 队列导出的 sync_file：排入的工作落地时它才 signal。
pub struct ExportedFence {
    /// The sync_file descriptor to import into a DRM timeline.
    /// 要导入 DRM timeline 的 sync_file 描述符。
    pub fd: std::os::fd::OwnedFd,
}

/// Image functions a dma-buf backed target needs.
/// dma-buf 支撑的目标所需的图像函数。
struct ImageFns {
    create: CreateImage,
    destroy: DestroyImage,
    target_texture: ImageTargetTexture,
}

/// A live EGL display + GL context on one GPU.
/// 单块 GPU 上的 EGL 显示与 GL 上下文。
pub struct EglContext {
    egl: egl::DynamicInstance<egl::EGL1_5>,
    display: egl::Display,
    context: egl::Context,
    gl: glow::Context,
    images: ImageFns,
    gbm: GbmDevice,
    is_gles: bool,
    /// Whether the driver can create a native fence; `None` until the first export tries.
    /// 驱动能否创建 native fence；首次导出尝试前为 `None`。
    native_fence: std::cell::Cell<Option<bool>>,
}

impl EglContext {
    /// Create a context on `node`, e.g. `/dev/dri/renderD128`.
    /// 在 `node` 上创建上下文，例如 `/dev/dri/renderD128`。
    pub fn new(node: &CStr) -> Result<Self, GpuError> {
        let egl = unsafe { egl::DynamicInstance::<egl::EGL1_5>::load_required() }
            .map_err(|e| GpuError::Egl(format!("cannot load libEGL: {e:?}")))?;
        let gbm = GbmDevice::open(node)?;

        // The GBM platform, not `EGL_EXT_platform_device`: GLVND loads every EGL vendor at
        // display creation, so the device platform saves no memory (design-errors, 2026-11-04).
        // 用 GBM 平台而非 `EGL_EXT_platform_device`：GLVND 在建显示时加载所有 EGL 厂商，
        // 设备平台因此省不下内存（见 design-errors 2026-11-04 那条）。
        let display = unsafe {
            egl.get_platform_display(EGL_PLATFORM_GBM_KHR, gbm.raw(), &[egl::ATTRIB_NONE])
        }
        .map_err(|e| GpuError::Egl(format!("no GBM display: {e:?}")))?;
        egl.initialize(display)
            .map_err(|e| GpuError::Egl(format!("eglInitialize: {e:?}")))?;

        let extensions = egl
            .query_string(Some(display), egl::EXTENSIONS)
            .map(|c| c.to_string_lossy().into_owned())
            .unwrap_or_default();
        for required in ["EGL_EXT_image_dma_buf_import", "EGL_KHR_image_base"] {
            if !extensions.contains(required) {
                return Err(GpuError::MissingExtension(required_message(required)));
            }
        }

        // No SURFACE_TYPE: GBM displays need not expose pbuffer configs.
        // 不指定 SURFACE_TYPE：GBM 显示不保证有 pbuffer 配置。
        let config = egl
            .choose_first_config(
                display,
                &[
                    egl::RENDERABLE_TYPE,
                    egl::OPENGL_ES3_BIT,
                    egl::RED_SIZE,
                    8,
                    egl::GREEN_SIZE,
                    8,
                    egl::BLUE_SIZE,
                    8,
                    egl::ALPHA_SIZE,
                    8,
                    EGL_NONE,
                ],
            )
            .map_err(|e| GpuError::Egl(format!("choose_config: {e:?}")))?
            .ok_or_else(|| GpuError::Egl("no GLES3 config".into()))?;

        let context = egl
            .create_context(
                display,
                config,
                None,
                &[
                    egl::CONTEXT_MAJOR_VERSION,
                    3,
                    egl::CONTEXT_MINOR_VERSION,
                    0,
                    EGL_NONE,
                ],
            )
            .map_err(|e| GpuError::Egl(format!("create_context: {e:?}")))?;
        egl.make_current(display, None, None, Some(context))
            .map_err(|e| GpuError::Egl(format!("make_current: {e:?}")))?;

        let gl = unsafe {
            glow::Context::from_loader_function(|s| {
                egl.get_proc_address(s)
                    .map_or(std::ptr::null(), |f| f as *const _)
            })
        };
        let version = unsafe { gl.get_parameter_string(glow::VERSION) };
        let is_gles = version.contains("OpenGL ES");

        let create = egl.get_proc_address("eglCreateImageKHR")
            .ok_or(GpuError::MissingExtension("eglCreateImageKHR"))?;
        let destroy = egl.get_proc_address("eglDestroyImageKHR")
            .ok_or(GpuError::MissingExtension("eglDestroyImageKHR"))?;
        let target_texture = egl.get_proc_address("glEGLImageTargetTexture2DOES")
            .ok_or(GpuError::MissingExtension("glEGLImageTargetTexture2DOES"))?;
        let images = ImageFns {
            create: unsafe { std::mem::transmute(create) },
            destroy: unsafe { std::mem::transmute(destroy) },
            target_texture: unsafe { std::mem::transmute(target_texture) },
        };

        Ok(Self {
            egl,
            display,
            context,
            gl,
            images,
            gbm,
            is_gles,
            native_fence: std::cell::Cell::new(None),
        })
    }

    /// The GL context.
    /// GL 上下文。
    pub fn gl(&self) -> &glow::Context {
        &self.gl
    }

    /// Human-readable renderer string, for reporting which GPU is in use.
    /// 可读的渲染器字符串，用于报告使用哪块 GPU。
    pub fn renderer(&self) -> String {
        unsafe { self.gl.get_parameter_string(glow::RENDERER) }
    }

    /// Version string, useful when picking a shader dialect.
    /// 版本字符串，选择着色器方言时有用。
    pub fn version(&self) -> String {
        unsafe { self.gl.get_parameter_string(glow::VERSION) }
    }

    /// Whether the context is OpenGL ES (affects the GLSL header).
    /// 上下文是否 OpenGL ES（影响着色器的 GLSL 头）。
    pub fn is_gles(&self) -> bool {
        self.is_gles
    }

    pub(crate) fn gbm(&self) -> &GbmDevice {
        &self.gbm
    }

    /// The DRM node descriptor, for syncobj timelines.
    /// DRM 节点描述符，供 syncobj timeline 使用。
    pub fn drm_fd(&self) -> i32 {
        self.gbm.fd()
    }

    /// Export a native fence for the GL work submitted so far, without blocking.
    /// 导出截至目前的 GL 工作的原生 fence，不阻塞。
    ///
    /// `eglDupNativeFenceFDANDROID` flushes the GL queue and returns a sync_file, which is
    /// what explicit synchronization imports into a timeline; it replaces `glFinish`.
    /// `eglDupNativeFenceFDANDROID` 会冲刷 GL 队列并返回 sync_file，显式同步正是把它导入
    /// timeline；它替代 `glFinish`。
    ///
    /// Drivers that refuse a native-fence sync object (NVIDIA) still hand a fence-sync
    /// marker's fd over, which signals with the same work; both paths avoid `glFinish`.
    /// 拒绝 native-fence 同步对象的驱动（NVIDIA）同样能给出 fence-sync 标记的 fd，
    /// 它与同一批工作一起 signal；两条路径都不需要 `glFinish`。
    pub fn export_fence(&self) -> Result<ExportedFence, GpuError> {
        use std::ffi::c_void;
        use std::os::fd::FromRawFd;
        const EGL_SYNC_NATIVE_FENCE_ANDROID: egl::Enum = 0x3140;
        const EGL_SYNC_FENCE_KHR: egl::Enum = 0x30F9;
        type CreateSync =
            unsafe extern "system" fn(*mut c_void, egl::Enum, *const egl::Int) -> *mut c_void;
        type DupFence = unsafe extern "system" fn(*mut c_void, *mut c_void) -> egl::Int;
        type DestroySync = unsafe extern "system" fn(*mut c_void, *mut c_void) -> egl::Boolean;
        let create: CreateSync = unsafe {
            std::mem::transmute(
                self.egl
                    .get_proc_address("eglCreateSyncKHR")
                    .ok_or(GpuError::MissingExtension("eglCreateSyncKHR"))?,
            )
        };
        let dup: DupFence = unsafe {
            std::mem::transmute(
                self.egl
                    .get_proc_address("eglDupNativeFenceFDANDROID")
                    .ok_or(GpuError::MissingExtension("eglDupNativeFenceFDANDROID"))?,
            )
        };
        let destroy: DestroySync = unsafe {
            std::mem::transmute(
                self.egl
                    .get_proc_address("eglDestroySyncKHR")
                    .ok_or(GpuError::MissingExtension("eglDestroySyncKHR"))?,
            )
        };
        let dpy = self.display.as_ptr();
        let attribs: [egl::Int; 1] = [EGL_NONE];
        // A real GPU fence, when the driver can create one (Mesa on AMD/Intel).
        // 驱动能创建真正的 GPU fence 时（AMD/Intel 上的 Mesa）就用它。
        if self.native_fence.get() != Some(false) {
            let native = unsafe { create(dpy, EGL_SYNC_NATIVE_FENCE_ANDROID, attribs.as_ptr()) };
            if !native.is_null() {
                let fd = unsafe { dup(dpy, native) };
                unsafe {
                    let _ = destroy(dpy, native);
                }
                if fd >= 0 {
                    if self.native_fence.get().is_none() {
                        eprintln!("explicit sync: native fence");
                    }
                    self.native_fence.set(Some(true));
                    return Ok(ExportedFence {
                        fd: unsafe { std::os::fd::OwnedFd::from_raw_fd(fd) },
                    });
                }
            }
            // Clear the failure so it is not misread as a later call's error.
            // 清掉这次失败，免得它被当成后续某个调用的错误。
            let _ = self.egl.get_error();
            eprintln!("explicit sync: fence-sync marker instead of a native fence");
            self.native_fence.set(Some(false));
        }
        // NVIDIA refuses a native-fence sync object; a fence-sync marker is still a real
        // GPU fence, and the fd below signals with the same work.
        // NVIDIA 拒绝创建 native-fence 同步对象；fence-sync 标记仍是真 GPU fence，
        // 下面的 fd 与同一批工作一起 signal。
        let marker = unsafe { create(dpy, EGL_SYNC_FENCE_KHR, attribs.as_ptr()) };
        if marker.is_null() {
            let err = self.egl.get_error();
            return Err(GpuError::Egl(format!("eglCreateSyncKHR: {err:?}")));
        }
        let fd = unsafe { dup(dpy, marker) };
        unsafe {
            let _ = destroy(dpy, marker);
        }
        if fd < 0 {
            return Err(GpuError::Egl("eglDupNativeFenceFDANDROID".into()));
        }
        Ok(ExportedFence {
            fd: unsafe { std::os::fd::OwnedFd::from_raw_fd(fd) },
        })
    }

    /// Wrap a dma-buf as an EGLImage. Both Mesa and NVIDIA support this, while
    /// `EGL_KHR_image_pixmap` is absent on NVIDIA.
    /// 把 dma-buf 包装成 EGLImage。Mesa 与 NVIDIA 都支持，
    /// 而 `EGL_KHR_image_pixmap` 在 NVIDIA 上缺失。
    pub(crate) fn import_dmabuf(
        &self,
        image: &DmaBufDesc,
    ) -> Result<*mut std::ffi::c_void, GpuError> {
        let _ = &self.images;
        // Width and height are mandatory; omitting them yields EGL_BAD_PARAMETER
        // on both Mesa and NVIDIA.
        // 宽高是必填的；漏掉会在 Mesa 与 NVIDIA 上都返回 EGL_BAD_PARAMETER。
        let attribs: [egl::Int; 17] = [
            egl::WIDTH,
            image.width as egl::Int,
            egl::HEIGHT,
            image.height as egl::Int,
            ffi::EGL_LINUX_DRM_FOURCC_EXT,
            image.format as egl::Int,
            ffi::EGL_DMA_BUF_PLANE0_FD_EXT,
            image.fd,
            ffi::EGL_DMA_BUF_PLANE0_OFFSET_EXT,
            image.offset as egl::Int,
            ffi::EGL_DMA_BUF_PLANE0_PITCH_EXT,
            image.stride as egl::Int,
            ffi::EGL_DMA_BUF_PLANE0_MODIFIER_LO_EXT,
            (image.modifier & 0xffff_ffff) as egl::Int,
            ffi::EGL_DMA_BUF_PLANE0_MODIFIER_HI_EXT,
            (image.modifier >> 32) as egl::Int,
            EGL_NONE,
        ];
        let img = unsafe {
            (self.images.create)(
                self.display.as_ptr(),
                std::ptr::null_mut(),
                ffi::EGL_LINUX_DMA_BUF_EXT,
                std::ptr::null_mut(),
                attribs.as_ptr(),
            )
        };
        if img.is_null() {
            return Err(GpuError::Egl(format!(
                "eglCreateImageKHR(dma_buf) failed: {:?}",
                self.egl.get_error()
            )));
        }
        Ok(img)
    }

    /// Bind an EGLImage as the current `GL_TEXTURE_2D`.
    /// 把 EGLImage 绑定为当前的 `GL_TEXTURE_2D`。
    pub(crate) fn bind_image_texture(&self, image: *mut std::ffi::c_void) {
        unsafe { (self.images.target_texture)(glow::TEXTURE_2D, image) };
    }

    pub(crate) fn destroy_image(&self, image: *mut std::ffi::c_void) {
        unsafe { (self.images.destroy)(self.display.as_ptr(), image) };
    }
}

impl Drop for EglContext {
    fn drop(&mut self) {
        // Two exit-test knobs: `EXIT_KEEP_GL` leaves the whole context to process exit,
        // `EXIT_KEEP_EGL` only the display teardown, so a stall can be pinned to one call.
        // 两个退出测试开关：`EXIT_KEEP_GL` 把整个上下文交给进程退出，
        // `EXIT_KEEP_EGL` 只留 display 拆除，停顿因此能钉到某一次调用上。
        if std::env::var_os("EXIT_KEEP_GL").is_some() {
            return;
        }
        let _ = self.egl.make_current(self.display, None, None, None);
        let _ = self.egl.destroy_context(self.display, self.context);
        if std::env::var_os("EXIT_KEEP_EGL").is_none() {
            let _ = self.egl.terminate(self.display);
        }
    }
}

/// The subset of a dma-buf description needed to import it.
/// 导入 dma-buf 所需的描述子集。
impl EglContext {
    /// Turn a dma-buf into a renderable texture + framebuffer.
    /// 把 dma-buf 变成可渲染的纹理 + 帧缓冲。
    ///
    /// The EGLImage must outlive the texture, so it is returned too; the caller destroys
    /// it after deleting the texture.
    /// EGLImage 必须活得比纹理久，因此一并返回；调用方删除纹理之后再销毁它。
    #[allow(clippy::type_complexity)]
    pub fn create_dmabuf_texture(
        &self,
        desc: &DmaBufDesc,
    ) -> Result<(glow::Texture, glow::Framebuffer, *mut std::ffi::c_void), crate::GpuError> {
        let image = self.import_dmabuf(desc)?;
        let gl = self.gl();
        let texture = unsafe {
            let tex = gl.create_texture()?;
            gl.bind_texture(glow::TEXTURE_2D, Some(tex));
            self.bind_image_texture(image);
            let err = gl.get_error();
            if err != 0 {
                self.destroy_image(image);
                return Err(crate::GpuError::Gl(format!(
                    "glEGLImageTargetTexture2DOES: {err:#x}"
                )));
            }
            gl.tex_parameter_i32(
                glow::TEXTURE_2D,
                glow::TEXTURE_MIN_FILTER,
                glow::NEAREST as i32,
            );
            gl.tex_parameter_i32(
                glow::TEXTURE_2D,
                glow::TEXTURE_MAG_FILTER,
                glow::NEAREST as i32,
            );
            tex
        };
        let fbo = unsafe {
            let fbo = gl.create_framebuffer()?;
            gl.bind_framebuffer(glow::FRAMEBUFFER, Some(fbo));
            gl.framebuffer_texture_2d(
                glow::FRAMEBUFFER,
                glow::COLOR_ATTACHMENT0,
                glow::TEXTURE_2D,
                Some(texture),
                0,
            );
            let status = gl.check_framebuffer_status(glow::FRAMEBUFFER);
            if status != glow::FRAMEBUFFER_COMPLETE {
                return Err(crate::GpuError::Gl(format!("FBO incomplete: {status:#x}")));
            }
            gl.bind_framebuffer(glow::FRAMEBUFFER, None);
            fbo
        };
        Ok((texture, fbo, image))
    }
}

pub struct DmaBufDesc {
    pub fd: i32,
    pub width: u32,
    pub height: u32,
    pub stride: u32,
    pub offset: u32,
    pub format: u32,
    pub modifier: u64,
}

fn required_message(name: &'static str) -> &'static str {
    name
}
