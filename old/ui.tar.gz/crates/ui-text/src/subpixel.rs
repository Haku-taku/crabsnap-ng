//! Subpixel positioning: quantize glyph origins to a small set of phases.
//! 亚像素定位：把字形原点量化到少量相位。

/// Horizontal subpixel phase of a glyph origin, in quarters of a pixel.
/// 字形原点的水平亚像素相位，以四分之一像素为单位。
///
/// Four phases is the consensus: egui/epaint uses four bins, GPUI sets
/// `SUBPIXEL_VARIANTS_X = 4`. Neither does vertical subpixel positioning.
/// 四个相位是共识：egui/epaint 用四个分箱，GPUI 设 `SUBPIXEL_VARIANTS_X = 4`。
/// 两者都不做垂直亚像素定位。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash, PartialOrd, Ord)]
#[repr(u8)]
pub enum SubpixelBin {
    #[default]
    Zero = 0,
    One = 1,
    Two = 2,
    Three = 3,
}

/// Number of horizontal phases; also the atlas multiplier per glyph.
/// 水平相位数量；也是每个字形占用的图集倍数。
pub const SUBPIXEL_PHASES: u8 = 4;

impl SubpixelBin {
    /// Split `pos` into a whole-pixel origin and a phase.
    /// 把 `pos` 拆成整像素原点与相位。
    ///
    /// Rounds to the *nearest* quarter pixel, which is what keeps a run's
    /// accumulated fractional advances from snapping a whole pixel at once.
    /// 四舍五入到最近的 1/4 像素，这正是避免累计小数前进量整像素跳变的关键。
    pub fn split(pos: f32) -> (i32, Self) {
        if !pos.is_finite() {
            return (0, Self::Zero);
        }
        // Work in quarter-pixel units so rounding and splitting share one integer.
        // 以 1/4 像素为单位，使取整与拆分共用一个整数。
        let quarters = (pos * SUBPIXEL_PHASES as f32).round() as i32;
        let whole = quarters.div_euclid(SUBPIXEL_PHASES as i32);
        let phase = quarters.rem_euclid(SUBPIXEL_PHASES as i32) as u8;
        (whole, Self::from_index(phase))
    }

    pub fn from_index(i: u8) -> Self {
        match i & 3 {
            0 => Self::Zero,
            1 => Self::One,
            2 => Self::Two,
            _ => Self::Three,
        }
    }

    pub fn index(self) -> u8 {
        self as u8
    }

    /// Phase as a fraction of a pixel: 0.0, 0.25, 0.5 or 0.75.
    /// 相位占像素的比例：0.0、0.25、0.5 或 0.75。
    pub fn as_float(self) -> f32 {
        self as u8 as f32 / SUBPIXEL_PHASES as f32
    }

    /// Reconstruct the quantized position from a split origin.
    /// 由拆分后的原点重建量化位置。
    pub fn recombine(whole: i32, bin: Self) -> f32 {
        whole as f32 + bin.as_float()
    }
}

/// Whether a run should use subpixel phases at all.
/// 某段文本是否应使用亚像素相位。
///
/// CJK is excluded: thousands of characters times four phases would dominate the
/// atlas, and Han glyphs are near-square so horizontal jitter is less visible.
/// CJK 被排除：数千字符乘以四相位会主导图集，且汉字近方形，水平抖动不明显。
pub fn should_subpixel(script: crate::Script) -> bool {
    !matches!(script, crate::Script::HAN | crate::Script::HIRAGANA | crate::Script::HANGUL)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn split_rounds_to_the_nearest_quarter() {
        assert_eq!(SubpixelBin::split(0.0), (0, SubpixelBin::Zero));
        assert_eq!(SubpixelBin::split(0.1), (0, SubpixelBin::Zero));
        assert_eq!(SubpixelBin::split(0.13), (0, SubpixelBin::One));
        assert_eq!(SubpixelBin::split(0.4), (0, SubpixelBin::Two));
        assert_eq!(SubpixelBin::split(0.7), (0, SubpixelBin::Three));
        // 0.9 rounds up into the next whole pixel, back to phase zero.
        // 0.9 向上取整到下一个整像素，相位回到零。
        assert_eq!(SubpixelBin::split(0.9), (1, SubpixelBin::Zero));
    }

    #[test]
    fn split_handles_negative_positions() {
        assert_eq!(SubpixelBin::split(-0.1), (0, SubpixelBin::Zero));
        assert_eq!(SubpixelBin::split(-0.3), (-1, SubpixelBin::Three));
        assert_eq!(SubpixelBin::split(-0.9), (-1, SubpixelBin::Zero));
        // -1.4 is nearest to -1.5, so it lands one whole pixel down at phase two.
        // -1.4 最接近 -1.5，因此落到下一个整像素的相位二。
        assert_eq!(SubpixelBin::split(-1.4), (-2, SubpixelBin::Two));
    }

    #[test]
    fn recombine_is_within_a_quarter_pixel_of_the_input() {
        for i in -400..400 {
            let pos = i as f32 * 0.017;
            let (whole, bin) = SubpixelBin::split(pos);
            let back = SubpixelBin::recombine(whole, bin);
            assert!(
                (back - pos).abs() <= 0.125 + 1e-4,
                "pos {pos} -> {back} drifts more than an eighth pixel"
            );
        }
    }

    #[test]
    fn accumulated_advances_do_not_jump_a_whole_pixel() {
        // A 10.37 px advance drifts by design; the quantized origin must never
        // move more than one quarter pixel beyond the ideal position.
        // 10.37px 的前进量本身就在漂移；量化后的原点偏离理想位置不得超过 1/4 像素。
        let advance = 10.37_f32;
        let mut pen = 0.0_f32;
        let mut previous: Option<i32> = None;
        for _ in 0..40 {
            let (whole, _bin) = SubpixelBin::split(pen);
            if let Some(prev) = previous {
                let jump = whole - prev;
                assert!(
                    jump == 10 || jump == 11,
                    "pen {pen} jumped {jump} px, expected 10 or 11"
                );
            }
            previous = Some(whole);
            pen += advance;
        }
    }

    #[test]
    fn cjk_scripts_skip_subpixel_phases() {
        assert!(should_subpixel(crate::Script::LATIN));
        assert!(should_subpixel(crate::Script::ARABIC));
        assert!(!should_subpixel(crate::Script::HAN));
        assert!(!should_subpixel(crate::Script::HIRAGANA));
        assert!(!should_subpixel(crate::Script::HANGUL));
    }

    #[test]
    fn phase_index_round_trips() {
        for i in 0..8u8 {
            let bin = SubpixelBin::from_index(i);
            assert_eq!(bin.index(), i & 3);
            assert!((0.0..1.0).contains(&bin.as_float()));
        }
    }
}
