//! Font stack: platform-native enumeration with an explicit fallback chain.
//! 字体栈：逐平台枚举系统字体，并给出显式回退链。
//!
//! The engine never names a concrete font. It asks for a `FontRequest` and
//! receives a resolved face, so swapping the provider (native, bundled, test)
//! changes nothing above this module.
//! 引擎从不指名具体字体；它提出 `FontRequest` 并拿到已解析的字面，
//! 因此替换提供者（原生/内置/测试）不影响上层。

pub mod bidi;
pub mod emoji;
pub mod fallback;
pub mod linebreak;
pub mod provider;
pub mod subpixel;

pub use bidi::{itemize, visual_order, visual_runs, Direction, LevelRun};
pub use fallback::{FontStack, ResolvedFont};
pub use linebreak::{
    break_lines, min_content_width, wrap, wrap_indented, Line, ELLIPSIS,
};
pub use subpixel::{SubpixelBin, SUBPIXEL_PHASES};
pub use provider::{
    FaceId, FaceMetrics, Features, FontBlob, FontProvider, FontRequest, GenericFamily, Script,
    StaticProvider, Variations, Weight,
};

/// Measurement over the chosen font stack.
/// 经由选定字体栈的测量。
pub struct StackMeasure {
    stack: FontStack,
}

impl StackMeasure {
    pub fn new(stack: FontStack) -> Self {
        Self { stack }
    }

    pub fn stack_mut(&mut self) -> &mut FontStack {
        &mut self.stack
    }
}

impl ui_core::TextMeasure for StackMeasure {
    fn layout(
        &mut self,
        block: &ui_core::TextBlock,
        max_width: f32,
    ) -> std::rc::Rc<ui_core::InlineLayout> {
        use ui_core::{InlineAtom, InlineLayout, InlineLine};
        let (text, spans) = block.flatten();
        if spans.is_empty() {
            return empty_layout();
        }
        // Face metrics per span: ascent, descent and the face's own line height.
        // 逐 span 的字面度量：上升、下降与字面自带的行高。
        let stack = &mut self.stack;
        let boxes: Vec<(std::ops::Range<usize>, f32, f32, f32)> = spans
            .iter()
            .map(|span| {
                let m = stack
                    .resolve_for_text(&text[span.range.clone()], span.style.size)
                    .metrics;
                let ascent = m.ascent * span.style.size;
                let descent = -m.descent * span.style.size;
                (
                    span.range.clone(),
                    ascent,
                    descent,
                    m.line_height() * span.style.size,
                )
            })
            .collect();
        // An atom takes its own size, never the room left on the line; the U+FFFC glyph
        // it replaces is not measured at all.
        // 原子取自身尺寸，绝不用行内剩余空间；它替代的 U+FFFC 字形根本不参与测量。
        // The ellipsis is drawn in the style of the text it replaces, so it is measured
        // in the last span's size; the source itself has no ellipsis to measure.
        // 省略号用它所替代文字的样式绘制，因此按最后一个 span 的字号测量；
        // 源文本里本来就没有可量的省略号。
        let ellipsis_width = stack
            .resolve_for_text(ELLIPSIS, ui_core::TextBlock::style_at(&spans, text.len()).size)
            .width;
        let lines = wrap_indented(
            &text,
            max_width,
            block.max_lines,
            block.indent,
            ellipsis_width,
            |_slice, range| range_width(stack, &text, &spans, &block.atoms, range),
        );
        let mut out: Vec<InlineLine> = Vec::with_capacity(lines.len());
        let mut y = 0.0f32;
        for line in lines {
            let on_line: Vec<ui_core::AtomBox> = block
                .atoms
                .iter()
                .copied()
                .filter(|a| a.at >= line.range.start && a.at < line.range.end)
                .collect();
            let mut ascent = 0.0f32;
            let mut descent = 0.0f32;
            let mut box_h = 0.0f32;
            for (span, a, d, h) in &boxes {
                if span.start < line.range.end && span.end > line.range.start {
                    ascent = ascent.max(*a);
                    descent = descent.max(*d);
                    box_h = box_h.max(*h);
                }
            }
            let (height, baseline) = ui_core::text::line_metrics(ascent, descent, box_h, &on_line);
            let mut atoms = Vec::new();
            let mut pen = 0.0f32;
            let mut from = line.range.start;
            for atom in &on_line {
                if atom.at > from {
                    let size = ui_core::TextBlock::style_at(&spans, from).size;
                    pen += stack.resolve_for_text(&text[from..atom.at], size).width;
                }
                atoms.push(InlineAtom {
                    at: atom.at,
                    x: pen,
                    y: atom.align.top(atom.size, atom.baseline, baseline, height),
                    size: atom.size,
                    align: atom.align,
                });
                pen += atom.size.w;
                from = atom.at + ui_core::OBJECT.len_utf8();
            }
            out.push(InlineLine {
                y,
                height,
                baseline,
                width: line.width,
                ellipsis: line.ellipsis,
                runs: ui_core::text::runs_in(block, &spans, line.range.clone()),
                atoms,
            });
            // A gap sits between lines only; the last line adds none.
            // 空隙只在行与行之间；最后一行之后不加。
            y += height + block.line_gap;
        }
        let height = y - block.line_gap;
        let width = out.iter().fold(0.0f32, |acc, l| acc.max(l.width)) + block.indent.max(0.0);
        let baseline = out.first().map_or(0.0, |l| l.baseline);
        std::rc::Rc::new(InlineLayout {
            lines: out,
            width,
            height: height.max(0.0),
            baseline,
        })
    }

    /// The narrowest this block can get: its widest unbreakable segment.
    /// 本块能取到的最窄宽度：最宽的不可断片段。
    fn intrinsic(&mut self, block: &ui_core::TextBlock) -> (ui_core::Size, ui_core::Size) {
        let max = self.measure(block, f32::INFINITY);
        let (text, spans) = block.flatten();
        if spans.is_empty() {
            return (ui_core::Size::new(0.0, max.h), max);
        }
        let min_w = min_content_width(&text, |_slice, range| {
            range_width(&mut self.stack, &text, &spans, &block.atoms, range)
        });
        (ui_core::Size::new(min_w, max.h), max)
    }
}

/// Width of `range`: atoms at their own size, the U+FFFC standing in for them at none.
/// `range` 的宽度：原子按自身尺寸计，代替它们的 U+FFFC 不计。
fn range_width(
    stack: &mut FontStack,
    text: &str,
    spans: &[ui_core::Span],
    atoms: &[ui_core::AtomBox],
    range: std::ops::Range<usize>,
) -> f32 {
    let mut total = 0.0f32;
    let mut from = range.start;
    for atom in atoms
        .iter()
        .filter(|a| a.at >= range.start && a.at < range.end)
    {
        if atom.at > from {
            let piece = text.get(from..atom.at).unwrap_or("");
            let size = ui_core::TextBlock::style_at(spans, from).size;
            total += stack.resolve_for_text(piece, size).width;
        }
        total += atom.size.w;
        from = atom.at + ui_core::OBJECT.len_utf8();
    }
    if from < range.end {
        let piece = text.get(from..range.end).unwrap_or("");
        let size = ui_core::TextBlock::style_at(spans, from).size;
        total += stack.resolve_for_text(piece, size).width;
    }
    total
}

/// A block with no text still owns one line box, so a caret has somewhere to sit.
/// 没有文字的块仍有一条行盒，插入符才有落点。
fn empty_layout() -> std::rc::Rc<ui_core::InlineLayout> {
    let height = ui_core::TextStyle::default().size * 1.2;
    std::rc::Rc::new(ui_core::InlineLayout {
        lines: vec![ui_core::InlineLine {
            y: 0.0,
            height,
            baseline: height * 0.8,
            width: 0.0,
            ellipsis: false,
            runs: Vec::new(),
            atoms: Vec::new(),
        }],
        width: 0.0,
        height,
        baseline: height * 0.8,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use ui_core::TextMeasure;

    fn static_stack() -> FontStack {
        let provider = StaticProvider::new("test")
            .with_face("Test Sans", 0.6)
            .with_face("Test Mono", 0.5);
        FontStack::new(provider)
    }

    fn block(text: &str, size: f32) -> ui_core::TextBlock {
        ui_core::TextBlock::plain(text, ui_core::TextStyle::new(size))
    }

    #[test]
    fn measure_uses_the_resolved_face_advance() {
        let mut m = StackMeasure::new(static_stack());
        let a = m.measure(&block("abc", 10.0), f32::INFINITY);
        let b = m.measure(&block("abcdef", 10.0), f32::INFINITY);
        assert!((b.w - a.w * 2.0).abs() < 0.01, "width must scale with char count");
    }

    #[test]
    fn measure_wraps_when_the_line_exceeds_max_width() {
        let mut m = StackMeasure::new(static_stack());
        let one_line = m.measure(&block("abcde", 10.0), f32::INFINITY);
        let wrapped = m.measure(&block("abcde", 10.0), 10.0);
        assert!(
            wrapped.h > one_line.h,
            "narrow width must increase height by wrapping"
        );
        assert!(wrapped.w <= 10.0);
    }

    #[test]
    fn zero_length_text_measures_zero_width() {
        let mut m = StackMeasure::new(static_stack());
        assert_eq!(m.measure(&block("", 12.0), f32::INFINITY).w, 0.0);
    }
}
