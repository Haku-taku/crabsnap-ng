//! Greedy line breaking over UAX #14 opportunities.
//! 按 UAX #14 换行机会做贪心断行。
//!
//! Layout measures with this and paint positions with this, so the two cannot disagree
//! about where the lines are.
//! 布局用这个测量、绘制用这个排位，因此两者不可能对断行位置产生分歧。

use std::ops::Range;

use unicode_linebreak::BreakOpportunity::Mandatory;

/// One visual line: a byte range into the source plus its advance width.
/// 一条视觉行：源文本中的字节区间及其推进宽度。
#[derive(Clone, Debug, PartialEq)]
pub struct Line {
    /// Trailing whitespace is excluded, so the glyphs stop where the ink stops.
    /// 已排除行尾空白，因此字形止于墨迹处。
    pub range: Range<usize>,
    pub width: f32,
    /// True when this line ends with an ellipsis appended by `wrap`.
    /// 为真时本行末尾由 `wrap` 追加了省略号。
    pub ellipsis: bool,
}

/// Break `text` into lines no wider than `max_width`.
/// 把 `text` 断成不超过 `max_width` 的行。
///
/// `width_of` is measured once per segment, so the greedy pass stays linear; kerning
/// across a break opportunity is therefore not counted, which no line count depends on.
/// 每段只测量一次，贪心过程保持线性；因此不计跨换行机会的字偶间距，而行数不受其影响。
pub fn break_lines<F>(text: &str, max_width: f32, width_of: F) -> Vec<Line>
where
    F: FnMut(&str, Range<usize>) -> f32,
{
    break_lines_indented(text, max_width, 0.0, width_of)
}

/// Widest unbreakable segment: the narrowest width this text can be laid out at.
/// 最宽的不可断片段：这段文字能排到的最窄宽度。
pub fn min_content_width<F>(text: &str, mut width_of: F) -> f32
where
    F: FnMut(&str, Range<usize>) -> f32,
{
    let mut widest = 0.0f32;
    let mut segment = |start: usize, end: usize| {
        let visible = trim_end(text, start, end);
        if visible > start {
            width_of(&text[start..visible], start..visible)
        } else {
            0.0
        }
    };
    let mut start = 0usize;
    for (index, _) in unicode_linebreak::linebreaks(text) {
        if index <= start {
            continue;
        }
        widest = widest.max(segment(start, index));
        start = index;
    }
    if start < text.len() {
        widest = widest.max(segment(start, text.len()));
    }
    widest
}

/// Like [`break_lines`], but the first line has `indent` less room.
/// 与 [`break_lines`] 相同，但首行少 `indent` 的可用宽度。
///
/// The indent narrows the first line only: it must participate in wrapping, or the first
/// line overflows into the indent area and the paragraph looks right-aligned by accident.
/// 缩进只收窄首行：它必须参与换行，否则首行会溢出到缩进区，
/// 看起来像段落意外右对齐了。
pub fn break_lines_indented<F>(
    text: &str,
    max_width: f32,
    indent: f32,
    mut width_of: F,
) -> Vec<Line>
where
    F: FnMut(&str, Range<usize>) -> f32,
{
    if text.is_empty() {
        return vec![Line {
            range: 0..0,
            width: 0.0,
            ellipsis: false,
        }];
    }

    // Segment at every opportunity; `visible` trims the trailing whitespace.
    // Each segment keeps both widths: `full` includes the trailing whitespace that
    // separates it from the next word, `ink` does not.
    // 每段记录两个宽度：`full` 含与后词分隔的尾部空白，`ink` 不含。
    let mut segments: Vec<(Range<usize>, f32, f32, bool)> = Vec::new();
    let mut start = 0usize;
    for (index, opportunity) in unicode_linebreak::linebreaks(text) {
        if index <= start {
            continue;
        }
        let visible = trim_end(text, start, index);
        segments.push((
            start..index,
            width_of(&text[start..index], start..index),
            width_of(&text[start..visible], start..visible),
            opportunity == Mandatory,
        ));
        start = index;
    }
    if start < text.len() {
        let visible = trim_end(text, start, text.len());
        segments.push((
            start..text.len(),
            width_of(&text[start..], start..text.len()),
            width_of(&text[start..visible], start..visible),
            true,
        ));
    }

    let wrap = max_width.is_finite() && max_width > 0.0;
    let first_limit = (max_width - indent.max(0.0)).max(0.0);
    // Count lines, not segments: `first` is a segment index and stays 0 when the text has
    // no break opportunity, which would apply the indent to every line.
    // 数行而不是数段：`first` 是段索引，文本没有断行机会时恒为 0，
    // 那会把缩进施加到每一行。
    let mut line_no = 0usize;
    let mut lines = Vec::new();
    let mut first = 0usize;
    // Width of the segments already on this line, including the spaces between them.
    // 本行已有各段的宽度，包含段间空格。
    let mut prefix = 0.0f32;
    let mut ink = 0.0f32;
    let mut last_end = segments.first().map_or(0, |s| s.0.start);

    for (i, (range, full, trimmed, mandatory)) in segments.iter().enumerate() {
        let starts_line = i == first;
        // A line's width is the previous segments plus this one without its trailing space.
        // 行宽等于此前各段加上本段（去掉尾部空白）。
        let candidate = prefix + trimmed;
        let limit = if line_no == 0 { first_limit } else { max_width };
        if !starts_line && wrap && candidate > limit {
            lines.push(Line {
                range: segments[first].0.start..last_end,
                width: ink,
                ellipsis: false,
            });
            line_no += 1;
            first = i;
            prefix = 0.0;
        }
        let candidate = if i == first { *trimmed } else { prefix + trimmed };
        prefix += full;
        ink = candidate;
        last_end = trim_end(text, range.start, range.end);
        if *mandatory {
            lines.push(Line {
                range: segments[first].0.start..last_end,
                width: ink,
                ellipsis: false,
            });
            line_no += 1;
            first = i + 1;
            prefix = 0.0;
            ink = 0.0;
        }
    }
    if first < segments.len() {
        lines.push(Line {
            range: segments[first].0.start..last_end,
            width: ink,
            ellipsis: false,
        });
    } else if segments
        .last()
        .is_some_and(|s| text[s.0.clone()].ends_with('\n'))
    {
        // The last segment closed on a hard break at the buffer end, so text lives after it:
        // `white-space: pre` keeps that empty final line, and the editor's caret needs it.
        // 最后一段在缓冲末尾的强制断行处收束，其后仍有文本：`white-space: pre` 保留
        // 这条末尾空行，编辑器的插入符也需要它。
        lines.push(Line {
            range: text.len()..text.len(),
            width: 0.0,
            ellipsis: false,
        });
    }

    // A single segment wider than the limit still has to fit: cut it by cluster.
    // 单段超过上限时仍须放下：按字簇切开。
    if wrap {
        let mut out = Vec::with_capacity(lines.len());
        for (index, line) in lines.into_iter().enumerate() {
            let limit = if index == 0 { first_limit } else { max_width };
            if line.width <= limit {
                out.push(line);
                continue;
            }
            out.extend(split_by_cluster_with(
                text,
                line.range,
                limit,
                max_width,
                &mut width_of,
            ));
        }
        lines = out;
    }
    lines
}

/// Appended to the last line when the text does not fit in `max_lines`.
/// 文本放不进 `max_lines` 时追加到最后一行。
pub const ELLIPSIS: &str = "…";

/// Like [`break_lines`], and if `max_lines` is exceeded, end the last line with an ellipsis.
/// 与 [`break_lines`] 相同；超过 `max_lines` 时让最后一行以省略号结束。
pub fn wrap<F>(
    text: &str,
    max_width: f32,
    max_lines: Option<u32>,
    ellipsis_width: f32,
    width_of: F,
) -> Vec<Line>
where
    F: FnMut(&str, Range<usize>) -> f32,
{
    wrap_indented(text, max_width, max_lines, 0.0, ellipsis_width, width_of)
}

/// Like [`wrap`], with a narrower first line.
/// 与 [`wrap`] 相同，只是首行更窄。
///
/// The truncated line's `range` excludes the ellipsis; painters append `ELLIPSIS` when
/// `Line::ellipsis` is set, so measurement and painting use the same string.
/// 截断行的 `range` 不含省略号；绘制端在 `Line::ellipsis` 为真时追加 `ELLIPSIS`，
/// 使测量与绘制用同一串。
///
/// `ellipsis_width` is the advance of [`ELLIPSIS`] in the block's own style: the source has
/// no ellipsis to measure, so the measurer reports it rather than the wrap guessing.
/// `ellipsis_width` 是 [`ELLIPSIS`] 按本块样式的前进宽度：源文本里没有可量的省略号，
/// 因此由测量器给出，断行不猜。
pub fn wrap_indented<F>(
    text: &str,
    max_width: f32,
    max_lines: Option<u32>,
    indent: f32,
    ellipsis_width: f32,
    mut width_of: F,
) -> Vec<Line>
where
    F: FnMut(&str, Range<usize>) -> f32,
{
    let mut lines = break_lines_indented(text, max_width, indent, &mut width_of);
    let Some(limit) = max_lines.filter(|l| *l > 0) else {
        return lines;
    };
    let limit = limit as usize;
    if lines.len() <= limit {
        return lines;
    }

    // Keep the first `limit - 1` lines and fit what remains into one ellipsized line.
    // 保留前 `limit - 1` 行，把余下的压进一行并加省略号。
    lines.truncate(limit);
    let start = lines[limit - 1].range.start;
    // The first line is the one the indent narrows, exactly as in the untruncated pass.
    // 缩进收窄的正是第一行，与未截断那一趟相同。
    let room = if limit == 1 {
        (max_width - indent.max(0.0)).max(0.0)
    } else {
        max_width
    };
    let mut cut = start;
    for (offset, cluster) in ui_core::grapheme::clusters(&text[start..]) {
        let end = start + offset + cluster.len();
        if width_of(&text[start..end], start..end) + ellipsis_width > room {
            break;
        }
        cut = end;
    }
    lines[limit - 1] = Line {
        range: start..cut,
        width: width_of(&text[start..cut], start..cut) + ellipsis_width,
        ellipsis: true,
    };
    lines
}

/// Split one over-long range at cluster boundaries, allowing a narrower first piece.
/// 在字簇边界上切开一个过长的区间，允许首片更窄。
fn split_by_cluster_with<F>(
    text: &str,
    range: Range<usize>,
    first_width: f32,
    max_width: f32,
    width_of: &mut F,
) -> Vec<Line>
where
    F: FnMut(&str, Range<usize>) -> f32,
{
    let mut out = Vec::new();
    let mut start = range.start;
    let mut last_fit = range.start;
    for (offset, cluster) in ui_core::grapheme::clusters(&text[range.clone()]) {
        let end = range.start + offset + cluster.len();
        let width = width_of(&text[start..end], start..end);
        let limit = if out.is_empty() { first_width } else { max_width };
        if width > limit && end > start {
            // A cluster wider than the limit still takes a line of its own; never split it.
            // 比上限还宽的字簇也独占一行，绝不切开它。
            let first = ui_core::grapheme::next(text, start);
            let cut = last_fit.max(first);
            out.push(Line {
                range: start..cut,
                width: width_of(&text[start..cut], start..cut),
                ellipsis: false,
            });
            start = cut;
            last_fit = start;
            continue;
        }
        last_fit = end;
    }
    if start < range.end {
        out.push(Line {
            range: start..range.end,
            width: width_of(&text[start..range.end], start..range.end),
            ellipsis: false,
        });
    }
    out
}

/// End of `text[start..end]` with trailing whitespace removed.
/// 去掉尾部空白后的 `text[start..end]` 结束位置。
fn trim_end(text: &str, start: usize, end: usize) -> usize {
    let slice = &text[start..end];
    start + slice.trim_end_matches(char::is_whitespace).len()
}


#[cfg(test)]
mod tests {
    use super::*;

    /// Ten units per character, so expected widths are easy to state.
    /// 每字符十单位，便于直接写出期望宽度。
    fn ten(s: &str, _: Range<usize>) -> f32 {
        s.chars().count() as f32 * 10.0
    }

    fn lines(text: &str, max: f32) -> Vec<(Range<usize>, f32)> {
        break_lines(text, max, ten)
            .into_iter()
            .map(|l| (l.range, l.width))
            .collect()
    }

    #[test]
    fn short_text_is_one_line() {
        let got = lines("hello", 1000.0);
        assert_eq!(got, vec![(0..5, 50.0)]);
    }

    #[test]
    fn min_content_is_the_widest_segment_the_breaker_will_not_split() {
        // A layout that reported the whole line as min-content could never shrink, so a
        // panel asked to fit 320 would still measure as wide as its message on one line.
        // 把整行当作 min-content 的布局永远缩不小，于是要求 320 宽的面板仍按整行消息测量。
        assert_eq!(min_content_width("one two three", ten), 50.0);
        // CJK breaks between characters, so its floor is one character, not the run.
        // CJK 逐字可断，下限因此是一个字宽，而不是整段。
        assert_eq!(min_content_width("中文字体", ten), 10.0);
        // A hard break ends a segment; the widest of them still sets the floor.
        // 硬断行结束一个片段；其中仍由最宽者决定下限。
        assert_eq!(min_content_width("ab\ncdef", ten), 40.0);
    }

    /// The truncation must reserve the ellipsis it is about to draw, or the line overflows.
    /// 截断必须为它将要画的省略号留出位置，否则这一行会溢出。
    #[test]
    fn a_truncated_line_reserves_room_for_its_ellipsis() {
        // The real measurers read the range, not the slice, so this closure does too.
        // 真正的测量器读的是区间而不是切片，因此这条闭包也这样读。
        let by_range = |_: &str, r: Range<usize>| r.end.saturating_sub(r.start) as f32 * 10.0;
        let out = wrap_indented("aaaa bbbb", 49.0, Some(1), 0.0, 15.0, by_range);
        assert_eq!(&"aaaa bbbb"[out[0].range.clone()], "aaa");
        assert_eq!(out[0].width, 45.0, "three characters plus the ellipsis");
        assert!(out[0].ellipsis);
    }

    #[test]
    fn empty_text_still_yields_one_line() {
        // Layout needs a height even for empty text.
        // 即使是空文本，布局也需要一个行高。
        assert_eq!(lines("", 100.0), vec![(0..0, 0.0)]);
    }

    #[test]
    fn an_indent_narrows_only_the_first_line() {
        // Spaces are what make this test meaningful: without a break opportunity the text
        // takes the character-splitting path, where the indent is applied elsewhere.
        // 空格是这条测试的意义所在：没有断行机会时走的是按字符切分路径，
        // 缩进在别处生效，测不到按段换行这条路径。
        // Every char (space included) is 10 wide, so "aaa bbb ccc" is 110.
        // 每个字符（含空格）宽 10，故 "aaa bbb ccc" 共 110。
        let width = |s: &str, _r: std::ops::Range<usize>| s.chars().count() as f32 * 10.0;
        let plain = break_lines("aaa bbb ccc", 110.0, width);
        let indented = break_lines_indented("aaa bbb ccc", 110.0, 40.0, width);
        assert_eq!(plain.len(), 1, "without an indent the whole line fits");
        assert!(indented.len() > 1, "the indent must force a second line");
    }

    #[test]
    fn an_indent_shortens_the_first_line_only() {
        // Same widths, now narrow enough that the plain version wraps too, so the two
        // differ only in where the *first* break falls.
        // 同样的宽度，但窄到无缩进版本也换行，因此两者只在**首行**断点处不同。
        let width = |s: &str, _r: std::ops::Range<usize>| s.chars().count() as f32 * 10.0;
        let plain = break_lines("aaa bbb ccc", 70.0, width);
        let indented = break_lines_indented("aaa bbb ccc", 70.0, 40.0, width);
        let count = |lines: &[Line]| -> Vec<usize> {
            lines
                .iter()
                .map(|l| l.range.end.saturating_sub(l.range.start))
                .collect()
        };
        // The indent moves the *first* break earlier and everything after it later:
        // that is exactly "shortens the first line only".
        // 缩进把**首行**断点前移，其后的行因此变长：
        // 这正是「只缩短首行」的含义。
        assert_eq!(count(&plain), vec![7, 3], "no indent: two segments on line 1");
        assert_eq!(
            count(&indented),
            vec![3, 7],
            "with the indent only one segment fits on line 1"
        );
    }

    #[test]
    fn an_indent_wider_than_the_line_still_makes_progress() {
        // A pathological indent must not loop or drop text: the first line just gets the
        // minimum one character, and everything still lands in the output.
        // 极端缩进不得死循环或丢字：首行只拿到最小的一字符，所有内容仍出现在结果里。
        let width = |s: &str, _r: std::ops::Range<usize>| s.chars().count() as f32 * 10.0;
        let lines = break_lines_indented("aaaa", 50.0, 200.0, width);
        let total: usize = lines
            .iter()
            .map(|l| l.range.end.saturating_sub(l.range.start))
            .sum();
        assert_eq!(total, 4, "no character may be dropped");
        // Only the first line is starved; the rest keep the full width, so the text ends
        // up in fewer lines than characters. What matters is that it makes progress.
        // 只有首行被压缩，其余行保持完整宽度，因此总行数少于字符数。
        // 关键是不能停滞。
        let first = lines.first().expect("at least one line");
        assert!(
            first.range.end > first.range.start,
            "the first line must still hold at least one character"
        );
        assert!(lines.len() >= 2, "the rest must spill onto later lines");
    }

    #[test]
    fn wraps_at_spaces_not_inside_words() {
        // "aa bb cc" advances 20 + 10 + 20 + 10 + 20; at 50 the third word must move down.
        // "aa bb cc" 推进为 20 + 10 + 20 + 10 + 20；限制 50 时第三个词必须下移。
        let got = lines("aa bb cc", 50.0);
        assert_eq!(got.len(), 2);
        assert_eq!(&"aa bb cc"[got[0].0.clone()], "aa bb");
        assert_eq!(&"aa bb cc"[got[1].0.clone()], "cc");
        assert_eq!(got[0].1, 50.0, "the space between the words must count");
    }

    #[test]
    fn trailing_space_does_not_count_towards_the_width() {
        // A trailing space is not ink, so it must not widen the line.
        // 行尾空格不是墨迹，因此不得让行变宽。
        let bare = lines("aa bb", 1000.0);
        let padded = lines("aa bb ", 1000.0);
        assert_eq!(bare[0].1, padded[0].1, "a trailing space must not add width");
        assert_eq!(bare[0].1, 50.0, "the inner space must count");
    }

    #[test]
    fn a_newline_forces_a_break() {
        let got = lines("a\nb", 1000.0);
        assert_eq!(got.len(), 2);
        assert_eq!(&"a\nb"[got[0].0.clone()], "a");
        assert_eq!(&"a\nb"[got[1].0.clone()], "b");
    }

    #[test]
    fn a_trailing_newline_keeps_its_empty_line_box() {
        // The editor's `\n` at the end of a buffer still owns the line after it, so a caret
        // on that empty line has somewhere to sit. CSS `white-space: pre` keeps the box too.
        // 缓冲末尾的 `\n` 仍拥有其后那一行，插在那条空行上的插入符才有落点。
        // CSS `white-space: pre` 同样保留这个行盒。
        let got = lines("a\n", 1000.0);
        assert_eq!(got.len(), 2, "a trailing hard break opens one more line");
        assert_eq!(&"a\n"[got[0].0.clone()], "a");
        assert_eq!(got[1].0.clone(), 2..2, "the last line is empty at the buffer end");
        assert_eq!(lines("\n", 1000.0).len(), 2, "a lone newline is two empty lines");
        assert_eq!(lines("a\n\n", 1000.0).len(), 3, "so is the line before it");
        // Without the trailing break the count must not change.
        // 没有行尾断行时行数不变。
        assert_eq!(lines("a", 1000.0).len(), 1);
        assert_eq!(lines("a\nb", 1000.0).len(), 2);
    }

    #[test]
    fn an_overlong_word_is_cut_by_character() {
        // "abcdefgh" is 80 wide and has no opportunity, so it must be split to fit 30.
        // "abcdefgh" 宽 80 且无换行机会，必须切开才放得进 30。
        let got = lines("abcdefgh", 30.0);
        assert!(got.len() >= 3, "expected a character split, got {got:?}");
        assert!(
            got.iter().all(|(_, w)| *w <= 30.0),
            "every piece must fit: {got:?}"
        );
        let joined: String = got
            .iter()
            .map(|(r, _)| &"abcdefgh"[r.clone()])
            .collect();
        assert_eq!(joined, "abcdefgh", "splitting must not lose text");
    }

    #[test]
    fn no_line_exceeds_the_limit() {
        let text = "the quick brown fox jumps over the lazy dog";
        let got = break_lines(text, 100.0, ten);
        assert!(got.iter().all(|l| l.width <= 100.0), "got {got:?}");
        let joined: String = got.iter().map(|l| &text[l.range.clone()]).collect::<Vec<_>>().join(" ");
        assert_eq!(joined, text, "wrapping must not lose or reorder text");
    }

    #[test]
    fn wrap_keeps_every_line_when_under_the_limit() {
        let got = wrap("aa bb cc", 50.0, Some(5), 10.0, ten);
        assert_eq!(got.len(), 2, "no truncation expected");
        assert!(got.iter().all(|l| !l.ellipsis));
    }

    #[test]
    fn wrap_marks_the_last_line_when_the_limit_is_exceeded() {
        // Three lines' worth of text capped at two: the second must be cut and flagged.
        // 文本本有三行但限两行：第二行必须被截断并标记。
        let got = wrap("aa bb cc dd ee ff", 50.0, Some(2), 10.0, ten);
        assert_eq!(got.len(), 2);
        assert!(!got[0].ellipsis);
        assert!(got[1].ellipsis, "the capped line must carry the ellipsis");
    }

    #[test]
    fn the_ellipsized_line_still_fits_the_width() {
        // The appended ellipsis counts towards the line, so the cut must leave room for it.
        // 追加的省略号计入行宽，因此截断必须为它留出空间。
        let text = "aa bb cc dd ee ff";
        let got = wrap(text, 50.0, Some(2), 10.0, ten);
        let last = got.last().expect("a line");
        assert!(
            last.width <= 50.0,
            "the ellipsized line must fit, got {}",
            last.width
        );
        // The capped line starts where the second line started ("cc dd"), so the
        // longest prefix plus "…" that fits 50 units is "cc d".
        // 被截断的行从第二行起点（"cc dd"）开始，因此能放进 50 单位的最长前缀加省略号是 "cc d"。
        assert_eq!(
            &text[last.range.clone()],
            "cc d",
            "the cut must keep the longest fitting prefix"
        );
    }
}
