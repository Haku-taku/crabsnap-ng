//! Resolving text to faces, with an explicit, inspectable fallback chain.
//! 把文本解析到字面，回退链显式且可检查。

use crate::provider::{FaceId, FaceMetrics, FontProvider, FontRequest, Script};

/// Outcome of trying to find a face that covers a whole run.
/// 为整段文本寻找覆盖字面的结果。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FallbackOutcome {
    /// The primary face covers the run; no fallback was attempted.
    /// 首选字面覆盖整段；未尝试回退。
    NotNeeded,
    /// A later face in the chain covers the whole run.
    /// 链中靠后的字面覆盖整段。
    Used,
    /// No single face covers the run; mixed-script runs need per-cluster
    /// splitting, which belongs to the shaper.
    /// 没有单字面覆盖整段；混合脚本需按字簇拆分，属整形器职责。
    Unresolved,
}

/// A resolved face plus the metrics and width computed for it.
/// 已解析的字面，以及为它算出的度量与宽度。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ResolvedFont {
    pub face: FaceId,
    pub metrics: FaceMetrics,
    pub width: f32,
    /// How many fallback steps were taken before a covering face was found.
    /// 找到覆盖字面前走了几步回退。
    pub fallback_steps: u8,
    pub outcome: FallbackOutcome,
}

/// The font stack: a provider plus per-script caching of the chain.
/// 字体栈：一个提供者，加上按脚本缓存回退链。
pub struct FontStack {
    provider: Box<dyn FontProvider>,
    /// Cached fallback chains, invalidated only on provider swap.
    /// 缓存的回退链，仅在替换提供者时失效。
    chains: std::collections::HashMap<Script, Vec<FaceId>>,
    /// Default request used when the caller names nothing.
    /// 调用方不指定时使用的默认请求。
    default_request: FontRequest,
    /// Counters, for tests and diagnostics.
    /// 计数器，供测试与诊断。
    pub stats: StackStats,
}

/// How often the stack had to fall back.
/// 字体栈回退的频次。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct StackStats {
    pub resolves: u64,
    pub fallbacks: u64,
    /// Faces tried and rejected because they lacked a glyph.
    /// 尝试过但因缺字形被拒的字面数。
    pub rejected: u64,
    /// Runs no single face could cover (mixed scripts).
    /// 无单字面能覆盖的文本段（混合脚本）。
    pub unresolved: u64,
}

impl FontStack {
    pub fn new(provider: impl FontProvider + 'static) -> Self {
        Self {
            provider: Box::new(provider),
            chains: std::collections::HashMap::new(),
            default_request: FontRequest::new(crate::provider::GenericFamily::SansSerif),
            stats: StackStats::default(),
        }
    }

    pub fn provider(&self) -> &dyn FontProvider {
        self.provider.as_ref()
    }

    pub fn provider_name(&self) -> &'static str {
        self.provider.name()
    }

    pub fn set_default_request(&mut self, request: FontRequest) {
        self.default_request = request;
    }

    /// Chain for `script`, cached after the first query.
    /// `script` 的回退链，首次查询后缓存。
    pub fn chain(&mut self, script: Script) -> &[FaceId] {
        self.chains
            .entry(script)
            .or_insert_with(|| self.provider.fallback_chain(script))
    }

    /// Pick the first face in the chain that covers every non-space char of `text`.
    /// 在链中选出第一个覆盖 `text` 所有非空格字符的字面。
    ///
    /// Returns the primary face when nothing covers the whole run; per-cluster
    /// splitting is a shaping concern and lands with the shaper.
    /// 若没有字面能覆盖整段，返回首选字面；按字簇拆分属于 shaping，随整形器一起落地。
    pub fn face_for_text(&mut self, request: &FontRequest, text: &str) -> (FaceId, u8, FallbackOutcome) {
        self.stats.resolves += 1;
        let primary = self
            .provider
            .resolve(request)
            .or_else(|| self.chain(request.script).first().copied());

        let Some(primary) = primary else {
            return (FaceId(0), 0, FallbackOutcome::Unresolved);
        };

        let needs_fallback = text
            .chars()
            .any(|c| !c.is_whitespace() && !self.provider.has_glyph(primary, c));
        if !needs_fallback {
            return (primary, 0, FallbackOutcome::NotNeeded);
        }

        let chain = self.chain(request.script).to_vec();
        for (steps, face) in chain.iter().enumerate().skip(1) {
            let covers = text
                .chars()
                .all(|c| c.is_whitespace() || self.provider.has_glyph(*face, c));
            self.stats.rejected += 1;
            if covers {
                self.stats.fallbacks += 1;
                return (*face, steps.min(u8::MAX as usize) as u8, FallbackOutcome::Used);
            }
        }
        // No single face covers the run. Mixed-script runs need the shaper to split
        // per cluster; until then the primary stays responsible and the outcome says so.
        // 没有单字面覆盖整段。混合脚本需整形器按字簇拆分；
        // 在此之前由首选负责，并由 outcome 如实反映。
        self.stats.unresolved += 1;
        (primary, 0, FallbackOutcome::Unresolved)
    }

    /// Resolve `text` and compute its width, using the default request.
    /// 解析 `text` 并算出宽度，使用默认请求。
    pub fn resolve_for_text(&mut self, text: &str, size: f32) -> ResolvedFont {
        let mut request = self.default_request.clone();
        // Narrow the chain to the script actually present in the run.
        // 把链收窄到这段文本真正出现的脚本。
        request.script = Script::dominant(text);
        self.resolve(&request, text, size)
    }

    /// Resolve `text` with an explicit request.
    /// 用显式请求解析 `text`。
    pub fn resolve(&mut self, request: &FontRequest, text: &str, size: f32) -> ResolvedFont {
        let (face, fallback_steps, outcome) = self.face_for_text(request, text);
        let metrics = self.provider.metrics(face);
        let width = self.provider.advance(face, text, size);
        ResolvedFont {
            face,
            metrics,
            width,
            fallback_steps,
            outcome,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::provider::{GenericFamily, StaticProvider};

    fn stack() -> FontStack {
        // Face 0 covers only Latin; face 1 covers CJK.
        // 字面 0 只覆盖拉丁；字面 1 覆盖中日韩。
        let provider = StaticProvider::new("test")
            .with_partial_face("Latin Only", 0.6, &['a', 'b', 'c', ' '])
            .with_partial_face("CJK Only", 0.75, &['中', '文', ' ']);
        FontStack::new(provider)
    }

    #[test]
    fn latin_text_stays_on_the_primary_face() {
        let mut s = stack();
        let r = s.resolve_for_text("abc", 10.0);
        assert_eq!(r.face, FaceId(0));
        assert_eq!(r.fallback_steps, 0);
        assert_eq!(s.stats.fallbacks, 0);
    }

    #[test]
    fn cjk_text_falls_back_to_the_next_face() {
        let mut s = stack();
        let r = s.resolve_for_text("中文", 10.0);
        assert_eq!(r.face, FaceId(1), "must pick the face that has the glyphs");
        assert_eq!(r.fallback_steps, 1);
        assert_eq!(s.stats.fallbacks, 1);
    }

    #[test]
    fn unresolved_text_keeps_the_primary_face() {
        let mut s = stack();
        // A char no face covers.
        // 没有任何字面覆盖的字符。
        let r = s.resolve_for_text("🦀", 10.0);
        assert_eq!(
            r.face,
            FaceId(0),
            "with no covering face the primary stays responsible"
        );
        assert_eq!(r.fallback_steps, 0);
    }

    #[test]
    fn whitespace_does_not_trigger_fallback() {
        let mut s = stack();
        let r = s.resolve_for_text("a b c", 10.0);
        assert_eq!(r.fallback_steps, 0);
        assert_eq!(s.stats.fallbacks, 0);
    }

    #[test]
    fn mixed_script_run_reports_unresolved_instead_of_silently_using_the_primary() {
        let mut s = stack();
        // Latin + CJK in one run: no single face covers everything.
        // 一段里既有拉丁又有中日韩：没有单字面覆盖全部。
        let r = s.resolve_for_text("abc中文", 10.0);
        assert_eq!(
            r.outcome,
            FallbackOutcome::Unresolved,
            "mixed-script runs must be reported, not silently misattributed"
        );
        assert_eq!(s.stats.unresolved, 1);
    }

    #[test]
    fn dominant_script_matches_the_first_non_ascii_char() {
        assert_eq!(Script::dominant("hello"), Script::LATIN);
        assert_eq!(Script::dominant("hello 中文"), Script::HAN);
        assert_eq!(Script::dominant("مرحبا"), Script::ARABIC);
        assert_eq!(Script::dominant("こんにちは"), Script::HIRAGANA);
    }

    #[test]
    fn named_family_wins_over_the_generic_default() {
        let provider = StaticProvider::new("test")
            .with_face("First", 0.6)
            .with_face("Mono Face", 0.5);
        let mut s = FontStack::new(provider);
        let req = FontRequest::new(GenericFamily::Monospace).family("Mono Face");
        let r = s.resolve(&req, "abc", 10.0);
        assert_eq!(r.face, FaceId(1));
        assert!((r.width - 15.0).abs() < 0.01, "0.5 * 10 * 3 chars");
    }

    #[test]
    fn metrics_drive_line_height() {
        let mut s = stack();
        let r = s.resolve_for_text("abc", 10.0);
        assert!((r.metrics.line_height() - 1.0).abs() < 0.01);
    }
}
