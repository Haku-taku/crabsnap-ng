//! Bidirectional text: split a paragraph into directional runs.
//! 双向文本：把段落拆成方向性的文本段。
//!
//! The Unicode algorithm itself comes from `unicode-bidi`; this module only maps
//! its per-byte levels onto the runs a shaper needs, and reorders them for display.
//! Unicode 算法本身来自 `unicode-bidi`；本模块只把逐字节 level 映射成整形器需要的
//! 文本段，并给出显示顺序。

use std::ops::Range;

use unicode_bidi::{BidiInfo, Level};

/// Reading direction of a run.
/// 文本段的阅读方向。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Direction {
    LeftToRight,
    RightToLeft,
}

impl Direction {
    pub fn is_rtl(self) -> bool {
        matches!(self, Direction::RightToLeft)
    }

    /// Direction implied by an embedding level: odd levels are right-to-left.
    /// 嵌入层级隐含的方向：奇数层级为从右到左。
    pub fn from_level(level: u8) -> Self {
        if level % 2 == 1 {
            Direction::RightToLeft
        } else {
            Direction::LeftToRight
        }
    }
}

/// A maximal run of text at one embedding level, in logical order.
/// 同一嵌入层级的一段最大连续文本，逻辑顺序。
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct LevelRun {
    /// Byte range into the original text.
    /// 原文本中的字节区间。
    pub range: Range<usize>,
    pub level: u8,
}

impl LevelRun {
    pub fn direction(&self) -> Direction {
        Direction::from_level(self.level)
    }

    pub fn is_rtl(&self) -> bool {
        self.direction().is_rtl()
    }
}

/// Split `text` into level runs in logical order.
/// 把 `text` 按逻辑顺序拆成层级文本段。
///
/// `base` forces the paragraph direction; `None` lets the algorithm infer it from
/// the first strong character, which is what a text editor normally wants.
/// `base` 强制段落方向；`None` 让算法从第一个强字符推断，这通常是文本编辑器想要的。
pub fn itemize(text: &str, base: Option<Direction>) -> Vec<LevelRun> {
    if text.is_empty() {
        return Vec::new();
    }
    let para_level = base.map(|d| match d {
        Direction::LeftToRight => Level::ltr(),
        Direction::RightToLeft => Level::rtl(),
    });
    let info = BidiInfo::new(text, para_level);
    runs_from_levels(text, &info.levels)
}

/// Group per-byte levels into maximal runs.
/// 把逐字节层级聚成最大连续段。
///
/// Levels are per *byte*, so a multi-byte character occupies several entries with
/// the same level; runs therefore always break on character boundaries.
/// 层级是按**字节**给的，多字节字符占多个相同层级项；因此段边界总落在字符边界上。
fn runs_from_levels(text: &str, levels: &[Level]) -> Vec<LevelRun> {
    let mut runs: Vec<LevelRun> = Vec::new();
    let mut current: Option<LevelRun> = None;

    for (offset, ch) in text.char_indices() {
        let level = levels
            .get(offset)
            .map(|l| l.number())
            .unwrap_or(0);
        let end = offset + ch.len_utf8();
        match &mut current {
            Some(run) if run.level == level => run.range.end = end,
            _ => {
                if let Some(run) = current.take() {
                    runs.push(run);
                }
                current = Some(LevelRun {
                    range: offset..end,
                    level,
                });
            }
        }
    }
    if let Some(run) = current {
        runs.push(run);
    }
    runs
}

/// Visual order of `runs`, as indices into the logical slice.
/// `runs` 的显示顺序，值为逻辑下标。
///
/// Applies UAX#9 rule L2: from the highest level down to the lowest odd level,
/// reverse every contiguous sequence of runs at or above that level.
/// 应用 UAX#9 L2：从最高层级降到最低奇数层级，反转每一段层级不低于当前值的连续文本段。
pub fn visual_order(runs: &[LevelRun]) -> Vec<usize> {
    let levels: Vec<Level> = runs
        .iter()
        .map(|r| Level::new_explicit(r.level).unwrap_or_else(|_| Level::ltr()))
        .collect();
    BidiInfo::reorder_visual(&levels)
}

/// Runs in visual order, paired with the logical index they came from.
/// 按显示顺序排列的文本段，附带其逻辑下标。
pub fn visual_runs(text: &str, base: Option<Direction>) -> Vec<(usize, LevelRun)> {
    let logical = itemize(text, base);
    visual_order(&logical)
        .into_iter()
        .filter_map(|i| logical.get(i).cloned().map(|r| (i, r)))
        .collect()
}

/// Whether `text` contains any right-to-left content.
/// `text` 是否含有从右到左的内容。
pub fn has_rtl(text: &str) -> bool {
    itemize(text, None).iter().any(|r| r.is_rtl())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pure_latin_is_a_single_ltr_run() {
        let runs = itemize("hello world", None);
        assert_eq!(runs.len(), 1);
        assert_eq!(runs[0].level, 0);
        assert!(!runs[0].is_rtl());
        assert_eq!(runs[0].range, 0..11);
    }

    #[test]
    fn pure_arabic_is_a_single_rtl_run() {
        // "مرحبا" — five Arabic letters, two bytes each.
        // "مرحبا" —— 五个阿拉伯字母，每个两字节。
        let text = "مرحبا";
        let runs = itemize(text, None);
        assert_eq!(runs.len(), 1);
        assert!(runs[0].is_rtl(), "Arabic must resolve to an RTL run");
        assert_eq!(runs[0].range, 0..text.len());
    }

    #[test]
    fn mixed_text_splits_into_alternating_runs() {
        // Latin, then Arabic, then Latin: three runs in logical order.
        // 拉丁、阿拉伯、拉丁：逻辑顺序下三段。
        let text = "abc مرحبا xyz";
        let runs = itemize(text, Some(Direction::LeftToRight));
        assert!(runs.len() >= 3, "got {runs:?}");
        assert!(!runs[0].is_rtl(), "leading Latin is LTR");
        assert!(
            runs.iter().any(|r| r.is_rtl()),
            "the Arabic middle must be RTL, got {runs:?}"
        );
        // Runs must tile the text without gaps or overlap.
        // 各段必须无缝隙、无重叠地铺满文本。
        let mut cursor = 0;
        for run in &runs {
            assert_eq!(run.range.start, cursor);
            cursor = run.range.end;
        }
        assert_eq!(cursor, text.len());
    }

    #[test]
    fn runs_never_split_a_multibyte_character() {
        let text = "a中bمc";
        let runs = itemize(text, None);
        for run in &runs {
            assert!(
                text.is_char_boundary(run.range.start) && text.is_char_boundary(run.range.end),
                "run {run:?} split a character"
            );
        }
    }

    #[test]
    fn visual_order_reverses_an_rtl_run() {
        // Base LTR, one RTL run surrounded by LTR runs: the RTL run stays in place
        // but the runs after it keep their order.
        // 基方向 LTR，中间一个 RTL 段：该段位置不变，其后的段保持顺序。
        let text = "abc مرحبا xyz";
        let logical = itemize(text, Some(Direction::LeftToRight));
        let order = visual_order(&logical);
        assert_eq!(order.len(), logical.len());
        // Every index appears exactly once.
        // 每个下标恰好出现一次。
        let mut sorted = order.clone();
        sorted.sort_unstable();
        assert_eq!(sorted, (0..logical.len()).collect::<Vec<_>>());
    }

    #[test]
    fn base_direction_changes_the_visual_run_order() {
        // Same text, two base directions: the visual sequence must differ.
        // 同一段文本，两种基方向：显示顺序必须不同。
        let text = "abc مرحبا";
        let ltr_order: Vec<usize> = visual_runs(text, Some(Direction::LeftToRight))
            .iter()
            .map(|(i, _)| *i)
            .collect();
        let rtl_order: Vec<usize> = visual_runs(text, Some(Direction::RightToLeft))
            .iter()
            .map(|(i, _)| *i)
            .collect();
        assert_ne!(
            ltr_order, rtl_order,
            "base direction must affect visual order, got {ltr_order:?} vs {rtl_order:?}"
        );
    }

    #[test]
    fn rtl_base_lifts_ltr_text_to_level_two() {
        // UAX#9 rule I2: LTR characters in an RTL paragraph rise to level 2.
        // UAX#9 规则 I2：RTL 段落中的 LTR 字符升到 level 2。
        let runs = itemize("abc", Some(Direction::RightToLeft));
        assert_eq!(runs.len(), 1);
        assert_eq!(runs[0].level, 2);
        assert!(!runs[0].is_rtl(), "level 2 is still displayed left-to-right");
    }

    #[test]
    fn empty_text_has_no_runs() {
        assert!(itemize("", None).is_empty());
        assert!(visual_runs("", None).is_empty());
        assert!(!has_rtl(""));
    }

    #[test]
    fn has_rtl_detects_arabic_and_hebrew() {
        assert!(!has_rtl("plain latin"));
        assert!(has_rtl("مرحبا"));
        assert!(has_rtl("שלום"));
        assert!(has_rtl("latin مرحبا"));
    }

    #[test]
    fn visual_runs_keeps_every_logical_index() {
        let text = "a مرحبا b שלום c";
        let logical = itemize(text, None);
        let visual = visual_runs(text, None);
        assert_eq!(visual.len(), logical.len());
        let mut seen: Vec<usize> = visual.iter().map(|(i, _)| *i).collect();
        seen.sort_unstable();
        assert_eq!(seen, (0..logical.len()).collect::<Vec<_>>());
    }

    #[test]
    fn direction_from_level_uses_parity() {
        assert_eq!(Direction::from_level(0), Direction::LeftToRight);
        assert_eq!(Direction::from_level(1), Direction::RightToLeft);
        assert_eq!(Direction::from_level(2), Direction::LeftToRight);
        assert_eq!(Direction::from_level(3), Direction::RightToLeft);
    }
}
