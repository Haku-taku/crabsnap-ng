//! Emoji presentation (UTS #51): which clusters a text face must not shape.
//! emoji 呈现（UTS #51）：哪些字簇不能交给文本字面整形。
//!
//! The decision is Parley's `parley_emoji` DFA (adapted from c-emoji, the same algorithm
//! Blink's `EmojiSegmentation` uses); only the UTS #51 property bits come from `unicode-properties`.
//! 判定用 Parley 的 `parley_emoji` 状态机（改编自 c-emoji，Blink 的 `EmojiSegmentation` 同源）；
//! 只有 UTS #51 的属性位取自 `unicode-properties`。

use parley_emoji::{EmojiDFA, EmojiPresentationStyle, EmojiSegmentationCategory};
use unicode_properties::emoji::EmojiStatus;
use unicode_properties::UnicodeEmoji;

/// Whether one cluster is displayed as emoji: an explicit sequence, or an emoji-default base.
/// 一个字簇是否按 emoji 显示：显式序列，或默认就是 emoji 的基字符。
pub fn asks_emoji(cluster: &str) -> bool {
    presentation(cluster).is_emoji()
}

/// The presentation UTS #51 gives one cluster; the selector, if any, outranks the default.
/// UTS #51 给一个字簇的呈现形式；选择符（若有）压过默认值。
pub fn presentation(cluster: &str) -> EmojiPresentationStyle {
    let mut dfa = EmojiDFA::new();
    let mut leading = false;
    for (i, c) in cluster.chars().enumerate() {
        if i == 0 {
            leading = defaults_to_emoji(c);
        }
        dfa.step_record(category(c));
    }
    dfa.presentation_style(leading)
}

/// The presentation of a whole run: `Some` when every cluster agrees, `None` when it mixes.
/// 整段的呈现形式：所有字簇一致时为 `Some`，混合时为 `None`。
///
/// A mixed run may not go to one face: an emoji face would answer for the plain clusters too,
/// and its digits are empty keycap components that draw nothing.
/// 混合的段不能交给单个字面：emoji 字面会连普通字簇一起接管，而它的数字是空白的键帽部件，什么也画不出来。
pub fn uniform_presentation(text: &str) -> Option<bool> {
    let mut seen: Option<bool> = None;
    for (_, cluster) in ui_core::grapheme::clusters(text) {
        let emoji = asks_emoji(cluster);
        match seen {
            Some(prev) if prev != emoji => return None,
            _ => seen = Some(emoji),
        }
    }
    seen
}

/// One code point as the DFA's input, with its UTS #51 properties.
/// 一个码点作为状态机的输入，附带它的 UTS #51 属性。
fn category(c: char) -> EmojiSegmentationCategory {
    let status = c.emoji_status();
    EmojiSegmentationCategory::from_codepoint(
        c as u32,
        !matches!(status, EmojiStatus::NonEmoji | EmojiStatus::NonEmojiButEmojiComponent),
        defaults_to_emoji(c),
        matches!(
            status,
            EmojiStatus::EmojiPresentationAndModifierAndEmojiComponent
        ),
        matches!(
            status,
            EmojiStatus::EmojiModifierBase
                | EmojiStatus::EmojiPresentationAndModifierBase
                | EmojiStatus::EmojiPresentationAndModifierAndEmojiComponent
        ),
        matches!(c, '\u{1f1e6}'..='\u{1f1ff}'),
    )
}

/// UTS #51 `Emoji_Presentation=Yes`: the character shows as emoji without a selector.
/// UTS #51 的 `Emoji_Presentation=Yes`：不带选择符也按 emoji 显示的字符。
fn defaults_to_emoji(c: char) -> bool {
    matches!(
        c.emoji_status(),
        EmojiStatus::EmojiPresentation
            | EmojiStatus::EmojiPresentationAndModifierBase
            | EmojiStatus::EmojiPresentationAndEmojiComponent
            | EmojiStatus::EmojiPresentationAndModifierAndEmojiComponent
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn only_clusters_with_an_emoji_presentation_ask_for_emoji() {
        // A bare digit or an emoji-capable character without VS16 stays text; a sequence with
        // no text form, and an emoji-default base, ask for emoji.
        // 裸数字、没有 VS16 的 emoji 字符保持文本；没有文本形式的序列与默认 emoji 的基字符请求 emoji。
        assert!(!asks_emoji("3"));
        assert!(!asks_emoji("\u{2764}"), "❤ is Emoji=Yes but Emoji_Presentation=No");
        assert!(!asks_emoji("\u{2764}\u{fe0e}"), "VS15 forces text");
        assert!(asks_emoji("\u{1f1e8}"), "a lone regional indicator is Emoji_Presentation=Yes");
        assert!(asks_emoji("\u{1f600}"), "😀 is Emoji_Presentation=Yes");
        assert!(asks_emoji("\u{2764}\u{fe0f}"), "VS16");
        assert!(asks_emoji("3\u{fe0f}\u{20e3}"), "keycap");
        assert!(asks_emoji("\u{1f468}\u{200d}\u{1f469}"), "ZWJ");
        assert!(asks_emoji("\u{1f1e8}\u{1f1f3}"), "flag");
        assert!(asks_emoji("\u{1f44d}\u{1f3fd}"), "skin tone");
        assert!(asks_emoji("\u{1f3f4}\u{e0067}\u{e0062}\u{e007f}"), "tag sequence");
    }

    #[test]
    fn a_run_mixes_when_an_emoji_sits_beside_plain_text() {
        // The digit after a keycap is plain text, so the run may not go to one face.
        // 键帽之后的数字是普通文本，因此整段不能交给单个字面。
        assert_eq!(uniform_presentation("abc"), Some(false));
        assert_eq!(uniform_presentation("\u{1f600}\u{1f600}"), Some(true));
        assert_eq!(uniform_presentation("3\u{fe0f}\u{20e3}4"), None);
        assert_eq!(uniform_presentation("\u{1f600} abc"), None);
        assert_eq!(uniform_presentation(""), None, "nothing to agree on");
    }
}
