//! The five key colours of the default (TonalSpot) scheme and the palettes derived from them.
//! 默认（TonalSpot）方案的五条 key colour，以及由它们派生的调色板。

use ui_color_hct::{cam_from_argb, Cam, TonalPalette};

/// Which tonal palette a role reads from.
/// 角色读取哪条色调调色板。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum PaletteId {
    Primary,
    Secondary,
    Tertiary,
    Neutral,
    NeutralVariant,
    Error,
}

impl PaletteId {
    pub const ALL: [Self; 6] = [
        Self::Primary,
        Self::Secondary,
        Self::Tertiary,
        Self::Neutral,
        Self::NeutralVariant,
        Self::Error,
    ];

    pub const fn name(self) -> &'static str {
        match self {
            Self::Primary => "primary",
            Self::Secondary => "secondary",
            Self::Tertiary => "tertiary",
            Self::Neutral => "neutral",
            Self::NeutralVariant => "neutral_variant",
            Self::Error => "error",
        }
    }
}

/// TonalSpot's key-colour rule: source hue, per-palette chroma, tertiary hue + 60.
/// TonalSpot 的 key colour 规则：沿用来源色相、各调色板固定彩度、tertiary 色相 +60。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TonalSpot {
    pub source_hue: f64,
    pub source_chroma: f64,
    pub source_tone: f64,
}

impl TonalSpot {
    /// The palettes for a source colour.
    /// 由来源色得到各调色板。
    pub fn palettes(&self) -> Palettes {
        let h = self.source_hue;
        Palettes {
            primary: TonalPalette::new(h, 36.0),
            secondary: TonalPalette::new(h, 16.0),
            tertiary: TonalPalette::new((h + 60.0) % 360.0, 24.0),
            neutral: TonalPalette::new(h, 6.0),
            neutral_variant: TonalPalette::new(h, 8.0),
            // The error palette ignores the source: hue 25, chroma 84.
            // error 调色板不取来源色：固定色相 25、彩度 84。
            error: TonalPalette::new(25.0, 84.0),
        }
    }
}

/// One tonal palette per key colour.
/// 每条 key colour 一条色调调色板。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Palettes {
    pub primary: TonalPalette,
    pub secondary: TonalPalette,
    pub tertiary: TonalPalette,
    pub neutral: TonalPalette,
    pub neutral_variant: TonalPalette,
    pub error: TonalPalette,
}

impl Palettes {
    pub fn get(&self, id: PaletteId) -> TonalPalette {
        match id {
            PaletteId::Primary => self.primary,
            PaletteId::Secondary => self.secondary,
            PaletteId::Tertiary => self.tertiary,
            PaletteId::Neutral => self.neutral,
            PaletteId::NeutralVariant => self.neutral_variant,
            PaletteId::Error => self.error,
        }
    }

    /// The colour at `tone` in the named palette.
    /// 指定调色板在 `tone` 处的颜色。
    pub fn tone(&self, id: PaletteId, tone: f64) -> u32 {
        self.get(id).tone(tone)
    }
}

/// Everything a scheme needs from its source colour.
/// 方案需要的来源色信息。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct SourceColor {
    pub hue: f64,
    pub chroma: f64,
    pub tone: f64,
}

impl SourceColor {
    /// Read hue, chroma and tone straight off an sRGB colour.
    /// 直接从 sRGB 颜色读出 hue、chroma 与 tone。
    pub fn from_argb(argb: u32) -> Self {
        let Cam { hue, chroma, .. } = cam_from_argb(argb);
        Self { hue, chroma, tone: ui_color_hct::tone_of(argb) }
    }

    pub fn tonal_spot(&self) -> TonalSpot {
        TonalSpot { source_hue: self.hue, source_chroma: self.chroma, source_tone: self.tone }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ui_color_hct::tone_of;

    // TonalSpot's numbers are the spec table; the derived hue/chroma must match it exactly.
    // TonalSpot 的数值来自规范表；派生的色相与彩度必须与之完全一致。
    #[test]
    fn tonal_spot_uses_the_documented_hue_and_chroma_per_palette() {
        let palettes = TonalSpot { source_hue: 40.0, source_chroma: 50.0, source_tone: 40.0 }.palettes();
        assert_eq!(palettes.primary.chroma, 36.0);
        assert_eq!(palettes.secondary.chroma, 16.0);
        assert_eq!(palettes.tertiary.chroma, 24.0);
        assert_eq!(palettes.neutral.chroma, 6.0);
        assert_eq!(palettes.neutral_variant.chroma, 8.0);
        assert!((palettes.tertiary.hue - 100.0).abs() < 1e-9, "tertiary hue {}", palettes.tertiary.hue);
        assert!((palettes.primary.hue - 40.0).abs() < 1e-9);
    }

    #[test]
    fn the_error_palette_ignores_the_source_colour() {
        let palettes = TonalSpot { source_hue: 200.0, source_chroma: 10.0, source_tone: 50.0 }.palettes();
        assert_eq!(palettes.error.hue, 25.0);
        assert_eq!(palettes.error.chroma, 84.0);
    }

    #[test]
    fn tersiary_hue_wraps_past_three_sixty() {
        let palettes = TonalSpot { source_hue: 340.0, source_chroma: 20.0, source_tone: 50.0 }.palettes();
        assert!((palettes.tertiary.hue - 40.0).abs() < 1e-9, "wrapped to {}", palettes.tertiary.hue);
    }

    #[test]
    fn a_palette_hits_the_tone_it_is_asked_for() {
        let palettes = SourceColor::from_argb(0xff67_50a4).tonal_spot().palettes();
        for tone in [10.0, 40.0, 90.0] {
            assert!((tone_of(palettes.tone(PaletteId::Primary, tone)) - tone).abs() < 0.8);
        }
    }

    #[test]
    fn source_colour_reads_its_own_hue_back() {
        let source = SourceColor::from_argb(0xff67_50a4);
        assert!((source.tone - 40.0).abs() < 0.6, "tone {}", source.tone);
        assert!((source.hue - 299.0).abs() < 1.0, "hue {}", source.hue);
    }
}
