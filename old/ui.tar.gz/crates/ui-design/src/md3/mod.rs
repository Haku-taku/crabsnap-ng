//! MD3 as a design system: 49 roles resolved by rule, not looked up in a table.
//! MD3 作为一套设计体系：49 个角色由规则解析，而非查表。

use crate::capabilities::{Geometry, Palette};
use crate::caps::StyleCaps;
use crate::common::CommonColor;
use crate::context::Context;
use crate::metric::CommonMetric;
use crate::source::Source;
use crate::system::{SystemId, StyleSystem};
use crate::value::{Reason, Resolution, Resolved, Rgba};

pub mod palette;
mod tone;

use palette::{PaletteId, Palettes, SourceColor};
use tone::{foreground_tone, Curve, DeltaPair};

/// A role's tone as the source declares it: a rule, never a constant.
/// 角色的 tone 按源声明：总是规则，从不是常量。
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum ToneRule {
    /// `s.is_dark ? dark : light`
    Pair { light: f64, dark: f64 },
    Const(f64),
    /// Dark is a constant; light follows a contrast curve.
    LightCurve { dark: f64, curve: Curve },
    /// Light is a constant; dark follows a contrast curve.
    DarkCurve { light: f64, curve: Curve },
    BothCurve { light: Curve, dark: Curve },
}

impl ToneRule {
    fn raw(&self, is_dark: bool, level: f64) -> f64 {
        match *self {
            Self::Pair { light, dark } => {
                if is_dark {
                    dark
                } else {
                    light
                }
            }
            Self::Const(v) => v,
            Self::LightCurve { dark, curve } => {
                if is_dark {
                    dark
                } else {
                    curve.get(level)
                }
            }
            Self::DarkCurve { light, curve } => {
                if is_dark {
                    curve.get(level)
                } else {
                    light
                }
            }
            Self::BothCurve { light, dark } => {
                if is_dark {
                    dark.get(level)
                } else {
                    light.get(level)
                }
            }
        }
    }
}

/// Which surface the `highestSurface` pseudo-role means in this theme.
/// 该主题下 `highestSurface` 这个伪角色指的是哪个表面。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Background {
    HighestSurface,
    Background,
    Primary,
    Secondary,
    Tertiary,
    Error,
    PrimaryContainer,
    SecondaryContainer,
    TertiaryContainer,
    ErrorContainer,
    InverseSurface,
    PrimaryFixed,
    SecondaryFixed,
    TertiaryFixed,
    PrimaryFixedDim,
    SecondaryFixedDim,
    TertiaryFixedDim,
}

/// One of the 49 colour roles.
/// 49 个颜色角色之一。
#[derive(Clone, Copy, Debug)]
pub struct Role {
    pub name: &'static str,
    pub palette: PaletteId,
    pub tone: ToneRule,
    pub is_background: bool,
    pub background: Option<Background>,
    pub second_background: Option<Background>,
    pub curve: Option<[f64; 4]>,
    pub delta: Option<DeltaPair>,
}

mod data {
    include!("../../data/md3_data.rs");
}

impl Role {
    /// The declared 49 roles, by name; the table is generated from the source.
    /// 声明式的 49 个角色，按名查找；表由源生成。
    pub fn all() -> &'static [Role] {
        data::ROLES
    }

    pub fn by_name(name: &str) -> Option<&'static Role> {
        data::ROLES.iter().find(|r| r.name == name)
    }
}

/// An MD3 scheme: five palettes plus the context it resolves under.
/// MD3 方案：五条调色板，加上解析所依据的上下文。
#[derive(Clone, Copy, Debug)]
pub struct Md3Scheme {
    pub ctx: Context,
    pub palettes: Palettes,
    pub source_tone: f64,
}

impl Md3Scheme {
    /// Build a scheme from a seed colour, the way a real app would.
    /// 由种子色建立方案，与真实应用一致。
    pub fn from_source(ctx: Context, seed: u32) -> Self {
        let source = SourceColor::from_argb(seed);
        Self { ctx, palettes: source.tonal_spot().palettes(), source_tone: source.tone }
    }

    /// A TonalSpot scheme whose seed is the default M3 baseline purple.
    /// 以 M3 默认 baseline 紫为种子的 TonalSpot 方案。
    pub fn baseline(ctx: Context) -> Self {
        Self::from_source(ctx, 0xff67_50a4)
    }

    fn level(&self) -> f64 {
        self.ctx.contrast.md3_level()
    }

    fn is_dark(&self) -> bool {
        self.ctx.is_dark()
    }

    /// The tone a role actually resolves to, after curves and delta pairs.
    /// 角色最终解析出的 tone，已应用对比曲线与配对约束。
    pub fn tone_of(&self, role: &Role) -> f64 {
        let level = self.level();
        let is_dark = self.is_dark();
        let mut answer = role.tone.raw(is_dark, level);

        // Case 1: a delta pair fixes both members together; the nearer member keeps the rule.
        // 情形一：配对把两个成员一起约束；nearer 一方沿用规则值。
        if let Some(pair) = role.delta {
            let other_name = if pair.a == role.name { pair.b } else { pair.a };
            if let Some(other) = Role::by_name(other_name) {
                let other_tone = other.tone.raw(is_dark, level);
                // `stay_together` means both sides keep the rule, as fixed roles do.
                // `stay_together` 表示两侧都保持规则值，fixed 角色即如此。
                if pair.stay_together {
                    return answer;
                }
                let (near, far) =
                    tone::resolve_delta_pair(role.name, answer, other_tone, &pair, is_dark);
                answer = if pair.a == role.name { near } else { far };
            }
            return answer;
        }

        // Case 2: a single background with a curve. A pair member keeps its delta instead.
        // 情形二：单一背景加对比曲线；配对成员则保持配对距离，不参与这里。
        if role.delta.is_none()
            && let (Some(raw), Some(bg)) = (role.curve, role.background) {
                let bg_tone = self.background_tone(bg);
                let want = if level < 0.0 { raw[0] } else { Curve(raw).get(level) };
                if !ratio_of_tones_ge(answer, bg_tone, want) {
                    answer = foreground_tone(bg_tone, want);
                }
                if role.is_background && (50.0..60.0).contains(&answer) {
                    answer = if ratio_of_tones_ge(49.0, bg_tone, want) { 49.0 } else { 60.0 };
                }
            }
        answer
    }

    fn background_tone(&self, bg: Background) -> f64 {
        match bg {
            // In dark themes the highest surface is the bright one, else the dim one.
            // 暗色下最高表面是 bright，明色下是 dim。
            Background::HighestSurface => {
                let name = if self.is_dark() { "surface_bright" } else { "surface_dim" };
                Role::by_name(name).map(|r| self.tone_of(r)).unwrap_or(0.0)
            }
            other => {
                let name = background_name(other);
                Role::by_name(name).map(|r| self.tone_of(r)).unwrap_or(0.0)
            }
        }
    }

    /// The colour of a role.
    /// 角色的颜色。
    pub fn color(&self, role: &Role) -> Rgba {
        Rgba::from_argb(self.palettes.tone(role.palette, self.tone_of(role)))
    }

    /// Read a native role exactly as M3's own token chain does:
    /// `md.sys.color.<role>` -> `md.ref.palette.<palette>` at a tone -> an sRGB value.
    /// Here that is: role name -> tone rule (evaluated) -> tonal palette -> hex, printed in
    /// the same three steps so a spec table row can be followed end to end.
    /// 按 M3 自身的令牌链读一个原生角色：`md.sys.color.<role>` -> 该调色板某个 tone 的
    /// `md.ref.palette.<palette>` -> sRGB 值。这里同样分三步打印：角色名 -> 求值后的 tone
    /// 规则 -> 调色板 -> hex，让人能从规范表的一行一路追到颜色。
    pub fn explain(&self, name: &str) -> Option<String> {
        let role = Role::by_name(name)?;
        let tone = self.tone_of(role);
        let argb = self.color(role);
        let hex = format!("#{:06X}", argb.argb() & 0x00ff_ffff);
        Some(format!(
            "md.sys.color.{name} -> md.ref.palette.{} at tone {tone:.2} (rule {:?}) -> {hex}",
            role.palette.name(),
            role.tone,
        ))
    }
}

fn ratio_of_tones_ge(a: f64, b: f64, want: f64) -> bool {
    ui_color_hct::ratio_of_tones(a, b) >= want
}

fn background_name(bg: Background) -> &'static str {
    match bg {
        Background::HighestSurface => "surface_bright",
        Background::Background => "background",
        Background::Primary => "primary",
        Background::Secondary => "secondary",
        Background::Tertiary => "tertiary",
        Background::Error => "error",
        Background::PrimaryContainer => "primary_container",
        Background::SecondaryContainer => "secondary_container",
        Background::TertiaryContainer => "tertiary_container",
        Background::ErrorContainer => "error_container",
        Background::InverseSurface => "inverse_surface",
        Background::PrimaryFixed => "primary_fixed",
        Background::SecondaryFixed => "secondary_fixed",
        Background::TertiaryFixed => "tertiary_fixed",
        Background::PrimaryFixedDim => "primary_fixed_dim",
        Background::SecondaryFixedDim => "secondary_fixed_dim",
        Background::TertiaryFixedDim => "tertiary_fixed_dim",
    }
}

/// The published table every `common_colour` answer comes from.
/// 每个 `common_colour` 答案所依据的公开表。
const ROLE_SPEC: &str = "m3 color roles";

/// Which MD3 role answers each common semantic colour.
/// 每个公共语义颜色由哪个 MD3 角色回答。
const ADAPTER: &[(CommonColor, &str)] = &[
    (CommonColor::Accent, "primary"),
    (CommonColor::OnAccent, "on_primary"),
    (CommonColor::AccentContainer, "primary_container"),
    (CommonColor::OnAccentContainer, "on_primary_container"),
    (CommonColor::Surface, "surface"),
    (CommonColor::OnSurface, "on_surface"),
    (CommonColor::SurfaceRaised, "surface_container_high"),
    (CommonColor::OnSurfaceRaised, "on_surface"),
    (CommonColor::TextMuted, "on_surface_variant"),
    (CommonColor::TextPlaceholder, "outline"),
    (CommonColor::TextLink, "primary"),
    (CommonColor::TextSelection, "primary"),
    (CommonColor::Divider, "outline_variant"),
    (CommonColor::Stroke, "outline"),
    (CommonColor::SurfaceHover, "surface_container_high"),
    (CommonColor::SurfacePressed, "surface_container_highest"),
    (CommonColor::SurfaceSelected, "secondary_container"),
    (CommonColor::Error, "error"),
    (CommonColor::OnError, "on_error"),
    (CommonColor::Success, "tertiary"),
    (CommonColor::Warning, "tertiary_container"),
    (CommonColor::FocusRing, "primary"),
    (CommonColor::Scrim, "scrim"),
];

impl StyleSystem for Md3Scheme {
    fn id(&self) -> SystemId {
        SystemId::Md3
    }

    fn context(&self) -> Context {
        self.ctx
    }

    fn common_colour(&self, role: CommonColor) -> Resolution<Resolved<Rgba>> {
        let Some((_, name)) = ADAPTER.iter().find(|(r, _)| *r == role) else {
            return Resolution::Absent(Reason::NotAConcept);
        };
        let Some(native) = Role::by_name(name) else {
            return Resolution::Unmapped;
        };
        let colour = self.color(native);
        // MD3 has no selection token; Flutter's MaterialApp default is the primary at 40%.
        // MD3 没有选区令牌；Flutter MaterialApp 的默认值是 primary 的 40%。
        if role == CommonColor::TextSelection {
            return Resolution::Value(Resolved::new(
                colour.with_alpha(0x66),
                Source::Spec("flutter TextSelectionThemeData: primary @ 40%"),
            ));
        }
        Resolution::Value(Resolved::new(colour, Source::Spec(ROLE_SPEC)))
    }

    fn common_metric(&self, metric: CommonMetric) -> Resolution<Resolved<f32>> {
        let scale = self.radius();
        match metric {
            CommonMetric::Radius => match scale.points("medium") {
                Some(points) => Resolution::Value(Resolved::new(points, scale.source)),
                None => Resolution::Unmapped,
            },
            CommonMetric::StrokeWidth => {
                Resolution::Value(Resolved::new(1.0, Source::Spec("m3 outline width")))
            }
        }
    }

    fn caps(&self) -> StyleCaps {
        StyleCaps {
            tonal_palettes: true,
            arbitrary_tones: true,
            containers: true,
            radius_scale: true,
            cut_corners: true,
            motion_tokens: true,
            ..StyleCaps::MINIMAL
        }
    }
}

impl Palette for Md3Scheme {
    fn native_colour(&self, id: &str) -> Resolution<Rgba> {
        match Role::by_name(id) {
            Some(role) => Resolution::Value(self.color(role)),
            None => Resolution::Unmapped,
        }
    }

    fn provenance(&self, _id: &str) -> Source {
        Source::Derived("material_dynamic_colors.cc + CAM16/HCT")
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::context::{Appearance, Contrast, Platform};
    use std::collections::HashSet;

    fn scheme(appearance: Appearance) -> Md3Scheme {
        Md3Scheme::baseline(Context::new(appearance, Platform::Android))
    }

    fn tone(s: &Md3Scheme, role: &str) -> f64 {
        s.tone_of(Role::by_name(role).unwrap())
    }

    // The documented defaults: primary 40, onPrimary 100, light surface 98, dark surface 6.
    // 文档默认值：primary 40、onPrimary 100、浅色 surface 98、深色 surface 6。
    #[test]
    fn the_documented_default_tones_reproduce() {
        let light = scheme(Appearance::Light);
        assert!((tone(&light, "primary") - 40.0).abs() < 0.01, "{}", tone(&light, "primary"));
        assert!((tone(&light, "on_primary") - 100.0).abs() < 0.01);
        assert!((tone(&light, "surface") - 98.0).abs() < 0.01);
        let dark = scheme(Appearance::Dark);
        assert!((tone(&dark, "primary") - 80.0).abs() < 0.01);
        assert!((tone(&dark, "on_primary") - 20.0).abs() < 0.01);
        assert!((tone(&dark, "surface") - 6.0).abs() < 0.01);
    }

    // TonalSpot's derived neutral palette must actually carry chroma 6, per the spec update.
    // TonalSpot 派生的 neutral 调色板彩度必须是规范更新后的 6。
    #[test]
    fn the_neutral_palette_uses_chroma_six() {
        assert_eq!(scheme(Appearance::Light).palettes.neutral.chroma, 6.0);
        assert_eq!(scheme(Appearance::Light).palettes.neutral_variant.chroma, 8.0);
    }

    // Tone law: every text-on-surface pair reaches 4.5:1 at standard contrast.
    // tone 定律：标准对比下每对前景/背景都达到 4.5:1。
    #[test]
    fn foregrounds_clear_four_and_a_half_to_one_against_their_surfaces() {
        for appearance in [Appearance::Light, Appearance::Dark] {
            let s = scheme(appearance);
            for (fg, bg) in [
                ("on_surface", "surface"),
                ("on_primary", "primary"),
                ("on_error", "error"),
                ("on_primary_container", "primary_container"),
            ] {
                let ratio = ui_color_hct::ratio_of_tones(tone(&s, fg), tone(&s, bg));
                assert!(ratio >= 4.5, "{appearance:?} {fg}/{bg} = {ratio:.2}");
            }
        }
    }

    // Higher contrast must never lower the tone gap of a pair.
    // 提高对比档不得降低任何一对的 tone 间距。
    #[test]
    fn raising_contrast_never_shrinks_a_tone_gap() {
        for appearance in [Appearance::Light, Appearance::Dark] {
            let base = scheme(appearance);
            let high = Md3Scheme::baseline(
                Context::new(appearance, Platform::Android).with_contrast(Contrast::High),
            );
            for (fg, bg) in [("on_surface", "surface"), ("on_primary", "primary")] {
                let gap_at = |s: &Md3Scheme| (tone(s, fg) - tone(s, bg)).abs();
                assert!(
                    gap_at(&high) >= gap_at(&base) - 0.01,
                    "{appearance:?} {fg}/{bg}: {} < {}",
                    gap_at(&high),
                    gap_at(&base)
                );
            }
        }
    }

    // A role in a delta pair must keep its declared distance from its partner.
    // 配对角色必须与伙伴保持声明的间距。
    #[test]
    fn delta_pairs_keep_their_ten_tone_distance() {
        for appearance in [Appearance::Light, Appearance::Dark] {
            let s = scheme(appearance);
            for (a, b) in [("primary", "primary_container"), ("error", "error_container")] {
                let gap = (tone(&s, a) - tone(&s, b)).abs();
                assert!(gap >= 10.0 - 0.01, "{appearance:?} {a}/{b} gap {gap}");
            }
        }
    }

    // Fixed roles must not move between light and dark.
    // fixed 角色在明暗之间不得移动。
    #[test]
    fn fixed_roles_are_identical_in_both_appearances() {
        let light = scheme(Appearance::Light);
        let dark = scheme(Appearance::Dark);
        for role in ["primary_fixed", "primary_fixed_dim", "on_primary_fixed", "tertiary_fixed"] {
            assert!(
                (tone(&light, role) - tone(&dark, role)).abs() < 0.01,
                "{role}: {} vs {}",
                tone(&light, role),
                tone(&dark, role)
            );
        }
    }

    // Fidelity schemes make primary_container equal the source tone; TonalSpot keeps 90.
    // fidelity 方案让 primary_container 等于来源 tone；TonalSpot 保持 90。
    #[test]
    fn tonal_spot_keeps_the_container_at_ninety_not_the_source_tone() {
        let s = scheme(Appearance::Light);
        assert!((tone(&s, "primary_container") - 90.0).abs() < 0.01);
        assert!((s.source_tone - 40.083).abs() < 0.5, "source tone {}", s.source_tone);
    }

    // A custom seed must move the palettes, not just the schema.
    // 自定义种子必须真正改变调色板，而不只是改个字段。
    #[test]
    fn a_custom_seed_changes_the_resolved_accent() {
        let seed = 0xff00_6e44; // a saturated green
        let scheme = Md3Scheme::from_source(Context::new(Appearance::Light, Platform::Android), seed);
        let baseline = Md3Scheme::baseline(Context::new(Appearance::Light, Platform::Android));
        assert_ne!(scheme.color(Role::by_name("primary").unwrap()).argb(),
                   baseline.color(Role::by_name("primary").unwrap()).argb());
        assert!((tone(&scheme, "primary") - 40.0).abs() < 0.8, "tone {}", tone(&scheme, "primary"));
    }

    #[test]
    fn every_role_resolves_to_a_tone_in_range() {
        for appearance in [Appearance::Light, Appearance::Dark] {
            let s = scheme(appearance);
            for role in Role::all() {
                let t = s.tone_of(role);
                assert!((0.0..=100.0).contains(&t), "{} -> {t}", role.name);
            }
        }
    }

    #[test]
    fn the_forty_nine_roles_are_present_and_unique() {
        let names: HashSet<_> = Role::all().iter().map(|r| r.name).collect();
        assert_eq!(Role::all().len(), 49);
        assert_eq!(names.len(), 49);
        for expected in ["primary", "on_primary", "surface", "on_surface", "scrim", "outline_variant"] {
            assert!(names.contains(expected), "{expected} missing");
        }
    }

    // The adapter must cover the common list, and every target must be a real role.
    // 适配表必须覆盖公共清单，且每个目标都是真实角色。
    #[test]
    fn the_adapter_covers_every_common_role_and_points_at_real_roles() {
        let covered: HashSet<_> = ADAPTER.iter().map(|(r, _)| *r).collect();
        for role in CommonColor::ALL {
            assert!(covered.contains(&role), "{} not adapted", role.name());
        }
        assert_eq!(ADAPTER.len(), CommonColor::ALL.len());
        for (common, target) in ADAPTER {
            assert!(Role::by_name(target).is_some(), "{} -> missing {target}", common.name());
        }
    }

    #[test]
    fn the_common_path_returns_colours_and_the_native_path_reaches_every_role() {
        let s = scheme(Appearance::Light);
        for (common, _) in ADAPTER {
            assert!(s.common_colour(*common).value().is_some(), "{} empty", common.name());
        }
        for role in Role::all() {
            assert!(s.native_colour(role.name).value().is_some(), "{} unreachable", role.name);
        }
        assert_eq!(s.native_colour("no_such_role"), Resolution::Unmapped);
    }
}
