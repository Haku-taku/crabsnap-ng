//! The corner vocabulary, re-exported so design code names shapes without reaching for the
//! renderer crate. The engine owns the definition; this module is the design-side door.
//! 圆角词汇。重导出以便设计层不必伸手到渲染 crate；定义归引擎，本模块是设计侧的入口。

pub use ui_core::geom::CornerShape;
