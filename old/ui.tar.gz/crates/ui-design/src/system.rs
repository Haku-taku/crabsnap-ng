//! The trait a design system implements, plus the registry that holds one instance per system.
//! 设计体系实现的 trait，以及每个体系一个实例的注册表。

use crate::caps::StyleCaps;
use crate::common::CommonColor;
use crate::context::Context;
use crate::metric::CommonMetric;
use crate::value::{Resolution, Resolved, Rgba};

/// Which design system a value came from.
/// 值来自哪套设计体系。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum SystemId {
    Md3,
    Fluent,
    Hig,
}

impl SystemId {
    pub const fn name(self) -> &'static str {
        match self {
            Self::Md3 => "MD3",
            Self::Fluent => "Fluent 2",
            Self::Hig => "HIG",
        }
    }
}

/// A named token in a system's own vocabulary, e.g. `("md3", "primaryContainer")`.
/// 体系自身词汇里的具名令牌，例如 `("md3", "primaryContainer")`。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct NativeName {
    pub system: SystemId,
    pub name: &'static str,
}

impl NativeName {
    pub const fn new(system: SystemId, name: &'static str) -> Self {
        Self { system, name }
    }
}

/// A complete design system: identity, context, capabilities, plus the four responsibilities.
/// 一套完整设计体系：身份、上下文、能力，外加四项职责。
pub trait StyleSystem:
    crate::capabilities::Palette
    + crate::capabilities::WithDimensions
    + crate::capabilities::Geometry
    + crate::capabilities::Typography
    + crate::capabilities::Motion
    + Send
    + Sync
{
    /// Which system this is.
    /// 这是哪套体系。
    fn id(&self) -> SystemId;

    /// The context this instance was built for.
    /// 本实例所依据的上下文。
    fn context(&self) -> Context;

    /// The shared-colour query, answered by this system's own rules. It lives here, not on
    /// `Palette`: a widget asks for a native token id; translating a shared role is the
    /// semantic variant's job.
    /// 共享颜色查询，由本体系自身规则回答。它在这里而非 `Palette` 上：控件问的是原生令牌 id，
    /// 翻译共享角色是语义化变体的职责。
    fn common_colour(&self, role: CommonColor) -> Resolution<Resolved<Rgba>>;

    /// The shared-metric query; same contract as `common_colour`, in points.
    /// 共享度量查询；契约同 `common_colour`，单位为点。
    fn common_metric(&self, metric: CommonMetric) -> Resolution<Resolved<f32>>;

    /// What this system can do beyond the common layer.
    /// 本体系在公共层之外的能力。
    fn caps(&self) -> StyleCaps;
}

/// A system together with the context it was resolved for.
/// 体系与其解析所依据的上下文。
pub struct Theme {
    pub system: Box<dyn StyleSystem>,
}

impl Theme {
    pub fn new(system: impl StyleSystem + 'static) -> Self {
        Self { system: Box::new(system) }
    }

    /// The common colour path with the usual loud failure.
    /// 公共颜色路径，失败即显式记录。
    pub fn common_colour(&self, role: CommonColor) -> Resolution<Resolved<Rgba>> {
        self.system.common_colour(role)
    }

    /// The common metric path.
    /// 公共度量路径。
    pub fn common_metric(&self, metric: CommonMetric) -> Resolution<Resolved<f32>> {
        self.system.common_metric(metric)
    }

    /// The style's own vocabulary, for anything the common list does not cover.
    /// 本体系自己的词汇，用于公共清单未覆盖的部分。
    pub fn native_colour(&self, name: &str) -> Resolution<Rgba> {
        self.system.native_colour(name)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::context::{Appearance, Platform};
    use crate::capabilities::{Geometry, Motion, Palette, Typography, WithDimensions};
    use crate::value::Reason;

    struct Stub;

    impl StyleSystem for Stub {
        fn id(&self) -> SystemId {
            SystemId::Hig
        }
        fn context(&self) -> Context {
            Context::new(Appearance::Light, Platform::Ios)
        }
        fn common_colour(&self, role: CommonColor) -> Resolution<Resolved<Rgba>> {
            match role {
                CommonColor::Accent => Resolution::Absent(Reason::PlatformResolved("tintColor")),
                _ => Resolution::Unmapped,
            }
        }
        fn common_metric(&self, _metric: CommonMetric) -> Resolution<Resolved<f32>> {
            Resolution::Unmapped
        }
        fn caps(&self) -> StyleCaps {
            StyleCaps::MINIMAL
        }
    }

    impl Palette for Stub {
        fn native_colour(&self, name: &str) -> Resolution<Rgba> {
            if name == "systemBlue" {
                Resolution::Value(Rgba::from_rgb(0x00, 0x88, 0xff))
            } else {
                Resolution::Unmapped
            }
        }

        fn provenance(&self, _name: &str) -> crate::source::Source {
            crate::source::Source::Spec("hig system colors")
        }
    }

    impl WithDimensions for Stub {
        fn dimensions(&self) -> crate::dimension::DimensionTokens {
            crate::scales::dimensions_of(SystemId::Hig, self.context())
        }
    }

    impl Geometry for Stub {}
    impl Typography for Stub {}
    impl Motion for Stub {}

    #[test]
    fn the_native_path_still_reaches_tokens_beyond_the_common_list() {
        let theme = Theme::new(Stub);
        assert_eq!(theme.native_colour("systemBlue").value().map(Rgba::argb), Some(0xff00_88ff));
    }

    #[test]
    fn an_unknown_native_name_is_unmapped_rather_than_a_made_up_colour() {
        let theme = Theme::new(Stub);
        assert_eq!(theme.native_colour("nope"), Resolution::Unmapped);
    }

    #[test]
    fn style_ids_have_display_names() {
        assert_eq!(SystemId::Md3.name(), "MD3");
        assert_eq!(SystemId::Fluent.name(), "Fluent 2");
    }
}
