//! Fluent 2 as a design system: 459 tokens as data, plus the common-role adapter.
//! Fluent 2 作为一套设计体系：459 个令牌为数据，外加公共角色适配表。

use crate::capabilities::{Geometry, Palette};
use crate::caps::StyleCaps;
use crate::common::CommonColor;
use crate::context::{Context, Contrast};
use crate::metric::CommonMetric;
use crate::source::Source;
use crate::system::{SystemId, StyleSystem};
use crate::value::{Reason, Resolution, Resolved, Rgba};

mod data {
    include!("../data/fluent_data.rs");
}

/// The package every value in this file traces back to.
/// 本文件所有值的出处。
const TOKEN_SPEC: Source = Source::Spec("@fluentui/tokens 1.0.0-alpha.24 (MIT)");

/// The three theme columns Fluent ships, in the order the data table uses.
/// Fluent 自带的三个主题列，顺序与数据表一致。
fn theme_column(ctx: &Context) -> usize {
    match (ctx.contrast, ctx.appearance) {
        (Contrast::High, _) => 2,
        (_, crate::context::Appearance::Light) => 0,
        (_, crate::context::Appearance::Dark) => 1,
    }
}

/// Every Fluent token, unpruned; a lookup by the token's own name.
/// 全部 Fluent 令牌，未裁剪；按令牌自身名字查询。
#[derive(Clone, Copy, Debug)]
pub struct FluentSystem {
    pub ctx: Context,
}

impl FluentSystem {
    pub const fn new(ctx: Context) -> Self {
        Self { ctx }
    }

    fn column(&self) -> usize {
        theme_column(&self.ctx)
    }

    /// The colour under this token name, if the token is a flat colour.
    /// 该令牌名下的颜色，前提是它确实是纯色。
    fn color(&self, name: &str) -> Option<Rgba> {
        data::COLORS
            .iter()
            .chain(data::ALPHA_COLORS.iter())
            .find(|(n, _)| *n == name)
            .map(|(_, v)| Rgba::from_argb(v[self.column()]))
    }

    /// The brand ramp colour at the given tone (10..=160), if the ramp has one.
    /// 品牌色阶在指定 tone（10..=160）的颜色，若存在。
    pub fn brand_tone(tone: u16) -> Option<Rgba> {
        data::BRAND_RAMP
            .iter()
            .find(|(t, _)| *t == tone)
            .map(|(_, c)| Rgba::from_argb(*c))
    }

    /// How many tokens exist at all, for coverage accounting.
    /// 令牌总数，供覆盖率核算。
    pub fn token_count() -> usize {
        data::COLORS.len()
            + data::ALPHA_COLORS.len()
            + data::NUMBERS.len()
            + data::LENGTHS.len()
            + data::TEXTS.len()
            + data::COLOR_TOKENS_WITHOUT_VALUE.len()
    }
}

/// Which Fluent alias fills each common role. `None` means Fluent has no such concept.
/// 每个公共角色由哪条 Fluent 别名填写。`None` 表示 Fluent 没有这个概念。
const ADAPTER: &[(CommonColor, Option<&str>)] = &[
    (CommonColor::Accent, Some("colorBrandBackground")),
    (CommonColor::OnAccent, Some("colorBrandForeground1")),
    (CommonColor::AccentContainer, Some("colorBrandBackground2")),
    (CommonColor::OnAccentContainer, Some("colorBrandForeground2")),
    (CommonColor::Surface, Some("colorNeutralBackground1")),
    (CommonColor::OnSurface, Some("colorNeutralForeground1")),
    (CommonColor::SurfaceRaised, Some("colorNeutralBackground2")),
    (CommonColor::OnSurfaceRaised, Some("colorNeutralForeground2")),
    (CommonColor::TextMuted, Some("colorNeutralForeground3")),
    (CommonColor::TextPlaceholder, Some("colorNeutralForeground4")),
    (CommonColor::TextLink, Some("colorBrandForegroundLink")),
    (CommonColor::TextSelection, Some("colorBrandBackground")),
    (CommonColor::Divider, Some("colorNeutralStroke2")),
    (CommonColor::Stroke, Some("colorNeutralStroke1")),
    (CommonColor::SurfaceHover, Some("colorNeutralBackground1Hover")),
    (CommonColor::SurfacePressed, Some("colorNeutralBackground1Pressed")),
    (CommonColor::SurfaceSelected, Some("colorNeutralBackground1Selected")),
    (CommonColor::Error, Some("colorPaletteRedBackground3")),
    (CommonColor::OnError, Some("colorPaletteRedForeground1")),
    (CommonColor::Success, Some("colorPaletteGreenBackground3")),
    (CommonColor::Warning, Some("colorPaletteDarkOrangeBackground3")),
    (CommonColor::FocusRing, Some("colorStrokeFocus2")),
    // Fluent expresses scrims as RGBA overlays the component stacks; no single solid token.
    // Fluent 用组件叠加的 RGBA 遮罩表达 scrim，没有单一实色令牌。
    (CommonColor::Scrim, None),
];

/// Widget-facing names in this framework mapped onto Fluent's own token names.
/// 本框架面向控件的名字到 Fluent 令牌名的映射。
const NATIVE_ALIAS: &[(&str, &str)] = &[
    ("accentFill", "colorBrandBackground"),
    ("onAccentFillColorPrimary", "colorNeutralForegroundOnBrand"),
    ("textOnAccentFillColorPrimary", "colorNeutralForegroundOnBrand"),
    ("textFillColorPrimary", "colorNeutralForeground1"),
    ("textFillColorSecondary", "colorNeutralForeground2"),
    ("controlSolidFillColorDefault", "colorNeutralBackground1"),
    ("controlStrongFillColorDefault", "colorNeutralStroke1"),
];

impl StyleSystem for FluentSystem {
    fn id(&self) -> SystemId {
        SystemId::Fluent
    }

    fn context(&self) -> Context {
        self.ctx
    }

    fn common_colour(&self, role: CommonColor) -> Resolution<Resolved<Rgba>> {
        // WinUI's TextSelectionHighlightColorThemeBrush is accent-derived; white text on it.
        // WinUI 的 TextSelectionHighlightColorThemeBrush 由 accent 派生；其上文字为白色。
        if role == CommonColor::TextSelection {
            return match self.color("colorBrandBackground") {
                Some(c) => Resolution::Value(Resolved::new(
                    c,
                    Source::Derived("winui TextSelectionHighlightColorThemeBrush"),
                )),
                None => Resolution::Unmapped,
            };
        }
        let Some(entry) = ADAPTER.iter().find(|(r, _)| *r == role) else {
            return Resolution::Absent(Reason::NotAConcept);
        };
        match entry.1 {
            None => Resolution::Absent(Reason::NotAConcept),
            Some(name) => match self.color(name) {
                Some(c) => Resolution::Value(Resolved::new(c, TOKEN_SPEC)),
                None => Resolution::Unmapped,
            },
        }
    }

    fn common_metric(&self, metric: CommonMetric) -> Resolution<Resolved<f32>> {
        let scale = self.radius();
        match metric {
            CommonMetric::Radius => match scale.points("medium") {
                Some(points) => Resolution::Value(Resolved::new(points, scale.source)),
                None => Resolution::Unmapped,
            },
            CommonMetric::StrokeWidth => Resolution::Value(Resolved::new(
                1.0,
                Source::Spec("@fluentui/tokens strokeWidthThin"),
            )),
        }
    }

    fn caps(&self) -> StyleCaps {
        StyleCaps {
            named_state_tokens: true,
            shared_palettes: true,
            radius_scale: true,
            motion_tokens: true,
            ..StyleCaps::MINIMAL
        }
    }
}

impl Palette for FluentSystem {
    fn native_colour(&self, id: &str) -> Resolution<Rgba> {
        if let Some(c) = self.color(id) {
            return Resolution::Value(c);
        }
        // A short alias table so widget-facing names land on Fluent's own tokens.
        // 别名表，使面向控件的名字落到 Fluent 自己的令牌上。
        if let Some(target) = NATIVE_ALIAS.iter().find(|(a, _)| *a == id).map(|(_, t)| *t)
            && let Some(c) = self.color(target) {
                return Resolution::Value(c);
            }
        // Every non-colour family is known to Fluent but has no colour here: one reason serves
        // them all, so they share one condition rather than two branches with the same body.
        // 每个非颜色族 Fluent 都认识，但这里给不出颜色：它们共用一个理由，也共用一条判定，
        // 而不是两个分支写同一个结果。
        let known = data::COLOR_TOKENS_WITHOUT_VALUE.contains(&id)
            || data::NUMBERS.iter().any(|(n, _)| *n == id)
            || data::LENGTHS.iter().any(|(n, _)| *n == id)
            || data::TEXTS.iter().any(|(n, _, _, _)| *n == id);
        if !known {
            return Resolution::Unmapped;
        }
        Resolution::Absent(Reason::NotAConcept)
    }

    fn provenance(&self, _id: &str) -> Source {
        TOKEN_SPEC
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::context::{Appearance, Platform};
    use std::collections::HashSet;

    fn light() -> FluentSystem {
        FluentSystem::new(Context::new(Appearance::Light, Platform::Web))
    }

    fn dark() -> FluentSystem {
        FluentSystem::new(Context::new(Appearance::Dark, Platform::Web))
    }

    // Cross-check against the fluentui MCP's reported value; independent of our data file.
    // 与 fluentui MCP 报告的值交叉核对；独立于我们的数据文件。
    #[test]
    fn the_default_text_colour_matches_the_published_token_value() {
        assert_eq!(light().native_colour("colorNeutralForeground1").value(), Some(Rgba::from_rgb(0x24, 0x24, 0x24)));
        assert_eq!(dark().native_colour("colorNeutralForeground1").value(), Some(Rgba::from_rgb(0xff, 0xff, 0xff)));
    }

    #[test]
    fn every_documented_token_name_is_addressable() {
        let mut names = HashSet::new();
        for (n, _) in data::COLORS.iter().chain(data::ALPHA_COLORS.iter()) {
            names.insert(*n);
        }
        for (n, _) in data::NUMBERS {
            names.insert(*n);
        }
        for (n, _) in data::LENGTHS {
            names.insert(*n);
        }
        for (n, _, _, _) in data::TEXTS {
            names.insert(*n);
        }
        for n in data::COLOR_TOKENS_WITHOUT_VALUE {
            names.insert(*n);
        }
        assert_eq!(names.len(), FluentSystem::token_count(), "duplicate or missing token name");
        // Spot-check the ends of each family so the sweep cannot pass on an empty table.
        // 抽查每族两端，避免在空表上误过。
        for name in [
            "colorBrandBackground",
            "colorNeutralBackground1",
            "spacingHorizontalXXXL",
            "borderRadiusCircular",
            "shadow64Brand",
            "fontFamilyBase",
            "durationUltraSlow",
            "fontWeightBold",
        ] {
            assert!(names.contains(name), "{name} missing");
        }
    }

    #[test]
    fn the_named_state_tokens_are_all_queryable_as_colours() {
        let names: Vec<&str> = data::COLORS
            .iter()
            .chain(data::ALPHA_COLORS.iter())
            .map(|(n, _)| *n)
            .filter(|n| n.ends_with("Hover") || n.ends_with("Pressed") || n.ends_with("Selected"))
            .collect();
        assert_eq!(names.len(), 103, "expected 103 named state tokens, got {}", names.len());
        let mut transparent = 0;
        for name in &names {
            let resolved = light().native_colour(name);
            assert!(!resolved.is_failure(), "{name} not resolvable: {resolved:?}");
            let value = resolved.value();
            if value.map(Rgba::alpha) == Some(0) {
                transparent += 1;
            }
        }
        // Five state tokens are deliberately fully transparent in light mode; the rest carry colour.
        // 有五个状态令牌在明色下故意全透明；其余都必须带颜色。
        assert_eq!(transparent, 5, "{transparent} transparent state tokens");
        let opaque = names
            .iter()
            .filter(|n| light().native_colour(n).value().map(Rgba::alpha) == Some(0xff))
            .count();
        assert!(opaque >= 85, "only {opaque} opaque state tokens");
    }

    #[test]
    fn the_four_contrast_buckets_collapse_to_the_three_theme_columns() {
        let ctx = Context::new(Appearance::Light, Platform::Web);
        assert_eq!(theme_column(&ctx.with_contrast(Contrast::Standard)), 0);
        assert_eq!(theme_column(&ctx.with_contrast(Contrast::Low)), 0);
        assert_eq!(theme_column(&ctx.with_contrast(Contrast::High)), 2);
        let dark = Context::new(Appearance::Dark, Platform::Web).with_contrast(Contrast::High);
        assert_eq!(theme_column(&dark), 2, "high contrast outranks dark");
    }

    #[test]
    fn a_role_fluent_lacks_is_refused_rather_than_approximated() {
        assert_eq!(light().common_colour(CommonColor::Scrim), Resolution::Absent(Reason::NotAConcept));
    }

    #[test]
    fn every_common_role_has_a_deliberate_adapter_entry() {
        let covered: HashSet<_> = ADAPTER.iter().map(|(r, _)| *r).collect();
        for role in CommonColor::ALL {
            assert!(covered.contains(&role), "{} has no adapter entry", role.name());
        }
        assert_eq!(ADAPTER.len(), CommonColor::ALL.len(), "duplicate adapter entries");
    }

    #[test]
    fn mapped_roles_return_a_real_colour_in_every_context() {
        for ctx in [
            Context::new(Appearance::Light, Platform::Web),
            Context::new(Appearance::Dark, Platform::Web),
            Context::new(Appearance::Dark, Platform::Web).with_contrast(Contrast::High),
        ] {
            let system = FluentSystem::new(ctx);
            for (role, target) in ADAPTER {
                if target.is_none() {
                    continue;
                }
                assert!(system.common_colour(*role).value().is_some(), "{} empty in {:?}", role.name(), ctx);
            }
        }
    }

    // The default web brand ramp's midpoint; documented as brand-80 #0f6cbd.
    // 默认 web 品牌色阶的中点，文档给出 brand-80 是 #0f6cbd。
    #[test]
    fn the_brand_ramp_is_exposed_and_starts_and_ends_where_documented() {
        assert_eq!(FluentSystem::brand_tone(80), Some(Rgba::from_rgb(0x0f, 0x6c, 0xbd)));
        assert_eq!(FluentSystem::brand_tone(10), Some(Rgba::from_rgb(0x06, 0x17, 0x24)));
        assert_eq!(FluentSystem::brand_tone(160), Some(Rgba::from_rgb(0xeb, 0xf3, 0xfc)));
        assert_eq!(FluentSystem::brand_tone(15), None);
    }

    #[test]
    fn the_adapter_points_at_names_that_actually_exist() {
        for (role, target) in ADAPTER {
            if let Some(name) = target {
                assert!(
                    data::COLORS.iter().chain(data::ALPHA_COLORS.iter()).any(|(n, _)| n == name),
                    "{} points at missing token {name}",
                    role.name()
                );
            }
        }
    }
}
