//! Fluent v8 brand-ramp generation: the `_darken`/`_lighten` HSV model from Fluent's `shades.ts`.
//! Fluent v8 品牌色阶生成：Fluent `shades.ts` 里基于 HSV 的 `_darken`/`_lighten` 模型。
//!
//! The Windows *default* blue ramp is a hand-authored table (`data::BRAND_RAMP`), not a product
//! of this model; this module generates a plausible 16-tone ramp for any other seed colour.
//! Windows **默认**蓝色阶是手写表（`data::BRAND_RAMP`），不是本模型的产物；本模块为任意其它种子色
//! 生成一条可信的 16 档色阶。

use crate::value::Rgba;

/// Tone steps of the 16-tone ramp, darkest to lightest; tone 80 is the seed itself.
/// 16 档色阶的档位，从暗到亮；第 80 档即种子色本身。
pub const TONES: [u16; 16] = [
    10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160,
];

/// The tone that carries the seed colour unchanged.
/// 原样携带种子色的那一档。
pub const KEY_TONE: u16 = 80;

/// Per-step darken factor (v scaled by `1 - f`); matches Fluent's `_darken` shape.
/// 每步变暗系数（v 乘 `1 - f`）；与 Fluent 的 `_darken` 形状一致。
pub const DARK_STEP: f32 = 0.14;

/// Per-step lighten factor (s scaled by `1 - f`, v lifted toward 1); Fluent's `_lighten` shape.
/// 每步变亮系数（s 乘 `1 - f`，v 抬向 1）；Fluent 的 `_lighten` 形状。
pub const LIGHT_STEP: f32 = 0.21;

/// HSV with all components in 0..=1.
/// 各分量均在 0..=1 的 HSV。
#[derive(Clone, Copy, Debug, PartialEq)]
struct Hsv {
    h: f32,
    s: f32,
    v: f32,
}

fn rgb_to_hsv(r: u8, g: u8, b: u8) -> Hsv {
    let (r, g, b) = (r as f32 / 255.0, g as f32 / 255.0, b as f32 / 255.0);
    let max = r.max(g).max(b);
    let min = r.min(g).min(b);
    let d = max - min;
    let h = if d == 0.0 {
        0.0
    } else if max == r {
        ((g - b) / d) % 6.0 / 6.0
    } else if max == g {
        ((b - r) / d + 2.0) / 6.0
    } else {
        ((r - g) / d + 4.0) / 6.0
    };
    let h = if h < 0.0 { h + 1.0 } else { h };
    let s = if max == 0.0 { 0.0 } else { d / max };
    Hsv { h, s, v: max }
}

fn hsv_to_rgb(hsv: Hsv) -> (u8, u8, u8) {
    let Hsv { h, s, v } = hsv;
    let i = (h * 6.0).floor();
    let f = h * 6.0 - i;
    let p = v * (1.0 - s);
    let q = v * (1.0 - f * s);
    let t = v * (1.0 - (1.0 - f) * s);
    let (r, g, b) = match i as i32 % 6 {
        0 => (v, t, p),
        1 => (q, v, p),
        2 => (p, v, t),
        3 => (p, q, v),
        4 => (t, p, v),
        _ => (v, p, q),
    };
    let q8 = |x: f32| (x.clamp(0.0, 1.0) * 255.0).round() as u8;
    (q8(r), q8(g), q8(b))
}

/// Fluent `_darken`: scale value down, keeping hue and saturation.
/// Fluent `_darken`：压低明度，保持色相与饱和。
fn darken(hsv: Hsv, f: f32) -> Hsv {
    Hsv { v: hsv.v * (1.0 - f), ..hsv }
}

/// Fluent `_lighten`: drop saturation and lift value toward white.
/// Fluent `_lighten`：降低饱和，把明度抬向白色。
fn lighten(hsv: Hsv, f: f32) -> Hsv {
    Hsv {
        s: hsv.s * (1.0 - f),
        v: hsv.v + (1.0 - hsv.v) * f,
        ..hsv
    }
}

/// Generate the 16-tone brand ramp for `seed`: tone 80 is the seed, darker below, lighter above.
/// 为 `seed` 生成 16 档品牌色阶：第 80 档为种子色，往下变暗、往上变亮。
pub fn brand_ramp_from_seed(seed: Rgba) -> [(u16, Rgba); 16] {
    let argb = seed.argb();
    let base = rgb_to_hsv((argb >> 16) as u8, (argb >> 8) as u8, argb as u8);
    let key = TONES.iter().position(|t| *t == KEY_TONE).expect("key tone present");

    let mut out = [(0u16, seed); 16];
    out[key] = (TONES[key], seed);

    // Darker: walk down from the seed to tone 10, darkening each step.
    // 变暗：从种子色向下走到第 10 档，每步压暗。
    let mut hsv = base;
    for j in (0..key).rev() {
        hsv = darken(hsv, DARK_STEP);
        let (r, g, b) = hsv_to_rgb(hsv);
        out[j] = (TONES[j], Rgba::from_rgb(r, g, b));
    }

    // Lighter: walk up from the seed to tone 160, lightening each step.
    // 变亮：从种子色向上走到第 160 档，每步提亮。
    let mut hsv = base;
    for j in (key + 1)..TONES.len() {
        hsv = lighten(hsv, LIGHT_STEP);
        let (r, g, b) = hsv_to_rgb(hsv);
        out[j] = (TONES[j], Rgba::from_rgb(r, g, b));
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn lum(c: Rgba) -> f32 {
        let a = c.argb();
        let (r, g, b) = ((a >> 16) as f32, (a >> 8) as f32, a as f32);
        0.2126 * r + 0.7152 * g + 0.0722 * b
    }

    #[test]
    fn the_ramp_is_strictly_monotone_in_luminance() {
        let ramp = brand_ramp_from_seed(Rgba::from_rgb(0x0f, 0x6c, 0xbd));
        for pair in ramp.windows(2) {
            assert!(
                lum(pair[1].1) > lum(pair[0].1),
                "tone {} ({:08x}) must be lighter than tone {} ({:08x})",
                pair[1].0, pair[1].1.argb(), pair[0].0, pair[0].1.argb()
            );
        }
    }

    #[test]
    fn the_key_tone_is_the_seed_unchanged() {
        let seed = Rgba::from_rgb(0x82, 0x22, 0x33);
        let ramp = brand_ramp_from_seed(seed);
        let at80 = ramp.iter().find(|(t, _)| *t == KEY_TONE).unwrap();
        assert_eq!(at80.1, seed);
    }

    /// Fidelity note: this HSV model is *not* how the Windows default ramp was authored, so a
    /// default-seed generation differs from `BRAND_RAMP`. The gap is recorded, not hidden.
    /// 保真说明：本 HSV 模型不是 Windows 默认色阶的成表方式，故默认种子生成值与 `BRAND_RAMP`
    /// 不同。差距被记录而非隐藏。
    #[test]
    fn the_hsv_model_documents_its_gap_to_the_hand_authored_default() {
        let generated = brand_ramp_from_seed(Rgba::from_argb(0xff0f_6cbd));
        let mut worst = 0u8;
        for (tone, g) in generated.iter() {
            let d = crate::fluent::FluentSystem::brand_tone(*tone).expect("default ramp has this tone");
            let (ga, da) = (g.argb(), d.argb());
            for shift in [16, 8, 0] {
                let gc = ((ga >> shift) & 0xff) as i32;
                let dc = ((da >> shift) & 0xff) as i32;
                worst = worst.max((gc - dc).unsigned_abs() as u8);
            }
        }
        // A visible gap is expected; this asserts it stays bounded (HSV cannot match LCH shape).
        // 可见差距在意料之中；此处断言其有界（HSV 无法匹配 LCH 形状）。
        assert!(worst <= 40, "worst channel delta {worst} exceeds documented bound (measured ~31)");
    }
}
