//! Dimension tokens: corner radii, spacing, typography, motion, hit targets.
//! 尺寸令牌：圆角、间距、排版、动效、命中区。
//!
//! Every scale carries its provenance, because none of the three systems publish the same
//! set of numbers: MD3 publishes shape and type, HIG publishes hit targets, Fluent publishes
//! everything, and all three leave some gaps we fill by convention.
//! 每条刻度都带来源，因为三套体系公布的数字并不相同：MD3 公布形状与排版，HIG 只公布命中区，
//! Fluent 公布全部，而三者都有缺口需要按约定补齐。

use crate::source::Source;

/// How a corner is drawn. MD3 exposes both; HIG uses continuous only; Fluent rounds.
/// 圆角怎么画。MD3 两者都暴露；HIG 只用连续曲率；Fluent 用普通圆角。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Curvature {
    /// Circular arc; the CSS `border-radius` behaviour.
    /// 圆弧；等同 CSS `border-radius`。
    Round,
    /// Continuous curvature (squircle); Apple's shape.
    /// 连续曲率（超椭圆）；Apple 的形状。
    Continuous,
    /// A straight chamfer, not a curve; MD3's `cut` family.
    /// 直线切角而非曲线；MD3 的 `cut` 家族。
    Cut,
}

impl Curvature {
    pub const fn name(self) -> &'static str {
        match self {
            Self::Round => "round",
            Self::Continuous => "continuous",
            Self::Cut => "cut",
        }
    }

    /// The engine shape this curvature maps onto. The engine expresses every corner on one
    /// superellipse axis, so the three names are presets, not kinds.
    /// 本曲率对应的引擎形状。引擎把一切圆角放在同一条超椭圆轴上，故三个名字是预设而非种类。
    pub const fn corner_shape(self) -> crate::corner::CornerShape {
        use crate::corner::CornerShape;
        match self {
            Self::Round => CornerShape::ROUND,
            Self::Continuous => CornerShape::SQUIRCLE,
            Self::Cut => CornerShape::BEVEL,
        }
    }
}

/// One named corner radius on a style's own scale.
/// 某风格自身刻度上的一个具名圆角。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct RadiusStep {
    pub name: &'static str,
    /// Points; `-1.0` is the style's sentinel for "fully rounded" (a capsule).
    /// 点数；`-1.0` 是该风格的「全圆」（胶囊）哨兵值。
    pub points: f32,
}

/// A style's full radius scale, plus the curvature family it uses.
/// 一套风格的完整圆角刻度，以及它使用的曲率家族。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct RadiusScale {
    pub steps: &'static [RadiusStep],
    pub curvature: Curvature,
    /// Whether this style can switch to straight-cut corners (MD3 only).
    /// 本风格能否切到直线角（仅 MD3）。
    pub supports_cut: bool,
    pub source: Source,
}

impl RadiusScale {
    pub fn step(&self, name: &str) -> Option<RadiusStep> {
        self.steps.iter().find(|s| s.name == name).copied()
    }

    pub fn points(&self, name: &str) -> Option<f32> {
        self.step(name).map(|s| s.points)
    }
}

/// One spacing token, expressed as a multiple of the style's base grid.
/// 一条间距令牌，表示为该风格基准栅格的倍数。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct SpacingStep {
    pub name: &'static str,
    pub multiple: f32,
}

/// A style's spacing grid: one base, plus named multiples of it.
/// 一套风格的间距栅格：一个基准，加上具名倍数。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct SpacingScale {
    pub base_points: f32,
    pub steps: &'static [SpacingStep],
    /// Off-grid values the style also uses (MD3 spells out 2/4/6/10dp).
    /// 该风格还会用到的非栅格值（MD3 明确列出 2/4/6/10dp）。
    pub nested: &'static [f32],
    pub source: Source,
}

impl SpacingScale {
    pub fn points(&self, name: &str) -> Option<f32> {
        self.steps.iter().find(|s| s.name == name).map(|s| s.multiple * self.base_points)
    }
}

/// One named text style: size, line height and weight.
/// 一个具名文本样式：字号、行高与字重。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TypeStep {
    pub name: &'static str,
    pub size: f32,
    pub line_height: f32,
    pub weight: u16,
}

/// A style's typography ramp. `scalable` marks systems where sizes are a starting point that
/// the OS magnifies (HIG's Dynamic Type), not fixed points.
/// 一套风格的字阶。`scalable` 标记字号只是起点、由系统放大的体系（HIG 的动态字体）。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TypeRamp {
    pub steps: &'static [TypeStep],
    pub scalable: bool,
    pub source: Source,
}

impl TypeRamp {
    pub fn step(&self, name: &str) -> Option<TypeStep> {
        self.steps.iter().find(|s| s.name == name).copied()
    }
}

/// One motion duration.
/// 一条动效时长。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct DurationStep {
    pub name: &'static str,
    pub ms: f32,
}

/// A style's motion vocabulary. `curves` are CSS cubic-bezier control pairs.
/// 一套风格的动效词汇。`curves` 是 CSS 三次贝塞尔控制点对。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct MotionScale {
    pub durations: &'static [DurationStep],
    pub curves: &'static [(&'static str, [f32; 4])],
    pub source: Source,
}

impl MotionScale {
    pub fn duration_ms(&self, name: &str) -> Option<f32> {
        self.durations.iter().find(|s| s.name == name).map(|s| s.ms)
    }

    pub fn curve(&self, name: &str) -> Option<[f32; 4]> {
        self.curves.iter().find(|(n, _)| *n == name).map(|(_, c)| *c)
    }
}

/// Hit-target minimums: `default` is the comfortable size, `minimum` the hard floor.
/// 命中区下限：`default` 是舒适尺寸，`minimum` 是硬下限。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct HitTarget {
    pub default_points: f32,
    pub minimum_points: f32,
    pub source: Source,
}

/// Everything a style says about dimensions.
/// 一套风格对尺寸的全部说法。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct DimensionTokens {
    pub radius: RadiusScale,
    pub spacing: SpacingScale,
    pub typography: TypeRamp,
    pub motion: MotionScale,
    pub hit_target: HitTarget,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn curvature_names_are_stable_and_distinct() {
        let names = [Curvature::Round.name(), Curvature::Continuous.name(), Curvature::Cut.name()];
        assert_eq!(names, ["round", "continuous", "cut"]);
    }

    #[test]
    fn a_radius_step_reports_its_points_and_a_missing_one_is_none() {
        static STEPS: &[RadiusStep] = &[
            RadiusStep { name: "small", points: 8.0 },
            RadiusStep { name: "large", points: 16.0 },
        ];
        let scale = RadiusScale {
            steps: STEPS,
            curvature: Curvature::Round,
            supports_cut: false,
            source: Source::Spec("test"),
        };
        assert_eq!(scale.points("large"), Some(16.0));
        assert_eq!(scale.points("nope"), None);
    }

    // Each curvature name must reach a distinct engine shape, and the three must be ordered
    // on the superellipse axis exactly as the names suggest: cut < round < continuous.
    // 每个曲率名必须映射到不同的引擎形状，且在超椭圆轴上按名称排序：cut < round < continuous。
    #[test]
    fn each_curvature_maps_to_its_own_engine_shape() {
        use crate::corner::CornerShape;
        assert_eq!(Curvature::Round.corner_shape(), CornerShape::ROUND);
        assert_eq!(Curvature::Continuous.corner_shape(), CornerShape::SQUIRCLE);
        assert_eq!(Curvature::Cut.corner_shape(), CornerShape::BEVEL);
        assert!(CornerShape::BEVEL.exponent() < CornerShape::ROUND.exponent());
        assert!(CornerShape::ROUND.exponent() < CornerShape::SQUIRCLE.exponent());
    }

    #[test]
    fn spacing_multiplies_the_base_grid() {
        static STEPS: &[SpacingStep] = &[SpacingStep { name: "space100", multiple: 1.0 }];
        let scale = SpacingScale {
            base_points: 8.0,
            steps: STEPS,
            nested: &[],
            source: Source::Spec("test"),
        };
        assert_eq!(scale.points("space100"), Some(8.0));
    }
}
