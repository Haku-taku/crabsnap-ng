//! What a system can do beyond the common layer, so shared widgets can enhance progressively.
//! 体系在公共层之外的能力，使共享控件可以渐进增强。

/// Optional capabilities. A shared widget checks these before reaching for `native()`.
/// 可选能力。共享控件先检查这些，再去取 `native()`。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Default)]
pub struct StyleCaps {
    /// Has a tonal palette for every key colour (MD3).
    /// 每条 key colour 都有色调调色板（MD3）。
    pub tonal_palettes: bool,
    /// Can produce any tone of any palette (MD3).
    /// 可产出任意调色板的任意 tone（MD3）。
    pub arbitrary_tones: bool,
    /// Has first-class container roles (MD3 `primaryContainer`).
    /// 有一等公民的容器角色（MD3 `primaryContainer`）。
    pub containers: bool,
    /// Has named state tokens instead of computing overlays (Fluent).
    /// 用具名状态令牌而非现场计算叠加（Fluent）。
    pub named_state_tokens: bool,
    /// Has a full shared/persona palette family (Fluent `colorPalette*`).
    /// 有完整的共享/人格化色板族（Fluent `colorPalette*`）。
    pub shared_palettes: bool,
    /// Has layered background depth (HIG base/elevated).
    /// 有分层背景深度（HIG base/elevated）。
    pub elevated_depth: bool,
    /// Has content materials (blur/vibrancy).
    /// 有内容材质（模糊/通透）。
    pub materials: bool,
    /// Has a Liquid Glass style functional layer.
    /// 有液态玻璃类功能层。
    pub glass: bool,
    /// Has a discrete corner-radius scale.
    /// 有离散圆角刻度。
    pub radius_scale: bool,
    /// Corners may be cut (straight) rather than rounded (MD3 `cut`).
    /// 圆角可切成直线（MD3 `cut`）。
    pub cut_corners: bool,
    /// Has a published motion token set; otherwise motion is our convention.
    /// 有公开的动效令牌集；否则动效是我们的自定约定。
    pub motion_tokens: bool,
}

impl StyleCaps {
    /// Nothing but the common layer.
    /// 只有公共层。
    pub const MINIMAL: Self = Self {
        tonal_palettes: false,
        arbitrary_tones: false,
        containers: false,
        named_state_tokens: false,
        shared_palettes: false,
        elevated_depth: false,
        materials: false,
        glass: false,
        radius_scale: false,
        cut_corners: false,
        motion_tokens: false,
    };
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_minimal_profile_claims_no_optional_capability() {
        let caps = StyleCaps::MINIMAL;
        assert!(!caps.containers && !caps.materials && !caps.motion_tokens);
    }

    #[test]
    fn profiles_can_be_built_by_flipping_fields() {
        let caps = StyleCaps { tonal_palettes: true, arbitrary_tones: true, ..StyleCaps::MINIMAL };
        assert!(caps.tonal_palettes && caps.arbitrary_tones);
        assert!(!caps.shared_palettes);
    }
}
