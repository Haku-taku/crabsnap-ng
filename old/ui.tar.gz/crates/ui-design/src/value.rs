//! Colour type and the resolution outcomes a token may have.
//! 颜色类型，以及令牌可能给出的解析结果。

/// Opaque sRGB, the only colour the renderer speaks.
/// 不透明 sRGB，渲染器唯一识别的颜色。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct Rgba(pub u32);

impl Rgba {
    pub const TRANSPARENT: Self = Self(0x0000_0000);

    pub const fn from_argb(argb: u32) -> Self {
        Self(argb)
    }

    pub const fn from_rgb(red: u8, green: u8, blue: u8) -> Self {
        Self(0xff00_0000 | (red as u32) << 16 | (green as u32) << 8 | blue as u32)
    }

    pub const fn argb(self) -> u32 {
        self.0
    }

    pub const fn alpha(self) -> u8 {
        (self.0 >> 24) as u8
    }

    /// Replace the alpha channel, keeping the colour.
    /// 替换 alpha 通道，颜色不变。
    pub const fn with_alpha(self, alpha: u8) -> Self {
        Self((self.0 & 0x00ff_ffff) | (alpha as u32) << 24)
    }
}

/// A value together with where it came from. A snapshot that drops this cannot tell a vendor
/// number from one we synthesized.
/// 值，连同它的来源。丢掉它的快照分不清厂商数字与我们合成的数字。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Resolved<T> {
    pub value: T,
    pub source: crate::source::Source,
}

impl<T> Resolved<T> {
    pub const fn new(value: T, source: crate::source::Source) -> Self {
        Self { value, source }
    }
}

/// What asking a system for a token produced.
/// 向体系索取令牌时得到的结果。
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Resolution<T> {
    /// The system has a concrete value for this context.
    /// 体系在该上下文下有具体值。
    Value(T),
    /// The token belongs to another system; the caller must ask elsewhere.
    /// 该令牌属于另一套体系，调用方需另寻出路。
    Unmapped,
    /// The system has a policy but cannot compute the value here (e.g. host-resolved).
    /// 体系有策略但无法在此求值（例如交宿主解析）。
    Absent(Reason),
}

/// Why a value is absent rather than merely unmapped.
/// 为何缺失，而非仅仅未映射。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Reason {
    /// Resolved by the operating system at runtime; we only know the name.
    /// 由操作系统在运行时解析，我们只知道名字。
    PlatformResolved(&'static str),
    /// Out of the sRGB gamut for this hue and tone.
    /// 该色相与 tone 下超出 sRGB 色域。
    OutOfGamut,
    /// The system has no concept of this role at all.
    /// 体系根本没有这个概念。
    NotAConcept,
}

impl<T> Resolution<T> {
    pub fn value(self) -> Option<T> {
        match self {
            Self::Value(v) => Some(v),
            _ => None,
        }
    }

    /// True when the caller must not silently fall back; this is the loud path.
    /// 调用方不得静默回退时为真；这是显式报错的路径。
    pub fn is_failure(self) -> bool {
        !matches!(self, Self::Value(_))
    }

    pub fn map<U>(self, f: impl FnOnce(T) -> U) -> Resolution<U> {
        match self {
            Self::Value(v) => Resolution::Value(f(v)),
            Self::Unmapped => Resolution::Unmapped,
            Self::Absent(r) => Resolution::Absent(r),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rgba_rounds_through_argb() {
        let c = Rgba::from_rgb(0x67, 0x50, 0xa4);
        assert_eq!(c.argb(), 0xff67_50a4);
        assert_eq!(c.alpha(), 0xff);
    }

    #[test]
    fn alpha_can_be_replaced_without_touching_the_colour() {
        let c = Rgba::from_rgb(0x10, 0x20, 0x30).with_alpha(0x40);
        assert_eq!(c.argb(), 0x4010_2030);
    }

    #[test]
    fn an_absent_resolution_is_a_failure_but_carries_its_reason() {
        let absent: Resolution<u32> = Resolution::Absent(Reason::PlatformResolved("tintColor"));
        assert!(absent.is_failure());
        assert_eq!(absent.value(), None);
        assert_eq!(absent, Resolution::Absent(Reason::PlatformResolved("tintColor")));
    }

    #[test]
    fn mapping_preserves_the_failure_kind() {
        let unmapped: Resolution<u32> = Resolution::Unmapped;
        assert_eq!(unmapped.map(|v| v + 1), Resolution::Unmapped);
    }
}
