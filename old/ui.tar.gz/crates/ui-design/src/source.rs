//! Provenance: every value must answer "why should I believe this?".
//! 来源：每个值都必须能回答「凭什么相信它」。

/// Where a token value came from. Chosen so that a gallery page can print it verbatim.
/// 令牌值从何而来。取值使得画廊页面可以原样印出。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Source {
    /// A number published by the design system's own spec or source.
    /// 由该设计体系规范或源码公开的数字。
    Spec(&'static str),
    /// We computed it from spec inputs; the fields say which rule.
    /// 我们由规范输入算出，字段标明所用规则。
    Derived(&'static str),
    /// Not published by the vendor; our own convention. Must be self-verified.
    /// 厂商未公布，我们的自定约定，必须自证。
    Convention(&'static str),
    /// Resolved by the host OS at runtime; the name is all we know.
    /// 由宿主 OS 在运行时解析，我们只知道名字。
    Platform(&'static str),
}

impl Source {
    /// A short label for display.
    /// 供显示的短标签。
    pub const fn label(self) -> &'static str {
        match self {
            Self::Spec(_) => "spec",
            Self::Derived(_) => "derived",
            Self::Convention(_) => "convention",
            Self::Platform(_) => "platform",
        }
    }

    /// The detail behind the label, e.g. the file or rule name.
    /// 标签背后的细节，例如文件名或规则名。
    pub const fn detail(self) -> &'static str {
        match self {
            Self::Spec(d) | Self::Derived(d) | Self::Convention(d) | Self::Platform(d) => d,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_source_always_yields_a_label_and_a_detail() {
        let s = Source::Derived("md3 GetTone case 2");
        assert_eq!(s.label(), "derived");
        assert_eq!(s.detail(), "md3 GetTone case 2");
    }

    #[test]
    fn convention_and_spec_are_distinguishable() {
        let spec = Source::Spec("HIG system blue");
        let conv = Source::Convention("our 8pt spacing grid");
        assert_ne!(spec.label(), conv.label());
    }
}
