//! The closed list of scalar metrics shared across style systems.
//! 跨风格共享的标量度量封闭清单。
//!
//! Only metrics with a real reader belong here; see `docs/style-object-design.md` §5.3.
//! 只有存在真实读取方的度量才进这里；见 `docs/style-object-design.md` §5.3。

/// A scalar metric every design system can be asked to fill, or to refuse explicitly.
/// 每个设计体系都能被要求填上（或明确拒绝）的标量度量。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum CommonMetric {
    /// The default corner radius of a neutral control.
    /// 中性控件的默认圆角。
    Radius,
    /// Stroke / hairline / divider width.
    /// 描边 / 细线 / 分隔线宽度。
    StrokeWidth,
}

impl CommonMetric {
    /// Every metric, for coverage sweeps.
    /// 全部度量，供覆盖率遍历。
    pub const ALL: [Self; 2] = [Self::Radius, Self::StrokeWidth];

    pub const COUNT: usize = Self::ALL.len();

    /// A stable name, usable in tests and gallery labels.
    /// 稳定名称，可用于测试与画廊标签。
    pub const fn name(self) -> &'static str {
        match self {
            Self::Radius => "radius",
            Self::StrokeWidth => "stroke_width",
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_metric_has_a_distinct_snake_case_name() {
        let names: std::collections::HashSet<_> =
            CommonMetric::ALL.iter().map(|m| m.name()).collect();
        assert_eq!(names.len(), CommonMetric::COUNT);
        assert!(names.iter().all(|n| !n.chars().any(char::is_uppercase)));
    }
}
