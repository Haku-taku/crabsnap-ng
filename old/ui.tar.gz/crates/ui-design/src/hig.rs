//! HIG as a design system: fixed system colours, derived semantic roles, host-resolved names.
//! HIG 作为一套设计体系：固定系统色、自派生的语义角色、交宿主解析的名字。

use crate::capabilities::{Geometry, Palette};
use crate::caps::StyleCaps;
use crate::common::CommonColor;
use crate::context::{Appearance, Context, Contrast, Platform};
use crate::metric::CommonMetric;
use crate::source::Source;
use crate::system::{SystemId, StyleSystem};
use crate::value::{Reason, Resolution, Resolved, Rgba};

mod data {
    include!("../data/hig_data.rs");
}

/// The accent is the published system blue; only the *choice* of it as `tintColor` is ours.
/// 强调色就是公开的系统蓝；只有「以它作 tintColor」这个选择是我们的。
const ACCENT_SPEC: Source = Source::Spec("hig systemBlue as tintColor");

/// The four published contexts Apple ships for every system colour.
/// Apple 为每个系统色提供的四个公开上下文。
fn column(ctx: &Context) -> usize {
    let increased = ctx.contrast == Contrast::High;
    match (ctx.appearance, increased) {
        (Appearance::Light, false) => 0,
        (Appearance::Dark, false) => 1,
        (Appearance::Light, true) => 2,
        (Appearance::Dark, true) => 3,
    }
}

/// Apple HIG, with the semantic layer we derive ourselves because Apple publishes no values.
/// Apple HIG；语义层由我们自己派生，因为 Apple 不公布数值。
#[derive(Clone, Copy, Debug)]
pub struct HigSystem {
    pub ctx: Context,
}

impl HigSystem {
    pub const fn new(ctx: Context) -> Self {
        Self { ctx }
    }

    /// A published system colour by name, in the current context.
    /// 按名取当前上下文下的公开系统色。
    pub fn system_color(&self, name: &str) -> Option<Rgba> {
        data::SYSTEM_COLORS
            .iter()
            .chain(data::GRAY_RAMP.iter())
            .chain(data::DISABLED_COLORS.iter())
            .chain(data::FILL_COLORS.iter())
            .find(|(n, _)| *n == name)
            .map(|(_, v)| Rgba::from_argb(v[column(&self.ctx)]))
    }

    /// A system colour name from HIG (`systemBlue`) in SwiftUI spelling (`blue`).
    /// HIG 名字（`systemBlue`）到 SwiftUI 写法（`blue`）。
    pub fn swiftui_name(name: &str) -> Option<&'static str> {
        const PAIRS: &[(&str, &str)] = &[
            ("systemRed", "red"),
            ("systemOrange", "orange"),
            ("systemYellow", "yellow"),
            ("systemGreen", "green"),
            ("systemMint", "mint"),
            ("systemTeal", "teal"),
            ("systemCyan", "cyan"),
            ("systemBlue", "blue"),
            ("systemIndigo", "indigo"),
            ("systemPurple", "purple"),
            ("systemPink", "pink"),
            ("systemBrown", "brown"),
            ("systemGray", "gray"),
        ];
        PAIRS.iter().find(|(a, _)| *a == name).map(|(_, b)| *b)
    }

    /// The hit-target minimum in points for this context's platform.
    /// 当前平台上下文下的命中区下限（pt）。
    pub fn hit_target(&self) -> (f32, f32) {
        let key = match self.ctx.platform {
            Platform::Ios | Platform::Ipados => "ios_ipados",
            Platform::Macos => "macos",
            Platform::Android => "ios_ipados",
            Platform::Web | Platform::Desktop => "macos",
        };
        data::HIT_TARGETS
            .iter()
            .find(|(p, _, _)| *p == key)
            .map(|(_, default, minimum)| (*default, *minimum))
            .unwrap_or((44.0, 28.0))
    }

    /// Pick the accent colour: the `tintColor` role has no published value, so we use the
    /// system blue, which is what `tintColor` resolves to on a stock system.
    /// `tintColor` 无公开值；系统蓝是其在原生系统的实际解析结果，故以之代表。
    fn accent(&self) -> Rgba {
        self.system_color("systemBlue").unwrap_or(Rgba::from_rgb(0, 122, 255))
    }

    /// A published system colour with its provenance, or our neutral step when it is missing.
    /// 公开系统色连同来源；缺失时退回自派生的中性步。
    fn system_ink(&self, name: &str, fallback: Rgba) -> Resolved<Rgba> {
        match self.system_color(name) {
            Some(c) => Resolved::new(c, Source::Spec("hig system colors")),
            None => Resolved::new(fallback, Source::Derived("neutral tone fallback")),
        }
    }
}

/// Our own derived neutral steps, since Apple publishes only system colours.
/// 自派生的中性色阶；Apple 只公布系统色。
fn neutral(tone: f64) -> Rgba {
    Rgba::from_argb(ui_color_hct::argb_from_tone(tone))
}

impl StyleSystem for HigSystem {
    fn id(&self) -> SystemId {
        SystemId::Hig
    }

    fn context(&self) -> Context {
        self.ctx
    }

    fn common_colour(&self, role: CommonColor) -> Resolution<Resolved<Rgba>> {
        let dark = self.ctx.is_dark();
        let ink = if dark { 92.0 } else { 12.0 };
        let base = if dark { 0.0 } else { 100.0 };
        let raised = if dark { 9.0 } else { 98.0 };
        // Apple publishes no colour-role table: every value here is our synthesis.
        // Apple 不公布颜色角色表：这里每个值都是我们合成的。
        let derived = |c| Resolved::new(c, Source::Derived("hig accent + neutral tone"));
        match role {
            CommonColor::Accent | CommonColor::TextLink | CommonColor::FocusRing => {
                Resolution::Value(Resolved::new(self.accent(), ACCENT_SPEC))
            }
            CommonColor::OnAccent | CommonColor::OnError => {
                Resolution::Value(derived(Rgba::from_rgb(0xff, 0xff, 0xff)))
            }
            CommonColor::AccentContainer => {
                Resolution::Value(derived(self.accent().with_alpha(0x2e)))
            }
            CommonColor::OnAccentContainer => Resolution::Value(derived(neutral(ink))),
            CommonColor::Surface => Resolution::Value(derived(neutral(base))),
            CommonColor::OnSurface | CommonColor::OnSurfaceRaised => {
                Resolution::Value(derived(neutral(ink)))
            }
            CommonColor::SurfaceRaised => Resolution::Value(derived(neutral(raised))),
            CommonColor::TextMuted => {
                Resolution::Value(derived(neutral(if dark { 62.0 } else { 44.0 })))
            }
            CommonColor::TextPlaceholder => {
                Resolution::Value(derived(neutral(if dark { 46.0 } else { 62.0 })))
            }
            CommonColor::Divider => {
                Resolution::Value(derived(neutral(if dark { 22.0 } else { 88.0 })))
            }
            CommonColor::Stroke => {
                Resolution::Value(derived(neutral(if dark { 32.0 } else { 78.0 })))
            }
            CommonColor::SurfaceHover => {
                Resolution::Value(derived(neutral(if dark { 14.0 } else { 95.0 })))
            }
            CommonColor::SurfacePressed => {
                Resolution::Value(derived(neutral(if dark { 18.0 } else { 92.0 })))
            }
            CommonColor::SurfaceSelected => {
                Resolution::Value(derived(self.accent().with_alpha(0x24)))
            }
            // Apple publishes no selection colour: the tint at 25% is our own reading of
            // the system's look, so the source says "convention", not "spec".
            // Apple 不公布选区颜色：tint 25% 是我们对系统观感的读法，
            // 因此来源写「约定」而非「规范」。
            CommonColor::TextSelection => {
                Resolution::Value(Resolved::new(
                    self.accent().with_alpha(0x40),
                    Source::Convention("tintColor wash behind selected text"),
                ))
            }
            CommonColor::Error => Resolution::Value(self.system_ink("systemRed", neutral(50.0))),
            CommonColor::Success => Resolution::Value(self.system_ink("systemGreen", neutral(50.0))),
            CommonColor::Warning => {
                Resolution::Value(self.system_ink("systemOrange", neutral(50.0)))
            }
            // A scrim is a live blur plus dim behind a sheet, never a flat colour.
            // scrim 是 sheet 背后的实时模糊加暗化，从不是纯色。
            CommonColor::Scrim => Resolution::Absent(Reason::PlatformResolved("sheet backdrop")),
        }
    }

    fn common_metric(&self, metric: CommonMetric) -> Resolution<Resolved<f32>> {
        let scale = self.radius();
        match metric {
            CommonMetric::Radius => match scale.points("medium") {
                Some(points) => Resolution::Value(Resolved::new(points, scale.source)),
                None => Resolution::Unmapped,
            },
            // iOS separators are a hairline: 1px at any scale, i.e. 0.5pt at @2x.
            // iOS 分隔线是发丝线：任何缩放下都是 1px，即 @2x 下的 0.5pt。
            CommonMetric::StrokeWidth => Resolution::Value(Resolved::new(
                0.5,
                Source::Convention("ios hairline separator"),
            )),
        }
    }

    fn caps(&self) -> StyleCaps {
        StyleCaps {
            elevated_depth: true,
            materials: true,
            glass: true,
            ..StyleCaps::MINIMAL
        }
    }
}

impl Palette for HigSystem {
    fn native_colour(&self, id: &str) -> Resolution<Rgba> {
        // Published system colours are values; semantic roles and materials are names only.
        // 公开系统色是有值的；语义角色与材质只有名字。
        if data::SYSTEM_COLORS.iter().any(|(n, _)| *n == id)
            || data::GRAY_RAMP.iter().any(|(n, _)| *n == id)
            || data::DISABLED_COLORS.iter().any(|(n, _)| *n == id)
            || data::FILL_COLORS.iter().any(|(n, _)| *n == id)
        {
            return match self.system_color(id) {
                Some(c) => Resolution::Value(c),
                None => Resolution::Unmapped,
            };
        }
        if data::MATERIALS.contains(&id) {
            return Resolution::Absent(Reason::PlatformResolved(material_name(id)));
        }
        if data::SEMANTIC_ROLES.contains(&id) {
            return Resolution::Absent(Reason::PlatformResolved(semantic_name(id)));
        }
        Resolution::Unmapped
    }

    fn provenance(&self, id: &str) -> Source {
        let published = data::SYSTEM_COLORS.iter().any(|(n, _)| *n == id)
            || data::GRAY_RAMP.iter().any(|(n, _)| *n == id)
            || data::DISABLED_COLORS.iter().any(|(n, _)| *n == id)
            || data::FILL_COLORS.iter().any(|(n, _)| *n == id);
        if published {
            Source::Spec("Apple HIG system colours")
        } else if data::MATERIALS.contains(&id) {
            Source::Spec("Apple HIG materials")
        } else {
            Source::Convention("our derivation; Apple publishes no value")
        }
    }
}

/// Apple's materials are known by name but resolved by the system; keep the name readable.
/// Apple 的材质虽只知名，但由系统解析；把名字保留为可读形式。
fn material_name(name: &str) -> &'static str {
    match name {
        "ultraThinMaterial" => ".ultraThinMaterial",
        "thinMaterial" => ".thinMaterial",
        "regularMaterial" => ".regularMaterial",
        "thickMaterial" => ".thickMaterial",
        "ultraThickMaterial" => ".ultraThickMaterial",
        _ => ".bar",
    }
}

fn semantic_name(name: &str) -> &'static str {
    match name {
        "label" => "Color(.label)",
        "secondaryLabel" => "Color(.secondaryLabel)",
        "tertiaryLabel" => "Color(.tertiaryLabel)",
        "quaternaryLabel" => "Color(.quaternaryLabel)",
        "systemBackground" => "Color(.systemBackground)",
        "secondarySystemBackground" => "Color(.secondarySystemBackground)",
        "tertiarySystemBackground" => "Color(.tertiarySystemBackground)",
        "systemGroupedBackground" => "Color(.systemGroupedBackground)",
        "separator" => "Color(.separator)",
        "opaqueSeparator" => "Color(.opaqueSeparator)",
        "systemFill" => "Color(.systemFill)",
        "secondarySystemFill" => "Color(.secondarySystemFill)",
        "tertiarySystemFill" => "Color(.tertiarySystemFill)",
        "quaternarySystemFill" => "Color(.quaternarySystemFill)",
        _ => "Color(.tintColor)",
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn light() -> HigSystem {
        HigSystem::new(Context::new(Appearance::Light, Platform::Ios))
    }

    fn dark() -> HigSystem {
        HigSystem::new(Context::new(Appearance::Dark, Platform::Ios))
    }

    fn increased(appearance: Appearance) -> HigSystem {
        HigSystem::new(Context::new(appearance, Platform::Ios).with_contrast(Contrast::High))
    }

    // The HIG table's own values, checked through our lookup so the table is wired, not just present.
    // 直接核对 HIG 表的值，确保数据被接通而不只是存在。
    #[test]
    fn published_system_colours_match_the_hig_table() {
        assert_eq!(light().system_color("systemBlue").map(Rgba::argb), Some(0xff00_88ff));
        assert_eq!(dark().system_color("systemBlue").map(Rgba::argb), Some(0xff00_91ff));
        assert_eq!(light().system_color("systemGray").map(Rgba::argb), Some(0xff8e_8e93));
    }

    // Increased contrast is a distinct published value, not a computed tweak.
    // 增强对比是独立公布的值，不是算出来的微调。
    #[test]
    fn increased_contrast_switches_to_its_own_published_value() {
        assert_eq!(increased(Appearance::Light).system_color("systemBlue").map(Rgba::argb), Some(0xff1e_6ef4));
        assert_eq!(increased(Appearance::Light).system_color("systemRed").map(Rgba::argb), Some(0xffe9_152d));
        assert_ne!(
            increased(Appearance::Light).system_color("systemBlue"),
            light().system_color("systemBlue")
        );
    }

    #[test]
    fn every_system_colour_is_addressable_and_has_four_contexts() {
        let count = data::SYSTEM_COLORS.len() + data::GRAY_RAMP.len();
        assert_eq!(count, 18);
        for (name, _) in data::SYSTEM_COLORS.iter().chain(data::GRAY_RAMP.iter()) {
            for ctx in [light(), dark(), increased(Appearance::Light), increased(Appearance::Dark)] {
                assert!(ctx.native_colour(name).value().is_some(), "{name} missing in {:?}", ctx.ctx);
            }
        }
    }

    // Semantic roles are names with no published value; refusing is the honest answer.
    // 语义角色只有名字、无公开值；拒绝才是诚实的答案。
    #[test]
    fn semantic_roles_and_materials_are_reported_as_host_resolved() {
        for name in data::SEMANTIC_ROLES {
            assert_eq!(
                light().native_colour(name),
                Resolution::Absent(Reason::PlatformResolved(semantic_name(name))),
                "{name}"
            );
        }
        for name in data::MATERIALS {
            assert!(matches!(light().native_colour(name), Resolution::Absent(Reason::PlatformResolved(_))));
        }
    }

    // HIG's contrast floor: body text must clear 4.5:1, and small text should aim at 7:1.
    // HIG 的对比下限：正文须过 4.5:1，小字应争取 7:1。
    #[test]
    fn text_pairs_clear_four_and_a_half_to_one_in_every_context() {
        for ctx in [light(), dark(), increased(Appearance::Light), increased(Appearance::Dark)] {
            for (fg, bg) in [
                (CommonColor::OnSurface, CommonColor::Surface),
                (CommonColor::OnSurfaceRaised, CommonColor::SurfaceRaised),
            ] {
                let f = ctx.common_colour(fg).value().unwrap();
                let b = ctx.common_colour(bg).value().unwrap();
                let ratio = ui_color_hct::ratio_of_tones(
                    ui_color_hct::tone_of(f.value.argb()),
                    ui_color_hct::tone_of(b.value.argb()),
                );
                assert!(ratio >= 4.5, "{ctx:?} {fg:?}/{bg:?} = {ratio:.2}");
            }
        }
    }

    // Increased contrast must not reduce foreground/background separation.
    // 增强对比不得减小前景/背景的分离度。
    #[test]
    fn increased_contrast_never_reduces_the_text_gap() {
        for appearance in [Appearance::Light, Appearance::Dark] {
            let plain = HigSystem::new(Context::new(appearance, Platform::Ios));
            let high = increased(appearance);
            let gap = |s: &HigSystem| {
                let f = ui_color_hct::tone_of(s.common_colour(CommonColor::OnSurface).value().unwrap().value.argb());
                let b = ui_color_hct::tone_of(s.common_colour(CommonColor::Surface).value().unwrap().value.argb());
                (f - b).abs()
            };
            assert!(gap(&high) >= gap(&plain) - 0.01, "{appearance:?}: {} vs {}", gap(&high), gap(&plain));
        }
    }

    // The grey ramp must be monotone: darker in light mode, lighter in dark mode.
    // 灰色阶必须单调：明色下逐渐变暗，暗色下逐渐变亮。
    #[test]
    fn the_grey_ramp_is_monotone_in_both_appearances() {
        let ramp: Vec<_> = ["systemGray", "systemGray2", "systemGray3", "systemGray4", "systemGray5", "systemGray6"]
            .iter()
            .map(|n| ui_color_hct::tone_of(light().system_color(n).unwrap().argb()))
            .collect();
        for pair in ramp.windows(2) {
            assert!(pair[1] >= pair[0] - 0.5, "light ramp not monotone: {pair:?}");
        }
        let dark_ramp: Vec<_> = ["systemGray", "systemGray2", "systemGray3", "systemGray4", "systemGray5", "systemGray6"]
            .iter()
            .map(|n| ui_color_hct::tone_of(dark().system_color(n).unwrap().argb()))
            .collect();
        for pair in dark_ramp.windows(2) {
            assert!(pair[1] <= pair[0] + 0.5, "dark ramp not monotone: {pair:?}");
        }
    }

    #[test]
    fn hit_targets_follow_the_platform_and_never_go_below_the_minimum() {
        let ios = HigSystem::new(Context::new(Appearance::Light, Platform::Ios));
        assert_eq!(ios.hit_target(), (44.0, 28.0));
        let mac = HigSystem::new(Context::new(Appearance::Light, Platform::Macos));
        assert_eq!(mac.hit_target(), (28.0, 20.0));
        for (_, default, minimum) in data::HIT_TARGETS {
            assert!(default >= minimum);
        }
    }

    #[test]
    fn every_common_role_is_answered_or_refused_deliberately() {
        let mut answered = 0;
        for ctx in [light(), dark()] {
            for role in CommonColor::ALL {
                match ctx.common_colour(role) {
                    Resolution::Value(_) => answered += 1,
                    Resolution::Absent(Reason::PlatformResolved(_)) => {}
                    other => panic!("{}: {other:?}", role.name()),
                }
            }
        }
        assert!(answered >= 2 * (CommonColor::ALL.len() - 1), "too many gaps: {answered}");
    }

    #[test]
    fn provenance_separates_published_values_from_our_derivations() {
        assert_eq!(light().provenance("systemBlue").label(), "spec");
        assert_eq!(light().provenance("label").label(), "convention");
        assert_eq!(HigSystem::swiftui_name("systemMint"), Some("mint"));
    }

    #[test]
    fn disabled_colours_resolve_in_every_context() {
        // The disabled fills/label come from Apple's dynamic palette (via Cupertino); they are
        // values now, not host-resolved names. 禁用填充/标签有具体值，不再交宿主解析。
        for name in ["inactiveGray", "tertiarySystemFill", "quaternarySystemFill"] {
            for ctx in [light(), dark(), increased(Appearance::Light), increased(Appearance::Dark)] {
                assert!(ctx.native_colour(name).value().is_some(), "{name} missing in {:?}", ctx.ctx);
            }
        }
        assert_eq!(light().native_colour("inactiveGray").value().map(Rgba::argb), Some(0xff99_9999));
        assert_eq!(dark().native_colour("inactiveGray").value().map(Rgba::argb), Some(0xff75_7575));
    }

}
