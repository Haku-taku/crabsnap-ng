//! ui-design: one semantic layer over three complete native design systems.
//! ui-design：覆盖三套完整原生设计体系的统一语义层。
//!
//! Two planes, not a lowest common denominator: `CommonColor` is one path across systems,
//! while every native token stays reachable through `Palette::colour`.
//! 双平面而非最小公约数：`CommonColor` 是跨体系的一条路径，而每个原生令牌都经
//! `Palette::colour` 可达。

pub mod caps;
pub mod capabilities;
pub mod common;
pub mod corner;
pub mod context;
pub mod dimension;
pub mod scales;
pub mod fluent;
pub mod fluent_brand;
pub mod fluent_brand_v9;
pub mod fluent_hue_map;
pub mod hig;
pub mod md3;
pub mod metric;
pub mod source;
pub mod system;
pub mod value;
pub mod winui;

pub use capabilities::{
    Geometry, Motion, NativePalette, NoPalette, Palette, Typography, WithDimensions,
};
pub use caps::StyleCaps;
pub use common::CommonColor;
pub use corner::CornerShape;
pub use context::{Appearance, Context, Contrast, Depth, Platform, WritingMode};
pub use scales::{dimension_caps, dimensions_of};
pub use dimension::{
    Curvature, DimensionTokens, DurationStep, HitTarget, MotionScale, RadiusScale,
    RadiusStep, SpacingScale, SpacingStep, TypeRamp, TypeStep,
};
pub use fluent::FluentSystem;
pub use fluent_brand::{brand_ramp_from_seed, KEY_TONE, TONES};
pub use fluent_brand_v9::{brand_ramp_from_seed as brand_ramp_v9_from_seed, brand_ramp_from_seed_with as brand_ramp_v9_with, LogDistribution};
pub use hig::HigSystem;
pub use md3::{Md3Scheme, Role};
pub use metric::CommonMetric;
pub use source::Source;
pub use system::{NativeName, SystemId, StyleSystem, Theme};
pub use ui_color_hct::tone_of;
pub use value::{Reason, Resolution, Resolved, Rgba};
pub use winui::{Accent, GradientBrush, Paint, WinUISystem};
