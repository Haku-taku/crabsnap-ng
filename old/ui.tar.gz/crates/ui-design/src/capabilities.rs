//! The four responsibilities a style answers, split apart so they can differ per handle.
//! 一套风格要回答的四项职责，拆开后每个句柄可以各自不同。
//!
//! Colour, geometry, type and motion change for different reasons; see §22 of the design doc.
//! 颜色、几何、字体、动效的变化理由各不相同；见设计文档 §22。

use crate::dimension::{
    DimensionTokens, HitTarget, MotionScale, RadiusScale, SpacingScale, TypeRamp, TypeStep,
};
use crate::source::Source;
use crate::value::{Reason, Resolution, Rgba};

/// One lookup path: a colour for a token id in the style's own vocabulary.
/// 只有一条查询路径：按本体系自身词汇里的令牌 id 取色。
///
/// Deliberately no `common` here: resolving a shared role is the semantic *variant* of `Style`
/// doing work — translate via the style's adapter, else fall back — not something every palette
/// must re-implement. See §22.
/// 这里刻意不设 `common`：解析共享角色是 `Style` 的**语义化变体**在做事——先翻译，否则回落——
/// 不是每个调色板都得重新实现一遍。见 §22。
pub trait Palette: Send + Sync {
    /// Resolve a token in this style's own vocabulary; never pruned, never silently guessed.
    /// 在本体系自身词汇里解析一个令牌；永不裁剪，也绝不静默臆造。
    fn native_colour(&self, id: &str) -> Resolution<Rgba>;

    /// The brush under `id` when it is more than one colour; `None` means `native_colour` rules.
    /// `id` 下不止一种颜色的画刷；`None` 表示以 `native_colour` 为准。
    fn native_brush(&self, _id: &str) -> Option<crate::winui::Paint> {
        None
    }

    /// Where the value behind `id` comes from.
    /// `id` 背后那个值的来源。
    fn provenance(&self, id: &str) -> Source;
}

/// The one source the dimension traits read from. Everything below is `Copy` over `&'static`
/// tables, so reading per call costs nothing and no cache can drift.
/// 各维度 trait 唯一的读取来源。下面的类型全是 `Copy` 加 `&'static` 表，故每次调用现取不花代价，
/// 也不会有缓存漂移。
pub trait WithDimensions {
    fn dimensions(&self) -> DimensionTokens;
}

/// Shape and space. Defaults read `dimensions()`; override a single method only where this
/// style genuinely answers that question differently.
/// 形状与空间。默认读 `dimensions()`；只有某问确实答案不同时才覆写单个方法。
pub trait Geometry: WithDimensions {
    fn radius(&self) -> RadiusScale {
        self.dimensions().radius
    }

    fn spacing(&self) -> SpacingScale {
        self.dimensions().spacing
    }

    fn hit_target(&self) -> HitTarget {
        self.dimensions().hit_target
    }

    /// A named radius, e.g. `"largeIncreased"`.
    fn radius_points(&self, name: &str) -> Option<f32> {
        self.radius().points(name)
    }

    /// A named radius together with the curvature family, so a widget gets the shape too.
    /// 具名圆角连同曲率家族一起给出，使控件同时拿到形状。
    fn corner(&self, name: &str) -> Option<crate::corner::CornerShape> {
        let scale = self.radius();
        scale.step(name).map(|_| scale.curvature.corner_shape())
    }
}

/// Type sizes only, deliberately **colour-free**: the spec ramps define size, weight and
/// leading, while ink is the component's role choice — colour here is that decision posing as a ramp.
/// 只含字号，刻意**不带颜色**：规范字阶定义字号/字重/行高，而墨色是控件对角色的选择——
/// 颜色若住在这里，等于那个决定冒充字阶。
pub trait Typography: WithDimensions {
    fn ramp(&self) -> TypeRamp {
        self.dimensions().typography
    }

    /// One named step of the ramp, e.g. `"body"`.
    fn step(&self, name: &str) -> Option<TypeStep> {
        self.ramp().step(name)
    }

    /// Whether the OS magnifies these sizes rather than fixing them (HIG's Dynamic Type).
    /// 字号是否由系统放大而非固定（HIG 动态字体）。
    fn scalable(&self) -> bool {
        self.ramp().scalable
    }
}

/// Durations and easing curves. Provenance honesty lives on `MotionScale.source`.
/// 时长与缓动曲线。来源是否可靠记在 `MotionScale.source` 上。
pub trait Motion: WithDimensions {
    fn scale(&self) -> MotionScale {
        self.dimensions().motion
    }

    /// A named duration in milliseconds, e.g. `"medium2"`.
    fn duration_ms(&self, name: &str) -> Option<f32> {
        self.scale().durations.iter().find(|d| d.name == name).map(|d| d.ms)
    }

    /// A named easing curve.
    fn curve(&self, name: &str) -> Option<[f32; 4]> {
        self.scale().curves.iter().find(|(n, _)| *n == name).map(|(_, c)| *c)
    }
}

/// Answers nothing, refusing with `Absent`. Lets a `Style` be complete when a system has no
/// such concept without inventing a colour to fill the hole.
/// 一律以 `Absent` 拒绝。使 `Style` 在体系确实无此概念时仍能完整构造，而不必臆造颜色填空。
pub struct NoPalette;

impl Palette for NoPalette {
    fn native_colour(&self, _id: &str) -> Resolution<Rgba> {
        Resolution::Absent(Reason::NotAConcept)
    }

    fn provenance(&self, _id: &str) -> Source {
        Source::Convention("no palette answers; the caller must fall back")
    }
}

/// Names the style's own answer, so a `Style` says "this handle is the native palette" instead
/// of holding an anonymous `Arc<dyn Palette>`.
/// 具名地表示该风格自己的答案，使 `Style` 能说「这个句柄是原生调色板」，而非持有匿名 `Arc`。
pub struct NativePalette<S: Palette>(pub S);

impl<S: Palette> Palette for NativePalette<S> {
    fn native_colour(&self, id: &str) -> Resolution<Rgba> {
        self.0.native_colour(id)
    }

    fn provenance(&self, id: &str) -> Source {
        self.0.provenance(id)
    }
}
