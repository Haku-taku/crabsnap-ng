//! The closed list of semantic colours shared across style systems.
//! 跨风格共享的语义颜色封闭清单。
//!
//! This is a *path*, not a lowest common denominator: every native token stays reachable
//! through `native()`, and a shared widget that needs something richer asks `caps()` first.
//! 这是一条*路径*，不是最小公约数：原生令牌全经 `native()` 可达，共享控件需要更强能力
//! 时先问 `caps()`。

/// A colour role every design system can be asked to fill, or to refuse explicitly.
/// 每个设计体系都能被要求填上（或明确拒绝）的颜色角色。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum CommonColor {
    /// The product's accent: MD3 `primary`, Fluent `colorBrandBackground`, HIG `tintColor`.
    /// 产品强调色：MD3 `primary`、Fluent `colorBrandBackground`、HIG `tintColor`。
    Accent,
    /// Text/symbol on the accent background.
    /// 强调色背景上的文字/符号。
    OnAccent,
    /// A lower-emphasis accent container (MD3 `primaryContainer`, HIG `secondarySystemFill`).
    /// 低强调的强调色容器（MD3 `primaryContainer`、HIG `secondarySystemFill`）。
    AccentContainer,
    /// Content on `AccentContainer`.
    /// `AccentContainer` 上的内容。
    OnAccentContainer,
    /// The page/app base surface.
    /// 页面/应用基底表面。
    Surface,
    /// Content on `Surface`.
    /// `Surface` 上的内容。
    OnSurface,
    /// A raised or grouped surface (card, sheet, dialog).
    /// 抬升或分组的表面（卡片、页签、对话框）。
    SurfaceRaised,
    /// Content on `SurfaceRaised`.
    /// `SurfaceRaised` 上的内容。
    OnSurfaceRaised,
    /// De-emphasised text.
    /// 弱化文字。
    TextMuted,
    /// Placeholder text.
    /// 占位文字。
    TextPlaceholder,
    /// Links.
    /// 链接。
    TextLink,
    /// The wash behind selected text.
    /// 被选中文字背后的底色。
    TextSelection,
    /// Hairline between regions.
    /// 区域之间的细线。
    Divider,
    /// The stroke around an interactive surface.
    /// 交互面周边的描边。
    Stroke,
    /// Hover state for a neutral surface.
    /// 中性表面的悬停态。
    SurfaceHover,
    /// Pressed state for a neutral surface.
    /// 中性表面的按下态。
    SurfacePressed,
    /// Selected state for a neutral surface.
    /// 中性表面的选中态。
    SurfaceSelected,
    /// Error accent.
    /// 错误强调色。
    Error,
    /// Content on `Error`.
    /// `Error` 上的内容。
    OnError,
    /// Success accent.
    /// 成功强调色。
    Success,
    /// Warning accent.
    /// 警告强调色。
    Warning,
    /// Focus ring.
    /// 焦点环。
    FocusRing,
    /// Scrim behind modals.
    /// 模态框后面的遮罩。
    Scrim,
}

impl CommonColor {
    /// Every role, for coverage sweeps.
    /// 全部角色，供覆盖率遍历。
    pub const ALL: [Self; 23] = [
        Self::Accent,
        Self::OnAccent,
        Self::AccentContainer,
        Self::OnAccentContainer,
        Self::Surface,
        Self::OnSurface,
        Self::SurfaceRaised,
        Self::OnSurfaceRaised,
        Self::TextMuted,
        Self::TextPlaceholder,
        Self::TextLink,
        Self::TextSelection,
        Self::Divider,
        Self::Stroke,
        Self::SurfaceHover,
        Self::SurfacePressed,
        Self::SurfaceSelected,
        Self::Error,
        Self::OnError,
        Self::Success,
        Self::Warning,
        Self::FocusRing,
        Self::Scrim,
    ];

    /// For fixed-size arrays that must hold one entry per role.
    /// 供「每个角色一个条目」的定长数组使用。
    pub const COUNT: usize = Self::ALL.len();

    /// A stable name, usable in tests and gallery labels.
    /// 稳定名称，可用于测试与画廊标签。
    pub const fn name(self) -> &'static str {
        match self {
            Self::Accent => "accent",
            Self::OnAccent => "on_accent",
            Self::AccentContainer => "accent_container",
            Self::OnAccentContainer => "on_accent_container",
            Self::Surface => "surface",
            Self::OnSurface => "on_surface",
            Self::SurfaceRaised => "surface_raised",
            Self::OnSurfaceRaised => "on_surface_raised",
            Self::TextMuted => "text_muted",
            Self::TextPlaceholder => "text_placeholder",
            Self::TextLink => "text_link",
            Self::TextSelection => "text_selection",
            Self::Divider => "divider",
            Self::Stroke => "stroke",
            Self::SurfaceHover => "surface_hover",
            Self::SurfacePressed => "surface_pressed",
            Self::SurfaceSelected => "surface_selected",
            Self::Error => "error",
            Self::OnError => "on_error",
            Self::Success => "success",
            Self::Warning => "warning",
            Self::FocusRing => "focus_ring",
            Self::Scrim => "scrim",
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashSet;

    #[test]
    fn the_all_table_lists_every_role_exactly_once() {
        let names: HashSet<_> = CommonColor::ALL.iter().map(|r| r.name()).collect();
        assert_eq!(names.len(), CommonColor::ALL.len());
        assert!(names.contains("accent") && names.contains("on_accent"));
    }

    #[test]
    fn names_are_stable_snake_case() {
        for role in CommonColor::ALL {
            assert!(!role.name().is_empty());
            assert!(!role.name().chars().any(|c| c.is_uppercase()));
        }
    }
}
