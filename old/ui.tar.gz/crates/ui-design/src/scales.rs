//! The three styles' dimension tokens, as data plus the accessors that reach them.
//! 三套风格的尺寸令牌：数据，以及取用它们的访问器。

use crate::caps::StyleCaps;
use crate::capabilities::{Geometry, Motion, Typography, WithDimensions};
use crate::dimension::DimensionTokens;
use crate::system::SystemId;

mod data {
    include!("../data/dimensions_data.rs");
}

// Each system answers the dimension traits from its own tables; the bodies are the trait
// defaults, so only the source is named here.
// 各体系由自身表回答维度 trait；方法体就是 trait 默认实现，故这里只命名来源。
impl Geometry for crate::md3::Md3Scheme {}
impl Typography for crate::md3::Md3Scheme {}
impl Motion for crate::md3::Md3Scheme {}
impl Geometry for crate::fluent::FluentSystem {}
impl Typography for crate::fluent::FluentSystem {}
impl Motion for crate::fluent::FluentSystem {}
impl Geometry for crate::hig::HigSystem {}
impl Typography for crate::hig::HigSystem {}
impl Motion for crate::hig::HigSystem {}

impl WithDimensions for crate::md3::Md3Scheme {
    /// MD3's shape, spacing, type and motion scales.
    /// MD3 的形状、间距、排版与动效刻度。
    fn dimensions(&self) -> DimensionTokens {
        DimensionTokens {
            radius: data::MD3_RADIUS_SCALE,
            spacing: data::MD3_SPACING_SCALE,
            typography: data::MD3_TYPE_RAMP,
            motion: data::MD3_MOTION,
            hit_target: data::MD3_HIT,
        }
    }
}

impl WithDimensions for crate::fluent::FluentSystem {
    /// Fluent's dimension tokens.
    /// Fluent 的尺寸令牌。
    fn dimensions(&self) -> DimensionTokens {
        DimensionTokens {
            radius: data::FLUENT_RADIUS_SCALE,
            spacing: data::FLUENT_SPACING_SCALE,
            typography: data::FLUENT_TYPE_RAMP,
            motion: data::FLUENT_MOTION,
            hit_target: data::FLUENT_HIT,
        }
    }
}

impl WithDimensions for crate::hig::HigSystem {
    /// HIG's dimension tokens.
    /// HIG 的尺寸令牌。
    fn dimensions(&self) -> DimensionTokens {
        DimensionTokens {
            radius: data::HIG_RADIUS_SCALE,
            spacing: data::HIG_SPACING_SCALE,
            typography: data::HIG_TYPE_RAMP,
            motion: data::HIG_MOTION,
            hit_target: data::HIG_HIT,
        }
    }
}

/// Reach a style's dimension tokens from the style's id and context.
/// 由风格 id 与上下文取该风格的尺寸令牌。
pub fn dimensions_of(id: SystemId, ctx: crate::context::Context) -> DimensionTokens {
    match id {
        // Dimension tokens are context-free today, so any seed produces the same scales.
        // 尺寸令牌目前与上下文无关，任何种子都得到同一套刻度。
        SystemId::Md3 => crate::md3::Md3Scheme::baseline(ctx).dimensions(),
        SystemId::Fluent => crate::fluent::FluentSystem::new(ctx).dimensions(),
        SystemId::Hig => crate::hig::HigSystem::new(ctx).dimensions(),
    }
}

/// What a style can do with dimensions, so a shared widget can degrade well.
/// 一套风格在尺寸上的能力，使共享控件可以优雅降级。
pub fn dimension_caps(system: &dyn crate::system::StyleSystem) -> StyleCaps {
    system.caps()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::context::{Appearance, Platform};
    use crate::dimension::Curvature;

    fn md3() -> crate::md3::Md3Scheme {
        crate::md3::Md3Scheme::baseline(crate::context::Context::new(Appearance::Light, Platform::Android))
    }

    fn fluent() -> crate::fluent::FluentSystem {
        crate::fluent::FluentSystem::new(crate::context::Context::new(Appearance::Light, Platform::Web))
    }

    fn hig() -> crate::hig::HigSystem {
        crate::hig::HigSystem::new(crate::context::Context::new(Appearance::Light, Platform::Ios))
    }

    #[test]
    fn md3_radius_scale_is_the_documented_ten_steps() {
        let d = md3().dimensions();
        assert_eq!(d.radius.steps.len(), 10);
        assert_eq!(d.radius.points("medium"), Some(12.0));
        assert_eq!(d.radius.points("extraExtraLarge"), Some(48.0));
        assert_eq!(d.radius.points("full"), Some(-1.0));
        assert!(d.radius.supports_cut, "MD3 can cut corners");
        assert_eq!(d.radius.source.label(), "spec");
    }

    #[test]
    fn md3_spacing_is_eight_dp_times_the_multiple() {
        let d = md3().dimensions();
        assert_eq!(d.spacing.base_points, 8.0);
        assert_eq!(d.spacing.points("space100"), Some(8.0));
        assert_eq!(d.spacing.points("space400"), Some(32.0));
        assert!(d.spacing.nested.contains(&4.0), "nested values include 4dp");
    }

    #[test]
    fn fluent_radius_and_spacing_come_from_its_token_table() {
        let d = fluent().dimensions();
        assert_eq!(d.radius.points("medium"), Some(4.0));
        assert_eq!(d.radius.points("circular"), Some(-1.0));
        assert_eq!(d.radius.curvature, Curvature::Round);
        assert!(!d.radius.supports_cut);
        assert_eq!(d.spacing.points("l"), Some(16.0));
        assert_eq!(d.radius.source.label(), "spec");
    }

    #[test]
    fn hig_uses_continuous_corners_and_its_published_hit_target() {
        let d = hig().dimensions();
        assert_eq!(d.radius.curvature, Curvature::Continuous);
        assert_eq!(d.radius.source.label(), "convention");
        assert_eq!(d.hit_target.default_points, 44.0);
        assert_eq!(d.hit_target.minimum_points, 28.0);
        assert_eq!(d.hit_target.source.label(), "spec");
    }

    // Typography: only HIG scales with the OS; the other two are fixed ramps.
    // 排版：只有 HIG 随系统缩放；另两套是固定字阶。
    #[test]
    fn only_hig_typography_is_scalable() {
        assert!(hig().dimensions().typography.scalable);
        assert!(!md3().dimensions().typography.scalable);
        assert!(!fluent().dimensions().typography.scalable);
    }

    // Motion provenance differs: MD3/Fluent publish numbers, HIG does not.
    // 动效来源不同：MD3/Fluent 有公开数值，HIG 没有。
    #[test]
    fn motion_provenance_reflects_what_each_system_publishes() {
        assert_eq!(md3().dimensions().motion.source.label(), "spec");
        assert_eq!(fluent().dimensions().motion.source.label(), "spec");
        assert_eq!(hig().dimensions().motion.source.label(), "convention");
    }

    // A style that advertises `cut` must have a curvature that actually reaches the engine's
    // bevel, otherwise the capability flag is a lie the UI shows and never honours.
    // 声明 `cut` 的风格，其曲率必须真的能到引擎的直线切角，否则该能力标志是界面上的空话。
    #[test]
    fn only_md3_advertises_cut_and_its_curvature_really_reaches_the_bevel() {
        use crate::dimension::Curvature;
        use crate::corner::CornerShape;
        for (id, expect_cut) in [(SystemId::Md3, true), (SystemId::Fluent, false), (SystemId::Hig, false)] {
            let ctx = crate::context::Context::new(Appearance::Light, Platform::Ios);
            let d = dimensions_of(id, ctx);
            assert_eq!(d.radius.supports_cut, expect_cut, "{id:?}");
        }
        assert_eq!(Curvature::Cut.corner_shape(), CornerShape::BEVEL);
        // And the engine really computes a straight cut for that shape, not a circle.
        // 且引擎对该形状真的算直线切角，而非圆弧。
        assert_eq!(CornerShape::BEVEL.exponent(), 1.0);
    }

    // Every scale must be internally ordered; a mis-sorted ramp is a silent design bug.
    // 每条刻度必须有序；乱序的字阶是静默的设计缺陷。
    #[test]
    fn every_radius_and_type_ramp_is_sorted() {
        for d in [md3().dimensions(), fluent().dimensions(), hig().dimensions()] {
            let usable: Vec<f32> = d.radius.steps.iter().map(|s| s.points).filter(|p| *p >= 0.0).collect();
            for pair in usable.windows(2) {
                assert!(pair[1] >= pair[0], "radius ramp out of order: {pair:?}");
            }
            // M3's official ramp interleaves by role (title 16 then body 16 then label 14),
            // so adjacency is not the invariant; every step must still be a sane size.
            // M3 官方字阶按角色交错（title 16、body 16、label 14），相邻递减不是不变量；
            // 但每一档都必须是合理字号。
            for step in d.typography.steps {
                assert!(step.size >= 10.0 && step.size <= 64.0, "{} size {}", step.name, step.size);
                assert!(step.line_height >= step.size, "{} line height below size", step.name);
                assert!(step.weight >= 100 && step.weight <= 900, "{} weight", step.name);
            }
        }
    }

    #[test]
    fn the_three_styles_expose_dimensions_through_one_entry_point() {
        let ctx = crate::context::Context::new(Appearance::Light, Platform::Web);
        let md3d = dimensions_of(SystemId::Md3, ctx);
        let fd = dimensions_of(SystemId::Fluent, ctx);
        let hd = dimensions_of(SystemId::Hig, ctx);
        assert_eq!(md3d.radius.steps.len(), 10);
        assert_eq!(fd.radius.points("large"), Some(6.0));
        assert_eq!(hd.typography.steps.len(), 5);
    }

    fn common_systems() -> [Box<dyn crate::system::StyleSystem>; 3] {
        let ctx = crate::context::Context::new(Appearance::Light, Platform::Ios);
        [
            Box::new(crate::md3::Md3Scheme::baseline(ctx)),
            Box::new(crate::fluent::FluentSystem::new(ctx)),
            Box::new(crate::hig::HigSystem::new(ctx)),
        ]
    }

    // The common radius must be the system's own "medium" step, credited to that scale's source.
    // 公共圆角必须取自该体系自己的 medium 档，并记在它那条刻度的来源上。
    #[test]
    fn each_system_answers_the_common_radius_from_its_own_scale() {
        use crate::metric::CommonMetric;
        for system in common_systems() {
            let id = system.id();
            let answer = system
                .common_metric(CommonMetric::Radius)
                .value()
                .unwrap_or_else(|| panic!("{id:?} has no common radius"));
            assert_eq!(Some(answer.value), system.radius().points("medium"), "{id:?}");
            assert_eq!(answer.source, system.radius().source, "{id:?}");
        }
    }

    // A metric only earns its place in the common list when the systems really disagree.
    // 一个度量只有在各体系答案确实不同时，才配进公共清单。
    #[test]
    fn the_common_stroke_width_is_not_one_shared_constant() {
        use crate::metric::CommonMetric;
        use crate::system::StyleSystem;
        let width = |system: &dyn StyleSystem| {
            system
                .common_metric(CommonMetric::StrokeWidth)
                .value()
                .expect("stroke width")
                .value
        };
        let systems = common_systems();
        let (md3, hig) = (&systems[0], &systems[2]);
        assert!(width(hig.as_ref()) < width(md3.as_ref()), "hig hairline should be thinner");
    }
}
