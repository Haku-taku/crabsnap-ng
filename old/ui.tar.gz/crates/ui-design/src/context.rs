//! The context a token resolves under: appearance, contrast, depth and platform.
//! 令牌解析所依据的上下文：外观、对比、深度与平台。
//!
//! The three design systems do not share one theme switch: MD3 has three contrast levels,
//! Fluent has light/dark/high-contrast, HIG also distinguishes base/elevated depth and
//! increased contrast. Modelling the union beats inventing a lowest common denominator.
//! 三套体系不共用一个主题开关：MD3 有三档对比，Fluent 有明/暗/高对比，HIG 还分
//! base/elevated 与 increased contrast。把并集建模，强于造一个最小公约数。

/// Light or dark appearance; every system has this axis.
/// 明或暗外观；每套体系都有这根轴。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Appearance {
    Light,
    Dark,
}

/// How much contrast to demand. Ordering runs from least to most demanding.
/// 要求的对比强度，由弱到强排序。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub enum Contrast {
    /// MD3 low / a deliberately softened scheme.
    /// MD3 低档，刻意柔化的方案。
    Low,
    /// MD3 standard, Fluent default, HIG default.
    /// MD3 标准档、Fluent 默认、HIG 默认。
    Standard,
    /// MD3 medium.
    /// MD3 中档。
    Medium,
    /// MD3 high, Fluent high contrast, HIG increased contrast.
    /// MD3 高档、Fluent 高对比、HIG increased contrast。
    High,
}

impl Contrast {
    /// MD3 writes contrast as a number in -1..=1; this maps it onto the four named levels.
    /// MD3 用 -1..=1 的数字表示对比档；这里映射到四个具名档。
    pub fn from_md3_level(level: f64) -> Self {
        if level <= -0.5 {
            Self::Low
        } else if level < 0.25 {
            Self::Standard
        } else if level < 0.75 {
            Self::Medium
        } else {
            Self::High
        }
    }

    /// The numeric contrast level MD3's resolution expects for this bucket.
    /// 该档对应的 MD3 解析所需数值。
    pub fn md3_level(self) -> f64 {
        match self {
            Self::Low => -1.0,
            Self::Standard => 0.0,
            Self::Medium => 0.5,
            Self::High => 1.0,
        }
    }
}

/// Whether the surface sits at the base layer or is elevated into the foreground.
/// 表面处于底层，还是被抬到前景（HIG 的 sheet/popover/多任务）。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Depth {
    Base,
    Elevated,
}

/// Which platform's conventions and hit-target minima apply.
/// 采用哪个平台的约定与命中区下限。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Platform {
    Ios,
    Ipados,
    Macos,
    Android,
    Web,
    Desktop,
}

/// Text direction; `Trailing` spacing flips with it, which MD3 calls out explicitly.
/// 文字方向；尾随间距随之翻转，MD3 明确要求如此。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum WritingMode {
    LeftToRight,
    RightToLeft,
}

/// The full context a resolution may depend on.
/// 解析可能依赖的完整上下文。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct Context {
    pub appearance: Appearance,
    pub contrast: Contrast,
    pub depth: Depth,
    pub platform: Platform,
    pub writing: WritingMode,
}

impl Context {
    /// The common case: standard contrast on a base layer, left to right.
    /// 常见情形：标准对比、底层、从左到右。
    pub const fn new(appearance: Appearance, platform: Platform) -> Self {
        Self {
            appearance,
            contrast: Contrast::Standard,
            depth: Depth::Base,
            platform,
            writing: WritingMode::LeftToRight,
        }
    }

    pub const fn with_contrast(mut self, contrast: Contrast) -> Self {
        self.contrast = contrast;
        self
    }

    pub const fn with_depth(mut self, depth: Depth) -> Self {
        self.depth = depth;
        self
    }

    pub const fn with_writing(mut self, writing: WritingMode) -> Self {
        self.writing = writing;
        self
    }

    /// Whether this is a dark appearance; most formulas branch on this.
    /// 是否为暗色外观；多数公式以此为分支。
    pub const fn is_dark(self) -> bool {
        matches!(self.appearance, Appearance::Dark)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn contrast_levels_round_trip_through_the_md3_scale() {
        for level in [Contrast::Low, Contrast::Standard, Contrast::Medium, Contrast::High] {
            assert_eq!(Contrast::from_md3_level(level.md3_level()), level);
        }
    }

    #[test]
    fn intermediate_md3_levels_land_in_the_nearer_bucket() {
        assert_eq!(Contrast::from_md3_level(-0.2), Contrast::Standard);
        assert_eq!(Contrast::from_md3_level(0.3), Contrast::Medium);
        assert_eq!(Contrast::from_md3_level(0.9), Contrast::High);
    }

    #[test]
    fn context_defaults_are_standard_contrast_on_the_base_layer() {
        let ctx = Context::new(Appearance::Dark, Platform::Web);
        assert_eq!(ctx.contrast, Contrast::Standard);
        assert_eq!(ctx.depth, Depth::Base);
        assert!(ctx.is_dark());
    }
}
