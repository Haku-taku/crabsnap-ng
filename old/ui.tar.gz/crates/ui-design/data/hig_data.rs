// Generated from docs/reference/hig-tokens.json. Do not edit by hand.
// 由 docs/reference/hig-tokens.json 生成，请勿手改。

pub const CONTEXT_COUNT: usize = 4;

/// System colours: (name, [light, dark, light-increased-contrast, dark-increased-contrast]).
/// 系统色：（名称，[明, 暗, 明-增强对比, 暗-增强对比]）。
pub const SYSTEM_COLORS: &[(&str, [u32; CONTEXT_COUNT])] = &[
    ("systemBlue", [0xff0088ff, 0xff0091ff, 0xff1e6ef4, 0xff5cb8ff]),
    ("systemBrown", [0xffac7f5e, 0xffb78a66, 0xff956d51, 0xffdba679]),
    ("systemCyan", [0xff00c0e8, 0xff3cd3fe, 0xff007eae, 0xff6dd9ff]),
    ("systemGray", [0xff8e8e93, 0xff8e8e93, 0xff6c6c70, 0xffaeaeb2]),
    ("systemGreen", [0xff34c759, 0xff30d158, 0xff008932, 0xff4ad968]),
    ("systemIndigo", [0xff6155f5, 0xff6d7cff, 0xff564ade, 0xffa7aaff]),
    ("systemMint", [0xff00c8b3, 0xff00dac3, 0xff008575, 0xff54dfcb]),
    ("systemOrange", [0xffff8d28, 0xffff9230, 0xffc55300, 0xffffa056]),
    ("systemPink", [0xffff2d55, 0xffff375f, 0xffe7124d, 0xffff8ac4]),
    ("systemPurple", [0xffcb30e0, 0xffdb34f2, 0xffb02fc2, 0xffea8dff]),
    ("systemRed", [0xffff383c, 0xffff4245, 0xffe9152d, 0xffff6165]),
    ("systemTeal", [0xff00c3d0, 0xff00d2e0, 0xff008198, 0xff3bddec]),
    ("systemYellow", [0xffffcc00, 0xffffd600, 0xffa16a00, 0xfffedf43]),
];

/// The iOS grey ramp beyond `systemGray`.
/// `systemGray` 之外的 iOS 灰色阶。
pub const GRAY_RAMP: &[(&str, [u32; CONTEXT_COUNT])] = &[
    ("systemGray2", [0xffaeaeb2, 0xff636366, 0xff8e8e93, 0xff7c7c80]),
    ("systemGray3", [0xffc7c7cc, 0xff48484a, 0xffaeaeb2, 0xff545456]),
    ("systemGray4", [0xffd1d1d6, 0xff3a3a3c, 0xffbcbcc0, 0xff444446]),
    ("systemGray5", [0xffe5e5ea, 0xff2c2c2e, 0xffd8d8dc, 0xff363638]),
    ("systemGray6", [0xfff2f2f7, 0xff1c1c1e, 0xffebebf0, 0xff242426]),
];

/// Hit-target minimums in points, per platform: (platform, default, minimum).
/// 各平台命中区下限，单位为 pt：（平台，默认，下限）。
pub const HIT_TARGETS: &[(&str, f32, f32)] = &[
    ("ios_ipados", 44.0f32, 28.0f32),
    ("macos", 28.0f32, 20.0f32),
    ("tvos", 66.0f32, 56.0f32),
    ("visionos", 60.0f32, 28.0f32),
    ("watchos", 44.0f32, 28.0f32),
];

/// Content materials, thinnest to thickest.
/// 内容材质，由薄到厚。
pub const MATERIALS: &[&str] = &[
    "ultraThinMaterial",
    "thinMaterial",
    "regularMaterial",
    "thickMaterial",
    "ultraThickMaterial",
    "bar",
];

/// Apple semantic colour role names; the values are resolved by the OS.
/// Apple 语义颜色角色名；值由 OS 解析。
pub const SEMANTIC_ROLES: &[&str] = &[
    "label",
    "secondaryLabel",
    "tertiaryLabel",
    "quaternaryLabel",
    "systemBackground",
    "secondarySystemBackground",
    "tertiarySystemBackground",
    "systemGroupedBackground",
    "separator",
    "opaqueSeparator",
    "tintColor",
];

/// Disabled-state colours from Apple's dynamic palette as published by Flutter Cupertino.
/// 禁用态颜色，取自 Flutter Cupertino 公布的 Apple 动态调色板。
pub const DISABLED_COLORS: &[(&str, [u32; CONTEXT_COUNT])] = &[
    ("inactiveGray", [0xff999999, 0xff757575, 0xff999999, 0xff757575]),
    ("tertiarySystemFill", [0x1e76_7680, 0x3d76_7680, 0x3376_7680, 0x5176_7680]),
    ("quaternarySystemFill", [0x1474_7480, 0x2d76_7680, 0x2874_7480, 0x4276_7680]),
];

/// System fill colours from the same dynamic palette; they differ light vs dark.
/// 同一动态调色板里的系统填充色；明暗不同。
pub const FILL_COLORS: &[(&str, [u32; CONTEXT_COUNT])] = &[
    ("systemFill", [0x3378_7880, 0x5b78_7880, 0x4778_7880, 0x7078_7880]),
    ("secondarySystemFill", [0x2878_7880, 0x5178_7880, 0x3d78_7880, 0x6678_7880]),
];
