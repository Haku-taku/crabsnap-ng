"""Generate hig_data.rs from docs/reference/hig-tokens.json (data only)."""
import json, pathlib, re

ROOT = pathlib.Path('/home/ollie/git/crabsnap-ng')
d = json.loads((ROOT / 'docs/reference/hig-tokens.json').read_text())
sc = d['color']['systemColors']
gr = d['color']['grayRamp']

# Column order matches `hig::theme_column`: [light, dark, light-IC, dark-IC].
COLS = ['light', 'dark', 'light_increased_contrast', 'dark_increased_contrast']


def hexargb(v):
    v = v.lstrip('#')
    if len(v) == 6:
        return int('ff' + v, 16)
    raise SystemExit('unexpected hex ' + v)


out = []
w = out.append
w('// Generated from docs/reference/hig-tokens.json. Do not edit by hand.')
w('// 由 docs/reference/hig-tokens.json 生成，请勿手改。')
w('')
w('pub const CONTEXT_COUNT: usize = 4;')
w('')
w('/// System colours: (name, [light, dark, light-increased-contrast, dark-increased-contrast]).')
w('/// 系统色：（名称，[明, 暗, 明-增强对比, 暗-增强对比]）。')
w('pub const SYSTEM_COLORS: &[(&str, [u32; CONTEXT_COUNT])] = &[')
for name in sorted(sc):
    vals = [hexargb(sc[name][c]) for c in COLS]
    w('    ("{}", [{}]),'.format(name, ', '.join('0x{:08x}'.format(v) for v in vals)))
w('];')
w('')
w('/// The iOS grey ramp beyond `systemGray`.')
w('/// `systemGray` 之外的 iOS 灰色阶。')
w('pub const GRAY_RAMP: &[(&str, [u32; CONTEXT_COUNT])] = &[')
for name in sorted(gr):
    vals = [hexargb(gr[name][c]) for c in COLS]
    w('    ("{}", [{}]),'.format(name, ', '.join('0x{:08x}'.format(v) for v in vals)))
w('];')
w('')
w('/// Hit-target minimums in points, per platform: (platform, default, minimum).')
w('/// 各平台命中区下限，单位为 pt：（平台，默认，下限）。')
w('pub const HIT_TARGETS: &[(&str, f32, f32)] = &[')
for plat, spec in sorted(d['layout']['hitTarget'].items()):
    # Only the per-platform entries have default/minimum; the rest are notes.
    # 只有分平台条目有 default/minimum，其余是说明性字段。
    if not isinstance(spec, dict) or 'default' not in spec:
        continue
    default = float(spec['default'].split('x')[0])
    minimum = float(spec['minimum'].split('x')[0])
    w('    ("{}", {}f32, {}f32),'.format(plat, default, minimum))
w('];')
w('')
w('/// Content materials, thinnest to thickest.')
w('/// 内容材质，由薄到厚。')
w('pub const MATERIALS: &[&str] = &[')
for m in d['materials']['systemMaterials']:
    w('    "{}",'.format(m.lstrip('.')))
w('];')

w('')
w('/// Apple semantic colour role names; the values are resolved by the OS.')
w('/// Apple 语义颜色角色名；值由 OS 解析。')
w('pub const SEMANTIC_ROLES: &[&str] = &[')
for name in d['color']['semanticRoles']:
    w('    "{}",'.format(name))
w('];')

path = pathlib.Path(__file__).with_name('hig_data.rs')
path.write_text('\n'.join(out) + '\n')
print('system colours:', len(sc), '| grey ramp:', len(gr),
      '| hit targets:', len(d['layout']['hitTarget']), '| materials:', len(out))
