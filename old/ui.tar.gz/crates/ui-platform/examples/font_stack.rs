//! Show the font stack resolving real text, with and without system fonts.
//! 展示字体栈如何解析真实文本，含有无系统字体两种情况。

use ui_core::geom::Size;
use ui_core::{Constraints, Decl, Id, LayoutEngine, NodeData, NodeKind, Tree, BuiltinLayout};
use ui_core::geom::Insets;
use ui_core::layout::{AxisSize, SizeClass};
use ui_text::{FontStack, GenericFamily, FontRequest, Script, StackMeasure, StaticProvider};

fn main() {
    // 1. A deterministic provider: proves the abstraction works with no system fonts.
    // 1. 确定性提供者：证明抽象在没有系统字体时也成立。
    let static_provider = StaticProvider::new("static")
        .with_partial_face("Latin Only", 0.55, &['a', 'b', 'c', 'H', 'e', 'l', 'o', ' ', 'w', 'r', 'd'])
        .with_partial_face("CJK Only", 0.95, &['中', '文', '字', '体', ' ', '测', '试']);
    let mut stack = FontStack::new(static_provider);

    println!("== provider: {} ==", stack.provider_name());
    for text in ["Hello world", "中文字体", "Hello 中文"] {
        let r = stack.resolve_for_text(text, 14.0);
        println!(
            "  {text:14} face={} width={:6.1} steps={} outcome={:?}",
            r.face.0, r.width, r.fallback_steps, r.outcome
        );
    }
    println!(
        "  stats: resolves={} fallbacks={} rejected={} unresolved={}",
        stack.stats.resolves, stack.stats.fallbacks, stack.stats.rejected, stack.stats.unresolved
    );

    // 2. Drive layout through the stack: text height now comes from real metrics.
    // 2. 让布局走字体栈：文字高度现在来自真实度量。
    let mut tree = Tree::new();
    tree.apply(
        &Decl::container(Id::str("root"), NodeKind::Column)
            .padding(Insets::all(8.0))
            .gap(4.0)
            .child(Decl {
                id: Id::str("label"),
                kind: NodeKind::Text,
                shapes: Vec::new(),
                data: NodeData::Text {
                    ink: ui_core::geom::Color::WHITE,
                    block: ui_core::TextBlock {
                        runs: vec![ui_core::TextRun::new(
                            "Hello 中文 world",
                            ui_core::TextStyle::new(14.0),
                        )],
                        align: ui_core::TextAlign::Start,
                        max_lines: None,
                        line_gap: 0.0,
                        indent: 0.0,
                        atoms: Vec::new(),
                    },
                    caret: None,
                    selection: None,
                    composing: None,
                    nowrap: false,
                },
                size_class: SizeClass {
                    width: AxisSize::hug(0.0, 0.0),
                    height: AxisSize::hug(0.0, 0.0),
                    grow_x: ui_core::layout::Grow::No,
                    grow_y: ui_core::layout::Grow::No,
                },
                ink_margin: Insets::ZERO,
                box_model: Default::default(),
                offset: ui_core::geom::Point::new(0.0, 0.0),
                cursor: None,
            sense: ui_core::Sense::NONE,
            disabled: false,
            grid: Default::default(),
            placement: Default::default(),
            env: None,
                children: Vec::new(),
            }),
    );
    let mut engine = BuiltinLayout::new(StackMeasure::new(stack));
    let root = tree.root().unwrap();
    engine.solve(&mut tree, root, Constraints::loose(Size::new(400.0, 200.0)));
    let label = tree.get(tree.find_by_id(Id::str("label")).unwrap()).unwrap();
    println!("\n== layout through the font stack ==");
    println!("  label rect: {:?}", label.rect);

    // 3. Query a named family, showing the request shape.
    // 3. 查询具名族，展示请求的形状。
    let req = FontRequest::new(GenericFamily::Monospace)
        .family("Latin Only")
        .script(Script::HAN);
    println!("\n  explicit request -> {req:?}");
}
