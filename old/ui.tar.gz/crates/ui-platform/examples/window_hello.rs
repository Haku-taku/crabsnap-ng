//! Minimal end-to-end run: declaration -> layout -> paint -> pixels.
//! 最小端到端运行：声明 -> 布局 -> 绘制 -> 像素。
//!
//! Validates the window/surface + CPU + UI framework combination without a
//! compositor: it writes a PPM and prints per-frame diagnostics.
//! 在没有 compositor 的情况下验证 window/surface + CPU + UI 框架的组合：
//! 写出 PPM 并打印每帧诊断信息。

use std::io::Write;

use ui_core::geom::{Color, Corners, Insets, Point, Rect, Size};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::{BuiltinLayout, Constraints, Decl, Id, LayoutEngine, NodeData, NodeKind};
use ui_paint::{CoverageAtlas, CpuRenderer};
use ui_platform::present::{OffscreenTarget, PresentTarget};
use ui_platform::{App, FrameInfo};

const W: u32 = 320;
const H: u32 = 180;

struct Hello {
    pointer: Option<Point>,
}

fn rounded(id: Id, color: Color, radius: f32) -> Decl {
    Decl {
        id,
        kind: NodeKind::Box,
        data: NodeData::Container(ui_core::tree::ContainerParams::default()),
        shapes: vec![ui_core::draw::Shape::Box {
            corners: Corners::all(radius),
            fill: color,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }],
        size_class: SizeClass::fixed(0.0, 0.0),
        ink_margin: Insets::ZERO,
        box_model: Default::default(),
        offset: ui_core::geom::Point::new(0.0, 0.0),
        cursor: None,
            sense: ui_core::Sense::NONE,
            disabled: false,
            grid: Default::default(),
            placement: Default::default(),
            env: None,
        children: Vec::new(),
    }
}

impl App for Hello {
    fn view(&mut self, frame: &mut ui_core::cx::Cx<'_>) -> Box<dyn ui_platform::Element> {
        let decl = {
        // A card that grows to fill, with a title and three swatches in a row.
        // 一张撑满的卡片，含标题与一行三个色块。
        let hover = self.pointer.is_some();
        let card_bg = if hover {
            Color::from_rgba8(52, 56, 64, 255)
        } else {
            Color::from_rgba8(44, 47, 54, 255)
        };

        let swatch = |name: &'static str, c: Color| -> Decl {
            let mut d = rounded(Id::str(name), c, 4.0);
            d.size_class = SizeClass {
                width: AxisSize::fill(0.0, 28.0),
                height: AxisSize::fixed(28.0),
                grow_x: Grow::Yes,
                grow_y: Grow::No,
            };
            d
        };

        let title = Decl {
            id: Id::str("title"),
            kind: NodeKind::Text,
            shapes: Vec::new(),
            data: NodeData::Text {
                ink: ui_core::geom::Color::WHITE,
                block: ui_core::TextBlock {
                    runs: vec![ui_core::TextRun::new(
                        format!("crabsnap ui  frame {}", frame.frame()),
                        ui_core::TextStyle::new(13.0),
                    )],
                    align: ui_core::TextAlign::Start,
                    max_lines: None,
                    line_gap: 0.0,
                    indent: 0.0,
                    atoms: Vec::new(),
                },
                caret: None,
                selection: None,
                composing: None,
                nowrap: false,
            },
            size_class: SizeClass {
                width: AxisSize::fill(0.0, 200.0),
                height: AxisSize::hug(16.0, 17.0),
                grow_x: Grow::No,
                grow_y: Grow::No,
            },
            ink_margin: Insets::ZERO,
            box_model: Default::default(),
            offset: ui_core::geom::Point::new(0.0, 0.0),
            cursor: None,
            sense: ui_core::Sense::NONE,
            disabled: false,
            grid: Default::default(),
            placement: Default::default(),
            env: None,
            children: Vec::new(),
        };

        let card = Decl::container(Id::str("card"), NodeKind::Column)
            .padding(Insets::all(14.0))
            .gap(10.0)
            .background(card_bg, Corners::all(10.0))
            .border(Color::from_rgba8(90, 96, 108, 255), 1.0)
            .child(title)
            .child(
                Decl::container(Id::str("swatches"), NodeKind::Row)
                    .gap(8.0)
                    .child(swatch("red", Color::from_rgba8(214, 72, 72, 255)))
                    .child(swatch("green", Color::from_rgba8(72, 178, 112, 255)))
                    .child(swatch("blue", Color::from_rgba8(74, 130, 214, 255))),
            );

        Decl::container(Id::str("root"), NodeKind::Column)
            .padding(Insets::all(16.0))
            .child(card)
    };
    ui_platform::from_decl(decl)
}
}

mod textmetrics {
    /// Fallback metrics when no font is available.
    /// 无字体时可用的回退度量。
    pub struct FallbackMetrics {
        pub ascent: f32,
        /// Kept for parity with real font metrics; unused while the fallback is active.
        /// 与真实字体度量保持同构；回退生效时未使用。
        #[allow(dead_code)]
        pub descent: f32,
        #[allow(dead_code)]
        pub line_gap: f32,
    }
    pub const FALLBACK: FallbackMetrics = FallbackMetrics {
        ascent: 0.8,
        descent: -0.2,
        line_gap: 0.0,
    };
    impl FallbackMetrics {
        pub fn ascent(&self) -> f32 {
            self.ascent
        }
    }
}

/// Install a real system font into the glyph cache when the feature is on.
/// 特性开启时把真实系统字体装进字形缓存。
mod font_provider {
    use ui_text::FaceId;
    use ui_text_fontique::glyph::GlyphCache;

    #[cfg(feature = "system-fonts")]
    pub fn install(cache: &mut GlyphCache, face: FaceId) -> bool {
        use ui_text::{FontProvider, FontRequest, GenericFamily};
        use ui_text_fontique::system_or_isolated;
        let provider = system_or_isolated();
        let Some(resolved) = provider.resolve(&FontRequest::new(GenericFamily::SansSerif)) else {
            return false;
        };
        let Some(data) = provider.face_data(resolved) else {
            return false;
        };
        cache.add_face(face, data)
    }

    #[cfg(not(feature = "system-fonts"))]
    pub fn install(_cache: &mut GlyphCache, _face: FaceId) -> bool {
        false
    }
}

fn write_ppm(path: &str, pixels: &ui_paint::Pixels) -> std::io::Result<()> {
    let mut f = std::fs::File::create(path)?;
    write!(f, "P6\n{} {}\n255\n", pixels.width, pixels.height)?;
    // PPM is RGB; our buffer is premultiplied BGRA.
    // PPM 是 RGB；我们的缓冲是预乘 BGRA。
    let mut rgb = Vec::with_capacity((pixels.width * pixels.height * 3) as usize);
    for px in pixels.as_bytes().as_chunks::<4>().0 {
        rgb.push(px[2]);
        rgb.push(px[1]);
        rgb.push(px[0]);
    }
    f.write_all(&rgb)
}

fn main() {
    let mut app = Hello { pointer: None };
    let mut tree = ui_core::Tree::new();
    let mut engine = BuiltinLayout::new(ui_core::MonospaceMeasure::default());
    let mut renderer = CpuRenderer::new();
    let mut target = OffscreenTarget::new(W, H);

    // Optional real font: absent when built without the system feature.
    // 可选的真实字体：未开启系统字体特性时为空。
    let face = ui_text::FaceId(0);
    let mut cache = ui_text_fontique::glyph::GlyphCache::new(512, 512);
    let have_font = font_provider::install(&mut cache, face);
    let mut font = have_font.then_some((face, cache, ()));

    let frames = [
        None,
        Some(Point::new(60.0, 80.0)),
        Some(Point::new(60.0, 80.0)),
    ];

    let mut store = ui_core::AnimStore::new();
    for (i, pointer) in frames.iter().enumerate() {
        let info = FrameInfo::new(W, H, *pointer, i as u64);
        app.pointer = *pointer;
        // Same shape the engine uses: one context per frame, owning the store.
        // 与引擎同形：每帧一个上下文，由它拥有存储。
        let mut cx = ui_core::cx::Cx::new(
            &mut store,
            info.frame,
            info.width,
            info.height,
            info.now,
            info.dt,
            1.0,
            info.pointer,
        );
        let root_element = app.view(&mut cx);
        let decl = ui_platform::Element::decl(&*root_element, &mut cx);
        let stats = tree.apply(&decl);

        let root = tree.root().expect("root");
        engine.solve(
            &mut tree,
            root,
            Constraints::loose(Size::new(W as f32, H as f32)),
        );

        // Rects come from the shared builder's rule (visual_rect); text is emitted here
        // because this example draws real glyphs when a font is available.
        // 矩形沿用共享构建器的规则（visual_rect）；文本在此单独发射，因为本示例在有字体时
        // 画真实字形。
        let mut list = ui_core::draw::DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
        for nid in tree.walk() {
            let Some(node) = tree.get(nid) else { continue };
            ui_core::draw::push_shapes(&mut list, nid, node, node.visual_rect(), |_, _| None);
            {
                let (block, node_ink) = match &node.data {
                    NodeData::Text { block, ink, .. } => (block, *ink),
                    _ => continue,
                };
                {
                    let (flat, _) = block.flatten();
                    let text = &flat;
                    let style = block.runs.first().map_or_else(Default::default, |r| r.style);
                    let (size, color) = (&style.size, &node_ink);
                    // Real glyphs when a font is available; the bar otherwise.
                    // 有字体时用真实字形，否则退回条块。
                    if let Some((_face, ref mut cache, _m)) = font {
                        let ascent = cache
                            .face_metrics(face)
                            .map(|m| m.ascent)
                            .unwrap_or(textmetrics::FALLBACK.ascent());
                        let baseline = node.rect.origin.y + ascent * *size;
                        let mut pen_x = node.rect.origin.x;
                        for c in text.chars() {
                            let Some(gid) = cache.glyph_id(face, c) else { continue };
                            let adv = cache.advance_px(face, gid, *size).unwrap_or(size * 0.6);
                            if let Some((slot, _)) = cache.glyph(face, c, *size) {
                                list.push_glyph(
                                    nid,
                                    ui_core::draw::GlyphPrim {
                                        rect: Rect::new(
                                            pen_x + slot.left as f32,
                                            baseline - slot.top as f32,
                                            slot.width as f32,
                                            slot.height as f32,
                                        ),
                                        atlas: Rect::new(
                                            slot.x as f32,
                                            slot.y as f32,
                                            slot.width as f32,
                                            slot.height as f32,
                                        ),
                                        alpha: 1.0,
                                        color: *color,
                                        kind: ui_core::draw::GlyphKind::Coverage,
                                    },
                                );
                            }
                            pen_x += adv;
                        }
                    } else {
                        list.push_text(
                            nid,
                            ui_core::draw::TextPrim {
                                block: block.clone(),
                                origin: node.visual_rect().origin,
                                max_width: node.rect.size.w,
                                layout: node.inline.clone(),
                                height: 0.0,
                                ink: node_ink,
                                caret: None,
                                selection: None,
                                composing: None,
                                zoom: None,
                            },
                        );
                    }
                }
            }
        }

        // This example repaints in full every frame; only the gallery tracks damage.
        // 本示例每帧整面重画；只有 gallery 跟踪脏区。
        let damage = ui_core::Damage::Full;
        if let Some((_, cache, _)) = font.as_mut() {
            let (aw, ah) = cache.dimensions();
            renderer.set_atlas(CoverageAtlas {
                width: aw,
                height: ah,
                data: cache.atlas().to_vec(),
            });
        }
        let px = target.pixels_mut();
        renderer.render(&list, px, &damage);

        println!(
            "frame {i}: nodes={} batches={} rects={} texts={} created={} reused={}",
            tree.len(),
            renderer.stats.batches,
            renderer.stats.rects,
            renderer.stats.texts,
            stats.created,
            stats.reused,
        );
        let _ = target.present(&damage);
        let _ = target.size();
    }

    let path = "window_hello.ppm";
    match write_ppm(path, &target.pixels) {
        Ok(()) => println!("wrote {path} ({}x{})", W, H),
        Err(e) => eprintln!("could not write {path}: {e}"),
    }
}
