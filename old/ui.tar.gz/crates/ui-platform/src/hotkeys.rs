//! System-wide hotkeys: the interface every desktop backend implements.
//! 系统级热键：每个桌面后端都要实现的接口。

use ui_core::shortcut::{KeyChord, ShortcutId};

/// Why a global hotkey could not be bound.
/// 全局热键绑定失败的原因。
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum GlobalHotkeyError {
    /// This backend has no system-wide hotkeys at all (X11, headless, a bare compositor).
    /// 该后端根本没有系统级热键（X11、无头、纯 compositor）。
    Unsupported,
    /// The desktop asked the user and the user said no, or the desktop closed the request.
    /// 桌面询问了用户而用户拒绝，或桌面关闭了请求。
    Refused,
    /// Another application already owns the chord.
    /// 别的应用已经占用了这个组合键。
    Taken,
    /// The backend failed for its own reason, with the text it gave.
    /// 后端因其自身原因失败，附它给出的说明。
    Failed(String),
}

/// What an app needs from the desktop, and nothing about how the desktop does it.
/// 应用需要桌面提供的功能，而不涉及桌面如何实现。
///
/// Wayland has no protocol for this: the portal is the portable path and a compositor's
/// private IPC is the fallback; Windows and macOS each have their own registry.
/// Wayland 没有这样的协议：portal 是可移植的路径，compositor 的私有 IPC 是退路；
/// Windows 与 macOS 各有自己的注册表。
pub trait GlobalHotkeys {
    /// Ask the desktop for `chord`; a press is later reported by [`Self::poll`].
    /// 向桌面申请 `chord`；之后由 [`Self::poll`] 上报按键。
    ///
    /// The desktop may prompt the user: on Wayland the portal owns the binding UI.
    /// 桌面可能会询问用户：在 Wayland 上绑定界面归 portal 所有。
    fn register(&mut self, chord: KeyChord, id: ShortcutId) -> Result<(), GlobalHotkeyError>;

    /// Give the chord back.
    /// 归还这个组合键。
    fn unregister(&mut self, id: ShortcutId);

    /// Hotkeys pressed since the last call, in order.
    /// 自上次调用以来按下的热键，按顺序。
    ///
    /// Never blocks: the host calls it once per frame, beside its other event sources.
    /// 绝不阻塞：宿主每帧调用一次，与其它事件源并列。
    fn poll(&mut self) -> Vec<ShortcutId>;
}

/// A backend with no system-wide hotkeys; every desktop without support uses it.
/// 没有系统级热键的后端；任何不支持的桌面都用它。
#[derive(Default)]
pub struct NoGlobalHotkeys;

impl GlobalHotkeys for NoGlobalHotkeys {
    fn register(&mut self, _chord: KeyChord, _id: ShortcutId) -> Result<(), GlobalHotkeyError> {
        Err(GlobalHotkeyError::Unsupported)
    }

    fn unregister(&mut self, _id: ShortcutId) {}

    fn poll(&mut self) -> Vec<ShortcutId> {
        Vec::new()
    }
}
