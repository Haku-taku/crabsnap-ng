//! Host light/dark preference and the mechanism that keeps it in sync.
//! 宿主明/暗偏好，以及让它保持同步的机制。
//!
//! Portable interface only: a platform crate supplies a concrete watcher (e.g. the XDG
//! portal on Wayland). The app reads `preference()` and drains `poll()` each frame.
//! 只有可移植接口：具体监视器由平台 crate 提供（如 Wayland 的 XDG portal）。app 读
//! `preference()` 并每帧排空 `poll()`。

/// The host's stated colour-scheme preference; `NoPreference` means "decide yourself".
/// 宿主声明的配色偏好；`NoPreference` 表示「你自行决定」。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum ThemePreference {
    /// No stated preference; the app falls back to its own default.
    /// 未声明偏好；app 用自身默认值。
    #[default]
    NoPreference,
    /// The host prefers a dark scheme.
    /// 宿主偏好深色。
    PreferDark,
    /// The host prefers a light scheme.
    /// 宿主偏好浅色。
    PreferLight,
}

impl ThemePreference {
    /// Whether this preference means dark, given a fallback for `NoPreference`.
    /// 在 `NoPreference` 用 `fallback_dark` 兜底时，本偏好是否代表深色。
    pub fn is_dark(self, fallback_dark: bool) -> bool {
        match self {
            Self::PreferDark => true,
            Self::PreferLight => false,
            Self::NoPreference => fallback_dark,
        }
    }
}

/// A source of the host's colour-scheme preference that can report changes.
/// 能报告变化的宿主配色偏好来源。
pub trait ThemeWatcher {
    /// The most recently known preference.
    /// 最近已知的偏好。
    fn preference(&self) -> ThemePreference;

    /// The new preference if it changed since the last call, else `None`.
    /// 自上次调用以来若有变化则返回新偏好，否则 `None`。
    fn poll(&mut self) -> Option<ThemePreference>;
}

/// A watcher that never changes; the sensible default where no host signal exists.
/// 永不变化的监视器；在没有宿主信号时是合理的默认。
#[derive(Clone, Copy, Debug, Default)]
pub struct FixedTheme {
    pub preference: ThemePreference,
}

impl ThemeWatcher for FixedTheme {
    fn preference(&self) -> ThemePreference {
        self.preference
    }
    fn poll(&mut self) -> Option<ThemePreference> {
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn no_preference_falls_back_but_explicit_ones_do_not() {
        assert!(ThemePreference::PreferDark.is_dark(false));
        assert!(!ThemePreference::PreferLight.is_dark(true));
        assert!(ThemePreference::NoPreference.is_dark(true));
        assert!(!ThemePreference::NoPreference.is_dark(false));
    }

    #[test]
    fn a_fixed_watcher_never_reports_a_change() {
        let mut w = FixedTheme { preference: ThemePreference::PreferDark };
        assert_eq!(w.preference(), ThemePreference::PreferDark);
        assert_eq!(w.poll(), None);
    }
}
