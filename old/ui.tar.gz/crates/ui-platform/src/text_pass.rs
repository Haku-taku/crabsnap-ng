//! Turns `Text` primitives into positioned `Glyph` primitives plus an atlas.
//! 把 `Text` 图元变成已定位的 `Glyph` 图元并配套一张图集。
//!
//! Both backends must see the same glyph stream: the CPU renderer takes coverage
//! from the atlas, the GPU renderer uploads it as a texture.
//! 两个后端必须看到同一条字形流：CPU 从图集取覆盖率，GPU 把图集传成纹理。

use ui_core::collections::{FastHasher, FastMap, FastSet};
use std::sync::Arc;

use ui_core::draw::{DrawList, GlyphPrim, Op, PrimKind, RectPrim, TextPrim};
use ui_core::{Family, TextStyle};
use ui_text::{FaceId, FontProvider, FontRequest, GenericFamily, Script};
use ui_text_fontique::{place_run_scaled, FontiqueProvider, GlyphCache, ShapedRun, Shaper};

/// Initial atlas dimensions; `GlyphCache` grows it as needed.
/// 初始图集尺寸；`GlyphCache` 会按需扩容。
const ATLAS_W: u32 = 1024;
const ATLAS_H: u32 = 1024;

/// Cap on cached measurements: a page never needs more, and dynamic text must not grow it.
/// 已测尺寸缓存的上限：一页用不到这么多，动态文字也不至于把它撑爆。
const MEASURE_CACHE_MAX: usize = 16_384;

/// Cap on cached shaped spans: one per styled run on screen, and a page has far fewer.
/// 已整形片段缓存的上限：屏幕上每个带样式的 run 一个，一页远用不到这么多。
const SHAPE_CACHE_MAX: usize = 4_096;

/// Cap on cached resolved primitives: one per text on screen, and a page has far fewer.
/// 已解析图元缓存的上限：屏幕上每段文字一个，一页远用不到这么多。
const RESOLVE_CACHE_MAX: usize = 4_096;

/// One shaped piece of a span: the face that shaped it, the run, its byte range and script.
/// 片段里的一段已整形内容：整形它的字面、run、字节范围与脚本。
type ShapedPiece = (FaceId, ShapedRun, usize, usize, Script);

/// A text primitive's resolved primitives, reusable while nothing that shapes it changed.
/// 一个文本图元的解析结果，在影响整形的输入未变时可复用。
struct CachedText {
    /// The primitive this was resolved from, compared exactly on every look-up.
    /// 解析所用的图元，每次查找都与它精确比较。
    prim: TextPrim,
    /// Atlas contents when it was resolved; the slot rects below only hold for that stamp.
    /// 解析时的图集内容；下面的槽位矩形只对这一版有效。
    stamp: (u64, u64, u64),
    rects: Vec<RectPrim>,
    glyphs: Vec<GlyphPrim>,
    caret: Option<RectPrim>,
}

/// MD3's caret: two logical units wide, centred on the insertion point.
/// MD3 的插入符：两个逻辑单位宽，以插入点为中心。
const CARET_WIDTH: f32 = 2.0;

/// Underline thickness for an input method's composing run, in logical units.
/// 输入法组合区间的下划线粗细，逻辑单位。
const COMPOSING_UNDERLINE: f32 = 1.0;

/// Opacity and corner radius of the block standing in for an atom (P4b placeholder).
/// 原子占位块的透明度与圆角半径（P4b 占位）。
const ATOM_ALPHA: f32 = 0.25;
const ATOM_RADIUS: f32 = 4.0;

pub struct TextPass {
    provider: FontiqueProvider,
    cache: GlyphCache,
    /// Faces in preference order: the explicit stack first, then the platform generic.
    /// 按偏好排序的字面：先是显式字体栈，然后是平台通用族。
    stack: Vec<FaceId>,
    /// Installed emoji faces, tried after the script fallback: no text face covers
    /// U+1F600, and the Latin fallback chain does not list them.
    /// 已安装的 emoji 字面，在脚本回退之后尝试：没有文字字面覆盖 U+1F600，
    /// 而拉丁回退链并不列出它们。
    emoji: Vec<FaceId>,
    /// Family names the pass was built with, kept so a styled run can re-resolve them.
    /// 构建时给出的族名，使带样式的 run 能重新解析它们。
    families: Vec<String>,
    /// Resolved stacks per (family, weight, italic): resolving walks the collection, and
    /// doing it per run per frame would repeat that walk needlessly.
    /// 按（族，字重，斜体）缓存已解析的栈：解析要遍历字体集合，
    /// 每个 run 每帧都走一遍是白费。
    styled: FastMap<(Family, u16, bool), Vec<FaceId>>,
    /// One shaper per face, because a run must be shaped by the face that covers it.
    /// 每个字面一个 shaper：一段文字必须由覆盖它的字面来整形。
    shapers: FastMap<FaceId, Shaper>,
    /// Script to the face found to cover it, within one family.
    /// 脚本到"覆盖该脚本的字面"的映射，限定在一个族内。
    /// Best face per (family, script, weight, italic): keying on the script alone let a bold
    /// run reuse a regular face, and let an icon face answer for unrelated Latin text.
    /// 每个（族，脚本，字重，斜体）的最佳字面：只按脚本做键会让粗体 run 复用常规字面，
    /// 也会让图标字面替无关的拉丁文本作答。
    script_face: FastMap<(Family, Script, u16, bool), FaceId>,
    /// Atlas generation: `(rasterized, grows)` when the atlas last changed.
    /// 图集代数：上次变化时的 `(rasterized, grows)`。
    atlas_mark: (u64, u64),
    version: u64,
    /// Text primitives this pass could not resolve, reported instead of dropped.
    /// 本趟未能解析的文本图元，会统计而非丢弃。
    unresolved: usize,
    /// Wrapped blocks, keyed by a hash of the block, the wrap width and the font set.
    /// 已换行的块，键为块内容、换行宽度与字体集合的哈希。
    measured: FastMap<u64, std::rc::Rc<ui_core::InlineLayout>>,
    /// Min-content widths, keyed like `measured` but without a width of their own.
    /// 最小内容宽度，键与 `measured` 相同，但没有自己的宽度。
    min_widths: FastMap<u64, f32>,
    /// Slice widths, keyed like `shaped_spans`: a page's labels repeat, and every line
    /// breaks over the same words several times before it settles.
    /// 片段宽度，键同 `shaped_spans`：一个页面的标签会重复，而每行在定稿前会多次按同一批词断行。
    slice_widths: FastMap<u64, f32>,
    /// Font files already admitted, by data pointer and face index.
    /// 已接纳的字体文件，按数据指针与字面序号记。
    font_files: FastSet<(usize, u32)>,
    /// Shaped spans, keyed by a hash of the text, the style and the font set: shaping is the
    /// costliest step of a frame, and a still page reshapes the same runs every frame.
    /// 已整形的片段，键为文本、样式与字体集合的哈希：整形是一帧里最贵的一步，
    /// 而不动的页面每帧都在重整形同一批 run。
    shaped_spans: FastMap<u64, std::rc::Rc<Vec<Vec<ShapedPiece>>>>,
    /// Resolved text primitives: resolving one re-runs shaping, fallback and atlas look-ups
    /// for every glyph, so a still page must not redo it. Keyed by `text_key`.
    /// 已解析的文本图元：解析一段要重跑整形、回退与逐字形图集查找，不动的页面不该重做。
    /// 以 `text_key` 为键。
    resolved_text: FastMap<u64, std::rc::Rc<CachedText>>,
    /// Bumped when the set of loaded faces changes, so a stale size is never served.
    /// 已加载字面集合变化时递增，绝不供应过期尺寸。
    fonts_version: u64,
    /// Measurements that missed the cache; a layout that repeats itself must not grow this.
    /// 未命中缓存的测量次数；重复布局不得让它增长。
    measure_misses: u64,
    /// Text primitives that had to be resolved; repeats are served from `resolved_text`.
    /// 真正重新解析过的文本图元次数；重复的由 `resolved_text` 供应。
    resolve_misses: u64,
}

/// Whether the block draws symbols rather than text: one run, in a symbol family.
/// 该块画的是符号而不是文字：单个 run，且属于符号族。
fn is_symbol_block(block: &ui_core::TextBlock) -> bool {
    match block.runs.as_slice() {
        [run] => run.style.family.is_symbol(),
        _ => false,
    }
}

/// A block prepared once, so paint and the geometry queries agree on every fact.
/// 一个块只准备一次，绘制与几何查询因此共用同一组事实。
struct Prepared {
    flat: String,
    spans: Vec<ui_core::Span>,
    /// The lines layout already sized; paint draws these instead of wrapping again.
    /// 布局已定尺寸的那些行；绘制照它落笔，不再断一次。
    layout: std::rc::Rc<ui_core::InlineLayout>,
}

/// One char boundary on a line, and where it sits on the surface.
/// 一行上的一个字符边界，以及它在表面上的位置。
///
/// Built from the shaped glyphs, so a click, a caret and a selection all agree about
/// where byte `n` is — prefix-shaping each of them separately would let them drift.
/// 由已整形的字形得到，点击、插入符与选区因此对「第 n 个字节在哪」意见一致；
/// 各自前缀整形一遍会让三者漂移。
#[derive(Clone, Copy, Debug)]
struct Boundary {
    byte: usize,
    x: f32,
    rtl: bool,
}

impl Default for TextPass {
    fn default() -> Self {
        Self::new()
    }
}

impl TextPass {
    /// Stack backed by the platform's generic sans face.
    /// 以平台通用无衬线字面为栈的字体栈。
    pub fn new() -> Self {
        Self::build(ui_text_fontique::system_or_isolated(), &[])
    }

    /// Family names tried in order; unknown or unloadable names are skipped.
    /// 按顺序尝试的族名；未知或无法加载的名字会被跳过。
    pub fn with_stack(families: &[&str]) -> Self {
        Self::build(ui_text_fontique::system_or_isolated(), families)
    }

    /// Pass with no font at all: text stays unresolved and is reported as such.
    /// 完全没有字体的 pass：文本保持未解析并被如实统计。
    pub fn isolated() -> Self {
        Self::build(FontiqueProvider::new_isolated(), &[])
    }

    /// Register font bytes under `name`; runs naming that family resolve to these bytes.
    /// Registered families win over system ones, so a bundled icon font cannot be shadowed.
    /// 把字体字节注册到 `name` 下；指定该族的 run 会解析到这些字节。
    /// 注册族优先于系统族，内置图标字体因此不会被陈旧系统副本遮蔽。
    pub fn register(&mut self, name: &str, data: Arc<[u8]>) -> bool {
        let ok = self.provider.register_family(name, data);
        if ok {
            // A stack built before the family existed would keep answering "no such face".
            // 族存在之前建好的栈会一直回答「没有这个字面」。
            self.styled.clear();
            self.script_face.clear();
            self.rebuild_stack();
            self.forget_measurements();
        }
        ok
    }

    fn build(provider: FontiqueProvider, families: &[&str]) -> Self {
        let mut pass = Self {
            families: families.iter().map(|f| f.to_string()).collect(),
            styled: FastMap::default(),
            provider,
            cache: GlyphCache::new(ATLAS_W, ATLAS_H),
            stack: Vec::new(),
            emoji: Vec::new(),
            shapers: FastMap::default(),
            script_face: FastMap::default(),
            atlas_mark: (0, 0),
            version: 0,
            unresolved: 0,
            measured: FastMap::default(),
            min_widths: FastMap::default(),
            slice_widths: FastMap::default(),
            font_files: FastSet::default(),
            shaped_spans: FastMap::default(),
            resolved_text: FastMap::default(),
            fonts_version: 0,
            measure_misses: 0,
            resolve_misses: 0,
        };
        pass.rebuild_stack();
        pass
    }

    /// Resolve the base stack from the configured families, in priority order.
    /// 按优先级由配置的族解析基础栈。
    ///
    /// This runs again after every registration: a family added later has to reach the
    /// stack too, and it belongs ahead of whatever the platform chose before it existed.
    /// 每次登记之后都要重跑：后到的族也得进栈，而且排在此前平台所选的字面之前。
    fn rebuild_stack(&mut self) {
        let names = self.families.clone();
        let mut stack: Vec<FaceId> = Vec::new();
        // Resolving is cheap; admitting is not: a CJK face's file is tens of megabytes, and
        // most of the stack never shapes anything, so the bytes wait for `shaper_for`.
        // 解析便宜，admit 不便宜：CJK 字面文件有几十 MB，而栈里大多从不整形，
        // 因此字节留到 `shaper_for` 时才读。
        let take = |pass: &mut Self, request: &FontRequest, stack: &mut Vec<FaceId>| {
            if let Some(face) = pass.provider.resolve(request)
                && !stack.contains(&face) {
                    stack.push(face);
                }
        };
        // Named families first: an explicit stack is what makes coverage predictable.
        // 先用具名族：显式字体栈才让覆盖率可预期。
        for name in &names {
            take(self, &FontRequest::new(GenericFamily::SansSerif).family(name.as_str()), &mut stack);
        }
        // Then the platform's own choice for the generic family.
        // 然后是平台对通用族自己的选择。
        take(self, &FontRequest::new(GenericFamily::SansSerif), &mut stack);
        self.stack = stack;

        // Emoji faces are found by name: the generic families have no Emoji variant, and
        // the script fallback for a Common character answers with a text face.
        // emoji 字面按名字查找：通用族没有 Emoji 变体，而 Common 字符的脚本回退
        // 会给出一个文字字面。
        let mut emoji: Vec<FaceId> = Vec::new();
        for name in self.provider.family_names() {
            if !name.to_ascii_lowercase().contains("emoji") {
                continue;
            }
            let request = FontRequest::new(GenericFamily::SansSerif).family(name);
            if let Some(face) = self.provider.resolve(&request)
                && !emoji.contains(&face) {
                    emoji.push(face);
                }
        }
        self.emoji = emoji;
    }

    /// True when at least one loadable face exists, i.e. text can reach the atlas.
    /// 是否至少有一个可加载字面，即文本能否进入图集。
    pub fn has_face(&self) -> bool {
        !self.stack.is_empty()
    }

    pub fn atlas(&self) -> &[u8] {
        self.cache.atlas()
    }

    /// Premultiplied RGBA page for colour glyphs; empty until one is rasterized.
    /// 颜色字形的预乘 RGBA 页；光栅出颜色字形前为空。
    pub fn color_atlas(&self) -> &[u8] {
        self.cache.color_atlas()
    }

    pub fn dimensions(&self) -> (u32, u32) {
        self.cache.dimensions()
    }

    pub fn color_dimensions(&self) -> (u32, u32) {
        self.cache.color_dimensions()
    }

    /// Changes whenever the colour page changes; tracked separately so a new text
    /// glyph does not re-upload four megabytes of emoji.
    /// 颜色页变化时推进；单独跟踪，避免新增文字字形就重传四兆 emoji。
    pub fn color_version(&self) -> u64 {
        self.cache.color_version
    }

    /// Changes whenever new coverage was rasterized into the atlas.
    /// 有新覆盖率光栅进图集时变化。
    pub fn version(&self) -> u64 {
        self.version
    }

    pub fn unresolved(&self) -> usize {
        self.unresolved
    }

    /// Measurements that actually ran; repeats are served from the cache.
    /// 真正执行过的测量次数；重复的测量由缓存供应。
    pub fn measure_misses(&self) -> u64 {
        self.measure_misses
    }

    /// Text primitives that had to be resolved; an unchanged one is reused.
    /// 真正重新解析过的文本图元；未变的直接复用。
    pub fn resolve_misses(&self) -> u64 {
        self.resolve_misses
    }

    /// Rebuild `list`, replacing every `Text` primitive with placed glyphs.
    /// 重建 `list`，把每个 `Text` 图元替换成已放置的字形。
    ///
    /// Unresolvable text stays in the list so a CPU fallback still runs; it is
    /// counted in `unresolved()` rather than vanishing.
    /// 无法解析的文本保留在列表里以便 CPU 兜底；计入 `unresolved()` 而不是消失。
    pub fn resolve(&mut self, list: &DrawList, scale: f32) -> DrawList {
        let mut out = DrawList::new(list.canvas);
        self.resolve_into(list, scale, &mut out);
        out
    }

    /// Same pass, writing into a caller-owned list so its capacity survives the frame.
    /// 同一趟解析，写进调用方持有的列表，使其容量跨帧保留。
    pub fn resolve_into(&mut self, list: &DrawList, scale: f32, out: &mut DrawList) {
        let scale = if scale.is_finite() && scale > 0.0 {
            scale
        } else {
            1.0
        };
        self.unresolved = 0;

        out.clear();
        out.canvas = list.canvas;
        out.clips.clone_from(&list.clips);
        out.layers.clone_from(&list.layers);
        // Backdrop entries are referenced by index from the ops, so they must travel too.
        // 背景模糊条目由 op 按下标引用，因此必须一起带过去。
        out.backdrops.clone_from(&list.backdrops);
        // Image entries are indexed by the image prims, so they travel too; the pixels sit
        // behind an Arc, so this copies handles rather than megabytes.
        // 图像条目由图像图元按下标引用，因此一起带过去；像素在 Arc 后面，
        // 这里复制的是句柄而不是几兆字节。
        out.images.clone_from(&list.images);

        for op in &list.ops {
            let Op::Prim(prim) = op else {
                out.ops.push(*op);
                continue;
            };
            match prim.kind {
                // Images carry no text, so the resolved list keeps them only for the painter.
                // 图像不含文本，因此解析后的列表只为绘制保留它们。
                PrimKind::Shadow => {
                    let owner = list.owners.shadows[prim.index as usize];
                    out.push_shadow(owner, list.prims.shadows[prim.index as usize]);
                }
                PrimKind::Image => {
                    let owner = list.owners.images[prim.index as usize];
                    out.push_image_prim(owner, list.prims.images[prim.index as usize]);
                }
                // Arcs carry no text either; they only need to survive the pass.
                // 弧同样不含文本，只需穿过这一趟。
                PrimKind::Sector => {
                    let owner = list.owners.sectors[prim.index as usize];
                    out.push_sector(owner, list.prims.sectors[prim.index as usize]);
                }
                PrimKind::Rect => {
                    let owner = list.owners.rects[prim.index as usize];
                    out.push_rect(owner, list.prims.rects[prim.index as usize]);
                }
                PrimKind::Glyph => {
                    let owner = list.owners.glyphs[prim.index as usize];
                    out.push_glyph(owner, list.prims.glyphs[prim.index as usize]);
                }
                PrimKind::Text => {
                    let owner = list.owners.texts[prim.index as usize];
                    let text = &list.prims.texts[prim.index as usize];
                    let done = self.shape_cached(text, scale);
                    if done.glyphs.is_empty() {
                        self.unresolved += 1;
                        // The prim carries its own zoom; the list must not stack a second one.
                        // 图元自带缩放；列表不得再叠一次。
                        out.transform = None;
                        out.push_text(owner, text.clone());
                        continue;
                    }
                    // Shaped unscaled, scaled on the way out; the highlight goes under the
                    // glyphs and the caret over them.
                    // 在未缩放空间成形、出门时缩放；高亮在字形之下、插入符在字形之上。
                    out.transform = text.zoom.filter(|t| !t.is_identity());
                    for rect in &done.rects {
                        out.push_rect(owner, *rect);
                    }
                    for glyph in &done.glyphs {
                        out.push_glyph(owner, *glyph);
                    }
                    // After the glyphs: the caret belongs on top of the text it splits.
                    // 在字形之后：插入符应盖在它分开的文字之上。
                    if let Some(rect) = done.caret {
                        out.push_rect(owner, rect);
                    }
                    out.transform = None;
                }
            }
        }
    }

    /// Resolve one text primitive, reusing the previous frame's answer when nothing that
    /// shapes it changed: shaping is by far the costliest step of a still frame.
    /// 解析一个文本图元；影响整形的输入都没变时复用上一帧的结果——不动的帧里整形是最贵的一步。
    fn shape_cached(&mut self, text: &TextPrim, scale: f32) -> std::rc::Rc<CachedText> {
        let key = text_key(text, scale, self.fonts_version);
        let stamp = self.atlas_stamp();
        if let Some(hit) = self.resolved_text.get(&key)
            && hit.stamp == stamp
            && hit.prim == *text
        {
            return std::rc::Rc::clone(hit);
        }
        self.resolve_misses += 1;
        let (rects, glyphs, caret) = self.shape(text, scale);
        // Re-keyed after shaping: shaping is what registers a face and bumps `fonts_version`,
        // and the stamp has the same problem — both must survive the frame that made them.
        // 在整形之后重新取键：注册字面并推进 `fonts_version` 的正是整形，戳同理——
        // 两者都必须能活过创建它们的那一帧。
        let key = text_key(text, scale, self.fonts_version);
        let entry = std::rc::Rc::new(CachedText {
            prim: text.clone(),
            stamp: self.atlas_stamp(),
            rects,
            glyphs,
            caret,
        });
        if self.resolved_text.len() >= RESOLVE_CACHE_MAX {
            self.resolved_text.clear();
        }
        self.resolved_text.insert(key, std::rc::Rc::clone(&entry));
        entry
    }

    /// Identity of the atlas contents: a cached slot rect is only valid for the stamp it was
    /// resolved against. Everything that moves or reuses a slot bumps one of these.
    /// 图集内容的标识：缓存的槽位矩形只在解析时的那一版上成立。任何搬动或复用槽位的事都会推进其中之一。
    fn atlas_stamp(&self) -> (u64, u64, u64) {
        (
            self.version,
            self.cache.color_version,
            self.cache.stats.evictions,
        )
    }

    /// Shape one text primitive, choosing a covering face per visual run.
    /// 整形一个文本图元，按视觉段选择覆盖它的字面。
    ///
    /// One face is not enough: Latin, CJK and Arabic are rarely covered by a single
    /// font, and shaping a run with a non-covering face yields `.notdef` boxes.
    /// 单一字面不够：拉丁、CJK、阿拉伯很少由同一种字体覆盖，
    /// 用不覆盖的字面整形只会得到 `.notdef` 方块。
    fn shape(
        &mut self,
        text: &TextPrim,
        scale: f32,
    ) -> (Vec<RectPrim>, Vec<GlyphPrim>, Option<RectPrim>) {
        let prep = self.prepare(text);
        if prep.spans.is_empty() {
            return (Vec::new(), Vec::new(), None);
        }
        let (selection, ink_override) = self.paint_selection(text, &prep, scale);
        let ink_override = ink_override.as_ref();
        // The composing run is underlined in the text's own ink, beneath its glyphs.
        // 组合中的区间用文字自身的墨色加下划线，画在字形之下。
        let mut rects = selection;
        rects.extend(self.composing_underline(text, &prep, scale));

        let mut out = Vec::new();
        for (index, line) in prep.layout.lines.iter().enumerate() {
            let range = line.range();
            let body = prep.flat.get(range.clone()).unwrap_or("");
            // The ellipsis is not part of the source range, so it is appended here.
            // 省略号不属于源区间，因此在这里追加。
            let owned = line.ellipsis.then(|| format!("{body}{}", ui_text::ELLIPSIS));
            let slice = owned.as_deref().unwrap_or(body);
            // The line's own baseline, from the layout that sized the block.
            // 本行自己的基线，取自为整块定尺寸的那份布局。
            let baseline = self.line_baseline(text, &prep, index);
            let x = self.line_x(text, &prep, index);
            if !slice.is_empty() {
                self.shape_line(
                    slice,
                    &prep.spans,
                    range.start,
                    baseline,
                    x,
                    line,
                    x,
                    scale,
                    text.ink,
                    ink_override,
                    Some(&mut out),
                    None,
                );
            }
            // An atom gets a faint block until P5 can position a real node inside the line.
            // 原子先画一块淡色占位，等 P5 能把真实节点定位进行内再换。
            let ink = text.ink;
            for atom in &line.atoms {
                rects.push(RectPrim {
                    rect: atom.rect(ui_core::geom::Point::new(x, Self::line_top(text, &prep) + line.y)),
                    radius: ui_core::Corners::all(ATOM_RADIUS),
                    fill: ui_core::Color::rgba(ink.r, ink.g, ink.b, ink.a * ATOM_ALPHA),
                    gradient: None,
                    border: None,
                    border_gradient: None,
                    notch: None,
                });
            }
        }

        // After the glyphs: the caret belongs on top of the text it splits.
        // 在字形之后：插入符应盖在它分开的文字之上。
        let caret_rect = text.caret.and_then(|caret| {
            let rect = self.caret_rect_with(text, &prep, caret.offset, scale)?;
            Some(RectPrim {
                rect,
                radius: ui_core::Corners::ZERO,
                fill: caret.color,
                gradient: None,
                border: None,
                border_gradient: None,
                notch: None,
            })
        });

        let mark = (self.cache.stats.rasterized, self.cache.stats.grows);
        if mark != self.atlas_mark {
            self.atlas_mark = mark;
            self.version += 1;
        }
        // A symbol is centred by its ink: its line box carries the font's ascent, and the
        // mark fills the em from the baseline, so the box centre and the ink centre differ.
        // 符号按墨居中：行盒含字体上伸部，而标记从基线起填满一个 em，盒心与墨心因此不重合。
        if is_symbol_block(&text.block) && text.height > 0.0 {
            let (top, bottom) = out.iter().fold((f32::MAX, f32::MIN), |(lo, hi), g| {
                (lo.min(g.rect.min_y()), hi.max(g.rect.max_y()))
            });
            if top < bottom {
                let dy = text.origin.y + text.height * 0.5 - (top + bottom) * 0.5;
                for glyph in &mut out {
                    glyph.rect.origin.y += dy;
                }
            }
        }
        (rects, out, caret_rect)
    }

    /// One thin rect per visual line under the composing run.
    /// 组合区间下方每条视觉行一个细矩形。
    fn composing_underline(
        &mut self,
        text: &TextPrim,
        prep: &Prepared,
        scale: f32,
    ) -> Vec<RectPrim> {
        let Some(range) = text.composing.clone() else {
            return Vec::new();
        };
        self.selection_fragments_with(text, prep, range, scale)
            .into_iter()
            .map(|f| RectPrim {
                rect: ui_core::geom::Rect {
                    origin: ui_core::geom::Point::new(
                        f.rect.origin.x,
                        f.rect.origin.y + f.rect.size.h - COMPOSING_UNDERLINE,
                    ),
                    size: ui_core::geom::Size {
                        w: f.rect.size.w,
                        h: COMPOSING_UNDERLINE,
                    },
                },
                radius: ui_core::Corners::ZERO,
                fill: text.ink,
                gradient: None,
                border: None,
                border_gradient: None,
                notch: None,
            })
            .collect()
    }

    /// Ask the node's painter for the highlight, and for any ink override.
    /// 向节点的绘制程序要高亮，以及可能的墨色覆盖。
    fn paint_selection(
        &mut self,
        text: &TextPrim,
        prep: &Prepared,
        scale: f32,
    ) -> (Vec<RectPrim>, Option<(std::ops::Range<usize>, ui_core::Color)>) {
        let Some(selection) = &text.selection else {
            return (Vec::new(), None);
        };
        let fragments = self.selection_fragments_with(text, prep, selection.range.clone(), scale);
        if fragments.is_empty() {
            return (Vec::new(), None);
        }
        let geometry = ui_core::SelectionGeometry {
            fragments: &fragments,
            fill: selection.fill,
            ink: text.ink,
        };
        let paint = match selection.painter {
            Some(painter) => (painter.0).paint(&geometry),
            None => ui_core::flat_selection(&geometry),
        };
        let range = selection.range.start.min(prep.flat.len())
            ..selection.range.end.min(prep.flat.len());
        (paint.rects, paint.ink.map(|ink| (range, ink)))
    }

    /// Flatten and take the wrapped lines; paint and every query start from this.
    /// 拼接并取来已断好的行；绘制与所有查询都从这里出发。
    fn prepare(&mut self, text: &TextPrim) -> Prepared {
        let (flat, spans) = text.block.flatten();
        // Layout already wrapped this block; a prim built outside layout gets it here once.
        // 布局已为本块断好行；不经过布局的图元在这里补一次。
        let layout = match &text.layout {
            Some(layout) => std::rc::Rc::clone(layout),
            None => self.layout(&text.block, text.max_width),
        };
        Prepared {
            flat,
            spans,
            layout,
        }
    }

    /// Left edge of a line, honouring the block's alignment and first-line indent.
    /// 一行的左边缘，考虑块的对齐与首行缩进。
    fn line_x(&self, text: &TextPrim, prep: &Prepared, index: usize) -> f32 {
        let line = &prep.layout.lines[index];
        let indent = if index == 0 {
            text.block.indent.max(0.0)
        } else {
            0.0
        };
        aligned_x(
            text.block.align,
            line.width,
            (text.max_width - indent).max(0.0),
            text.origin.x + indent,
        )
    }

    /// Top of the line block: `origin` is the node's box top, and the block sits centred in
    /// a box taller than it, so an icon is not pinned to the top of its 1.4 em slot.
    /// 行块顶端：`origin` 是节点盒顶，行块在更高的盒子里居中，图标因此不会被钉在
    /// 1.4em 槽的顶边。所有行内几何都从这里出发，免得各算各的。
    fn line_top(text: &TextPrim, prep: &Prepared) -> f32 {
        let spare = (text.height - prep.layout.height).max(0.0);
        text.origin.y + spare * 0.5
    }

    /// Baseline of a line, from the block's origin.
    /// 一行的基线，相对块的起点。
    fn line_baseline(&self, text: &TextPrim, prep: &Prepared, index: usize) -> f32 {
        let line = &prep.layout.lines[index];
        Self::line_top(text, prep) + line.y + line.baseline
    }

    /// Every char boundary of one line and where it sits, in visual (left-to-right) order.
    /// 一行的全部字符边界及其位置，按视觉（从左到右）顺序。
    ///
    /// RTL runs contribute the *end* of a cluster at their left edge: the glyph's left
    /// side is where the reader has finished it, not where they started.
    /// RTL 段在其左缘给出字簇的**结束**：字形的左侧是读者读完它的位置，而不是起点。
    fn boundaries(
        &mut self,
        text: &TextPrim,
        prep: &Prepared,
        index: usize,
        scale: f32,
    ) -> Vec<Boundary> {
        let layout = &prep.layout.lines[index];
        let range = layout.range();
        let body = prep.flat.get(range.clone()).unwrap_or("");
        let x = self.line_x(text, prep, index);
        let baseline = self.line_baseline(text, prep, index);
        let mut out = Vec::new();
        if !body.is_empty() {
            self.shape_line(
                body,
                &prep.spans,
                range.start,
                baseline,
                x,
                layout,
                x,
                scale,
                text.ink,
                None,
                None,
                Some(&mut out),
            );
        }
        // Boundaries come back relative to the line; callers index the whole block.
        // 边界以行内偏移返回；调用方用的是整块的字节偏移。
        let start = range.start;
        for b in &mut out {
            b.byte += start;
        }
        out
    }

    /// x of `byte` among visual boundaries; a byte inside a cluster takes the nearest one.
    /// `byte` 在视觉边界中的 x；落在字簇内部的字节取最近的边界。
    fn x_at(bounds: &[Boundary], byte: usize, fallback: f32) -> f32 {
        let Some(first) = bounds.first() else {
            return fallback;
        };
        if let Some(hit) = bounds.iter().find(|b| b.byte == byte) {
            return hit.x;
        }
        let mut best = *first;
        for b in bounds {
            if b.byte.abs_diff(byte) < best.byte.abs_diff(byte) {
                best = *b;
            }
        }
        best.x
    }

    /// Whether the text at `byte` reads right to left.
    /// `byte` 处的文字是否从右到左。
    fn rtl_at(bounds: &[Boundary], byte: usize) -> bool {
        bounds
            .iter()
            .find(|b| b.byte == byte)
            .or_else(|| bounds.first())
            .is_some_and(|b| b.rtl)
    }

    /// The caret for `index`, or `None` when the block has no lines at all.
    /// `index` 处的插入符；整块没有任何行时返回 `None`。
    fn caret_rect_with(
        &mut self,
        text: &TextPrim,
        prep: &Prepared,
        index: usize,
        scale: f32,
    ) -> Option<ui_core::geom::Rect> {
        if prep.layout.lines.is_empty() {
            return None;
        }
        let at = ui_core::text_input::clamp(&prep.flat, index);
        // A wrapped boundary belongs to the next line, which is where paint puts it too.
        // 换行处的边界属于下一行，绘制端也是这么放的。
        let lines = &prep.layout.lines;
        let line = lines
            .iter()
            .position(|l| l.range().contains(&at))
            .or_else(|| lines.iter().position(|l| at <= l.range().end))
            .unwrap_or(lines.len() - 1);
        let bounds = self.boundaries(text, prep, line, scale);
        let fallback = self.line_x(text, prep, line);
        let x = Self::x_at(&bounds, at, fallback);
        let box_line = &lines[line];
        Some(ui_core::geom::Rect::new(
            x - CARET_WIDTH * 0.5,
            Self::line_top(text, prep) + box_line.y,
            CARET_WIDTH,
            box_line.height,
        ))
    }

    /// The cluster boundary nearest to a surface point; the click-to-caret primitive.
    /// 距表面点最近的字簇边界；点击定位插入符的基本运算。
    pub fn index_at(
        &mut self,
        text: &TextPrim,
        p: ui_core::geom::Point,
        scale: f32,
    ) -> usize {
        let prep = self.prepare(text);
        let lines = &prep.layout.lines;
        if lines.is_empty() {
            return 0;
        }
        // Lines can differ in height, so pick by each one's own box, not by a fixed step.
        // 各条行可以不同高，因此按各自的行盒取，而不是按固定步长。
        let rel = (p.y - Self::line_top(text, &prep)).max(0.0);
        let line = lines
            .iter()
            .position(|l| rel < l.bottom())
            .unwrap_or(lines.len() - 1);
        let bounds = self.boundaries(text, &prep, line, scale);
        let Some(first) = bounds.first() else {
            return lines[line].range().start;
        };
        let mut best = *first;
        for b in &bounds {
            if (b.x - p.x).abs() < (best.x - p.x).abs() {
                best = *b;
            }
        }
        // Shaped clusters are the boundaries, but a face may split inside one; snap back.
        // 边界来自整形的字簇，但字面可能在字簇内部切开；退回到字簇边界。
        ui_core::grapheme::snap(&prep.flat, best.byte)
    }

    /// Where the caret for `index` sits, in surface coordinates.
    /// `index` 处的插入符位置，表面坐标。
    pub fn caret_rect(
        &mut self,
        text: &TextPrim,
        index: usize,
        scale: f32,
    ) -> Option<ui_core::geom::Rect> {
        let prep = self.prepare(text);
        self.caret_rect_with(text, &prep, index, scale)
    }

    /// One rect per visual line piece the selection covers, in surface coordinates.
    /// 选区覆盖的每一段视觉行一个矩形，表面坐标。
    pub fn selection_fragments(
        &mut self,
        text: &TextPrim,
        range: std::ops::Range<usize>,
        scale: f32,
    ) -> Vec<ui_core::SelectionFragment> {
        let prep = self.prepare(text);
        self.selection_fragments_with(text, &prep, range, scale)
    }

    /// The same fragments, from a block that is already prepared.
    /// 同一批片段，但块已经准备过。
    fn selection_fragments_with(
        &mut self,
        text: &TextPrim,
        prep: &Prepared,
        range: std::ops::Range<usize>,
        scale: f32,
    ) -> Vec<ui_core::SelectionFragment> {
        let mut out = Vec::new();
        let start = range.start.min(prep.flat.len());
        let end = range.end.min(prep.flat.len());
        if start >= end {
            return out;
        }
        for index in 0..prep.layout.lines.len() {
            let line = &prep.layout.lines[index];
            let range = line.range();
            let from = start.max(range.start);
            let to = end.min(range.end);
            if from >= to {
                continue;
            }
            let bounds = self.boundaries(text, prep, index, scale);
            let fallback = self.line_x(text, prep, index);
            let x0 = Self::x_at(&bounds, from, fallback);
            let x1 = Self::x_at(&bounds, to, fallback);
            out.push(ui_core::SelectionFragment {
                rect: ui_core::geom::Rect::new(
                    x0.min(x1),
                    Self::line_top(text, prep) + line.y,
                    (x1 - x0).abs(),
                    line.height,
                ),
                line: index,
                first: false,
                last: false,
                rtl: Self::rtl_at(&bounds, from),
            });
        }
        if let Some(first) = out.first_mut() {
            first.first = true;
        }
        if let Some(last) = out.last_mut() {
            last.last = true;
        }
        out
    }

    /// Measured size for layout: the same breaker and shaping the painter uses.
    /// 供布局使用的测量尺寸：与绘制器相同的断行与整形。
    pub fn measure(&mut self, block: &ui_core::TextBlock, max_width: f32) -> ui_core::Size {
        self.layout(block, max_width).size()
    }

    /// Smallest and largest size: the widest unbreakable segment, and the unwrapped line.
    /// 最小与最大尺寸：最宽的不可断片段，以及不断行时的整行。
    pub fn intrinsic(
        &mut self,
        block: &ui_core::TextBlock,
    ) -> (ui_core::Size, ui_core::Size) {
        let max = self.measure(block, f32::INFINITY);
        // The floor is width-independent, so it caches like the wrap does; without this every
        // layout reshapes the block slice by slice just to re-measure the same floor.
        // 下限与宽度无关，因此像换行一样可以缓存；没有它，每次布局都要逐片重整形一遍，
        // 只为再量同一个下限。
        let key = measure_key(block, f32::INFINITY, self.fonts_version);
        let min_w = match self.min_widths.get(&key) {
            Some(w) => *w,
            None => {
                let (flat, spans) = block.flatten();
                let w = ui_text::min_content_width(&flat, |_slice, range| {
                    self.measure_range(&flat, &spans, &block.atoms, range)
                });
                if self.min_widths.len() >= MEASURE_CACHE_MAX {
                    self.min_widths.clear();
                }
                self.min_widths.insert(key, w);
                w
            }
        };
        (ui_core::Size::new(min_w, max.h), max)
    }

    /// The cached wrap for this block at this width, computed once.
    /// 该块在该宽度下的缓存换行，只计算一次。
    pub fn layout(
        &mut self,
        block: &ui_core::TextBlock,
        max_width: f32,
    ) -> std::rc::Rc<ui_core::InlineLayout> {
        let key = measure_key(block, max_width, self.fonts_version);
        if let Some(hit) = self.measured.get(&key) {
            return std::rc::Rc::clone(hit);
        }
        let computed = std::rc::Rc::new(timed!("measure", self.layout_uncached(block, max_width)));
        self.measure_misses += 1;
        if self.measured.len() >= MEASURE_CACHE_MAX {
            self.measured.clear();
        }
        self.measured.insert(key, std::rc::Rc::clone(&computed));
        computed
    }

    fn layout_uncached(
        &mut self,
        block: &ui_core::TextBlock,
        max_width: f32,
    ) -> ui_core::InlineLayout {
        let (flat, spans) = block.flatten();
        // Face metrics per span: a line's box and its baseline both come from the face.
        // 逐 span 的字面度量：行的行盒与基线都来自字面。
        let boxes: Vec<(std::ops::Range<usize>, f32, f32, f32)> = spans
            .iter()
            .map(|span| {
                let size = span.style.size.max(1.0);
                let m = self.line_metrics(&span.style);
                let ascent = m.map_or(0.8, |m| m.ascent) * size;
                let descent = m.map_or(0.3, |m| -m.descent) * size;
                let line_h = m.map_or(1.2, |m| (m.ascent - m.descent + m.line_gap).max(0.0)) * size;
                (span.range.clone(), ascent, descent, line_h)
            })
            .collect();
        let lines =
            self.break_into_lines(&flat, &spans, &block.atoms, max_width, block.max_lines, block.indent);
        let mut out: Vec<ui_core::InlineLine> = Vec::with_capacity(lines.len());
        let mut y = 0.0f32;
        for line in lines {
            let on_line: Vec<ui_core::AtomBox> = block
                .atoms
                .iter()
                .copied()
                .filter(|a| a.at >= line.range.start && a.at < line.range.end)
                .collect();
            let mut ascent = 0.0f32;
            let mut descent = 0.0f32;
            let mut box_h = 0.0f32;
            for (span, a, d, h) in &boxes {
                if span.start < line.range.end && span.end > line.range.start {
                    ascent = ascent.max(*a);
                    descent = descent.max(*d);
                    box_h = box_h.max(*h);
                }
            }
            let (height, baseline) = ui_core::text::line_metrics(ascent, descent, box_h, &on_line);
            let mut atoms = Vec::new();
            for atom in &on_line {
                let x = self.measure_range(
                    &flat,
                    &spans,
                    &block.atoms,
                    line.range.start..atom.at,
                );
                atoms.push(ui_core::InlineAtom {
                    at: atom.at,
                    x,
                    y: atom.align.top(atom.size, atom.baseline, baseline, height),
                    size: atom.size,
                    align: atom.align,
                });
            }
            out.push(ui_core::InlineLine {
                y,
                height,
                baseline,
                width: line.width,
                ellipsis: line.ellipsis,
                runs: ui_core::text::runs_in(block, &spans, line.range.clone()),
                atoms,
            });
            // A gap sits between lines only; the last line adds none.
            // 空隙只在行与行之间；最后一行之后不加。
            y += height + block.line_gap;
        }
        // An empty block still owns a caret line: without one, `caret_rect` has no origin
        // and an empty text field could never place the candidate window.
        // 空块仍拥有一条插入符行：没有它 `caret_rect` 就没有原点，
        // 空文本框也就永远无法为输入法候选窗定位。
        let height = if out.is_empty() {
            let height = boxes
                .first()
                .map_or(ui_core::TextStyle::default().size * 1.2, |b| b.1 + b.2);
            out.push(ui_core::InlineLine {
                y: 0.0,
                height,
                baseline: height * 0.8,
                width: 0.0,
                ellipsis: false,
                runs: Vec::new(),
                atoms: Vec::new(),
            });
            height
        } else {
            (y - block.line_gap).max(0.0)
        };
        let width = out.iter().fold(0.0f32, |acc, l| acc.max(l.width)) + block.indent.max(0.0);
        let baseline = out.first().map_or(0.0, |l| l.baseline);
        ui_core::InlineLayout {
            lines: out,
            width,
            height,
            baseline,
        }
    }

    /// Metrics of the face that answers `style`'s stack, admitting it on first use.
    /// `style` 的栈中首个字面的度量；首次使用时把它加入缓存。
    fn line_metrics(&mut self, style: &TextStyle) -> Option<ui_text_fontique::RealMetrics> {
        let face = *self
            .stack_for(style.family, style.weight, style.italic)
            .first()?;
        self.admit_face(face);
        self.cache.face_metrics(face)
    }

    fn break_into_lines(
        &mut self,
        text: &str,
        spans: &[ui_core::Span],
        atoms: &[ui_core::AtomBox],
        max_width: f32,
        max_lines: Option<u32>,
        indent: f32,
    ) -> Vec<ui_text::Line> {
        // The ellipsis is drawn in the style of the text it replaces: the last span's.
        // 省略号用它所替代文字的样式绘制：即最后一个 span 的样式。
        let ellipsis = self.measure_slice(
            ui_text::ELLIPSIS,
            ui_core::TextBlock::style_at(spans, text.len()),
        );
        timed!("linebreak", ui_text::wrap_indented(text, max_width, max_lines, indent, ellipsis, |_slice, range| {
            self.measure_range(text, spans, atoms, range)
        }))
    }

    /// Width of `range`, with every atom counted at its own size and its U+FFFC at none.
    /// `range` 的宽度：原子按自身尺寸计，其 U+FFFC 不计。
    fn measure_range(
        &mut self,
        text: &str,
        spans: &[ui_core::Span],
        atoms: &[ui_core::AtomBox],
        range: std::ops::Range<usize>,
    ) -> f32 {
        let mut total = 0.0;
        let mut from = range.start;
        for atom in atoms
            .iter()
            .filter(|a| a.at >= range.start && a.at < range.end)
        {
            if atom.at > from {
                let piece = text.get(from..atom.at).unwrap_or("");
                total += self.measure_slice(piece, ui_core::TextBlock::style_at(spans, from));
            }
            total += atom.size.w;
            from = atom.at + ui_core::OBJECT.len_utf8();
        }
        if from < range.end {
            let piece = text.get(from..range.end).unwrap_or("");
            // The whole style, not just the size: a bold run is wider than a regular one.
            // 传整个样式而不只是字号：粗体 run 比常规宽。
            total += self.measure_slice(piece, ui_core::TextBlock::style_at(spans, from));
        }
        total
    }

    fn measure_slice(&mut self, line: &str, style: ui_core::TextStyle) -> f32 {
        let key = shape_key(line, &style, self.fonts_version);
        if let Some(&width) = self.slice_widths.get(&key) {
            return width;
        }
        let width = timed!("slice", {
            let mut total = 0.0;
            for run in ui_text::itemize(line, None) {
                let slice = line.get(run.range.clone()).unwrap_or("");
                if slice.is_empty() {
                    continue;
                }
                let script = Script::dominant(slice);
                // The same split the painter uses, or measurement and paint drift apart.
                // 与绘制端同一套拆分，否则测量与绘制会各走各的。
                total += self
                    .shape_run_parts(line, run.range.clone(), style, script, run.direction())
                    .iter()
                    .map(|(_, shaped, _, _)| shaped.width)
                    .sum::<f32>();
            }
            total
        });
        if self.slice_widths.len() >= SHAPE_CACHE_MAX {
            self.slice_widths.clear();
        }
        self.slice_widths.insert(key, width);
        width
    }

    /// Lay one line out left to right, switching style at every span boundary.
    /// 从左到右排一行，在每个区间边界切换样式。
    fn shape_line(
        &mut self,
        line: &str,
        spans: &[ui_core::Span],
        base: usize,
        baseline: f32,
        mut pen_x: f32,
        layout: &ui_core::InlineLine,
        line_left: f32,
        scale: f32,
        ink: ui_core::Color,
        ink_override: Option<&(std::ops::Range<usize>, ui_core::Color)>,
        mut out: Option<&mut Vec<GlyphPrim>>,
        mut bounds: Option<&mut Vec<Boundary>>,
    ) -> f32 {
        let end = base + line.len();
        let mut cursor = base;
        while cursor < end {
            // An atom occupies its U+FFFC: no glyph, but the pen moves past its width.
            // 原子占据它的 U+FFFC：不出字形，但笔要越过它的宽度。
            if let Some(atom) = layout.atoms.iter().find(|a| a.at == cursor) {
                let left = line_left + atom.x;
                let right = left + atom.size.w;
                if let Some(bounds) = bounds.as_deref_mut() {
                    bounds.push(Boundary {
                        byte: cursor,
                        x: left,
                        rtl: false,
                    });
                    bounds.push(Boundary {
                        byte: cursor + ui_core::OBJECT.len_utf8(),
                        x: right,
                        rtl: false,
                    });
                }
                pen_x = right;
                cursor += ui_core::OBJECT.len_utf8();
                continue;
            }
            let style = ui_core::TextBlock::style_at(spans, cursor);
            let span_end = spans
                .iter()
                .find(|s| s.range.contains(&cursor))
                .map_or(end, |s| s.range.end.min(end));
            // Stop the piece at the next atom so its U+FFFC is never shaped.
            // 片段在下一个原子处截断，其 U+FFFC 因此不参与整形。
            let next_atom = layout
                .atoms
                .iter()
                .filter(|a| a.at > cursor)
                .map(|a| a.at)
                .min()
                .unwrap_or(end);
            let span_end = span_end.max(cursor + 1).min(end).min(next_atom.max(cursor + 1));
            // Split at the selection boundary so the override ink covers exactly its bytes.
            // 在选区边界处切开，使覆盖墨色恰好落在它的字节上。
            let mut pieces = [(cursor, span_end); 3];
            let mut count = 0;
            let mut from = cursor;
            if let Some((range, _)) = ink_override {
                for cut in [range.start, range.end] {
                    if cut > from && cut < span_end && line.is_char_boundary(cut - base) {
                        pieces[count] = (from, cut);
                        count += 1;
                        from = cut;
                    }
                }
            }
            pieces[count] = (from, span_end);
            count += 1;
            for &(a, b) in &pieces[..count] {
                let slice = line.get(a - base..b - base).unwrap_or("");
                if slice.is_empty() {
                    continue;
                }
                let piece_ink = match ink_override {
                    Some((range, colour)) if range.start <= a && b <= range.end => *colour,
                    _ => ink,
                };
                pen_x += self.shape_span(
                    slice,
                    a - base,
                    style,
                    baseline,
                    pen_x,
                    scale,
                    piece_ink,
                    out.as_deref_mut(),
                    bounds.as_deref_mut(),
                );
            }
            cursor = span_end;
        }
        pen_x
    }

    /// Shape one styled slice and return the advance it consumed.
    /// 整形一个带样式的片段，返回它消耗的推进宽度。
    ///
    /// `out` and `bounds` are both optional: paint asks for glyphs, the geometry queries
    /// ask for boundaries, and neither pays for the other's work.
    /// `out` 与 `bounds` 都可选：绘制要字形，几何查询要边界，各自不为对方的工作付费。
    fn shape_span(
        &mut self,
        slice: &str,
        offset: usize,
        style: ui_core::TextStyle,
        baseline: f32,
        mut pen_x: f32,
        scale: f32,
        ink: ui_core::Color,
        mut out: Option<&mut Vec<GlyphPrim>>,
        mut bounds: Option<&mut Vec<Boundary>>,
    ) -> f32 {
        let key = shape_key(slice, &style, self.fonts_version);
        let shaped = match self.shaped_spans.get(&key) {
            Some(hit) => std::rc::Rc::clone(hit),
            None => {
                let built = std::rc::Rc::new(self.build_shaped(slice, style));
                if self.shaped_spans.len() >= SHAPE_CACHE_MAX {
                    self.shaped_spans.clear();
                }
                self.shaped_spans.insert(key, std::rc::Rc::clone(&built));
                built
            }
        };
        let logical = ui_text::itemize(slice, None);
        let start = pen_x;
        for index in ui_text::visual_order(&logical) {
            let Some(parts) = shaped.get(index) else {
                continue;
            };
            let rtl = logical[index].direction().is_rtl();
            // RTL runs were shaped in logical order and must be placed in reverse.
            // RTL 段按逻辑序整形，摆放时必须反转。
            let ordered: Vec<&(FaceId, ShapedRun, usize, usize, Script)> = if rtl {
                parts.iter().rev().collect()
            } else {
                parts.iter().collect()
            };
            for (face, run, from, to, script) in ordered {
                let base = offset + *from;
                let run_len = to - from;
                let placed = place_run_scaled(
                    run,
                    pen_x,
                    baseline,
                    ui_text::subpixel::should_subpixel(*script),
                    scale,
                );
                if let Some(out) = out.as_deref_mut() {
                    for blit in self.cache.blit_run(*face, &placed, style.size, scale) {
                        out.push(GlyphPrim {
                            rect: blit.dest_logical(scale),
                            atlas: blit.atlas,
                            alpha: 1.0,
                            color: ink,
                            kind: blit.kind,
                        });
                    }
                }
                if let Some(bounds) = bounds.as_deref_mut() {
                    record_boundaries(run, base, run_len, rtl, pen_x, bounds);
                }
                pen_x += run.width;
            }
        }
        pen_x - start
    }

    /// Shape one itemized run: one face when its clusters agree on presentation, else split.
    /// 整形一个 itemize 出来的段：字簇呈现形式一致时用单个字面，否则拆分。
    fn shape_run_parts(
        &mut self,
        whole: &str,
        range: std::ops::Range<usize>,
        style: TextStyle,
        script: Script,
        direction: ui_text::Direction,
    ) -> Vec<(FaceId, ShapedRun, usize, usize)> {
        let piece = whole.get(range.clone()).unwrap_or("");
        if let Some(emoji) = ui_text::emoji::uniform_presentation(piece)
            && let Some((face, shaped)) =
                self.shape_covering(whole, range.clone(), style, script, direction, emoji)
            {
                return vec![(face, shaped, range.start, range.end)];
            }
        self.shape_covering_split(whole, range, style, script, direction)
    }

    /// Shape one span into logical runs, each possibly split across several faces.
    /// 把一个片段整形成若干逻辑段，每段可能跨多个字面。
    fn build_shaped(&mut self, slice: &str, style: ui_core::TextStyle) -> Vec<Vec<ShapedPiece>> {
        let logical = ui_text::itemize(slice, None);
        let mut shaped: Vec<Vec<ShapedPiece>> = Vec::with_capacity(logical.len());
        for run in &logical {
            let piece = slice.get(run.range.clone()).unwrap_or("");
            if piece.is_empty() {
                shaped.push(Vec::new());
                continue;
            }
            let script = Script::dominant(piece);
            let parts = self.shape_run_parts(slice, run.range.clone(), style, script, run.direction());
            shaped.push(
                parts
                    .into_iter()
                    .map(|(face, shaped_run, start, end)| (face, shaped_run, start, end, script))
                    .collect(),
            );
        }
        shaped
    }

    /// Faces for a style, in priority order: the family the run names, then the configured
    /// families, then the generic choice, then the base stack.
    /// 某个样式的字面序列，按优先级：run 指定的族、配置里的族、通用族的选择，最后是基础栈。
    ///
    /// A plain family lookup lands on the family's default face, which is Regular —
    /// so asking for Bold without this would still rasterise Regular outlines.
    /// 只按族名查找会落在族的默认字面上，而那是 Regular——
    /// 因此没有这一步，请求 Bold 仍然会按 Regular 光栅化。
    pub fn stack_for(&mut self, family: Family, weight: ui_core::Weight, italic: bool) -> Vec<FaceId> {
        let key = (family, weight.0, italic);
        if let Some(hit) = self.styled.get(&key) {
            return hit.clone();
        }
        let mut out: Vec<FaceId> = Vec::new();
        let unstyled = weight == ui_core::Weight::REGULAR && !italic;
        // The base stack already answers the default family at its default weight.
        // 基础栈本身就是默认族在默认字重下的答案。
        if unstyled && family == Family::Generic(GenericFamily::SystemUi) {
            out = self.stack.clone();
        } else {
            let request = |family: Option<&str>, generic: GenericFamily| {
                let mut r = FontRequest::new(generic).weight(weight);
                r.italic = italic;
                if let Some(f) = family {
                    r = r.family(f);
                }
                r
            };
            let push = |face: FaceId, out: &mut Vec<FaceId>| {
                if !out.contains(&face) {
                    out.push(face);
                }
            };
            if let Family::Named(name) = family
                && let Some(face) = self.provider.resolve(&request(Some(name), GenericFamily::SansSerif)) {
                    push(face, &mut out);
                }
            if let Family::Generic(generic) = family
                && let Some(face) = self.provider.resolve(&request(None, generic)) {
                    push(face, &mut out);
                }
            for name in &self.families {
                if let Some(face) = self.provider.resolve(&request(Some(name), GenericFamily::SansSerif)) {
                    push(face, &mut out);
                }
            }
            if let Some(face) = self.provider.resolve(&request(None, GenericFamily::SansSerif)) {
                push(face, &mut out);
            }
            // Coverage beats fidelity: a family with no bold face yields nothing above,
            // and losing the glyph is worse than losing the weight.
            // 覆盖率优先于保真：没有粗体字面的族在上面什么也给不出，
            // 而丢字形比丢字重更糟。
            for face in &self.stack {
                push(*face, &mut out);
            }
        }
        self.styled.insert(key, out.clone());
        out
    }

    /// First face whose shaping produces no `.notdef` glyph; `emoji_first` reorders the list.
    /// 第一个整形后不含 `.notdef` 的字面；`emoji_first` 改变候选顺序。
    fn shape_covering(
        &mut self,
        whole: &str,
        range: std::ops::Range<usize>,
        style: TextStyle,
        script: Script,
        direction: ui_text::Direction,
        emoji_first: bool,
    ) -> Option<(FaceId, ShapedRun)> {
        timed!("shape", {
            let key = (style.family, script, style.weight.0, style.italic);
        let candidates = self.face_candidates(style, script, emoji_first);

        for base in candidates {
            // Coverage does not depend on the axes, so the cache above keys on the base
            // face; the instance is what shapes and rasterises.
            // 覆盖率与轴无关，因此上面的缓存以基础字面为键；整形与光栅用实例。
            let face = self.provider.instance(base, style.variations);
            let Some(shaper) = self.shaper_for(face) else {
                continue;
            };
            let run = shaper.shape_run(whole, range.clone(), style.size, script, direction, style.features);
            if run.is_empty() {
                continue;
            }
            if run.glyphs.iter().all(|g| g.glyph_id != 0) {
                self.script_face.insert(key, base);
                return Some((face, run));
            }
        }
            None
        })
    }

    /// The faces to try for one run, in order; `emoji_first` puts emoji presentation ahead.
    /// 一个 run 要尝试的字面，按顺序；`emoji_first` 把 emoji 呈现排在前面。
    fn face_candidates(
        &mut self,
        style: TextStyle,
        script: Script,
        emoji_first: bool,
    ) -> Vec<FaceId> {
        let key = (style.family, script, style.weight.0, style.italic);
        let mut out: Vec<FaceId> = Vec::new();
        fn push(face: FaceId, out: &mut Vec<FaceId>) {
            if !out.contains(&face) {
                out.push(face);
            }
        }
        // A remembered face answers only runs of its own presentation: an emoji face would
        // otherwise claim the plain clusters beside an emoji and draw them as empty components.
        // 记住的字面只回答同类呈现形式的段：否则 emoji 字面会接管旁边的普通字簇，把它们画成空白部件。
        if let Some(&known) = self.script_face.get(&key)
            && self.emoji.contains(&known) == emoji_first {
                out.push(known);
            }
        if emoji_first {
            for face in self.emoji.clone() {
                push(face, &mut out);
            }
        }
        for face in self.stack_for(style.family, style.weight, style.italic) {
            push(face, &mut out);
        }
        for face in self.provider.fallback_chain(script) {
            push(face, &mut out);
        }
        if !emoji_first {
            for face in self.emoji.clone() {
                push(face, &mut out);
            }
        }
        out
    }

    /// Shape a run no single face covers, splitting it where coverage changes.
    /// 整形没有单个字面能覆盖的段，在覆盖率变化处切开。
    ///
    /// Emoji is the common case: no text face has it, and dropping the whole run made
    /// every character in it disappear. Splits fall on cluster boundaries, never inside one.
    /// emoji 是常见情形：文本字面都没有它，整段丢弃会让整串字符一起消失。
    /// 切点只落在字簇边界上，绝不切进字簇内部。
    fn shape_covering_split(
        &mut self,
        whole: &str,
        range: std::ops::Range<usize>,
        style: TextStyle,
        script: Script,
        direction: ui_text::Direction,
    ) -> Vec<(FaceId, ShapedRun, usize, usize)> {
        let plain = self.face_candidates(style, script, false);
        let emoji = self.face_candidates(style, script, true);
        let Some(&first) = plain.first() else {
            return Vec::new();
        };
        let mut groups: Vec<(usize, usize, FaceId)> = Vec::new();
        let body = whole.get(range.clone()).unwrap_or("");
        for (i, cluster) in ui_core::grapheme::clusters(body) {
            let start = range.start + i;
            let end = start + cluster.len();
            // Presentation belongs to the cluster, not to the run: `❤` stays text beside `❤️`.
            // 呈现形式属于字簇而非整段：`❤` 挨着 `❤️` 时仍是文本。
            let list = match ui_text::emoji::asks_emoji(cluster) {
                true => &emoji,
                false => &plain,
            };
            let face = cluster
                .chars()
                .next()
                .and_then(|base| {
                    list.iter()
                        .copied()
                        .find(|&f| self.provider.has_glyph(f, base))
                })
                .unwrap_or_else(|| groups.last().map_or(first, |g| g.2));
            match groups.last_mut() {
                Some(g) if g.2 == face && g.1 == start => g.1 = end,
                _ => groups.push((start, end, face)),
            }
        }
        let mut out = Vec::new();
        for (start, end, base) in groups {
            let face = self.provider.instance(base, style.variations);
            let Some(shaper) = self.shaper_for(face) else {
                continue;
            };
            let run = shaper.shape_run(whole, start..end, style.size, script, direction, style.features);
            if run.is_empty() {
                continue;
            }
            out.push((face, run, start, end));
        }
        out
    }

    /// Put a face's metrics and outlines in the cache, once; false when it has no bytes.
    /// 把字面的度量与轮廓放进缓存，只放一次；没有字节时返回 false。
    fn admit_face(&mut self, face: FaceId) -> bool {
        if self.cache.face_metrics(face).is_some() {
            return true;
        }
        let Some(data) = self.provider.face_data(face) else {
            return false;
        };
        if data.is_empty() {
            return false;
        }
        let axes = self.provider.face_axes(face);
        let index = self.provider.face_index(face) as u32;
        let source = (data.as_ptr() as usize, index);
        let admitted = self.cache.add_face_axes(
            face,
            data,
            index,
            self.provider.face_variation(face),
            axes,
        );
        // Only a font file the pass had never loaded can change line heights it cached; a new
        // axis instance of a known file leaves every other run's metrics alone.
        // 只有此前从未加载过的字体文件才会改变已缓存的行高；已知文件的新轴实例不影响其他 run 的度量。
        if admitted && self.font_files.insert(source) {
            self.forget_measurements();
        }
        admitted
    }

    /// Drop cached sizes and change the font generation so nothing stale is served.
    /// 丢弃已缓存的尺寸并推进字体代数，不再供应任何过期值。
    fn forget_measurements(&mut self) {
        self.measured.clear();
        self.min_widths.clear();
        self.slice_widths.clear();
        self.shaped_spans.clear();
        self.fonts_version = self.fonts_version.wrapping_add(1);
    }

    fn shaper_for(&mut self, face: FaceId) -> Option<&mut Shaper> {
        if !self.shapers.contains_key(&face) {
            if !self.admit_face(face) {
                return None;
            }
            let data = self.provider.face_data(face)?;
            let axes = self.provider.face_axes(face);
            let index = self.provider.face_index(face);
            let weight = self.provider.face_variation(face);
            let shaper = Shaper::new_with_axes(data, index, weight, axes)?;
            self.shapers.insert(face, shaper);
        }
        self.shapers.get_mut(&face)
    }
}

/// One hash over everything that changes how a span shapes: its text, its style and the faces.
/// 把影响片段整形的一切压进一个哈希：文本、样式与字体集合。
fn shape_key(slice: &str, style: &TextStyle, fonts_version: u64) -> u64 {
    use std::hash::{Hash, Hasher};
    let mut h = FastHasher::default();
    fonts_version.hash(&mut h);
    slice.hash(&mut h);
    hash_style(style, &mut h);
    h.finish()
}

/// Bucket key for resolved text. Correctness rests on the exact comparison against the
/// cached primitive, so a collision only costs a recompute; the key just has to separate
/// the primitives a page really has.
/// 已解析文本的分桶键。正确性靠与缓存图元的精确比较，碰撞只是重算一次；键只需把页面上
/// 实际存在的图元分开即可。
fn text_key(text: &TextPrim, scale: f32, fonts_version: u64) -> u64 {
    use std::hash::{Hash, Hasher};
    let mut h = FastHasher::default();
    fonts_version.hash(&mut h);
    text.block.runs.len().hash(&mut h);
    text.block.atoms.len().hash(&mut h);
    text.max_width.to_bits().hash(&mut h);
    scale.to_bits().hash(&mut h);
    text.origin.x.to_bits().hash(&mut h);
    text.origin.y.to_bits().hash(&mut h);
    text.height.to_bits().hash(&mut h);
    // The layout allocation, kept alive by the cached entry, so the address cannot be reused.
    // 布局分配；缓存条目持有它，因此这个地址不会被别处复用。
    text.layout
        .as_ref()
        .map_or(0, |l| std::rc::Rc::as_ptr(l) as usize)
        .hash(&mut h);
    h.finish()
}

/// One hash over everything that changes the measured size of a block.
/// 把影响块测量尺寸的一切压进一个哈希。
fn measure_key(block: &ui_core::TextBlock, max_width: f32, fonts_version: u64) -> u64 {
    use std::hash::{Hash, Hasher};
    let mut h = FastHasher::default();
    fonts_version.hash(&mut h);
    max_width.to_bits().hash(&mut h);
    block.max_lines.hash(&mut h);
    block.line_gap.to_bits().hash(&mut h);
    block.indent.to_bits().hash(&mut h);
    for run in &block.runs {
        run.text.hash(&mut h);
        hash_style(&run.style, &mut h);
    }
    h.finish()
}

/// The style fields that reach face selection, shaping and metrics.
/// 影响字面选择、整形与度量的样式字段。
fn hash_style(style: &TextStyle, h: &mut impl std::hash::Hasher) {
    use std::hash::Hash;
    style.size.to_bits().hash(h);
    style.weight.0.hash(h);
    style.italic.hash(h);
    match style.family {
        Family::Generic(generic) => {
            0u8.hash(h);
            (generic as u8).hash(h);
        }
        Family::Named(name) => {
            1u8.hash(h);
            name.hash(h);
        }
    }
    // Quantised exactly as the face instance is: an animated axis then reuses one entry per
    // step instead of minting a key — and a reshape — on every frame.
    // 与字面实例同样量化：动画中的轴因此每步复用一个条目，而不是每帧造一个新键、再整形一遍。
    style.variations.quantized().hash(h);
    for (tag, value) in style.features.iter() {
        tag.hash(h);
        value.hash(h);
    }
}

/// Record where each glyph's cluster starts, in visual order.
/// 按视觉顺序记录每个字形所属字簇的边界。
///
/// A glyph's left edge is the boundary *before* it in LTR and the boundary *after* its
/// cluster in RTL, because an RTL run is laid out left to right while reading right to left.
/// 字形左缘在 LTR 是它之前的边界，在 RTL 是其字簇之后的边界——RTL 段从左到右排布、从右到左阅读。
fn record_boundaries(
    run: &ShapedRun,
    base: usize,
    run_len: usize,
    rtl: bool,
    pen_x: f32,
    out: &mut Vec<Boundary>,
) {
    if run.glyphs.is_empty() {
        return;
    }
    let mut clusters: Vec<u32> = run.glyphs.iter().map(|g| g.cluster).collect();
    clusters.sort_unstable();
    let after = |c: u32| {
        clusters
            .iter()
            .copied()
            .find(|s| *s > c)
            .unwrap_or(run_len as u32)
    };
    let mut gx = pen_x;
    for glyph in &run.glyphs {
        let byte = if rtl {
            base + after(glyph.cluster) as usize
        } else {
            base + glyph.cluster as usize
        };
        out.push(Boundary { byte, x: gx, rtl });
        gx += glyph.advance;
    }
    let tail = if rtl { base } else { base + run_len };
    out.push(Boundary {
        byte: tail,
        x: gx,
        rtl,
    });
}

/// Left edge of a line inside the wrap width, per the block's alignment.
/// 按块的对齐方式，行在换行宽度内的左边缘。
fn aligned_x(align: ui_core::TextAlign, line_width: f32, max_width: f32, origin_x: f32) -> f32 {
    let spare = if max_width.is_finite() {
        (max_width - line_width).max(0.0)
    } else {
        0.0
    };
    let offset = match align {
        ui_core::TextAlign::Start => 0.0,
        ui_core::TextAlign::Center => spare * 0.5,
        ui_core::TextAlign::End => spare,
    };
    origin_x + offset
}

#[cfg(test)]
mod tests {
    use super::*;
    use ui_core::draw::RectPrim;
    use ui_core::geom::{Color, Corners, Rect};
    use ui_core::NodeId;

    /// The family a style gets when it names none.
    /// 未指定族时样式得到的族。
    const DEFAULT_FAMILY: Family = Family::Generic(GenericFamily::SystemUi);

    /// An unchanged text primitive is reused; anything that changes it resolves again.
    /// 未变的文本图元直接复用；任何改变它的东西都会重新解析。
    ///
    /// Reuse is what makes a still frame cheap, and the exact comparison in `shape_cached` is
    /// what keeps it honest — so both halves are checked here.
    /// 复用才让不动的帧便宜，而 `shape_cached` 里的精确比较保证它不出错——两半都在这里查。
    #[test]
    fn an_unchanged_text_primitive_is_reused_and_a_changed_one_is_not() {
        let mut pass = TextPass::new();
        if !pass.has_face() {
            eprintln!("skipped: no system fonts");
            return;
        }
        let list = text_list("Hello", 24.0);
        let first = pass.resolve(&list, 1.0);
        let resolved = pass.resolve_misses();
        assert!(resolved > 0, "the first pass has nothing to reuse");

        let again = pass.resolve(&list, 1.0);
        assert_eq!(pass.resolve_misses(), resolved, "an unchanged primitive must be reused");
        assert_eq!(first.prims.glyphs, again.prims.glyphs, "reuse must reproduce the glyphs");
        assert_eq!(first.ops, again.ops, "and the op order that places them");

        // Ink is deliberately not in the key: only the exact comparison catches it. This has
        // to come before the scale change, which rasterizes at a new size and restamps the atlas.
        // 墨色刻意不在键里：只有精确比较能发现它。这一项必须在换缩放之前——
        // 后者会按新尺寸光栅并推进图集的戳，把前面的条目一并作废。
        let red = Color::rgba(1.0, 0.0, 0.0, 1.0);
        let mut recoloured = text_list("Hello", 24.0);
        recoloured.prims.texts[0].ink = red;
        let painted = pass.resolve(&recoloured, 1.0);
        assert!(
            painted.prims.glyphs.iter().all(|g| g.color == red),
            "a recoloured label must not reuse the previous ink"
        );

        // The scale reaches glyph placement, so it is part of what makes a primitive its own.
        // 缩放会进入字形定位，因此它属于「这是不是同一个图元」的一部分。
        let before_scale = pass.resolve_misses();
        pass.resolve(&list, 2.0);
        assert!(pass.resolve_misses() > before_scale, "a different scale must resolve again");
    }

    #[test]
    fn a_keycap_sequence_shapes_as_one_colour_glyph() {
        // `3️⃣` is base + VS16 + enclosing keycap; split by code point, the marks fell to a
        // different face and only the bare digit reached the screen.
        // `3️⃣` 是基字符 + VS16 + 封闭键帽；按码点拆分时标记落到别的字面，只剩裸数字上屏。
        let mut pass = TextPass::new();
        if !pass.has_face() {
            eprintln!("skipped: no system fonts");
            return;
        }
        let out = pass.resolve(&text_list("3\u{fe0f}\u{20e3}", 24.0), 1.0);
        if pass.color_atlas().is_empty() {
            eprintln!("skipped: no colour emoji face is installed");
            return;
        }
        let kinds: Vec<_> = out.prims.glyphs.iter().map(|g| g.kind).collect();
        assert_eq!(kinds.len(), 1, "one cluster must shape to one glyph, got {kinds:?}");
        assert_eq!(kinds[0], ui_core::draw::GlyphKind::Color, "a keycap is emoji");
    }

    #[test]
    fn a_digit_after_a_keycap_keeps_its_own_glyph() {
        // An emoji face holds digits only as empty keycap components, so letting it answer
        // for the whole run made every digit after `3️⃣` vanish.
        // emoji 字面的数字只是空白的键帽部件；让它接管整段时，`3️⃣` 之后的数字全部消失。
        let mut pass = TextPass::new();
        if !pass.has_face() {
            eprintln!("skipped: no system fonts");
            return;
        }
        let out = pass.resolve(&text_list("3\u{fe0f}\u{20e3}4", 24.0), 1.0);
        if pass.color_atlas().is_empty() {
            eprintln!("skipped: no colour emoji face is installed");
            return;
        }
        let kinds: Vec<_> = out.prims.glyphs.iter().map(|g| g.kind).collect();
        assert_eq!(kinds, [ui_core::draw::GlyphKind::Color, ui_core::draw::GlyphKind::Coverage]);
    }

    fn text_list(text: &str, size: f32) -> DrawList {
        styled_list(text, ui_core::TextStyle::new(size))
    }

    fn styled_list(text: &str, style: ui_core::TextStyle) -> DrawList {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 400.0, 100.0));
        list.push_text(
            NodeId::from_raw(1, 0),
            TextPrim {
                block: ui_core::TextBlock::plain(text, style),
                origin: ui_core::geom::Point::new(10.0, 20.0),
                ink: Color::WHITE,
                max_width: f32::INFINITY,
                layout: None,
                height: 0.0,
                caret: None,
                selection: None,
                composing: None,
                zoom: None,
            },
        );
        list
    }

    #[test]
    fn a_variable_font_bold_instance_draws_different_pixels() {
        // CJK fonts keep the same advance at every weight, so width cannot detect a
        // missing axis there. The rasterised coverage can.
        // CJK 字体在任何字重下前进宽度都相同，因此宽度无法发现缺失的轴。
        // 光栅出的覆盖率可以。
        let mut pass = TextPass::with_stack(&["MiSans VF"]);
        let regular = pass.stack_for(DEFAULT_FAMILY, ui_core::Weight::REGULAR, false);
        let bold = pass.stack_for(DEFAULT_FAMILY, ui_core::Weight::BOLD, false);
        if regular.is_empty() || regular == bold {
            eprintln!("skipped: MiSans VF unavailable or has no weight instances");
            return;
        }
        // The two stacks must reference different faces, which for a variable font means
        // different instances of the same file.
        // 两个栈必须引用不同字面——对可变字体而言即同一文件的不同实例。
        assert_ne!(regular, bold, "bold must be a distinct instance");
    }

    #[test]
    fn painted_lines_follow_the_same_spacing_the_measurer_used() {
        // The classic drift: measure adds the gap, paint forgets it, and the last line
        // sits inside the box while its glyphs are drawn past the bottom edge.
        // 最典型的漂移：测量加了空隙，绘制忘了加，于是最后一行的字形被画到盒子外。
        let mut pass = TextPass::new();
        if !pass.has_face() {
            eprintln!("skipped: no system fonts");
            return;
        }
        let text = "alpha beta gamma delta epsilon zeta eta theta";
        let width = 90.0;
        let block = |gap: f32| {
            let mut b = ui_core::TextBlock::plain(
                text.to_string(),
                ui_core::TextStyle::new(16.0),
            );
            b.line_gap = gap;
            b
        };
        let tight = block(0.0);
        let loose = block(9.0);
        let tight_h = pass.measure(&tight, width).h;
        let loose_h = pass.measure(&loose, width).h;
        assert!(
            loose_h > tight_h,
            "line_gap must grow the block: {tight_h:.1} vs {loose_h:.1}"
        );

        // Paint each and compare where the ink ends. Comparing one build against itself
        // cannot catch a missing gap on the paint side; comparing two can.
        // 分别绘制并比较墨迹底部。只跟自己比抓不到绘制端漏加空隙；两个对比才能。
        let bottom_of = |pass: &mut TextPass, block: ui_core::TextBlock| -> f32 {
            let mut list = DrawList::new(Rect::new(0.0, 0.0, 400.0, 400.0));
            list.push_text(
                NodeId::from_raw(1, 0),
                TextPrim {
                    block,
                    origin: ui_core::geom::Point::new(0.0, 0.0),
                    max_width: width,
                    layout: None,
                height: 0.0,
                    ink: Color::WHITE,
                    caret: None,
                    selection: None,
                    composing: None,
                    zoom: None,
                },
            );
            pass.resolve(&list, 1.0)
                .prims
                .glyphs
                .iter()
                .map(|g| g.rect.max_y())
                .fold(0.0f32, f32::max)
        };
        let tight_bottom = bottom_of(&mut pass, tight);
        let loose_bottom = bottom_of(&mut pass, loose);
        let grown = loose_bottom - tight_bottom;
        assert!(
            grown > 1.0,
            "paint must apply the gap too: ink grew by only {grown:.1}px"
        );
        // And the ink must still fit the measured box.
        assert!(
            loose_bottom <= loose_h + 1.0,
            "painted glyphs reach {loose_bottom:.1} but the block measures {loose_h:.1}"
        );
    }

    #[test]
    fn the_painter_draws_the_lines_layout_gave_it() {
        // One layout, two consumers: the painter must not wrap again at its own width.
        // 一份布局两处消费：绘制端不得按自己的宽度再断一次行。
        let mut pass = TextPass::new();
        if !pass.has_face() {
            eprintln!("skipped: no system fonts");
            return;
        }
        let block = ui_core::TextBlock::plain(
            "alpha bravo charlie delta",
            ui_core::TextStyle::new(20.0),
        );
        let layout = pass.layout(&block, f32::INFINITY);
        assert_eq!(layout.lines.len(), 1, "the block is one line when unconstrained");
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 400.0, 400.0));
        list.push_text(
            NodeId::from_raw(1, 0),
            TextPrim {
                block,
                origin: ui_core::geom::Point::new(10.0, 10.0),
                // Far narrower than the text: re-wrapping here would stack the words.
                // 远窄于文字：在这里重新换行会把词叠成多行。
                max_width: 20.0,
                layout: Some(layout),
                height: 0.0,
                ink: Color::WHITE,
                caret: None,
                selection: None,
                composing: None,
                zoom: None,
            },
        );
        let out = pass.resolve(&list, 1.0);
        let ink_h = out
            .prims
            .glyphs
            .iter()
            .map(|g| g.rect.max_y())
            .fold(0.0f32, f32::max)
            - out
                .prims
                .glyphs
                .iter()
                .map(|g| g.rect.origin.y)
                .fold(f32::INFINITY, f32::min);
        assert!(
            ink_h < 40.0,
            "the painter re-wrapped the block: its ink is {ink_h:.0} units tall"
        );
    }

    #[test]
    fn a_bold_run_is_wider_than_a_regular_one() {
        // The end-to-end invariant: weight must reach shaping, not just face selection.
        // A different FaceId that still parses byte 0 of the same file shapes identically,
        // which is exactly the bug this pins.
        // 端到端不变量：字重必须到达整形，而不只是选到不同字面。
        // 选了不同 FaceId 却仍解析同一文件的字节 0，整形结果完全相同——正是这里要钉住的 bug。
        let mut pass = TextPass::with_stack(&["Tahoma"]);
        let block = |w: ui_core::Weight| ui_core::TextBlock {
            runs: vec![ui_core::TextRun::new(
                "Hamburgefonstiv".to_string(),
                ui_core::TextStyle::new(24.0).weight(w),
            )],
            align: ui_core::TextAlign::Start,
            max_lines: None,
            line_gap: 0.0,
            indent: 0.0,
            atoms: Vec::new(),
        };
        let regular = pass.measure(&block(ui_core::Weight::REGULAR), f32::INFINITY);
        let bold = pass.measure(&block(ui_core::Weight::BOLD), f32::INFINITY);
        if regular.w <= 0.0 {
            eprintln!("skipped: Tahoma is not available");
            return;
        }
        assert!(
            bold.w > regular.w,
            "bold must be wider: regular={:.2} bold={:.2}",
            regular.w,
            bold.w
        );
    }

    #[test]
    fn a_bold_run_resolves_a_different_face_than_a_regular_one() {
        // The styled stack is what makes weight reach shaping at all; if it returns the
        // same faces, every run rasterises Regular outlines regardless of the request.
        // 带样式的栈是字重能到达整形的唯一通道；若它返回同样的字面，
        // 无论请求什么，每个 run 都按 Regular 的轮廓光栅化。
        let mut pass = TextPass::with_stack(&["DejaVu Sans"]);
        let regular = pass.stack_for(DEFAULT_FAMILY, ui_core::Weight::REGULAR, false);
        let bold = pass.stack_for(DEFAULT_FAMILY, ui_core::Weight::BOLD, false);
        if regular.is_empty() {
            eprintln!("skipped: no system fonts");
            return;
        }
        assert_ne!(
            regular, bold,
            "a bold run must not reuse the regular face stack"
        );
        // The cache must be stable: asking twice cannot drift.
        // 缓存必须稳定：问两次不能漂移。
        assert_eq!(pass.stack_for(DEFAULT_FAMILY, ui_core::Weight::BOLD, false), bold);
    }

    #[test]
    fn the_fill_axis_changes_the_rasterized_coverage() {
        // FILL reshapes the same glyph, so the proof is the atlas: two positions that
        // differ only in this axis must produce different pixels.
        // FILL 改变同一字形的形状，因此证据在图集里：只有这个轴不同的两个位置，
        // 必须产出不同的像素。
        let icon = |fill: f32| {
            ui_core::TextStyle::new(24.0)
                .named("Material Symbols Outlined")
                .variations(ui_core::Variations::NONE.fill(fill))
        };
        let coverage = |pass: &mut TextPass, fill: f32| -> Option<u32> {
            let out = pass.resolve(&styled_list("\u{e88a}", icon(fill)), 1.0);
            let glyph = *out.prims.glyphs.first()?;
            let (width, _) = pass.dimensions();
            let atlas = pass.atlas();
            let mut sum = 0u32;
            for y in glyph.atlas.origin.y as u32..glyph.atlas.max_y() as u32 {
                for x in glyph.atlas.origin.x as u32..glyph.atlas.max_x() as u32 {
                    sum += u32::from(atlas[(y * width + x) as usize]);
                }
            }
            Some(sum)
        };
        let mut pass = TextPass::new();
        if !pass.has_face() {
            eprintln!("skipped: no system fonts");
            return;
        }
        let (Some(outlined), Some(filled)) = (coverage(&mut pass, 0.0), coverage(&mut pass, 1.0))
        else {
            eprintln!("skipped: Material Symbols Outlined is not installed");
            return;
        };
        assert!(outlined > 0, "the outlined glyph must ink the atlas");
        assert!(
            filled > outlined,
            "FILL 1 must ink more than FILL 0: {outlined} vs {filled}"
        );
    }

    #[test]
    fn an_icon_run_does_not_poison_the_latin_stack() {
        // PUA icons read as Script::LATIN, so a face cache keyed by script alone let the
        // icon face answer for later Latin text — the font's ligature component glyphs.
        // PUA 图标会被判为 Script::LATIN；只按脚本做键的字面缓存会让图标字面替
        // 后来的拉丁文本作答——用的是字体里给连字预留的部件字形。
        let icon = || {
            styled_list(
                "\u{e88a}",
                ui_core::TextStyle::new(24.0).named("Material Symbols Outlined"),
            )
        };
        let latin = || styled_list("Hamburgefonstiv", ui_core::TextStyle::new(16.0));

        let mut shared = TextPass::new();
        if !shared.has_face() {
            eprintln!("skipped: no system fonts");
            return;
        }
        if shared.resolve(&icon(), 1.0).prims.glyphs.is_empty() {
            eprintln!("skipped: Material Symbols Outlined is not installed");
            return;
        }
        let pen = |list: DrawList, pass: &mut TextPass| -> Vec<f32> {
            pass.resolve(&list, 1.0)
                .prims
                .glyphs
                .iter()
                .map(|g| g.rect.origin.x)
                .collect()
        };
        let after_icon = pen(latin(), &mut shared);
        let mut fresh = TextPass::new();
        let alone = pen(latin(), &mut fresh);
        assert_eq!(
            after_icon, alone,
            "an icon run must not change how Latin is shaped"
        );
    }

    #[test]
    fn resolve_replaces_text_with_glyphs() {
        let mut pass = TextPass::new();
        if !pass.has_face() {
            return;
        }
        let out = pass.resolve(&text_list("Hi", 24.0), 1.0);
        assert!(out.prims.texts.is_empty(), "text must be consumed");
        assert_eq!(out.prims.glyphs.len(), 2, "one glyph per visible char");
        assert_eq!(pass.unresolved(), 0);
    }

    #[test]
    fn resolved_glyphs_follow_the_pen_direction() {
        let mut pass = TextPass::new();
        if !pass.has_face() {
            return;
        }
        let out = pass.resolve(&text_list("III", 24.0), 1.0);
        let xs: Vec<f32> = out.prims.glyphs.iter().map(|g| g.rect.origin.x).collect();
        assert!(
            xs.windows(2).all(|w| w[0] <= w[1]),
            "LTR pen must not go backwards: {xs:?}"
        );
    }

    #[test]
    fn unresolved_text_is_reported_and_preserved() {
        let mut pass = TextPass::isolated();
        assert!(!pass.has_face(), "isolated pass must not claim a face");
        let out = pass.resolve(&text_list("Hi", 24.0), 1.0);
        assert_eq!(out.prims.texts.len(), 1, "text kept for the CPU fallback");
        assert!(out.prims.glyphs.is_empty());
        assert_eq!(pass.unresolved(), 1);
    }

    #[test]
    fn a_repeated_measurement_is_served_from_the_cache() {
        // Layout measures every label every frame; only a new block or width may recompute.
        // 布局每帧都要测量每个标签；只有新块或新宽度才允许重算。
        let mut pass = TextPass::isolated();
        let block = ui_core::TextBlock::plain("Row", ui_core::TextStyle::new(14.0));
        let first = pass.measure(&block, f32::INFINITY);
        let misses = pass.measure_misses();
        assert_eq!(pass.measure(&block, f32::INFINITY), first);
        assert_eq!(pass.measure_misses(), misses, "a repeat must not recompute");
        pass.measure(&block, 40.0);
        assert_eq!(
            pass.measure_misses(),
            misses + 1,
            "a different wrap width is a different measurement"
        );
    }

    #[test]
    fn non_text_primitives_keep_their_order_and_paint_order() {
        let mut pass = TextPass::isolated();
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 200.0, 100.0));
        list.push_rect(
            NodeId::from_raw(1, 0),
            RectPrim {
                rect: Rect::new(0.0, 0.0, 10.0, 10.0),
                radius: Corners::ZERO,
                fill: Color::BLACK,
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
        list.push_text(
            NodeId::from_raw(2, 0),
            TextPrim {
                block: ui_core::TextBlock::plain(
                    "x",
                    ui_core::TextStyle::new(12.0),
                ),
                origin: ui_core::geom::Point::new(0.0, 0.0),
                ink: Color::WHITE,
                max_width: f32::INFINITY,
                layout: None,
                height: 0.0,
                caret: None,
                selection: None,
                composing: None,
                zoom: None,
            },
        );
        let out = pass.resolve(&list, 1.0);
        assert_eq!(out.prims.rects.len(), 1);
        assert_eq!(out.ops.len(), 2, "one op per primitive, order preserved");
        assert!(matches!(out.ops[0], Op::Prim(p) if p.kind == PrimKind::Rect));
        assert!(matches!(out.ops[1], Op::Prim(p) if p.kind == PrimKind::Text));
    }

    #[test]
    fn atlas_version_bumps_only_when_new_coverage_appears() {
        let mut pass = TextPass::new();
        if !pass.has_face() {
            return;
        }
        let list = text_list("A", 20.0);
        pass.resolve(&list, 1.0);
        let after_first = pass.version();
        assert!(after_first > 0, "first resolve must rasterize");

        pass.resolve(&list, 1.0);
        assert_eq!(
            pass.version(),
            after_first,
            "cached glyphs must not bump the version"
        );

        pass.resolve(&text_list("B", 20.0), 1.0);
        assert!(pass.version() > after_first, "new glyph must bump the version");
    }

    #[test]
    fn unknown_stack_names_never_claim_a_face() {
        // Deterministic: with no font source at all, a stack of unknown names must leave
        // the pass without a face rather than silently pretending it has one.
        // 确定性：完全没有字体来源时，一串未知名字必须让 pass 没有字面，
        // 而不是悄悄假装有。
        let unknown = TextPass::with_stack(&["__no_such_family__", "__also_missing__"]);
        let plain = TextPass::new();
        assert_eq!(
            unknown.has_face(),
            plain.has_face(),
            "unknown names must be ignored, leaving the platform generic in charge"
        );
    }

    #[test]
    fn a_loadable_stack_entry_survives_an_unknown_one_in_front() {
        // Needs a real font: fontconfig can list families whose files are missing, so
        // this pins that the *second* entry still takes effect.
        // 需要真实字体：fontconfig 可能列出文件已缺失的族，
        // 本条钉住"第二个条目仍然生效"。
        let stack = TextPass::with_stack(&["__no_such_family__", "Tahoma"]);
        if !stack.has_face() {
            return;
        }
        let mut pass = stack;
        let out = pass.resolve(&text_list("Hi", 20.0), 1.0);
        assert!(!out.prims.glyphs.is_empty(), "the loadable entry must be used");
        assert_eq!(pass.unresolved(), 0);
    }

    /// A text primitive sized like the paint path sees it: the node hugs the text.
    /// 一个与绘制端看到的一致文本图元：节点贴合文字宽度。
    fn prim_of(pass: &mut TextPass, text: &str, size: f32) -> Option<TextPrim> {
        let block = ui_core::TextBlock::plain(text, ui_core::TextStyle::new(size));
        let natural = pass.measure(&block, f32::INFINITY).w;
        if natural <= 0.0 {
            return None;
        }
        Some(TextPrim {
            block,
            origin: ui_core::geom::Point::new(10.0, 20.0),
            ink: Color::WHITE,
            max_width: natural,
            layout: None,
            height: 0.0,
            caret: None,
            selection: None,
            composing: None,
            zoom: None,
        })
    }

    #[test]
    fn a_zoomed_text_runs_its_glyphs_through_the_same_transform() {
        // Text is shaped before the scale is known; the pass must place the glyphs through
        // it anyway, or a scaled subtree would keep full-size text.
        // 文本在知道缩放之前就已成形；解析趟仍必须让字形走一遍缩放，
        // 否则被缩放的子树会保留原尺寸的文字。
        let mut pass = TextPass::new();
        if !pass.has_face() {
            eprintln!("skipped: no system fonts");
            return;
        }
        let Some(prim) = prim_of(&mut pass, "alpha bravo", 20.0) else {
            eprintln!("skipped: the text measured empty");
            return;
        };
        let canvas = Rect::new(0.0, 0.0, 400.0, 400.0);
        let mut plain = DrawList::new(canvas);
        plain.push_text(NodeId::from_raw(1, 0), prim.clone());
        let unzoomed = pass.resolve(&plain, 1.0);
        if unzoomed.prims.glyphs.is_empty() {
            eprintln!("skipped: no glyphs rasterized");
            return;
        }

        let t = ui_core::draw::Transform::about(ui_core::geom::Point::new(50.0, 50.0), 0.5);
        let mut zoomed = DrawList::new(canvas);
        zoomed.push_text(
            NodeId::from_raw(1, 0),
            TextPrim {
                zoom: Some(t),
                ..prim
            },
        );
        let out = pass.resolve(&zoomed, 1.0);
        assert_eq!(out.prims.glyphs.len(), unzoomed.prims.glyphs.len());
        assert_eq!(
            out.prims.glyphs[0].rect,
            t.apply_rect(unzoomed.prims.glyphs[0].rect),
            "the first glyph must land where the transform puts it"
        );
    }

    #[test]
    fn a_click_lands_on_the_caret_it_was_aimed_at() {
        // The two directions must agree: the x a caret sits at must hit-test back to the
        // same byte, or clicks land one character off and a drag creeps as it moves.
        // 两个方向必须一致：插入符所在的 x 必须命中回同一个字节，
        // 否则点击差一个字符、拖选会一路爬。
        let mut pass = TextPass::with_stack(&["Tahoma"]);
        let Some(prim) = prim_of(&mut pass, "Hamburgefonstiv", 20.0) else {
            eprintln!("skipped: Tahoma is not available");
            return;
        };
        for at in [0usize, 1, 4, 9, 15] {
            let caret = pass.caret_rect(&prim, at, 1.0).expect("a caret");
            let back = pass.index_at(
                &prim,
                ui_core::geom::Point::new(
                    caret.origin.x + caret.size.w * 0.5,
                    caret.origin.y + caret.size.h * 0.5,
                ),
                1.0,
            );
            assert_eq!(back, at, "the caret at byte {at} must hit-test back to it");
        }
    }

    #[test]
    fn a_selection_across_a_wrap_reports_one_fragment_per_line() {
        // One rect per visual line piece: a painter must never have to re-break the text,
        // and a selection that spans a wrap must cover both lines.
        // 每段视觉行一个矩形：绘制程序绝不该重新断行，跨换行的选区必须覆盖两行。
        let mut pass = TextPass::with_stack(&["Tahoma"]);
        let block =
            ui_core::TextBlock::plain("alpha bravo charlie delta", ui_core::TextStyle::new(20.0));
        let natural = pass.measure(&block, f32::INFINITY).w;
        if natural <= 0.0 {
            eprintln!("skipped: Tahoma is not available");
            return;
        }
        let len = block.flatten().0.len();
        let prim = TextPrim {
            block,
            origin: ui_core::geom::Point::new(10.0, 20.0),
            ink: Color::WHITE,
            max_width: natural * 0.5,
            layout: None,
                height: 0.0,
            caret: None,
            selection: None,
            composing: None,
            zoom: None,
        };
        let frags = pass.selection_fragments(&prim, 0..len, 1.0);
        assert!(
            frags.len() >= 2,
            "the selection must span at least two lines, got {}",
            frags.len()
        );
        assert!(frags[0].first, "the first fragment must say so");
        assert!(!frags[0].last, "one fragment cannot be both ends");
        assert!(frags.last().is_some_and(|f| f.last));
        assert!(
            frags[1].rect.origin.y > frags[0].rect.origin.y,
            "the second fragment must sit on the next line"
        );
        for fragment in &frags {
            assert!(
                fragment.rect.size.w > 0.0,
                "a fragment with no width would paint nothing"
            );
        }
    }

    #[test]
    fn a_click_on_a_wrapped_line_lands_in_that_line() {
        // Boundaries are built per line; the hit test must still answer in block bytes,
        // or every click below the first line selects text from the first one.
        // 边界按行构建；命中测试仍须回答整块字节，否则首行以下的每次点击都选中首行的文字。
        let mut pass = TextPass::with_stack(&["Tahoma"]);
        let block =
            ui_core::TextBlock::plain("alpha bravo charlie delta", ui_core::TextStyle::new(20.0));
        let natural = pass.measure(&block, f32::INFINITY).w;
        if natural <= 0.0 {
            eprintln!("skipped: Tahoma is not available");
            return;
        }
        let width = natural * 0.5;
        let layout = pass.layout(&block, width);
        assert!(layout.lines.len() >= 2, "the block must wrap for this test");
        let prim = TextPrim {
            block,
            origin: ui_core::geom::Point::new(10.0, 20.0),
            ink: Color::WHITE,
            max_width: width,
            layout: None,
                height: 0.0,
            caret: None,
            selection: None,
            composing: None,
            zoom: None,
        };
        // Click at the left edge of the second line: the answer must be that line's first
        // byte, not byte 0 (which is what line-relative boundaries would report).
        // 点第二行的左缘：答案必须是该行的首字节，而不是 0（行内偏移会给出 0）。
        let second = layout.lines[1].range();
        let caret = pass
            .caret_rect(&prim, second.start, 1.0)
            .expect("a caret on the second line");
        let at = pass.index_at(
            &prim,
            ui_core::geom::Point::new(prim.origin.x + 1.0, caret.origin.y + caret.size.h * 0.5),
            1.0,
        );
        assert!(
            at >= second.start,
            "a click at the start of line 2 ({second:?}) must answer at or past it, got {at}"
        );
    }

    #[test]
    fn an_rtl_run_puts_its_first_byte_on_the_right() {
        // Arabic reads right to left: byte 0 sits at the right edge, so the caret for the
        // start of the text must be to the *right* of the caret for its end.
        // 阿拉伯文从右到左：第 0 个字节在右缘，文本起点的插入符必须在终点插入符的**右边**。
        let mut pass = TextPass::with_stack(&["Tahoma"]);
        let Some(prim) = prim_of(&mut pass, "مرحبا", 20.0) else {
            eprintln!("skipped: no face covers Arabic");
            return;
        };
        let start = pass.caret_rect(&prim, 0, 1.0).expect("a caret at the start");
        let end = pass
            .caret_rect(&prim, prim.block.flatten().0.len(), 1.0)
            .expect("a caret at the end");
        assert!(
            start.origin.x > end.origin.x,
            "RTL text starts on the right: start {:.1} vs end {:.1}",
            start.origin.x,
            end.origin.x
        );
    }

    #[test]
    fn a_line_block_centres_in_a_taller_node_box() {
        // `origin` is the node's box top and the line block sits centred in it; pinning the
        // block to the top is what left every 1.4 em icon slot hanging high.
        // `origin` 是节点盒顶，行块在盒中居中；把行块钉在顶部正是所有 1.4em 图标槽吊高的原因。
        let mut pass = TextPass::with_stack(&["Tahoma"]);
        let Some(mut prim) = prim_of(&mut pass, "Hamburgefonstiv", 20.0) else {
            eprintln!("skipped: Tahoma is not available");
            return;
        };
        let line_h = pass.measure(&prim.block, f32::INFINITY).h;
        let top_at_zero = pass.caret_rect(&prim, 0, 1.0).expect("a caret").origin.y;
        prim.height = line_h + 20.0;
        let top_in_tall_box = pass.caret_rect(&prim, 0, 1.0).expect("a caret").origin.y;
        assert_eq!(
            top_in_tall_box - top_at_zero,
            10.0,
            "20 dp of spare box height must split evenly above and below the block"
        );
    }

    #[test]
    fn the_painted_caret_sits_where_the_geometry_query_says() {
        // Paint and the query must share one geometry: a caret drawn from a second
        // prefix-shaping pass is free to drift from what clicks and the IME rectangle use.
        // 绘制与查询必须共用同一套几何：另起一次前缀整形画出的插入符，
        // 可以自由地漂离点击与 IME 矩形所用的位置。
        let mut pass = TextPass::with_stack(&["Tahoma"]);
        let Some(mut prim) = prim_of(&mut pass, "Hamburgefonstiv", 20.0) else {
            eprintln!("skipped: Tahoma is not available");
            return;
        };
        prim.caret = Some(ui_core::Caret {
            offset: 5,
            color: Color::WHITE,
        });
        let expected = pass.caret_rect(&prim, 5, 1.0).expect("a caret");
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 400.0, 100.0));
        list.push_text(NodeId::from_raw(1, 0), prim);
        let out = pass.resolve(&list, 1.0);
        let painted = out.prims.rects.last().expect("the caret rect");
        assert_eq!(
            painted.rect, expected,
            "the painted caret must be the rect the query reports"
        );
    }

    #[test]
    fn an_emoji_in_a_line_reaches_the_colour_atlas() {
        let mut pass = TextPass::new();
        if !pass.has_face() {
            eprintln!("skipped: no system fonts");
            return;
        }
        let list = text_list("hi\u{1F600}there", 24.0);
        let out = pass.resolve(&list, 1.0);
        let colour = out
            .prims
            .glyphs
            .iter()
            .filter(|g| g.kind == ui_core::draw::GlyphKind::Color)
            .count();
        if pass.color_atlas().is_empty() {
            eprintln!("skipped: no colour emoji face is installed");
            return;
        }
        assert!(
            colour > 0,
            "the emoji must become a colour glyph, got {} glyphs and no colour entry",
            out.prims.glyphs.len()
        );
        // The other characters must stay on the coverage path.
        // 其余字符必须仍在覆盖率路径上。
        assert!(
            out.prims
                .glyphs
                .iter()
                .any(|g| g.kind == ui_core::draw::GlyphKind::Coverage),
            "Latin characters must not be redirected to the colour page"
        );
    }
}
