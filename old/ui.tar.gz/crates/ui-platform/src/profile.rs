//! Frame-phase timing for the `profile` feature.
//! 供 `profile` 特性使用的帧阶段计时。

/// Times a block with hotpath under the `profile` feature, and is the block itself otherwise.
/// 开启 `profile` 特性时用 hotpath 给该块计时，否则就是该块本身。
macro_rules! timed {
    ($label:literal, $body:expr) => {{
        #[cfg(feature = "profile")]
        {
            hotpath::measure_block!($label, $body)
        }
        #[cfg(not(feature = "profile"))]
        {
            $body
        }
    }};
}
