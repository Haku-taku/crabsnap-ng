//! The frame driver: intake, demand, pacing — everything a loop would otherwise repeat.
//! 帧驱动：事件摄入、帧需求、配速——主循环否则要重复的一切。

use std::time::{Duration, Instant};

use ui_core::geom::Point;
use ui_core::Event;

use crate::view::{App, AppLoop};

/// What a driver needs from the platform window.
/// 驱动需要平台窗口提供的一切。
///
/// The window implements this once; an app never re-derives the loop's rules from it.
/// 窗口实现一次即可；应用不必再从它推导循环规则。
pub trait FrameHost {
    /// Surface size in physical pixels.
    /// 表面尺寸，物理像素。
    fn size(&self) -> (u32, u32);
    fn scale(&self) -> f32;
    fn pointer(&self) -> Option<Point>;
    /// Whether the compositor has opened a frame window (a frame callback arrived).
    /// compositor 是否已打开帧窗口（帧回调已到）。
    fn can_draw(&self) -> bool;
    /// Block until some event arrives or `timeout` passes; true when events are waiting.
    /// The engine's own deadlines (the caret's blink) ride on this.
    /// 阻塞到有事件到达或 `timeout` 到期；有事件在等时返回真。
    /// 引擎自己的截止时间（插入符闪烁）靠它按期醒来。
    fn wait_until(&mut self, timeout: Option<Duration>) -> bool;
    /// Block until some event arrives.
    /// 阻塞到有事件到达。
    fn wait(&mut self) {
        let _ = self.wait_until(None);
    }
    /// Block until the compositor's frame callback arrives.
    /// 阻塞到 compositor 的帧回调到达。
    fn wait_for_frame(&mut self);
    fn should_close(&self) -> bool;
    /// Events since the last call, in arrival order.
    /// 上一次调用以来到达的事件，按顺序。
    fn take_events(&mut self) -> Vec<Event>;
    /// A change the app made outside `view`, which arrives without an `Event`.
    /// 应用在 `view` 之外做的、不经 `Event` 到达的变更。
    fn take_silent_change(&mut self) -> bool;
}

/// What this turn should do; the driver has already slept or waited when it returns.
/// 本轮该做什么；返回时驱动已经把该睡的睡完、该等的等完。
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Turn {
    /// Nothing an event could change: the driver slept.
    /// 没有事件能改变的东西：驱动已经睡过。
    Idle,
    /// A frame is wanted, but the compositor has not opened the window yet.
    /// 想要一帧，但 compositor 尚未打开帧窗口。
    Waiting,
    /// Build and present now.
    /// 现在构建并提交。
    Draw { pointer: Option<Point> },
}

/// Owns the loop's state: demand, pacing and the last surface size.
/// 持有循环的状态：帧需求、配速与上一次的表面尺寸。
///
/// The states mirror GPUI's platform `FrameLoop`: a frame is wanted (`Ticking`), then the
/// loop waits for the callback (`AwaitingCallback`), then it draws again.
/// 状态对齐 GPUI 平台层的 `FrameLoop`：想要一帧（`Ticking`）→ 等回调（`AwaitingCallback`）
/// → 再画。
pub struct Driver {
    /// Ask for a frame on every turn instead of one per compositor callback.
    /// 每轮都要一帧，而不是每个 compositor 回调一帧。
    uncapped: bool,
    /// A frame was wanted on an earlier turn and has not been drawn yet.
    /// 之前的轮次想要一帧，但还没画。
    pending: bool,
    last_size: Option<(u32, u32)>,
    waited: Duration,
    waited_n: u32,
    last_wait: Duration,
    /// Events taken from the host this turn, kept for the caller's diagnostics.
    /// 本轮从窗口取到的事件，留给调用方做诊断。
    events: Vec<Event>,
}

impl Default for Driver {
    fn default() -> Self {
        Self::new()
    }
}

impl Driver {
    pub fn new() -> Self {
        Self {
            uncapped: false,
            pending: false,
            last_size: None,
            waited: Duration::ZERO,
            waited_n: 0,
            last_wait: Duration::ZERO,
            events: Vec::new(),
        }
    }

    /// Events taken from the host on the last `step`, already dispatched to the app.
    /// 上一次 `step` 从窗口取到的事件（已派发给应用）。
    pub fn events(&self) -> &[Event] {
        &self.events
    }

    /// Drop the one-frame-per-callback gate. A stress knob, not a mode: frames the
    /// compositor never draws are neither shown nor counted.
    /// 去掉「每个回调一帧」的门。压测旋钮而非模式：compositor 没画的帧既不显示也不计数。
    pub fn uncapped(mut self, on: bool) -> Self {
        self.uncapped = on;
        self
    }

    /// Time spent waiting for frame callbacks, and how many waits that was.
    /// 等待帧回调的总时长，以及等待次数。
    pub fn wait_stats(&self) -> (Duration, u32) {
        (self.waited, self.waited_n)
    }

    /// How long the last `step` waited for a frame callback; a long one means a stalled
    /// output. The deadline that ends such a wait belongs to the window, not the caller.
    /// 上一次 `step` 等帧回调的时长；很长说明输出停住了。结束这种等待的截止时间属于窗口，
    /// 不属于调用方。
    pub fn last_wait(&self) -> Duration {
        self.last_wait
    }

    /// After a drawn frame: wait for the compositor's callback, so the next turn starts
    /// inside a fresh frame window. Skipped while uncapped.
    /// 画完一帧后等 compositor 的回调，使下一轮落在一个新的帧窗口里。取消帧率上限时跳过。
    pub fn pace(&mut self, host: &mut dyn FrameHost) {
        if self.uncapped {
            return;
        }
        let started = Instant::now();
        host.wait_for_frame();
        self.last_wait = started.elapsed();
        self.waited += self.last_wait;
        self.waited_n += 1;
    }

    /// Intake events, decide, and sleep or wait as the decision requires.
    /// 摄入事件、做判定，并按判定结果睡觉或等待。
    ///
    /// A resized surface counts as demand even with no event: layout still has to run.
    /// 尺寸变化即使没有事件也算需求：布局仍要重跑。
    pub fn step<A: App>(&mut self, lp: &mut AppLoop<A>, host: &mut dyn FrameHost) -> Turn {
        self.last_wait = Duration::ZERO;
        if host.should_close() {
            return Turn::Idle;
        }
        self.events = host.take_events();
        for event in &self.events {
            lp.dispatch(event.clone());
        }
        let size = host.size();
        self.pending |= lp.take_dispatched()
            || host.take_silent_change()
            || lp.is_animating()
            || self.last_size != Some(size);
        // Consumed once: a turn that waits for the callback must still draw afterwards.
        // 只消费一次：等了回调的那一轮之后仍必须画。
        if !self.pending {
            let wake = lp.next_wake();
            if host.wait_until(wake) || wake.is_none() {
                // An event arrived (the next turn dispatches it), or nothing is timed to
                // happen on its own.
                // 有事件到了（下一轮派发它），或者没有任何东西会自己到期。
                return Turn::Idle;
            }
            // Nothing arrived, and the engine's own deadline did: the caret's toggle is
            // the demand. Without this the wait would swallow it until unrelated input.
            // 没有事件，但引擎自己的截止时间到了：插入符的明灭就是这次需求。
            // 否则这次等待会把它一直吞到下一次无关输入。
            self.pending = true;
        }
        if !self.uncapped && !host.can_draw() {
            let started = Instant::now();
            host.wait_for_frame();
            self.last_wait = started.elapsed();
            self.waited += self.last_wait;
            self.waited_n += 1;
            // Drawing in this turn keeps the gap between the callback and the commit as
            // short as the frame itself; a second turn costs a missed vblank.
            // 在同一轮里画，回调到提交之间的间隙才只等于这一帧；多走一轮会丢一个 vblank。
            if !host.can_draw() {
                return Turn::Waiting;
            }
        }
        self.pending = false;
        self.last_size = Some(size);
        // The app no longer reads the window's scale: it is layout input, so the driver sets it.
        // 应用不再自己去读窗口缩放：它是布局输入，由驱动设置。
        lp.set_scale(host.scale());
        Turn::Draw {
            pointer: host.pointer(),
        }
    }
}
