//! What the engine needs from a live control: a declaration, children, and a change.
//! 引擎对「活控件」的要求：一份声明、子元素，以及语义变化。

use ui_core::change::Change;
use ui_core::geom::Rect;
use ui_core::memo::CachedKey;
use ui_core::{Decl, Id, NodeKind};

use crate::state::WidgetState;

/// One node of the live control tree, alive for the whole frame.
/// 活控件树的一个节点，在整个帧内存活。
///
/// Style-free: styles are already resolved into the declaration, so a container and a
/// themed slider are the same kind of thing here.
/// 与样式无关：样式已解析进声明，因此容器与主题化滑块在这里是同类。
pub trait Element {
    /// This frame's declaration, built from the engine context.
    /// 本帧声明，由引擎上下文构建。
    fn decl(&self, cx: &mut ui_core::cx::Cx<'_>) -> Decl;

    /// Child elements in paint order; empty for a leaf.
    /// 子元素，按绘制顺序；叶子为空。
    fn children(&self) -> &[Box<dyn Element>] {
        &[]
    }

    /// This frame's semantic change, or `None`. Called after layout, so `bounds` is final.
    /// 本帧的语义变化，或 `None`。布局后调用，因此 `bounds` 是最终几何。
    fn change(&self, _state: &WidgetState, _bounds: Rect) -> Option<Change> {
        None
    }

    /// Identity and a fingerprint of this element's own inputs, when both are known
    /// without building. Supplying one promises that everything `decl` reads beyond the
    /// context is inside the fingerprint.
    /// 不构建即可给出的身份与自身输入指纹。给出它即承诺：`decl` 除上下文之外读到的一切
    /// 都在指纹里。
    fn cache_key(&self) -> Option<CachedKey> {
        None
    }

    /// Whether the cached declaration still says what this element says now. A container
    /// compares the shell it built against the cached one, field by field.
    /// 缓存声明是否仍与本元素现在说的一致。容器把自建的外壳与缓存中的那份逐字段比对。
    fn cache_matches(&self, _cached: &Decl) -> bool {
        true
    }

    /// This frame's declaration, already shared, for an element that holds one finished.
    /// Handing out the `Rc` itself skips a deep clone of text blocks and shape lists.
    /// 本帧声明，已经是共享形态，供持有成品声明的元素使用：直接交出 `Rc`，
    /// 省掉文本块与形状表的一次深拷贝。
    fn decl_shared(&self) -> Option<std::rc::Rc<Decl>> {
        None
    }
}

/// Build one child's declaration, reusing the cached subtree when its facts still hold.
/// 构建一个子元素的声明；其事实未变时复用缓存的子树。
///
/// The cache is only as sound as the app's invalidation: state the engine cannot see must
/// be announced with `changed` or `Cx::invalidate_decls`.
/// 缓存的可信度取决于 app 的失效声明：引擎看不见的状态必须用 `changed` 或
/// `Cx::invalidate_decls` 上报。
pub fn element_decl(el: &dyn Element, cx: &mut ui_core::cx::Cx<'_>) -> std::rc::Rc<Decl> {
    if let Some(shared) = el.decl_shared() {
        return shared;
    }
    // Probe: `CRABSNAP_NO_DECL_CACHE=1` rebuilds every declaration, so an A/B can price reuse.
    // 探针：`CRABSNAP_NO_DECL_CACHE=1` 每帧都重建声明，A/B 才能给复用定价。
    let key = el.cache_key().filter(|_| decl_cache_enabled());
    let Some(key) = key else {
        // No key: this child is rebuilt, so the parent's declaration is no longer provable.
        // 没有键：这个子元素被重建，父节点的声明因此不再可证。
        cx.note_rebuilt_child();
        return std::rc::Rc::new(el.decl(cx));
    };
    if let Some(hit) = cx.cached_decl_matching(key, |cached| el.cache_matches(cached)) {
        return hit;
    }
    // A miss rebuilt this child, so whatever encloses it cannot be reused this frame.
    // 未命中意味着这个子元素被重建，包着它的那一层本帧因此不能复用。
    cx.note_rebuilt_child();
    cx.begin_record();
    let decl = el.decl(cx);
    // A key that disagrees with the declaration would poison every later lookup.
    // 键与声明根不一致会污染之后每一次查找。
    debug_assert_eq!(decl.id, key.id, "a cache key must be the declaration's root id");
    cx.end_record(key, decl)
}

/// Read once: the answer cannot change within a run, and this is asked once per element.
/// 只读一次：同一次运行内答案不会变，而每个元素都会问它。
fn decl_cache_enabled() -> bool {
    static ON: std::sync::OnceLock<bool> = std::sync::OnceLock::new();
    *ON.get_or_init(|| std::env::var_os("CRABSNAP_NO_DECL_CACHE").is_none())
}

/// Forwarding so `Box<dyn Element>` composes without ceremony.
/// 泛型转发，使 `Box<dyn Element>` 无需额外包装即可组合。
impl Element for Box<dyn Element> {
    fn decl(&self, cx: &mut ui_core::cx::Cx<'_>) -> Decl {
        (**self).decl(cx)
    }

    fn children(&self) -> &[Box<dyn Element>] {
        (**self).children()
    }

    fn change(&self, state: &WidgetState, bounds: Rect) -> Option<Change> {
        (**self).change(state, bounds)
    }

    fn cache_key(&self) -> Option<CachedKey> {
        (**self).cache_key()
    }

    fn cache_matches(&self, cached: &Decl) -> bool {
        (**self).cache_matches(cached)
    }

    fn decl_shared(&self) -> Option<std::rc::Rc<Decl>> {
        (**self).decl_shared()
    }
}

/// A node with no children and no interaction: text, a painted box.
/// 无子节点、无交互的节点：文本、绘制的盒子。
pub struct Leaf {
    decl: std::rc::Rc<Decl>,
}

impl Leaf {
    pub fn new(decl: Decl) -> Self {
        Self { decl: std::rc::Rc::new(decl) }
    }
}

/// Wrap a finished declaration as an element with no children and no change.
/// 把已完成的声明包成无子节点、无变化的元素。
pub fn from_decl(decl: Decl) -> Box<dyn Element> {
    Box::new(Leaf::new(decl))
}

impl Element for Leaf {
    fn decl(&self, _cx: &mut ui_core::cx::Cx<'_>) -> Decl {
        (*self.decl).clone()
    }

    fn decl_shared(&self) -> Option<std::rc::Rc<Decl>> {
        Some(std::rc::Rc::clone(&self.decl))
    }
}

/// Arranges children; reports no change. Its own fields are a childless `Decl`, so the
/// node's semantics live in exactly one place.
/// 排列子元素，不上报变化。自身字段就是一份无子节点的 `Decl`，因此节点语义只有一处定义。
pub struct Container {
    own: Decl,
    children: Vec<Box<dyn Element>>,
}

impl Container {
    /// A flow container: `Row`, `Column`, `Stack` or `Overlay`.
    /// 流式容器：`Row`、`Column`、`Stack` 或 `Overlay`。
    pub fn new(id: Id, kind: NodeKind) -> Self {
        Self {
            own: Decl::container(id, kind),
            children: Vec::new(),
        }
    }

    /// Wrap an already-built childless declaration, e.g. one carrying effects.
    /// 包装一份已建好的无子节点声明，例如带效果链的那种。
    pub fn from_decl(own: Decl) -> Self {
        Self {
            own,
            children: Vec::new(),
        }
    }

    pub fn id(&self) -> Id {
        self.own.id
    }

    /// Edit the node's own declaration; covers every `Decl` field without mirroring it.
    /// 编辑节点自身声明；覆盖 `Decl` 的全部字段而不必逐一镜像。
    pub fn map(mut self, f: impl FnOnce(Decl) -> Decl) -> Self {
        self.own = f(self.own);
        self
    }

    pub fn child(mut self, child: Box<dyn Element>) -> Self {
        self.children.push(child);
        self
    }

    pub fn children(mut self, children: impl IntoIterator<Item = Box<dyn Element>>) -> Self {
        self.children.extend(children);
        self
    }

    /// Add a child only when the condition holds, keeping call sites flat.
    /// 条件成立时才加子元素，使调用点保持扁平。
    pub fn child_if(mut self, yes: bool, child: impl FnOnce() -> Box<dyn Element>) -> Self {
        if yes {
            self.children.push(child());
        }
        self
    }

    /// Add a finished declaration as a static child with no liveness.
    /// 把已完成的声明加为无生命周期的静态子元素。
    pub fn child_decl(mut self, decl: Decl) -> Self {
        self.children.push(Box::new(Leaf::new(decl)));
        self
    }

    pub fn gap(mut self, gap: f32) -> Self {
        self.own = self.own.gap(gap);
        self
    }

    pub fn padding(mut self, p: ui_core::Insets) -> Self {
        self.own = self.own.padding(p);
        self
    }

    pub fn size(mut self, size: ui_core::SizeClass) -> Self {
        self.own = self.own.size(size);
        self
    }

    pub fn background(mut self, fill: ui_core::geom::Color, radius: ui_core::geom::Corners) -> Self {
        self.own = self.own.background(fill, radius);
        self
    }

    /// Draw a registered texture under this container's children, over its fill.
    /// 在本容器的子节点之下、填充之上绘制已登记的纹理。
    pub fn background_image(mut self, id: u64, fit: ui_core::tree::ImageFit) -> Self {
        self.own = self.own.background_image(id, fit);
        self
    }

    pub fn border(mut self, color: ui_core::geom::Color, width: f32) -> Self {
        self.own = self.own.border(color, width);
        self
    }

    pub fn offset(mut self, x: f32, y: f32) -> Self {
        self.own = self.own.offset(x, y);
        self
    }

    /// Make this container and its subtree inert, without the child knowing.
    /// 使本容器及其子树惰性，而子节点无需知情。
    pub fn disabled(mut self, yes: bool) -> Self {
        self.own = self.own.disabled(yes);
        self
    }

    pub fn sense(mut self, sense: ui_core::Sense) -> Self {
        self.own = self.own.sense(sense);
        self
    }

    pub fn cursor(mut self, shape: ui_core::CursorShape) -> Self {
        self.own = self.own.cursor(shape);
        self
    }

    pub fn scrollable(mut self) -> Self {
        self.own = self.own.scrollable();
        self
    }

    pub fn scroll_y(mut self, y: f32) -> Self {
        self.own = self.own.scroll_y(y);
        self
    }

    pub fn opacity(mut self, o: f32) -> Self {
        self.own = self.own.opacity(o);
        self
    }

    /// Travel to a new fixed size instead of jumping, when the declared size changes.
    /// 声明的固定尺寸变化时走过去，而不是跳过去。
    pub fn transition_size(mut self, spec: ui_core::AnimSpec) -> Self {
        self.own = self.own.transition_size(spec);
        self
    }

    /// Appear from `enter`'s start values instead of at full strength.
    /// 从 `enter` 的起始值淡入，而不是直接以全强度出现。
    pub fn enter(mut self, enter: ui_core::tree::Presence) -> Self {
        self.own = self.own.enter(enter);
        self
    }

    /// Fade out through `exit`'s values after the app stops declaring this node.
    /// 应用不再声明本节点后，按 `exit` 的值淡出。
    pub fn exit(mut self, exit: ui_core::tree::Presence) -> Self {
        self.own = self.own.exit(exit);
        self
    }

    pub fn cross_align(mut self, a: f32) -> Self {
        self.own = self.own.cross_align(a);
        self
    }

    /// Place children in the cross-axis space they left over; 0.5 centres them.
    /// 把子节点放在它们让出的交叉空间里；0.5 居中。
    pub fn cross_pos(mut self, a: f32) -> Self {
        self.own = self.own.cross_pos(a);
        self
    }
}

impl Element for Container {
    fn decl(&self, cx: &mut ui_core::cx::Cx<'_>) -> Decl {
        let mut decl = self.own.clone();
        decl.children = self
            .children
            .iter()
            .map(|c| element_decl(c.as_ref(), cx))
            .collect();
        decl
    }

    fn children(&self) -> &[Box<dyn Element>] {
        &self.children
    }

    fn cache_key(&self) -> Option<CachedKey> {
        // The shell is app input, so it is proved by comparison rather than by recording;
        // `cache_matches` is where that proof lives, and it runs on every lookup.
        // 外壳是 app 输入，因此靠比对而非记录来证明；证明在 `cache_matches` 里，
        // 每次查找都会跑一遍。
        Some(CachedKey::new(self.own.id, 0))
    }

    fn cache_matches(&self, cached: &Decl) -> bool {
        self.own.own_eq(cached)
    }
}
