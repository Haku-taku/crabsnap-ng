//! Clipboard requests, in the portable half: the engine says what it wants, the platform
//! does it.
//! 剪贴板请求的可移植半边：引擎说出想要什么，平台去做。

/// Which selection a request targets.
/// 请求针对哪一个选区。
///
/// `Primary` is X11/Wayland's middle-click selection; backends that have none ignore it.
/// `Primary` 是 X11/Wayland 的中键选区；没有它的后端会忽略。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ClipboardKind {
    /// The ordinary clipboard: Ctrl+C, Ctrl+V.
    /// 普通剪贴板：Ctrl+C、Ctrl+V。
    Selection,
    /// The selection buffer; on Linux a mouse selection fills it as you drag.
    /// 选区缓冲；在 Linux 上拖选就会填它。
    Primary,
}

/// One thing the engine asks the platform to do after a dispatch.
/// 引擎在一次事件分发后请平台做的一件事。
///
/// The engine never reads the clipboard itself: a read is a round trip, and `dispatch`
/// must not block. A read therefore comes back as [`ui_core::Event::Paste`].
/// 引擎从不自己读剪贴板：读取是一次往返，`dispatch` 不能阻塞。
/// 因此读取的结果以 [`ui_core::Event::Paste`] 回来。
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum ClipboardCommand {
    /// Put `text` on the clipboard.
    /// 把 `text` 放进剪贴板。
    Copy { text: String, kind: ClipboardKind },
    /// Ask for the clipboard's text; the answer is an `Event::Paste`.
    /// 请求剪贴板文本；答案是一条 `Event::Paste`。
    RequestPaste { kind: ClipboardKind },
}

impl ClipboardCommand {
    /// The clipboard this command works on.
    /// 这条命令作用于哪个剪贴板。
    pub fn kind(&self) -> ClipboardKind {
        match self {
            Self::Copy { kind, .. } | Self::RequestPaste { kind } => *kind,
        }
    }
}
