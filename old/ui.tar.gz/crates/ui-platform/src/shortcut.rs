//! App-level shortcut bindings, plus the engine's built-in table.
//! 应用级快捷键绑定，以及引擎的内置表。

use ui_core::shortcut::{KeyChord, ShortcutId};
use ui_core::{Key, Modifiers};

/// Chord → id pairs, split by layer; the first match within a layer wins.
/// 组合键到 id 的映射，按层分开；每层内先匹配先赢。
#[derive(Clone, Debug, Default)]
pub struct Bindings {
    /// Bindings the app registered for the whole loop.
    /// 应用为整个循环注册的绑定。
    pub app: Vec<(KeyChord, ShortcutId)>,
    /// The engine's own bindings; an app may rebind or drop any of them by id.
    /// 引擎自带的绑定；应用可按 id 改写或移除其中任意一条。
    pub builtin: Vec<(KeyChord, ShortcutId)>,
}

impl Bindings {
    /// The engine's defaults, ready for overrides.
    /// 引擎默认绑定，等待被改写。
    pub fn with_builtins() -> Self {
        Self {
            app: Vec::new(),
            builtin: builtins(),
        }
    }

    /// Bind a chord for the whole app; it fires when no control claimed it.
    /// 为整个应用绑定一个组合键；没有控件认领时它才触发。
    pub fn bind(&mut self, chord: KeyChord, id: ShortcutId) {
        self.app.push((chord, id));
    }

    /// Point `id` at `chord` instead of whatever it was bound to, in its own layer.
    /// 把 `id` 改绑到 `chord`，留在它原本所属的层里。
    ///
    /// Rebinding a built-in is how an app replaces the engine's text-editing keys.
    /// 改写内置绑定，就是应用替换引擎文本编辑快捷键的方式。
    pub fn rebind(&mut self, id: ShortcutId, chord: KeyChord) {
        let builtin = self.builtin.iter().any(|(_, i)| *i == id);
        self.app.retain(|(_, i)| *i != id);
        self.builtin.retain(|(_, i)| *i != id);
        if builtin {
            self.builtin.push((chord, id));
        } else {
            self.app.push((chord, id));
        }
    }

    /// Drop every binding of `id`, so the chord reaches nothing.
    /// 移除 `id` 的全部绑定，使它不再响应任何组合。
    pub fn unbind(&mut self, id: ShortcutId) {
        self.app.retain(|(_, i)| *i != id);
        self.builtin.retain(|(_, i)| *i != id);
    }

    /// The app-level id bound to this chord, if any.
    /// 绑定到此组合的应用级 id（若有）。
    pub fn app_id(&self, key: Key, mods: Modifiers) -> Option<ShortcutId> {
        first(&self.app, key, mods)
    }

    /// The built-in id bound to this chord, if any.
    /// 绑定到此组合的内置 id（若有）。
    pub fn builtin_id(&self, key: Key, mods: Modifiers) -> Option<ShortcutId> {
        first(&self.builtin, key, mods)
    }

    /// The chord `id` currently answers, in the order a key press resolves: the app's layer
    /// first, then the engine's. A menu row shows this, so a rebind shows through.
    /// `id` 目前响应的组合键，按按键解析的顺序：先应用层，后引擎层。菜单行显示它，
    /// 因此改写绑定会如实反映。
    pub fn chord_of(&self, id: ShortcutId) -> Option<KeyChord> {
        self.app
            .iter()
            .chain(self.builtin.iter())
            .find(|(_, i)| *i == id)
            .map(|(chord, _)| *chord)
    }
}

fn first(table: &[(KeyChord, ShortcutId)], key: Key, mods: Modifiers) -> Option<ShortcutId> {
    table
        .iter()
        .find(|(chord, _)| chord.matches(key, mods))
        .map(|(_, id)| *id)
}

fn ctrl(c: char) -> KeyChord {
    KeyChord::new(
        Key::Char(c),
        Modifiers {
            ctrl: true,
            ..Modifiers::default()
        },
    )
}

fn plain(key: Key) -> KeyChord {
    KeyChord::new(key, Modifiers::default())
}

fn shifted(key: Key) -> KeyChord {
    KeyChord::new(
        key,
        Modifiers {
            shift: true,
            ..Modifiers::default()
        },
    )
}

fn ctrl_key(key: Key) -> KeyChord {
    KeyChord::new(
        key,
        Modifiers {
            ctrl: true,
            ..Modifiers::default()
        },
    )
}

fn ctrl_shifted(key: Key) -> KeyChord {
    KeyChord::new(
        key,
        Modifiers {
            ctrl: true,
            shift: true,
            ..Modifiers::default()
        },
    )
}

/// Every built-in the engine binds; each is overridable through its id.
/// 引擎绑定的全部内置项；每一条都可以按 id 改写。
fn builtins() -> Vec<(KeyChord, ShortcutId)> {
    vec![
        (ctrl('c'), ShortcutId::COPY),
        (ctrl('x'), ShortcutId::CUT),
        (ctrl('v'), ShortcutId::PASTE),
        (ctrl('a'), ShortcutId::SELECT_ALL),
        (ctrl('d'), ShortcutId::DELETE_FORWARD),
        (plain(Key::Home), ShortcutId::HOME),
        (plain(Key::End), ShortcutId::END),
        (ctrl_key(Key::Home), ShortcutId::DOCUMENT_HOME),
        (ctrl_key(Key::End), ShortcutId::DOCUMENT_END),
        (shifted(Key::Left), ShortcutId::EXTEND_LEFT),
        (shifted(Key::Right), ShortcutId::EXTEND_RIGHT),
        (ctrl_shifted(Key::Left), ShortcutId::EXTEND_WORD_LEFT),
        (ctrl_shifted(Key::Right), ShortcutId::EXTEND_WORD_RIGHT),
        (shifted(Key::Up), ShortcutId::EXTEND_UP),
        (shifted(Key::Down), ShortcutId::EXTEND_DOWN),
        (shifted(Key::Home), ShortcutId::EXTEND_HOME),
        (shifted(Key::End), ShortcutId::EXTEND_END),
        (ctrl_shifted(Key::Home), ShortcutId::EXTEND_DOCUMENT_HOME),
        (ctrl_shifted(Key::End), ShortcutId::EXTEND_DOCUMENT_END),
    ]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn rebinding_a_builtin_moves_it_and_frees_the_old_chord() {
        let mut bindings = Bindings::with_builtins();
        let ctrl = |c: char| {
            KeyChord::new(
                Key::Char(c),
                Modifiers {
                    ctrl: true,
                    ..Modifiers::default()
                },
            )
        };
        let press = |c: char| (Key::Char(c), ctrl(c).mods);
        assert_eq!(
            bindings.builtin_id(press('c').0, press('c').1),
            Some(ShortcutId::COPY)
        );

        bindings.rebind(ShortcutId::COPY, ctrl('y'));

        assert_eq!(
            bindings.builtin_id(press('y').0, press('y').1),
            Some(ShortcutId::COPY)
        );
        assert_eq!(
            bindings.builtin_id(press('c').0, press('c').1),
            None,
            "the old chord no longer reaches copy"
        );
    }
}
