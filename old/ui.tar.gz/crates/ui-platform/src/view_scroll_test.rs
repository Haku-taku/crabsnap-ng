//! Engine tests for the engine-owned scroll container: wheel accumulation and clamping.
//! 引擎自有滚动容器的引擎测试：滚轮累计与钳位。
//!
//! These tests live in ui-platform because the wheel handler (`scroll_owned_delta`) is part
//! of `AppLoop`. They use a bare `Decl` with `Sense::SCROLL_OWNED`, never ui-widgets, so the
//! layering boundary (platform must not depend on widgets) stays intact.
//! 这些测试在 ui-platform 里，因为滚轮处理（`scroll_owned_delta`）属于 `AppLoop`。
//! 它们用带 `Sense::SCROLL_OWNED` 的裸 `Decl`，绝不依赖 ui-widgets，分层边界（平台不得依赖控件）不受破坏。

use ui_core::{Decl, Id, NodeKind, Sense, SizeClass, layout, geom};

use crate::{App, AppLoop, OffscreenTarget};

/// An app that reads its scroller's geometry from the context, as a scrollbar or a
/// collapsing app bar would: the read must see the engine's stored offset, not the
/// declaration's default.
/// 一个从上下文读取滚动容器几何的 app，就像滚动条或折叠中的 app bar 那样：
/// 读到的必须是引擎存储的偏移，而不是声明的默认值。
struct ReadingApp {
    seen: std::rc::Rc<std::cell::RefCell<Vec<(f32, f32, f32, f32, bool)>>>,
}

impl App for ReadingApp {
    fn view(&mut self, cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
        let content = Decl::container(Id::str("content"), NodeKind::Box)
            .size(SizeClass::fixed(100.0, 300.0));
        let read = cx.scroll_of(Id::str("scroller"));
        self.seen.borrow_mut().push(
            read.map(|g| (g.extent_h, g.viewport_w, g.viewport_h, g.offset_y, g.active))
                .unwrap_or((-1.0, -1.0, -1.0, -1.0, false)),
        );
        crate::from_decl(
            Decl::container(Id::str("scroller"), NodeKind::Column)
                .size(SizeClass::fixed(100.0, 100.0))
                .sense(Sense::SCROLL_OWNED)
                .clip(layout::Clip {
                    x: layout::Overflow::Hidden,
                    y: layout::Overflow::Scroll,
                })
                .child(content),
        )
    }
}

/// A fixed 100-tall scroll container holding a 300-tall child: 200 overflow on y.
/// 一个固定 100 高的滚动容器，内有一个 300 高的子节点：y 向溢出 200。
struct ScrollApp;

impl App for ScrollApp {
    fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
        let content = Decl::container(Id::str("content"), NodeKind::Box)
            .size(SizeClass::fixed(100.0, 300.0));
        crate::from_decl(
            Decl::container(Id::str("scroller"), NodeKind::Column)
                .size(SizeClass::fixed(100.0, 100.0))
                .sense(Sense::SCROLL_OWNED)
                .clip(layout::Clip {
                    x: layout::Overflow::Hidden,
                    y: layout::Overflow::Scroll,
                })
                .child(content),
        )
    }
}

/// The scroller's `scroll_y` after a frame.
/// 一帧后滚动容器的 `scroll_y`。
fn scroll_y_of(lp: &AppLoop<ScrollApp>) -> f32 {
    let nid = lp.tree().find_by_id(Id::str("scroller")).unwrap();
    lp.tree()
        .get(nid)
        .and_then(|n| n.data.params())
        .map(|p| p.scroll_y)
        .unwrap()
}

#[test]
fn an_engine_owned_scroller_accumulates_the_wheel_and_clamps_to_its_content() {
    // A `SCROLL_OWNED` container takes the wheel itself: the engine sums the delta into
    // `scroll_y` and clamps at the content overflow, instead of reporting `Value` up.
    // `SCROLL_OWNED` 容器自己接收滚轮：引擎把增量累进 `scroll_y`，并在内容溢出处钳位，
    // 而不是把 `Value` 上报出去。
    let mut lp = AppLoop::new(ScrollApp);
    let mut target = OffscreenTarget::new(100, 100);
    lp.frame(&mut target, None);
    let pos = geom::Point::new(50.0, 50.0);
    lp.dispatch(ui_core::Event::PointerMoved { pos });
    lp.dispatch(ui_core::Event::wheel(pos, 30.0));
    lp.frame(&mut target, None);
    assert!(
        (scroll_y_of(&lp) - 30.0).abs() < 1e-3,
        "the engine must accumulate the wheel into the scroller, got {}",
        scroll_y_of(&lp)
    );
    // The content is 300 tall in a 100-tall viewport: 200 is the clamp ceiling.
    // 内容 300 高、视口 100 高：钳位上限是 200。
    lp.dispatch(ui_core::Event::wheel(pos, 300.0));
    lp.frame(&mut target, None);
    assert!(
        (scroll_y_of(&lp) - 200.0).abs() < 1e-3,
        "the wheel must clamp at the content overflow, got {}",
        scroll_y_of(&lp)
    );
    // A negative delta scrolls back toward the top, but never below zero.
    // 负增量向回滚动，但绝不小于零。
    lp.dispatch(ui_core::Event::wheel(pos, -500.0));
    lp.frame(&mut target, None);
    assert!(
        (scroll_y_of(&lp) - 0.0).abs() < 1e-3,
        "the wheel must not scroll below the top, got {}",
        scroll_y_of(&lp)
    );
}

/// A strip that scrolls sideways only: a 300-wide child in a 100-wide row.
/// 只横向滚动的条带：100 宽的横向容器里装 300 宽的子节点。
struct StripApp;

impl App for StripApp {
    fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
        let content = Decl::container(Id::str("content"), NodeKind::Box)
            .size(SizeClass::fixed(300.0, 100.0));
        crate::from_decl(
            Decl::container(Id::str("strip"), NodeKind::Row)
                .size(SizeClass::fixed(100.0, 100.0))
                .sense(Sense::SCROLL_OWNED)
                .clip(layout::Clip {
                    x: layout::Overflow::Scroll,
                    y: layout::Overflow::Hidden,
                })
                .child(content),
        )
    }
}

#[test]
fn an_upright_wheel_scrolls_a_sideways_only_strip() {
    // A mouse has one wheel, so a strip with no vertical axis to give the delta to takes
    // it sideways; otherwise a horizontal carousel could not be scrolled by a mouse at all.
    // 鼠标只有一个轮，没有纵向可给的条带便把它收作横向；否则横向轮播根本无法用鼠标滚动。
    let mut lp = AppLoop::new(StripApp);
    let mut target = OffscreenTarget::new(100, 100);
    lp.frame(&mut target, None);
    let pos = geom::Point::new(50.0, 50.0);
    lp.dispatch(ui_core::Event::PointerMoved { pos });
    lp.dispatch(ui_core::Event::wheel(pos, 30.0));
    lp.frame(&mut target, None);
    let nid = lp.tree().find_by_id(Id::str("strip")).unwrap();
    let x = lp.tree().get(nid).and_then(|n| n.data.params()).unwrap().scroll_x;
    assert!((x - 30.0).abs() < 1e-3, "the wheel must move the strip, got {x}");
    // 200 is the overflow, so the same clamp applies on this axis.
    // 溢出是 200，这条轴上同样钳位。
    lp.dispatch(ui_core::Event::wheel(pos, 500.0));
    lp.frame(&mut target, None);
    let x = lp.tree().get(nid).and_then(|n| n.data.params()).unwrap().scroll_x;
    assert!((x - 200.0).abs() < 1e-3, "the wheel must clamp at the overflow, got {x}");
}

#[test]
fn a_build_reads_the_engine_owned_offset_and_content_extent_from_the_context() {
    // A control that draws a scrollbar or follows the scroll must read the engine's stored
    // offset through `Cx::scroll_of`, one frame behind the wheel but never the declaration's
    // default. The content extent is the scroller's 300-tall child.
    // 画滚动条或跟随滚动的控件必须通过 `Cx::scroll_of` 读到引擎存储的偏移——
    // 落后滚轮一帧，但绝不是声明的默认值。内容尺寸就是滚动容器里 300 高的子节点。
    let seen = std::rc::Rc::new(std::cell::RefCell::new(Vec::new()));
    let mut lp = AppLoop::new(ReadingApp { seen: seen.clone() });
    let mut target = OffscreenTarget::new(100, 100);
    // First frame establishes the tree; the context has nothing to report yet.
    // 第一帧建立树；上下文还没有任何可上报的东西。
    lp.frame(&mut target, None);
    assert_eq!(*seen.borrow(), vec![(-1.0, -1.0, -1.0, -1.0, false)]);

    let pos = geom::Point::new(50.0, 50.0);
    lp.dispatch(ui_core::Event::PointerMoved { pos });
    lp.dispatch(ui_core::Event::wheel(pos, 40.0));
    lp.frame(&mut target, None);
    // Second frame: the previous frame's layout and the stored offset show up; the viewport
    // size (a 100x100 scroller) lets a scrollbar size and anchor its thumb. The wheel marks
    // the scroller active, which the auto scrollbar keys on.
    // 第二帧：上一帧的布局与存储的偏移出现；视口尺寸（100×100 的滚动容器）让滚动条
    // 定 thumb 的尺寸与锚点。滚轮把容器标为活动，自动滚动条据此显隐。
    assert_eq!(
        *seen.borrow(),
        vec![
            (-1.0, -1.0, -1.0, -1.0, false),
            (300.0, 100.0, 100.0, 40.0, true)
        ]
    );
    // Third frame, after another wheel: the offset follows, the extents unchanged.
    // 第三帧，再滚一次：偏移跟上，两个尺寸都不变。
    lp.dispatch(ui_core::Event::wheel(pos, 20.0));
    lp.frame(&mut target, None);
    assert_eq!(
        *seen.borrow(),
        vec![
            (-1.0, -1.0, -1.0, -1.0, false),
            (300.0, 100.0, 100.0, 40.0, true),
            (300.0, 100.0, 100.0, 60.0, true)
        ]
    );
}

/// A scroller that also declares its scrollbar geometry, as ui-widgets' `Scroll` does.
/// 一个同时声明滚动条几何的滚动容器，与 ui-widgets 的 `Scroll` 一样。
struct BarApp;

impl App for BarApp {
    fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
        let content = Decl::container(Id::str("content"), NodeKind::Box)
            .size(SizeClass::fixed(100.0, 300.0));
        let mut scroller = Decl::container(Id::str("scroller"), NodeKind::Column)
            .size(SizeClass::fixed(100.0, 100.0))
            .sense(Sense::SCROLL_OWNED)
            .clip(layout::Clip {
                x: layout::Overflow::Hidden,
                y: layout::Overflow::Scroll,
            })
            .child(content);
        // 100-tall viewport over 300 of content: a third-sized thumb with two thirds of
        // travel, which is what `thumb_geometry` computes.
        // 100 高的视口装 300 的内容：thumb 占三分之一，行程占三分之二，正是 `thumb_geometry` 的结果。
        if let Some(p) = scroller.data.params_mut() {
            p.scrollbar = Some(ui_core::ScrollbarHit {
                thumb: geom::Rect::new(96.0, 0.0, 4.0, 100.0 / 3.0),
                track: geom::Rect::new(96.0, 0.0, 4.0, 100.0),
            });
        }
        crate::from_decl(scroller)
    }
}

/// A control inside the strip that asks the engine to step it, as a scroll button does.
/// 条带里的一个控件，像滚动按钮那样请求引擎把它滚动一步。
struct Stepper;

impl crate::Element for Stepper {
    fn decl(&self, _cx: &mut ui_core::cx::Cx<'_>) -> Decl {
        Decl::container(Id::str("step"), NodeKind::Box)
            .size(SizeClass::fixed(20.0, 20.0))
            .sense(Sense::HOVER | Sense::CLICK)
    }

    fn change(
        &self,
        state: &crate::WidgetState,
        _bounds: geom::Rect,
    ) -> Option<ui_core::change::Change> {
        (state.clicked && !state.disabled).then_some(ui_core::change::Change::ScrollBy {
            dx: 50.0,
            dy: 0.0,
            owner: None,
        })
    }
}

/// A sideways strip holding a stepper control, so the request has a scroller above it.
/// 一个横向条带，里面放一个步进控件，于是请求之上有可接住它的滚动容器。
struct StepApp;

impl App for StepApp {
    fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
        let content = Decl::container(Id::str("content"), NodeKind::Box)
            .size(SizeClass::fixed(280.0, 100.0));
        Box::new(
            crate::Container::new(Id::str("strip"), NodeKind::Row)
                .size(SizeClass::fixed(100.0, 100.0))
                .map(|d| {
                    d.sense(Sense::SCROLL_OWNED).clip(layout::Clip {
                        x: layout::Overflow::Scroll,
                        y: layout::Overflow::Hidden,
                    })
                })
                .child(Box::new(Stepper))
                .child_decl(content),
        )
    }
}

#[test]
fn a_scroll_request_steps_the_nearest_engine_scroller() {
    // A scroll button says "move my strip" without knowing its id: the engine finds the
    // nearest `SCROLL_OWNED` ancestor, clamps the step and eases it in.
    // 滚动按钮只说「把我的条带移一步」，不必知道它的 id：
    // 引擎找最近的 `SCROLL_OWNED` 祖先，钳位并缓动过去。
    let mut lp = AppLoop::new(StepApp);
    let mut target = OffscreenTarget::new(100, 100);
    lp.frame(&mut target, None);
    let pos = geom::Point::new(10.0, 10.0);
    lp.dispatch(ui_core::Event::PointerMoved { pos });
    lp.dispatch(ui_core::Event::PointerPressed {
        pos,
        button: ui_core::PointerButton::Primary,
    });
    lp.dispatch(ui_core::Event::PointerReleased {
        pos,
        button: ui_core::PointerButton::Primary,
    });
    // The step is eased, so let the settle run for a second of scripted frames.
    // 步进是缓动的，因此让落定跑满一秒的脚本帧。
    for _ in 0..60 {
        lp.frame_with_dt(&mut target, None, 1.0 / 60.0);
    }
    let offset = lp.scroll_offset(Id::str("strip")).expect("the strip moved");
    assert!(
        (offset.x - 50.0).abs() < 1.0,
        "one request moves the strip by its step, got {}",
        offset.x
    );
}

/// A clickable box that may also be an anchored overlay.
/// 一个可点击的盒子，也可以同时是锚定浮层。
struct Reporter {
    id: Id,
    overlay: Option<layout::OverlayPlacement>,
    fill: Option<geom::Color>,
}

impl crate::Element for Reporter {
    fn decl(&self, _cx: &mut ui_core::cx::Cx<'_>) -> Decl {
        let mut decl = Decl::container(self.id, NodeKind::Box)
            .size(SizeClass::fixed(100.0, 40.0))
            .sense(Sense::HOVER | Sense::CLICK);
        if let Some(fill) = self.fill {
            decl = decl.background(fill, geom::Corners::all(0.0));
        }
        if let Some(overlay) = self.overlay {
            decl = decl.overlay(overlay);
        }
        decl
    }

    fn change(
        &self,
        state: &crate::WidgetState,
        _bounds: geom::Rect,
    ) -> Option<ui_core::change::Change> {
        (state.clicked && !state.disabled).then_some(ui_core::change::Change::Activated)
    }
}

/// An app whose overlay is declared before the content it must cover.
/// 一个把浮层声明在它要覆盖的内容之前的 app。
struct HitOrderApp {
    seen: std::rc::Rc<std::cell::RefCell<Vec<Id>>>,
}

impl App for HitOrderApp {
    fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
        Box::new(
            crate::Container::new(Id::str("root"), NodeKind::Column)
                .size(SizeClass::fixed(200.0, 200.0))
                .child(Box::new(Reporter {
                    id: Id::str("panel"),
                    overlay: Some(layout::OverlayPlacement::below(layout::Anchor::Point(
                        geom::Point::new(0.0, 0.0),
                    ))),
                    fill: None,
                }))
                .child(Box::new(Reporter {
                    id: Id::str("late"),
                    overlay: None,
                    fill: None,
                })),
        )
    }

    fn changed(&mut self, id: Id, change: ui_core::change::Change) -> bool {
        if let ui_core::change::Change::Activated = change {
            self.seen.borrow_mut().push(id);
        }
        true
    }
}

#[test]
fn an_overlay_takes_the_pointer_over_content_declared_after_it() {
    // An overlay paints above the whole tree, so it hits first too: declaration order must
    // not decide between a floating panel and the content it covers.
    // 浮层画在整棵树之上，因此也先接收命中：浮面板与它所覆盖的内容之间，声明顺序不作数。
    let seen = std::rc::Rc::new(std::cell::RefCell::new(Vec::new()));
    let mut lp = AppLoop::new(HitOrderApp { seen: seen.clone() });
    let mut target = OffscreenTarget::new(200, 200);
    lp.frame(&mut target, None);
    let pos = geom::Point::new(10.0, 10.0);
    lp.dispatch(ui_core::Event::PointerMoved { pos });
    lp.dispatch(ui_core::Event::PointerPressed {
        pos,
        button: ui_core::PointerButton::Primary,
    });
    lp.dispatch(ui_core::Event::PointerReleased {
        pos,
        button: ui_core::PointerButton::Primary,
    });
    lp.frame(&mut target, None);
    assert_eq!(
        *seen.borrow(),
        vec![Id::str("panel")],
        "the overlay, not the later sibling, takes the click"
    );
}

/// An app whose overlay and the sibling under it both paint, in telltale colours.
/// 一个浮层与它下面的兄弟都会上色的 app，用颜色区分谁在上。
struct PaintOrderApp;

impl App for PaintOrderApp {
    fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
        Box::new(
            crate::Container::new(Id::str("root"), NodeKind::Column)
                .size(SizeClass::fixed(200.0, 200.0))
                .child(Box::new(Reporter {
                    id: Id::str("panel"),
                    overlay: Some(layout::OverlayPlacement {
                        anchor: layout::Anchor::Point(geom::Point::new(10.0, 10.0)),
                        side: layout::Side::Below,
                        align: layout::OverlayAlign::Start,
                        offset: 0.0,
                        flip: false,
                        match_anchor_width: false,
                        match_anchor_height: false,
                        min_width: 0.0,
                    }),
                    fill: Some(geom::Color::from_rgba8(255, 0, 0, 255)),
                }))
                .child(Box::new(Reporter {
                    id: Id::str("late"),
                    overlay: None,
                    fill: Some(geom::Color::from_rgba8(0, 0, 255, 255)),
                })),
        )
    }
}

#[test]
fn an_overlay_paints_over_content_declared_after_it() {
    // Paint order is walk order and the walk defers overlays, so the panel declared first
    // must still be the one seen where the two overlap.
    // 绘制顺序即遍历顺序，而遍历推后浮层，所以先声明的面板在两者重叠处仍必须是看得见的那个。
    let mut lp = AppLoop::new(PaintOrderApp);
    let mut target = OffscreenTarget::new(200, 200);
    lp.frame(&mut target, None);
    let px = target.pixels.get(50, 25);
    assert_eq!(
        &px[0..3],
        &[255, 0, 0],
        "the overlay covers the later sibling, got {px:?}"
    );
}

/// A scroller whose build keeps the row 200 units down visible.
/// 一个在构建时要求保持 200 处那一行可见的滚动容器。
struct BringApp;

impl App for BringApp {
    fn view(&mut self, cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
        cx.bring_into_view(Id::str("target"));
        crate::from_decl(
            Decl::container(Id::str("scroller"), NodeKind::Column)
                .size(SizeClass::fixed(100.0, 100.0))
                .sense(Sense::SCROLL_OWNED)
                .clip(layout::Clip {
                    x: layout::Overflow::Hidden,
                    y: layout::Overflow::Scroll,
                })
                .child(
                    Decl::container(Id::str("content"), NodeKind::Column)
                        .size(SizeClass::fixed(100.0, 300.0))
                        .child(
                            Decl::container(Id::str("spacer"), NodeKind::Box)
                                .size(SizeClass::fixed(100.0, 200.0)),
                        )
                        .child(
                            Decl::container(Id::str("target"), NodeKind::Box)
                                .size(SizeClass::fixed(100.0, 30.0)),
                        ),
                ),
        )
    }
}

#[test]
fn a_build_can_keep_a_node_visible_in_its_scroller() {
    // WinUI's `BringIntoViewOnFocusChange`: the control names the row that must stay seen.
    // WinUI 的 `BringIntoViewOnFocusChange`：控件点名必须保持在视野内的那一行。
    let mut lp = AppLoop::new(BringApp);
    let mut target = OffscreenTarget::new(200, 200);
    lp.frame(&mut target, None);
    lp.frame(&mut target, None);
    let offset = lp
        .scroll_offset(Id::str("scroller"))
        .expect("the request stored an offset");
    assert_eq!(
        offset.y, 130.0,
        "the target's 230 end meets the viewport's 100 edge"
    );
}

/// A scroller whose second focus stop begins below the viewport.
/// 一个滚动容器，其第二个焦点停靠点起始于视野之外。
struct FocusFollowApp;

impl App for FocusFollowApp {
    fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
        let stop = |id: &'static str| {
            Decl::container(Id::str(id), NodeKind::Box)
                .size(SizeClass::fixed(100.0, 30.0))
                .background(geom::Color::WHITE, geom::Corners::ZERO)
                .sense(Sense::FOCUSABLE)
        };
        crate::from_decl(
            Decl::container(Id::str("root"), NodeKind::Column)
                .size(SizeClass::fixed(200.0, 300.0))
                .child(
                    Decl::container(Id::str("scroller"), NodeKind::Column)
                        .size(SizeClass::fixed(100.0, 100.0))
                        .sense(Sense::SCROLL_OWNED)
                        .clip(layout::Clip {
                            x: layout::Overflow::Hidden,
                            y: layout::Overflow::Scroll,
                        })
                        .child(
                            Decl::container(Id::str("content"), NodeKind::Column)
                                .size(SizeClass::fixed(100.0, 300.0))
                                .child(stop("first"))
                                .child(
                                    Decl::container(Id::str("spacer"), NodeKind::Box)
                                        .size(SizeClass::fixed(100.0, 170.0)),
                                )
                                .child(stop("second")),
                        ),
                ),
        )
    }
}

#[test]
fn focus_moving_below_the_viewport_scrolls_the_stop_into_view() {
    // Every WinUI scroller keeps the focused element visible; keyboard navigation must not
    // walk focus off screen. 每个 WinUI 滚动容器都让焦点元素保持可见，键盘导航不能把焦点走出屏幕。
    let mut lp = AppLoop::new(FocusFollowApp);
    let mut target = OffscreenTarget::new(200, 300);
    lp.frame(&mut target, None);
    lp.dispatch(ui_core::Event::KeyPressed {
        key: ui_core::Key::Tab,
    });
    lp.frame(&mut target, None);
    assert_eq!(lp.focused(), Some(Id::str("first")));
    assert!(
        lp.scroll_offset(Id::str("scroller")).is_none(),
        "the first stop is already visible, so nothing may scroll"
    );
    lp.dispatch(ui_core::Event::KeyPressed {
        key: ui_core::Key::Tab,
    });
    lp.frame(&mut target, None);
    assert_eq!(lp.focused(), Some(Id::str("second")));
    let offset = lp
        .scroll_offset(Id::str("scroller"))
        .expect("the move stored an offset");
    assert_eq!(
        offset.y, 130.0,
        "the stop's 230 end meets the viewport's 100 edge"
    );
}

#[test]
fn dragging_the_scrollbar_thumb_maps_track_pixels_onto_the_offset_range() {
    // The thumb's travel maps onto the offset's range: half the travel is half the overflow,
    // and the press belongs to the bar, not to the content under it.
    // thumb 的行程映射到偏移的值域：走一半行程就滚过一半溢出，且这次按下属于滚动条而非其下内容。
    let mut lp = AppLoop::new(BarApp);
    let mut target = OffscreenTarget::new(100, 100);
    lp.frame(&mut target, None);
    lp.dispatch(ui_core::Event::PointerPressed {
        pos: geom::Point::new(98.0, 100.0 / 6.0),
        button: ui_core::PointerButton::Primary,
    });
    assert!(lp.pressed().is_none(), "the bar takes the press, not the content");
    lp.dispatch(ui_core::Event::PointerMoved {
        pos: geom::Point::new(98.0, 50.0),
    });
    let offset = lp
        .scroll_offset(Id::str("scroller"))
        .expect("the drag stored an offset");
    assert!(
        (offset.y - 100.0).abs() < 0.5,
        "half the travel is half the 200 overflow, got {}",
        offset.y
    );
}
