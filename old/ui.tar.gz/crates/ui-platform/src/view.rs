//! The app loop: build -> layout -> paint -> present.
//! 应用循环：构建 -> 布局 -> 绘制 -> 呈现。

use std::cell::RefCell;
use std::rc::Rc;

use crate::text_pass::TextPass;
use ui_core::collections::{FastHasher, FastMap, FastSet};
use ui_core::draw::{DrawList, PrimKind, TextPrim};
use ui_core::geom::{Rect, Size};
#[cfg(test)]
use ui_core::geom::Insets;
use ui_core::hit::{HitBehavior, HitIndex};
use ui_core::layout::{AxisSize, Len, Sizing};
use ui_core::{
    BuiltinLayout, Constraints, Damage, DamageAccum, Id, LayoutEngine, MonospaceMeasure,
    NodeData, NodeKind, Tree,
};
use ui_paint::CpuRenderer;

use crate::present::PresentTarget;

/// Per-frame information handed to user code.
/// 交给用户代码的每帧信息。
#[derive(Clone, Debug, Default)]
pub struct FrameInfo {
    pub width: u32,
    pub height: u32,
    /// Pointer position, if the pointer is over the surface.
    /// 指针位置（若指针在表面内）。
    pub pointer: Option<ui_core::geom::Point>,
    /// Index of this frame, starting at 0.
    /// 帧序号，从 0 开始。
    pub frame: u64,
    /// What the last frame reported as hovered, pressed and focused.
    /// 上一帧算出的悬停、按下与焦点节点。
    pub hovered: Option<ui_core::Id>,
    pub pressed: Option<ui_core::Id>,
    /// The clicked node and its ancestors, root first; empty when nothing was clicked.
    /// 被点击节点及其祖先，根在前；无点击时为空。
    clicked_path: Vec<Id>,
    /// The drag-release chain, root first.
    /// 拖拽释放的祖先链，根在前。
    dropped_path: Vec<Id>,
    /// The node that release landed on, when it accepts drops.
    /// 那次释放落到的节点，且它接受放下。
    drop_target: Option<Id>,
    /// Whether the live press has travelled past the click threshold.
    /// 进行中的按下是否已越过点击阈值。
    pub drag_started: bool,
    /// Pointer movement since the previous event while a drag is live.
    /// 拖拽进行中，指针相对上一次事件的位移。
    pub drag_step: Option<ui_core::geom::Point>,
    pub focused: Option<ui_core::Id>,
    /// Focus arrived by keyboard, so a focus ring may be drawn.
    /// 焦点由键盘带来，因此可以画焦点环。
    pub focus_visible: bool,
    /// The node Enter or Space reached since the last frame, and the chord that fired.
    /// 自上一帧以来 Enter 或 Space 到达的节点，以及被触发的组合键。
    activated: Option<Id>,
    /// That node's ancestor chain, root first; empty when nothing was activated.
    /// 该节点的祖先链，根在前；无激活时为空。
    activated_path: Vec<Id>,
    /// The popup a press outside it asked to close since the last frame.
    /// 自上一帧以来因外部按下而请求关闭的浮层。
    pub dismissed: Option<Id>,
    shortcut: Option<(Id, ui_core::ShortcutId)>,
    /// The focused text input and the caret's byte offset inside it.
    /// 持有焦点的文本输入及其插入符的字节偏移。
    pub caret: Option<(ui_core::Id, usize)>,
    /// The caret's x inside the text node drawing the buffer, in that node's layout space.
    /// 插入符在绘制缓冲的文本节点内的 x，位于该节点的布局坐标系。
    pub caret_in_text: Option<(ui_core::Id, f32)>,
    /// The text node holding a selection, and that selection.
    /// 持有选区的文本节点，以及该选区。
    pub selection: Option<(ui_core::Id, ui_core::TextSelection)>,
    /// The input method's composition, when one is live.
    /// 输入法的组合内容，组合进行中时存在。
    pub preedit: Option<(ui_core::Id, ui_core::Preedit)>,
    /// Seconds since the previous frame, fed by the platform; 0 for a static frame.
    /// 距上一帧的秒数，由平台喂入；静止帧为 0。
    pub dt: f32,
    /// This frame's timestamp from the engine clock. Apps pass it to `AnimStore` and
    /// never read a clock themselves.
    /// 引擎时钟给出的本帧时间戳。app 把它交给 `AnimStore`，自己从不读时钟。
    pub now: f64,
    /// The hovered node and its ancestors, root first; empty when nothing is hovered.
    /// 悬停节点及其祖先，根在前；无悬停时为空。
    hovered_path: Vec<Id>,
    /// The pressed node and its ancestors, root first; empty when nothing is pressed.
    /// 被按下节点及其祖先，根在前；无按下时为空。
    pressed_path: Vec<Id>,
    /// The node owning the current drag, resolved by the engine from the pressed node.
    /// 当前拖拽的归属节点，由引擎从被按下节点解析。
    drag_owner: Option<Id>,
}

impl FrameInfo {
    /// A frame with no derived state, for callers that drive `view` by hand.
    /// 无派生状态的帧，供手工驱动 `view` 的调用方使用。
    pub fn new(width: u32, height: u32, pointer: Option<ui_core::geom::Point>, frame: u64) -> Self {
        Self {
            width,
            height,
            pointer,
            frame,
            ..Self::default()
        }
    }

    /// Whether the pointer is over `id` or anywhere inside it.
    /// 指针是否在 `id` 之上或其内部任意位置。
    ///
    /// `hovered` alone is the *topmost* node, so a container is never reported while the
    /// pointer is over its children. Hit testing has to stay topmost (that is what a
    /// click means), so the container question is answered by the ancestor path.
    /// `hovered` 只是**最上层**节点，指针在子节点上时容器永远不会被报告。
    /// 命中测试必须保持最上层（那才是点击的含义），
    /// 因此「容器是否被悬停」由祖先路径回答。
    pub fn hovered_within(&self, id: Id) -> bool {
        self.hovered_path.contains(&id)
    }

    /// The hovered node and its ancestors, root first.
    /// 悬停节点及其祖先，根在前。
    pub fn hovered_path(&self) -> &[Id] {
        &self.hovered_path
    }

    /// The pressed path, for the engine to fold into the build context.
    /// 被按下的路径，供引擎折入构建上下文。
    fn pressed_path_field(&self) -> &[Id] {
        &self.pressed_path
    }

    /// Whether `id` is the pressed node or contains it. A control's thumb is hit first, so
    /// an exact match would hide the press from the control that owns it.
    /// `id` 是被按下节点还是包含它。控件滑块会先被命中，精确匹配会让拥有它的控件看不到按下。
    pub fn pressed_within(&self, id: Id) -> bool {
        self.pressed_path.contains(&id)
    }

    /// Whether a drag that started inside `id` is in progress.
    /// 是否有始于 `id` 内部的拖拽正在进行。
    pub fn dragging_within(&self, id: Id) -> bool {
        match self.drag_owner {
            Some(owner) => owner == id || self.pressed_path.contains(&id),
            None => false,
        }
    }
}

/// User code: describe the UI and react to derived state.
/// 用户代码：描述界面并响应派生状态。
pub trait App {
    /// Produce this frame's live control tree; the engine turns it into declarations.
    /// 产出本帧的活控件树；引擎把它变成声明树。
    fn view(&mut self, cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::element::Element>;

    /// A control reported a semantic change. The engine already resolved which node and
    /// what the new value is, so the app never parses a gesture or hit-tests.
    /// 控件上报了一次语义变化。引擎已解析好归属节点与新值，
    /// 因此 app 既不需要解析手势，也不需要做命中测试。
    fn changed(&mut self, _id: Id, _change: ui_core::change::Change) -> bool {
        false
    }

    /// An app-level shortcut fired: one bound to the loop, not to a control.
    /// 应用级快捷键触发：绑定在循环上，而不是某个控件上。
    fn shortcut(&mut self, _id: ui_core::ShortcutId) -> bool {
        false
    }

    /// The look of the engine's own menu, resolved by the app during `view`. The engine
    /// asks after every `view`, so chrome and content always share one transition.
    /// 引擎自带菜单的外观，由应用在 `view` 中解析。引擎每次 `view` 后索取，
    /// 引擎界面元素与内容因此总处在同一段过渡上。
    fn menu_style(&self) -> Option<crate::menu::MenuStyle> {
        None
    }
}

/// Result of one frame, useful for tests and diagnostics.
/// 单帧结果，供测试与诊断。
#[derive(Debug, Default)]
pub struct FrameOutcome {
    pub damage: Damage,
    pub nodes: usize,
    pub hit: Option<Id>,
    /// Something is still moving: present even without damage so the commit's callback
    /// drives the next frame. Blocking on input here stalls the animation.
    /// 仍有东西在动：即使无脏区也要提交，靠它的回调驱动下一帧。
    /// 在这里等输入会让动画停住。
    pub animating: bool,
    /// Resolved pointer shape for this frame; definite, so a cleared shape cannot stick.
    /// 本帧解析出的指针形状；永远确定，因此清除后不会卡住。
    pub cursor: ui_core::CursorShape,
}

/// What a scene frame produced: the frame, and what the target did with it.
/// 场景帧的产物：这一帧，以及目标把它交给了屏幕什么。
pub struct SceneFrameOutcome {
    pub outcome: FrameOutcome,
    /// `None` when the frame had nothing to show.
    /// 该帧没有可显示的内容时为 `None`。
    pub presented: Option<crate::present::PresentStats>,
}

/// Layout measurement sharing the painter's pass, so both see identical state.
/// 与绘制器共享同一个 pass 的布局测量，二者看到完全相同的状态。
struct PassMeasure(Rc<RefCell<TextPass>>);

/// The build's measurer over an existing pass; never a second pass.
/// 建在既有 pass 之上的构建期测量器；绝不另开一个 pass。
fn shared_measure(text: &Rc<RefCell<TextPass>>) -> Rc<RefCell<dyn ui_core::TextMeasure>> {
    Rc::new(RefCell::new(PassMeasure(Rc::clone(text))))
}

impl ui_core::TextMeasure for PassMeasure {
    fn layout(
        &mut self,
        block: &ui_core::TextBlock,
        max_width: f32,
    ) -> std::rc::Rc<ui_core::InlineLayout> {
        self.0.borrow_mut().layout(block, max_width)
    }

    fn intrinsic(
        &mut self,
        block: &ui_core::TextBlock,
    ) -> (ui_core::Size, ui_core::Size) {
        self.0.borrow_mut().intrinsic(block)
    }
}

/// The row ids the engine supplies for text editing; an app may reuse them in its own menu.
/// 引擎为文本编辑提供的行 id；应用可以在自己的菜单里复用它们。
pub const MENU_SELECT_ALL: &str = "menu/select-all";
pub const MENU_COPY: &str = "menu/copy";
pub const MENU_CUT: &str = "menu/cut";
pub const MENU_PASTE: &str = "menu/paste";

/// The shortcut this node binds for a chord, if any.
/// 本节点为此组合绑定的快捷键（若有）。
fn bound_on(
    node: &ui_core::tree::Node,
    key: ui_core::Key,
    mods: ui_core::Modifiers,
) -> Option<ui_core::ShortcutId> {
    node.data
        .params()?
        .shortcuts
        .iter()
        .find(|(chord, _)| chord.matches(key, mods))
        .map(|(_, id)| *id)
}

/// The start and end byte offsets of the line that holds `at`.
/// `at` 所在行的首尾字节偏移。
fn line_bounds(value: &str, at: usize) -> (usize, usize) {
    let at = ui_core::text_input::clamp(value, at);
    let start = value[..at].rfind('\n').map_or(0, |i| i + 1);
    let end = value[at..].find('\n').map_or(value.len(), |i| at + i);
    (start, end)
}

/// Where a text node's lines start: its box origin moved in by its own padding.
/// 文本节点的行从哪里开始：盒原点向内移动它自己的内边距。
///
/// Hit testing, painting and the caret all read this one answer, or a padded label would
/// wrap at one width and be clicked at another.
/// 命中、绘制与插入符都读这一个答案，否则带内边距的标签会按一种宽度换行、按另一种被点击。
fn text_origin(node: &ui_core::Node) -> ui_core::geom::Point {
    let rect = node.visual_rect();
    ui_core::geom::Point::new(
        rect.origin.x + node.box_model.padding.left,
        rect.origin.y + node.box_model.padding.top,
    )
}

/// Walk the live element tree beside the declaration tree, asking each node for a change.
/// 在声明树旁并行遍历活元素树，逐节点索取语义变化。
fn collect_changes(
    element: &dyn crate::Element,
    decl: &ui_core::Decl,
    tree: &ui_core::Tree,
    cx: &ui_core::cx::Cx<'_>,
    out: &mut Vec<(Id, ui_core::change::Change)>,
) {
    let rect = tree
        .find_by_id(decl.id)
        .and_then(|nid| tree.get(nid))
        .map(|n| n.visual_rect())
        .unwrap_or(Rect::ZERO);
    // `state.local` is the press point in *layout* space, so a control inside a scroller
    // sees content coordinates (the scroller's offset is visual, not layout). Using the
    // visual rect would fold the offset back in and shift every hit inside a scrolled
    // control; hit testing already follows the visual rect, so the press still lands on
    // the right node — this is only about the coordinates handed to `change`.
    // `state.local` 是按下点在**布局**空间中的坐标，因此滚动容器里的控件拿到的是内容坐标
    // （滚动容器的偏移是视觉的，不属于布局）。若用视觉矩形会把偏移折回来，
    // 使滚动容器内每次命中都偏移；命中测试本身已跟随视觉矩形，按下仍落在正确节点上——
    // 这里只涉及交给 `change` 的坐标。
    let mut state = crate::state::WidgetState::of(cx, decl.id);
    let layout_rect = tree
        .find_by_id(decl.id)
        .and_then(|nid| tree.get(nid))
        .map(|n| n.rect)
        .unwrap_or(Rect::ZERO);
    // The press point must be in *this* node's space, not the deepest hit node's.
    // 按下点必须换算到**本**节点空间，而不是最深层命中节点的空间。
    state.local = cx.pointer().map(|p| {
        ui_core::geom::Point::new(p.x - layout_rect.origin.x, p.y - layout_rect.origin.y)
    });
    if let Some(change) = element.change(&state, rect) {
        out.push((decl.id, change));
    }
    let kids = element.children();
    if kids.is_empty() {
        return;
    }
    for (child_element, child_decl) in kids.iter().zip(decl.children.iter()) {
        collect_changes(child_element.as_ref(), child_decl, tree, cx, out);
    }
}

/// Owns the engine state and drives frames.
/// 持有引擎状态并驱动帧循环。
/// The engine's single time source. `now` is monotonic seconds from the loop's epoch.
/// 引擎唯一的时间源。`now` 是相对循环起点的单调秒数。
pub struct FrameClock {
    epoch: std::time::Instant,
    last: std::time::Instant,
    now: f64,
    /// Injectable for tests: returns the next `now` instead of a wall clock.
    /// 测试可注入：返回下一个 `now` 而不是墙钟。
    script: Option<Vec<f64>>,
    cursor: usize,
}

impl Default for FrameClock {
    fn default() -> Self {
        let t = std::time::Instant::now();
        Self {
            epoch: t,
            last: t,
            now: 0.0,
            script: None,
            cursor: 0,
        }
    }
}

impl FrameClock {
    /// A clock that hands out `times` in order, so a test controls every frame.
    /// 按顺序发放 `times` 的时钟，使测试能控制每一帧。
    pub fn scripted(times: Vec<f64>) -> Self {
        let t = std::time::Instant::now();
        Self {
            epoch: t,
            last: t,
            now: *times.first().unwrap_or(&0.0),
            script: Some(times),
            cursor: 0,
        }
    }

    /// Advance to this frame's timestamp. Called exactly once per frame.
    /// 走到本帧时间戳。每帧恰好调用一次。
    pub fn tick(&mut self) -> f64 {
        if let Some(times) = &self.script {
            let t = times.get(self.cursor).copied().unwrap_or(self.now);
            self.cursor += 1;
            self.now = t;
            return t;
        }
        let t = std::time::Instant::now();
        self.now = (t - self.epoch).as_secs_f64();
        self.last = t;
        self.now
    }

    /// This frame's timestamp, without advancing.
    /// 本帧时间戳，不推进。
    pub fn now(&self) -> f64 {
        self.now
    }

    /// The wall clock right now, without advancing the frame's stamp.
    /// 此刻的墙钟，不推进本帧时间戳。
    ///
    /// Input arrives between frames, and those gaps are as long as the user was idle. A
    /// transition started in one must start now, not at the last frame: after a pause of a
    /// second, stamping the old frame would land the whole entrance before it is drawn.
    /// 输入在两帧之间到达，而这段间隙等于用户空闲了多久。在此期间开始的过渡必须从现在起算，
    /// 而不是从上一帧起算：停了一秒之后再盖旧时间戳，入场在画出第一帧之前就走完了。
    pub fn live(&self) -> f64 {
        if self.script.is_some() {
            // A scripted clock only moves when a frame is built; there is no wall to read.
            // 脚本时钟只在建帧时前进，没有可读的墙钟。
            return self.now;
        }
        (std::time::Instant::now() - self.epoch).as_secs_f64()
    }

    /// Push the timestamp forward by `dt` seconds, for scripted test frames.
    /// 为脚本化测试帧把时间戳往前推 `dt` 秒。
    pub fn advance_by(&mut self, dt: f64) {
        self.now += dt;
        let wall = std::time::Instant::now();
        // `tick` derives `now` from `Instant::now() - epoch`, so the epoch has to move with a
        // scripted jump; otherwise the next real frame rewinds time and every running
        // animation freezes until the wall clock catches up.
        // `tick` 用 `Instant::now() - epoch` 求 `now`，故脚本化跳变必须一并移动起点；
        // 否则下一次真实帧会把时间倒退，所有在跑的动画要等墙钟追上才恢复。
        self.epoch = wall
            .checked_sub(std::time::Duration::from_secs_f64(self.now.max(0.0)))
            .unwrap_or(wall);
        self.last = wall;
    }

}

/// One press splat: where it was splatted, how big it may grow, and its life so far.
/// 一次按压墨迹：泼在哪里、最大能多大、已经过了多久。
struct Splat {
    /// The node that asked for the ink; the splat paints on that node only.
    /// 请求该墨迹的节点；墨迹只画在这个节点上。
    node: Id,
    /// The press point in surface space; the node may move or scroll under it.
    /// 按下点，表面空间；节点可能在它下面移动或滚动。
    origin: ui_core::geom::Point,
    ink: ui_core::draw::PressInk,
    started: f64,
    /// When the press ended; the fade starts here and the origin stops mattering.
    /// 按下结束的时刻；淡出从这里起算，落点也不再重要。
    released: Option<f64>,
}

/// How far a leg starting at `start` has travelled by `now`, past its delay, eased.
/// 从 `start` 起（越过延迟后）的一段到 `now` 已走了多远，已缓动。
fn leg(spec: ui_core::AnimSpec, start: f64, now: f64) -> f32 {
    let duration = spec.duration.max(1e-4) as f64;
    let t = ((now - start - spec.delay.max(0.0) as f64) / duration).clamp(0.0, 1.0) as f32;
    spec.easing.apply(t)
}

impl Splat {
    /// Whether the fade after release has finished; such a splat can be dropped.
    /// 松手后的淡出是否已结束；结束的墨迹可以丢弃。
    fn finished(&self, now: f64) -> bool {
        self.released.is_some_and(|at| {
            now >= at + self.ink.fade.delay.max(0.0) as f64 + self.ink.fade.duration.max(0.0) as f64
        })
    }

    /// This frame's circle in surface space, or `None` when it would be invisible.
    /// 本帧的圆，表面空间；不可见时为 `None`。
    ///
    /// `clip` is the effective-background rect in node space, resolved this frame from the
    /// descendant the control named; the ripple sizes to it and is clipped to it, as
    /// Flutter's `_IndicatorInkWell`. `None` uses the node's own box.
    /// `clip` 是控件命名的后代在本帧解析出的有效背景矩形（节点空间）；
    /// 墨迹以它为尺寸与裁剪基准（Flutter `_IndicatorInkWell`）。`None` 用节点自身盒子。
    fn prim(&self, now: f64, node: Rect, clip: Option<Rect>) -> Option<(Rect, ui_core::geom::Color)> {
        let grow = leg(self.ink.grow, self.started, now);
        // The fade-in keeps running after release; freezing it there would freeze the
        // opacity a fast click had reached — which is zero, so the ink would never show.
        // 淡入在松手后继续走；若在那里定格，快点的透明度就定格在 0，墨迹永远不出现。
        let alpha = leg(self.ink.fade_in, self.started, now)
            * match self.released {
                None => 1.0,
                Some(at) => 1.0 - leg(self.ink.fade, at, now),
            };
        if alpha <= 0.0 {
            return None;
        }
        // Measured in node space, so the splat travels with the node when it moves.
        // 按节点空间度量，节点移动时墨迹跟着走。
        let x = self.origin.x - node.origin.x;
        let y = self.origin.y - node.origin.y;
        let (x, y, target) = match self.ink.radius {
            ui_core::InkRadius::Fixed(r) => (x, y, r),
            // Flutter's `InkRipple`: the splash drifts to the reference box centre and ends
            // at half the diagonal, which covers that box from its middle.
            // Flutter 的 `InkRipple`：墨迹漂到参考框中心，终点半径取对角线的一半，
            // 从中心刚好盖住参考框。
            ui_core::InkRadius::Cover => {
                // `clip` is in node space; the node's own box must be too, or the drift
                // target is off by the node's surface origin.
                // `clip` 位于节点空间；节点自身的盒子也必须如此，否则漂移目标会差一个表面原点。
                let box_rect = clip.unwrap_or_else(|| {
                    Rect::from_origin_size(ui_core::geom::Point::ZERO, node.size)
                });
                let cx = box_rect.origin.x + box_rect.size.w * 0.5;
                let cy = box_rect.origin.y + box_rect.size.h * 0.5;
                let half =
                    (box_rect.size.w * box_rect.size.w + box_rect.size.h * box_rect.size.h)
                        .sqrt()
                        * 0.5;
                (x + (cx - x) * grow, y + (cy - y) * grow, half)
            }
        };
        // Flutter starts the radius at 30% of its target, so a tap shows a dot at once.
        // Flutter 的半径从目标的 30% 起步，因此轻点也立刻看得见一个点。
        let radius = target * (0.3 + 0.7 * grow);
        (radius > 0.0).then(|| {
            let colour = ui_core::geom::Color { a: self.ink.colour.a * alpha, ..self.ink.colour };
            // The circle stays whole: the effective-background clip below is a rounded clip,
            // so cutting the rect here would square off the splash inside the pill.
            // 圆保持完整：下方有效背景的裁剪是圆角裁剪，若在此处求交会把胶囊内的墨迹裁成方角。
            (
                Rect::new(
                    node.origin.x + x - radius,
                    node.origin.y + y - radius,
                    radius * 2.0,
                    radius * 2.0,
                ),
                colour,
            )
        })
    }
}

/// One live scrollbar drag: the scroller, the press position, and the offset it began at.
/// 一次进行中的滚动条拖拽：滚动容器、按下位置与起始偏移。
struct ScrollbarDrag {
    id: Id,
    press_y: f32,
    start_offset: f32,
    /// Pixels of track the thumb may travel; the offset's range maps onto it.
    /// thumb 在轨道上的可移动像素；偏移的值域映射到它上面。
    travel: f32,
    /// The offset's range, `extent - viewport`.
    /// 偏移的值域，即 `extent - viewport`。
    overflow: f32,
}

/// A scroller held by the pointer: content follows the finger, and past an end it
/// stretches by a rubber band instead of stopping dead.
/// 被指针抓住的滚动容器：内容跟随手指，越过端点时按橡皮筋拉伸，而不是硬停。
#[derive(Clone, Copy)]
struct ScrollPan {
    id: Id,
    /// The offset the finger has asked for, before any bound is applied. Clamping this
    /// rather than the visible offset keeps a stretch from accumulating error.
    /// 手指要求的偏移，尚未施加边界；夹它而不是夹可见偏移，拉伸因此不会累积误差。
    raw: ui_core::cx::ScrollOffset,
    /// Where the pointer was at the previous move.
    /// 上一次移动时指针的位置。
    last: ui_core::geom::Point,
    /// Offset at the previous frame, for measuring the velocity a fling starts with.
    /// 上一帧的偏移，用于量出惯性起始速度。
    prev: ui_core::cx::ScrollOffset,
    axes: (bool, bool),
    overflow: ui_core::geom::Point,
    viewport: ui_core::geom::Size,
    /// Velocity in logical px/s, opposite the pointer.
    /// 逻辑像素每秒的速度，方向与指针相反。
    v: ui_core::geom::Point,
}

/// A scroller moving after the pointer let go: momentum, then the spring that pulls an
/// overscroll back to the edge.
/// 指针松开后仍在运动的滚动容器：先是惯性，随后由弹簧把越界部分拉回边缘。
#[derive(Clone, Copy)]
struct ScrollMotion {
    /// The hand's speed at release, in logical px/s opposite the pointer.
    /// 松手时手的速度，逻辑像素每秒，方向与指针相反。
    v0: ui_core::geom::Point,
    /// Where the coast began; the closed form is evaluated from here, not from the last
    /// frame, so a long frame lands where the same instant would have put it.
    /// 滑行的起点；闭式解从这里求值而不是从上一帧，长帧因此落在同一时刻该到的位置。
    origin: ui_core::cx::ScrollOffset,
    /// When the coast began.
    /// 滑行开始的时间。
    started_at: f64,
    /// The speed this instant, for the crossing test and the hand-over to the spring.
    /// 此刻的速度，用于越界判定与交给弹簧。
    v: ui_core::geom::Point,
    /// The spring owns the offset from here on.
    /// 此后偏移由弹簧接管。
    spring: bool,
    /// The travel range, captured when the motion began so a relayout cannot retarget it.
    /// 运动开始时记下的可滚动范围，重新布局不会改变它。
    overflow: ui_core::geom::Point,
    /// The viewport the overscroll is damped against, captured with the range.
    /// 越界位移据以阻尼的视口，与可滚动范围一同记下。
    viewport: ui_core::geom::Size,
    /// The edge the spring settles on, fixed when the bounce starts.
    /// 弹簧收敛到的边界，回弹开始时即固定。
    target: ui_core::cx::ScrollOffset,
}

/// Velocity decay per second: GPUI's `0.998` per millisecond.
/// 每秒的速度衰减率：即 GPUI 每毫秒 `0.998`。
const SCROLL_FRICTION: f32 = 2.0;
/// Below this a fling is over, in logical px/s.
/// 惯性到此为止的速度阈值，逻辑像素每秒。
const SCROLL_STOP: f32 = 30.0;
/// How far a stretch travels per unit of drag at the end of the viewport.
/// 端点处每单位拖拽换算成的拉伸距离系数。
const RUBBER: f32 = 0.55;
/// Spring returning an overscroll: under-damped enough to feel like a bounce.
/// 把越界偏移拉回的弹簧：欠阻尼，因此有回弹感。
const BOUNCE_STIFFNESS: f32 = 280.0;
const BOUNCE_DAMPING: f32 = 30.0;
/// A flick reaches the edge faster than the band can absorb; the entry speed is scaled so the
/// overshoot is a nudge, not a jump.
/// 甩动到达边界时比橡皮筋能吸收的更快；入口速度按比例缩减，过冲因此只是一下轻推而非跳变。
const BOUNCE_ENTRY: f32 = 0.35;

/// The insertion caret rests visible this long, then hidden for as long again.
/// 插入符亮这么久、再灭同样久，如此往复。
const CARET_BLINK: f64 = 0.5;

/// The caret and selection a frame holds: a change in either restarts the blink.
/// 一帧持有的插入符与选区：任一变化都会重开闪烁周期。
#[derive(Clone, Copy, PartialEq)]
struct CaretFact {
    /// The editing input and its caret's byte offset.
    /// 正在编辑的输入及其插入符的字节偏移。
    editing: Option<(Id, usize)>,
    /// The read-only selection's owner, anchor and caret.
    /// 只读选区的所有者、锚点与插入符。
    selection: Option<(Id, usize, usize)>,
}

/// `offset` with its overshoot past either end damped, as iOS damps a stretched scroll view.
/// 把越出两端的偏移按 iOS 拉伸滚动视图的方式阻尼。
fn stretch(offset: f32, overflow: f32, viewport: f32) -> f32 {
    if offset < 0.0 {
        -rubber(-offset, viewport)
    } else if offset > overflow {
        overflow + rubber(offset - overflow, viewport)
    } else {
        offset
    }
}

/// How far a stretch of `x` actually travels in a viewport of `dim`; the first pixels are
/// nearly 1:1 and the travel asymptotes, so the content never runs away.
/// `dim` 视口中一段 `x` 的拉伸实际走多远：开头近乎 1:1，随后渐近，内容因此不会跑飞。
fn rubber(x: f32, dim: f32) -> f32 {
    let dim = dim.max(1.0);
    (1.0 - 1.0 / (x * RUBBER / dim + 1.0)) * dim
}

pub struct AppLoop<A: App> {
    app: A,
    tree: Tree,
    engine: BuiltinLayout<Box<dyn ui_core::TextMeasure>>,
    renderer: CpuRenderer,
    text: Rc<RefCell<TextPass>>,
    /// The same pass, shaped for the build: a widget measuring a label must see the faces
    /// paint will use, so it shares `text` rather than opening a second pass.
    /// 同一个 pass，供构建期使用：量标签的控件必须看到绘制会用的字面，因此与 `text` 共用。
    measure: Rc<RefCell<dyn ui_core::TextMeasure>>,
    /// Painted list before text resolution; kept for inspection.
    /// 文本解析前的绘制列表，保留供检查。
    list: DrawList,
    /// Backend-neutral list: text already turned into positioned glyphs.
    /// 后端中立的列表：文本已变成定位好的字形。
    resolved: DrawList,
    scale: f32,
    /// Renderer supersample factor; text must be rasterized on the same finer grid.
    /// 渲染器的超采样倍数；文本必须在同一张更细的网格上光栅。
    supersample: u32,
    /// Atlas generation already copied into the renderer.
    /// 已复制进渲染器的图集代数。
    atlas_version: u64,
    /// Colour-page generation already copied into the renderer.
    /// 已复制进渲染器的颜色页代数。
    color_atlas_version: u64,
    /// Target buffer size of the last presented frame.
    /// 上次呈现帧的目标缓冲区尺寸。
    last_size: (u32, u32),
    /// The only clock in the engine. Ticked once per frame; everything else reads `now`.
    /// 引擎里唯一的时钟。每帧走一次，其余地方只读 `now`。
    clock: FrameClock,
    /// This frame's timestamp, ticked once at the top of the frame.
    /// 本帧时间戳，在帧开头走一次时钟。
    frame_now: f64,
    /// The step the clock took into this frame, in seconds; scroll physics integrates on it.
    /// 时钟到本帧所走的步长（秒）；滚动物理按它积分。
    frame_step: f32,
    /// Whether the last build read the raw pointer position, anywhere in the tree.
    /// 上一次构建是否有节点读过原始指针位置（树里任何一处）。
    pointer_read: bool,
    /// Whether the last build read the clock, so the loop must keep it alive.
    /// 上一次构建是否有节点读过时钟，循环因此必须继续。
    time_driven: bool,
    /// An event arrived that the tree has to be rebuilt for; the loop takes it each build.
    /// 收到了必须重建树的输入事件；循环在每次构建时取走它。
    dispatched: bool,
    /// The engine owns the animation store: it advances it, damages it, and hands it to
    /// the build. An app that held it itself would need a second, conflicting borrow.
    /// 动画存储归引擎：推进、标脏、交给构建。由 app 持有会造成第二处冲突借用。
    anim_store: ui_core::AnimStore,
    damage: DamageAccum,
    frame: u64,
    /// Engine-owned scroll offsets per `SCROLL_OWNED` container; re-applied after every
    /// apply so the app's declaration never resets the wheel position.
    /// 每个 `SCROLL_OWNED` 容器的引擎自有滚动偏移；每次 apply 后重新写回，
    /// 使应用的声明不会重置滚轮位置。
    scroll_offsets: FastMap<Id, ui_core::cx::ScrollOffset>,
    /// Containers a wheel moved since the previous frame; the build reads it once to drive
    /// the auto scrollbar, then it is cleared.
    /// 自上一帧以来有滚轮移动过的容器；构建读取一次以驱动自动滚动条，随后清空。
    scrolled_since: FastSet<Id>,
    /// Textures the app registered, keyed by stable id.
    /// 应用登记的纹理，按稳定标识索引。
    images: FastMap<u64, ui_core::draw::ImageEntry>,
    /// Press splats the engine owns; they outlive the press that made them.
    /// 引擎拥有的按压墨迹；它们比产生自己的那次按下活得更久。
    splats: Vec<Splat>,
    /// Per-frame texture index, so one texture is uploaded once per frame.
    /// 每帧的纹理下标，使一张纹理每帧只上传一次。
    image_slots: FastMap<u64, u32>,
    /// Last frame's ink rect and content hash per node id, for damage diffing.
    /// 上帧每个节点的墨迹矩形与内容哈希，供脏区差分。
    node_prints: FastMap<Id, (Rect, u64)>,
    /// Last frame's offscreen layers. Their opacity and effects live outside every primitive,
    /// so a change to them alone would otherwise produce no damage at all.
    /// 上帧的离屏层。层的不透明度与效果不落在任何图元上，
    /// 只看图元指纹的话它们单独变化时不会产生任何脏区。
    layer_prints: Vec<(Rect, Vec<ui_core::Effect>)>,
    /// Node under the pointer last frame.
    /// 上帧指针下的节点。
    hovered: Option<Id>,
    /// A click completed on this node since the last frame; consumed by the next frame.
    /// 自上一帧以来在此节点上完成的点击；由下一帧消费。
    clicked: Option<Id>,
    /// That node's ancestor chain, root first; rebuilt with the frame.
    /// 该节点的祖先链，根在前；随帧重建。
    clicked_path: Vec<Id>,
    /// Enter or Space reached this node while it held focus; one frame only.
    /// 焦点在此节点时按下了 Enter 或 Space；只存在一帧。
    activated: Option<Id>,
    /// That node's ancestor chain, root first; empty when nothing was activated.
    /// 该节点的祖先链，根在前；无激活时为空。
    activated_path: Vec<Id>,
    /// The popup a press landed outside of; one frame only.
    /// 一次按下落在其之外的浮层；只存在一帧。
    dismissed: Option<Id>,
    /// The chord that fired since the last frame and the node declaring it; one frame only.
    /// 自上一帧以来触发的组合键及其声明节点；只存在一帧。
    shortcut: Option<(Id, ui_core::ShortcutId)>,
    /// The node a drag was released on since the last frame; one frame only.
    /// 自上一帧以来拖拽释放所在的节点；只存在一帧。
    dropped: Option<Id>,
    /// What that release landed on, when the node there accepts drops; one frame only.
    /// 那次释放落到了什么上（该处节点接受放下时）；只存在一帧。
    drop_target: Option<Id>,
    /// Pointer movement since the previous event while a drag is live.
    /// 拖拽进行中，指针相对上一次事件的位移。
    drag_step: Option<ui_core::geom::Point>,
    /// That node's ancestor chain, root first; rebuilt with the frame.
    /// 该节点的祖先链，根在前；随帧重建。
    dropped_path: Vec<Id>,
    /// Hovered node and its ancestors, root first; only hover subscribers appear here.
    /// 悬停节点及其祖先，根在前；只有订阅了悬停的节点会出现在这里。
    hovered_path: Vec<Id>,
    /// Every node under the pointer, subscribers or not; cursor inheritance walks this.
    /// 指针下的每个节点，无论是否订阅；光标继承走这一条。
    pointer_path: Vec<Id>,
    /// The drag gesture in progress, if any.
    /// 正在进行的拖拽手势（若有）。
    drag: ui_core::DragTracker,
    /// Node the primary button went down on, until it is released.
    /// 主键按下的节点，直到松开。
    pressed: Option<Id>,
    /// Where the primary button went down: the threshold is measured from here.
    /// 主键按下时的位置：阈值从这里量起。
    press_at: Option<ui_core::geom::Point>,
    /// The pressed node and its ancestors, so a control sees press through its children.
    /// 被按下节点及其祖先，使控件能透过子节点看到按下。
    pressed_path: Vec<Id>,
    /// Click target; `Escape` or a click elsewhere releases it, pointer leave does not.
    /// 点击目标；`Escape` 或点击别处释放，指针离开**不**释放。
    focused: Option<Id>,
    /// True when the last focus move came from the keyboard, not a pointer press.
    /// 当最近一次焦点移动来自键盘而非指针按下时为真。
    focus_visible: bool,
    /// The popup that last took the keyboard, so its arrival and departure are noticed once.
    /// 上一次接管键盘的浮层，使它的到来与离去各只被注意到一次。
    scope_root: Option<ui_core::NodeId>,
    /// What held focus before that popup opened; closing it hands focus back.
    /// 该浮层打开前持有焦点的节点；关闭时把焦点交还给它。
    focus_before_scope: Option<Id>,
    /// The focus the previous frame ended with, so a move is noticed once.
    /// 上一帧结束时的焦点，使一次移动只被注意到一次。
    focus_shown: Option<Id>,
    /// The focused text input and its selection; a collapsed selection is a plain caret.
    /// 持有焦点的文本输入及其选区；折叠的选区就是一个普通插入符。
    editing: Option<(Id, ui_core::TextSelection)>,
    /// The text node that drew an input's buffer last frame, by the input's own id.
    /// 上一帧绘制某个输入缓冲的文本节点，按输入自身的 id 记。
    input_text_cache: Option<(Id, Id)>,
    /// The text node holding a selection, and that selection.
    /// 持有选区的文本节点，以及该选区。
    selection: Option<(Id, ui_core::TextSelection)>,
    /// The selectable text node a pointer drag is extending.
    /// 指针拖拽正在扩展选区的可选文本节点。
    select_drag: Option<Id>,
    /// The text input a pointer drag is selecting inside.
    /// 指针拖拽正在其中选择的文本输入。
    editing_drag: Option<Id>,
    /// A live scrollbar drag: which scroller, where the press landed, and the offset it
    /// began at. The bar owns the pointer for the duration, like a selection drag.
    /// 正在进行的滚动条拖拽：哪个滚动容器、按在哪里、起始偏移。期间指针归滚动条所有，
    /// 与选区拖拽同理。
    scrollbar_drag: Option<ScrollbarDrag>,
    /// A scroller the pointer is currently dragging.
    /// 指针正在拖动的滚动容器。
    pan: Option<ScrollPan>,
    /// The scroller a live press would pan once it travels past the threshold.
    /// 进行中的按下一旦越过阈值就要拖动的滚动容器。
    pan_candidate: Option<Id>,
    /// Scrollers still coasting or springing back after the pointer let go.
    /// 指针松开后仍在惯性滑行或回弹的滚动容器。
    scroll_motion: FastMap<Id, ScrollMotion>,
    /// The input method's composition, owned by the engine and never merged early.
    /// 输入法的组合内容，归引擎所有，绝不提前并入缓冲。
    preedit: Option<(Id, ui_core::Preedit)>,
    /// What was last handed to the target, so a change with no damage still presents.
    /// 上次交给目标的状态；它变化时即使没有脏区也要呈现。
    last_ime: crate::present::ImeState,
    /// Last primary press on a selectable node, for double-click word selection.
    /// 最近一次落在可选节点上的主键按下，用于双击选词。
    last_press: Option<(f64, ui_core::geom::Point, Id)>,
    /// Held modifiers, reported separately from key events.
    /// 按住的修饰键，与按键事件分开上报。
    modifiers: ui_core::Modifiers,
    /// Hit index of the last laid-out frame; input arrives between frames.
    /// 上一帧的命中索引；输入在两帧之间到达。
    hit: HitIndex,
    /// Latest pointer position, kept so `dispatch` can re-run the hit test.
    /// 最新指针位置，供 `dispatch` 重做命中测试。
    pointer: Option<ui_core::geom::Point>,
    /// The shape the target was last told; a move that only changes it still needs a frame.
    /// 目标上一次收到的形状；只改变它的移动仍需要一帧。
    cursor_sent: ui_core::CursorShape,
    /// When the caret's blink cycle last restarted; any caret movement moves it to now.
    /// 插入符闪烁周期上一次重新开始的时间；插入符一动就移到当前。
    caret_blink_at: f64,
    /// The caret fact of the previous frame: a change restarts the cycle.
    /// 上一帧的插入符事实：它一变就重开周期。
    caret_last: CaretFact,
    /// Whether this frame drew a caret: the blink's own reason to want the next one.
    /// 本帧是否画了插入符：这是闪烁自己索要下一帧的理由。
    caret_painted: bool,
    /// Declarations kept from the previous frame, reused while the facts they read hold.
    /// 上一帧留下的声明；其读取的事实仍然成立时直接复用。
    decl_cache: ui_core::DeclCache,
    /// Set when something the cache cannot see changed; the next build drops every entry.
    /// 当缓存看不见的东西发生变化时置位；下一次构建丢弃全部条目。
    decls_stale: bool,
    /// Clipboard work the engine asked for; the host drains it and hands it to the platform.
    /// 引擎请求的剪贴板工作；宿主取走后交给平台。
    clipboard: Vec<crate::clipboard::ClipboardCommand>,
    /// App-level bindings and the built-in text-editing table.
    /// 应用级绑定与内置的文本编辑表。
    shortcuts: crate::shortcut::Bindings,
    /// The open context menu, if any; the engine draws and hit-tests it itself.
    /// 已打开的上下文菜单（若有）；引擎自己绘制并命中测试它。
    menu: Option<crate::menu::OpenMenu>,
    /// How that menu looks; a design system replaces it through `set_menu_style`.
    /// 该菜单的外观；设计体系通过 `set_menu_style` 替换它。
    menu_style: crate::menu::MenuStyle,
    /// The app's words for the engine's built-in text rows; none until it supplies them.
    /// 应用为引擎内建文本行提供的措辞；应用给出之前为空。
    text_menu_labels: Option<crate::menu::TextMenuLabels>,
}

impl<A: App> AppLoop<A> {
    /// How a node kind participates in hit testing. An engine rule, not an app one:
    /// text paints but must not swallow the pointer, or a label steals its container's
    /// hover and every click lands on the wrong node.
    /// 节点种类如何参与命中测试。这是引擎规则而非应用规则：
    /// Text paints but must not swallow the pointer, or a label steals its control's hover.
    /// 文字会绘制但不得吞掉指针，否则标签会抢走容器的悬停，每次点击都落到错误的节点上。
    fn hit_behavior_of(kind: NodeKind, sense: ui_core::Sense, disabled: bool) -> HitBehavior {
        // An inert node takes nothing: no press, no hover, no drop.
        // 惰性节点不接受任何输入：不按下、不悬停、不放置。
        if disabled {
            return HitBehavior::Ignore;
        }
        // A node that lets hover through stays in the index but never ends the search.
        // 允许悬停透传的节点仍在索引里，但不会终结查找。
        if sense.contains(ui_core::Sense::PASS_THROUGH) {
            return HitBehavior::PassThrough;
        }
        match kind {
            // Only text that asked to be selectable takes the pointer; every other label
            // stays inert so it cannot steal the click of the control it sits in.
            // 只有声明可选中的文本接收指针；其余标签保持惰性，免得抢走所在控件的点击。
            NodeKind::Text if sense.contains(ui_core::Sense::SELECT) => HitBehavior::Opaque,
            NodeKind::Text => HitBehavior::Ignore,
            _ => HitBehavior::Opaque,
        }
    }

    /// Loop whose text uses an explicit font stack.
    /// 文本使用显式字体栈的循环。
    pub fn with_stack(app: A, families: &[&str]) -> Self {
        let mut this = Self::new(app);
        // One pass for both layout and paint: two instances diverge because their face
        // caches end up in different states, and then the line breaks differ.
        // 布局与绘制共用一个 pass：两个实例的字面缓存状态会分叉，进而断行位置不同。
        this.text = Rc::new(RefCell::new(TextPass::with_stack(families)));
        this.engine = BuiltinLayout::new(Box::new(PassMeasure(Rc::clone(&this.text))));
        this.measure = shared_measure(&this.text);
        this
    }

    pub fn new(app: A) -> Self {
        let text = Rc::new(RefCell::new(TextPass::new()));
        Self {
            app,
            tree: Tree::new(),
            engine: BuiltinLayout::new(Box::new(MonospaceMeasure::default())),
            renderer: CpuRenderer::new(),
            measure: shared_measure(&text),
            text,
            list: DrawList::default(),
            resolved: DrawList::default(),
            scroll_offsets: FastMap::default(),
            scrolled_since: FastSet::default(),
            images: FastMap::default(),
            splats: Vec::new(),
            image_slots: FastMap::default(),
            scale: 1.0,
            supersample: 1,
            atlas_version: u64::MAX,
            color_atlas_version: 0,
            last_size: (0, 0),
            clock: FrameClock::default(),
            frame_now: 0.0,
            frame_step: 0.0,
            pointer_read: false,
            time_driven: false,
            dispatched: false,
            anim_store: ui_core::AnimStore::new(),
            damage: DamageAccum::new(),
            frame: 0,
            node_prints: FastMap::default(),
            layer_prints: Vec::new(),
            hovered: None,
            pressed: None,
            focused: None,
            focus_visible: false,
            scope_root: None,
            focus_before_scope: None,
            focus_shown: None,
            editing: None,
            input_text_cache: None,
            selection: None,
            select_drag: None,
            editing_drag: None,
            scrollbar_drag: None,
            pan: None,
            pan_candidate: None,
            scroll_motion: FastMap::default(),
            preedit: None,
            last_ime: crate::present::ImeState::default(),
            last_press: None,
            modifiers: ui_core::Modifiers::default(),
            hit: HitIndex::new(),
            pointer: None,
            cursor_sent: ui_core::CursorShape::Arrow,
            caret_blink_at: 0.0,
            caret_last: CaretFact {
                editing: None,
                selection: None,
            },
            caret_painted: false,
            clicked: None,
            clicked_path: Vec::new(),
            activated: None,
            activated_path: Vec::new(),
            dismissed: None,
            shortcut: None,
            dropped: None,
            drop_target: None,
            dropped_path: Vec::new(),
            drag_step: None,
            hovered_path: Vec::new(),
            pointer_path: Vec::new(),
            pressed_path: Vec::new(),
            drag: ui_core::DragTracker::new(),
            press_at: None,
            decl_cache: ui_core::DeclCache::default(),
            decls_stale: true,
            clipboard: Vec::new(),
            shortcuts: crate::shortcut::Bindings::with_builtins(),
            menu: None,
            menu_style: crate::menu::MenuStyle::default(),
            text_menu_labels: None,
        }
    }

    /// Replace the fallback menu's look with the design system's own.
    /// 用设计体系自己的外观替换兜底菜单。
    pub fn set_menu_style(&mut self, style: crate::menu::MenuStyle) {
        self.menu_style = style;
    }

    /// Supply the words the built-in text rows are shown with; `None` withdraws them.
    /// 提供内建文本行显示用的措辞；`None` 撤回它们。
    pub fn set_text_menu_labels(&mut self, labels: Option<crate::menu::TextMenuLabels>) {
        self.text_menu_labels = labels;
    }

    /// The chord `id` answers right now, so an app can print it beside a menu row.
    /// `id` 此刻响应的组合键，应用据此在菜单行旁印出它。
    pub fn shortcut(&self, id: ui_core::ShortcutId) -> Option<ui_core::KeyChord> {
        self.shortcuts.chord_of(id)
    }

    /// Bind a chord for the whole app: it fires only when no control claimed it.
    /// 为整个应用绑定一个组合键：只有没有控件认领时它才触发。
    pub fn bind_shortcut(&mut self, chord: ui_core::KeyChord, id: ui_core::ShortcutId) {
        self.shortcuts.bind(chord, id);
    }

    /// Point an id at another chord, built-in or app-level.
    /// 把一个 id 改绑到另一个组合键，内置与应用级都可以。
    pub fn rebind_shortcut(&mut self, id: ui_core::ShortcutId, chord: ui_core::KeyChord) {
        self.shortcuts.rebind(id, chord);
    }

    /// Drop every binding of `id`; the chords reach nothing afterwards.
    /// 移除 `id` 的全部绑定；此后这些组合键不再命中任何东西。
    pub fn unbind_shortcut(&mut self, id: ui_core::ShortcutId) {
        self.shortcuts.unbind(id);
    }

    /// Clipboard work this frame's events asked for; the host hands it to the platform.
    /// 本帧事件请求的剪贴板工作；由宿主交给平台。
    pub fn take_clipboard_commands(&mut self) -> Vec<crate::clipboard::ClipboardCommand> {
        std::mem::take(&mut self.clipboard)
    }

    /// Drop every cached declaration; the app calls this when it changed state silently.
    /// 丢弃全部缓存声明；app 静默改动了状态时调用。
    pub fn invalidate_decls(&mut self) {
        self.decls_stale = true;
    }

    /// How many declarations the cache is holding, for diagnostics.
    /// 缓存当前持有多少声明，供诊断。
    pub fn cached_decls(&self) -> usize {
        self.decl_cache.len()
    }

    /// Cache entries held, plus the running hit and miss totals.
    /// 持有的缓存条目数，以及累计的命中与未命中次数。
    pub fn decl_cache_stats(&self) -> (usize, u64, u64) {
        self.decl_cache.stats()
    }

    /// What still keeps the loop awake, with the node each animation belongs to.
    /// 仍让循环停不下来的东西，连同每条动画所属的节点。
    /// Whether this pointer position can change what the last frame drew.
    /// 这个指针位置是否会改变上一帧画出来的东西。
    ///
    /// A loop uses it to absorb pointer samples above the refresh rate: moving inside one
    /// hover owner, with nothing reading the position, cannot change a pixel.
    /// 循环据此吸收高于刷新率的指针样本：在同一个悬停所有者内部移动、又没有东西读位置时，
    /// 它改不动任何一个像素。
    pub fn pointer_affects_frame(&self, p: ui_core::geom::Point) -> bool {
        // A gesture owns the position; every sample must reach the tree. A text selection
        // is one of them: it takes the press without keeping `pressed`, and it repaints
        // while the hover stays exactly where it was.
        // 手势拥有这个位置：每个样本都必须送进树里。文本拖选就是其中之一：
        // 它接下按下却不留 `pressed`，而且悬停原地不动时它照样改变绘制。
        if self.pressed.is_some() || self.pan.is_some() || self.select_drag.is_some() {
            return true;
        }
        // Something asked for the raw position, so it can change anywhere inside itself.
        // 有东西要了原始位置，因此它内部任何一点都可能变。
        if self.pointer_read {
            return true;
        }
        let hovered = self
            .hit
            .topmost_consumer(p)
            .and_then(|nid| self.tree.get(nid).map(|n| n.id))
            .and_then(|id| self.hover_owner(id));
        // A shape reaches the target only with a frame, so a move that changes just the
        // shape is still work: hovering a paragraph changes no pixel of its own.
        // 形状只能随帧下发，因此只改变形状的移动仍是活：悬停一段文字本身不改任何像素。
        hovered != self.hovered || self.cursor_shape_at(p) != self.cursor_sent
    }

    /// Whether an event since the last call requires a build; takes the flag.
    /// 自上次调用以来是否有事件需要重建；取走后复位。
    pub fn take_dispatched(&mut self) -> bool {
        std::mem::take(&mut self.dispatched)
    }

    /// Ask for a rebuild with no event behind it: an app that changed its own state says so.
    /// 在没有事件的情况下要求重建：自己改了状态的应用要自己说出来。
    pub fn request_frame(&mut self) {
        self.dispatched = true;
    }

    /// Whether anything in the engine still wants the next frame.
    /// 引擎里是否还有东西需要下一帧。
    pub fn is_animating(&self) -> bool {
        self.anim_store.is_animating(self.clock.now())
            || !self.splats.is_empty()
            || !self.scroll_motion.is_empty()
            || self
                .menu
                .as_ref()
                .is_some_and(|m| m.entrance(self.clock.now()).0 < 1.0)
            // A control that read the clock must be rebuilt to see the new time.
            // 读过时钟的控件必须重建才能看到新时间。
            || self.time_driven
    }

    /// The caret and selection this frame holds, in the shape a blink reset compares.
    /// 本帧持有的插入符与选区，即闪烁重置所比较的那个形状。
    fn caret_fact(&self) -> CaretFact {
        CaretFact {
            editing: self.editing.map(|(id, s)| (id, s.caret)),
            selection: self.selection.map(|(id, s)| (id, s.anchor, s.caret)),
        }
    }

    /// Whether the caret is in its lit half of the cycle at `now`.
    /// `now` 时刻插入符是否处在周期的亮半程。
    fn caret_blink_lit(&self, now: f64) -> bool {
        let elapsed = (now - self.caret_blink_at).max(0.0);
        ((elapsed / CARET_BLINK) as u64).is_multiple_of(2)
    }

    /// How long the engine itself wants to be woken, with no input: the caret's next toggle.
    /// 没有输入时引擎自己想被叫醒的时间：插入符的下一次明灭。
    pub fn next_wake(&self) -> Option<std::time::Duration> {
        if !self.caret_painted || self.editing.is_none() {
            return None;
        }
        let elapsed = (self.frame_now - self.caret_blink_at).max(0.0);
        Some(std::time::Duration::from_secs_f64(
            CARET_BLINK - elapsed % CARET_BLINK,
        ))
    }

    pub fn anim_report(&self) -> String {
        let moving = self.anim_store.moving(self.clock.now());
        let (springs, live) = self.anim_store.spring_counts();
        // A frozen spring is the whole question here, so the counts come first.
        // 这里要回答的就是"弹簧僵住了"，因此先给出计数。
        let head = format!(
            "springs={live}/{springs} scroll={} tween={}",
            self.scroll_motion.len(),
            moving.len().saturating_sub(live)
        );
        if moving.is_empty() {
            return format!("still ({head})");
        }
        let body = moving
            .iter()
            .map(|m| {
                let place = self
                    .tree
                    .find_by_id(m.id())
                    .and_then(|n| self.tree.get(n))
                    .map(|n| format!("{:?}@{:?}", n.kind, n.rect.origin))
                    .unwrap_or_else(|| "no node (derived id)".to_string());
                format!("{m} -> {place}")
            })
            .collect::<Vec<_>>()
            .join("; ");
        format!("{head} | {body}")
    }

    /// Device pixels per logical unit. Text is rasterized and placed at this scale.
    /// 每个逻辑单位的设备像素数。文本按此比例光栅与定位。
    pub fn set_scale(&mut self, scale: f32) {
        if scale.is_finite() && scale > 0.0 {
            if scale != self.scale {
                self.decls_stale = true;
            }
            self.scale = scale;
        }
    }

    /// The grid text is rasterized on: the device scale times the renderer's supersample.
    /// 文本光栅所用的网格：设备比例乘渲染器的超采样倍数。
    pub fn set_supersample(&mut self, ss: u32) {
        self.supersample = ss.clamp(1, 4);
    }

    fn text_scale(&self) -> f32 {
        self.scale * self.supersample as f32
    }

    pub fn scale(&self) -> f32 {
        self.scale
    }

    /// The backend-neutral draw list: every `Text` primitive already resolved to glyphs.
    /// 后端中立的绘制列表：每个 `Text` 图元都已解析成字形。
    pub fn draw_list(&self) -> &DrawList {
        &self.resolved
    }

    pub fn text_pass(&self) -> std::cell::Ref<'_, TextPass> {
        self.text.borrow()
    }

    /// Mutable text pass, for measuring and diagnostics.
    /// 可变的文本 pass，用于测量与诊断。
    pub fn text_pass_mut(&mut self) -> std::cell::RefMut<'_, TextPass> {
        self.text.borrow_mut()
    }

    pub fn tree(&self) -> &Tree {
        &self.tree
    }

    /// The engine's stored offset for a `SCROLL_OWNED` container, or `None` when the id
    /// never received a wheel. Tests and apps that follow the scroll read this instead of
    /// keeping their own copy.
    /// 一个 `SCROLL_OWNED` 容器的引擎存储偏移；该 id 从未收到滚轮时为 `None`。
    /// 测试与跟随滚动的应用应读这里，而不是自己留一份副本。
    pub fn scroll_of(&self, id: Id) -> Option<f32> {
        self.scroll_offsets.get(&id).map(|o| o.y)
    }

    /// Both stored offsets of a `SCROLL_OWNED` container; `None` when it never scrolled.
    /// 一个 `SCROLL_OWNED` 容器的双轴存储偏移；从未滚动过时为 `None`。
    pub fn scroll_offset(&self, id: Id) -> Option<ui_core::cx::ScrollOffset> {
        self.scroll_offsets.get(&id).copied()
    }

    /// Register a texture once; the app refers to it by `ImageSpec::id`.
    /// 登记一张纹理；应用通过 `ImageSpec::id` 引用它。
    pub fn register_image(&mut self, entry: ui_core::draw::ImageEntry) {
        self.images.insert(entry.id, entry);
    }

    /// Register font bytes under `name`; runs naming that family resolve to them.
    /// 把字体字节注册到 `name` 下；指定该族的 run 会解析到这些字节。
    ///
    /// The bytes stay the host's business: the engine ships no fonts, and a proprietary one
    /// must be supplied by whoever is allowed to distribute it.
    /// 字节由宿主负责：引擎不自带字体，专有字体必须由有权分发的一方提供。
    pub fn register_font(&mut self, name: &str, data: std::sync::Arc<[u8]>) -> bool {
        self.text.borrow_mut().register(name, data)
    }

    pub fn app_mut(&mut self) -> &mut A {
        &mut self.app
    }

    /// Write `id`'s ancestor chain into `out`, root first; empty when there is no such node.
    /// 把 `id` 的祖先链自根向叶写入 `out`；没有该节点时清空。
    fn fill_ancestors(tree: &ui_core::Tree, out: &mut Vec<Id>, id: Option<Id>) {
        out.clear();
        let mut cur = id.and_then(|id| tree.find_by_id(id));
        while let Some(node) = cur.and_then(|nid| tree.get(nid)) {
            out.push(node.id);
            cur = node.parent;
        }
        out.reverse();
    }

    /// Run one frame against `target`, advancing animations by the wall clock.
    /// 对 `target` 跑一帧，动画按墙钟推进。
    pub fn frame(
        &mut self,
        target: &mut dyn PresentTarget,
        pointer: Option<ui_core::geom::Point>,
    ) -> FrameOutcome {
        self.present(target, pointer, None)
    }

    /// Present one frame after advancing animations by exactly `dt` seconds; `0.0` freezes them.
    /// 把动画恰好推进 `dt` 秒后呈现一帧；`0.0` 即冻结动画。
    /// Test-only: production uses `frame`. Scripted time never reads the wall clock.
    /// 仅测试：生产用 `frame`。脚本化时间不读墙钟。
    pub fn frame_with_dt(
        &mut self,
        target: &mut dyn PresentTarget,
        pointer: Option<ui_core::geom::Point>,
        dt: f32,
    ) -> FrameOutcome {
        self.present(target, pointer, Some(dt.max(0.0)))
    }

    /// Build one frame and hand its scene to `target`; the engine owns the commit decision.
    /// 构建一帧并把场景交给 `target`；提交与否由引擎决定。
    pub fn frame_scene(
        &mut self,
        target: &mut dyn crate::present::SceneTarget,
        pointer: Option<ui_core::geom::Point>,
    ) -> Result<SceneFrameOutcome, String> {
        let (outcome, damage, ime, ime_changed) =
            timed!("build", self.begin_frame(target.size(), pointer, None));
        // Before any early return: the shape can change on a frame that paints nothing, and
        // a still pointer produces no further event to carry it later.
        // 必须在任何提前返回之前：形状可能在一帧什么都不画时改变，
        // 而指针静止时不会再有事件替它捎带。
        target.set_cursor(outcome.cursor);
        target.set_ime(ime);
        // Still frames hand nothing over; an animating one must commit even with no damage,
        // because that commit is what requests the callback the loop paces on.
        // 静止帧什么都不交；运动中的帧即使无脏区也必须提交，
        // 因为这次 commit 才会申请循环配速所依赖的回调。
        if damage.is_none() && !outcome.animating && !ime_changed && !target.commit_pending() {
            return Ok(SceneFrameOutcome {
                outcome,
                presented: None,
            });
        }
        let text = self.text.borrow();
        let presented = timed!("present", target.present_scene(&self.resolved, &text, &damage))?;
        Ok(SceneFrameOutcome {
            outcome,
            presented: Some(presented),
        })
    }

    /// Drive each transitioned node's fixed axes toward the size it declared, writing the
    /// interpolated values back before layout; a settled node matches its declaration.
    /// 把每个过渡节点的固定轴推向它声明的尺寸，布局前写回插值；落定后与声明一致。
    fn resolve_size_transitions(&mut self) {
        if self.tree.animated().is_empty() {
            return;
        }
        // The list lives on the tree; take a copy so nodes can be written while walking it.
        // 列表归树所有；先复制一份，遍历时才能写节点。
        let ids = self.tree.animated().to_vec();
        let now = self.frame_now;
        for nid in ids {
            let Some((id, spec, target)) = self.tree.get(nid).and_then(|n| {
                let spec = n.data.params()?.size_transition?;
                Some((n.id, spec, n.declared_size))
            }) else {
                continue;
            };
            let mut size = target;
            let mut moving = false;
            for (axis, key) in [(&mut size.width, "size.w"), (&mut size.height, "size.y")] {
                let AxisSize {
                    sizing: Sizing::Definite(Len::Px(asked)),
                    ..
                } = *axis
                else {
                    continue;
                };
                let value = self.anim_store.animate(id.with(key), asked, spec, now);
                moving |= (value - asked).abs() > 0.01;
                *axis = AxisSize::fixed(value);
            }
            if let Some(n) = self.tree.get_mut(nid) {
                n.size_class = size;
            }
            if moving {
                self.tree.mark_dirty_up(nid);
            }
        }
    }

    /// Advance each entering node toward full presence, and each held one toward zero.
    /// 把每个入场节点推向完全在场，把每个被持有的节点推向零。
    fn resolve_presence(&mut self) {
        // A node id outlives the node, so a dialog shown again must start over.
        // 节点 id 比节点本身活得长，因此再次出现的对话框必须从头开始。
        for nid in self.tree.appeared().to_vec() {
            if let Some(id) = self.tree.get(nid).map(|n| n.id) {
                self.anim_store.forget(id.with("presence"));
            }
        }
        let now = self.frame_now;
        for nid in self.tree.animated().to_vec() {
            let Some((id, enter, presence)) = self.tree.get(nid).and_then(|n| {
                Some((n.id, n.data.params()?.enter?, n.presence))
            }) else {
                continue;
            };
            let value = self
                .anim_store
                .travel(id.with("presence"), presence, 1.0, enter.spec, now);
            // A scale on its own clock: WinUI fades its dialog in 83 ms and scales it over
            // 250, and one shared value would make one of the two wrong.
            // 缩放走自己的时钟：WinUI 的对话框 83 毫秒淡完、缩放走 250 毫秒，
            // 共用一个值必然让其中之一出错。
            let scale_value = match enter.scale_spec {
                Some(spec) => self
                    .anim_store
                    .travel(id.with("presence-scale"), presence, 1.0, spec, now),
                None => value,
            };
            self.paint_presence(nid, enter, value, scale_value);
        }

        // Exit: the node is already out of the declaration and out of layout; it only has
        // to fade out where it stood, and then nothing of it remains.
        // 退场：节点已离开声明与布局，只需在原处淡出，之后不再留下任何东西。
        for nid in self.tree.held().to_vec() {
            let Some((id, exit, presence)) = self.tree.get(nid).and_then(|n| {
                Some((n.id, n.data.params()?.exit?, n.presence))
            }) else {
                self.tree.release(nid);
                continue;
            };
            // A node is held once in its life, so the handle names this exit uniquely: it
            // cannot inherit the landed 0 a previous appearance left behind.
            // 一个节点一生只被持有一次，句柄因此唯一标识这次退场：它不会继承上次留下的 0。
            let key = id.with(("exit", nid.index(), nid.generation()));
            let value = self.anim_store.travel(key, presence, 0.0, exit.spec, now);
            if value <= 0.0 {
                self.anim_store.forget(key);
                self.anim_store.forget(id.with("presence-scale"));
                self.tree.release(nid);
            } else {
                let scale_value = match exit.scale_spec {
                    Some(spec) => {
                        self.anim_store
                            .travel(id.with("presence-scale"), presence, 0.0, spec, now)
                    }
                    None => value,
                };
                self.paint_presence(nid, exit, value, scale_value);
            }
        }
    }

    /// Write what paint reads for a node `value` of the way from `far` to its declaration.
    /// 写回绘制所读的值：节点正处于从 `far` 走向声明值、已完成 `value` 的比例。
    fn paint_presence(
        &mut self,
        nid: ui_core::NodeId,
        far: ui_core::tree::Presence,
        value: f32,
        scale_value: f32,
    ) {
        if let Some(n) = self.tree.get_mut(nid) {
            n.presence = value;
            // The far values are interpolated, not multiplied: a slide that keeps opacity
            // at 1 must stay fully opaque while it travels.
            // 远端值是插值而不是相乘：保持不透明度为 1 的滑入在行进中必须始终不透明。
            n.presence_alpha = far.opacity + value * (1.0 - far.opacity);
            n.presence_shift = far.offset * (1.0 - value);
            // Landed values snap: a scale a hair off 1 would keep every glyph in the subtree
            // on the transformed path for the rest of the frame.
            // 落定值取整：差之毫厘的缩放会让子树里每个字形都继续走变换路径。
            n.presence_scale = if scale_value >= 1.0 {
                1.0
            } else {
                far.scale + scale_value * (1.0 - far.scale)
            };
        }
    }

    /// Everything a frame needs before it can be drawn: size, build, damage, IME state.
    /// 一帧在能画之前需要的一切：尺寸、构建、脏区、输入法状态。
    fn begin_frame(
        &mut self,
        (dw, dh): (u32, u32),
        pointer: Option<ui_core::geom::Point>,
        step: Option<f32>,
    ) -> (FrameOutcome, ui_core::Damage, crate::present::ImeState, bool) {
        // Layout runs in logical units; the buffer is larger by the scale factor.
        // 布局在逻辑单位下进行；缓冲区按缩放系数更大。
        let scale = self.scale;
        let logical = (
            (dw as f32 / scale).round() as u32,
            (dh as f32 / scale).round() as u32,
        );
        // A resize repaints everything: the damage diff was computed against a buffer of a
        // different size, so its rects mean nothing in the new one.
        // 尺寸变化即整帧重画：脏区差分是针对另一个尺寸的缓冲算出的，在新缓冲里没有意义。
        if self.last_size != (dw, dh) {
            self.last_size = (dw, dh);
            self.damage.add_full();
            self.decls_stale = true;
        }
        let outcome = self.build_step(logical, pointer, step);
        let damage = outcome.damage.clone();
        // The IME state travels with the same frame's layout: its caret rect is what the
        // compositor places the candidate window against.
        // 输入法状态随同一帧的布局一起送出：合成器按它的插入符矩形摆放候选窗。
        let ime = self.ime_state();
        let ime_changed = ime != self.last_ime;
        self.last_ime = ime.clone();
        (outcome, damage, ime, ime_changed)
    }

    fn present(
        &mut self,
        target: &mut dyn PresentTarget,
        pointer: Option<ui_core::geom::Point>,
        step: Option<f32>,
    ) -> FrameOutcome {
        let scale = self.scale;
        let (outcome, damage, ime, ime_changed) =
            self.begin_frame(target.size(), pointer, step);
        target.set_cursor(outcome.cursor);
        target.set_ime(ime);
        self.renderer.set_scale(scale);

        // Hand the atlas to the renderer only when it actually grew: copying 1 MiB
        // every frame would dominate the frame cost.
        // 只在图集确实增长时交给渲染器：每帧复制 1 MiB 会主导帧开销。
        let pass = self.text.borrow();
        if pass.version() != self.atlas_version {
            self.atlas_version = pass.version();
            let (w, h) = pass.dimensions();
            self.renderer.set_atlas(ui_paint::CoverageAtlas {
                width: w,
                height: h,
                data: pass.atlas().to_vec(),
            });
        }
        // The colour page changes only when an emoji is first rasterized; re-uploading
        // its megabytes alongside every text glyph would be waste.
        // 颜色页只在首次光栅出 emoji 时变化；随每个文字字形重传几兆是浪费。
        if pass.color_version() != self.color_atlas_version {
            self.color_atlas_version = pass.color_version();
            if !pass.color_atlas().is_empty() {
                let (w, h) = pass.color_dimensions();
                self.renderer.set_color_atlas(ui_paint::ColorAtlas {
                    width: w,
                    height: h,
                    data: pass.color_atlas().to_vec(),
                });
            }
        }

        // Still frames hand nothing over; an animating one must present even with no
        // damage, because the commit is what requests the callback the loop paces on.
        // 静止帧什么都不交付；运动中的帧即使无脏区也必须提交，
        // 因为这次 commit 才会申请帧回调，循环靠它配速。
        if damage.is_none() && !outcome.animating && !ime_changed {
            return outcome;
        }

        let target_pixels = target.pixels_mut();
        self.renderer.render(&self.resolved, target_pixels, &damage);
        // The renderer repaints the whole surface, so the compositor must be told the whole
        // surface changed. Reporting only the diff would leave it showing its cached copy
        // wherever we repainted but did not report — the same class of stale-pixel bug as
        // the caching this replaced.
        // 渲染器重画整个表面，因此必须告知合成器整个表面都变了。只上报差分会让它在我们
        // 重画过却没上报的地方继续显示缓存副本——与被替换掉的缓存属于同一类陈旧像素缺陷。
        let _ = target.present(&ui_core::damage::Damage::Full);
        outcome
    }

    /// Build one frame without touching a backend, advancing animations by the wall clock.
    /// 不触碰后端地构建一帧，动画按墙钟推进。
    pub fn build(
        &mut self,
        size: (u32, u32),
        pointer: Option<ui_core::geom::Point>,
    ) -> FrameOutcome {
        self.build_step(size, pointer, None)
    }

    /// Build with an explicit time step, so animations advance by exactly that amount.
    /// 用显式时间步构建，使动画恰好推进该时长。
    pub fn build_with_dt(
        &mut self,
        size: (u32, u32),
        pointer: Option<ui_core::geom::Point>,
        dt: f32,
    ) -> FrameOutcome {
        self.build_step(size, pointer, Some(dt.max(0.0)))
    }

    fn build_step(
        &mut self,
        (w, h): (u32, u32),
        pointer: Option<ui_core::geom::Point>,
        step: Option<f32>,
    ) -> FrameOutcome {
        // The surface size, kept for anything placed outside the tree (the context menu).
        // 表面尺寸，供树之外摆放的东西使用（上下文菜单）。
        self.last_size = (w, h);
        // Scripted time moves by exactly the step; with none, the clock reads the wall.
        // 脚本化时间恰好走一步；没有给步长时，时钟读墙钟。
        match step {
            Some(dt) => self.clock.advance_by(dt as f64),
            None => {
                self.clock.tick();
            }
        }
        // Adopt the timestamp before anything reads it: `FrameInfo` and the animation
        // store must see this frame's time, not the previous frame's.
        // 在任何读取之前采用本帧时间戳：`FrameInfo` 与动画存储必须看到本帧的时间。
        let previous_now = self.frame_now;
        self.frame_now = self.clock.now();
        // The step the clock actually took, capped so a stalled app cannot fling the content.
        // 时钟实际走过的步长，取上限使卡顿的应用无法把内容甩出去。
        self.frame_step = (self.frame_now - previous_now).clamp(0.0, 0.05) as f32;
        // What the caller asked for when scripting time, else what the wall clock took.
        // 脚本化时取调用方所给的步长，否则取墙钟实际走过的量。
        let dt = step.unwrap_or(self.frame_step);
        // A splat that finished fading is gone before anything paints it again.
        // 淡出结束的墨迹在任何东西再画它之前就丢掉。
        self.splats.retain(|splat| !splat.finished(self.frame_now));
        // The click's chain is derived here, so the context can answer `clicked_within`
        // for a control whose root is an ancestor of the node that was actually hit.
        // 点击的祖先链在此重建，使控件根节点（实际命中节点的祖先）也能回答 `clicked_within`。
        Self::fill_ancestors(&self.tree, &mut self.clicked_path, self.clicked);
        Self::fill_ancestors(&self.tree, &mut self.activated_path, self.activated);
        Self::fill_ancestors(&self.tree, &mut self.dropped_path, self.dropped);
        // A caret that just moved is solid at once: restart the cycle before anything
        // decides whether to draw it, so the frame the user typed into shows it.
        // 刚移过的插入符立刻是亮的：在决定画不画它之前重开周期，
        // 用户刚刚输入的那一帧因此一定看得见它。
        let fact = self.caret_fact();
        if self.caret_last != fact {
            self.caret_last = fact;
            self.caret_blink_at = self.frame_now;
        }
        self.caret_painted = false;
        let caret_in_text = self.caret_in_text_fact();
        let mut info = FrameInfo {
            width: w,
            height: h,
            pointer,
            frame: self.frame,
            // The previous frame's answer: input arrives between frames, not during one.
            // 上一帧的答案：输入在两帧之间到达，而不是帧内。
            hovered: self.hovered,
            pressed: self.pressed,
            clicked_path: self.clicked_path.clone(),
            dropped_path: self.dropped_path.clone(),
            drop_target: self.drop_target,
            drag_step: self.drag_step,
            focused: self.focused,
            focus_visible: self.focus_visible,
            activated: self.activated,
            activated_path: self.activated_path.clone(),
            dismissed: self.dismissed,
            shortcut: self.shortcut,
            // An input's selection and a read-only one are never live at the same time.
            // 输入的选区与只读选区从不同时存在。
            caret: self.editing.map(|(id, sel)| (id, sel.caret)),
            caret_in_text,
            selection: self.selection.or(self.editing),
            preedit: self.preedit.clone(),
            dt,
            now: self.frame_now,
            hovered_path: self.hovered_path.clone(),
            pressed_path: self.pressed_path.clone(),
            drag_owner: if self.pressed.is_some() { self.drag_owner() } else { None },
            drag_started: self.drag.is_dragging(),
        };
        // One-frame facts: the frame that reads them also consumes them, so nothing else
        // may clear them — events arrive in bursts and would erase a click no frame has seen.
        // 单帧事实：读到它们的那一帧同时消费它们，别处不得清除——
        // 事件成批到达，会抹掉还没有任何一帧读到过的点击。
        self.clicked = None;
        self.activated = None;
        self.dismissed = None;
        self.shortcut = None;
        self.dropped = None;
        self.drop_target = None;
        self.drag_step = None;
        self.pointer = pointer;

        // 0. Advance animations before the view runs, so this frame reads settled values.
        // 0. 在 view 之前推进动画，使本帧读到的是推进后的值。
        self.advance_animations();

        // 1. Declaration, built under the one context that owns the engine's store.
        // 1. 声明，在拥有引擎存储的唯一上下文下构建。
        let (root_element, decl, scroll_requests, bring_requests, time_driven, pointer_read) = {
            // Collect everything the context needs before it borrows the store, or the
            // two borrows of `self` would overlap.
            // 在上下文借用存储之前先取齐它需要的一切，否则两处 `self` 借用会重叠。
            let drag_owner = if info.pressed.is_some() { self.drag_owner() } else { None };
            let local = self.pointer_local(info.pressed, info.pointer);
            let inert = self.inert_ids();
            // Anything the cache cannot observe dropped its entries; start the frame clean.
            // 缓存观察不到的变化已让它作废；本帧从干净状态开始。
            if self.decls_stale {
                self.decl_cache.clear();
                self.decls_stale = false;
            }
            let mut cx = ui_core::cx::Cx::new(
                &mut self.anim_store,
                info.frame,
                info.width,
                info.height,
                info.now,
                info.dt,
                self.scale,
                info.pointer,
            );
            cx.attach_measure(Rc::clone(&self.measure));
            cx.attach_cache(&mut self.decl_cache);
            // Last frame's layout, for a build that measures other nodes: the retained tree
            // is only read here, and the apply that writes it happens after this block.
            // 上一帧的布局，供需要量别的节点的构建读取：此处只读保留树，
            // 写它的 apply 在这个块之后才发生。
            cx.attach_tree(&self.tree);
            cx.set_modifiers(self.modifiers);
            // Scroll geometry for the view: content extent and offset per engine-owned
            // scroller, from the previous frame's layout and this frame's stored offsets.
            // A scroller that never saw a wheel still reports itself, offset 0.
            // 供 view 读取的滚动几何：每个引擎自有滚动容器的内容尺寸与偏移，
            // 来自上一帧的布局与本帧存储的偏移。从未滚过的容器也会上报自身，偏移为 0。
            {
                let mut scrolls: Vec<ui_core::cx::ScrollGeom> = Vec::new();
                for nid in self.tree.walk() {
                    if let Some(node) = self.tree.get(nid)
                        && node.sense.contains(ui_core::Sense::SCROLL_OWNED) {
                            let offset = self
                                .scroll_offsets
                                .get(&node.id)
                                .copied()
                                .unwrap_or_default();
                            scrolls.push(ui_core::cx::ScrollGeom {
                                id: node.id,
                                extent_w: node.scroll_extent.w,
                                extent_h: node.scroll_extent.h,
                                viewport_w: node.rect.size.w,
                                viewport_h: node.rect.size.h,
                                offset_x: offset.x,
                                offset_y: offset.y,
                                active: self.scrolled_since.contains(&node.id),
                            });
                        }
                }
                self.scrolled_since.clear();
                cx.set_scrolls(scrolls);
            }
            // Read the frame's own routing; a context has no routing until this call.
            // 读取本帧自己的路由；在本次调用之前上下文里没有路由。
            cx.route(ui_core::cx::Routing {
                hovered: info.hovered,
                pressed: info.pressed,
                clicked_path: info.clicked_path.clone(),
                dropped_path: info.dropped_path.clone(),
                drop_target: info.drop_target,
                focused: info.focused,
                focus_visible: info.focus_visible,
                activated_path: info.activated_path.clone(),
                dismissed: info.dismissed,
                shortcut: info.shortcut,
                caret: info.caret,
                caret_in_text: info.caret_in_text,
                selection: info.selection,
                preedit: info.preedit.clone(),
                hovered_path: info.hovered_path().to_vec(),
                pressed_path: info.pressed_path_field().to_vec(),
                drag_owner,
                drag_started: info.drag_started,
                drag_step: info.drag_step,
                local,
                disabled: inert.clone(),
            });
            // Facts the app reads outside every build gate the cache as a whole: they may
            // change state that later builds read without recording it.
            // 在所有构建之外读到的事实整体决定缓存能否留下：它们可能改变后续构建不记录
            // 就读取的状态。
            if !cx.settle_outside() {
                cx.invalidate_decls();
            }
            let (root, decl, time_driven, pointer_read) = timed!("decl", {
                // Two different costs: what the app builds, and what the engine makes of it.
                // 两种成本：app 构造了什么，以及引擎把它变成什么。
                let root = timed!("view", self.app.view(&mut cx));
                // Asked here, before paint: the menu and the content share this frame's look.
                // 在此索取、在绘制之前：菜单与内容共享本帧的外观。
                if let Some(style) = self.app.menu_style() {
                    self.menu_style = style;
                }
                let decl = timed!("root_decl", root.decl(&mut cx));
                (root, decl, cx.take_time_driven(), cx.take_pointer_read())
            });
            (
                root,
                decl,
                cx.take_scroll_requests(),
                cx.take_bring_requests(),
                time_driven,
                pointer_read,
            )
        };
        // A control that read the raw pointer can change with any move of it: the loop must
        // not absorb those moves without building.
        // 读过原始指针的控件会随指针的任何移动而变：循环不能把这些移动吸收掉而不构建。
        self.pointer_read = pointer_read;
        self.time_driven = time_driven;
        // The app may move a scroller itself (a drag, a page button); its request becomes
        // the stored offset before the declaration is applied.
        // 应用可能自己移动滚动容器（拖拽、翻页按钮）；请求在应用声明之前成为存储偏移。
        for req in scroll_requests {
            // An app that moves a scroller takes it back from a coast, exactly as a wheel does.
            // 应用移动滚动容器时，与滚轮一样把它从滑行中收回。
            self.end_motion(req.id);
            if req.animate {
                self.start_settle(req.id, req.x, req.y);
            } else {
                self.scroll_offsets
                    .insert(req.id, ui_core::cx::ScrollOffset { x: req.x, y: req.y });
            }
        }

        // 2. Apply: diff against the retained tree.
        // 2. 应用：与保留树做差分。
        let _stats = timed!("apply", self.tree.apply(&decl));

        // 2b. Re-apply engine-owned scroll offsets: the app's declaration may not reset the
        // wheel position of a `SCROLL_OWNED` container.
        // 2b. 重新写回引擎自有的滚动偏移：应用的声明不得重置 `SCROLL_OWNED` 容器的滚轮位置。
        if !self.scroll_offsets.is_empty() {
            // Only a scroller the engine is actively stretching may show an offset past its
            // end; every other one is clamped by layout, as an app-declared offset is.
            // 只有引擎正在拉伸的容器才允许显示越过端点的偏移；其余由布局钳位，与应用给出的偏移相同。
            let elastic: FastSet<Id> = self
                .pan
                .iter()
                .map(|p| p.id)
                .chain(self.scroll_motion.keys().copied())
                .collect();
            for (id, offset) in self.scroll_offsets.iter() {
                if let Some(nid) = self.tree.find_by_id(*id)
                    && let Some(params) = self.tree.get_mut(nid).and_then(|n| n.data.params_mut()) {
                        params.scroll_x = offset.x;
                        params.scroll_y = offset.y;
                        params.scroll_elastic = elastic.contains(id);
                    }
            }
        }
        // No global fallback: `compute_damage` already damages new and retired nodes by
        // their own ink. A full-screen safety net would hide exactly the bugs it covers.
        // 不做全局兜底：`compute_damage` 已按各自墨迹处理新增与消失的节点。
        // 全屏兜底只会掩盖它本该暴露的缺陷。

        // 2c. Size transitions: resolve declared fixed sizes into this frame's animated
        // values before layout, so siblings see the travelling size and reflow with it.
        // 2c. 尺寸过渡：布局前把声明的固定尺寸解析成本帧的动画值，
        // 兄弟因此看到行进中的尺寸并随之重排。
        self.resolve_size_transitions();

        // 2d. Presence: an entering node is painted from its declared start values, which
        // layout never sees; presence reaches 1 and the node matches its declaration again.
        // 2d. 入场：节点按声明的起始值绘制，布局看不到这些值；presence 到 1 后节点与声明一致。
        self.resolve_presence();

        // 3. Layout.
        // 3. 布局。
        let root = self.tree.root().expect("apply always yields a root");
        let constraints = Constraints::loose(Size::new(w as f32, h as f32));
        timed!("layout", self.engine.solve(&mut self.tree, root, constraints));
        // A modal owns the keyboard, so focus must be inside it once it is laid out.
        // 模态拥有键盘，因此它一摆好，焦点就必须在它里面。
        let settled = self.settle_focus();
        if settled {
            info.focused = self.focused;
            info.focus_visible = self.focus_visible;
        }
        // 3a. Keep the nodes the build asked for visible. The offset is stored now and
        // reaches the tree on the next frame's scroll pass, so the frame repaints.
        // 3a. 保持构建要求可见的节点。偏移此刻存下，下一帧的滚动趟才写进树，
        // 因此这一帧要重绘。
        let mut brought = false;
        for id in bring_requests {
            brought |= self.bring_into_view(id);
        }
        // Focus moving to a node keeps it visible, as every WinUI scroller does by default.
        // 焦点移到某个节点时让它保持可见，与 WinUI 各滚动容器的默认行为一致。
        if self.focused != self.focus_shown {
            self.focus_shown = self.focused;
            if let Some(id) = self.focused {
                brought |= self.bring_into_view(id);
            }
        }
        if brought {
            self.decls_stale = true;
            self.damage.add(Rect::new(0.0, 0.0, w as f32, h as f32));
        }

        // 3b. Semantic changes from live controls, now that geometry is settled.
        // 3b. 活控件的语义变化；此时几何已经确定。
        let mut changes: Vec<(Id, ui_core::change::Change)> = Vec::new();
        let inert = self.inert_ids();
        {
            let drag_owner = if info.pressed.is_some() { self.drag_owner() } else { None };
            let local = self.pointer_local(info.pressed, info.pointer);
            let mut cx = ui_core::cx::Cx::new(
                &mut self.anim_store,
                info.frame,
                info.width,
                info.height,
                info.now,
                info.dt,
                self.scale,
                info.pointer,
            );
            cx.attach_measure(Rc::clone(&self.measure));
            cx.route(ui_core::cx::Routing {
                hovered: info.hovered,
                pressed: info.pressed,
                clicked_path: info.clicked_path.clone(),
                dropped_path: info.dropped_path.clone(),
                drop_target: info.drop_target,
                focused: info.focused,
                focus_visible: info.focus_visible,
                activated_path: info.activated_path.clone(),
                dismissed: info.dismissed,
                shortcut: info.shortcut,
                caret: info.caret,
                caret_in_text: info.caret_in_text,
                selection: info.selection,
                preedit: info.preedit.clone(),
                hovered_path: info.hovered_path().to_vec(),
                pressed_path: info.pressed_path_field().to_vec(),
                drag_owner,
                drag_started: info.drag_started,
                drag_step: info.drag_step,
                local,
                disabled: inert.clone(),
            });
            cx.set_modifiers(self.modifiers);
            let was_muted = cx.mute();
            timed!("changes", collect_changes(
                root_element.as_ref(),
                &decl,
                &self.tree,
                &cx,
                &mut changes,
            ));
            cx.unmute(was_muted);
            // A control reports its own activation; a bare node has nobody but the engine.
            // 控件自己上报激活；裸节点除引擎外无人可报。
            if let Some(id) = info.activated {
                let spoke = changes
                    .iter()
                    .any(|(cid, _)| info.activated_path.contains(cid));
                if !spoke {
                    changes.push((id, ui_core::change::Change::Activated));
                }
            }
        }
        let mut changed_any = false;
        for (id, change) in changes {
            // A scroll request names no scroller: the nearest one that owns its axis takes it.
            // 滚动请求不指名容器：最近的、确实滚这条轴的容器接住它。
            if let ui_core::change::Change::ScrollBy { dx, dy, owner } = change {
                let moved = match owner {
                    Some(owner) => self.scroll_owner(owner, dx as f32, dy as f32),
                    None => self.scroll_owner_by(id, dx as f32, dy as f32),
                };
                // The requesting control's own state (a chevron's enablement) follows the
                // new offset, so its declaration must be rebuilt.
                // 请求方自身的状态（箭头的可用性）跟随新偏移，因此必须重建它的声明。
                if moved {
                    self.decls_stale = true;
                }
                changed_any |= moved;
                continue;
            }
            // A focus request names its target, and only a node the frame can focus may take
            // the keyboard; the app is never told.
            // 焦点请求指名目标，且只有本帧可聚焦的节点能拿走键盘；应用不会收到它。
            if let ui_core::change::Change::Focus(target) = change {
                changed_any |= self.focus_node(target);
                continue;
            }
            changed_any |= self.app_changed(id, change);
        }
        if changed_any {
            self.damage.add(Rect::new(0.0, 0.0, w as f32, h as f32));
        }
        // These changes land after `view()` already ran, so this frame still paints the
        // state before them: a click that closes something would stay on screen until an
        // unrelated event. Ask for the frame that makes them visible.
        // 这些变更发生在 `view()` 跑完之后，因此本帧画的仍是变更前的状态：
        // 一次关闭的点击会停在屏幕上，直到一个无关事件到来。请求那一帧让它显形。
        if changed_any {
            self.dispatched = true;
        }

        // 4. Paint into the draw list.
        // 4. 绘制进绘制列表。
        self.list.clear();
        self.image_slots.clear();
        self.list.canvas = Rect::new(0.0, 0.0, w as f32, h as f32);
        timed!("paint", self.paint_tree(root));
        // The menu is transient engine-owned UI: it paints above the tree, never inside it.
        // 菜单是引擎自有的瞬时界面：画在树之上，从不进入树里。
        self.paint_menu();

        // 5. Hit test with this frame's rects.
        // 5. 用本帧矩形做命中测试。
        timed!("hit", self.hit.rebuild(&self.tree, |nid| {
            self.tree
                .get(nid)
                .map(|n| Self::hit_behavior_of(n.kind, n.sense, n.disabled))
                .unwrap_or(HitBehavior::Ignore)
        }));
        let hit_id = pointer
            .and_then(|p| self.hit.topmost_consumer(p))
            .and_then(|nid| self.tree.get(nid).map(|n| n.id));

        // Any change of the hovered node repaints both old and new nodes. Compare like with
        // like: `hovered` holds the owner, so comparing it against the raw hit would repaint
        // every frame whenever the pointer rests on a node that declares no hover.
        // 悬停节点变化时重绘旧节点与新节点。同类相比：`hovered` 存的是所有者，
        // 拿它与原始命中相比会让指针停在不声明 hover 的节点上时每帧重绘。
        let hovered = hit_id.and_then(|nid| self.hover_owner(nid));
        if self.hovered != hovered {
            self.damage.add(Rect::new(0.0, 0.0, w as f32, h as f32));
        }
        self.hovered = hovered;
        self.refresh_hovered_path();
        let cursor = self.resolve_cursor();
        // The caller hands this same value to the target; remembering it is what tells a
        // later move whether its shape is news.
        // 调用方把这个值原样交给目标；记住它，后续移动才知道自己的形状是不是新消息。
        self.cursor_sent = cursor;

        // 6. Resolve text once, before damage: a changed label must dirty its node even
        // when the node's geometry did not move.
        // 6. 在脏区之前解析文本：文案变化即使几何没动，也必须让其所属节点变脏。
        let text_scale = self.text_scale();
        timed!("text", {
            let mut text = self.text.borrow_mut();
            text.resolve_into(&self.list, text_scale, &mut self.resolved);
        });

        // 7. Damage: fingerprint the resolved primitives per owning node.
        // 7. 脏区：按所属节点为已解析图元取指纹。
        timed!("damage", self.compute_damage());

        let damage = std::mem::take(&mut self.damage).finish();

        // Springs are integrated, so the scheduler steps them: one left to a widget that
        // stopped building it would never land, and would ask for frames for ever.
        // 弹簧是积分出来的，因此由调度器推进：控件不再构建它时，没人推进的那条永远落不下来，
        // 会一直要求新帧。
        self.anim_store.advance(self.frame_now);
        self.frame += 1;
        FrameOutcome {
            damage,
            nodes: self.tree.len(),
            hit: hit_id,
            // A live splat is an animation the app cannot see in its own store: without
            // this, a held press would stop presenting frames and the ink would freeze.
            // 活的墨迹是 app 自己的存储里看不到的动画：不把这一项加进来，
            // 按住不动时就不再提交帧，墨迹会僵在半路。
            // A coasting or bouncing scroller is the same kind of engine-owned motion.
            // 滑行或回弹中的滚动容器是同一种引擎自有的运动。
            animating: self.anim_store.is_animating(self.clock.now())
                || !self.splats.is_empty()
                || !self.scroll_motion.is_empty()
                // A menu still travelling in is engine-owned motion like the ink above.
                // 仍在走位的菜单与上面的墨迹一样，是引擎自有的运动。
                || self
                    .menu
                    .as_ref()
                    .is_some_and(|m| m.entrance(self.clock.now()).0 < 1.0)
                // A control reading the clock asked for every frame; it never settles.
                // 读取时钟的控件要求每一帧；它永不落定。
                || time_driven,
            cursor,
        }
    }

    /// Deliver one drag transition to the app as a semantic change.
    /// 把一次拖拽转变作为语义变化交给 app。
    ///
    /// Gesture mechanics stay in the engine; the app only learns "how far, and onto what".
    /// 手势机制留在引擎；app 只知道「移动了多远、落在什么上面」。
    /// The pointer translated into the pressed node's own space.
    /// 把指针换算到按下节点自身的空间。
    ///
    /// Zero when no press is live: a control decides for itself whether that matters.
    /// 无按下时为 0：控件的判断不依赖它。
    fn pointer_local(&self, pressed: Option<Id>, pointer: Option<ui_core::geom::Point>) -> Option<ui_core::geom::Point> {
        // The gesture belongs to the node that declares the drag, not to whatever is on top:
        // the topmost node is usually the thumb, which moves with the finger it measures.
        // 手势属于声明拖拽的节点，而不是最上层那个：最上层通常是跟着手指走的滑块，
        // 拿它当原点会让原点追着自己跑。
        let id = self.drag_owner().or(pressed)?;
        let p = pointer?;
        let nid = self.tree.find_by_id(id)?;
        let rect = self.tree.get(nid)?.visual_rect();
        Some(ui_core::geom::Point::new(p.x - rect.origin.x, p.y - rect.origin.y))
    }

    /// Splat ink for a press that just landed on `at`.
    /// 为刚落在 `at` 的那次按下泼出墨迹。
    ///
    /// The nearest ancestor-or-self that declared ink owns the press: the hit node is often
    /// a label, while the control that draws is its container.
    /// 最近一个声明了墨迹的祖先（含自身）拥有这次按下：命中的常是标签，作画的是它的容器。
    fn begin_splat(&mut self, at: ui_core::geom::Point) {
        let Some(hit) = self.pressed else { return };
        let mut cur = self.tree.find_by_id(hit);
        while let Some(nid) = cur {
            let Some(node) = self.tree.get(nid) else { return };
            if let Some(ink) = node.data.params().and_then(|p| p.press_ink) {
                let splat = Splat {
                    node: node.id,
                    origin: at,
                    ink,
                    started: self.clock.live(),
                    released: None,
                };
                self.splats.push(splat);
                return;
            }
            cur = node.parent;
        }
    }

    /// End the live splats; they keep fading, but only the fade's clock matters now.
    /// 结束进行中的墨迹：它们继续淡出，此后只有淡出的时钟有意义。
    fn end_splat(&mut self) {
        let now = self.clock.now();
        for splat in &mut self.splats {
            splat.released.get_or_insert(now);
        }
    }

    fn report_drag(&mut self, event: ui_core::DragEvent) -> bool {
        use ui_core::change::Change;
        use ui_core::DragEvent;
        let (id, change) = match event {
            // A drag start carries no value yet: the first `Moved` says where the pointer
            // is inside the control, and that is what a control maps to a value.
            // 拖拽开始尚无值：第一个 `Moved` 才给出指针在控件内的位置，控件据此映射成值。
            DragEvent::Started { on, .. } => {
                // A new gesture starts with no movement banked: the previous drag's slice
                // must not be added to this one if both fall inside a single frame.
                // 新手势不带任何已记下的位移：两次拖拽若落在同一帧里，
                // 上一段不得加到这一段上。
                self.drag_step = None;
                (on, Change::DragStarted)
            }
            DragEvent::Moved { on, delta, step, .. } => {
                // Several moves can land between frames, and a control adds `drag_step` to
                // what it has; the frame must see the whole slice, not the last event's.
                // 一帧之内可能落进多次移动，控件把它加到自己身上；帧必须看到整段而非最后一段。
                self.drag_step = Some(match self.drag_step {
                    Some(prev) => ui_core::geom::Point::new(prev.x + step.x, prev.y + step.y),
                    None => step,
                });
                (
                    on,
                    Change::Moved {
                        dx: delta.x as f64,
                        dy: delta.y as f64,
                    },
                )
            }
            DragEvent::Dropped { on, target } => {
                self.dropped = Some(on);
                self.drop_target = target;
                (on, Change::Dropped(target))
            }
            DragEvent::Cancelled { on } => (on, Change::Cancelled),
        };
        self.app_changed(id, change)
    }

    /// Forward a change to the app; any app state may have moved, so the cache is dropped.
    /// 把变化转给 app；任何应用状态都可能已变，因此丢弃缓存。
    fn app_changed(&mut self, id: Id, change: ui_core::change::Change) -> bool {
        self.decls_stale = true;
        self.app.changed(id, change)
    }

    /// Nearest declared shape along the hovered path wins, so a child's `Arrow` stops a
    /// parent's `Grab`. Definite: no pointer, or nothing declared, means `Arrow`.
    /// 悬停路径上最近的声明生效，因此子节点的 `Arrow` 能阻断父的 `Grab`。
    /// 永远确定：无指针或无人声明都是 `Arrow`。
    fn resolve_cursor(&self) -> ui_core::CursorShape {
        self.pointer
            .map_or(ui_core::CursorShape::Arrow, |p| self.cursor_shape_at(p))
    }

    /// The shape the pointer shows at `p`, resolved against the last laid-out frame.
    /// `p` 处的指针形状，按上一帧的布局解析。
    ///
    /// Takes the point rather than reading the live one: a move has to know what shape it
    /// is moving to before it is stored, and the answer is a pixel-independent effect.
    /// 直接取点而不读当前指针：移动要先知道它将移向什么形状，而这个答案与像素无关。
    fn cursor_shape_at(&self, p: ui_core::geom::Point) -> ui_core::CursorShape {
        // An open menu is painted above the tree and owns the pointer over itself: a row
        // that can be chosen is a control, the rest of the surface is not.
        // 打开的菜单画在树之上，指针落在它上面时归它管：可选的行是控件，其余表面不是。
        if let Some(menu) = self.menu.as_ref()
            && menu.rect.contains(p) {
                return match menu.enabled_row_at(p, self.frame_now) {
                    Some(_) => ui_core::CursorShape::PointingHand,
                    None => ui_core::CursorShape::Arrow,
                };
            }
        let mut cur = self.hit.topmost_consumer(p);
        while let Some(nid) = cur {
            let Some(node) = self.tree.get(nid) else {
                break;
            };
            if let Some(shape) = node.cursor {
                return shape;
            }
            // Text the engine made selectable shows the I-beam without the app declaring it.
            // 引擎赋予可选性的文本自动显示文字光标，无需应用声明。
            if Self::is_selectable_text(node) {
                return ui_core::CursorShape::Text;
            }
            cur = node.parent;
        }
        ui_core::CursorShape::Arrow
    }

    /// No damage special case: changed values change primitives, which are fingerprinted.
    /// 脏区无需特殊处理：值变化会改变图元，而图元已被逐步取指纹。
    /// Adopt this frame's timestamp. The clock was already advanced by the frame entry
    /// point; reading it here keeps the whole frame on one value.
    /// 采用本帧时间戳。时钟已在帧入口推进；这里只读取，使整帧共用一个值。
    fn advance_animations(&mut self) {
        self.frame_now = self.clock.now();
        // Motion is tallied per frame, so the report can tell "moving" from "abandoned".
        // 位移按帧累计，报告因此能区分"在动"与"被丢下"。
        self.anim_store.begin_frame();
        // Scroll physics runs before the view, so this frame reads the moved offset.
        // 滚动物理先于 view 运行，本帧因此读到已移动的偏移。
        let (now, dt) = (self.frame_now, self.frame_step);
        self.sample_pan_velocity(dt);
        self.advance_scroll_motion(now, dt);
    }


    /// The nearest node that accepts text, walking up from `id`.
    /// 从 `id` 向上找最近的接受文本的节点。
    fn text_input_owner(&self, id: Id) -> Option<Id> {
        let mut cur = self.tree.find_by_id(id);
        while let Some(nid) = cur {
            let node = self.tree.get(nid)?;
            if node.data.params().is_some_and(|p| p.text_input.is_some()) {
                return Some(node.id);
            }
            cur = node.parent;
        }
        None
    }

    /// The buffer a text input currently holds, as last declared by the app.
    /// 文本输入当前持有的缓冲，即应用上次声明的值。
    fn text_input_value(&self, id: Id) -> Option<String> {
        let nid = self.tree.find_by_id(id)?;
        self.tree.get(nid)?.data.params()?.text_input.clone()
    }

    /// Whether `id`'s input declared itself multiline; an absent input is not.
    /// `id` 的输入是否声明为多行；不存在即算否。
    fn input_is_multiline(&self, id: Id) -> bool {
        self.tree
            .find_by_id(id)
            .and_then(|nid| self.tree.get(nid))
            .and_then(|n| n.data.params())
            .is_some_and(|p| p.text_input.is_some() && p.text_input_multiline)
    }

    /// Write an edit back into the tree so the next event in the same batch sees it.
    /// 把一次编辑写回树，使同一批里的下一个事件能读到它。
    ///
    /// The app is still the owner: its next declaration overwrites this optimistic value.
    /// 应用仍是所有者：它下一次声明会覆盖这个乐观值。
    fn set_input_value(&mut self, owner: Id, value: &str) {
        if let Some(nid) = self.tree.find_by_id(owner)
            && let Some(params) = self.tree.get_mut(nid).and_then(|n| n.data.params_mut()) {
                params.text_input = Some(value.to_string());
            }
    }

    /// The selectable text node `id` is, if it is one.
    /// 若 `id` 是可选中文本节点，返回它。
    fn selectable_text(&self, id: Id) -> Option<Id> {
        let node = self.tree.find_by_id(id).and_then(|nid| self.tree.get(nid))?;
        Self::is_selectable_text(node).then_some(node.id)
    }

    /// Selectable text is the engine's own affordance, so the pointer shape follows from it.
    /// 可选中的文本是引擎自己给的，指针形状也随它而来。
    fn is_selectable_text(node: &ui_core::tree::Node) -> bool {
        matches!(node.data, ui_core::NodeData::Text { .. })
            && node.sense.contains(ui_core::Sense::SELECT)
    }

    /// The text primitive a node paints, sized exactly as the paint path sizes it.
    /// 节点绘制用的文本图元，尺寸与绘制端完全一致。
    fn text_prim_of(&self, id: Id) -> Option<ui_core::draw::TextPrim> {
        let node = self.tree.find_by_id(id).and_then(|nid| self.tree.get(nid))?;
        let ui_core::NodeData::Text { block, ink, .. } = &node.data else {
            return None;
        };
        let rect = node.visual_rect();
        Some(ui_core::draw::TextPrim {
            block: block.clone(),
            origin: text_origin(node),
            max_width: node.wrap_width,
            layout: node.inline.clone(),
            height: rect.size.h,
            ink: *ink,
            caret: None,
            selection: None,
            composing: None,
            zoom: None,
        })
    }

    /// The text node that draws an input's buffer: the one whose flattened text is the
    /// buffer, with the preedit spliced in at the caret when a composition is live.
    /// 绘制输入缓冲的文本节点：其拼接文本等于缓冲，组合进行中时在插入符处插入预编辑串。
    fn input_text_node(
        &self,
        owner: Id,
        value: &str,
        preedit: Option<&ui_core::Preedit>,
        caret: usize,
    ) -> Option<Id> {
        let composed = composed_input(value, preedit, caret);
        let mut stack = vec![self.tree.find_by_id(owner)?];
        // Document order: the buffer is declared before the clear glyph, and an empty
        // buffer matches both, so a reversed walk would answer with the glyph.
        // 按文档顺序：缓冲声明在清除字形之前，空缓冲与两者都相等，倒序会把字形当答案。
        while let Some(nid) = stack.pop() {
            let Some(node) = self.tree.get(nid) else {
                continue;
            };
            if let ui_core::NodeData::Text { block, .. } = &node.data {
                let (flat, _) = block.flatten();
                if flat == value || flat == composed {
                    return Some(node.id);
                }
            }
            let kids = self.tree.children_of(Some(nid));
            stack.extend(kids.into_iter().rev());
        }
        None
    }

    /// What the compositor needs to place the candidate window, from this frame's layout.
    /// 合成器摆放候选窗所需的状态，取自本帧布局。
    pub fn ime_state(&mut self) -> crate::present::ImeState {
        let Some((owner, sel)) = self.editing else {
            return crate::present::ImeState::default();
        };
        let Some(value) = self.text_input_value(owner) else {
            return crate::present::ImeState::default();
        };
        let preedit = self
            .preedit
            .clone()
            .filter(|(id, _)| *id == owner)
            .map(|(_, p)| p);
        let at = sel.caret + preedit.as_ref().map_or(0, |p| p.cursor);
        let cursor = self
            .input_text_node(owner, &value, preedit.as_ref(), sel.caret)
            .and_then(|text| self.text_prim_of(text))
            .and_then(|prim| self.text.borrow_mut().caret_rect(&prim, at, self.scale));
        crate::present::ImeState {
            // No rect from this frame means no enable: a stale rectangle is the bug §6 names.
            // 本帧没有矩形就不启用：陈旧矩形正是 §6 记录的缺陷。
            enabled: cursor.is_some(),
            cursor,
            surrounding: Some((value, sel.caret, sel.anchor)),
        }
    }

    /// The caret's x inside the text node drawing the buffer, in that node's layout space.
    /// 插入符在绘制缓冲的文本节点内的 x，位于该节点的布局坐标系。
    ///
    /// Measured from a zero origin on purpose: a node that scrolls by this value must not have
    /// its own offset folded in, or each frame would outbid the last.
    /// 刻意从零原点测量：按这个值滚动的节点不能把自己的偏移折进来，否则每帧都会加码。
    fn caret_in_text_fact(&mut self) -> Option<(Id, f32)> {
        let (owner, sel) = self.editing?;
        let value = self.text_input_value(owner)?;
        let preedit = self
            .preedit
            .clone()
            .filter(|(id, _)| *id == owner)
            .map(|(_, p)| p);
        let at = sel.caret + preedit.as_ref().map_or(0, |p| p.cursor);
        let mut prim;
        let text = match self.input_text_node(owner, &value, preedit.as_ref(), sel.caret) {
            Some(text) => {
                self.input_text_cache = Some((owner, text));
                prim = self.text_prim_of(text)?;
                text
            }
            None => {
                // A keystroke has changed the buffer while the tree still holds the old text:
                // measure the new buffer in the style its node used last frame.
                // 按键已改缓冲而树里仍是旧文字：用上一帧绘制缓冲那个节点的样式量新缓冲。
                let (_, text) = *self.input_text_cache.as_ref().filter(|(o, _)| *o == owner)?;
                prim = self.text_prim_of(text)?;
                let style = prim.block.runs.first().map(|r| r.style).unwrap_or_default();
                let composed = composed_input(&value, preedit.as_ref(), sel.caret);
                prim.block.runs = vec![ui_core::text::TextRun::new(composed, style)];
                prim.block.atoms.clear();
                prim.layout = None;
                text
            }
        };
        prim.origin = ui_core::geom::Point::new(0.0, 0.0);
        let caret = self.text.borrow_mut().caret_rect(&prim, at, self.scale)?;
        Some((text, caret.origin.x))
    }

    /// The byte offset in `id`'s text nearest to a surface point.
    /// `id` 的文本中距表面点最近的字节偏移。
    fn text_index_at(&mut self, id: Id, p: ui_core::geom::Point) -> Option<usize> {
        let prim = self.text_prim_of(id)?;
        Some(self.text.borrow_mut().index_at(&prim, p, self.scale))
    }

    /// Flattened text of a node, for word selection.
    /// 节点的拼接文本，供选词使用。
    fn text_value(&self, id: Id) -> Option<String> {
        let node = self.tree.find_by_id(id).and_then(|nid| self.tree.get(nid))?;
        let ui_core::NodeData::Text { block, .. } = &node.data else {
            return None;
        };
        Some(block.flatten().0)
    }

    /// The text a node holds, whether it is an editable input or a read-only label.
    /// 节点持有的文本，无论它是可编辑输入还是只读标签。
    fn text_of(&self, id: Id) -> Option<String> {
        self.text_input_value(id).or_else(|| self.text_value(id))
    }

    /// Put `sel` back on whichever of the two selections owns `id`.
    /// 把 `sel` 放回持有 `id` 的那一个选区。
    fn set_live_selection(&mut self, id: Id, sel: ui_core::TextSelection) {
        if self.editing.is_some_and(|(owner, _)| owner == id) {
            self.editing = Some((id, sel));
        } else if self.selection.is_some_and(|(node, _)| node == id) {
            self.selection = Some((id, sel));
        }
    }

    /// Start (or extend into) a selection on a read-only text node.
    /// 在只读文本节点上开始（或换成）一次选区。
    ///
    /// Returns true when the selection changed, which is what asks for a repaint.
    /// 选区变化时返回真，这就是重绘请求。
    fn begin_selection(&mut self, node: Id, at: ui_core::geom::Point) -> bool {
        let Some(index) = self.text_index_at(node, at) else {
            return false;
        };
        let now = self.clock.now();
        let double = self.last_press.is_some_and(|(t, p, n)| {
            n == node
                && now - t <= 0.4
                && (p.x - at.x).abs() <= 4.0
                && (p.y - at.y).abs() <= 4.0
        });
        let selection = if double {
            let value = self.text_value(node).unwrap_or_default();
            let word = ui_core::text_input::word_at(&value, index);
            ui_core::TextSelection::new(word.start, word.end)
        } else {
            ui_core::TextSelection::collapsed(index)
        };
        self.last_press = Some((now, at, node));
        let changed = self.selection != Some((node, selection));
        self.selection = Some((node, selection));
        self.select_drag = Some(node);
        changed
    }

    /// Extend the live selection to the pointer, if a selection drag is running.
    /// 若选区拖拽正在进行，把选区扩展到指针处。
    fn extend_selection(&mut self, p: ui_core::geom::Point) -> bool {
        let Some(node) = self.select_drag else {
            return false;
        };
        let Some(index) = self.text_index_at(node, p) else {
            return false;
        };
        let Some((_, selection)) = self.selection.as_mut() else {
            return false;
        };
        if selection.caret == index {
            return false;
        }
        selection.caret = index;
        true
    }

    /// The text node drawing `owner`'s buffer, the one a click must be measured against.
    /// 绘制 `owner` 缓冲的文本节点，点击要相对它来度量。
    ///
    /// Never the header, placeholder or clear glyph: answering from those puts a click
    /// beside the text at their own start.
    /// 绝不用标题、占位符或清除字形作答：用它们会把文字旁的点击放到它们自己的开头。
    fn input_text_at(&self, owner: Id) -> Option<Id> {
        let value = self.text_input_value(owner)?;
        let (caret, preedit) = match self.editing.filter(|(o, _)| *o == owner) {
            Some((_, sel)) => (
                sel.caret,
                self.preedit
                    .as_ref()
                    .filter(|(id, _)| *id == owner)
                    .map(|(_, p)| p),
            ),
            None => (0, None),
        };
        self.input_text_node(owner, &value, preedit, caret)
    }

    /// The byte offset in an input's text nearest to a surface point.
    /// 输入的文本中距表面点最近的字节偏移。
    fn input_index_at(&mut self, owner: Id, p: ui_core::geom::Point) -> Option<usize> {
        let value = self.text_input_value(owner)?;
        match self.input_text_at(owner) {
            Some(text) => self.text_index_at(text, p),
            // An empty buffer draws no text node; its only caret sits at the origin.
            // 空缓冲不绘制文本节点；它唯一的插入符就在原点。
            None if value.is_empty() => Some(0),
            None => None,
        }
    }

    /// Extend the input's selection to the pointer, if an editing drag is running.
    /// 若文本输入拖拽正在进行，把选区扩展到指针处。
    fn extend_editing(&mut self, p: ui_core::geom::Point) -> bool {
        let Some(owner) = self.editing_drag else {
            return false;
        };
        let Some(index) = self.input_index_at(owner, p) else {
            return false;
        };
        let Some((_, selection)) = self.editing.as_mut() else {
            return false;
        };
        if selection.caret == index {
            return false;
        }
        selection.caret = index;
        true
    }

    /// One arrow-key step in the focused input: Shift extends, a plain arrow collapses.
    /// 聚焦输入里的一个方向键步进：Shift 扩展选区，普通方向键把选区收拢。
    ///
    /// With Ctrl the step is a word, the unit every mature editor uses for Ctrl+arrow.
    /// 带 Ctrl 时步进单位是一个词，即成熟编辑器对 Ctrl+方向键的做法。
    fn step_editing(&mut self, delta: isize) -> bool {
        // Ctrl+Shift+arrow is a table shortcut; an unbound one must not fall back to a word step.
        // Ctrl+Shift+方向键属于表内快捷键；解绑后不得回退成按词步进。
        if self.modifiers.ctrl && self.modifiers.shift {
            return false;
        }
        let Some((owner, sel)) = self.editing else {
            return false;
        };
        let value = self.text_input_value(owner).unwrap_or_default();
        let step = |at: usize| {
            if self.modifiers.ctrl {
                ui_core::text_input::step_word(&value, at, delta)
            } else {
                ui_core::text_input::moved(&value, at, delta)
            }
        };
        let next = if self.modifiers.shift {
            ui_core::TextSelection::new(sel.anchor, step(sel.caret))
        } else if !sel.is_collapsed() {
            let range = sel.range();
            ui_core::TextSelection::collapsed(if delta < 0 { range.start } else { range.end })
        } else {
            ui_core::TextSelection::collapsed(step(sel.caret))
        };
        self.editing = Some((owner, next));
        next != sel
    }

    /// Extend the selection one character from its caret, keeping the anchor.
    /// 从插入符起扩展一个字符，锚点不动。
    fn extend_char_editing(&mut self, delta: isize) -> bool {
        self.extend_editing_by(|value, caret| ui_core::text_input::moved(value, caret, delta))
    }

    /// Extend the selection one word from its caret, keeping the anchor.
    /// 从插入符起扩展一个词，锚点不动。
    fn extend_word_editing(&mut self, delta: isize) -> bool {
        self.extend_editing_by(|value, caret| ui_core::text_input::step_word(value, caret, delta))
    }

    /// Move the caret to `step`'s answer while the anchor stays put.
    /// 把插入符移到 `step` 的结果处，锚点保持不动。
    fn extend_editing_by(&mut self, step: impl Fn(&str, usize) -> usize) -> bool {
        let Some((owner, sel)) = self.editing else {
            return false;
        };
        let value = self.text_input_value(owner).unwrap_or_default();
        let next = ui_core::TextSelection::new(sel.anchor, step(&value, sel.caret));
        self.editing = Some((owner, next));
        next != sel
    }

    /// Up/Down inside a text input: the offset nearest to the caret one line away. `None`
    /// when no line lies in that direction, so focus navigation takes over.
    /// 文本输入里的 Up/Down：距插入符一行远处最近的偏移。该方向没有行时返回 `None`，
    /// 交给焦点导航处理。
    fn step_line_editing(&mut self, delta: isize) -> Option<bool> {
        let (owner, sel) = self.editing?;
        let value = self.text_input_value(owner)?;
        let text = self.input_text_node(owner, &value, None, sel.caret)?;
        let prim = self.text_prim_of(text)?;
        let caret = self.text.borrow_mut().caret_rect(&prim, sel.caret, self.scale)?;
        let step = (caret.size.h + prim.block.line_gap).max(1.0);
        let p = ui_core::geom::Point::new(caret.origin.x, caret.origin.y + delta as f32 * step);
        let at = self.text.borrow_mut().index_at(&prim, p, self.scale);
        if at == sel.caret {
            return None;
        }
        let next = if self.modifiers.shift {
            ui_core::TextSelection::new(sel.anchor, at)
        } else {
            ui_core::TextSelection::collapsed(at)
        };
        self.editing = Some((owner, next));
        Some(next != sel)
    }

    /// Home/End in the focused input; Shift keeps the anchor where it was.
    /// 聚焦输入里的 Home/End；Shift 让锚点留在原处。
    fn jump_editing(&mut self, at: usize) -> bool {
        let Some((owner, sel)) = self.editing else {
            return false;
        };
        let next = if self.modifiers.shift {
            ui_core::TextSelection::new(sel.anchor, at)
        } else {
            ui_core::TextSelection::collapsed(at)
        };
        self.editing = Some((owner, next));
        next != sel
    }

    /// Resolve a key press through every layer, most specific first.
    /// 按层解析一次按键，最具体的优先。
    ///
    /// `None` means nothing claimed the key, so the plain key arms still see it.
    /// `None` 表示无人认领该键，普通按键分支仍然会看到它。
    fn fire_shortcut(&mut self, key: ui_core::Key) -> Option<(bool, bool)> {
        let mods = self.modifiers;
        // A control that owns focus outranks the hit chain, which outranks the app.
        // 持有焦点的控件优先于命中链，命中链优先于应用级。
        if let Some((id, shortcut)) = self.shortcut_in_focus(key, mods) {
            self.shortcut = Some((id, shortcut));
            let changed = self.app_changed(id, ui_core::change::Change::Shortcut(shortcut));
            return Some((changed, false));
        }
        if let Some((id, shortcut)) = self.shortcut_in_hit_chain(key, mods) {
            self.shortcut = Some((id, shortcut));
            let changed = self.app_changed(id, ui_core::change::Change::Shortcut(shortcut));
            return Some((changed, false));
        }
        if let Some(shortcut) = self.shortcuts.app_id(key, mods) {
            self.decls_stale = true;
            return Some((self.app.shortcut(shortcut), false));
        }
        self.run_builtin(self.shortcuts.builtin_id(key, mods)?)
    }

    /// The menu a secondary press at `p` opens: the nearest declaring node, plus text rows.
    /// 在 `p` 处右键打开的菜单：最近的声明节点，再加上文本编辑行。
    fn menu_for(&mut self, p: ui_core::geom::Point) -> Option<(Id, Vec<ui_core::MenuItem>)> {
        let hit = self
            .hit
            .topmost_consumer(p)
            .and_then(|nid| self.tree.get(nid).map(|n| n.id));
        let mut owner = None;
        let mut items = Vec::new();
        let mut cur = hit.and_then(|id| self.tree.find_by_id(id));
        while let Some(nid) = cur {
            let node = self.tree.get(nid)?;
            if let Some(menu) = node.data.params().map(|p| &p.menu)
                && !menu.is_empty() {
                    owner = Some(node.id);
                    items = menu.clone();
                    break;
                }
            cur = node.parent;
        }
        // Text always offers its own four rows, appended below whatever the app declared.
        // 文本总会附上自己那四行，排在应用声明的行之后。
        if let Some((text_owner, text_items)) = self.text_menu() {
            owner.get_or_insert(text_owner);
            items.extend(text_items);
        }
        owner.map(|owner| (owner, items)).filter(|(_, i)| !i.is_empty())
    }

    /// Select-all / copy / cut / paste, with the enabled state the engine can see and the
    /// words the app supplied.
    /// 全选 / 复制 / 剪切 / 粘贴，可用状态取引擎能看到的事实，措辞取应用提供的。
    fn text_menu(&self) -> Option<(Id, Vec<ui_core::MenuItem>)> {
        use ui_core::MenuItem;
        let labels = self.text_menu_labels.as_ref()?;
        let row = |id: &'static str, text: &crate::menu::MenuRowText, on: bool| {
            let item = MenuItem::new(Id::str(id), text.label.clone());
            let item = match text.shortcut.clone() {
                Some(shortcut) => item.with_shortcut(shortcut),
                None => item,
            };
            if on {
                item
            } else {
                item.disabled()
            }
        };
        if let Some((owner, sel)) = self.editing {
            let value = self.text_input_value(owner).unwrap_or_default();
            let has = !sel.is_collapsed();
            return Some((
                owner,
                vec![
                    row(MENU_SELECT_ALL, &labels.select_all, !value.is_empty()),
                    row(MENU_COPY, &labels.copy, has),
                    row(MENU_CUT, &labels.cut, has),
                    row(MENU_PASTE, &labels.paste, true),
                ],
            ));
        }
        // A read-only selection can be copied, never cut or pasted into.
        // 只读选区可以复制，不能剪切，也没有可粘贴的目标。
        let (node, sel) = self.selection?;
        let has = !sel.is_collapsed();
        Some((
            node,
            vec![
                row(MENU_SELECT_ALL, &labels.select_all, true),
                row(MENU_COPY, &labels.copy, has),
            ],
        ))
    }

    /// Open a menu at `p` if anything there offers one; a stale menu closes first.
    /// 若 `p` 处有东西提供菜单就在那里打开；先关掉旧的。
    fn open_menu(&mut self, p: ui_core::geom::Point) -> bool {
        self.close_menu();
        let Some((owner, items)) = self.menu_for(p) else {
            return false;
        };
        let style = self.menu_style.clone();
        let surface = ui_core::geom::Size::new(
            self.last_size.0 as f32,
            self.last_size.1 as f32,
        );
        let text = std::rc::Rc::clone(&self.text);
        let menu = crate::menu::OpenMenu::open(
            &style,
            owner,
            items,
            p,
            self.clock.live(),
            surface,
            |block| text.borrow_mut().measure(block, f32::INFINITY).w,
        );
        self.damage.add(menu.rect);
        self.menu = Some(menu);
        true
    }

    /// Close the menu, damaging where it was.
    /// 关闭菜单，并把它所在处标脏。
    fn close_menu(&mut self) -> bool {
        let Some(menu) = self.menu.take() else {
            return false;
        };
        self.damage.add(menu.rect);
        true
    }

    /// Run one row of the open menu, then close it.
    /// 执行打开菜单中的某一行，然后关闭它。
    fn pick_menu_row(&mut self, index: usize) -> bool {
        let Some(menu) = self.menu.take() else {
            return false;
        };
        self.damage.add(menu.rect);
        let Some(item) = menu.items.get(index).cloned() else {
            return true;
        };
        if !item.enabled {
            return true;
        }
        let builtin = if item.id == Id::str(MENU_SELECT_ALL) {
            Some(ui_core::ShortcutId::SELECT_ALL)
        } else if item.id == Id::str(MENU_COPY) {
            Some(ui_core::ShortcutId::COPY)
        } else if item.id == Id::str(MENU_CUT) {
            Some(ui_core::ShortcutId::CUT)
        } else if item.id == Id::str(MENU_PASTE) {
            Some(ui_core::ShortcutId::PASTE)
        } else {
            None
        };
        match builtin {
            Some(id) => {
                self.run_builtin(id);
                true
            }
            None => self.app_changed(menu.owner, ui_core::change::Change::MenuItem(item.id)),
        }
    }

    /// Handle one event while a menu is open. `None` means it falls through.
    /// 菜单打开时处理一条事件。`None` 表示交给常规路径。
    fn menu_event(&mut self, event: &ui_core::Event) -> Option<bool> {
        match event {
            ui_core::Event::PointerMoved { pos } => {
                let hovered = self
                    .menu
                    .as_ref()
                    .and_then(|m| m.row_at(*pos, self.frame_now));
                if let Some(menu) = self.menu.as_mut()
                    && menu.hovered != hovered {
                        menu.hovered = hovered;
                        self.damage.add(menu.rect);
                        return Some(true);
                    }
                Some(false)
            }
            ui_core::Event::PointerPressed {
                pos,
                button: ui_core::PointerButton::Primary,
            } => {
                let row = self
                    .menu
                    .as_ref()
                    .and_then(|m| m.enabled_row_at(*pos, self.frame_now));
                match row {
                    Some(index) => Some(self.pick_menu_row(index)),
                    None => Some(self.close_menu()),
                }
            }
            // A second right-click closes this menu; the press then opens a fresh one.
            // 再按一次右键会关掉这个菜单；这次按下随后会打开新的。
            ui_core::Event::PointerPressed {
                button: ui_core::PointerButton::Secondary,
                ..
            } => {
                self.close_menu();
                None
            }
            ui_core::Event::KeyPressed {
                key: ui_core::Key::Escape,
            } => Some(self.close_menu()),
            // The menu owns the pointer, not the keyboard: typing still reaches its target.
            // 菜单占用的是指针而非键盘：键入仍然到达原本的目标。
            ui_core::Event::PointerReleased { .. } | ui_core::Event::Scroll { .. } => Some(false),
            _ => None,
        }
    }

    /// Draw the open menu over everything else, in the engine's own fallback style.
    /// 用引擎自带的兜底样式把打开的菜单画在一切之上。
    fn paint_menu(&mut self) {
        let Some(menu) = self.menu.clone() else {
            return;
        };
        let Some(nid) = self.tree.find_by_id(menu.owner).or_else(|| self.tree.root()) else {
            return;
        };
        let style = &self.menu_style;
        let corners = crate::menu::OpenMenu::corners(style);
        let (presence, travel) = menu.entrance(self.frame_now);
        let shift = ui_core::geom::Point::new(0.0, travel);
        let fade = |colour: ui_core::geom::Color| ui_core::geom::Color {
            a: colour.a * presence,
            ..colour
        };
        // The shadow is a halo around the rest position, so it stays outside the clip and
        // simply fades in; only the surface and its rows are cut to the box.
        // 阴影是静止位置周围的光晕，因此留在裁剪之外、只做淡入；裁到盒子里的只有表面与行。
        self.list.push_shadow(
            nid,
            ui_core::draw::ShadowPrim {
                rect: menu.rect,
                corners,
                colour: fade(ui_core::geom::Color::from_rgba8(0, 0, 0, 90)),
                blur: style.shadow,
                dy: 3.0,
                ring: 0.0,
            },
        );
        // The surface travels inside the footprint it will keep: that box is the clip, so
        // the part still on its way in never covers what it hangs over.
        // 表面在它将保持的轮廓之内移动：这个盒子就是裁剪，尚在途中的部分不会盖住它所悬于其上的东西。
        self.list.push_clip(menu.rect, corners);
        self.list.push_rect(
            nid,
            ui_core::draw::RectPrim {
                rect: menu.rect.translate(shift),
                radius: corners,
                fill: fade(style.surface),
                gradient: None,
                border: style.border.map(|(colour, width)| (fade(colour), width)),
                border_gradient: None,
                notch: None,
            },
        );
        for (i, item) in menu.items.iter().enumerate() {
            let row = menu.rows[i].translate(shift);
            if menu.hovered == Some(i) && item.enabled {
                self.list.push_rect(
                    nid,
                    ui_core::draw::RectPrim {
                        rect: row,
                        radius: ui_core::geom::Corners::all(style.radius),
                        fill: fade(style.hover),
                        gradient: None,
                        border: None,
                        border_gradient: None,
                        notch: None,
                    },
                );
            }
            self.list.push_text(
                nid,
                ui_core::draw::TextPrim {
                    block: style.block(&item.label),
                    origin: ui_core::geom::Point::new(
                        menu.rect.origin.x + style.pad_x,
                        row.origin.y + (style.row_height - style.font_size * 1.25) * 0.5,
                    ),
                    max_width: f32::INFINITY,
                    layout: None,
                    height: 0.0,
                    ink: fade(if item.enabled { style.ink } else { style.muted }),
                    caret: None,
                    selection: None,
                    composing: None,
                    zoom: None,
                },
            );
            let (Some(shortcut), Some(slot)) = (item.shortcut.as_deref(), menu.shortcuts[i]) else {
                continue;
            };
            let chord_y = row.origin.y + (style.row_height - style.shortcut_size * 1.25) * 0.5;
            self.list.push_text(
                nid,
                ui_core::draw::TextPrim {
                    block: style.shortcut_block(shortcut),
                    origin: ui_core::geom::Point::new(slot.origin.x, chord_y),
                    max_width: f32::INFINITY,
                    layout: None,
                    height: 0.0,
                    ink: fade(if item.enabled {
                        style.shortcut_ink
                    } else {
                        style.muted
                    }),
                    caret: None,
                    selection: None,
                    composing: None,
                    zoom: None,
                },
            );
        }
        self.list.pop_clip();
    }

    /// The nearest focused node that wants raw chords, if any.
    /// 最近的、想要原始组合键的聚焦节点（若有）。
    fn key_capture_owner(&self) -> Option<Id> {
        let mut cur = self.focused.and_then(|id| self.tree.find_by_id(id));
        while let Some(nid) = cur {
            let node = self.tree.get(nid)?;
            if node.sense.contains(ui_core::Sense::CAPTURE_KEYS) {
                return Some(node.id);
            }
            cur = node.parent;
        }
        None
    }

    /// The nearest node on the focus chain that binds this chord.
    /// 焦点链上最近一个绑定了此组合的节点。
    fn shortcut_in_focus(
        &self,
        key: ui_core::Key,
        mods: ui_core::Modifiers,
    ) -> Option<(Id, ui_core::ShortcutId)> {
        let mut cur = self.focused.and_then(|id| self.tree.find_by_id(id));
        while let Some(nid) = cur {
            let node = self.tree.get(nid)?;
            if let Some(found) = bound_on(node, key, mods) {
                return Some((node.id, found));
            }
            cur = node.parent;
        }
        None
    }

    /// The nearest node on the hit chain that binds this chord: hover alone can claim a key.
    /// 命中链上最近一个绑定了此组合的节点：仅悬停也能认领按键。
    fn shortcut_in_hit_chain(
        &self,
        key: ui_core::Key,
        mods: ui_core::Modifiers,
    ) -> Option<(Id, ui_core::ShortcutId)> {
        for id in self.pointer_path.iter().rev() {
            let Some(node) = self.tree.find_by_id(*id).and_then(|n| self.tree.get(n)) else {
                continue;
            };
            if let Some(found) = bound_on(node, key, mods) {
                return Some((node.id, found));
            }
        }
        None
    }

    /// Run the engine's action for a built-in id; `None` when it does not apply right now.
    /// 执行某个内置 id 对应的引擎动作；当下不适用时返回 `None`。
    fn run_builtin(&mut self, id: ui_core::ShortcutId) -> Option<(bool, bool)> {
        use ui_core::ShortcutId as S;
        // Copying also serves a read-only selection, which no input owns.
        // 复制也服务只读选区，那种选区不属于任何输入。
        if matches!(id, S::COPY | S::CUT) {
            return Some((self.copy_selection(id == S::CUT), false));
        }
        // Selecting everything needs no owner to write into, so a read-only label serves too.
        // 全选不需要可写入的所有者，只读标签同样适用。
        if id == S::SELECT_ALL {
            let (target, _) = self.editing.or(self.selection)?;
            let len = self.text_of(target).map_or(0, |v| v.len());
            self.set_live_selection(target, ui_core::TextSelection::new(0, len));
            return Some((true, false));
        }
        let (owner, sel) = self.editing?;
        match id {
            S::PASTE => {
                self.clipboard
                    .push(crate::clipboard::ClipboardCommand::RequestPaste {
                        kind: crate::clipboard::ClipboardKind::Selection,
                    });
                Some((true, false))
            }
            S::DELETE_FORWARD => {
                let value = self.text_input_value(owner)?;
                let range = if sel.is_collapsed() {
                    let next = ui_core::text_input::moved(&value, sel.caret, 1);
                    if next == sel.caret {
                        return Some((false, false));
                    }
                    sel.caret..next
                } else {
                    sel.range()
                };
                let (next, caret) = ui_core::text_input::delete_range(&value, range);
                self.editing = Some((owner, ui_core::TextSelection::collapsed(caret)));
                self.preedit = None;
                self.set_input_value(owner, &next);
                Some((
                    self.app_changed(owner, ui_core::change::Change::Text(next)),
                    true,
                ))
            }
            S::HOME | S::EXTEND_HOME => {
                let value = self.text_input_value(owner).unwrap_or_default();
                Some((self.jump_editing(line_bounds(&value, sel.caret).0), false))
            }
            S::END | S::EXTEND_END => {
                let value = self.text_input_value(owner).unwrap_or_default();
                Some((self.jump_editing(line_bounds(&value, sel.caret).1), false))
            }
            S::DOCUMENT_HOME | S::EXTEND_DOCUMENT_HOME => Some((self.jump_editing(0), false)),
            S::DOCUMENT_END | S::EXTEND_DOCUMENT_END => {
                let len = self.text_input_value(owner).map_or(0, |v| v.len());
                Some((self.jump_editing(len), false))
            }
            S::EXTEND_LEFT => Some((self.extend_char_editing(-1), false)),
            S::EXTEND_RIGHT => Some((self.extend_char_editing(1), false)),
            S::EXTEND_WORD_LEFT => Some((self.extend_word_editing(-1), false)),
            S::EXTEND_WORD_RIGHT => Some((self.extend_word_editing(1), false)),
            S::EXTEND_UP => self.step_line_editing(-1).map(|m| (m, false)),
            S::EXTEND_DOWN => self.step_line_editing(1).map(|m| (m, false)),
            _ => None,
        }
    }

    /// Copy the live selection to the clipboard; `cut` also removes it from the input.
    /// 把当前选区复制到剪贴板；`cut` 还会把它从输入里删掉。
    ///
    /// Returns true when the frame changed, which for a cut means a new buffer.
    /// 帧发生变化时返回真；对剪切而言就是缓冲变了。
    fn copy_selection(&mut self, cut: bool) -> bool {
        let kind = crate::clipboard::ClipboardKind::Selection;
        if let Some((owner, sel)) = self.editing {
            let Some(value) = self.text_input_value(owner) else {
                return false;
            };
            let range = sel.range();
            let (a, b) = (
                ui_core::text_input::clamp(&value, range.start),
                ui_core::text_input::clamp(&value, range.end),
            );
            if a == b {
                return false;
            }
            self.clipboard.push(crate::clipboard::ClipboardCommand::Copy {
                text: value[a..b].to_string(),
                kind,
            });
            if !cut {
                return true;
            }
            let (next, caret) = ui_core::text_input::delete_range(&value, a..b);
            self.editing = Some((owner, ui_core::TextSelection::collapsed(caret)));
            self.set_input_value(owner, &next);
            return self.app_changed(owner, ui_core::change::Change::Text(next));
        }
        // A read-only selection can be copied, never cut: nothing owns its text.
        // 只读选区可以复制、不能剪切：没有谁拥有它的文本。
        if cut {
            return false;
        }
        let Some((node, sel)) = self.selection else {
            return false;
        };
        let Some(value) = self.text_value(node) else {
            return false;
        };
        let range = sel.range();
        let (a, b) = (
            ui_core::text_input::clamp(&value, range.start),
            ui_core::text_input::clamp(&value, range.end),
        );
        if a == b {
            return false;
        }
        self.clipboard.push(crate::clipboard::ClipboardCommand::Copy {
            text: value[a..b].to_string(),
            kind,
        });
        true
    }

    /// Point the caret at the focused text input: the end of its buffer, or the previous
    /// offset when the same input keeps focus.
    /// 把插入符对准聚焦的文本输入：缓冲末尾，或同一输入保持焦点时的原偏移。
    fn sync_caret(&mut self) {
        let owner = self.focused.and_then(|id| self.text_input_owner(id));
        // A composition belongs to one input; moving focus ends it.
        // 组合内容属于某一个输入；焦点移动即结束它。
        if self.preedit.as_ref().is_some_and(|(id, _)| Some(*id) != owner) {
            self.preedit = None;
        }
        self.editing = owner.map(|owner| {
            let value = self.text_input_value(owner).unwrap_or_default();
            let sel = match self.editing {
                // The same input keeps its selection; a newly focused one starts at the end.
                // 同一个输入保留选区；新聚焦的输入从末尾开始。
                Some((prev, sel)) if prev == owner => sel,
                _ => ui_core::TextSelection::collapsed(value.len()),
            };
            (
                owner,
                ui_core::TextSelection::new(
                    ui_core::text_input::clamp(&value, sel.anchor),
                    ui_core::text_input::clamp(&value, sel.caret),
                ),
            )
        });
    }

    /// Feed one input event; returns true when a repaint is needed.
    /// 送入一个输入事件；需要重绘时返回 true。
    ///
    /// Hit testing uses the last laid-out frame, because input arrives between frames.
    /// 命中测试用上一帧的布局，因为输入在两帧之间到达。
    pub fn dispatch(&mut self, event: ui_core::Event) -> bool {
        // A move that cannot change a pixel is delivered but does not ask for a build: the
        // pointer reports several times per refresh, and building is the expensive part.
        // 改不动像素的移动照样送达，但不要求构建：指针每次刷新上报好几次，
        // 而构建是贵的那一头。
        let absorbed = event.is_continuous()
            && event
                .pos()
                .is_some_and(|p| !self.pointer_affects_frame(p));
        self.dispatched |= !absorbed;
        let before = (self.hovered, self.pressed, self.focused);
        // One-frame facts are cleared when a frame consumes them, not here: events arrive in
        // bursts, and a motion after a release must not erase a click no frame has read yet.
        // 单帧事实在帧消费它们时清除，而不是在这里：事件成批到达，
        // 松手之后的移动不得抹掉还没有任何一帧读到过的点击。
        // The app's answer to a callback is a repaint request, exactly like `event`'s.
        // app 对回调的回答就是一次重绘请求，与 `event` 的返回值同等。
        let mut requested = false;
        // A text edit already names the new buffer, so the caret must not be re-clamped
        // against the old one at the end of this dispatch.
        // 文本编辑已给出新缓冲，因此本次分发结束时不得再按旧值夹取插入符。
        let mut edited = false;
        if let Some(p) = event.pos() {
            self.pointer = Some(p);
        }
        if matches!(event, ui_core::Event::PointerLeft) {
            self.pointer = None;
            // A drag keeps its capture across leave: the button is still down, and
            // dropping the gesture here would strand the app mid-move.
            // 拖拽跨离开保持捕获：按钮仍按着，此时丢弃手势会让 app 停在移动中途。
        }
        // An open menu owns the pointer until it closes: a pick, or a dismissal.
        // 打开的菜单在关闭前占用指针：要么选中，要么被关掉。
        if self.menu.is_some()
            && let Some(handled) = self.menu_event(&event) {
                return handled || before != (self.hovered, self.pressed, self.focused);
            }
        // A node that captures keys turns them into chords instead of commands: a shortcut
        // editor must see the very chord it is about to bind.
        // 捕获按键的节点把按键变成组合键而不是命令：快捷键编辑器必须看到它即将绑定的组合。
        if let ui_core::Event::KeyPressed { key } = &event
            && let Some(id) = self.key_capture_owner() {
                // Tab still walks the focus ring; a capture that ate it would trap focus.
                // Tab 仍然走焦点环；吃掉它的捕获会把焦点困住。
                if !matches!(key, ui_core::Key::Tab) {
                    let chord = ui_core::KeyChord::new(*key, self.modifiers);
                    let changed = self.app_changed(id, ui_core::change::Change::KeyChord(chord));
                    return changed || before != (self.hovered, self.pressed, self.focused);
                }
            }
        // Shortcuts resolve before the key arms: a binding may claim a chord the plain
        // arms would read as navigation.
        // 快捷键先于按键分支解析：绑定可能认领本会被普通分支当作导航的组合键。
        if let ui_core::Event::KeyPressed { key } = &event
            && let Some((repaint, was_edit)) = self.fire_shortcut(*key) {
                let requested = repaint || was_edit;
                return requested || before != (self.hovered, self.pressed, self.focused);
            }
        if event.moves_pointer() {
            if let ui_core::Event::PointerMoved { pos } = &event {
                if self.scrollbar_drag.is_some() {
                    // A scrollbar drag owns the pointer while it lasts.
                    // 滚动条拖拽进行期间占用指针。
                    requested |= self.scrollbar_move(*pos);
                } else if self.pan.is_some() {
                    requested |= self.pan_move(*pos);
                } else if self.select_drag.is_some() {
                    // A selection drag owns the pointer: it is not a control drag.
                    // 选区拖拽占用指针：它不是控件拖拽。
                    requested |= self.extend_selection(*pos);
                } else if self.editing_drag.is_some() {
                    // The same inside a text input: the drag selects, it does not scroll.
                    // 文本输入内同理：拖拽是在选字，不是滚动。
                    requested |= self.extend_editing(*pos);
                } else if let Some(ev) = self.drag.moved(*pos) {
                    requested |= self.report_drag(self.in_node_space(ev));
                } else if self.pan_candidate.is_some()
                    && self.press_at.is_some_and(|at| ui_core::past_threshold(at, *pos))
                {
                    // The press became a pan: from here the content follows the pointer.
                    // 按下变成了平移：此后内容跟随指针。
                    requested |= self.begin_pan(*pos);
                } else if self.press_at.is_some_and(|at| ui_core::past_threshold(at, *pos)) {
                    // A press with no drag owner still dies once it travels past the
                    // threshold: it is neither a click nor a drag, so releasing later must
                    // not activate the node the pointer has left behind.
                    // 没有拖拽所有者的按下越过阈值后同样作废：它既不是点击也不是拖拽，
                    // 之后松手不得激活指针早已离开的节点。
                    self.pressed = None;
                    self.press_at = None;
                    self.pressed_path.clear();
                    self.end_splat();
                }
            }
            self.hovered = self.hit_at_pointer().and_then(|nid| self.hover_owner(nid));
            self.refresh_hovered_path();
        }
        match &event {
            ui_core::Event::Modifiers(m) => {
                self.modifiers = *m;
                // A shortcut editor previews the held modifiers, so it needs the repaint.
                // 快捷键编辑器要预览按住的修饰键，因此需要这次重绘。
                if self.key_capture_owner().is_some() {
                    requested = true;
                }
            }
            ui_core::Event::PointerPressed { button, pos } => {
                // A new press cancels any candidate the previous one left behind.
                // 新的按下清除上一次留下的候选。
                self.pan_candidate = None;
                if *button == ui_core::PointerButton::Primary {
                    // A press outside an open popup asks it to close: the light dismiss every
                    // flyout has, judged here because only the engine knows both rectangles.
                    // 落在打开着的浮层之外的按下要求它关闭：每个浮层都有的轻关闭，
                    // 由引擎判定，因为只有它同时知道两个矩形。
                    self.dismissed = self.tree.popup_root().and_then(|nid| {
                        self.tree
                            .get(nid)
                            .filter(|n| !n.visual_rect().contains(*pos))
                            .map(|n| n.id)
                    });
                    if self.dismissed.is_some() {
                        // The tap that dismisses belongs to the dismissal, as a light-dismiss
                        // layer takes it: it reaches nothing underneath and leaves no click.
                        // 关掉浮层的那一下属于这次关闭，正如轻关闭遮罩接住它：它不落到下面的
                        // 任何东西上，也不留下点击。
                        self.pressed = None;
                        self.press_at = None;
                        self.pressed_path.clear();
                        requested = true;
                    } else if self.scrollbar_press(*pos) {
                        // The bar took the press: no click, no ink, no focus change.
                        // 滚动条接下了这次按下：没有点击、墨迹或焦点变化。
                        requested = true;
                    } else {
                    let hit = self.hit_at_pointer();
                    if let Some(node) = hit.and_then(|id| self.selectable_text(id)) {
                        // A selectable label takes the press for its selection only: it is
                        // not a control press, so it never splats ink or reports a click.
                        // 可选标签只为选区接收按下：它不是控件按下，因此不泼墨、也不上报点击。
                        requested |= self.begin_selection(node, *pos);
                        self.pressed = None;
                        self.press_at = None;
                        self.pressed_path.clear();
                        self.focus_visible = false;
                        self.editing = None;
                        self.editing_drag = None;
                        self.preedit = None;
                        self.focused = hit.and_then(|id| {
                            self.tree.find_by_id(id).and_then(|nid| {
                                self.ancestor_with_sense(nid, ui_core::Sense::FOCUSABLE)
                            })
                        });
                    } else {
                        // Pressing anywhere else drops a read-only selection.
                        // 按在别处即丢弃只读选区。
                        if self.selection.take().is_some() {
                            requested = true;
                        }
                        self.select_drag = None;
                        self.pressed = hit;
                        self.press_at = Some(*pos);
                        // Pressing moves focus to the nearest node that subscribes to it; a
                        // press on inert ground clears focus instead of parking it on a box.
                        // 按下把焦点移到最近的订阅者；按在无订阅处则清除焦点，而不是停在一个盒子上。
                        self.focus_visible = false;
                        self.focused = self.pressed.and_then(|id| {
                            self.tree.find_by_id(id).and_then(|nid| {
                                self.ancestor_with_sense(nid, ui_core::Sense::FOCUSABLE)
                            })
                        });
                        self.refresh_pressed_path();
                        // A press inside a text input places the caret and opens a drag;
                        // the field itself still gets the click.
                        // 在文本输入内按下会定位插入符并开启拖拽；字段本身仍收到点击。
                        if let Some(owner) = self.pressed.and_then(|id| self.text_input_owner(id))
                            && let Some(index) = self.input_index_at(owner, *pos) {
                                self.selection = None;
                                self.editing =
                                    Some((owner, ui_core::TextSelection::collapsed(index)));
                                self.editing_drag = Some(owner);
                                requested = true;
                            }
                        // Ink starts where the finger landed, not at the control's centre: the
                        // declaration says how much, the engine knows where.
                        // 墨迹从手指落点开始，而不是控件中心：控件声明多大，引擎知道落在哪。
                        self.begin_splat(*pos);
                        // A press inside a scroller may become a pan; only the distance
                        // decides, so a click on a row still works.
                        // 滚动容器内的按下可能变成平移；由距离决定，因此点一行仍然有效。
                        self.pan_candidate = self
                            .hit_at_pointer()
                            .and_then(|id| self.pan_target(id));
                        // Touch-down stops inertia: the content freezes under the finger,
                        // or the coast and the drag would both move it.
                        // 按下即停止惯性：内容在手指下停住，否则滑行与拖拽会同时推动它。
                        if let Some(id) = self.pan_candidate {
                            self.end_motion(id);
                        }
                    }
                    if let Some(on) = self.drag_owner() {
                        self.drag.press(on, *pos);
                    }
                    }
                } else if *button == ui_core::PointerButton::Secondary {
                    // A right click focuses what it lands on first, so a text field can offer
                    // its own rows; nothing else hears the press.
                    // 右键先把焦点给它落到的节点，使文本字段能提供自己的行；这次按下不传给别的节点。
                    let hit = self
                        .hit
                        .topmost_consumer(*pos)
                        .and_then(|nid| self.tree.get(nid).map(|n| n.id));
                    self.focused = hit.and_then(|id| {
                        self.tree
                            .find_by_id(id)
                            .and_then(|nid| self.ancestor_with_sense(nid, ui_core::Sense::FOCUSABLE))
                    });
                    self.focus_visible = false;
                    self.sync_caret();
                    // Selectable text takes a caret where it was hit, so the rows it offers
                    // have something to act on. No drag: a menu, not a selection, follows.
                    // A hit inside the existing selection keeps it — Copy is what the menu
                    // is for.
                    // 可选文本在命中处放下插入符，使它的行有可作用的对象。不开启拖拽：接着来的是菜单。
                    // 落在既有选区之内的命中保留选区——菜单正是为了复制它。
                    if let Some(node) = hit.and_then(|id| self.selectable_text(id))
                        && let Some(index) = self.text_index_at(node, *pos) {
                            let kept = self
                                .selection
                                .is_some_and(|(sel_node, sel)| sel_node == node && sel.covers(index));
                            let sel = ui_core::TextSelection::collapsed(index);
                            if !kept && self.selection != Some((node, sel)) {
                                self.selection = Some((node, sel));
                                requested = true;
                            }
                        }
                    requested |= self.open_menu(*pos);
                }
            }
            ui_core::Event::PointerReleased { button, pos } => {
                if *button == ui_core::PointerButton::Primary {
                    self.scrollbar_drag = None;
                    self.pan_candidate = None;
                    // The pan ends first: its speed becomes the fling's, and the press it
                    // came from is already gone.
                    // 先结束平移：它的速度变成惯性的速度，而催生它的按下早已作废。
                    let now = self.clock.live();
                    requested |= self.end_pan(now);
                    if self.select_drag.take().is_some() {
                        // A selection drag ends here; it is neither a click nor a drag.
                        // 选区拖拽到此结束；它既不是点击也不是拖拽。
                        self.pressed = None;
                        self.press_at = None;
                        self.pressed_path.clear();
                    }
                    self.editing_drag = None;
                    let clicked = self.pressed.take();
                    let press_at = self.press_at.take();
                    self.pressed_path.clear();
                    // The ink outlives the press, but its growth stops here and the fade
                    // begins; waiting for the frame would delay it by one frame.
                    // 墨迹比按下活得久，但扩张到此为止、淡出从此开始；等到下一帧会晚一帧。
                    self.end_splat();
                    // The release is the last point of the pointer's path: a flick that
                    // produced no motion event still crosses the threshold here.
                    // 松手是指针路径的最后一点：没有中间移动事件的快速甩动在这里才越过阈值。
                    if !self.drag.is_dragging()
                        && let Some(ev) = self.drag.moved(*pos) {
                            requested |= self.report_drag(self.in_node_space(ev));
                        }
                    // The drop target is what is under the pointer *now*, so it must be
                    // hit tested before the press state is cleared.
                    // 放下目标是指针**此刻**下的东西，因此必须在清掉按下状态之前命中。
                    let target = self.drop_target();
                    match self.drag.release(target) {
                        Some(ev) => requested |= self.report_drag(self.in_node_space(ev)),
                        // No drag was live, so this was a click: report its identity.
                        // 没有拖拽在进行，因此这是一次点击：报告它的身份。
                        None => {
                            // Released within the threshold of the press: a click.
                            // The engine only records the *fact*; what a click means is
                            // the control's to decide, so nothing is announced from here.
                            // 松手时仍在按下点的阈值之内：这才是一次点击。
                            // 引擎只记录**事实**；点击的含义归控件判断，因此这里不宣布任何事。
                            // Only a subscriber is told: the engine routes, it does not
                            // decide what a click means.
                            // 只告知订阅者：引擎负责路由，不决定点击的含义。
                            let stayed = press_at.is_some_and(|at| !ui_core::past_threshold(at, *pos));
                            if let Some(id) = clicked.filter(|_| stayed) {
                                let subscribes = self
                                    .tree
                                    .find_by_id(id)
                                    .and_then(|nid| {
                                        self.ancestor_with_sense(nid, ui_core::Sense::CLICK)
                                    })
                                    .is_some();
                                if subscribes {
                                    self.clicked = Some(id);
                                }
                            }
                        }
                    }
                }
            }
            ui_core::Event::KeyPressed {
                key: ui_core::Key::Escape,
            } => {
                // A drag in flight owns Escape: cancelling it must not also drop focus.
                // 进行中的拖拽优先占用 Escape：取消它不该顺带丢掉焦点。
                match self.drag.cancel() {
                    Some(ev) => {
                        // The app restores its start state on `Cancelled`, so the engine
                        // must hand the gesture back now: a `dragging` that outlives the
                        // cancel freezes every family gated on it.
                        // app 收到 `Cancelled` 会恢复起始状态，引擎必须在同一刻交出手势：
                        // 取消之后仍为真的 `dragging` 会冻住所有以它为门控的家族。
                        requested |= self.report_drag(self.in_node_space(ev));
                        self.pressed = None;
                        self.press_at = None;
                        self.pressed_path.clear();
                        self.end_splat();
                    }
                    None => self.focused = None,
                }
            }
            // Tab walks the focus ring; Shift reverses it.
            // Tab 在焦点环上移动；Shift 反向。
            ui_core::Event::KeyPressed {
                key: ui_core::Key::Tab,
            } => {
                // Keyboard focus may show a ring; pointer focus may not.
                // 键盘焦点可以显示焦点环，指针焦点不行。
                self.focus_visible = true;
                self.focus_step(!self.modifiers.shift);
            }
            ui_core::Event::Scroll { delta, .. } => {
                // A scroll container the engine owns accumulates the wheel itself, clamped
                // to its content; any other scrollable reports the delta up as a semantic
                // value change, and the app keeps its own offset.
                // 引擎拥有的滚动容器自行累计滚轮、钳位到内容；其余可滚动节点把增量
                // 作为语义值上报，偏移由应用自己持有。
                if let Some(id) = self.scroll_target() {
                    if self.scroll_owned_delta(id, *delta) {
                        requested |= true;
                    } else if self.tree.find_by_id(id).is_some() {
                        requested |= self.app_changed(
                            id,
                            ui_core::change::Change::Value(-delta.y as f64),
                        );
                    }
                }
            }
            // Text goes to the caret, and the app gets the whole new buffer, never a diff.
            // 文本送到插入符处，应用收到完整的新缓冲，而不是差量。
            ui_core::Event::Text(text) => {
                if let Some((owner, sel)) = self.editing
                    && let Some(value) = self.text_input_value(owner) {
                        let (value, at) = ui_core::text_input::delete_range(&value, sel.range());
                        let (next, caret) = ui_core::text_input::insert(&value, at, text);
                        self.editing = Some((owner, ui_core::TextSelection::collapsed(caret)));
                        // A commit ends the composition; the engine never merges early.
                        // 提交即结束组合；引擎绝不提前并入。
                        self.preedit = None;
                        edited = true;
                        self.set_input_value(owner, &next);
                        requested |=
                            self.app_changed(owner, ui_core::change::Change::Text(next));
                    }
            }
            // A paste is one edit over the selection, exactly like typing one character.
            // 粘贴是对选区的一次编辑，与键入一个字符完全相同。
            ui_core::Event::Paste(text) => {
                if let Some((owner, sel)) = self.editing
                    && let Some(value) = self.text_input_value(owner) {
                        // The input is one line, so a line break would have nowhere to go.
                        // 输入只有一行，换行没有地方可去。
                        let text = text.replace("\r\n", " ").replace(['\r', '\n'], " ");
                        let (value, at) = ui_core::text_input::delete_range(&value, sel.range());
                        let (next, caret) = ui_core::text_input::insert(&value, at, &text);
                        self.editing = Some((owner, ui_core::TextSelection::collapsed(caret)));
                        self.preedit = None;
                        edited = true;
                        self.set_input_value(owner, &next);
                        requested |=
                            self.app_changed(owner, ui_core::change::Change::Text(next));
                    }
            }
            // The composition lives in the engine: the app's buffer stays committed-only.
            // 组合内容住在引擎里：应用的缓冲只含已提交内容。
            ui_core::Event::Preedit(preedit) => {
                if let Some((owner, _)) = self.editing {
                    let next = preedit
                        .as_ref()
                        .filter(|p| !p.is_empty())
                        .map(|p| (owner, p.clone()));
                    if self.preedit != next {
                        self.preedit = next;
                        requested = true;
                    }
                }
            }
            ui_core::Event::DeleteSurrounding { before, after } => {
                if let Some((owner, sel)) = self.editing
                    && let Some(value) = self.text_input_value(owner) {
                        // The protocol counts bytes; widen to whole clusters so a split
                        // surrogate-free sequence is never left half deleted.
                        // 协议按字节计数；向外扩到整字簇，避免留下删了一半的序列。
                        let start = ui_core::grapheme::snap(
                            &value,
                            sel.caret.saturating_sub(*before),
                        );
                        let end = ui_core::grapheme::ceil(
                            &value,
                            sel.caret.saturating_add(*after),
                        );
                        let (next, caret) = ui_core::text_input::delete_range(&value, start..end);
                        self.editing = Some((owner, ui_core::TextSelection::collapsed(caret)));
                        self.preedit = None;
                        edited = true;
                        self.set_input_value(owner, &next);
                        requested |=
                            self.app_changed(owner, ui_core::change::Change::Text(next));
                    }
            }
            ui_core::Event::KeyPressed {
                key: ui_core::Key::Backspace,
            } => {
                if let Some((owner, sel)) = self.editing
                    && let Some(value) = self.text_input_value(owner) {
                        let (next, caret) = if sel.is_collapsed() {
                            if self.modifiers.ctrl {
                                // Ctrl+Backspace removes the whole word behind the caret.
                                // Ctrl+Backspace 删掉插入符前的整个词。
                                let from = ui_core::text_input::step_word(&value, sel.caret, -1);
                                ui_core::text_input::delete_range(&value, from..sel.caret)
                            } else {
                                ui_core::text_input::backspace(&value, sel.caret)
                            }
                        } else {
                            ui_core::text_input::delete_range(&value, sel.range())
                        };
                        self.editing = Some((owner, ui_core::TextSelection::collapsed(caret)));
                        edited = true;
                        self.set_input_value(owner, &next);
                        requested |=
                            self.app_changed(owner, ui_core::change::Change::Text(next));
                    }
            }
            ui_core::Event::KeyPressed {
                key: ui_core::Key::Delete,
            } => {
                if let Some((owner, sel)) = self.editing
                    && let Some(value) = self.text_input_value(owner) {
                        let (next, caret) = if sel.is_collapsed() {
                            if self.modifiers.ctrl {
                                // Ctrl+Delete removes the whole word ahead of the caret.
                                // Ctrl+Delete 删掉插入符后的整个词。
                                let to = ui_core::text_input::step_word(&value, sel.caret, 1);
                                ui_core::text_input::delete_range(&value, sel.caret..to)
                            } else {
                                ui_core::text_input::delete(&value, sel.caret)
                            }
                        } else {
                            ui_core::text_input::delete_range(&value, sel.range())
                        };
                        self.editing = Some((owner, ui_core::TextSelection::collapsed(caret)));
                        edited = true;
                        self.set_input_value(owner, &next);
                        requested |=
                            self.app_changed(owner, ui_core::change::Change::Text(next));
                    }
            }
            ui_core::Event::KeyPressed {
                key: ui_core::Key::Left,
            } => {
                if self.editing.is_some() {
                    requested |= self.step_editing(-1);
                } else {
                    self.focus_spatial(Direction::Left);
                }
            }
            ui_core::Event::KeyPressed {
                key: ui_core::Key::Right,
            } => {
                if self.editing.is_some() {
                    requested |= self.step_editing(1);
                } else {
                    self.focus_spatial(Direction::Right);
                }
            }
            // Home, End and the Ctrl/Cmd commands live in the shortcut table, so an app can
            // rebind them by id; only plain navigation stays here.
            // Home、End 与 Ctrl/Cmd 命令住在快捷键表里，应用可按 id 改绑；
            // 这里只留下纯导航。
            ui_core::Event::KeyPressed {
                key: ui_core::Key::Up,
            } => match self.step_line_editing(-1) {
                Some(moved) => requested |= moved,
                None => {
                    self.focus_spatial(Direction::Up);
                }
            },
            ui_core::Event::KeyPressed {
                key: ui_core::Key::Down,
            } => match self.step_line_editing(1) {
                Some(moved) => requested |= moved,
                None => {
                    self.focus_spatial(Direction::Down);
                }
            },
            // Home and End jump to the ends of an open popup's list; an input keeps them for
            // the shortcut table, which is where its line editing lives.
            // Home 与 End 跳到打开浮层列表的两端；输入保留给快捷键表，行内编辑住在那里。
            ui_core::Event::KeyPressed {
                key: ui_core::Key::Home,
            } => {
                if self.editing.is_none() {
                    requested |= self.focus_popup_edge(false);
                }
            }
            ui_core::Event::KeyPressed {
                key: ui_core::Key::End,
            } => {
                if self.editing.is_none() {
                    requested |= self.focus_popup_edge(true);
                }
            }
            ui_core::Event::KeyPressed {
                key: ui_core::Key::Enter,
            }
            | ui_core::Event::KeyPressed {
                key: ui_core::Key::Space,
            } => {
                // A space inside a text input is text, already delivered as `Text`.
                // 文本输入里的空格是文本，已由 `Text` 送达。
                if matches!(event, ui_core::Event::KeyPressed { key: ui_core::Key::Space })
                    && self.editing.is_some()
                {
                    return requested;
                }
                // Shift+Enter in a declared multiline input is a hard break, one whole-buffer
                // edit like typing; single-line fields never reach it and fall through.
                // 声明为多行的输入里 Shift+Enter 是强制换行，与键入同样是整缓冲一次编辑；
                // 单行字段不会走到这里，继续落到下面的激活。
                if matches!(event, ui_core::Event::KeyPressed { key: ui_core::Key::Enter })
                    && self.modifiers.shift
                    && self.editing.is_some_and(|(owner, _)| self.input_is_multiline(owner))
                {
                    let (owner, sel) = self.editing.expect("checked above");
                    if let Some(value) = self.text_input_value(owner) {
                        let (value, at) = ui_core::text_input::delete_range(&value, sel.range());
                        let (next, caret) = ui_core::text_input::insert(&value, at, "\n");
                        self.editing = Some((owner, ui_core::TextSelection::collapsed(caret)));
                        self.preedit = None;
                        self.set_input_value(owner, &next);
                        requested |=
                            self.app_changed(owner, ui_core::change::Change::Text(next));
                        // Return instead of falling through: `Key::Enter` would otherwise
                        // activate the node, and this edit already owns the caret.
                        // 用 return 而非下穿：否则 `Key::Enter` 会去激活节点，而这次编辑已自行
                        // 决定了插入符。
                        return requested
                            || before != (self.hovered, self.pressed, self.focused);
                    }
                }
                // The engine owns keyboard translation: the app never sees a key code.
                // 引擎负责键盘翻译：app 永远看不到键码。
                // Keyboard activation is a focus event: only a focused, live node hears it,
                // and only inside the modal that owns the keyboard.
                // 键盘激活是焦点事件：只有已聚焦且存活的节点才会收到，
                // 而且必须在拥有键盘的那个模态之内。
                if let Some(id) = self.focused.filter(|id| self.in_key_scope(*id)) {
                    let live = self
                        .tree
                        .find_by_id(id)
                        .and_then(|nid| self.tree.get(nid))
                        .map(|n| !n.disabled)
                        .unwrap_or(false);
                    if live {
                        // The control's `change()` turns this into its own semantic change, as
                        // it does for a click; reporting it here too would deliver it twice.
                        // 控件的 `change()` 把它转成自己的语义变化，与点击相同；
                        // 这里再报一次会让同一事件送达两次。
                        self.activated = Some(id);
                        // The fact lives for exactly one frame, so that frame must run.
                        // 该事实只存活一帧，因此必须让那一帧跑起来。
                        requested = true;
                    }
                }
            }
            _ => {}
        }
        if !edited {
            self.sync_caret();
        }
        // Handled when anything asked for a repaint or the routing changed; there is no
        // raw-event hook for the app to answer.
        // 只要有东西请求重绘、或路由发生了变化就算已处理；app 没有原始事件钩子可回答。
        requested || before != (self.hovered, self.pressed, self.focused)
    }

    /// Recompute the pressed node's ancestor chain from the last laid-out frame.
    /// 用上次布局的帧重算被按下节点的祖先链。
    fn refresh_pressed_path(&mut self) {
        self.pressed_path.clear();
        let Some(id) = self.pressed else { return };
        let Some(nid) = self.tree.find_by_id(id) else { return };
        let mut cur = Some(nid);
        while let Some(node) = cur {
            let Some(n) = self.tree.get(node) else { break };
            self.pressed_path.push(n.id);
            cur = n.parent;
        }
        self.pressed_path.reverse();
    }

    /// Recompute the hovered node's ancestor chain from the last laid-out frame.
    /// 用上次布局的帧重算悬停节点的祖先链。
    fn refresh_hovered_path(&mut self) {
        self.hovered_path.clear();
        self.pointer_path.clear();
        let Some(nid) = self.pointer.and_then(|p| self.hit.topmost_consumer(p)) else {
            return;
        };
        let mut chain = Vec::new();
        let mut cur = Some(nid);
        while let Some(node) = cur {
            let Some(n) = self.tree.get(node) else {
                break;
            };
            // Only subscribers are on the path, so `hovered_within` answers the same
            // question the declaration did.
            // 只有订阅者在路径上，因此 `hovered_within` 回答的正是声明所问的那个问题。
            self.pointer_path.push(n.id);
            if n.sense.contains(ui_core::Sense::HOVER) {
                chain.push(n.id);
            }
            cur = n.parent;
        }
        chain.reverse();
        self.pointer_path.reverse();
        self.hovered_path = chain;
    }

    /// Where a wheel event should go: the nearest scrollable ancestor of the node under
    /// the pointer, or that node itself when nothing above it scrolls.
    /// 滚轮事件的去处：指针下节点的**最近可滚动祖先**；若其上方没有可滚动容器，
    /// 则仍是该节点本身。
    ///
    /// The wheel lands on whatever is on top — a row, a label — never on the viewport
    /// that would actually move, so routing it by the raw hit target does nothing.
    /// 滚轮落在最上面的东西上——一行、一个标签——而不会落在真正该移动的视口上，
    /// 因此按原始命中目标路由等于什么也没做。
    fn scroll_target(&self) -> Option<Id> {
        let start = self.pointer.and_then(|p| self.hit.topmost_consumer(p))?;
        let mut current = Some(start);
        while let Some(nid) = current {
            let Some(node) = self.tree.get(nid) else {
                break;
            };
            // Two ways to be a scroll container: the layout clip (overflow scrollable) or
            // the subscription bit. A control declares the bit; a container may set either.
            // 成为滚动容器有两条路：布局裁剪（可滚动溢出）或订阅位。控件声明订阅位；容器可任选。
            let scrolls_by_layout = node.data.params().map(|p| p.clip.scrolls()).unwrap_or(false);
            if scrolls_by_layout || node.sense.contains(ui_core::Sense::SCROLL) {
                return Some(node.id);
            }
            current = node.parent;
        }
        self.tree.get(start).map(|n| n.id)
    }

    /// Accumulate a wheel step into a scroll container the engine owns, on whichever axes
    /// its clip scrolls. Returns whether the target was such a container.
    /// 把滚轮步进累进引擎拥有的滚动容器，按它裁剪所声明的轴。返回目标是否为这种容器。
    fn scroll_owned_delta(&mut self, id: Id, delta: ui_core::geom::Point) -> bool {
        let Some(nid) = self.tree.find_by_id(id) else {
            return false;
        };
        let Some(node) = self.tree.get(nid) else {
            return false;
        };
        if !node.sense.contains(ui_core::Sense::SCROLL_OWNED) {
            return false;
        }
        let clip = node.data.params().map(|p| p.clip).unwrap_or_default();
        let (extent, viewport) = (node.scroll_extent, node.rect.size);
        // The stored offset is the source of truth across frames; the tree's own fields are
        // re-applied from it each frame and never read back.
        // 存储的偏移是跨帧的事实源；树的字段每帧由它重新写回，从不读回。
        let current = self.scroll_offsets.get(&id).copied().unwrap_or_default();
        let mut next = current;
        if clip.x == ui_core::layout::Overflow::Scroll {
            // A strip that only scrolls sideways still takes an upright wheel: there is no
            // other axis it could mean, and a mouse has one wheel.
            // 只横向滚动的条带照样接收竖直滚轮：它没有别的轴可指，而鼠标只有一个轮。
            let step = if clip.y == ui_core::layout::Overflow::Scroll || delta.x != 0.0 {
                delta.x
            } else {
                delta.y
            };
            next.x = (current.x + step).clamp(0.0, (extent.w - viewport.w).max(0.0));
        }
        if clip.y == ui_core::layout::Overflow::Scroll {
            next.y = (current.y + delta.y).clamp(0.0, (extent.h - viewport.h).max(0.0));
        }
        self.scroll_offsets.insert(id, next);
        // A wheel takes the scroller back: a coasting or bouncing offset must not fight it.
        // 滚轮重新接管该容器：滑行或回弹中的偏移不得与它相争。
        self.end_motion(id);
        // Even a no-op wheel counts as activity: the auto scrollbar should flash on.
        // 即使空转的滚轮也算活动：自动滚动条应当闪烁出现。
        self.scrolled_since.insert(id);
        true
    }

    /// Animate the nearest engine-owned scroller above `from` by `(dx, dy)`, clamped to its
    /// content. A control says where it wants its strip to go without knowing its id.
    /// 把 `from` 之上最近的引擎滚动容器按 `(dx, dy)` 缓动，并钳在内容范围内。
    /// 控件因此不必知道滚动容器的 id 就能要求它移动。
    /// Move the nearest vertical scroller the least amount that shows `id` whole.
    /// 让最近的纵向滚动容器移动最小的距离，使 `id` 完整可见。
    fn bring_into_view(&mut self, id: Id) -> bool {
        let Some(nid) = self.tree.find_by_id(id) else {
            return false;
        };
        let Some(rect) = self.tree.get(nid).map(|n| n.rect) else {
            return false;
        };
        // Walk up for the scroller, copying what the arithmetic needs so the borrow ends.
        // 向上找滚动容器，并把算式需要的事实取出来，以便结束借用。
        let mut cur = self.tree.get(nid).and_then(|n| n.parent);
        let mut found = None;
        while let Some(p) = cur {
            let Some(parent) = self.tree.get(p) else {
                break;
            };
            let clip = parent.data.params().map(|p| p.clip).unwrap_or_default();
            if parent.sense.contains(ui_core::Sense::SCROLL_OWNED)
                && clip.y == ui_core::layout::Overflow::Scroll
            {
                found = Some((
                    parent.id,
                    parent.rect.size.h,
                    parent.scroll_extent.h,
                    parent.rect.min_y(),
                ));
                break;
            }
            cur = parent.parent;
        }
        let Some((scroller, viewport, extent, viewport_top)) = found else {
            return false;
        };
        let current = self.scroll_offsets.get(&scroller).copied().unwrap_or_default();
        // Children are laid out already offset, so content space adds the offset back.
        // 子节点已按偏移摆放，因此内容坐标要把偏移加回去。
        let top = rect.min_y() - viewport_top + current.y;
        let bottom = top + rect.size.h;
        let mut y = current.y;
        if top < y {
            y = top;
        } else if bottom > y + viewport {
            y = bottom - viewport;
        }
        let y = y.clamp(0.0, (extent - viewport).max(0.0));
        if (y - current.y).abs() < 0.01 {
            return false;
        }
        self.scroll_offsets.insert(
            scroller,
            ui_core::cx::ScrollOffset { x: current.x, y },
        );
        self.scrolled_since.insert(scroller);
        true
    }

    fn scroll_owner_by(&mut self, from: Id, dx: f32, dy: f32) -> bool {
        let mut cur = self.tree.find_by_id(from);
        while let Some(nid) = cur {
            let Some(node) = self.tree.get(nid) else {
                return false;
            };
            if node.sense.contains(ui_core::Sense::SCROLL_OWNED) && Self::scrolls(node) {
                let id = node.id;
                return self.scroll_owner(id, dx, dy);
            }
            cur = node.parent;
        }
        false
    }

    /// Move the scroller `id` by this much; a request that names a node which is not an
    /// engine-owned scroller moves nothing, rather than guessing at one.
    /// 让滚动容器 `id` 移动这么多；指名了一个并非引擎自有滚动容器的节点时不动，
    /// 而不是去猜一个。
    fn scroll_owner(&mut self, id: Id, dx: f32, dy: f32) -> bool {
        let Some(nid) = self.tree.find_by_id(id) else {
            return false;
        };
        let Some(node) = self.tree.get(nid) else {
            return false;
        };
        if !node.sense.contains(ui_core::Sense::SCROLL_OWNED) || !Self::scrolls(node) {
            return false;
        }
        let clip = node.data.params().map(|p| p.clip).unwrap_or_default();
        let (extent, viewport) = (node.scroll_extent, node.rect.size);
        let current = self.scroll_offsets.get(&id).copied().unwrap_or_default();
        let mut next = current;
        if clip.x == ui_core::layout::Overflow::Scroll {
            next.x = (current.x + dx).clamp(0.0, (extent.w - viewport.w).max(0.0));
        }
        if clip.y == ui_core::layout::Overflow::Scroll {
            next.y = (current.y + dy).clamp(0.0, (extent.h - viewport.h).max(0.0));
        }
        if next == current {
            return false;
        }
        self.start_settle(id, next.x, next.y);
        self.scrolled_since.insert(id);
        true
    }

    /// Whether this node clips and scrolls at least one axis.
    /// 本节点是否至少有一条轴在裁切并滚动。
    fn scrolls(node: &ui_core::tree::Node) -> bool {
        let clip = node.data.params().map(|p| p.clip).unwrap_or_default();
        clip.x == ui_core::layout::Overflow::Scroll || clip.y == ui_core::layout::Overflow::Scroll
    }

    /// The scrollbar under `pos`, its scroller, and that scroller's visual rect.
    /// `pos` 下的滚动条、它所属的滚动容器，以及该容器的视觉矩形。
    fn scrollbar_at(
        &self,
        pos: ui_core::geom::Point,
    ) -> Option<(Id, ui_core::ScrollbarHit, ui_core::geom::Rect)> {
        let mut current = self.hit.topmost_consumer(pos);
        while let Some(nid) = current {
            let node = self.tree.get(nid)?;
            if let Some(bar) = node.data.params().and_then(|p| p.scrollbar) {
                let rect = node.visual_rect();
                let local =
                    ui_core::geom::Point::new(pos.x - rect.origin.x, pos.y - rect.origin.y);
                let inside = local.x >= bar.track.min_x()
                    && local.x <= bar.track.max_x()
                    && local.y >= bar.track.min_y()
                    && local.y <= bar.track.max_y();
                if inside {
                    return Some((node.id, bar, rect));
                }
            }
            current = node.parent;
        }
        None
    }

    /// Take a primary press on a scrollbar as a thumb drag; a press outside the thumb
    /// jumps it there first. Returns whether the press belonged to a scrollbar.
    /// 把落在滚动条上的主键按下当作 thumb 拖拽；按在 thumb 之外先把它跳过去。
    /// 返回这次按下是否属于滚动条。
    fn scrollbar_press(&mut self, pos: ui_core::geom::Point) -> bool {
        let Some((id, bar, rect)) = self.scrollbar_at(pos) else {
            return false;
        };
        let Some((extent, viewport)) = self
            .tree
            .find_by_id(id)
            .and_then(|nid| self.tree.get(nid))
            .map(|n| (n.scroll_extent, n.rect.size))
        else {
            return false;
        };
        let overflow = (extent.h - viewport.h).max(0.0);
        let travel = (bar.track.size.h - bar.thumb.size.h).max(0.0);
        if overflow <= 0.0 || travel <= 0.0 {
            return false;
        }
        let local_y = pos.y - rect.origin.y;
        let mut offset = self.scroll_offsets.get(&id).copied().unwrap_or_default();
        if local_y < bar.thumb.min_y() || local_y > bar.thumb.max_y() {
            offset.y =
                ((local_y - bar.thumb.size.h * 0.5) / travel * overflow).clamp(0.0, overflow);
            self.scroll_offsets.insert(id, offset);
        }
        self.scrollbar_drag = Some(ScrollbarDrag {
            id,
            press_y: pos.y,
            start_offset: offset.y,
            travel,
            overflow,
        });
        self.pressed = None;
        self.press_at = None;
        self.pressed_path.clear();
        true
    }

    /// Move the dragged thumb with the pointer; returns whether a drag was live.
    /// 让被拖的 thumb 跟随指针；返回是否有拖拽在进行。
    fn scrollbar_move(&mut self, pos: ui_core::geom::Point) -> bool {
        let Some(drag) = self.scrollbar_drag.as_ref() else {
            return false;
        };
        let id = drag.id;
        let next = (drag.start_offset + (pos.y - drag.press_y) / drag.travel * drag.overflow)
            .clamp(0.0, drag.overflow);
        let mut offset = self.scroll_offsets.get(&id).copied().unwrap_or_default();
        offset.y = next;
        self.scroll_offsets.insert(id, offset);
        self.scrolled_since.insert(id);
        true
    }

    /// The scroller a pointer drag from `hit` would move, if any.
    /// 从 `hit` 起拖拽会移动的滚动容器（若有）。
    ///
    /// Anything that claims dragging or selection between the press and the scroller owns
    /// the gesture: a slider or a selectable label must not pan the page. A plain click
    /// does not block, because a drag cancels a click anyway.
    /// 按下点到滚动容器之间若有节点认领拖拽或选择，手势归它：滑块或可选标签不得滚动页面。
    /// 单纯的可点击不会阻挡，因为拖拽本来就会取消点击。
    fn pan_target(&self, hit: Id) -> Option<Id> {
        let mut current = self.tree.find_by_id(hit);
        while let Some(nid) = current {
            let node = self.tree.get(nid)?;
            if node
                .sense
                .any(ui_core::Sense::DRAG | ui_core::Sense::SELECT)
            {
                return None;
            }
            if node.sense.contains(ui_core::Sense::SCROLL_OWNED) {
                return Some(node.id);
            }
            current = node.parent;
        }
        None
    }

    /// Take the pointer over as a pan once the press has travelled far enough.
    /// 按下移动足够远后，把指针接管为拖拽平移。
    fn begin_pan(&mut self, pos: ui_core::geom::Point) -> bool {
        self.pan_candidate = None;
        let Some(hit) = self.hit_at_pointer() else {
            return false;
        };
        let Some(id) = self.pan_target(hit) else {
            return false;
        };
        let Some(node) = self.tree.find_by_id(id).and_then(|n| self.tree.get(n)) else {
            return false;
        };
        let clip = node.data.params().map(|p| p.clip).unwrap_or_default();
        let axes = (
            clip.x == ui_core::layout::Overflow::Scroll,
            clip.y == ui_core::layout::Overflow::Scroll,
        );
        if !axes.0 && !axes.1 {
            return false;
        }
        let (extent, viewport) = (node.scroll_extent, node.rect.size);
        let raw = self.scroll_offsets.get(&id).copied().unwrap_or_default();
        // The pan owns the scroller from here; a coast still running would fight it.
        // 平移从此拥有该容器；仍在跑的滑行会与它相争。
        self.end_motion(id);
        self.pan = Some(ScrollPan {
            id,
            raw,
            // The threshold's own travel is dropped: the content starts moving from
            // where the finger crossed it, as a touch scroller does.
            // 阈值内的位移不计入：内容从手指越过阈值处开始移动，与触控滚动一致。
            last: pos,
            prev: raw,
            axes,
            overflow: ui_core::geom::Point::new(
                (extent.w - viewport.w).max(0.0),
                (extent.h - viewport.h).max(0.0),
            ),
            viewport,
            v: ui_core::geom::Point::new(0.0, 0.0),
        });
        // A pan is neither a click nor a control drag: the press it grew out of is over.
        // 平移既不是点击也不是控件拖拽：催生它的那次按下到此结束。
        self.pressed = None;
        self.press_at = None;
        self.pressed_path.clear();
        self.end_splat();
        true
    }

    /// Move the panned content with the pointer; returns whether a pan was live.
    /// 让被平移到内容跟随指针；返回是否有平移在进行。
    fn pan_move(&mut self, pos: ui_core::geom::Point) -> bool {
        let Some(pan) = self.pan.as_mut() else {
            return false;
        };
        let (dx, dy) = (pos.x - pan.last.x, pos.y - pan.last.y);
        pan.last = pos;
        // Content follows the finger, so the offset moves opposite to it.
        // 内容跟随手指，因此偏移与指针反向移动。
        if pan.axes.0 {
            pan.raw.x -= dx;
        }
        if pan.axes.1 {
            pan.raw.y -= dy;
        }
        let next = ui_core::cx::ScrollOffset {
            x: stretch(pan.raw.x, pan.overflow.x, pan.viewport.w),
            y: stretch(pan.raw.y, pan.overflow.y, pan.viewport.h),
        };
        let id = pan.id;
        self.scroll_offsets.insert(id, next);
        self.scrolled_since.insert(id);
        true
    }

    /// Release the pan: hand its speed to a fling, or to the spring if it is stretched.
    /// 松开平移：把速度交给惯性；若仍在拉伸，则交给弹簧。
    fn end_pan(&mut self, now: f64) -> bool {
        let Some(pan) = self.pan.take() else {
            return false;
        };
        let offset = self.scroll_offsets.get(&pan.id).copied().unwrap_or_default();
        let outside = offset.x < 0.0
            || offset.x > pan.overflow.x
            || offset.y < 0.0
            || offset.y > pan.overflow.y;
        if !outside && pan.v.x.abs() <= SCROLL_STOP && pan.v.y.abs() <= SCROLL_STOP {
            return true;
        }
        let target = if outside {
            self.start_bounce(pan.id, now, pan.v, pan.overflow)
        } else {
            ui_core::cx::ScrollOffset { x: 0.0, y: 0.0 }
        };
        self.scroll_motion.insert(
            pan.id,
            ScrollMotion {
                v0: pan.v,
                origin: offset,
                started_at: now,
                v: pan.v,
                spring: outside,
                overflow: pan.overflow,
                viewport: pan.viewport,
                target,
            },
        );
        true
    }

    /// Seed a scroller's springs at the offset they start from, then retarget them to the
    /// edge with `v` as the launch speed: without the seed the first frame jumps.
    /// 弹簧先以当前偏移起步，再改目标到边界并以 `v` 出发：没有起步值，第一帧就会跳。
    ///
    /// Returns the edge both axes settle on, which the caller keeps as the target: recomputing
    /// it from the moving offset would let the spring freeze wherever it overshoots.
    /// 返回两轴共同收敛到的边界，由调用方留作目标：按运动中的偏移重算，弹簧会停在它越界处。
    fn start_bounce(
        &mut self,
        id: Id,
        now: f64,
        v: ui_core::geom::Point,
        overflow: ui_core::geom::Point,
    ) -> ui_core::cx::ScrollOffset {
        let offset = self.scroll_offsets.get(&id).copied().unwrap_or_default();
        let target = ui_core::cx::ScrollOffset {
            x: offset.x.clamp(0.0, overflow.x),
            y: offset.y.clamp(0.0, overflow.y),
        };
        for (key, from, to, speed) in [
            ("scroll-x", offset.x, target.x, v.x),
            ("scroll-y", offset.y, target.y, v.y),
        ] {
            let key = id.with(key);
            // A spring left over from the previous bounce would ignore `from` and start
            // where it stopped, which is exactly the jump this seeds away.
            // 上一次回弹留下的弹簧会忽略 `from`，从它停下的地方起步，
            // 那正是这里要避免的跳变。
            self.anim_store.forget_spring(key);
            self.anim_store
                .spring_hinted(key, from, BOUNCE_STIFFNESS, BOUNCE_DAMPING, 0.0, now);
            self.anim_store.spring_hinted(
                key,
                to,
                BOUNCE_STIFFNESS,
                BOUNCE_DAMPING,
                speed * BOUNCE_ENTRY,
                now,
            );
        }
        target
    }

    /// Send a scroller to an offset under the same spring a bounce settles with: a move the
    /// app asks for eases instead of landing at once.
    /// 用回弹所用的同一条弹簧把滚动容器送到偏移：应用请求的移动因此是缓动而非一步到位。
    fn start_settle(&mut self, id: Id, x: f32, y: f32) {
        let from = self.scroll_offsets.get(&id).copied().unwrap_or_default();
        let target = ui_core::cx::ScrollOffset { x, y };
        for (key, from, to) in [("scroll-x", from.x, x), ("scroll-y", from.y, y)] {
            let key = id.with(key);
            self.anim_store.forget_spring(key);
            self.anim_store
                .spring_hinted(key, from, BOUNCE_STIFFNESS, BOUNCE_DAMPING, 0.0, self.frame_now);
            self.anim_store
                .spring_hinted(key, to, BOUNCE_STIFFNESS, BOUNCE_DAMPING, 0.0, self.frame_now);
        }
        self.scroll_motion.insert(
            id,
            ScrollMotion {
                v0: ui_core::geom::Point::new(0.0, 0.0),
                origin: from,
                started_at: self.frame_now,
                v: ui_core::geom::Point::new(0.0, 0.0),
                spring: true,
                overflow: ui_core::geom::Point::new(0.0, 0.0),
                viewport: ui_core::geom::Size::new(0.0, 0.0),
                target,
            },
        );
    }

    /// Measure the pan's speed from what the frame actually moved, so the fling starts
    /// with the hand's speed and not with an event's.
    /// 按本帧实际移动量测出平移速度，惯性因此以手的而非事件的速度起步。
    fn sample_pan_velocity(&mut self, dt: f32) {
        let Some(pan) = self.pan.as_mut() else {
            return;
        };
        let offset = self.scroll_offsets.get(&pan.id).copied().unwrap_or_default();
        if dt > 0.0 {
            let instant = ui_core::geom::Point::new(
                (offset.x - pan.prev.x) / dt,
                (offset.y - pan.prev.y) / dt,
            );
            // Smoothed: one frame's jitter must not decide a fling's direction.
            // 做平滑：单帧抖动不应决定甩动的方向。
            pan.v = ui_core::geom::Point::new(
                pan.v.x + (instant.x - pan.v.x) * 0.6,
                pan.v.y + (instant.y - pan.v.y) * 0.6,
            );
        }
        pan.prev = offset;
    }

    /// Drop a scroller's motion together with the springs it seeded.
    /// 丢弃滚动容器的运动，连同它种下的弹簧。
    ///
    /// Only this motion advances those springs, so one left behind would report itself as
    /// still moving for ever and keep the frame loop awake with nothing to draw.
    /// 只有这里的运动在推进那些弹簧，残留下来的一条会永远声称还在动，让帧循环空转。
    fn end_motion(&mut self, id: Id) {
        self.scroll_motion.remove(&id);
        self.anim_store.forget_spring(id.with("scroll-x"));
        self.anim_store.forget_spring(id.with("scroll-y"));
    }

    /// Advance every released scroller: momentum decays exponentially, and past an end
    /// the spring takes over, carrying whatever speed the fling arrived with.
    /// 推进每个已松手的滚动容器：惯性按指数衰减，越过端点则交给弹簧，并带上惯性到达时的速度。
    fn advance_scroll_motion(&mut self, now: f64, dt: f32) {
        if dt <= 0.0 || self.scroll_motion.is_empty() {
            return;
        }
        let ids: Vec<Id> = self.scroll_motion.keys().copied().collect();
        for id in ids {
            let Some(mut motion) = self.scroll_motion.get(&id).copied() else {
                continue;
            };
            let next = if motion.spring {
                let x = self.anim_store.spring_hinted(
                    id.with("scroll-x"),
                    motion.target.x,
                    BOUNCE_STIFFNESS,
                    BOUNCE_DAMPING,
                    0.0,
                    now,
                );
                let y = self.anim_store.spring_hinted(
                    id.with("scroll-y"),
                    motion.target.y,
                    BOUNCE_STIFFNESS,
                    BOUNCE_DAMPING,
                    0.0,
                    now,
                );
                // The spring decides when it has landed, not a threshold of our own: a
                // looser one would end the motion while the spring still reports movement.
                // 落定与否由弹簧自己说了算，而不是另定一个阈值：更松的阈值会在弹簧仍报
                // 运动时就结束运动。
                let settled = !self.anim_store.spring_live(id.with("scroll-x"))
                    && !self.anim_store.spring_live(id.with("scroll-y"));
                if settled {
                    self.end_motion(id);
                    Some(motion.target)
                } else {
                    Some(ui_core::cx::ScrollOffset { x: x.x, y: y.x })
                }
            } else {
                // Closed form: the same distance the decay integral gives, so a dropped frame
                // does not turn into one large jump.
                // 闭式解：与衰减积分给出同一段距离，掉帧因此不会变成一次大跳。
                let t = (now - motion.started_at) as f32;
                let decay = (-SCROLL_FRICTION * t).exp();
                motion.v = ui_core::geom::Point::new(motion.v0.x * decay, motion.v0.y * decay);
                let travel = (1.0 - decay) / SCROLL_FRICTION;
                let (raw_x, raw_y) = (
                    motion.origin.x + motion.v0.x * travel,
                    motion.origin.y + motion.v0.y * travel,
                );
                let crossed = raw_x < 0.0
                    || raw_x > motion.overflow.x
                    || raw_y < 0.0
                    || raw_y > motion.overflow.y;
                // Past an end the same rubber band damps the coast, so a long frame cannot
                // fling the content far out and then snap it back.
                // 越过端点时用同一条橡皮筋阻尼滑行，长帧因此不会把内容甩得很远再弹回。
                let moved = ui_core::cx::ScrollOffset {
                    x: stretch(raw_x, motion.overflow.x, motion.viewport.w),
                    y: stretch(raw_y, motion.overflow.y, motion.viewport.h),
                };
                if crossed {
                    // The momentum hands its speed to the spring at the edge.
                    // 惯性在边缘把速度交给弹簧。
                    self.scroll_offsets.insert(id, moved);
                    motion.spring = true;
                    motion.target = self.start_bounce(id, now, motion.v, motion.overflow);
                    self.scroll_motion.insert(id, motion);
                    Some(moved)
                } else if motion.v.x.abs() <= SCROLL_STOP && motion.v.y.abs() <= SCROLL_STOP {
                    self.end_motion(id);
                    Some(moved)
                } else {
                    self.scroll_motion.insert(id, motion);
                    Some(moved)
                }
            };
            if let Some(next) = next {
                self.scroll_offsets.insert(id, next);
                self.scrolled_since.insert(id);
            }
        }
    }

    /// The subtree that owns the keyboard: the topmost modal, else the topmost popup.
    /// 拥有键盘的子树：最上层模态，否则最上层浮层。
    fn focus_scope(&self) -> Option<ui_core::NodeId> {
        self.tree.modal_root().or_else(|| self.tree.popup_root())
    }

    /// Keep focus on a live node inside the topmost modal; report whether it moved.
    /// 让焦点停在最上层模态内的活节点上；返回它是否移动过。
    ///
    /// A dialog that opens takes focus from whatever was behind it, as WinUI's
    /// `ContentDialog` does, or Enter and Escape would reach nothing at all.
    /// 打开的对话框从身后接管焦点（与 WinUI 的 `ContentDialog` 一致），否则 Enter 与
    /// Escape 将无处可去。
    fn settle_focus(&mut self) -> bool {
        let before = (self.focused, self.focus_visible);
        if self.focused.is_some_and(|id| self.tree.find_by_id(id).is_none()) {
            self.focused = None;
        }
        if let Some(modal) = self.tree.modal_root() {
            let inside = self
                .focused
                .and_then(|id| self.tree.find_by_id(id))
                .is_some_and(|nid| self.tree.within(nid, modal));
            if !inside {
                self.focused = self.focus_stops(false).into_iter().next();
                // Programmatic: the ring waits until the user reaches the dialog by key.
                // 程序化聚焦：焦点环等用户自己用键盘走到对话框里再出现。
                self.focus_visible = false;
            }
            self.scope_root = None;
        } else if let Some(popup) = self.tree.popup_root() {
            // A popup takes the keyboard once, when it appears: WinUI's flyouts do the same,
            // or the arrows would keep walking the page behind an open menu.
            // 浮层只在出现时接管一次键盘：WinUI 的浮层如此，否则方向键会一直走去打开的菜单之后。
            if self.scope_root != Some(popup) {
                let inside = self
                    .focused
                    .and_then(|id| self.tree.find_by_id(id))
                    .is_some_and(|nid| self.tree.within(nid, popup));
                if !inside {
                    self.focus_before_scope = self.focused;
                    // A combo box opens onto its selected row; a menu onto its first.
                    // 下拉框打开时落在选中行上；菜单落在第一行。
                    let preferred = self
                        .tree
                        .get(popup)
                        .and_then(|n| n.data.params())
                        .and_then(|p| p.focus_initial);
                    let stops = self.focus_stops(false);
                    self.focused = preferred
                        .filter(|id| stops.contains(id))
                        .or_else(|| stops.first().copied());
                    self.focus_visible = false;
                }
                self.scope_root = Some(popup);
            }
        } else if self.scope_root.take().is_some() {
            // The popup went away. Focus inside it died with it, so it goes back to where it
            // was; a press outside already moved focus somewhere live, and keeps it.
            // 浮层消失。落在里面的焦点随它一起消失，于是回到原处；
            // 外部按下已把焦点移到一个活节点上，就留在那里。
            let alive = self.focused.is_some_and(|id| self.tree.find_by_id(id).is_some());
            if alive {
                self.focus_before_scope = None;
            } else {
                self.focused = self
                    .focus_before_scope
                    .take()
                    .filter(|id| self.tree.find_by_id(*id).is_some());
            }
        }
        if before != (self.focused, self.focus_visible) {
            self.damage.add(Rect::new(
                0.0,
                0.0,
                self.last_size.0 as f32,
                self.last_size.1 as f32,
            ));
            return true;
        }
        false
    }

    /// Nodes Tab can reach, in document order: they receive input and paint something.
    /// Tab 可达的节点，按文档顺序：既接收输入又绘制内容。
    ///
    /// A bare layout container is skipped: it is a hit target but has nothing to focus.
    /// 纯布局容器被跳过：它是命中目标，但没有可聚焦的内容。
    fn focusables(&self) -> Vec<Id> {
        self.focus_stops(true)
    }

    /// Focus stops inside the keyboard scope, in document order.
    /// 键盘作用域内的焦点停靠点，按文档顺序。
    ///
    /// `clipped` keeps only what the mask lets through, which is what Tab must walk; the
    /// initial take passes `false`, since an entrance animation clips its own first rows.
    /// `clipped` 只留遮罩放行的停靠点，Tab 走的正是它们；初始接管传 `false`，
    /// 因为入场动画会裁掉自己最前面的几行。
    fn focus_stops(&self, clipped: bool) -> Vec<Id> {
        let scope = self.focus_scope();
        self.tree
            .walk()
            .into_iter()
            // The scope root asks for the keyboard on behalf of its contents; it is not a stop
            // of its own, or a menu's first Tab would land on a panel that draws no ring.
            // 作用域根替它的内容索取键盘，自身不是停靠点；否则菜单的第一次 Tab 会落在一块
            // 不画焦点环的面板上。
            .filter(|nid| scope.is_none_or(|m| *nid != m && self.tree.within(*nid, m)))
            .filter_map(|nid| self.tree.get(nid))
            .filter(|n| {
                Self::hit_behavior_of(n.kind, n.sense, n.disabled) != HitBehavior::Ignore
            })
            .filter(|n| n.sense.contains(ui_core::Sense::FOCUSABLE))
            .filter(|n| focus_stop(n))
            .filter(|n| {
                // The mask is in visual space, so the rect compared against it must be too.
                // 遮罩位于视觉空间，与它比较的矩形也必须是视觉矩形。
                !clipped
                    || !n
                        .visual_rect()
                        .intersection(n.focus_mask)
                        .unwrap_or(ui_core::geom::Rect::ZERO)
                        .is_empty()
            })
            .map(|n| n.id)
            .collect()
    }

    /// Whether `id` may hear the keyboard: it sits inside the modal that owns it, if any.
    /// `id` 能否收到键盘：若有模态，它必须在该模态之内。
    fn in_key_scope(&self, id: Id) -> bool {
        match self.tree.modal_root() {
            None => true,
            Some(modal) => self
                .tree
                .find_by_id(id)
                .is_some_and(|nid| self.tree.within(nid, modal)),
        }
    }

    fn focusables_with_rects(&self) -> Vec<(Id, Rect)> {
        // A modal owns the keyboard: Tab and the arrows may not walk out of the surface it
        // covers, or the scrim would only be a picture of a modal.
        // 模态拥有键盘：Tab 与方向键不得走出它所覆盖的表面，否则遮罩只是模态的一幅画。
        let scope = self.focus_scope();
        self.tree
            .walk()
            .into_iter()
            .filter(|nid| scope.is_none_or(|m| *nid != m && self.tree.within(*nid, m)))
            .filter_map(|nid| self.tree.get(nid))
            // An inert node is not a Tab stop either, so the same gate applies here.
            // 惰性节点同样不是 Tab 停靠点，因此这里用同一道门。
            .filter(|n| Self::hit_behavior_of(n.kind, n.sense, n.disabled) != HitBehavior::Ignore)
            .filter(|n| n.sense.contains(ui_core::Sense::FOCUSABLE))
            .filter(|n| focus_stop(n))
            .filter_map(|n| {
                let r = n
                    .visual_rect()
                    .intersection(n.focus_mask)
                    .unwrap_or(Rect::ZERO);
                (!r.is_empty()).then_some((n.id, r))
            })
            .collect()
    }

    /// Move focus to the nearest node in `dir`, judged from layout rects.
    /// 把焦点移到 `dir` 方向上最近的节点，依据布局矩形判断。
    ///
    /// Geometry, not tree order: a node can be visually anywhere regardless of where it
    /// sits in the tree, so structural order answers a different question (that is Tab).
    /// 依据几何而非树序：节点的视觉位置可以完全脱离它在树里的位置，
    /// 结构顺序回答的是另一个问题（那是 Tab）。
    fn focus_spatial(&mut self, dir: Direction) -> bool {
        // Arrow keys are keyboard focus like Tab, so they may show a ring after a click.
        // 方向键与 Tab 一样属于键盘焦点，因此点击之后它们也可以显示焦点环。
        self.focus_visible = true;
        let items = self.focusables_with_rects();
        if items.is_empty() {
            return false;
        }
        let Some((current, from)) = self
            .focused
            .and_then(|f| items.iter().find(|(id, _)| *id == f).copied())
        else {
            // Nothing focused: arrows start the ring, like Tab does.
            // 尚无焦点：方向键像 Tab 一样从头开始。
            let first = items[0].0;
            if self.focused == Some(first) {
                return false;
            }
            self.focused = Some(first);
            return true;
        };
        let best = items
            .iter()
            .filter(|(id, _)| *id != current)
            .filter_map(|(id, r)| spatial_score(from, *r, dir).map(|score| (score, *id)))
            .min_by(|a, b| {
                // Lexicographic: band miss, then gap, then misalignment.
                // 字典序：错带、间隙、偏轴量。
                a.0.0.total_cmp(&b.0.0)
                    .then(a.0.1.total_cmp(&b.0.1))
                    .then(a.0.2.total_cmp(&b.0.2))
            });
        match best {
            // No wrap: an arrow that finds nothing in its direction must not jump across
            // the screen, which would be indistinguishable from a wrong answer.
            // 不环绕：该方向没有候选时，方向键不能跳到屏幕另一端，
            // 那与「答案错了」无法区分。
            Some((_, id)) => {
                self.focused = Some(id);
                true
            }
            // A menu's ends meet: Down on the last item wraps to the first, as its own list
            // does. Only a popup wraps — on a page an arrow that finds nothing must not jump.
            // 菜单的两端相接：最后一项按下绕回第一项，与它自己的列表一致。
            // 只有浮层会绕——页面上找不到目标的箭头绝不能跳。
            None => self.wrap_in_popup(dir, &items, current),
        }
    }

    /// Move focus to the first or last item of an open popup, in document order.
    /// 把焦点移到打开浮层的第一项或最后一项，按文档顺序。
    fn focus_popup_edge(&mut self, last: bool) -> bool {
        if !self.popup_owns_keys() {
            return false;
        }
        let items = self.focusables();
        let next = if last { items.last() } else { items.first() }.copied();
        match next {
            Some(id) if self.focused != Some(id) => {
                self.focused = Some(id);
                self.focus_visible = true;
                true
            }
            _ => false,
        }
    }

    /// Whether the keyboard belongs to an open popup rather than to the page behind it.
    /// 键盘是否属于一块打开的浮层，而不是它身后的页面。
    fn popup_owns_keys(&self) -> bool {
        self.tree.modal_root().is_none() && self.tree.popup_root().is_some()
    }

    /// Wrap an arrow that found nothing to the far end of an open popup's axis.
    /// 把找不到目标的方向键绕到打开浮层的轴另一端。
    fn wrap_in_popup(&mut self, dir: Direction, items: &[(Id, Rect)], current: Id) -> bool {
        if !self.popup_owns_keys() {
            return false;
        }
        let along_y = matches!(dir, Direction::Up | Direction::Down);
        let key = |r: Rect| if along_y { r.origin.y } else { r.origin.x };
        let forward = matches!(dir, Direction::Down | Direction::Right);
        let far = items
            .iter()
            .filter(|(id, _)| *id != current)
            .min_by(|a, b| {
                let (a, b) = (key(a.1), key(b.1));
                if forward { a.total_cmp(&b) } else { b.total_cmp(&a) }
            })
            .map(|(id, _)| *id);
        match far {
            Some(id) => {
                self.focused = Some(id);
                true
            }
            None => false,
        }
    }

    /// Move the keyboard focus to one named node, if the frame can focus it.
    /// 把键盘焦点移到某个具名节点，前提是本帧可以聚焦它。
    fn focus_node(&mut self, id: Id) -> bool {
        if self.focused == Some(id) || !self.focusables().contains(&id) {
            return false;
        }
        self.focused = Some(id);
        // A control that steers focus by itself is doing it for the keyboard.
        // 自己驱动焦点的控件是在为键盘服务。
        self.focus_visible = true;
        true
    }

    /// Move focus one step around the ring, wrapping at both ends.
    /// 在焦点环上移动一步，两端都环绕。
    fn focus_step(&mut self, forward: bool) -> bool {
        let items = self.focusables();
        if items.is_empty() {
            return false;
        }
        let next = match self.focused.and_then(|f| items.iter().position(|id| *id == f)) {
            Some(i) if forward => items[(i + 1) % items.len()],
            Some(i) => items[(i + items.len() - 1) % items.len()],
            None if forward => items[0],
            None => items[items.len() - 1],
        };
        if self.focused == Some(next) {
            return false;
        }
        self.focused = Some(next);
        true
    }

    /// The nearest ancestor-or-self of the *pressed* node that can be dragged.
    /// 被按下节点处最近的、可拖拽的祖先或自身。
    ///
    /// Anchored on the press, not on the pointer: a drag belongs to what was pressed, and
    /// resolving it from the pointer loses the gesture the moment it leaves the control.
    /// 锚定在按下而不是指针：拖拽属于按下时的目标，按指针解析会在它离开控件时丢掉手势。
    /// Rewrite a drag event's `local` point into the dragged node's own space.
    /// 把拖拽事件的 `local` 改写成被拖节点自身空间的坐标。
    ///
    /// The tracker is a pure state machine with no tree, so it reports surface points; the
    /// only place that knows the node's rect is here.
    /// 跟踪器是纯状态机、没有树，只能报表面坐标；知道节点矩形的地方只有这里。
    fn in_node_space(&self, ev: ui_core::DragEvent) -> ui_core::DragEvent {
        let origin = |id: Id| -> Option<ui_core::geom::Point> {
            let nid = self.tree.find_by_id(id)?;
            Some(self.tree.get(nid)?.visual_rect().origin)
        };
        match ev {
            ui_core::DragEvent::Started { on, from, local } => {
                let o = origin(on).unwrap_or(ui_core::geom::Point::new(0.0, 0.0));
                ui_core::DragEvent::Started {
                    on,
                    from,
                    local: ui_core::geom::Point::new(local.x - o.x, local.y - o.y),
                }
            }
            ui_core::DragEvent::Moved {
                on,
                delta,
                step,
                local,
            } => {
                let o = origin(on).unwrap_or(ui_core::geom::Point::new(0.0, 0.0));
                ui_core::DragEvent::Moved {
                    on,
                    delta,
                    step,
                    local: ui_core::geom::Point::new(local.x - o.x, local.y - o.y),
                }
            }
            other => other,
        }
    }

    fn drag_owner(&self) -> Option<Id> {
        let pressed = self.pressed?;
        let nid = self.tree.find_by_id(pressed)?;
        // The declaration is the only source: no hook can widen or veto it.
        // 只有声明是真相源：没有钩子能扩大或否决它。
        self.ancestor_matching(nid, |id| {
            self.tree
                .find_by_id(id)
                .and_then(|n| self.tree.get(n))
                .map(|n| n.sense.contains(ui_core::Sense::DRAG))
                .unwrap_or(false)
        })
    }

    /// Walk from `start` up to the root, returning the first id the predicate accepts.
    /// 从 `start` 上溯到根，返回第一个满足条件的 id。
    /// Every node folded as inert this frame, for the context to answer `is_disabled`.
    /// 本帧折入为惰性的全部节点，供上下文回答 `is_disabled`。
    fn inert_ids(&self) -> Vec<Id> {
        self.tree
            .walk()
            .into_iter()
            .filter_map(|nid| self.tree.get(nid))
            .filter(|n| n.disabled)
            .map(|n| n.id)
            .collect()
    }

    /// The nearest ancestor-or-self that subscribes to hover; `None` when none does.
    /// 最近的、订阅了悬停的自身或祖先；无人订阅时为 `None`。
    ///
    /// Hover is a subscription, not a side effect of being drawn: a plain box that never
    /// asked for it must not report itself hovered.
    /// 悬停是订阅而非「被画出来」的副作用：没订阅过的普通盒子不得报告自己被悬停。
    fn hover_owner(&self, start: Id) -> Option<Id> {
        self.tree
            .find_by_id(start)
            .and_then(|nid| self.ancestor_with_sense(nid, ui_core::Sense::HOVER))
    }

    /// The nearest ancestor-or-self whose node declares `bit`.
    /// 最近的、声明了 `bit` 的自身或祖先节点。
    fn ancestor_with_sense(&self, start: ui_core::NodeId, bit: ui_core::Sense) -> Option<Id> {
        let mut cur = Some(start);
        while let Some(node) = cur {
            let n = self.tree.get(node)?;
            if n.sense.contains(bit) {
                return Some(n.id);
            }
            cur = n.parent;
        }
        None
    }

    fn ancestor_matching(&self, start: ui_core::NodeId, want: impl Fn(Id) -> bool) -> Option<Id> {
        let mut cur = Some(start);
        while let Some(node) = cur {
            let n = self.tree.get(node)?;
            if want(n.id) {
                return Some(n.id);
            }
            cur = n.parent;
        }
        None
    }

    /// The nearest ancestor-or-self of the pointer that accepts a drop.
    /// 指针处最近的、接受放下的祖先或自身。
    fn drop_target(&self) -> Option<Id> {
        let nid = self.pointer.and_then(|p| self.hit.topmost_consumer(p))?;
        // Declared once on the node; the ancestor walk covers containers full of children.
        // 在节点上声明一次；沿祖先上溯以覆盖铺满子节点的容器。
        self.ancestor_matching(nid, |id| {
            self.tree
                .find_by_id(id)
                .and_then(|n| self.tree.get(n))
                .map(|n| n.sense.contains(ui_core::Sense::DROP))
                .unwrap_or(false)
        })
    }

    fn hit_at_pointer(&self) -> Option<Id> {
        self.pointer
            .and_then(|p| self.hit.topmost_consumer(p))
            .and_then(|nid| self.tree.get(nid).map(|n| n.id))
    }

    /// Node currently under the pointer.
    /// 当前指针下的节点。
    pub fn hovered(&self) -> Option<Id> {
        self.hovered
    }

    /// Node the primary button is held down on.
    /// 主键按住的节点。
    pub fn pressed(&self) -> Option<Id> {
        self.pressed
    }

    /// Node holding keyboard focus.
    /// 持有键盘焦点的节点。
    pub fn focused(&self) -> Option<Id> {
        self.focused
    }

    /// The focused text input and the caret's byte offset inside it.
    /// 持有焦点的文本输入，以及插入符在其中的字节偏移。
    pub fn caret(&self) -> Option<(Id, usize)> {
        self.editing.map(|(id, sel)| (id, sel.caret))
    }

    /// The live selection: an input's own, or a read-only text node's.
    /// 当前选区：文本输入自己的，或只读文本节点的。
    pub fn selection(&self) -> Option<(Id, ui_core::TextSelection)> {
        self.selection.or(self.editing)
    }

    /// Per-node fingerprint of the painted primitives from last frame.
    /// 上帧按节点的已绘制图元指纹。
    ///
    /// Geometry alone is not enough: changing a label, a colour or a glyph position
    /// leaves the rect identical while the pixels differ.
    /// 只看几何不够：改文案、改颜色、改字形位置时矩形不变而像素不同。
    /// Backdrop read distance for `id`, or `None` when it does not filter its backdrop.
    /// `id` 的背景读取距离；不过滤背景时返回 `None`。
    fn backdrop_pad(&self, id: Id) -> Option<f32> {
        self.tree
            .find_by_id(id)
            .and_then(|nid| self.tree.get(nid))
            .and_then(|n| n.data.params())
            .and_then(|p| p.backdrop_blur)
            .map(|b| b.radius as f32)
    }

    fn compute_damage(&mut self) {
        let current = self.prim_fingerprints();
        // Backdrop nodes are resolved after the ordinary ones: their pixels depend on what
        // changed, not on their own primitives, so they inherit damage rather than claim it.
        // 背景模糊节点在普通节点之后处理：它们的像素取决于「变了什么」而不是自身图元，
        // 因此继承脏区而不是自己制造脏区。
        let mut frosts: Vec<(Rect, f32)> = Vec::new();
        for (id, (ink_now, fp_now)) in &current {
            match self.node_prints.get(id) {
                // An identical fingerprint means this node contributes identical pixels.
                // 指纹相同意味着该节点贡献的像素完全相同。
                Some((_, fp_before)) if fp_before == fp_now => {
                    if let Some(pad) = self.backdrop_pad(*id) {
                        frosts.push((*ink_now, pad));
                    }
                }
                Some((ink_before, _)) => {
                    // old ∪ new: the vacated area must be cleared too.
                    // 旧∪新：腾出来的地方也必须清掉。
                    self.damage.add(*ink_before);
                    self.damage.add(*ink_now);
                }
                None => self.damage.add(*ink_now),
            }
        }
        for (id, (ink_before, _)) in &self.node_prints {
            if !current.contains_key(id) {
                self.damage.add(*ink_before);
            }
        }
        self.node_prints = current;
        // A layer's opacity and effects are not primitives: a change to them alone leaves
        // every fingerprint intact, so the layer's own area has to be claimed here.
        // 层的不透明度与效果不是图元：它们单独变化时指纹全都相同，
        // 因此要在这里为层自己的区域标脏。
        let layers: Vec<(Rect, Vec<ui_core::Effect>)> = self
            .resolved
            .layers
            .iter()
            .map(|l| (l.bounds, l.effects.clone()))
            .collect();
        for (bounds, effects) in &layers {
            let same = self
                .layer_prints
                .iter()
                .any(|(b, e)| b == bounds && e == effects);
            if !same {
                self.damage.add(*bounds);
            }
        }
        // A layer that disappears still changes the pixels under it, so its old bounds
        // need damage; a settled fade drops its layer on exactly the last frame shown.
        // 消失的层同样改变其下像素，旧边界必须标脏；淡入淡出落定的那一帧正好丢掉层。
        for (bounds, _) in &self.layer_prints {
            if !layers.iter().any(|(b, _)| b == bounds) {
                self.damage.add(*bounds);
            }
        }
        self.layer_prints = layers;
        // A frost only needs repainting where something under it actually changed.
        // 磨砂效果只需要在它下方确实发生变化的地方重绘。
        // Take the snapshot once: a frost must react to what changed under it, not to the
        // damage other frosts have already inherited.
        // 快照只取一次：磨砂应响应它下方真实的变化，而不是其他磨砂已继承的脏区。
        let inherited = self.damage.snapshot();
        let margin = |pad: f32| ui_core::geom::Insets::all(pad);
        for (ink, pad) in frosts {
            // The widened rect is a *probe* only: it decides whether a change can reach the
            // frost. What gets painted is always the change clipped back to the frost.
            // 外延矩形**只用于求交**：它判断某个变化能否影响到磨砂。
            // 真正标脏的始终是「脏区与磨砂矩形求交」的那部分。
            let probe = margin(pad).expand(ink);
            let reached = inherited
                .rects(ink)
                .iter()
                .any(|r| r.intersection(probe).is_some());
            // Any change within the kernel's reach alters every output pixel, because the
            // convolution re-reads a neighbourhood around each one. The whole frost is the
            // damaged region, not just the overlap.
            // 核读取范围内的任何变化都会改变每一个输出像素，因为卷积为每个像素重读邻域。
            // 因此脏区是整个磨砂矩形，而不只是重叠部分。
            if reached {
                self.damage.add(ink);
            }
        }
    }

    /// Union ink rect and content hash per owning node, taken from the resolved list.
    /// 从已解析列表取每个所属节点的合并墨迹矩形与内容哈希。
    fn prim_fingerprints(&self) -> FastMap<Id, (Rect, u64)> {
        use std::hash::{Hash, Hasher};

        let list = &self.resolved;
        let mut acc: FastMap<Id, (Rect, FastHasher)> = FastMap::default();
        let mut note = |nid: ui_core::NodeId, ink: Rect, fill: &mut dyn FnMut(&mut FastHasher)| {
            let Some(node) = self.tree.get(nid) else {
                return;
            };
            let entry = acc.entry(node.id).or_insert_with(|| {
                let mut hasher = FastHasher::default();
                // The node id seeds the hash so two nodes never collide by content alone.
                // 用节点 id 作种子，使两个节点不会仅因内容相同而碰撞。
                node.id.hash(&mut hasher);
                (Rect::ZERO, hasher)
            });
            entry.0 = union_rect(entry.0, ink);
            fill(&mut entry.1);
        };

        for op in &list.ops {
            let ui_core::draw::Op::Prim(prim) = op else {
                continue;
            };
            match prim.kind {
                PrimKind::Shadow => {
                    let i = prim.index as usize;
                    let p = &list.prims.shadows[i];
                    // The shader pads the quad past `rect`; damage has to claim all of it.
                    // 着色器会把四边形撑到 `rect` 之外；脏区必须把这些都算上。
                    note(list.owners.shadows[i], p.painted(), &mut |h| {
                        hash_rect(&p.rect, h);
                        hash_color(&p.colour, h);
                        p.blur.to_bits().hash(h);
                        p.dy.to_bits().hash(h);
                    });
                }
                PrimKind::Image => {
                    let i = prim.index as usize;
                    let p = &list.prims.images[i];
                    note(list.owners.images[i], p.rect, &mut |h| {
                        hash_rect(&p.rect, h);
                        h.write(&p.texture.to_le_bytes());
                        hash_rect(&p.src, h);
                    });
                }
                PrimKind::Rect => {
                    let i = prim.index as usize;
                    let p = &list.prims.rects[i];
                    let owner = list.owners.rects[i];
                    note(owner, p.rect, &mut |h| {
                        hash_rect(&p.rect, h);
                        for c in [p.radius.tl, p.radius.tr, p.radius.br, p.radius.bl] {
                            c.to_bits().hash(h);
                        }
                        hash_color(&p.fill, h);
                        match &p.border {
                            Some((c, w)) => {
                                true.hash(h);
                                hash_color(c, h);
                                w.to_bits().hash(h);
                            }
                            None => false.hash(h),
                        }
                    });
                }
                PrimKind::Sector => {
                    let i = prim.index as usize;
                    let p = &list.prims.sectors[i];
                    note(list.owners.sectors[i], p.bounds, &mut |h| {
                        hash_rect(&p.bounds, h);
                        hash_color(&p.colour, h);
                        let s = &p.sector;
                        for v in [
                            s.centre.x,
                            s.centre.y,
                            s.radius,
                            s.thickness,
                            s.trim.0,
                            s.trim.1,
                        ] {
                            v.to_bits().hash(h);
                        }
                        s.round_caps.hash(h);
                    });
                }
                PrimKind::Glyph => {
                    let i = prim.index as usize;
                    let p = &list.prims.glyphs[i];
                    let owner = list.owners.glyphs[i];
                    note(owner, p.rect, &mut |h| {
                        hash_rect(&p.rect, h);
                        hash_rect(&p.atlas, h);
                        p.alpha.to_bits().hash(h);
                        hash_color(&p.color, h);
                    });
                }
                PrimKind::Text => {
                    let i = prim.index as usize;
                    let p = &list.prims.texts[i];
                    let owner = list.owners.texts[i];
                    let (text, _) = p.block.flatten();
                    let style = p.block.runs.first().map_or_else(Default::default, |r| r.style);
                    let ink = Rect::new(
                        p.origin.x,
                        p.origin.y,
                        style.size * text.chars().count() as f32 * 0.6,
                        style.size * 1.3,
                    );
                    note(owner, ink, &mut |h| {
                        text.hash(h);
                        style.size.to_bits().hash(h);
                        hash_color(&p.ink, h);
                    });
                }
            }
        }

        acc.into_iter()
            .map(|(id, (ink, hasher))| (id, (ink, hasher.finish())))
            .collect()
    }

    /// Paint the subtree, wrapping group-opacity nodes in an offscreen layer.
    /// 绘制子树，把组不透明度节点包进离屏层。
    ///
    /// Group opacity is not per-primitive alpha: two overlapping opaque children inside a
    /// 50% layer must stay uniformly 50%, not darken twice where they overlap.
    /// 组不透明度不等于逐图元 alpha：50% 层内两个重叠的不透明子节点必须保持均匀 50%，
    /// 而不是在重叠处变暗两次。
    fn paint_tree(&mut self, root: ui_core::NodeId) {
        // The same order the hit index uses: modal and overlay subtrees last, so the topmost
        // in paint is the topmost in hits. One found inside a deferred one queues behind it.
        // 与命中索引用的是同一顺序：模态与浮层子树排最后，于是绘制最靠上的也正是命中最靠上的。
        // 在已推后的子树里再发现它们，就排到它后面。
        let mut deferred = Vec::new();
        self.paint_node(root, true, &mut deferred, None);
        // A held subtree is out of the live tree but still on screen while it leaves.
        // 被持有的子树已不在活动树里，但在离开期间仍在屏幕上。
        deferred.extend_from_slice(self.tree.held());
        let mut next = 0usize;
        while let Some(nid) = deferred.get(next).copied() {
            next += 1;
            self.paint_node(nid, false, &mut deferred, None);
        }
    }

    /// `inherited` is the rect of the innermost clip an ancestor already pushed this frame.
    /// 祖先本帧已压入的最内层裁剪矩形。
    fn paint_node(
        &mut self,
        nid: ui_core::NodeId,
        is_root: bool,
        deferred: &mut Vec<ui_core::NodeId>,
        inherited: Option<Rect>,
    ) {
        let Some(node) = self.tree.get(nid) else {
            return;
        };
        if node.mask.is_empty() && !is_root {
            return;
        }
        // A presence scale wraps the whole subtree: shapes, clips, layers and glyphs alike.
        // presence 缩放包住整棵子树：形状、裁剪、层与字形一视同仁。
        let outer = self.list.transform;
        if (node.presence_scale - 1.0).abs() > 1e-6 {
            let own =
                ui_core::draw::Transform::about(node.visual_rect().center(), node.presence_scale);
            self.list.transform = Some(match outer {
                Some(outer) => outer.then(own),
                None => own,
            });
        }

        // Layout intersected every declared clip down the tree; paint has to honour it.
        // A visible ancestor contributes nothing, so only this node's own ink is checked.
        // 布局已把每一道声明的裁剪沿树求交，绘制必须落实；
        // 可见祖先不贡献裁剪，因此只检查本节点自身的墨迹。
        let mask = node.mask;
        let ink = node.ink_rect();
        let corners = node_corners(node);
        // Only a container that declares a clip cuts its subtree; a visible one lets an
        // overflowing child paint, so the ink is not cut by an unasked-for rect.
        // 只有声明了裁剪的容器才裁切子树；可见容器让溢出的子节点照常绘制，
        // 墨迹不会因未声明的矩形而被切。
        let declaring_clip = !is_root
            && node
                .data
                .params()
                .map(|p| p.clip.clips())
                .unwrap_or(false)
            && !self.tree.children_of(Some(nid)).is_empty();
        let clipped = declaring_clip || (!is_root && exceeds(ink, mask));
        let mut pushed = false;
        let mut clip_rect = Rect::ZERO;
        if clipped {
            // A curved node keeps its own box; a square one is bounded by the mask alone.
            // 圆角节点按自身矩形裁剪；方角节点只受遮罩约束。
            clip_rect = if declaring_clip || corners.is_zero() {
                mask
            } else {
                // The mask is visual, so a displaced node's own box must be too.
                // 遮罩位于视觉空间，被位移节点自身的盒子也必须是视觉矩形。
                mask.intersection(node.visual_rect()).unwrap_or(Rect::ZERO)
            };
            // A node that declares no clip inherits its ancestor's shape; repeating the same
            // rect as a square cut would overwrite the ancestor's corners.
            // 未声明裁剪的节点继承祖先的形状；以方角重复同一矩形会覆盖祖先的圆角。
            let redundant = !declaring_clip && inherited == Some(clip_rect);
            if !redundant {
                // The corners belong to the node's uncut box: when a parent or the window cuts
                // it, the cut edge must stay square instead of gaining a corner of its own.
                // 圆角属于节点未裁切的盒子：父或窗口裁切时，切口必须保持方角，而不是自己长出圆角。
                self.list
                    .push_clip_shaped(clip_rect, corners, node.visual_rect());
                pushed = true;
            }
        }

        let backdrops_before = self.list.backdrops.len();
        // Presence folds into group opacity, so an entering subtree fades as one unit.
        // presence 折入组不透明度，正在入场的子树因此作为整体淡入。
        let (opacity, effects) = match &node.data {
            NodeData::Container(p) => {
                (p.opacity * node.presence_alpha, p.effects.clone())
            }
            _ => (1.0, Vec::new()),
        };
        let offscreen = matches!(&node.data, NodeData::Container(p) if p.offscreen);
        let layered = opacity < 1.0 || !effects.is_empty() || offscreen;
        let mut layer_index = None;
        if layered {
            // Bounds must cover everything the subtree paints, not just this node's rect.
            // 边界必须覆盖整个子树绘制的内容，而不只是本节点的矩形。
            let bounds = self.subtree_ink(nid);
            let mut chain = effects;
            if opacity < 1.0 {
                chain.push(ui_core::Effect::opacity(opacity));
            }
            // Kernels are authored in logical units, so their reach needs no conversion.
            // 卷积核按逻辑单位撰写，因此它触及的距离不需要换算。
            let reach = ui_core::EffectReach::of(&chain).actual as f32;
            let bounds = bounds.inflate(reach);
            layer_index = Some(if offscreen {
                self.list.push_cached_layer(
                    node.id.as_u64(),
                    bounds,
                    chain,
                    ui_core::geom::Corners::ZERO,
                )
            } else {
                self.list.push_layer(bounds, chain, ui_core::geom::Corners::ZERO)
            });
        }

        self.paint_self(nid);
        // Same order the hit index uses: `z` first, declaration order on a tie.
        // 与命中索引同一顺序：先 `z`，相同则按声明顺序。
        let child_inherited = if pushed { Some(clip_rect) } else { inherited };
        // Indexed rather than iterated: painting mutates the tree it is reading.
        // 用下标而不是迭代：绘制会改动它正在读的那棵树。
        let child_count = self.tree.children_in_paint_order(nid).len();
        for i in 0..child_count {
            let Some(child) = self.tree.paint_child_at(nid, i) else {
                continue;
            };
            // An overlay floats above everything it covers, so paint order cannot follow
            // declaration order. `walk()` defers these kinds; paint must match it.
            // 浮层浮在所覆盖的一切之上，绘制顺序因此不能跟声明顺序；`walk()` 已推后这几类，
            // 绘制必须与之一致。
            if self.tree.is_modal(child)
                || self.tree.is_overlay(child)
                || self.tree.is_lifted(child)
            {
                deferred.push(child);
                continue;
            }
            self.paint_node(child, false, deferred, child_inherited);
        }

        // Press ink draws over the node's own shapes and over its children: Material's
        // ripple tints whatever it covers, so an opaque child cannot hide it.
        // 按压墨迹盖在节点自身形状与子节点之上：Material 的涟漪会给覆盖到的一切染色，
        // 不透明的子节点因此遮不住它。
        let ink_args = self
            .tree
            .get(nid)
            .map(|n| (n.id, n.visual_rect(), node_corners(n)));
        if let Some((id, visual, outline)) = ink_args {
            self.paint_press_ink(nid, id, visual, outline);
        }

        // The adorner is drawn outside the box and above the subtree, so children can never
        // hide it; it is the last thing this node contributes to the frame.
        // 装饰画在盒子之外、子树之上，子节点遮不住它；它是本节点对帧的最后贡献。
        self.paint_focus_visual(nid);

        if let Some(index) = layer_index {
            // A frost inside reads its parent, which a skipped frame would not supply; such a
            // subtree has to be rebuilt every frame, so it keeps no cache.
            // 层内的磨砂读取父级，跳过绘制的帧提供不了它；这类子树必须每帧重建，因此不缓存。
            if self.list.backdrops.len() > backdrops_before {
                self.list.layers[index as usize].cache_key = None;
            }
            self.list.pop_layer();
        }
        if pushed {
            self.list.pop_clip();
        }
        self.list.transform = outer;
    }

    fn paint_self(&mut self, nid: ui_core::NodeId) {
        let Some(node) = self.tree.get(nid) else {
            return;
        };
        // Paint where the node *appears*, which differs from where layout put it when a
        // drag is offsetting it.
        // 按节点**出现**的位置绘制；拖拽偏移时它与布局位置不同。
        let visual = node.visual_rect();
        // Emitted before the fill: the blur must read the backdrop, not this node's own box.
        // 在填充之前发出：模糊必须读取背景，而不是本节点自己的盒子。
        if let Some(blur) = node.data.params().and_then(|p| p.backdrop_blur) {
            self.list.push_backdrop(ui_core::draw::BackdropEntry {
                rect: visual,
                // The frost is cut by the same clip as the box it shades: a panel sliding
                // inside its window must not blur the page it hangs over.
                // 磨砂与它着色的盒子同受一道裁剪：在窗口里滑动的面板不该模糊它所依附的页面。
                clip: node.mask,
                corners: node_corners(node),
                radius: blur.radius,
                sigma: blur.sigma,
                material: blur.material,
            });
        }
        let corners = node_corners(node);
        // Register the textures first: the shape pass may only read the slot table.
        // 先登记纹理：形状那一趟只读槽位表。
        for spec in node.shapes.iter().filter_map(|s| match s {
            ui_core::draw::Shape::Box { image: Some(spec), .. } => Some(spec),
            _ => None,
        }) {
            if !self.image_slots.contains_key(&spec.id)
                && let Some(entry) = self.images.get(&spec.id).cloned() {
                    let slot = self.list.push_image(entry);
                    self.image_slots.insert(spec.id, slot);
                }
        }
        let images = &self.images;
        let slots = &self.image_slots;
        ui_core::draw::push_shapes(&mut self.list, nid, node, visual, |spec, dest| {
            let entry = images.get(&spec.id)?;
            let (dest, src) = spec.fit.place(dest, (entry.width, entry.height));
            Some(ui_core::draw::ImagePrim {
                rect: dest,
                corners,
                texture: *slots.get(&spec.id)?,
                src,
            })
        });
        if let ui_core::NodeData::Text {
            block,
            ink,
            caret,
            selection,
            composing,
            ..
        } = &node.data
        {
            // A caret blinks while an input is being edited; the engine owns the clock, so
            // every field on every design system blinks the same way without a timer each.
            // 编辑输入期间插入符闪烁；时钟归引擎，各体系的每个字段因此自动同步，
            // 不必各自起一个定时器。
            // Recorded before the gate: the dark half still owes the engine a wake, or the
            // caret would go out and never come back.
            // 在门控之前记录：灭的半程同样欠引擎一次唤醒，否则插入符熄灭后再不会亮。
            self.caret_painted |= caret.is_some() && self.editing.is_some();
            let caret = if self.editing.is_some() && !self.caret_blink_lit(self.frame_now) {
                None
            } else {
                *caret
            };
            self.list.push_text(
                nid,
                TextPrim {
                    block: block.clone(),
                    origin: text_origin(node),
                    max_width: node.wrap_width,
                    layout: node.inline.clone(),
                    height: visual.size.h,
                    ink: *ink,
                    caret,
                    selection: selection.clone(),
                    composing: composing.clone(),
                    zoom: None,
                },
            );
        }
    }

    /// Draw the node's focus adorner, if it holds visible focus and asked for one.
    /// 若节点持有可见焦点且要求了装饰，就把它画出来。
    fn paint_focus_visual(&mut self, nid: ui_core::NodeId) {
        if !self.focus_visible {
            return;
        }
        let Some(node) = self.tree.get(nid) else {
            return;
        };
        if self.focused != Some(node.id) {
            return;
        }
        let Some(visual) = node.data.params().and_then(|p| p.focus_visual) else {
            return;
        };
        let rect = node.visual_rect();
        // XAML writes a negative margin when the adorner reaches outside the control.
        // XAML 用负的 margin 表示装饰伸出控件之外。
        let outer_rect = Rect::new(
            rect.origin.x + visual.margin.left,
            rect.origin.y + visual.margin.top,
            rect.size.w - visual.margin.left - visual.margin.right,
            rect.size.h - visual.margin.top - visual.margin.bottom,
        );
        let base = node_corners(node);
        let ring = |grow: f32| ui_core::geom::Corners {
            tl: base.tl + grow,
            tr: base.tr + grow,
            br: base.br + grow,
            bl: base.bl + grow,
            shape: base.shape,
        };
        if visual.outer_width > 0.0 {
            self.list.push_rect(
                nid,
                ui_core::draw::RectPrim {
                    rect: outer_rect,
                    radius: ring(visual.radius),
                    fill: ui_core::geom::Color::TRANSPARENT,
                    gradient: None,
                    border: Some((visual.outer, visual.outer_width)),
                    border_gradient: None,
                    notch: None,
                },
            );
        }
        if visual.inner_width > 0.0 {
            let w = visual.outer_width;
            let inner_rect = Rect::new(
                outer_rect.origin.x + w,
                outer_rect.origin.y + w,
                (outer_rect.size.w - 2.0 * w).max(0.0),
                (outer_rect.size.h - 2.0 * w).max(0.0),
            );
            self.list.push_rect(
                nid,
                ui_core::draw::RectPrim {
                    rect: inner_rect,
                    radius: ring((visual.radius - w).max(0.0)),
                    fill: ui_core::geom::Color::TRANSPARENT,
                    gradient: None,
                    border: Some((visual.inner, visual.inner_width)),
                    border_gradient: None,
                    notch: None,
                },
            );
        }
    }

    /// The live splats belonging to one node, oldest first.
    /// 属于某个节点的活墨迹，先泼的先画。
    fn paint_press_ink(
        &mut self,
        nid: ui_core::NodeId,
        id: Id,
        visual: Rect,
        corners: ui_core::geom::Corners,
    ) {
        if self.splats.is_empty() {
            return;
        }
        let now = self.frame_now;
        // The target is resolved per frame: a shape's rect or a descendant's box may be
        // mid-animation, so the reference must follow, as Flutter's `getRectCallback` does.
        // 目标每帧解析：形状矩形或后代盒子可能处于动画中段，参考框必须跟随，
        // 与 Flutter 的 `getRectCallback` 一致。
        let target = self.splats.iter().find(|s| s.node == id).map(|s| s.ink.target);
        let clip_geom: Option<(Rect, ui_core::geom::Corners)> = match target {
            Some(ui_core::InkTarget::Rect { rect, corners }) => Some((rect, corners)),
            Some(ui_core::InkTarget::Shape(index)) => self
                .tree
                .get(nid)
                .and_then(|node| node_shape_rect(node, visual, index)),
            Some(ui_core::InkTarget::Descendant(clip_id)) => self
                .tree
                .find_by_id(clip_id)
                .and_then(|cnid| self.tree.get(cnid))
                .map(|cnode| {
                    (
                        cnode.visual_rect().translate(ui_core::geom::Point::new(
                            -visual.origin.x,
                            -visual.origin.y,
                        )),
                        node_corners(cnode),
                    )
                }),
            Some(ui_core::InkTarget::Node) | None => None,
        };
        let clip = clip_geom.map(|(r, _)| r);
        let inks: Vec<(Rect, ui_core::geom::Color)> = self
            .splats
            .iter()
            .filter(|splat| splat.node == id)
            .filter_map(|splat| splat.prim(now, visual, clip))
            .collect();
        if inks.is_empty() {
            return;
        }
        // The effective background owns the curve too: an indicator is a pill, and the
        // splat cut to it must inherit that curve rather than the node's.
        // 有效背景也拥有曲线：指示片是胶囊，裁到它的墨迹应继承胶囊曲线而非节点的。
        let (clip_rect, clip_corners) = match clip_geom {
            Some((bg, curve)) => (bg.translate(visual.origin), curve),
            None => (visual, corners),
        };
        self.list.push_clip(clip_rect, clip_corners);
        for (rect, fill) in inks {
            self.list.push_rect(
                nid,
                ui_core::draw::RectPrim {
                    rect,
                    radius: ui_core::geom::Corners::all(rect.size.w * 0.5),
                    fill,
                    gradient: None,
                    border: None,
                    border_gradient: None,
                    notch: None,
                },
            );
        }
        self.list.pop_clip();
    }

    fn subtree_ink(&self, nid: ui_core::NodeId) -> Rect {
        let mut acc: Option<Rect> = None;
        let mut stack = vec![nid];
        while let Some(cur) = stack.pop() {
            if let Some(node) = self.tree.get(cur) {
                let ink = node.ink_rect();
                acc = Some(match acc {
                    Some(a) => union_rect(a, ink),
                    None => ink,
                });
            }
            stack.extend(self.tree.children_of(Some(cur)));
        }
        acc.unwrap_or(Rect::ZERO)
    }
}

/// Convenience: build a loop and run `frames` frames.
/// 便捷：建循环并跑 `frames` 帧。
pub fn run_app<A: App>(
    app: A,
    target: &mut dyn PresentTarget,
    frames: usize,
    pointer: Option<ui_core::geom::Point>,
) -> Vec<FrameOutcome> {
    let mut lp = AppLoop::new(app);
    (0..frames).map(|_| lp.frame(target, pointer)).collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use ui_core::Decl;
    use crate::present::OffscreenTarget;
    use ui_core::geom::{Color, Corners};
    use ui_core::layout::{AxisSize, Grow, SizeClass};

    /// Records which node the keyboard activated.
    /// 记录键盘激活了哪个节点。
    struct Counting {
        activated: Vec<Id>,
        scrolled: Vec<(Id, f32)>,
        expand: bool,
        /// Whether the bar owns drags, so "a drag is not a click" can be exercised.
        /// 长条是否拥有拖拽，用于检验「拖拽不算点击」。
        draggable: bool,
    }

    impl App for Counting {
        fn view(&mut self, f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            Demo {
                expand: self.expand,
                draggable: self.draggable,
            }
            .view(f)
        }
        fn changed(&mut self, id: Id, change: ui_core::change::Change) -> bool {
            use ui_core::change::Change as C;
            match change {
                C::Activated => self.activated.push(id),
                C::Value(v) => self.scrolled.push((id, -v as f32)),
                _ => {}
            }
            true
        }
    }

    struct Demo {
        expand: bool,
        /// Whether the bar subscribes to drags; the click-vs-drag test flips this.
        /// 长条是否订阅拖拽；「拖拽不算点击」这条测试靠它切换。
        draggable: bool,
    }

    /// The demo's bar as a control: a completed click means "activated".
    /// 示例的长条作为控件：一次完成的点击意味着「已激活」。
    struct DemoBar {
        draggable: bool,
    }

    impl crate::Element for DemoBar {
        fn decl(&self, _cx: &mut ui_core::cx::Cx<'_>) -> Decl {
            bar_decl(self.draggable)
        }

        fn change(
            &self,
            state: &crate::WidgetState,
            _bounds: Rect,
        ) -> Option<ui_core::change::Change> {
            (state.activation() && !state.disabled).then_some(ui_core::change::Change::Activated)
        }
    }

    fn bar_decl(draggable: bool) -> Decl {
        Decl {
                id: Id::str("bar"),
                kind: NodeKind::Box,
                shapes: vec![ui_core::draw::Shape::Box {
                    corners: ui_core::geom::Corners::ZERO,
                    fill: ui_core::geom::Color::WHITE,
                    gradient: None,
                    border: None,
                    shadow: None,
                    image: None,
                }],
                data: NodeData::Container(ui_core::tree::ContainerParams::default()),
                size_class: SizeClass {
                    width: AxisSize::fill(0.0, 100.0),
                    height: AxisSize::fixed(40.0),
                    grow_x: Grow::Yes,
                    grow_y: Grow::No,
                },
                ink_margin: Insets::ZERO,
                box_model: Default::default(),
                offset: ui_core::geom::Point::new(0.0, 0.0),
                cursor: None,
                // The bar is the demo's one interactive, keyboard-reachable node.
                // 长条是示例里唯一可交互、可由键盘到达的节点。
                sense: ui_core::Sense::HOVER
                    | ui_core::Sense::CLICK
                    | ui_core::Sense::FOCUSABLE
                    | if draggable {
                        ui_core::Sense::DRAG
                    } else {
                        ui_core::Sense::NONE
                    },
                disabled: false,
                grid: ui_core::GridItem::default(),
                placement: ui_core::layout::Placement::default(),
                env: None,
                children: Vec::new(),
        }
    }

    impl App for Demo {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let mut root = crate::Container::new(Id::str("root"), NodeKind::Column)
                .padding(Insets::all(10.0))
                .gap(8.0)
                .child(Box::new(DemoBar {
                    draggable: self.draggable,
                }));
            if self.expand {
                root = root.child_decl(Decl {
                    id: Id::str("extra"),
                    kind: NodeKind::Box,
                    shapes: vec![ui_core::draw::Shape::Box {
                        corners: ui_core::geom::Corners::ZERO,
                        fill: ui_core::geom::Color::WHITE,
                        gradient: None,
                        border: None,
                        shadow: None,
                        image: None,
                    }],
                    data: NodeData::Container(ui_core::tree::ContainerParams::default()),
                    size_class: SizeClass::fixed(50.0, 30.0),
                    ink_margin: Insets::ZERO,
                    box_model: Default::default(),
                    offset: ui_core::geom::Point::new(0.0, 0.0),
                    cursor: None,
                    // The extra box is Tab-reachable, like the bar.
                    // 额外盒子与长条一样可由 Tab 到达。
                    sense: ui_core::Sense::HOVER
                        | ui_core::Sense::CLICK
                        | ui_core::Sense::FOCUSABLE,
                    disabled: false,
                    grid: ui_core::GridItem::default(),
                    placement: ui_core::layout::Placement::default(),
                    env: None,
                    children: Vec::new(),
                });
            }
            Box::new(root)
        }
    }

    /// An app whose one node accepts text and keeps whatever the engine reports.
    /// 一个应用：唯一节点接受文本，并保存引擎上报的值。
    struct Typing {
        text: String,
        seen: std::rc::Rc<std::cell::RefCell<Vec<String>>>,
    }

    impl App for Typing {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            crate::from_decl(
                Decl::container(Id::str("field"), NodeKind::Row)
                    .size(SizeClass::fixed(100.0, 40.0))
                    .sense(ui_core::Sense::CLICK | ui_core::Sense::FOCUSABLE)
                    .text_input(self.text.clone()),
            )
        }

        fn changed(&mut self, _id: Id, change: ui_core::change::Change) -> bool {
            if let ui_core::change::Change::Text(next) = change {
                self.seen.borrow_mut().push(next.clone());
                self.text = next;
            }
            true
        }
    }

    /// An input whose buffer is drawn by a text child, as every real field does.
    /// 一个输入，其缓冲由文本子节点绘制，与真实字段一致。
    struct Buffered {
        text: String,
        carets: std::rc::Rc<std::cell::RefCell<Vec<Option<f32>>>>,
    }

    impl App for Buffered {
        fn view(&mut self, cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let text_id = Id::str("field").with("text");
            self.carets.borrow_mut().push(cx.caret_in_text_for(text_id));
            let text_node = |id: Id, body: String| Decl {
                id,
                kind: NodeKind::Text,
                shapes: Vec::new(),
                data: NodeData::Text {
                    ink: Color::BLACK,
                    block: ui_core::TextBlock::plain(body, ui_core::TextStyle::new(16.0)),
                    caret: None,
                    selection: None,
                    composing: None,
                    nowrap: true,
                },
                size_class: SizeClass {
                    width: AxisSize::hug(0.0, f32::INFINITY),
                    height: AxisSize::hug(16.0, 24.0),
                    grow_x: Grow::No,
                    grow_y: Grow::No,
                },
                ink_margin: Insets::ZERO,
                box_model: Default::default(),
                offset: ui_core::geom::Point::new(0.0, 0.0),
                cursor: None,
                sense: ui_core::Sense::NONE,
                disabled: false,
                grid: ui_core::GridItem::default(),
                placement: ui_core::layout::Placement::default(),
                env: None,
                children: Vec::new(),
            };
            crate::from_decl(
                Decl::container(Id::str("field"), NodeKind::Row)
                    .size(SizeClass::fixed(100.0, 40.0))
                    .sense(ui_core::Sense::CLICK | ui_core::Sense::FOCUSABLE)
                    .text_input(self.text.clone())
                    .child(text_node(text_id, self.text.clone()))
                    // A decoy text node beside the buffer, as every clear glyph is.
                    // 缓冲旁边的一个诱饵文本节点，每个清除字形都是这样。
                    .child(text_node(Id::str("field").with("clear-glyph"), String::new())),
            )
        }

        fn changed(&mut self, _id: Id, change: ui_core::change::Change) -> bool {
            if let ui_core::change::Change::Text(next) = change {
                self.text = next;
            }
            true
        }
    }

    /// The caret's own colour, chosen so nothing else in these frames can produce it.
    /// 插入符自己的颜色，特意选得让这些帧里别的东西都产生不了它。
    const CARET_INK: Color = Color {
        r: 0.0,
        g: 1.0,
        b: 0.0,
        a: 1.0,
    };

    /// An input that draws its caret itself, so a frame can show whether it is lit.
    /// 一个自己画插入符的输入，帧因此能看出它亮着没有。
    struct Blinking {
        text: String,
    }

    impl App for Blinking {
        fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let text = Decl {
                id: Id::str("field").with("text"),
                kind: NodeKind::Text,
                shapes: Vec::new(),
                data: NodeData::Text {
                    ink: Color::BLACK,
                    block: ui_core::TextBlock::plain(
                        self.text.clone(),
                        ui_core::TextStyle::new(16.0),
                    ),
                    caret: Some(ui_core::Caret {
                        offset: self.text.len(),
                        color: CARET_INK,
                    }),
                    selection: None,
                    composing: None,
                    nowrap: true,
                },
                size_class: SizeClass {
                    width: AxisSize::hug(0.0, f32::INFINITY),
                    height: AxisSize::hug(16.0, 24.0),
                    grow_x: Grow::No,
                    grow_y: Grow::No,
                },
                ink_margin: Insets::ZERO,
                box_model: Default::default(),
                offset: ui_core::geom::Point::new(0.0, 0.0),
                cursor: None,
                sense: ui_core::Sense::NONE,
                disabled: false,
                grid: ui_core::GridItem::default(),
                placement: ui_core::layout::Placement::default(),
                env: None,
                children: Vec::new(),
            };
            crate::from_decl(
                Decl::container(Id::str("field"), NodeKind::Row)
                    .size(SizeClass::fixed(100.0, 40.0))
                    .sense(ui_core::Sense::CLICK | ui_core::Sense::FOCUSABLE)
                    .text_input(self.text.clone())
                    .child(text),
            )
        }

        fn changed(&mut self, _id: Id, change: ui_core::change::Change) -> bool {
            if let ui_core::change::Change::Text(next) = change {
                self.text = next;
            }
            true
        }
    }

    /// Whether the frame that was just built lit the caret.
    /// 刚构建的那一帧是否画出了插入符。
    fn caret_lit(lp: &AppLoop<Blinking>) -> bool {
        lp.resolved.prims.rects.iter().any(|r| r.fill == CARET_INK)
    }

    #[test]
    fn a_caret_blinks_while_an_input_is_edited_and_relights_when_it_moves() {
        // The engine owns the blink, so every field on every design system blinks alike;
        // and a caret that just moved must be lit at once, or typing into it looks dead.
        // 闪烁归引擎，各体系的每个字段因此同步；刚移过的插入符必须立刻是亮的，
        // 否则刚输入时看起来像没反应。
        let mut lp = AppLoop::new(Blinking {
            text: "abc".to_string(),
        });
        let mut target = OffscreenTarget::new(200, 120);
        let pos = ui_core::geom::Point::new(20.0, 20.0);
        lp.frame(&mut target, None);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.frame_with_dt(&mut target, Some(pos), 0.0);
        assert!(caret_lit(&lp), "placing the caret must light it");
        assert!(
            lp.next_wake().is_some(),
            "the lit half must ask to be woken at its end"
        );
        lp.frame_with_dt(&mut target, Some(pos), 0.6);
        assert!(!caret_lit(&lp), "the second half of the cycle is dark");
        assert!(
            lp.next_wake().is_some(),
            "the dark half must ask to be woken too, or it never comes back"
        );
        lp.dispatch(ui_core::Event::Text("d".to_string()));
        lp.frame_with_dt(&mut target, Some(pos), 0.6);
        assert!(caret_lit(&lp), "typing must light the caret again");
    }

    #[test]
    fn the_caret_fact_survives_the_frame_a_keystroke_changes_the_buffer() {
        // The fact is computed before the build, when the tree still holds the old text; a
        // field that scrolls by it must not lose it for that one frame and jump back.
        // 该事实在构建前求值，此时树里仍是旧文字；按它滚动的字段不能在这一帧丢掉它而跳回。
        let carets = std::rc::Rc::new(std::cell::RefCell::new(Vec::new()));
        let mut lp = AppLoop::new(Buffered {
            text: String::new(),
            carets: carets.clone(),
        });
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let pos = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.frame(&mut target, None);
        lp.dispatch(ui_core::Event::Text("overflowing".to_string()));
        lp.frame(&mut target, None);
        let last = *carets.borrow().last().expect("a frame was built");
        assert!(
            last.is_some(),
            "the frame that changed the buffer must still know where the caret is, got {last:?}"
        );
    }

    #[test]
    fn a_click_beside_the_buffer_puts_the_caret_at_its_end() {
        // The clear glyph is a text node too; answering from it would place every click
        // beside the text at the buffer's start.
        // 清除字形同样是文本节点；用它作答会把文字旁的每次点击都放到缓冲开头。
        let carets = std::rc::Rc::new(std::cell::RefCell::new(Vec::new()));
        let mut lp = AppLoop::new(Buffered {
            text: "abc".to_string(),
            carets,
        });
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: ui_core::geom::Point::new(95.0, 20.0),
            button: ui_core::PointerButton::Primary,
        });
        assert_eq!(
            lp.editing,
            Some((Id::str("field"), ui_core::TextSelection::collapsed(3))),
            "a click right of the text lands after its last character"
        );
    }

    #[test]
    fn typing_reaches_the_focused_text_input_as_the_whole_buffer() {
        // Keys only go to a focused input, and the app must receive the whole buffer.
        // 键盘只送往已聚焦的输入，应用收到的必须是完整缓冲。
        let seen = std::rc::Rc::new(std::cell::RefCell::new(Vec::new()));
        let mut lp = AppLoop::new(Typing {
            text: String::new(),
            seen: seen.clone(),
        });
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let pos = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        assert!(
            lp.dispatch(ui_core::Event::Text("hé".to_string())),
            "an edit asks for a repaint"
        );
        lp.frame(&mut target, None);
        assert_eq!(seen.borrow().as_slice(), ["hé"]);
        assert_eq!(
            lp.editing,
            Some((Id::str("field"), ui_core::TextSelection::collapsed(3))),
            "the caret follows the edit"
        );
    }

    /// An app whose field carries a floating label overlay, as every MD3 field does.
    /// 一个带浮动标签悬浮层的字段应用，MD3 字段都是这样。
    struct Labelled;

    impl App for Labelled {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let text = Decl {
                id: Id::str("label-text"),
                kind: NodeKind::Text,
                shapes: Vec::new(),
                data: NodeData::Text {
                    ink: Color::BLACK,
                    block: ui_core::TextBlock::plain("Label", ui_core::TextStyle::new(16.0)),
                    caret: None,
                    selection: None,
                    composing: None,
                    nowrap: false,
                },
                size_class: SizeClass {
                    width: AxisSize::hug(0.0, f32::INFINITY),
                    height: AxisSize::hug(16.0, 24.0),
                    grow_x: Grow::No,
                    grow_y: Grow::No,
                },
                ink_margin: Insets::ZERO,
                box_model: Default::default(),
                offset: ui_core::geom::Point::new(0.0, 0.0),
                cursor: None,
                sense: ui_core::Sense::NONE,
                disabled: false,
                grid: ui_core::GridItem::default(),
                placement: ui_core::layout::Placement::default(),
                env: None,
                children: Vec::new(),
            };
            let label = Decl::container(Id::str("label"), NodeKind::Row)
                .sense(ui_core::Sense::PASS_THROUGH)
                .child(text);
            let layer = Decl::container(Id::str("label-layer"), NodeKind::Overlay)
                .size(SizeClass::fixed(200.0, 40.0))
                .sense(ui_core::Sense::PASS_THROUGH)
                .cross_align(0.0)
                .child(label);
            // The label floats beside the field, as it does in a real text field: it is a
            // sibling overlay, so only pass-through keeps the press on the field.
            // 标签与字段并列浮动，与真实文本字段一致：它是兄弟悬浮层，
            // 只有透传才能让按下落到字段上。
            crate::from_decl(
                Decl::container(Id::str("root"), NodeKind::Column)
                    .size(SizeClass::fixed(200.0, 40.0))
                    .child(
                        Decl::container(Id::str("field"), NodeKind::Row)
                            .size(SizeClass::fixed(200.0, 40.0))
                            .sense(ui_core::Sense::CLICK | ui_core::Sense::FOCUSABLE)
                            .text_input(""),
                    )
                    .child(layer),
            )
        }
    }

    #[test]
    fn a_press_on_a_pass_through_label_still_focuses_the_field_under_it() {
        // The floating label sits on top of the field; a press on it belongs to the field.
        // 浮动标签盖在字段上；点在标签上的按下属于字段。
        let mut lp = AppLoop::new(Labelled);
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let pos = ui_core::geom::Point::new(10.0, 10.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        assert_eq!(
            lp.focused(),
            Some(Id::str("field")),
            "the label must not swallow the press"
        );
    }

    /// One selectable paragraph with `pad` of its own on every side.
    /// 一段自带 `pad` 内边距的可选文本。
    fn paragraph_decl(pad: f32) -> Decl {
        Decl {
            id: Id::str("para"),
            kind: NodeKind::Text,
            shapes: Vec::new(),
            data: NodeData::Text {
                ink: Color::BLACK,
                block: ui_core::TextBlock {
                    runs: vec![ui_core::TextRun::new(
                        "drag across this paragraph to select it",
                        ui_core::TextStyle::new(14.0),
                    )],
                    align: ui_core::TextAlign::Start,
                    max_lines: None,
                    line_gap: 0.0,
                    indent: 0.0,
                    atoms: Vec::new(),
                },
                caret: None,
                selection: None,
                composing: None,
                nowrap: false,
            },
            size_class: SizeClass {
                width: AxisSize::hug(0.0, 600.0),
                height: AxisSize::hug(14.0, 20.0),
                grow_x: Grow::No,
                grow_y: Grow::No,
            },
            ink_margin: Insets::ZERO,
            box_model: ui_core::layout::BoxModel {
                padding: Insets::all(pad),
                ..ui_core::layout::BoxModel::default()
            },
            offset: ui_core::geom::Point::new(0.0, 0.0),
            cursor: None,
            sense: ui_core::Sense::SELECT,
            disabled: false,
            grid: ui_core::GridItem::default(),
            placement: ui_core::layout::Placement::default(),
            env: None,
            children: Vec::new(),
        }
    }

    /// An app whose one node is a selectable paragraph, so a drag has something to select.
    /// 一个只有一段可选文本的应用，让拖拽有东西可选。
    struct Selectable;

    impl App for Selectable {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            crate::from_decl(paragraph_decl(0.0))
        }
    }

    /// The same paragraph with 10pt of its own padding.
    /// 同样的段落，四边各带 10pt 自身内边距。
    struct PaddedSelectable;

    impl App for PaddedSelectable {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            crate::from_decl(paragraph_decl(10.0))
        }
    }

    /// The paragraph painted with whatever selection the engine keeps for it.
    /// 把引擎为它记着的选区画出来的同一段文字。
    struct Painting;

    impl App for Painting {
        fn view(&mut self, f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let id = Id::str("para");
            let selection = f
                .selection_for(id)
                .filter(|s| !s.is_collapsed())
                .map(|s| ui_core::SelectionPrim {
                    range: s.range(),
                    fill: Color::from_rgba8(0, 0, 255, 255),
                    painter: None,
                });
            let mut decl = paragraph_decl(0.0);
            if let NodeData::Text { selection: slot, .. } = &mut decl.data {
                *slot = selection;
            }
            crate::from_decl(decl)
        }
    }

    /// Whether any pixel carries the selection's own blue, which nothing else uses.
    /// 是否有像素用的是选区独有的那种蓝，别处不用。
    fn has_selection_blue(target: &OffscreenTarget) -> bool {
        (0..target.pixels.height)
            .any(|y| (0..target.pixels.width).any(|x| target.pixels.get(x, y) == [0, 0, 255, 255]))
    }

    #[test]
    fn a_drag_across_selectable_text_records_the_range_it_crossed() {
        // The engine owns the selection, not the app: a press plus a move must leave one.
        // 选区归引擎所有而非应用：一次按下加一次移动必须留下一个选区。
        let mut lp = AppLoop::new(Selectable);
        let mut target = OffscreenTarget::new(600, 120);
        lp.frame(&mut target, None);
        let y = 8.0;
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: ui_core::geom::Point::new(1.0, y),
            button: ui_core::PointerButton::Primary,
        });
        assert!(
            lp.dispatch(ui_core::Event::PointerMoved {
                pos: ui_core::geom::Point::new(220.0, y),
            }),
            "extending the selection must ask for a repaint"
        );
        let (id, selection) = lp.selection.expect("the drag left no selection");
        assert_eq!(id, Id::str("para"));
        assert!(
            selection.anchor < selection.caret,
            "a rightward drag must leave anchor before caret, got {selection:?}"
        );
        assert!(!selection.is_collapsed());
    }

    #[test]
    fn a_selection_drag_asks_for_every_frame_it_traverses() {
        // The pointer reports faster than the screen, and a move that changes no hover
        // owner is normally dropped. A selection drag changes what is painted without
        // moving the hover, so dropping it would show the range only when the button
        // came up.
        // 指针上报快于屏幕，不改变悬停所有者的移动通常被丢弃。拖选在悬停不变时改变绘制，
        // 丢掉它高亮就得等松手才出现。
        let mut lp = AppLoop::new(Selectable);
        let mut target = OffscreenTarget::new(600, 120);
        lp.frame(&mut target, Some(ui_core::geom::Point::new(500.0, 100.0)));
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: ui_core::geom::Point::new(1.0, 8.0),
            button: ui_core::PointerButton::Primary,
        });
        assert!(lp.take_dispatched(), "the press itself wants a frame");
        lp.frame(&mut target, Some(ui_core::geom::Point::new(1.0, 8.0)));
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(120.0, 8.0),
        });
        assert!(
            lp.take_dispatched(),
            "the move must want the frame that draws the range it crossed"
        );
        assert!(
            lp.selection.is_some_and(|(_, s)| !s.is_collapsed()),
            "and the range must be the one the move crossed"
        );
    }

    #[test]
    fn a_selection_reaches_the_pixels_on_the_frame_the_move_lands_on() {
        // A drag shows its highlight while the button is held; waiting for the release
        // leaves the whole gesture without feedback.
        // 拖拽在按住期间就要显示高亮；等到松手才画，整个手势都没有反馈。
        let mut lp = AppLoop::new(Painting);
        let mut target = OffscreenTarget::new(600, 120);
        lp.frame(&mut target, None);
        assert!(!has_selection_blue(&target), "nothing is selected before the press");
        let y = 8.0;
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: ui_core::geom::Point::new(1.0, y),
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(220.0, y),
        });
        lp.frame(&mut target, None);
        assert!(
            has_selection_blue(&target),
            "the move must paint the highlight with the button still held"
        );
    }

    #[test]
    fn selectable_text_shows_the_text_cursor_without_the_app_naming_one() {
        // The I-beam is the engine's consequence of selectability; an app declaring the
        // paragraph must not also have to spell out a cursor.
        // 文字光标是可选性的引擎推论；声明该段落的应用不该还要另写一个光标。
        let mut lp = AppLoop::new(Selectable);
        let mut target = OffscreenTarget::new(600, 120);
        let ground = ui_core::geom::Point::new(500.0, 100.0);
        lp.frame(&mut target, Some(ground));
        let over = ui_core::geom::Point::new(50.0, 8.0);
        // Both points belong to the same hover owner, so no pixel changes: without this
        // frame the shape it reaches is never sent and the pointer stays an arrow.
        // 两点属于同一个悬停所有者，因此没有像素变化：少了这一帧，形状永远发不出去，
        // 指针会一直是箭头。
        lp.dispatch(ui_core::Event::PointerMoved { pos: over });
        assert!(
            lp.take_dispatched(),
            "a move that only changes the cursor shape must still ask for a frame"
        );
        let outcome = lp.frame(&mut target, Some(over));
        assert_eq!(
            outcome.cursor,
            ui_core::CursorShape::Text,
            "the pointer over a selectable paragraph must be an I-beam"
        );
    }

    #[test]
    fn a_padded_text_paints_and_takes_clicks_from_its_content_origin() {
        // Padding is the box's, so the line and the caret start inside it; hit testing must
        // subtract the same offset or every press lands ten points into the buffer.
        // 内边距属于盒子，行与插入符都从里面开始；命中必须减掉同一个偏移，
        // 否则每次按下都会落进缓冲十点。
        let mut lp = AppLoop::new(PaddedSelectable);
        let mut target = OffscreenTarget::new(600, 120);
        lp.frame(&mut target, None);
        let prim = lp.list.prims.texts.first().expect("the paragraph painted");
        assert_eq!(
            (prim.origin.x, prim.origin.y),
            (10.0, 10.0),
            "the line starts inside the padding"
        );
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: ui_core::geom::Point::new(12.0, 12.0),
            button: ui_core::PointerButton::Primary,
        });
        assert_eq!(
            lp.selection.map(|(_, s)| s.caret),
            Some(0),
            "a press two points inside the content origin is offset 0"
        );
    }

    #[test]
    fn select_all_reaches_a_read_only_paragraph() {
        // A read-only selection has no input to own it, so the row must not go looking for
        // one: it selects the paragraph the right click landed on.
        // 只读选区没有输入持有它，因此这一行不该去找输入：它选中右键落到的那一段。
        let mut lp = AppLoop::new(Selectable);
        lp.set_text_menu_labels(Some(crate::menu::TextMenuLabels {
            select_all: row_text("Sel all", "Ctrl + A"),
            copy: row_text("Copy", "Ctrl + C"),
            cut: row_text("Cut", "Ctrl + X"),
            paste: row_text("Paste", "Ctrl + V"),
        }));
        let mut target = OffscreenTarget::new(600, 120);
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(60.0, 8.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: at,
            button: ui_core::PointerButton::Secondary,
        });
        let menu = lp.menu.as_ref().expect("selectable text offers a menu");
        let labels: Vec<&str> = menu.items.iter().map(|i| i.label.as_str()).collect();
        assert_eq!(labels, ["Sel all", "Copy"], "a label offers no cut or paste");
        // The entrance shifts the rows while it plays: settle before aiming at one.
        // 开场期间行是移动的：瞄准某一行之前先让它落定。
        lp.frame_with_dt(&mut target, None, 0.30);
        let row = lp.menu.as_ref().expect("still open").rows[0];
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: ui_core::geom::Point::new(
                row.origin.x + row.size.w * 0.5,
                row.origin.y + row.size.h * 0.5,
            ),
            button: ui_core::PointerButton::Primary,
        });
        let len = lp.text_value(Id::str("para")).expect("the paragraph has text").len();
        let (id, sel) = lp.selection.expect("the row left a selection");
        assert_eq!(id, Id::str("para"));
        assert_eq!(sel, ui_core::TextSelection::new(0, len), "the whole paragraph");
    }

    #[test]
    fn typing_replaces_the_selected_range_in_one_edit() {
        // Select-all then a character must produce one whole-buffer edit, not delete+insert.
        // 全选后输入一个字符必须产生一次整缓冲编辑，而不是先删后插。
        let seen = std::rc::Rc::new(std::cell::RefCell::new(Vec::new()));
        let mut lp = AppLoop::new(Typing {
            text: "alpha bravo".to_string(),
            seen: seen.clone(),
        });
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let pos = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers {
            ctrl: true,
            ..Default::default()
        }));
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Char('a'),
        });
        assert_eq!(
            lp.editing,
            Some((Id::str("field"), ui_core::TextSelection::new(0, 11))),
            "Ctrl+A selects the whole buffer"
        );
        lp.dispatch(ui_core::Event::Text("x".to_string()));
        assert_eq!(seen.borrow().as_slice(), ["x"], "one edit, whole buffer");
        assert_eq!(
            lp.editing,
            Some((Id::str("field"), ui_core::TextSelection::collapsed(1)))
        );
    }

    /// The same, with a declared line mode and a log of activations, for the Enter-split tests.
    /// 同上，但带声明的行模式与激活记录，供 Enter 分叉的测试使用。
    struct Editable {
        text: String,
        multiline: bool,
        seen: std::rc::Rc<std::cell::RefCell<Vec<String>>>,
        activated: Vec<Id>,
    }

    impl App for Editable {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            crate::from_decl(
                Decl::container(Id::str("field"), NodeKind::Row)
                    .size(SizeClass::fixed(100.0, 40.0))
                    .sense(ui_core::Sense::CLICK | ui_core::Sense::FOCUSABLE)
                    .text_input(self.text.clone())
                    .text_input_multiline(self.multiline),
            )
        }

        fn changed(&mut self, id: Id, change: ui_core::change::Change) -> bool {
            match change {
                ui_core::change::Change::Text(next) => {
                    self.seen.borrow_mut().push(next.clone());
                    self.text = next;
                }
                ui_core::change::Change::Activated => self.activated.push(id),
                _ => {}
            }
            true
        }
    }

    #[test]
    fn shift_enter_inserts_a_newline_in_a_multiline_input() {
        // The declared multiline intent is what turns the chord into a hard break, reported
        // as one whole-buffer edit like any other insertion.
        // 声明的多行意图才让这个组合键变成强制换行，并像其它插入一样整缓冲上报。
        let seen = std::rc::Rc::new(std::cell::RefCell::new(Vec::new()));
        let mut lp = AppLoop::new(Editable {
            text: "ab".to_string(),
            seen: seen.clone(),
            activated: Vec::new(),
            multiline: true,
        });
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let pos = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        // The caret sits at the end of "ab"; Shift+Enter breaks after it.
        // 插入符停在 "ab" 的末尾；Shift+Enter 在其后换行。
        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers {
            shift: true,
            ..Default::default()
        }));
        assert!(
            lp.dispatch(ui_core::Event::KeyPressed {
                key: ui_core::Key::Enter
            }),
            "a hard break asks for a repaint"
        );
        assert_eq!(seen.borrow().as_slice(), ["ab\n"]);
        assert_eq!(
            lp.editing,
            Some((Id::str("field"), ui_core::TextSelection::collapsed(3))),
            "the caret lands on the new line"
        );
    }

    #[test]
    fn enter_still_activates_inside_a_multiline_input() {
        // Without Shift the chord keeps the existing activation path: no `\n` enters the
        // buffer, and the app hears `Activated`, not a text edit.
        // 不带 Shift 时该组合键走既有的激活路径：缓冲里没有 `\n`，应用收到 `Activated` 而非文本编辑。
        let seen = std::rc::Rc::new(std::cell::RefCell::new(Vec::new()));
        let mut lp = AppLoop::new(Editable {
            text: "ab".to_string(),
            seen: seen.clone(),
            activated: Vec::new(),
            multiline: true,
        });
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let pos = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers::default()));
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Enter,
        });
        // Activation is a frame fact: the frame after the key is what reports it.
        // 激活是随帧的事实：按键之后的那一帧才上报它。
        lp.frame(&mut target, None);
        assert!(
            seen.borrow().is_empty(),
            "activation must not report a buffer: {:?}",
            seen.borrow()
        );
        let activated = lp
            .app_mut()
            .activated
            .iter()
            .any(|id| *id == Id::str("field"));
        assert!(activated, "Enter activates the focused field");
    }

    #[test]
    fn shift_enter_is_ignored_in_a_single_line_input() {
        // The leak this guards: a field that never declared multiline must not gain a `\n`.
        // 本测试防的是漏：从未声明多行的字段不得混进 `\n`。
        let seen = std::rc::Rc::new(std::cell::RefCell::new(Vec::new()));
        let mut lp = AppLoop::new(Editable {
            text: "ab".to_string(),
            seen: seen.clone(),
            activated: Vec::new(),
            multiline: false,
        });
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let pos = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers {
            shift: true,
            ..Default::default()
        }));
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Enter,
        });
        assert!(
            seen.borrow().is_empty(),
            "a single-line field never breaks a line: {:?}",
            seen.borrow()
        );
        assert!(
            !lp.app_mut().text.contains('\n'),
            "the buffer stays free of newlines"
        );
    }

    #[test]
    fn text_events_in_one_batch_each_build_on_the_last_edit() {
        // A batch can carry several keys; each edit must see the previous one's result.
        // 一批里可能带来多个按键；每次编辑都必须看到上一次的结果。
        let seen = std::rc::Rc::new(std::cell::RefCell::new(Vec::new()));
        let mut lp = AppLoop::new(Typing {
            text: String::new(),
            seen: seen.clone(),
        });
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let pos = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        for c in ["a", "b", "c"] {
            lp.dispatch(ui_core::Event::Text(c.to_string()));
        }
        assert_eq!(seen.borrow().as_slice(), ["a", "ab", "abc"]);
    }

    #[test]
    fn shift_extends_the_selection_and_a_plain_arrow_collapses_it() {
        // Shift grows the selection from a fixed anchor; a plain arrow drops it to an edge.
        // Shift 从固定锚点扩展选区；不带 Shift 的方向键把选区收拢到某一端。
        let mut lp = AppLoop::new(Typing {
            text: "abc".to_string(),
            seen: std::rc::Rc::new(std::cell::RefCell::new(Vec::new())),
        });
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let pos = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Home,
        });
        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers {
            shift: true,
            ..Default::default()
        }));
        for _ in 0..2 {
            lp.dispatch(ui_core::Event::KeyPressed {
                key: ui_core::Key::Right,
            });
        }
        assert_eq!(
            lp.editing,
            Some((Id::str("field"), ui_core::TextSelection::new(0, 2)))
        );
        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers::default()));
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Right,
        });
        assert_eq!(
            lp.editing,
            Some((Id::str("field"), ui_core::TextSelection::collapsed(2))),
            "a plain arrow collapses the selection to the edge it moves towards"
        );
    }

    #[test]
    fn ctrl_arrows_move_the_caret_a_word_at_a_time() {
        // Ctrl+arrow is a word step, and the held modifier must reach the editing path.
        // Ctrl+方向键按词步进，且按住的修饰键必须传到编辑路径。
        let mut lp = AppLoop::new(Typing {
            text: "alpha bravo".to_string(),
            seen: std::rc::Rc::new(std::cell::RefCell::new(Vec::new())),
        });
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let pos = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Home,
        });
        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers {
            ctrl: true,
            ..Default::default()
        }));
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Right,
        });
        assert_eq!(
            lp.editing,
            Some((Id::str("field"), ui_core::TextSelection::collapsed(5))),
            "one step lands on the end of the first word"
        );
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Right,
        });
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Left,
        });
        assert_eq!(
            lp.editing,
            Some((Id::str("field"), ui_core::TextSelection::collapsed(6))),
            "the step back lands on the start of the second word"
        );
    }

    #[test]
    fn ctrl_home_goes_to_the_document_start_not_the_line_start() {
        // Home stops at the line; Ctrl+Home reaches the buffer's first byte.
        // Home 停在行首；Ctrl+Home 到达缓冲的首字节。
        let mut lp = AppLoop::new(Typing {
            text: "ab\ncd".to_string(),
            seen: std::rc::Rc::new(std::cell::RefCell::new(Vec::new())),
        });
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let pos = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        // Focus starts at the buffer end; walk to the middle of the second line.
        // 聚焦时插入符在缓冲末尾；走到第二行中间。
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Home,
        });
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Right,
        });
        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers {
            ctrl: true,
            ..Default::default()
        }));
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Home,
        });
        assert_eq!(
            lp.editing,
            Some((Id::str("field"), ui_core::TextSelection::collapsed(0))),
            "Ctrl+Home reaches offset 0, not the second line's start"
        );
    }

    #[test]
    fn a_rebound_word_extend_still_extends_by_word() {
        // A word extend is a table id, so rebinding it moves the chord and the action stays.
        // 按词扩选是表内 id：改绑会移动组合键，而动作不变。
        let mut lp = AppLoop::new(Typing {
            text: "alpha bravo".to_string(),
            seen: std::rc::Rc::new(std::cell::RefCell::new(Vec::new())),
        });
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let pos = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Home,
        });
        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers {
            ctrl: true,
            shift: true,
            ..Default::default()
        }));
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Right,
        });
        let after_one_word = Some((Id::str("field"), ui_core::TextSelection::new(0, 5)));
        assert_eq!(lp.editing, after_one_word);

        lp.rebind_shortcut(
            ui_core::ShortcutId::EXTEND_WORD_RIGHT,
            ui_core::KeyChord::new(
                ui_core::Key::Right,
                ui_core::Modifiers {
                    alt: true,
                    shift: true,
                    ..Default::default()
                },
            ),
        );
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Right,
        });
        assert_eq!(lp.editing, after_one_word, "the old chord no longer responds");

        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers {
            alt: true,
            shift: true,
            ..Default::default()
        }));
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Right,
        });
        assert_eq!(
            lp.editing,
            Some((Id::str("field"), ui_core::TextSelection::new(0, 11))),
            "the new chord still extends by word"
        );
    }

    #[test]
    fn a_chord_resolves_focus_then_the_hit_chain_then_the_app() {
        // Three layers can claim one chord; the order between them is the whole contract.
        // 三层都可能认领同一个组合键；它们之间的先后就是全部契约。
        struct Layered {
            log: Rc<RefCell<Vec<(Option<Id>, &'static str)>>>,
        }

        fn ctrl(c: char) -> ui_core::KeyChord {
            ui_core::KeyChord::new(
                ui_core::Key::Char(c),
                ui_core::Modifiers {
                    ctrl: true,
                    ..ui_core::Modifiers::default()
                },
            )
        }

        impl App for Layered {
            fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
                let box_at = |id: &'static str, sense: ui_core::Sense| {
                    Decl::container(Id::str(id), NodeKind::Row)
                        .size(SizeClass::fixed(80.0, 40.0))
                        .sense(sense)
                        .shortcut(ctrl('k'), ui_core::ShortcutId(if id == "a" { "a.k" } else { "b.k" }))
                };
                crate::from_decl(
                    Decl::container(Id::str("root"), NodeKind::Row)
                        .size(SizeClass::fixed(200.0, 40.0))
                        .gap(20.0)
                        .child(box_at("a", ui_core::Sense::CLICK | ui_core::Sense::FOCUSABLE))
                        .child(box_at("b", ui_core::Sense::CLICK)),
                )
            }

            fn changed(&mut self, id: Id, change: ui_core::change::Change) -> bool {
                if let ui_core::change::Change::Shortcut(shortcut) = change {
                    self.log.borrow_mut().push((Some(id), shortcut.0));
                }
                true
            }

            fn shortcut(&mut self, id: ui_core::ShortcutId) -> bool {
                self.log.borrow_mut().push((None, id.0));
                true
            }
        }

        let log = Rc::new(RefCell::new(Vec::new()));
        let mut lp = AppLoop::new(Layered { log: Rc::clone(&log) });
        lp.bind_shortcut(ctrl('j'), ui_core::ShortcutId("app.j"));
        let mut target = OffscreenTarget::new(200, 60);
        lp.frame(&mut target, None);

        let press = |lp: &mut AppLoop<Layered>, x: f32| {
            lp.dispatch(ui_core::Event::PointerMoved {
                pos: ui_core::geom::Point::new(x, 10.0),
            });
            lp.dispatch(ui_core::Event::PointerPressed {
                pos: ui_core::geom::Point::new(x, 10.0),
                button: ui_core::PointerButton::Primary,
            });
        };
        let chord = |lp: &mut AppLoop<Layered>, c: char| {
            lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers {
                ctrl: true,
                ..ui_core::Modifiers::default()
            }));
            lp.dispatch(ui_core::Event::KeyPressed {
                key: ui_core::Key::Char(c),
            });
        };

        // Focus on `a`, pointer over `b`: the focused node wins over the hit chain.
        // 焦点在 `a`、指针悬在 `b`：聚焦节点胜过命中链。
        press(&mut lp, 40.0);
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(140.0, 10.0),
        });
        chord(&mut lp, 'k');
        assert_eq!(
            log.borrow().last().copied(),
            Some((Some(Id::str("a")), "a.k"))
        );

        // `b` is not focusable, so pressing it drops focus; now the hit chain answers.
        // `b` 不可聚焦，按下它会清掉焦点；此时由命中链应答。
        press(&mut lp, 140.0);
        chord(&mut lp, 'k');
        assert_eq!(
            log.borrow().last().copied(),
            Some((Some(Id::str("b")), "b.k"))
        );

        // No node binds this chord, so the app-level binding is the one that fires.
        // 没有节点绑定此组合键，于是触发的是应用级绑定。
        chord(&mut lp, 'j');
        assert_eq!(log.borrow().last().copied(), Some((None, "app.j")));
    }

    /// One built-in text row's words, as an app supplies them.
    /// 应用提供的一行内建文本行的措辞。
    fn row_text(label: &str, shortcut: &str) -> crate::menu::MenuRowText {
        crate::menu::MenuRowText {
            label: label.to_string(),
            shortcut: Some(shortcut.to_string()),
        }
    }

    #[test]
    fn a_secondary_click_offers_the_text_rows_and_copy_waits_for_a_selection() {
        // The engine's own menu: right-click a field, and the four text rows must be there,
        // with the ones that need a selection greyed until there is one.
        // 引擎自带的菜单：右键字段，四行文本项必须都在，需要选区的项在选中前是灰的。
        struct Field;
        impl App for Field {
            fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
                crate::from_decl(
                    Decl::container(Id::str("field"), NodeKind::Row)
                        .size(SizeClass::fixed(200.0, 40.0))
                        .sense(ui_core::Sense::CLICK | ui_core::Sense::FOCUSABLE)
                        .text_input("alpha"),
                )
            }
        }

        let mut lp = AppLoop::new(Field);
        // The engine contributes no rows until the app names them; these are the app's words.
        // 应用给出措辞之前引擎不添加任何行；下面的字都来自应用。
        lp.set_text_menu_labels(Some(crate::menu::TextMenuLabels {
            select_all: row_text("Sel all", "Ctrl + A"),
            copy: row_text("Copy", "Ctrl + C"),
            cut: row_text("Cut", "Ctrl + X"),
            paste: row_text("Paste", "Ctrl + V"),
        }));
        let mut target = OffscreenTarget::new(300, 200);
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: at,
            button: ui_core::PointerButton::Secondary,
        });
        let menu = lp.menu.as_ref().expect("a text input offers a menu");
        let labels: Vec<&str> = menu.items.iter().map(|i| i.label.as_str()).collect();
        assert_eq!(labels, ["Sel all", "Copy", "Cut", "Paste"]);
        let shortcuts: Vec<Option<&str>> = menu
            .items
            .iter()
            .map(|i| i.shortcut.as_deref())
            .collect();
        assert_eq!(
            shortcuts,
            [Some("Ctrl + A"), Some("Ctrl + C"), Some("Ctrl + X"), Some("Ctrl + V")],
            "each row shows the chord it runs"
        );
        assert!(menu.items[0].enabled, "there is text to select");
        assert!(!menu.items[1].enabled, "nothing is selected yet");

        // Escape dismisses without reporting anything.
        // Escape 关闭菜单且不上报任何东西。
        assert!(lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Escape
        }));
        assert!(lp.menu.is_none());

        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers {
            ctrl: true,
            ..ui_core::Modifiers::default()
        }));
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Char('a'),
        });
        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers::default()));
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: at,
            button: ui_core::PointerButton::Secondary,
        });
        let copy_row = {
            // The entrance shifts the rows while it plays: settle before aiming at one.
            // 开场期间行是移动的：瞄准某一行之前先让它落定。
            lp.frame_with_dt(&mut target, None, 0.30);
            lp.menu.as_ref().expect("reopened").rows[1]
        };
        assert!(lp.menu.as_ref().unwrap().items[1].enabled, "a selection exists");

        lp.dispatch(ui_core::Event::PointerPressed {
            pos: ui_core::geom::Point::new(
                copy_row.origin.x + copy_row.size.w * 0.5,
                copy_row.origin.y + copy_row.size.h * 0.5,
            ),
            button: ui_core::PointerButton::Primary,
        });
        assert_eq!(
            lp.take_clipboard_commands(),
            vec![crate::clipboard::ClipboardCommand::Copy {
                text: "alpha".to_string(),
                kind: crate::clipboard::ClipboardKind::Selection,
            }],
            "picking Copy runs the engine's own action"
        );
        assert!(lp.menu.is_none(), "picking a row closes the menu");
    }

    #[test]
    fn a_secondary_click_inside_a_selection_keeps_it() {
        // Right-clicking a selected paragraph acts on that selection; collapsing it to a
        // caret would grey out the only row worth opening the menu for. A click outside it
        // still moves the caret there.
        // 在已选中的段落上右键作用于该选区；把它收拢成插入符会让菜单里唯一有用的行变灰。
        // 落在选区外的点击仍然把插入符移过去。
        let mut lp = AppLoop::new(Selectable);
        lp.set_text_menu_labels(Some(crate::menu::TextMenuLabels {
            select_all: row_text("Sel all", "Ctrl + A"),
            copy: row_text("Copy", "Ctrl + C"),
            cut: row_text("Cut", "Ctrl + X"),
            paste: row_text("Paste", "Ctrl + V"),
        }));
        let mut target = OffscreenTarget::new(600, 120);
        lp.frame(&mut target, None);
        let y = 8.0;
        let button = ui_core::PointerButton::Primary;
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: ui_core::geom::Point::new(60.0, y),
            button,
        });
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(150.0, y),
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos: ui_core::geom::Point::new(150.0, y),
            button,
        });
        let (node, selected) = lp.selection.expect("the drag left no selection");
        assert!(!selected.is_collapsed());

        // Inside: the menu opens on that selection, and Copy is there to take.
        // 之内：菜单作用于该选区，复制行可以点。
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: ui_core::geom::Point::new(100.0, y),
            button: ui_core::PointerButton::Secondary,
        });
        assert_eq!(
            lp.selection,
            Some((node, selected)),
            "a right click inside the selection must leave it alone"
        );
        let menu = lp.menu.as_ref().expect("a selectable paragraph offers a menu");
        assert!(menu.items[1].enabled, "the kept selection can be copied");

        // Outside: the caret moves there and nothing stays selected.
        // 之外：插入符移到那里，什么都不再选中。
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Escape,
        });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: ui_core::geom::Point::new(2.0, y),
            button: ui_core::PointerButton::Secondary,
        });
        let (_, after) = lp.selection.expect("the caret still lives in the paragraph");
        assert!(after.is_collapsed(), "a click outside the selection drops it");
        assert!(!lp.menu.as_ref().unwrap().items[1].enabled);
    }

    #[test]
    fn a_menu_row_takes_the_pointing_hand_and_the_surface_the_arrow() {
        // The open menu is painted above the tree, so the node under the pointer is not what
        // is being pointed at: a row that can be chosen shows the hand, a dead one the arrow.
        // 打开的菜单画在树之上，指针下的节点并不是被指着的东西：
        // 可选的行显示手形，失效的行显示箭头。
        let mut lp = AppLoop::new(Selectable);
        lp.set_text_menu_labels(Some(crate::menu::TextMenuLabels {
            select_all: row_text("Sel all", "Ctrl + A"),
            copy: row_text("Copy", "Ctrl + C"),
            cut: row_text("Cut", "Ctrl + X"),
            paste: row_text("Paste", "Ctrl + V"),
        }));
        let mut target = OffscreenTarget::new(600, 120);
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(60.0, 8.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: at,
            button: ui_core::PointerButton::Secondary,
        });
        let (live, dead) = {
            // The entrance shifts the rows while it plays: settle before aiming at one.
            // 开场期间行是移动的：瞄准某一行之前先让它落定。
            lp.frame_with_dt(&mut target, None, 0.30);
            let menu = lp.menu.as_ref().expect("a selectable paragraph offers a menu");
            assert!(menu.items[0].enabled && !menu.items[1].enabled);
            (menu.rows[0], menu.rows[1])
        };
        let centre = |r: ui_core::geom::Rect| {
            ui_core::geom::Point::new(
                r.origin.x + r.size.w * 0.5,
                r.origin.y + r.size.h * 0.5,
            )
        };
        let live_at = centre(live);
        lp.dispatch(ui_core::Event::PointerMoved { pos: live_at });
        assert_eq!(
            lp.frame(&mut target, Some(live_at)).cursor,
            ui_core::CursorShape::PointingHand,
            "a row that can be chosen is a control"
        );
        let dead_at = centre(dead);
        lp.dispatch(ui_core::Event::PointerMoved { pos: dead_at });
        assert_eq!(
            lp.frame(&mut target, Some(dead_at)).cursor,
            ui_core::CursorShape::Arrow,
            "a row that cannot be chosen is not"
        );
    }

    #[test]
    fn an_entering_menu_keeps_the_loop_awake_until_it_lands() {
        // The menu is drawn outside the tree, so no widget store reports its motion: without
        // this flag the loop would stop presenting after the frame it opened on.
        // 菜单画在树之外，没有控件存储替它报告运动：少了这一项，
        // 循环在它打开的那一帧之后就不再提交帧。
        let mut lp = AppLoop::new(Selectable);
        lp.set_text_menu_labels(Some(crate::menu::TextMenuLabels {
            select_all: row_text("Sel all", "Ctrl + A"),
            copy: row_text("Copy", "Ctrl + C"),
            cut: row_text("Cut", "Ctrl + X"),
            paste: row_text("Paste", "Ctrl + V"),
        }));
        let mut target = OffscreenTarget::new(600, 120);
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(60.0, 8.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: at,
            button: ui_core::PointerButton::Secondary,
        });
        assert!(lp.menu.is_some(), "the press opened a menu");
        assert!(
            lp.frame_with_dt(&mut target, None, 0.01).animating,
            "the entrance is motion"
        );
        assert!(
            !lp.frame_with_dt(&mut target, None, 0.30).animating,
            "once it lands the loop may rest"
        );
    }

    #[test]
    fn a_menu_opened_after_an_idle_gap_starts_its_entrance_at_the_click() {
        // The engine's clock only moves when a frame is built, and an idle app builds none.
        // Stamping the last frame made the entrance begin in the past, so a right click
        // after any pause painted an already-landed menu: on screen, "it just appears".
        // 引擎时钟只在建帧时前进，而空闲的应用不建帧。盖上上一帧的时间戳会让入场在过去开始，
        // 停顿之后的右键因此第一次被画时菜单就已落定：屏幕上就是"直接出现"。
        let mut lp = AppLoop::new(Selectable);
        lp.set_text_menu_labels(Some(crate::menu::TextMenuLabels {
            select_all: row_text("Sel all", "Ctrl + A"),
            copy: row_text("Copy", "Ctrl + C"),
            cut: row_text("Cut", "Ctrl + X"),
            paste: row_text("Paste", "Ctrl + V"),
        }));
        let mut target = OffscreenTarget::new(600, 120);
        lp.frame(&mut target, None);
        // The user stops touching the app, then right-clicks the paragraph.
        std::thread::sleep(std::time::Duration::from_millis(250));
        let at = ui_core::geom::Point::new(60.0, 8.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: at,
            button: ui_core::PointerButton::Secondary,
        });
        let menu = lp.menu.as_ref().expect("the press opened a menu");
        let (presence, _) = menu.entrance(lp.clock.live());
        assert!(
            presence < 0.5,
            "the entrance must still be near its start, got {presence}"
        );
    }

    #[test]
    fn selectable_text_takes_the_text_cursor_without_a_declaration() {
        // The engine is what makes the paragraph selectable, so the I-beam is its answer
        // too: an app marking `Sense::SELECT` must not also have to name a pointer shape.
        // 让段落可选中的是引擎，文字光标因此也是它的回答：
        // 只标了 `Sense::SELECT` 的应用不必再指明指针形状。
        let mut target = OffscreenTarget::new(600, 120);
        let mut lp = AppLoop::new(Selectable);
        let out = lp.frame(&mut target, Some(ui_core::geom::Point::new(20.0, 8.0)));
        assert_eq!(out.cursor, ui_core::CursorShape::Text);
        // Off the paragraph there is nothing to select, so the pointer stays an arrow.
        // 离开段落就没有可选的东西，指针仍是箭头。
        let out = lp.frame(&mut target, Some(ui_core::geom::Point::new(500.0, 100.0)));
        assert_eq!(out.cursor, ui_core::CursorShape::Arrow);
    }

    #[test]
    fn a_copy_cut_and_paste_round_trip_through_the_clipboard_queue() {
        // Copy, cut and paste are one path: the engine names the text, the host does the
        // round trip, and the answer comes back as `Paste`.
        // 复制、剪切、粘贴是同一条路：引擎给出文本，宿主做往返，答案以 `Paste` 回来。
        use crate::clipboard::{ClipboardCommand, ClipboardKind};
        let seen = std::rc::Rc::new(std::cell::RefCell::new(Vec::new()));
        let mut lp = AppLoop::new(Typing {
            text: "alpha".to_string(),
            seen: seen.clone(),
        });
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let pos = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Home,
        });
        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers {
            shift: true,
            ..Default::default()
        }));
        for _ in 0..2 {
            lp.dispatch(ui_core::Event::KeyPressed {
                key: ui_core::Key::Right,
            });
        }
        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers {
            ctrl: true,
            ..Default::default()
        }));
        let copy = ClipboardCommand::Copy {
            text: "al".to_string(),
            kind: ClipboardKind::Selection,
        };
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Char('c'),
        });
        assert_eq!(lp.take_clipboard_commands(), vec![copy.clone()]);
        assert_eq!(lp.editing.map(|(_, sel)| sel), Some(ui_core::TextSelection::new(0, 2)));

        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Char('x'),
        });
        assert_eq!(lp.take_clipboard_commands(), vec![copy]);
        assert_eq!(
            seen.borrow().last().map(String::as_str),
            Some("pha"),
            "a cut removes the selection from the buffer"
        );

        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Char('v'),
        });
        assert_eq!(
            lp.take_clipboard_commands(),
            vec![ClipboardCommand::RequestPaste { kind: ClipboardKind::Selection }],
            "the engine asks for the text instead of reading it"
        );
        lp.dispatch(ui_core::Event::Paste("al".to_string()));
        assert_eq!(
            seen.borrow().last().map(String::as_str),
            Some("alpha"),
            "the paste lands at the caret"
        );
        // Releasing Ctrl is its own event; without it the platform would still be holding it.
        // 松开 Ctrl 是单独的一条事件；没有它，平台仍认为它按着。
        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers::default()));
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::End,
        });
        lp.dispatch(ui_core::Event::Paste("\r\nb".to_string()));
        assert_eq!(
            seen.borrow().last().map(String::as_str),
            Some("alpha b"),
            "a line break flattens to a space: this input is one line"
        );
    }

    #[test]
    fn composing_text_does_not_reach_the_app_until_it_commits() {
        // The preedit belongs to the engine: the app sees one edit, at commit time.
        // 预编辑串归引擎所有：应用只在提交时看到一次编辑。
        let seen = std::rc::Rc::new(std::cell::RefCell::new(Vec::new()));
        let mut lp = AppLoop::new(Typing {
            text: String::new(),
            seen: seen.clone(),
        });
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let pos = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos,
            button: ui_core::PointerButton::Primary,
        });
        let preedit = ui_core::Preedit::new("にほ", 6);
        assert!(
            lp.dispatch(ui_core::Event::Preedit(Some(preedit.clone()))),
            "a composition change asks for a repaint"
        );
        assert_eq!(
            lp.preedit,
            Some((Id::str("field"), preedit)),
            "the engine holds the composition"
        );
        assert!(
            seen.borrow().is_empty(),
            "the app must not see composing text"
        );
        lp.dispatch(ui_core::Event::Text("日本".to_string()));
        assert_eq!(seen.borrow().as_slice(), ["日本"], "one edit, at commit");
        assert_eq!(lp.preedit, None, "a commit ends the composition");
        assert_eq!(
            lp.editing,
            Some((Id::str("field"), ui_core::TextSelection::collapsed(6)))
        );
    }

    #[test]
    fn first_frame_reports_full_damage() {
        let mut target = OffscreenTarget::new(200, 120);
        let outcomes = run_app(
            Demo {
            expand: false,
            draggable: true,
        },
            &mut target,
            1,
            None,
        );
        assert!(outcomes[0].damage.is_full());
        assert_eq!(outcomes[0].nodes, 2, "root + bar");
    }

    /// One box whose only painter is an explicit shadow, translated by `step` when asked.
    /// 一个只画显式阴影的盒子，按需平移 `step`。
    struct Shadowed {
        step: std::rc::Rc<std::cell::Cell<f32>>,
    }

    impl App for Shadowed {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            crate::from_decl(
                Decl::container(Id::str("shadowed"), NodeKind::Box)
                    .size(SizeClass::fixed(60.0, 40.0))
                    .shapes(vec![
                        // Both producers of a shadow prim: a box's own elevation and an
                        // explicit shape.
                        // 阴影图元的两条来路：盒子自身的立面，与显式形状。
                        ui_core::draw::Shape::Box {
                            corners: Corners::ZERO,
                            fill: Color::WHITE,
                            gradient: None,
                            border: None,
                            shadow: Some(ui_core::tree::ShadowSpec {
                                colour: Color::from_rgba8(0, 0, 0, 120),
                                blur: 8.0,
                                spread: 2.0,
                                dy: 3.0,
                            }),
                            image: None,
                        },
                        ui_core::draw::Shape::Shadow {
                            rect: Rect::new(0.0, 0.0, 60.0, 40.0),
                            corners: Corners::ZERO,
                            colour: Color::from_rgba8(0, 0, 0, 120),
                            blur: 8.0,
                            dy: 3.0,
                            ring: 0.0,
                        },
                    ])
                    .offset(self.step.get(), 0.0),
            )
        }
    }

    #[test]
    fn a_moved_shadow_damages_every_pixel_it_paints() {
        let step = std::rc::Rc::new(std::cell::Cell::new(0.0f32));
        let mut lp = AppLoop::new(Shadowed { step: step.clone() });
        let mut target = OffscreenTarget::new(200, 160);
        let _ = lp.frame(&mut target, None);
        step.set(4.0);
        let moved = lp.frame(&mut target, None);
        println!("moved damage: {:?}", moved.damage);
        // `blur * 1.5 + |dy|` past the box, plus the box's own 2dp spread: a 4dp move must
        // claim that whole ring in both positions, not just the box.
        // 盒子外 `blur × 1.5 + |dy|`，再加上盒子自身的 2dp spread：平移 4dp 必须标脏
        // 两个位置上的整圈，而不只是盒子。
        let union = moved
            .damage
            .rects(Rect::new(0.0, 0.0, 200.0, 160.0))
            .into_iter()
            .reduce(|a, b| a.union(b))
            .expect("damage for a moved shadow");
        assert_eq!(union, Rect::new(-17.0, -17.0, 98.0, 74.0));
    }

    #[test]
    fn unchanged_second_frame_produces_no_damage() {
        let mut target = OffscreenTarget::new(200, 120);
        let outcomes = run_app(
            Demo {
            expand: false,
            draggable: true,
        },
            &mut target,
            2,
            None,
        );
        assert!(
            outcomes[1].damage.is_none(),
            "a frame with identical declarations must not repaint, got {:?}",
            outcomes[1].damage
        );
    }

    /// One box whose group opacity the app owns, outside any animation.
    /// 一个盒子，其组不透明度由应用直接改变，不经过动画。
    struct GroupFade {
        alpha: f32,
    }

    impl App for GroupFade {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let decl = Decl::container(Id::str("fade"), NodeKind::Box)
                .size(SizeClass::fixed(60.0, 40.0))
                .background(Color::WHITE, Corners::ZERO)
                .opacity(self.alpha);
            Box::new(crate::from_decl(decl))
        }
    }

    #[test]
    fn a_group_layers_opacity_damages_its_area_when_it_changes() {
        // Opacity lives on the layer, not on any primitive: a fingerprint comparison that
        // only reads primitives leaves the frame unrepainted after the change.
        // 不透明度属于层而不属于任何图元：只读图元的指纹比较会让这一帧不重绘。
        let mut target = OffscreenTarget::new(200, 120);
        let mut lp = AppLoop::new(GroupFade { alpha: 0.5 });
        lp.frame(&mut target, None);
        lp.app_mut().alpha = 0.75;
        let out = lp.frame(&mut target, None);
        assert!(
            !out.damage.is_none(),
            "a layer opacity change must damage, got {:?}",
            out.damage
        );
        let settled = lp.frame(&mut target, None);
        assert!(
            settled.damage.is_none(),
            "an unchanged layer must not repaint, got {:?}",
            settled.damage
        );
    }

    #[test]
    fn adding_a_node_damages_the_new_area() {
        let mut target = OffscreenTarget::new(200, 120);
        let mut lp = AppLoop::new(Demo {
            expand: false,
            draggable: true,
        });
        lp.frame(&mut target, None);
        lp.app_mut().expand = true;
        let out = lp.frame(&mut target, None);
        assert!(!out.damage.is_none(), "adding a child must damage");
        assert_eq!(out.nodes, 3);
    }

    #[test]
    fn hit_test_finds_the_box_under_the_pointer() {
        let mut target = OffscreenTarget::new(200, 120);
        let mut lp = AppLoop::new(Demo {
            expand: false,
            draggable: true,
        });
        // Bar occupies y = 10..50 inside the padded root.
        // 条形位于带内边距的根内 y = 10..50。
        let out = lp.frame(&mut target, Some(ui_core::geom::Point::new(50.0, 30.0)));
        assert_eq!(out.hit, Some(Id::str("bar")));

        let out_miss = lp.frame(&mut target, Some(ui_core::geom::Point::new(50.0, 100.0)));
        assert_ne!(out_miss.hit, Some(Id::str("bar")));
    }

    #[test]
    fn dispatch_moves_the_hover_between_nodes() {
        let mut target = OffscreenTarget::new(200, 120);
        let mut lp = AppLoop::new(Demo {
            expand: false,
            draggable: true,
        });
        // One frame first: input hit-tests against a laid-out tree.
        // 先跑一帧：输入要对着已布局的树做命中测试。
        lp.frame(&mut target, None);
        assert_eq!(lp.hovered(), None, "nothing is hovered before the pointer arrives");

        let on_bar = ui_core::geom::Point::new(50.0, 30.0);
        assert!(
            lp.dispatch(ui_core::Event::PointerMoved { pos: on_bar }),
            "entering a node must ask for a repaint"
        );
        assert_eq!(lp.hovered(), Some(Id::str("bar")));

        let off = ui_core::geom::Point::new(50.0, 100.0);
        assert!(lp.dispatch(ui_core::Event::PointerMoved { pos: off }));
        assert_ne!(lp.hovered(), Some(Id::str("bar")));
    }

    /// An app whose background opacity follows an animated value.
    /// 背景不透明度跟随动画值的 app。
    struct Fading {
        target: f32,
    }

    impl App for Fading {
        fn view(&mut self, f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let decl = {
            // The app animates through the context; it owns no store of its own.
            // app 通过上下文做动画，自己不再拥有存储。
            let a = f.animate(
                Id::str("fade"),
                self.target,
                ui_core::AnimSpec::new(0.1, ui_core::Easing::Linear),
            );
            Decl::container(Id::str("fade"), NodeKind::Column)
                .size(ui_core::layout::SizeClass::fixed(50.0, 50.0))
                .background(
                    Color::from_rgba8(200, 60, 60, (a.clamp(0.0, 1.0) * 255.0) as u8),
                    Corners::ZERO,
                )
        };
    crate::from_decl(decl)
}
}

    #[test]
    fn an_animating_frame_dirties_the_node_it_moves() {
        // The contract that makes animation visible: a frame whose value changed must
        // carry damage for that node, or the new value never reaches the screen.
        // 让动画可见的契约：值变化的那一帧必须为该节点带上脏区，
        // 否则新值永远上不了屏。
        let mut target = OffscreenTarget::new(120, 120);
        let mut lp = AppLoop::new(Fading { target: 0.0 });
        // Settle at 0 first.
        // 先落在 0。
        lp.frame(&mut target, None);
        lp.app_mut().target = 1.0;
        // The retarget happens inside `view`, and time advances *before* `view`, so the
        // value first moves on the following frame.
        // 重定向发生在 `view` 内，而时间在 `view` **之前**推进，
        // 因此值要到下一帧才第一次移动。
        lp.frame_with_dt(&mut target, None, 0.03);

        let mid = lp.frame_with_dt(&mut target, None, 0.03);
        assert!(
            !mid.damage.is_none(),
            "a frame that moved a value must carry damage"
        );
        assert!(mid.animating, "the animation is still in flight");
    }

    /// Counts presents, so a test can ask whether a frame handed anything over.
    /// 统计提交次数，测试据此判断本帧有没有交付画面。
    struct CountingTarget {
        inner: OffscreenTarget,
        presents: u32,
    }

    impl CountingTarget {
        fn new(width: u32, height: u32) -> Self {
            Self {
                inner: OffscreenTarget::new(width, height),
                presents: 0,
            }
        }
    }

    impl PresentTarget for CountingTarget {
        fn kind(&self) -> crate::present::SurfaceKind {
            self.inner.kind()
        }
        fn size(&self) -> (u32, u32) {
            self.inner.size()
        }
        fn pixels_mut(&mut self) -> &mut ui_paint::Pixels {
            self.inner.pixels_mut()
        }
        fn present(&mut self, _damage: &Damage) -> Result<(), String> {
            self.presents += 1;
            Ok(())
        }
    }

    /// Fades a box, but only after a delay, so a frame can be mid-animation and still.
    /// 延迟后才淡入一个盒子，使某一帧处在动画中却什么都没动。
    struct Delayed {
        target: f32,
    }

    impl App for Delayed {
        fn view(&mut self, f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let spec = ui_core::AnimSpec {
                delay: 0.05,
                ..ui_core::AnimSpec::new(0.1, ui_core::Easing::Linear)
            };
            let a = f.animate(Id::str("late"), self.target, spec);
            crate::from_decl(
                Decl::container(Id::str("late"), NodeKind::Column)
                    .size(ui_core::layout::SizeClass::fixed(50.0, 50.0))
                    .background(
                        Color::from_rgba8(200, 60, 60, (a.clamp(0.0, 1.0) * 255.0) as u8),
                        Corners::ZERO,
                    ),
            )
        }
    }

    #[test]
    fn an_animating_frame_presents_even_when_nothing_changed_yet() {
        // The loop waits on input for a frame that hands it nothing; an animation whose
        // first frame moves no pixel would then stall until unrelated input arrived.
        // 循环对「无事可做」的帧等输入；动画首帧若不动像素，就会卡到下一次无关输入。
        let mut target = CountingTarget::new(120, 120);
        let mut lp = AppLoop::new(Delayed { target: 0.0 });
        lp.frame(&mut target, None);

        lp.app_mut().target = 1.0;
        let before = target.presents;
        // Still inside the delay: the value is pinned, so the frame draws the same pixels.
        // 仍在延迟内：值被钉住，因此这一帧画出的像素与上一帧相同。
        let out = lp.frame_with_dt(&mut target, None, 0.01);
        assert!(out.damage.is_none(), "nothing has moved yet");
        assert!(out.animating, "a pending delay is still motion");
        assert_eq!(
            target.presents,
            before + 1,
            "an animating frame must present so the loop gets a frame callback"
        );
    }

    /// Counts scene presents and can claim to owe a commit, like a window with pending IME.
    /// 统计场景提交次数，并可声称欠一次提交，模拟有待发输入法状态的窗口。
    struct CountingScene {
        presents: u32,
        pending: bool,
    }

    impl crate::present::SceneTarget for CountingScene {
        fn size(&self) -> (u32, u32) {
            (120, 120)
        }
        fn present_scene(
            &mut self,
            _scene: &ui_core::draw::DrawList,
            _text: &TextPass,
            _damage: &Damage,
        ) -> Result<crate::present::PresentStats, String> {
            self.presents += 1;
            Ok(crate::present::PresentStats::default())
        }
        fn commit_pending(&self) -> bool {
            self.pending
        }
    }

    /// The same box every frame, so only the commit rule decides what gets presented.
    /// 每帧都是同一个盒子，于是只有提交规则决定交付什么。
    struct Still;

    impl App for Still {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            crate::from_decl(
                Decl::container(Id::str("still"), NodeKind::Column)
                    .size(ui_core::layout::SizeClass::fixed(50.0, 50.0)),
            )
        }
    }

    #[test]
    fn a_scene_frame_presents_only_when_it_has_something_to_carry() {
        // Handing over a still frame costs a commit per callback, but skipping one that
        // carries pending IME state leaves the compositor's copy stale.
        // 交付静止帧等于每个回调都提交一次；而跳过带待发输入法状态的那帧，会让合成器留着旧副本。
        let mut target = CountingScene {
            presents: 0,
            pending: false,
        };
        let mut lp = AppLoop::new(Still);
        let first = lp.frame_scene(&mut target, None).expect("scene frame");
        assert!(first.presented.is_some(), "the first frame has content to show");
        let still = lp.frame_scene(&mut target, None).expect("scene frame");
        assert!(
            still.presented.is_none(),
            "a still frame hands nothing over"
        );
        target.pending = true;
        let owed = lp.frame_scene(&mut target, None).expect("scene frame");
        assert!(
            owed.presented.is_some(),
            "a pending commit must be carried even with nothing to draw"
        );
    }

    /// A card with an opaque child box and a text label, like the demo's card.
    /// 带不透明子盒与文本标签的卡片，与样例程序的结构相同。
    struct Card {
        seen: Vec<Option<Id>>,
    }

    impl App for Card {
        fn view(&mut self, info: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let decl = {
            self.seen.push(info.hovered());
            Decl::container(Id::str("card"), NodeKind::Column)
                .size(ui_core::layout::SizeClass::fixed(120.0, 120.0))
                .padding(ui_core::geom::Insets::all(10.0))
                // Both subscribe to hover: the card to fade, the inner box to be the
                // topmost answer. Nothing else in this app asks to be hovered.
                // 两者都订阅悬停：卡片用于淡入，内层盒子用于成为最上层的答案。
                .sense(ui_core::Sense::HOVER)
                .child(
                    Decl::container(Id::str("inner"), NodeKind::Column)
                        .size(ui_core::layout::SizeClass::fixed(60.0, 60.0))
                        .sense(ui_core::Sense::HOVER)
                        .background(Color::from_rgba8(10, 200, 10, 255), Corners::ZERO),
                )
                .child(Decl {
                    id: Id::str("label"),
                    kind: NodeKind::Text,
                    shapes: Vec::new(),
                    data: NodeData::Text {
                        ink: ui_core::geom::Color::WHITE,
                        block: ui_core::TextBlock::plain(
                            "hi",
                            ui_core::TextStyle::new(12.0),
                        ),
                        caret: None,
                        selection: None,
                        composing: None,
                        nowrap: false,
                    },
                    size_class: ui_core::layout::SizeClass::fixed(40.0, 20.0),
                    ink_margin: ui_core::geom::Insets::ZERO,
                    box_model: Default::default(),
                    offset: ui_core::geom::Point::new(0.0, 0.0),
                    cursor: None,
                    sense: ui_core::Sense::NONE,
                    disabled: false,
            grid: ui_core::GridItem::default(),
            placement: ui_core::layout::Placement::default(),
            env: None,
                    children: Vec::new(),
                })
        };
    crate::from_decl(decl)
}
}

    /// Records drag events and accepts drops on a zone that contains a child.
    /// 记录拖拽事件，并在一个含子节点的区域上接受放下。
    struct Dragging {
        seen: Vec<(Id, ui_core::change::Change)>,
        /// Whether the declaration subscribes to drags; the only routing input.
        /// 声明是否订阅拖拽；这是唯一的路由输入。
        declare_in_tree: bool,
    }

    impl App for Dragging {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let decl = {
            let declared = self.declare_in_tree;
            Decl::container(Id::str("root"), NodeKind::Column)
                .size(ui_core::layout::SizeClass::fixed(200.0, 200.0))
                .child(
                    Decl::container(Id::str("source"), NodeKind::Column)
                        .size(ui_core::layout::SizeClass::fixed(60.0, 60.0))
                        .background(Color::from_rgba8(200, 40, 40, 255), Corners::ZERO)
                        // One subscription expression: the drag bit is one of them, and a
                        // focusable node is what a press may move focus to.
                        // 一条订阅表达式：拖拽位是其中之一，而按下只能把焦点移给可聚焦节点。
                        .sense(ui_core::Sense::HOVER | ui_core::Sense::FOCUSABLE | if declared {
                            ui_core::Sense::DRAG
                        } else {
                            ui_core::Sense::NONE
                        }),
                )
                .child(
                    Decl::container(Id::str("zone"), NodeKind::Column)
                        .size(ui_core::layout::SizeClass::fixed(120.0, 80.0))
                        .background(Color::from_rgba8(40, 200, 40, 255), Corners::ZERO)
                        // One subscription expression: a later `sense` replaces, it does not add.
                        // 用一条订阅表达式：后写的 `sense` 是替换而不是追加。
                        .sense(if declared {
                            ui_core::Sense::DRAG | ui_core::Sense::DROP
                        } else {
                            ui_core::Sense::NONE
                        })
                        .child(
                            Decl::container(Id::str("inner"), NodeKind::Column)
                                .size(ui_core::layout::SizeClass::fixed(40.0, 30.0))
                                .background(Color::from_rgba8(40, 40, 200, 255), Corners::ZERO),
                        ),
                )
        };
    crate::from_decl(decl)
}
        fn changed(&mut self, id: Id, change: ui_core::change::Change) -> bool {
            // Only drag transitions count as "a drag happened"; a click is not one.
            // 只有拖拽转变算「发生了拖拽」；点击不算。
            if matches!(
                change,
                ui_core::change::Change::DragStarted
                    | ui_core::change::Change::Moved { .. }
                    | ui_core::change::Change::Dropped(_)
                    | ui_core::change::Change::Cancelled
            ) {
                self.seen.push((id, change));
            }
            true
        }
    }

    fn drag_demo() -> AppLoop<Dragging> {
        AppLoop::new(Dragging {
            seen: Vec::new(),
            declare_in_tree: true,
        })
    }

    #[test]
    fn a_node_declared_draggable_starts_a_drag_without_any_app_hook() {
        // The declaration alone must be enough: `Decl::draggable` is the single source of
        // truth, and an app that never implements `App::draggable` still gets drags.
        // 仅有声明就该够：`Decl::draggable` 是唯一真相源，没实现 `App::draggable` 的 app 也该能拖。
        let mut target = OffscreenTarget::new(220, 220);
        let mut lp = AppLoop::new(Dragging {
            seen: Vec::new(),
            declare_in_tree: true,
        });
        lp.frame(&mut target, None);
        let from = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: from });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: from,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(50.0, 20.0),
        });
        let started = lp.app_mut().seen.first().map(|(id, _)| *id);
        assert_eq!(
            started,
            Some(Id::str("source")),
            "the declaration alone must reach the app as a change"
        );
    }

    #[test]
    fn an_undeclared_node_starts_no_drag_even_though_its_parent_is_declared() {
        // Withdrawing the declaration must withdraw the gesture, otherwise a "can drag"
        // flag could never be turned off at runtime.
        // 撤掉声明就必须撤掉手势，否则「可拖」标记在运行时永远关不掉。
        let mut target = OffscreenTarget::new(220, 220);
        let mut lp = AppLoop::new(Dragging {
            seen: Vec::new(),
            declare_in_tree: false,
        });
        lp.frame(&mut target, None);
        let from = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: from });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: from,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(50.0, 20.0),
        });
        assert!(
            lp.app_mut().seen.is_empty(),
            "no declaration, no drag: got {:?}",
            lp.app_mut().seen
        );
    }

    #[test]
    fn pressing_a_child_of_a_draggable_container_drags_the_container() {
        // The same trap as hover: the pressed node is the topmost child, so without an
        // ancestor walk the gesture would belong to a node the app never marked.
        // 与悬停同一个坑：被按下的节点是最上层子节点，
        // 不做祖先上溯的话手势会属于一个 app 从未标记的节点。
        let mut target = OffscreenTarget::new(220, 220);
        let mut lp = drag_demo();
        lp.frame(&mut target, None);
        // Press the zone's inner child (topmost), which is *not* marked draggable.
        // 按在放置区的内层子节点上（最上层），它**没有**被标记为可拖拽。
        let from = ui_core::geom::Point::new(20.0, 70.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: from });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: from,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(50.0, 70.0),
        });
        let started = lp.app_mut().seen.first().map(|(id, _)| *id);
        assert_eq!(
            started,
            Some(Id::str("zone")),
            "the drag must belong to the draggable ancestor"
        );
    }

    #[test]
    fn a_shaky_click_reports_no_drag_at_all() {
        // The click path already ran; a stray `Started` would also move the node.
        // 点击路径已经执行过；多出来的 `Started` 会顺带移动节点。
        let mut target = OffscreenTarget::new(220, 220);
        let mut lp = drag_demo();
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: at,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(21.0, 21.0),
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos: at,
            button: ui_core::PointerButton::Primary,
        });
        assert!(lp.app_mut().seen.is_empty(), "a click is not a drag");
    }

    #[test]
    fn a_drag_keeps_reporting_after_the_pointer_leaves_the_source() {
        // Pointer capture: without it, dragging out of the widget silently ends the
        // gesture and the app is left mid-move.
        // 指针捕获：没有它，拖出控件会让手势静默结束，app 停在移动中途。
        let mut target = OffscreenTarget::new(220, 220);
        let mut lp = drag_demo();
        lp.frame(&mut target, None);
        let from = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: from });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: from,
            button: ui_core::PointerButton::Primary,
        });
        // The first move past the threshold reports `Started`; a second one, well
        // outside the 60x60 source, must still report `Moved`.
        // 第一次越过阈值报告 `Started`；第二次远在 60x60 源之外，仍须报告 `Moved`。
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(40.0, 40.0),
        });
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(150.0, 120.0),
        });
        let moved = lp
            .app_mut()
            .seen
            .iter()
            .any(|(_, c)| matches!(c, ui_core::change::Change::Moved { .. }));
        assert!(moved, "a captured drag must keep reporting moves");
    }

    #[test]
    fn a_drop_over_a_child_reports_the_zone_that_accepts_it() {
        // The drop zone's own children are on top; without walking up, the drop would
        // land on a child that accepts nothing and the drag would be lost.
        // 放置区自己的子节点在上面；不上溯的话放下会落在不接受任何东西的子节点上，
        // 拖拽就丢了。
        let mut target = OffscreenTarget::new(220, 220);
        let mut lp = drag_demo();
        lp.frame(&mut target, None);
        let from = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: from });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: from,
            button: ui_core::PointerButton::Primary,
        });
        // Start the drag, then release over the zone's inner child.
        // 先开始拖拽，再在放置区的内层子节点上松开。
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(40.0, 40.0),
        });
        let over_child = ui_core::geom::Point::new(20.0, 70.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: over_child });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos: over_child,
            button: ui_core::PointerButton::Primary,
        });
        let dropped = lp
            .app_mut()
            .seen
            .iter()
            .find_map(|(_, c)| match c {
                ui_core::change::Change::Dropped(over) => *over,
                _ => None,
            })
            .expect("a drop was reported");
        assert_eq!(
            dropped,
            Id::str("zone"),
            "the drop must resolve to the zone, not its child"
        );
    }

    #[test]
    fn escape_cancels_a_drag_and_keeps_the_focus() {
        // Two independent facts: the app is told it was cancelled, and Escape does not
        // also clear focus, which would lose the user's place.
        // 两件独立的事：app 被告知已取消；Escape 没有顺带清掉焦点，否则用户会丢失位置。
        let mut target = OffscreenTarget::new(220, 220);
        let mut lp = drag_demo();
        lp.frame(&mut target, None);
        let from = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: from });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: from,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(60.0, 60.0),
        });
        assert_eq!(lp.focused(), Some(Id::str("source")));

        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Escape,
        });
        let cancelled = lp
            .app_mut()
            .seen
            .iter()
            .any(|(_, c)| matches!(c, ui_core::change::Change::Cancelled));
        assert!(cancelled, "the app must learn the drag was cancelled");
        assert_eq!(
            lp.focused(),
            Some(Id::str("source")),
            "cancelling a drag must not drop focus"
        );
    }

    /// A red block offset by `dx`, with a green sibling that must not move.
    /// 一个按 `dx` 偏移的红块，以及一个不应移动的绿色兄弟。
    struct Offset {
        dx: f32,
    }

    impl App for Offset {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let decl = {
            Decl::container(Id::str("root"), NodeKind::Column)
                .size(ui_core::layout::SizeClass::fixed(200.0, 200.0))
                .child(
                    Decl::container(Id::str("mover"), NodeKind::Column)
                        .size(ui_core::layout::SizeClass::fixed(40.0, 40.0))
                        .sense(ui_core::Sense::HOVER)
                        .offset(self.dx, 0.0)
                        .background(Color::from_rgba8(255, 0, 0, 255), Corners::ZERO),
                )
                .child(
                    Decl::container(Id::str("stay"), NodeKind::Column)
                        .size(ui_core::layout::SizeClass::fixed(40.0, 40.0))
                        .background(Color::from_rgba8(0, 255, 0, 255), Corners::ZERO),
                )
        };
    crate::from_decl(decl)
}
}

    #[test]
    fn an_offset_moves_the_pixels_without_moving_the_layout() {
        // The whole point of a paint offset: the dragged node moves, its siblings stay
        // put, and the layout is not recomputed.
        // 绘制偏移的全部意义：被拖的节点移动、兄弟不动、布局不重算。
        let sample = |dx: f32| {
            let mut target = OffscreenTarget::new(200, 200);
            let mut lp = AppLoop::new(Offset { dx });
            lp.frame(&mut target, None);
            // (60,20) is empty until the block moves there; (20,60) is the green
            // sibling's territory and must never change.
            // (60,20) 在色块移过去之前是空的；(20,60) 属于绿色兄弟，永远不该变。
            let moved = target.pixels.get(60, 20);
            let stay = target.pixels.get(20, 60);
            (moved, stay)
        };
        let (before_moved, before_stay) = sample(0.0);
        let (after_moved, after_stay) = sample(50.0);
        assert_ne!(
            before_moved, after_moved,
            "the offset must move the block's pixels"
        );
        assert_eq!(
            before_stay, after_stay,
            "the sibling must not move: an offset is not a relayout"
        );
    }

    #[test]
    fn a_changed_offset_is_picked_up_without_compounding() {
        // An offset is declarative: it mirrors the declaration each frame, never history.
        // 偏移是声明式的：每帧反映声明本身，从不累积历史。
        let mut target = OffscreenTarget::new(240, 240);
        let mut lp = AppLoop::new(Offset { dx: 60.0 });
        let offset_x = |lp: &AppLoop<Offset>| {
            let nid = lp.tree().find_by_id(Id::str("mover")).expect("mover");
            lp.tree().get(nid).expect("node").offset.x
        };
        lp.frame(&mut target, None);
        let a = offset_x(&lp);
        lp.frame(&mut target, None);
        let b = offset_x(&lp);
        assert_eq!((a, b), (60.0, 60.0), "a held offset must not compound");

        lp.app_mut().dx = 100.0;
        lp.frame(&mut target, None);
        assert_eq!(offset_x(&lp), 100.0, "a new offset must replace the held one");
    }

    #[test]
    fn the_caret_fact_is_layout_space_so_a_scroll_cannot_feed_back() {
        // A control that scrolls text by the caret's x must never read its own offset back.
        // 按插入符 x 滚动文本的控件绝不能读回自己施加的偏移。
        struct Field {
            dx: f32,
        }
        impl App for Field {
            fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
                let text = Decl {
                    id: Id::str("field-input"),
                    kind: NodeKind::Text,
                    shapes: Vec::new(),
                    data: NodeData::Text {
                        ink: Color::BLACK,
                        block: ui_core::TextBlock::plain(
                            "alpha",
                            ui_core::TextStyle::new(16.0),
                        ),
                        caret: None,
                        selection: None,
                        composing: None,
                        nowrap: true,
                    },
                    size_class: SizeClass {
                        width: AxisSize::hug(0.0, f32::INFINITY),
                        height: AxisSize::hug(16.0, 24.0),
                        grow_x: Grow::No,
                        grow_y: Grow::No,
                    },
                    ink_margin: Insets::ZERO,
                    box_model: Default::default(),
                    offset: ui_core::geom::Point::new(self.dx, 0.0),
                    cursor: None,
                    sense: ui_core::Sense::NONE,
                    disabled: false,
                    grid: ui_core::GridItem::default(),
                    placement: ui_core::layout::Placement::default(),
                    env: None,
                    children: Vec::new(),
                };
                crate::from_decl(
                    Decl::container(Id::str("field"), NodeKind::Row)
                        .size(SizeClass::fixed(200.0, 40.0))
                        .sense(ui_core::Sense::CLICK | ui_core::Sense::FOCUSABLE)
                        .text_input("alpha")
                        .child(text),
                )
            }
        }

        let mut target = OffscreenTarget::new(300, 200);
        let mut lp = AppLoop::new(Field { dx: 0.0 });
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(80.0, 20.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: at,
            button: ui_core::PointerButton::Primary,
        });
        // The caret's byte is the engine's business; this test is about where it lands.
        // 插入符落在哪个字节是引擎的事；本条测试关心的是它落在哪里。
        lp.editing = Some((
            Id::str("field"),
            ui_core::TextSelection::collapsed("alpha".len()),
        ));
        lp.frame(&mut target, None);
        let (node, x) = lp.caret_in_text_fact().expect("a focused input reports its caret");
        assert_eq!(node, Id::str("field-input"));

        // Whatever x is, the offset must not move it: measured through `visual_rect` the 40
        // would come back inside the fact and every frame would scroll ten more pixels.
        // 无论 x 是多少，偏移都不能改变它：若按 `visual_rect` 测量，那 40 会被折回事实里，
        // 每一帧都会再滚十像素。
        lp.app_mut().dx = 40.0;
        lp.frame(&mut target, None);
        let (_, moved) = lp.caret_in_text_fact().expect("still focused");
        assert_eq!(moved, x, "a paint offset must not move the fact a scroll is computed from");
    }

    #[test]
    fn a_moved_node_dirties_both_the_old_and_new_area() {
        // An offset stresses the damage contract: when a node moves, the pixels it
        // vacates must be cleared as well as the ones it now covers, or a ghost stays.
        // 偏移给脏区契约加了考验：节点移动时，它腾出的像素必须与新覆盖的像素一起标脏，
        // 否则留下残影。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(Offset { dx: 0.0 });
        lp.frame(&mut target, None);

        lp.app_mut().dx = 80.0;
        let out = lp.frame(&mut target, None);
        let rects = out.damage.rects(Rect::new(0.0, 0.0, 200.0, 200.0));
        let covers_old = rects.iter().any(|r| r.contains(ui_core::geom::Point::new(20.0, 20.0)));
        let covers_new = rects.iter().any(|r| r.contains(ui_core::geom::Point::new(100.0, 20.0)));
        assert!(covers_old, "the vacated area must be damaged: {rects:?}");
        assert!(covers_new, "the newly covered area must be damaged: {rects:?}");
    }

    #[test]
    fn a_hit_test_lands_where_the_node_is_drawn_not_where_layout_put_it() {
        // The invariant that makes a paint offset safe for dragging: the click target
        // follows the pixels. Otherwise the node moves on screen but must be clicked
        // back at its old spot, which reads as a dead zone.
        // 让绘制偏移能安全用于拖拽的前提：点击目标跟随像素。
        // 否则节点在屏上移动了，却要点击它原来的位置，感觉像一块死区。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(Offset { dx: 50.0 });
        // The pointer must be passed to `frame` as well: it is authoritative, and
        // passing `None` clears the hover the dispatch just computed.
        // 指针也必须传给 `frame`：它是权威，传 `None` 会清掉 dispatch 刚算出的悬停。
        let old_spot = ui_core::geom::Point::new(20.0, 20.0);
        let new_spot = ui_core::geom::Point::new(60.0, 20.0);
        lp.frame(&mut target, Some(old_spot));
        // (20,20) is where layout placed the block; (60,20) is where it is drawn.
        // (20,20) 是布局放置的位置；(60,20) 是它被画出的位置。
        assert_ne!(
            lp.hovered(),
            Some(Id::str("mover")),
            "the old layout position must no longer be the block"
        );

        lp.frame(&mut target, Some(new_spot));
        assert_eq!(
            lp.hovered(),
            Some(Id::str("mover")),
            "the block must be hovered where it is drawn"
        );
    }

    #[test]
    fn hovering_a_child_does_not_report_the_parent_as_hovered() {
        // Why the demo's fade never showed: `cx.hovered()` is the *topmost* node, so a
        // container is never reported while the pointer is over its own children.
        // 样例淡入看不到的原因：`cx.hovered()` 是**最上层**节点，
        // 指针落在子节点上时，容器永远不会被报告为悬停。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(Card { seen: Vec::new() });
        lp.frame(&mut target, None);
        // Over the inner box.
        // 落在内层盒子上。
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(20.0, 20.0),
        });
        lp.frame(&mut target, None);
        let last = *lp.app_mut().seen.last().expect("a frame ran");
        assert_eq!(
            last,
            Some(Id::str("inner")),
            "the topmost node is the child, not the card"
        );
    }

    /// Records what `hovered_within` says for the card each frame.
    /// 每帧记录 `hovered_within` 对卡片的回答。
    struct CardHover {
        seen: Vec<bool>,
    }

    impl App for CardHover {
        fn view(&mut self, info: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let decl = {
            self.seen.push(info.hovered_within(Id::str("card")));
            Decl::container(Id::str("card"), NodeKind::Column)
                .size(ui_core::layout::SizeClass::fixed(120.0, 120.0))
                .padding(ui_core::geom::Insets::all(10.0))
                // The card subscribes to hover; the child deliberately does not, so the
                // answer must come from the ancestor chain.
                // 卡片订阅悬停；子节点刻意不订阅，因此答案必须来自祖先链。
                .sense(ui_core::Sense::HOVER)
                .child(
                    Decl::container(Id::str("inner"), NodeKind::Column)
                        .size(ui_core::layout::SizeClass::fixed(60.0, 60.0))
                        .background(Color::from_rgba8(10, 200, 10, 255), Corners::ZERO),
                )
        };
    crate::from_decl(decl)
}
}

    /// A container and a child, each optionally declaring a shape.
    /// 一个容器与一个子节点，各自可选地声明形状。
    struct CursorDecl {
        parent: Option<ui_core::CursorShape>,
        child: Option<ui_core::CursorShape>,
    }

    impl App for CursorDecl {
        fn view(&mut self, _info: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let decl = {
            let mut inner = Decl::container(Id::str("inner"), NodeKind::Column)
                .size(ui_core::layout::SizeClass::fixed(60.0, 60.0))
                .background(Color::from_rgba8(10, 200, 10, 255), Corners::ZERO);
            if let Some(shape) = self.child {
                inner = inner.cursor(shape);
            }
            let mut outer = Decl::container(Id::str("outer"), NodeKind::Column)
                .size(ui_core::layout::SizeClass::fixed(120.0, 120.0))
                .padding(ui_core::geom::Insets::all(10.0))
                .background(Color::from_rgba8(60, 130, 220, 255), Corners::ZERO)
                .child(inner);
            if let Some(shape) = self.parent {
                outer = outer.cursor(shape);
            }
            outer
        };
    crate::from_decl(decl)
}
}

    #[test]
    fn a_parent_shape_covers_its_children_when_they_declare_none() {
        // The shape is inherited down the tree, like the cursor in CSS.
        // 形状沿树继承，与 CSS 的光标一致。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(CursorDecl { parent: Some(ui_core::CursorShape::Grab), child: None });
        // Inside the child, which declares nothing.
        // 在子节点内，它没有声明任何形状。
        let out = lp.frame(&mut target, Some(ui_core::geom::Point::new(20.0, 20.0)));
        assert_eq!(out.cursor, ui_core::CursorShape::Grab);
    }

    #[test]
    fn an_arrow_child_stops_a_parent_grab_from_leaking() {
        // "Nearest declaration wins" is what makes an explicit arrow possible at all.
        // 「最近声明生效」正是显式箭头能够存在的前提。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(CursorDecl {
            parent: Some(ui_core::CursorShape::Grab),
            child: Some(ui_core::CursorShape::Arrow),
        });
        let out = lp.frame(&mut target, Some(ui_core::geom::Point::new(20.0, 20.0)));
        assert_eq!(out.cursor, ui_core::CursorShape::Arrow);
    }

    #[test]
    fn the_cursor_reverts_when_the_pointer_leaves_the_declaring_node() {
        // Cleared shapes must be reported, not omitted: an "unchanged" answer would leave
        // the stale shape stuck under the pointer.
        // 清除后的形状必须被报告而不是省略：回答「无变化」会让旧形状卡在指针下。
        let mut target = OffscreenTarget::new(400, 400);
        let mut lp = AppLoop::new(CursorDecl { parent: Some(ui_core::CursorShape::Grab), child: None });
        let inside = lp.frame(&mut target, Some(ui_core::geom::Point::new(20.0, 20.0)));
        assert_eq!(inside.cursor, ui_core::CursorShape::Grab);

        let outside = lp.frame(&mut target, Some(ui_core::geom::Point::new(350.0, 350.0)));
        assert_eq!(
            outside.cursor,
            ui_core::CursorShape::Arrow,
            "leaving the node must revert the shape to the default"
        );
    }

    #[test]
    fn hovered_within_reports_the_container_when_a_child_is_hovered() {
        // The bug the demo's fade exposed: `hovered` is topmost, so a container asking
        // "am I hovered?" never sees the pointer over its own children.
        // 样例淡入暴露的缺陷：`hovered` 是最上层，容器问「我是否被悬停」时，
        // 指针落在它自己的子节点上永远得不到肯定。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(CardHover { seen: Vec::new() });
        lp.frame(&mut target, None);
        assert_eq!(
            lp.app_mut().seen.last(),
            Some(&false),
            "nothing hovered means nothing within"
        );

        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(20.0, 20.0),
        });
        lp.frame(&mut target, None);
        assert_eq!(
            lp.app_mut().seen.last(),
            Some(&true),
            "the pointer over the inner box is still within the card"
        );

        // Outside the card entirely.
        // 完全离开卡片。
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(190.0, 190.0),
        });
        lp.frame(&mut target, None);
        assert_eq!(
            lp.app_mut().seen.last(),
            Some(&false),
            "outside the card is not within it"
        );
    }

    /// A card that fades its own background while the pointer is anywhere inside it.
    /// 指针在内部任意位置时淡入自身背景的卡片。
    struct FadingCard;

    impl App for FadingCard {
        fn view(&mut self, info: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let decl = {
            let hovered = info.hovered_within(Id::str("card"));
            let t = info.animate(
                Id::str("card"),
                if hovered { 1.0 } else { 0.0 },
                ui_core::AnimSpec::new(0.1, ui_core::Easing::Linear),
            );
            let base = Color::from_rgba8(0, 0, 0, 255);
            let lifted = Color::from_rgba8(200, 200, 200, 255);
            Decl::container(Id::str("card"), NodeKind::Column)
                .size(ui_core::layout::SizeClass::fixed(100.0, 100.0))
                // The card is the one asking to be hovered; the child takes nothing.
                // 卡片才是那个要求被悬停的节点；子节点不接受任何交互。
                .sense(ui_core::Sense::HOVER)
                .background(base.lerp(lifted, t), Corners::ZERO)
                .child(
                    // An opaque child covering the middle: the pointer lands here, so a
                    // topmost-only hover check would never fade the card.
                    // 覆盖中部的不透明子节点：指针落在它上面，
                    // 只看最上层的悬停判断永远不会让卡片淡入。
                    Decl::container(Id::str("inner"), NodeKind::Column)
                        .size(ui_core::layout::SizeClass::fixed(60.0, 60.0))
                        .background(Color::from_rgba8(0, 0, 255, 255), Corners::ZERO),
                )
        };
    crate::from_decl(decl)
}
}

    #[test]
    fn hovering_a_child_fades_the_container_that_asked_to_be_hovered() {
        // The end-to-end claim the user could not see: pointer over a child, container
        // colour changes over successive frames.
        // 用户看不到的端到端事实：指针在子节点上，容器颜色随帧变化。
        let mut target = OffscreenTarget::new(160, 160);
        let mut lp = AppLoop::new(FadingCard);
        lp.frame(&mut target, None);
        // Sample a corner of the card, outside the opaque child.
        // 取卡片的一个角，位于不透明子节点之外。
        let sample = |t: &OffscreenTarget| t.pixels.get(90, 90);
        let before = sample(&target);

        // Pointer over the inner child, not over the card itself. The position must go
        // to `frame_with_dt` too: that argument is authoritative and `None` clears it.
        // 指针落在内层子节点上，而不是卡片本身。位置也必须传给 `frame_with_dt`：
        // 那个参数才是权威，传 `None` 会把它清掉。
        let at = ui_core::geom::Point::new(50.0, 50.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        for _ in 0..4 {
            lp.frame_with_dt(&mut target, Some(at), 0.03);
        }
        let after = sample(&target);
        assert_ne!(
            before, after,
            "hovering the child must fade the card: {before:?} vs {after:?}"
        );
    }

    /// A box whose declared width the app toggles; the declaration never sees the tween.
    /// 宽度可切换的盒子；声明本身看不到补间。
    struct Resizing {
        wide: bool,
    }

    impl App for Resizing {
        fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let width = if self.wide { 200.0 } else { 100.0 };
            Box::new(
                crate::Container::new(Id::str("resize"), NodeKind::Box)
                    .size(SizeClass {
                        width: AxisSize::fixed(width),
                        height: AxisSize::fixed(50.0),
                        grow_x: ui_core::layout::Grow::No,
                        grow_y: ui_core::layout::Grow::No,
                    })
                    .transition_size(ui_core::AnimSpec::new(0.1, ui_core::Easing::Linear)),
            )
        }
    }

    fn resized_width(lp: &AppLoop<Resizing>) -> f32 {
        lp.tree()
            .find_by_id(Id::str("resize"))
            .and_then(|nid| lp.tree().get(nid))
            .map(|n| n.rect.size.w)
            .expect("resize box")
    }

    #[test]
    fn a_size_transition_reaches_its_target_through_the_layout() {
        // The declaration only ever names 100 or 200; the frames in between must come from
        // the engine's interpolation, and layout must see each of them.
        // 声明只会说 100 或 200；中间那些帧必须来自引擎的插值，而且布局要看得到它们。
        let mut target = OffscreenTarget::new(320, 120);
        let mut lp = AppLoop::new(Resizing { wide: false });
        lp.frame(&mut target, None);
        assert_eq!(resized_width(&lp), 100.0, "the first frame is the target itself");

        lp.app_mut().wide = true;
        // The frame that observes the change still shows the old size; the leg starts here.
        // 看到变化的那一帧仍显示旧尺寸；行程从这一刻起算。
        lp.frame_with_dt(&mut target, None, 0.0);
        assert_eq!(resized_width(&lp), 100.0, "a retarget starts from where the box is");
        lp.frame_with_dt(&mut target, None, 0.05);
        let middle = resized_width(&lp);
        assert!(
            (middle - 150.0).abs() < 6.0,
            "halfway through a 100ms linear leg the box is about 150 wide, got {middle}"
        );

        lp.frame_with_dt(&mut target, None, 0.06);
        assert_eq!(resized_width(&lp), 200.0, "past the leg the box is its declared size");
    }

    /// A card declared only while `shown`; it states how it enters and leaves.
    /// 仅在 `shown` 时声明的卡片；它自己写明如何入场与离场。
    struct Appearing {
        shown: bool,
        enter: Option<ui_core::tree::Presence>,
        exit: Option<ui_core::tree::Presence>,
    }

    impl App for Appearing {
        fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let (enter, exit) = (self.enter, self.exit);
            Box::new(
                crate::Container::new(Id::str("host"), NodeKind::Stack).child_if(
                    self.shown,
                    || {
                        let mut card = crate::Container::new(Id::str("card"), NodeKind::Box)
                            .size(SizeClass::fixed(60.0, 40.0))
                            .background(Color::from_rgba8(220, 60, 60, 255), Corners::ZERO)
                            .sense(ui_core::Sense::CLICK);
                        if let Some(enter) = enter {
                            card = card.enter(enter);
                        }
                        if let Some(exit) = exit {
                            card = card.exit(exit);
                        }
                        Box::new(card)
                    },
                ),
            )
        }
    }

    #[test]
    fn an_entering_node_is_painted_from_its_start_offset() {
        // Enter says "come from 20 px below": the first frame must already honour it, and
        // the declared rect is only reached once presence lands.
        // enter 说「从下方 20px 过来」：第一帧就得照办，声明的位置要等 presence 落定才到达。
        let mut target = OffscreenTarget::new(120, 120);
        let mut lp = AppLoop::new(Appearing {
            shown: false,
            enter: Some(ui_core::tree::Presence {
                spec: ui_core::AnimSpec::new(0.1, ui_core::Easing::Linear),
                scale_spec: None,
                opacity: 1.0,
                offset: ui_core::geom::Point::new(0.0, 20.0),
                scale: 1.0,
            }),
            exit: None,
        });
        lp.frame(&mut target, None);
        let bg = target.pixels.get(30, 5);

        lp.app_mut().shown = true;
        lp.frame_with_dt(&mut target, None, 0.0);
        // At presence 0 the card spans y 20..60, so it has left the place it will occupy.
        // presence 为 0 时卡片占 y 20..60，因此它还没到达自己的位置。
        assert_ne!(target.pixels.get(30, 45), bg, "the card is drawn 20 px lower");
        assert_eq!(target.pixels.get(30, 5), bg, "its declared place is still empty");

        lp.frame_with_dt(&mut target, None, 0.06);
        lp.frame_with_dt(&mut target, None, 0.06);
        let nid = lp.tree().find_by_id(Id::str("card")).expect("card");
        let node = lp.tree().get(nid).expect("node");
        assert_eq!(node.presence, 1.0, "the card has arrived");
        assert_eq!(node.visual_rect().origin.y, node.rect.origin.y);
        assert_ne!(target.pixels.get(30, 5), bg, "it now covers its declared place");
        assert_eq!(target.pixels.get(30, 45), bg, "and has left the start area");
    }

    #[test]
    fn an_entering_node_fades_in_from_its_declared_opacity() {
        // `enter` states the starting opacity; until presence lands the card must actually
        // be transparent, not merely carry a small number.
        // enter 写明起始不透明度；presence 落定之前卡片必须真的透明，而不只是记了个小数。
        let mut target = OffscreenTarget::new(120, 120);
        let mut lp = AppLoop::new(Appearing {
            shown: false,
            enter: Some(ui_core::tree::Presence {
                spec: ui_core::AnimSpec::new(0.1, ui_core::Easing::Linear),
                scale_spec: None,
                opacity: 0.0,
                offset: ui_core::geom::Point::ZERO,
                scale: 1.0,
            }),
            exit: None,
        });
        lp.frame(&mut target, None);
        let bg = target.pixels.get(30, 20);

        lp.app_mut().shown = true;
        let first = lp.frame_with_dt(&mut target, None, 0.0);
        assert!(first.animating, "an entering node keeps the loop awake");
        assert_eq!(target.pixels.get(30, 20), bg, "presence 0 paints nothing");

        lp.frame_with_dt(&mut target, None, 0.05);
        assert_ne!(target.pixels.get(30, 20), bg, "halfway it is partly there");

        lp.frame_with_dt(&mut target, None, 0.06);
        let done = lp.frame_with_dt(&mut target, None, 0.016);
        assert!(!done.animating, "a landed node stops asking for frames");
        assert_ne!(target.pixels.get(30, 20), bg, "and stays painted");
    }

    #[test]
    fn a_scale_on_its_own_clock_outlives_the_fade_that_rides_the_presence() {
        // WinUI's dialog fades in 83 ms and scales over 250; one shared value would land
        // the scale with the fade, which is the difference between opening and appearing.
        // WinUI 的对话框 83 毫秒淡完、缩放走 250 毫秒；共用一个值会让缩放跟着淡一起落定，
        // 那就成了"直接出现"而不是"打开"。
        let mut target = OffscreenTarget::new(120, 120);
        let mut lp = AppLoop::new(Appearing {
            shown: false,
            enter: Some(
                ui_core::tree::Presence::fade(
                    ui_core::AnimSpec::new(0.1, ui_core::Easing::Linear),
                    0.0,
                )
                .scaled_over(
                    2.0,
                    ui_core::AnimSpec::new(0.3, ui_core::Easing::Linear),
                ),
            ),
            exit: None,
        });
        lp.frame_with_dt(&mut target, None, 0.0);
        lp.app_mut().shown = true;
        lp.frame_with_dt(&mut target, None, 0.0);
        lp.frame_with_dt(&mut target, None, 0.15);
        let card = lp
            .tree
            .get(lp.tree.find_by_id(Id::str("card")).expect("the card"))
            .expect("the card");
        assert_eq!(
            card.presence_alpha, 1.0,
            "the 100 ms fade has landed by 150 ms"
        );
        assert!(
            card.presence_scale > 1.0 && card.presence_scale < 2.0,
            "and the 300 ms scale is still on its way, got {}",
            card.presence_scale
        );
    }

    #[test]
    fn an_entering_node_scales_about_its_centre_and_hits_where_it_is_painted() {
        // A scale lives in paint, not in layout: the pixels and the hit box must move
        // together, so the corner the card has not grown into yet does not take the press.
        // 缩放只存在于绘制而不在布局：像素与命中盒必须一起移动，
        // 卡片还没长到的那个角因此不接收按下。
        let mut target = OffscreenTarget::new(120, 120);
        let mut lp = AppLoop::new(Appearing {
            shown: true,
            enter: Some(ui_core::tree::Presence {
                spec: ui_core::AnimSpec::new(0.1, ui_core::Easing::Linear),
                scale_spec: None,
                opacity: 1.0,
                offset: ui_core::geom::Point::ZERO,
                scale: 0.5,
            }),
            exit: None,
        });
        let corner = ui_core::geom::Point::new(5.0, 5.0);
        let first = lp.frame(&mut target, Some(corner));
        assert_ne!(first.hit, Some(Id::str("card")), "half size, the corner is outside");
        let bg = target.pixels.get(100, 100);
        assert_eq!(target.pixels.get(5, 5), bg, "and nothing is painted there either");
        assert_ne!(target.pixels.get(30, 20), bg, "the centre already carries the card");

        lp.frame_with_dt(&mut target, Some(corner), 0.06);
        let done = lp.frame_with_dt(&mut target, Some(corner), 0.06);
        assert_eq!(done.hit, Some(Id::str("card")), "settled, the corner belongs to it");
        assert_ne!(target.pixels.get(5, 5), bg, "and the corner is painted");
    }

    /// A page with a modal scrim and a surface: the structure MD3's dialog builds.
    /// 一个带模态遮罩与表面的页面：MD3 对话框搭出来的结构。
    struct ModalPage {
        show: bool,
    }

    impl App for ModalPage {
        fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let enter = ui_core::tree::Presence::fade(
                ui_core::AnimSpec::new(0.1, ui_core::Easing::Linear),
                0.0,
            );
            Box::new(
                crate::Container::new(Id::str("page"), NodeKind::Stack)
                    .background(Color::from_rgba8(0, 0, 255, 255), Corners::ZERO)
                    .child_if(self.show, || {
                        Box::new(
                            crate::Container::new(Id::str("scrim"), NodeKind::Stack)
                                .map(|d| d.modal(ui_core::tree::ModalTarget::Global))
                                .background(Color::from_rgba8(0, 0, 0, 255), Corners::ZERO)
                                .enter(enter)
                                .exit(enter)
                                .child(Box::new(
                                    crate::Container::new(Id::str("surface"), NodeKind::Box)
                                        .size(SizeClass::fixed(20.0, 20.0))
                                        .background(Color::WHITE, Corners::ZERO)
                                        .enter(enter),
                                )),
                        )
                    }),
            )
        }
    }

    #[test]
    fn a_modal_scrim_fades_instead_of_appearing_dark() {
        // The scrim is a layer over the page; its enter must reach the pixels on the first
        // frame, not after the click that mounted it.
        // 遮罩是页面之上的一层；它的入场必须在那第一帧就落到像素上，而不是等挂载它的点击过去。
        let mut target = OffscreenTarget::new(120, 120);
        let mut lp = AppLoop::new(ModalPage { show: false });
        lp.frame(&mut target, None);
        // The surface hugs the scrim's origin, so a point far from it can only be scrim.
        // 表面贴在遮罩原点，远离它的点只可能是遮罩。
        let page = target.pixels.get(60, 60);

        lp.app_mut().show = true;
        lp.frame_with_dt(&mut target, None, 0.0);
        assert_eq!(
            target.pixels.get(60, 60),
            page,
            "at presence 0 the scrim must paint nothing"
        );

        lp.frame_with_dt(&mut target, None, 0.05);
        assert_ne!(
            target.pixels.get(60, 60),
            page,
            "halfway the scrim is partly there"
        );

        // The landing frame is the last one anyone sees: it must reach the pixels, or the
        // dialog rests one step short of where it declared it would.
        // 落定的那一帧是最后被看见的一帧：它必须落到像素上，否则对话框会停在声明位置前一步。
        let landed = lp.frame_with_dt(&mut target, None, 0.06);
        assert!(!landed.damage.is_none(), "the landing frame must be drawn");
        assert_eq!(
            target.pixels.get(60, 60),
            [0, 0, 0, 255],
            "and it must show the scrim at full strength"
        );
    }

    /// The dialogs' scrim is translucent and its surface scales: MD3's exact shape.
    /// 对话框遮罩是半透明的、表面带缩放：MD3 的确切形态。
    struct Md3Page {
        show: bool,
    }

    impl App for Md3Page {
        fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let enter = ui_core::tree::Presence::fade(
                ui_core::AnimSpec::new(0.1, ui_core::Easing::Linear),
                0.0,
            );
            Box::new(
                crate::Container::new(Id::str("page"), NodeKind::Stack)
                    .background(Color::from_rgba8(0, 0, 255, 255), Corners::ZERO)
                    .child_if(self.show, || {
                        Box::new(
                            crate::Container::new(Id::str("scrim"), NodeKind::Stack)
                                .map(|d| d.modal(ui_core::tree::ModalTarget::Global))
                                .background(Color::from_rgba8(0, 0, 0, 138), Corners::ZERO)
                                .enter(enter)
                                .exit(enter)
                                .child(Box::new(
                                    crate::Container::new(Id::str("surface"), NodeKind::Box)
                                        .size(SizeClass::fixed(20.0, 20.0))
                                        .background(Color::WHITE, Corners::ZERO)
                                        .enter(enter.scaled(0.8))
                                        .exit(enter),
                                )),
                        )
                    }),
            )
        }
    }

    #[test]
    fn an_exit_starts_from_the_pixels_its_subtree_rested_on() {
        // A held root left in its parent's paint list is drawn twice — once through the
        // parent, once from `held()` — and a translucent scrim doubles its own alpha.
        // 被持有的根留在父节点的绘制表里会被画两次——父节点一次、`held()` 一次——
        // 半透明遮罩因此把自己的 alpha 叠了两遍。
        let mut target = OffscreenTarget::new(120, 120);
        let mut lp = AppLoop::new(Md3Page { show: false });
        lp.frame(&mut target, None);
        lp.app_mut().show = true;
        lp.frame_with_dt(&mut target, None, 0.0);
        lp.frame_with_dt(&mut target, None, 0.06);
        lp.frame_with_dt(&mut target, None, 0.06);
        let settled = target.pixels.get(60, 60);
        assert_eq!(settled, [0, 0, 117, 255], "black54 over the page, composited once");

        lp.app_mut().show = false;
        // A zero step freezes the clock, so this frame paints whatever the exit starts from.
        // 零步长冻结时钟，因此这一帧画的正是退场的起始值。
        assert!(lp.frame_with_dt(&mut target, None, 0.0).animating, "the exit is under way");
        assert_eq!(
            target.pixels.get(60, 60),
            settled,
            "the first exit frame must not jump away from the state it rested in"
        );
    }

    #[test]
    fn a_leaving_node_keeps_painting_until_its_exit_lands() {
        // The declaration drops the card. The engine must keep drawing it while it fades,
        // then let go of it — the app never holds a dead subtree itself.
        // 声明不再提到卡片。引擎必须一边淡出一边继续绘制，落定后再放手——应用不必自己持有死子树。
        let mut target = OffscreenTarget::new(120, 120);
        let mut lp = AppLoop::new(Appearing {
            shown: true,
            enter: None,
            exit: Some(ui_core::tree::Presence {
                spec: ui_core::AnimSpec::new(0.1, ui_core::Easing::Linear),
                scale_spec: None,
                opacity: 0.0,
                offset: ui_core::geom::Point::ZERO,
                scale: 1.0,
            }),
        });
        lp.frame(&mut target, None);
        let empty = target.pixels.get(100, 100);
        assert_ne!(target.pixels.get(30, 20), empty, "the card is on screen");

        lp.app_mut().shown = false;
        let leaving = lp.frame_with_dt(&mut target, None, 0.0);
        assert!(leaving.animating, "the card is still leaving");
        assert!(!lp.tree().held().is_empty(), "the engine holds the subtree");
        assert!(
            lp.tree().find_by_id(Id::str("card")).is_none(),
            "a held node is out of the live tree, so nothing can hit or focus it"
        );
        let host = lp.tree().find_by_id(Id::str("host")).expect("host");
        assert!(
            lp.tree().children_of(Some(host)).is_empty(),
            "and out of the flow, so its siblings close the gap at once"
        );
        assert_ne!(target.pixels.get(30, 20), empty, "and it is still painted");

        lp.frame_with_dt(&mut target, None, 0.05);
        assert_ne!(
            target.pixels.get(30, 20),
            empty,
            "halfway through the fade it is still there"
        );

        lp.frame_with_dt(&mut target, None, 0.06);
        assert_eq!(
            target.pixels.get(30, 20),
            empty,
            "once the exit lands nothing of it remains"
        );
        assert!(lp.tree().held().is_empty(), "and the engine has let go");
        let after = lp.frame_with_dt(&mut target, None, 0.016);
        assert!(!after.animating, "nothing is left to animate");
    }

    #[test]
    fn an_animated_colour_reaches_the_pixels() {
        // Damage and "animating" are both proxies. This checks the thing itself: the
        // colour written to the buffer moves as the animation progresses.
        // 脏区与 animating 都是代理指标。这条检查本体：
        // 写进缓冲的颜色随动画推进而变化。
        let mut target = OffscreenTarget::new(120, 120);
        let mut lp = AppLoop::new(Fading {
            target: 0.0,
        });
        lp.frame(&mut target, None);
        // Premultiplied BGRA; the block is opaque so the order does not matter here.
        // 预乘 BGRA；该色块不透明，因此通道顺序在这里无关。
        let sample = |t: &OffscreenTarget| t.pixels.get(25, 25);
        let before = sample(&target);

        lp.app_mut().target = 1.0;
        // Advance a few frames so the value is part-way, not at either end.
        // 推进几帧，使值处于中途而不是两端。
        for _ in 0..3 {
            lp.frame_with_dt(&mut target, None, 0.02);
        }
        let after = sample(&target);
        assert_ne!(
            before, after,
            "the animated colour must reach the buffer: {before:?} vs {after:?}"
        );
    }

    #[test]
    fn a_settled_animation_reports_no_motion_and_goes_quiet() {
        // Otherwise the platform keeps scheduling frames forever.
        // 否则平台会永远安排下一帧。
        let mut target = OffscreenTarget::new(120, 120);
        let mut lp = AppLoop::new(Fading {
            target: 0.0,
        });
        lp.frame(&mut target, None);
        lp.app_mut().target = 1.0;
        lp.frame_with_dt(&mut target, None, 0.05);

        // Push past the 0.1s duration: the frame that crosses the end still paints.
        // 推过 0.1 秒的时长：跨过终点的那一帧仍要绘制。
        let settling = lp.frame_with_dt(&mut target, None, 0.15);
        assert!(!settling.damage.is_none(), "the settling frame must be drawn");

        // One more frame at the landed value: nothing moved, so nothing is damaged.
        // 在落定值上再走一帧：什么都没动，因此不产生脏区。
        lp.frame_with_dt(&mut target, None, 0.016);
        let after = lp.frame_with_dt(&mut target, None, 0.016);
        assert!(!after.animating, "nothing is moving any more");
        assert!(
            after.damage.is_none(),
            "a still frame with unchanged content must not damage anything"
        );
    }

    #[test]
    fn tab_walks_the_focus_ring_and_wraps_at_both_ends() {
        // Three painted boxes; Tab visits them in document order and then returns.
        // 三个有背景的盒子；Tab 按文档顺序访问，然后回到开头。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(Demo {
            expand: true,
            draggable: true,
        });
        lp.frame(&mut target, None);
        assert_eq!(lp.focused(), None, "nothing is focused before Tab");

        let tab = || ui_core::Event::KeyPressed {
            key: ui_core::Key::Tab,
        };
        assert!(lp.dispatch(tab()), "first Tab must ask for a repaint");
        assert_eq!(lp.focused(), Some(Id::str("bar")), "starts at the first stop");
        lp.dispatch(tab());
        assert_eq!(lp.focused(), Some(Id::str("extra")));
        lp.dispatch(tab());
        assert_eq!(lp.focused(), Some(Id::str("bar")), "wraps to the start");

        // Shift reverses the walk from wherever focus is.
        // Shift 从当前位置反向走。
        lp.dispatch(ui_core::Event::Modifiers(ui_core::Modifiers {
            shift: true,
            ..Default::default()
        }));
        lp.dispatch(tab());
        assert_eq!(lp.focused(), Some(Id::str("extra")), "shift goes backwards");
    }

    /// A shell that binds Escape on itself and puts one focusable box inside.
    /// 在自身绑定 Escape、里面放一个可聚焦盒子的外壳。
    struct Shell(std::rc::Rc<std::cell::Cell<Option<ui_core::ShortcutId>>>);

    impl crate::Element for Shell {
        fn decl(&self, _cx: &mut ui_core::cx::Cx<'_>) -> Decl {
            Decl::container(Id::str("shell"), NodeKind::Column)
                .shortcut(
                    ui_core::KeyChord::new(ui_core::Key::Escape, ui_core::Modifiers::NONE),
                    ui_core::ShortcutId("test.close"),
                )
                .child(
                    Decl::container(Id::str("inner"), NodeKind::Box)
                        .sense(ui_core::Sense::FOCUSABLE)
                        .size(SizeClass::fixed(40.0, 40.0))
                        .background(Color::WHITE, Corners::ZERO),
                )
        }

        fn change(
            &self,
            state: &crate::WidgetState,
            _bounds: Rect,
        ) -> Option<ui_core::change::Change> {
            self.0.set(state.shortcut);
            None
        }
    }

    struct ShellApp {
        heard: std::rc::Rc<std::cell::Cell<Option<ui_core::ShortcutId>>>,
    }

    impl App for ShellApp {
        fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            Box::new(Shell(self.heard.clone()))
        }
    }

    #[test]
    fn a_chord_bound_on_a_container_reaches_the_control_that_owns_it() {
        // A composite binds chords on its root and must hear them itself: the app is never
        // told which inner node held focus.
        // 复合控件在根上绑定组合键，必须自己听到：应用永远不知道哪个内部节点持有焦点。
        let heard = std::rc::Rc::new(std::cell::Cell::new(None));
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(ShellApp { heard: heard.clone() });
        lp.frame(&mut target, None);
        lp.dispatch(ui_core::Event::KeyPressed { key: ui_core::Key::Tab });
        assert_eq!(lp.focused(), Some(Id::str("inner")), "the box holds focus");
        assert_eq!(heard.get(), None, "nothing has fired yet");

        lp.dispatch(ui_core::Event::KeyPressed { key: ui_core::Key::Escape });
        lp.frame(&mut target, None);
        assert_eq!(
            heard.get(),
            Some(ui_core::ShortcutId("test.close")),
            "the owning control hears its own chord"
        );
    }

    /// One focusable box under `id`.
    /// `id` 下的一个可聚焦盒子。
    fn focus_box(id: Id) -> Decl {
        Decl::container(id, NodeKind::Box)
            .sense(ui_core::Sense::FOCUSABLE)
            .size(SizeClass::fixed(40.0, 40.0))
            .background(Color::WHITE, Corners::ZERO)
    }

    /// A page with one box outside a modal and one inside it.
    /// 一个页面：模态外一个盒子，模态内一个盒子。
    struct ModalApp {
        open: bool,
    }

    impl App for ModalApp {
        fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let mut col = Decl::container(Id::str("page"), NodeKind::Column)
                .child(focus_box(Id::str("outside")));
            if self.open {
                col = col.child(
                    Decl::container(Id::str("modal"), NodeKind::Column)
                        .modal(ui_core::tree::ModalTarget::Global)
                        .sense(ui_core::Sense::HOVER)
                        .child(focus_box(Id::str("inside"))),
                );
            }
            Box::new(crate::Leaf::new(col))
        }
    }

    #[test]
    fn a_modal_that_appears_takes_focus_from_behind_it() {
        // Otherwise the keyboard would stay on a node the scrim now covers, and a dialog
        // could not be answered with Enter or dismissed with Escape.
        // 否则键盘会留在遮罩已盖住的节点上，对话框既无法用 Enter 回答也无法用 Escape 关掉。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(ModalApp { open: false });
        lp.frame(&mut target, None);
        lp.dispatch(ui_core::Event::KeyPressed { key: ui_core::Key::Tab });
        assert_eq!(lp.focused(), Some(Id::str("outside")), "focus starts behind");

        lp.app_mut().open = true;
        lp.frame(&mut target, None);
        assert_eq!(
            lp.focused(),
            Some(Id::str("inside")),
            "the modal owns the keyboard, so focus moves inside it"
        );
    }

    /// A control that asks the keyboard to move to `ask` whenever its row is clicked.
    /// 行被点击时请求把键盘交给 `ask` 的控件。
    struct FocusAsker {
        decl: Decl,
        ask: Id,
    }

    impl crate::Element for FocusAsker {
        fn decl(&self, _cx: &mut ui_core::cx::Cx<'_>) -> Decl {
            self.decl.clone()
        }

        fn change(
            &self,
            state: &crate::WidgetState,
            _bounds: Rect,
        ) -> Option<ui_core::change::Change> {
            state
                .clicked
                .then_some(ui_core::change::Change::Focus(self.ask))
        }
    }

    fn click_at(lp: &mut AppLoop<impl App>, target: &mut OffscreenTarget, at: ui_core::geom::Point) {
        lp.frame(target, Some(at));
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.dispatch(ui_core::Event::PointerPressed {
            button: ui_core::PointerButton::Primary,
            pos: at,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            button: ui_core::PointerButton::Primary,
            pos: at,
        });
        lp.frame(target, Some(at));
    }

    /// A page whose control asks for the keyboard on one node of a given sense.
    /// 一页：其控件在某个给定 sense 的节点上请求键盘。
    struct AskApp {
        target: Decl,
    }

    impl App for AskApp {
        fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let id = Id::str("target");
            Box::new(FocusAsker {
                decl: Decl::container(Id::str("root"), NodeKind::Column)
                    .child(
                        Decl::container(Id::str("go"), NodeKind::Box)
                            .sense(ui_core::Sense::CLICK)
                            .size(SizeClass::fixed(80.0, 40.0)),
                    )
                    .child(self.target.clone()),
                ask: id,
            })
        }
    }

    #[test]
    fn a_control_hands_the_keyboard_to_a_node_that_can_take_it() {
        // A menu walks its own rows by asking the engine to move focus; a row that cannot be
        // focused must not take the keyboard from the live one.
        // 菜单通过请求引擎移动焦点来逐行走动；不能聚焦的行不得把键盘从活着的行上拿走。
        let at = ui_core::geom::Point::new(20.0, 20.0);
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(AskApp {
            target: focus_box(Id::str("target")),
        });
        click_at(&mut lp, &mut target, at);
        assert_eq!(lp.focused(), Some(Id::str("target")), "the request moves focus");

        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(AskApp {
            target: Decl::container(Id::str("target"), NodeKind::Box)
                .size(SizeClass::fixed(40.0, 40.0)),
        });
        click_at(&mut lp, &mut target, at);
        assert_eq!(lp.focused(), None, "an unfocusable target is refused");
    }

    #[test]
    fn enter_activates_the_focused_node_and_nothing_when_unfocused() {
        // Activation is routed by identity, so it must reach the app with the right one.
        // 激活按身份路由，因此必须带着正确的身份到达 app。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(Counting { activated: Vec::new(), scrolled: Vec::new(), expand: true, draggable: false });
        lp.frame(&mut target, None);

        // No focus yet: Enter must not invent one.
        // 尚无焦点：Enter 不得凭空产生焦点。
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Enter,
        });
        assert!(lp.app_mut().activated.is_empty(), "nothing focused, nothing activated");

        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Tab,
        });
        assert!(
            lp.dispatch(ui_core::Event::KeyPressed {
                key: ui_core::Key::Enter,
            }),
            "an accepted activation must ask for a repaint"
        );
        // The control reports it in `change()`, so exactly one delivery comes out of the frame.
        // 控件在 `change()` 里上报它，因此一帧只产出一条送达。
        lp.frame(&mut target, None);
        assert_eq!(lp.app_mut().activated, vec![Id::str("bar")]);
        // Space is the other activation key on most toolkits.
        // 空格是多数工具包里的另一个激活键。
        assert!(lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Space,
        }));
        lp.frame(&mut target, None);
        assert_eq!(
            lp.app_mut().activated,
            vec![Id::str("bar"), Id::str("bar")]
        );
    }

    /// A 2x2 grid: a/b on the top row, c/d on the bottom, so arrows have a real choice.
    /// 2x2 网格：a/b 在上排，c/d 在下排，使方向键有真正的选择。
    struct Grid;

    impl App for Grid {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let decl = {
            let cell = |name: &'static str| Decl {
                id: Id::str(name),
                kind: NodeKind::Box,
                shapes: vec![ui_core::draw::Shape::Box {
                    corners: ui_core::geom::Corners::ZERO,
                    fill: ui_core::geom::Color::WHITE,
                    gradient: None,
                    border: None,
                    shadow: None,
                    image: None,
                }],
                data: NodeData::Container(ui_core::tree::ContainerParams::default()),
                size_class: SizeClass {
                    width: AxisSize::fixed(40.0),
                    height: AxisSize::fixed(40.0),
                    grow_x: Grow::No,
                    grow_y: Grow::No,
                },
                ink_margin: Insets::ZERO,
                box_model: Default::default(),
                offset: ui_core::geom::Point::new(0.0, 0.0),
                cursor: None,
                sense: ui_core::Sense::HOVER | ui_core::Sense::CLICK | ui_core::Sense::FOCUSABLE,
                disabled: false,
                grid: ui_core::GridItem::default(),
                placement: ui_core::layout::Placement::default(),
                env: None,
                children: Vec::new(),
            };
            Decl::container(Id::str("grid"), NodeKind::Column)
                .gap(10.0)
                .child(
                    Decl::container(Id::str("row1"), NodeKind::Row)
                        .gap(10.0)
                        .child(cell("a"))
                        .child(cell("b")),
                )
                .child(
                    Decl::container(Id::str("row2"), NodeKind::Row)
                        .gap(10.0)
                        .child(cell("c"))
                        .child(cell("d")),
                )
        };
    crate::from_decl(decl)
}
}

    /// A 200×200 scroller over 400 of content: 200 of travel and one optional child that
    /// claims drags itself, so the panning rule can be exercised against it.
    /// 200×200、内容 400 的滚动容器：可滚 200，另有可选子节点自己认领拖拽，用于检验平移规则。
    struct Tall {
        drag_child: bool,
    }

    impl App for Tall {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let mut list = Decl::container(Id::str("content"), NodeKind::Column)
                .size(SizeClass::fixed(200.0, 400.0));
            if self.drag_child {
                list = list.child(
                    Decl::container(Id::str("knob"), NodeKind::Box)
                        .size(SizeClass::fixed(200.0, 40.0))
                        .sense(ui_core::Sense::HOVER | ui_core::Sense::DRAG),
                );
            }
            crate::from_decl(
                Decl::container(Id::str("scroller"), NodeKind::Column)
                    .size(SizeClass::fixed(200.0, 200.0))
                    .sense(ui_core::Sense::HOVER | ui_core::Sense::SCROLL_OWNED)
                    .clip(ui_core::layout::Clip {
                        x: ui_core::layout::Overflow::Hidden,
                        y: ui_core::layout::Overflow::Scroll,
                    })
                    .child(list),
            )
        }
    }

    /// The scroller laid out, with a clock the test steps frame by frame.
    /// 已布局的滚动容器，时钟由测试逐帧推进。
    fn tall(drag_child: bool, frames: usize) -> (AppLoop<Tall>, OffscreenTarget) {
        let mut lp = AppLoop::new(Tall { drag_child });
        lp.clock = FrameClock::scripted((0..=frames).map(|i| i as f64 / 60.0).collect());
        let mut target = OffscreenTarget::new(200, 200);
        lp.frame(&mut target, None);
        (lp, target)
    }

    fn dragged(lp: &mut AppLoop<Tall>, from: f32, to: f32) {
        let at = |y: f32| ui_core::geom::Point::new(100.0, y);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: at(from),
            button: ui_core::PointerButton::Primary,
        });
        // The first move only crosses the threshold; the pan starts where it crossed.
        // 第一次移动只越过阈值；平移从越过处开始。
        lp.dispatch(ui_core::Event::PointerMoved { pos: at(from - 6.0) });
        lp.dispatch(ui_core::Event::PointerMoved { pos: at(to) });
    }

    fn offset_y(lp: &AppLoop<Tall>) -> f32 {
        lp.scroll_offset(Id::str("scroller"))
            .map(|o| o.y)
            .unwrap_or(0.0)
    }

    #[test]
    fn a_pointer_drag_inside_a_scroller_moves_its_offset() {
        // Touch-style panning: the content follows the finger, so dragging up scrolls down.
        // 触控式平移：内容跟随手指，因此向上拖即向下滚。
        let (mut lp, mut target) = tall(false, 4);
        dragged(&mut lp, 150.0, 100.0);
        lp.frame(&mut target, None);
        assert_eq!(offset_y(&lp), 44.0, "the drag distance becomes the offset");
    }

    #[test]
    fn a_drag_past_the_end_stretches_less_than_the_pointer_travels() {
        // The rubber band: past the top edge the content keeps moving, but damped, so it
        // never runs away however far the pointer goes.
        // 橡皮筋：越过顶部后内容仍在动，但被阻尼，指针拖多远都不会跑飞。
        let (mut lp, mut target) = tall(false, 4);
        // Dragging down pulls the content down past the top edge, where it has no room.
        // 向下拖会把内容拉过顶部边界，那里本没有空间。
        dragged(&mut lp, 100.0, 180.0);
        lp.frame(&mut target, None);
        let y = offset_y(&lp);
        assert!(y < 0.0, "the content must follow past the edge, got {y}");
        assert!(y > -86.0, "and by less than the 86 travelled, got {y}");
    }

    #[test]
    fn releasing_a_stretched_scroller_springs_back_to_the_edge() {
        // iOS behaviour: let go mid-stretch and the content returns to the boundary.
        // iOS 行为：在拉伸中途松手，内容回到边界。
        let (mut lp, mut target) = tall(false, 90);
        dragged(&mut lp, 100.0, 180.0);
        lp.dispatch(ui_core::Event::PointerReleased {
            pos: ui_core::geom::Point::new(100.0, 180.0),
            button: ui_core::PointerButton::Primary,
        });
        assert!(
            !lp.scroll_motion.is_empty(),
            "a spring still pulling must keep the loop awake"
        );
        for _ in 0..80 {
            lp.frame(&mut target, None);
        }
        assert_eq!(offset_y(&lp), 0.0, "the stretch must end exactly on the edge");
        assert!(lp.scroll_motion.is_empty(), "and the scroller must come to rest");
    }

    #[test]
    fn a_release_with_speed_coasts_and_then_settles_on_the_far_edge() {
        // The hand's speed becomes the content's: a flick carries past where it was let go.
        // 手的速度变成内容的速度：一甩会越过松手处继续滑行。
        let (mut lp, mut target) = tall(false, 400);
        dragged(&mut lp, 190.0, 100.0);
        lp.frame(&mut target, None);
        let let_go = offset_y(&lp);
        lp.dispatch(ui_core::Event::PointerReleased {
            pos: ui_core::geom::Point::new(100.0, 100.0),
            button: ui_core::PointerButton::Primary,
        });
        lp.frame(&mut target, None);
        assert!(
            offset_y(&lp) > let_go,
            "a flick must carry the content further: {} vs {}",
            offset_y(&lp),
            let_go
        );
        for _ in 0..380 {
            lp.frame(&mut target, None);
        }
        assert_eq!(offset_y(&lp), 200.0, "it comes to rest on the far edge");
    }

    #[test]
    fn a_press_while_the_content_coasts_stops_it_where_it_is() {
        // Touch platforms stop inertia on touch-down: the content must freeze under the
        // finger, not race on and then jump when the pan takes the offset over.
        // 触控平台在按下时停止惯性：内容必须在手指下停住，而不是继续滑、再在平移接管时跳一下。
        let (mut lp, mut target) = tall(false, 400);
        dragged(&mut lp, 190.0, 100.0);
        lp.frame(&mut target, None);
        lp.dispatch(ui_core::Event::PointerReleased {
            pos: ui_core::geom::Point::new(100.0, 100.0),
            button: ui_core::PointerButton::Primary,
        });
        lp.frame(&mut target, None);
        assert!(!lp.scroll_motion.is_empty(), "the flick must still be coasting");
        let caught = offset_y(&lp);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: ui_core::geom::Point::new(100.0, 100.0),
            button: ui_core::PointerButton::Primary,
        });
        lp.frame(&mut target, None);
        assert_eq!(offset_y(&lp), caught, "the press must freeze the coast");
        // From there the content follows the pointer alone.
        // 此后内容只跟随指针。
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(100.0, 94.0),
        });
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(100.0, 80.0),
        });
        lp.frame(&mut target, None);
        assert_eq!(
            offset_y(&lp),
            caught + 14.0,
            "the drag adds its own travel and nothing else"
        );
    }

    #[test]
    fn a_coast_past_the_end_is_damped_instead_of_snapping_back() {
        // The rubber band applies to the coast too: a flick that reaches the edge must not
        // overshoot by the whole of `v * dt`, or the spring's return reads as a jump.
        // 橡皮筋同样作用于滑行：到达边界的甩动不得按整个 `v * dt` 越界，否则回弹看起来像跳变。
        let (mut lp, mut target) = tall(false, 400);
        dragged(&mut lp, 190.0, 100.0);
        lp.frame(&mut target, None);
        lp.dispatch(ui_core::Event::PointerReleased {
            pos: ui_core::geom::Point::new(100.0, 100.0),
            button: ui_core::PointerButton::Primary,
        });
        let mut peak = f32::MIN;
        for _ in 0..380 {
            lp.frame(&mut target, None);
            peak = peak.max(offset_y(&lp));
        }
        assert!(peak > 200.0, "the coast must reach past the edge, got {peak}");
        // Undamped this flick overshoots by 75; the band plus the scaled entry keep it near 30.
        // 不做阻尼时这一甩会过冲 75；橡皮筋加缩减的入口速度把它压到 30 左右。
        assert!(peak < 240.0, "and by a damped amount, got {peak}");
    }

    #[test]
    fn a_second_bounce_continues_from_the_coast_instead_of_the_last_resting_place() {
        // The spring is keyed by scroller id and reused across bounces; without a reset the
        // second one starts at the previous rest position, so the first frame snaps there.
        // 弹簧按滚动容器 id 复用；不重置时第二次回弹从上次的静止位置起步，
        // 第一帧因此跳到那里。
        let (mut lp, mut target) = tall(false, 400);
        let release = |lp: &mut AppLoop<Tall>| {
            lp.dispatch(ui_core::Event::PointerReleased {
                pos: ui_core::geom::Point::new(100.0, 100.0),
                button: ui_core::PointerButton::Primary,
            });
        };
        dragged(&mut lp, 190.0, 100.0);
        lp.frame(&mut target, None);
        release(&mut lp);
        for _ in 0..380 {
            lp.frame(&mut target, None);
        }
        assert_eq!(offset_y(&lp), 200.0, "the first flick settles on the far edge");
        dragged(&mut lp, 190.0, 100.0);
        lp.frame(&mut target, None);
        release(&mut lp);
        let before = offset_y(&lp);
        // The spring must be seeded at the offset the coast left, not at the previous rest
        // position: a leftover entry ignores the seed and the next frame snaps to it.
        // 弹簧必须以滑行留下的偏移为起点，而不是上次的静止位置：
        // 残留的条目会忽略起点，下一帧就跳到那里。
        let seeded = lp
            .anim_store
            .spring_value(Id::str("scroller").with("scroll-y"))
            .expect("the bounce seeds its spring")
            .x;
        assert!(
            (seeded - before).abs() < 0.01,
            "the spring starts at {before}, not at {seeded}"
        );
    }

    #[test]
    fn a_drag_control_inside_a_scroller_keeps_the_pointer() {
        // A slider or a draggable card must not pan the page it sits in.
        // 滑块或可拖卡片不得滚动它所在的页面。
        let (mut lp, mut target) = tall(true, 4);
        dragged(&mut lp, 20.0, 180.0);
        lp.frame(&mut target, None);
        assert_eq!(offset_y(&lp), 0.0, "the knob owns the drag, the scroller does not move");
    }

    #[test]
    fn the_wheel_walks_up_to_the_nearest_scrollable_ancestor() {
        // The hit lands on the row, but only the scroller moves: routing by the raw hit
        // target would report the row and the app would ignore it.
        // 命中落在行上，但只有滚动容器会动：按原始命中目标路由会上报行，app 会忽略它。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(ScrollTree { scrolled: Vec::new() });
        lp.frame(&mut target, None);
        lp.dispatch(ui_core::Event::wheel(
            ui_core::geom::Point::new(30.0, 10.0),
            10.0,
        ));
        assert_eq!(
            lp.app_mut().scrolled.last().map(|(id, _)| *id),
            Some(Id::str("scroller")),
            "the wheel must reach the container, not the row under it"
        );
    }

    #[test]
    fn the_wheel_reports_the_node_under_the_pointer() {
        // Scrolling is routed by identity like activation, so it must carry the right one
        // and must not invent one when the pointer is over nothing.
        // 滚动与激活一样按身份路由，因此必须带正确的 id，且指针不在任何节点上时不得凭空产生。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(Counting { activated: Vec::new(), scrolled: Vec::new(), expand: true, draggable: false });
        lp.frame(&mut target, None);

        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(50.0, 30.0),
        });
        assert!(
            lp.dispatch(ui_core::Event::wheel(
                ui_core::geom::Point::new(50.0, 30.0),
                -20.0,
            )),
            "a scroll the app accepted must ask for a repaint"
        );
        assert_eq!(lp.app_mut().scrolled, vec![(Id::str("bar"), -20.0)]);

        // Away from the bar the wheel reaches whatever is under it instead — here the
        // root container, which is what a scrollable page would be.
        // 离开那个盒子后，滚轮到达指针下的另一个节点——这里是根容器，
        // 也正是可滚动页面会是的东西。
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(150.0, 150.0),
        });
        lp.dispatch(ui_core::Event::wheel(
            ui_core::geom::Point::new(150.0, 150.0),
            -20.0,
        ));
        assert_eq!(lp.app_mut().scrolled.len(), 2);
        assert_ne!(
            lp.app_mut().scrolled[1].0,
            Id::str("bar"),
            "the wheel followed the pointer to a different node"
        );
    }

    #[test]
    fn spatial_score_prefers_the_same_band_over_a_smaller_gap() {
        // The rule GTK and Flutter share: a neighbour in your row wins even if another
        // candidate is closer but sits off-axis.
        // GTK 与 Flutter 共同的规则：同排的邻居胜出，即使另一个候选更近但在别的带里。
        let from = Rect::new(0.0, 0.0, 40.0, 40.0);
        let aligned_far = Rect::new(60.0, 0.0, 40.0, 40.0);
        let off_band_near = Rect::new(45.0, 60.0, 40.0, 40.0);
        let a = spatial_score(from, aligned_far, Direction::Right).expect("in direction");
        let b = spatial_score(from, off_band_near, Direction::Right).expect("in direction");
        assert_eq!(a.0, 0.0, "aligned candidate is in the band");
        assert_eq!(b.0, 1.0, "the other one is not");
        assert!(a.1 > b.1, "and it is genuinely farther: {a:?} vs {b:?}");
        // Lexicographic order still picks the aligned one.
        // 字典序仍然选对齐的那个。
        assert!(a < b, "{a:?} must sort before {b:?}");
    }

    #[test]
    fn spatial_score_rejects_what_is_not_in_the_direction() {
        // Behind, above, or overlapping-but-not-beyond must all be rejected.
        // 后方、上方、以及相交但未越过的候选都必须被拒绝。
        let from = Rect::new(40.0, 40.0, 40.0, 40.0);
        let behind = Rect::new(0.0, 40.0, 40.0, 40.0);
        let above = Rect::new(40.0, 0.0, 40.0, 40.0);
        let same = Rect::new(40.0, 40.0, 40.0, 40.0);
        assert!(spatial_score(from, behind, Direction::Right).is_none());
        assert!(spatial_score(from, above, Direction::Down).is_none());
        assert!(spatial_score(from, same, Direction::Right).is_none());
        // But it is in the direction once the centre is past ours.
        // 一旦中心越过，就算在该方向上。
        let overlapping_but_beyond = Rect::new(60.0, 40.0, 40.0, 40.0);
        assert!(spatial_score(from, overlapping_but_beyond, Direction::Right).is_some());
    }

    /// A scrollable container holding one row.
    /// 一个可滚动容器，内含一行。
    struct ScrollTree {
        scrolled: Vec<(Id, f32)>,
    }

    impl App for ScrollTree {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let decl = {
            Decl::container(Id::str("scroller"), NodeKind::Column)
                .size(ui_core::layout::SizeClass::fixed(100.0, 40.0))
                .scrollable()
                .background(Color::from_rgba8(30, 60, 110, 255), Corners::ZERO)
                .child(Decl {
                    id: Id::str("row"),
                    kind: NodeKind::Box,
                    shapes: vec![ui_core::draw::Shape::Box {
                        corners: ui_core::geom::Corners::ZERO,
                        fill: ui_core::geom::Color::WHITE,
                        gradient: None,
                        border: None,
                        shadow: None,
                        image: None,
                    }],
                    data: NodeData::Container(ui_core::tree::ContainerParams::default()),
                    size_class: ui_core::layout::SizeClass::fixed(100.0, 22.0),
                    ink_margin: Insets::ZERO,
                    box_model: Default::default(),
                    offset: ui_core::geom::Point::new(0.0, 0.0),
                    cursor: None,
                    sense: ui_core::Sense::NONE,
                    disabled: false,
            grid: ui_core::GridItem::default(),
            placement: ui_core::layout::Placement::default(),
            env: None,
                    children: Vec::new(),
                })
        };
    crate::from_decl(decl)
}
        fn changed(&mut self, id: Id, change: ui_core::change::Change) -> bool {
            if let ui_core::change::Change::Value(v) = change {
                self.scrolled.push((id, -v as f32));
            }
            true
        }
    }

    #[test]
    fn arrows_move_within_the_visual_grid() {
        // Direction semantics on a real layout. Geometry-vs-tree-order is pinned by
        // `spatial_score_*` instead: with a flow layout the two orders agree, so this
        // test could not tell them apart.
        // 真实布局上的方向语义。几何与树序之分由 `spatial_score_*` 钉住：
        // 流式布局下两者一致，这个测试无法区分。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(Grid);
        lp.frame(&mut target, None);
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Tab,
        });
        assert_eq!(lp.focused(), Some(Id::str("a")));
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Right,
        });
        assert_eq!(lp.focused(), Some(Id::str("b")), "right stays in the row");
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Left,
        });
        assert_eq!(lp.focused(), Some(Id::str("a")), "left returns");

        // Down moves to the row below, and stays in the same column.
        // Down 移到下一排，并保持在同一列。
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Down,
        });
        assert_eq!(lp.focused(), Some(Id::str("c")), "down keeps the column");
    }

    #[test]
    fn an_arrow_with_nothing_in_its_direction_does_not_move() {
        // `a` is the top-left cell: nothing is above it, and focus must not wrap.
        // a 在左上角：上方没有候选，且焦点不得环绕。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(Grid);
        lp.frame(&mut target, None);
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Tab,
        });
        let moved = lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Up,
        });
        assert!(!moved, "no candidate above, so nothing changes");
        assert_eq!(lp.focused(), Some(Id::str("a")));
    }

    #[test]
    fn tab_skips_a_layout_container_that_paints_nothing() {
        // The root is a Column: it is a hit target but has nothing to focus.
        // 根节点是 Column：它是命中目标，但没有可聚焦的内容。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(Demo {
            expand: false,
            draggable: true,
        });
        lp.frame(&mut target, None);
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Tab,
        });
        assert_eq!(
            lp.focused(),
            Some(Id::str("bar")),
            "the container must not be the first stop"
        );
    }

    #[test]
    fn a_drag_keeps_its_owner_after_the_pointer_leaves_the_control() {
        // Resolving the owner from the pointer loses the gesture as soon as it leaves the
        // control, and every family that gates on `dragging` snaps back.
        // 按指针解析归属，会在指针离开控件时丢掉手势，所有以 `dragging` 门控的家族都会弹回原位。
        struct Watch {
            dragging: Vec<bool>,
        }
        impl App for Watch {
            fn view(&mut self, f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
                self.dragging.push(f.dragging_within(Id::str("bar")));
                Demo {
                    expand: false,
                    draggable: true,
                }
                .view(f)
            }
        }

        let mut target = OffscreenTarget::new(200, 120);
        let mut lp = AppLoop::new(Watch {
            dragging: Vec::new(),
        });
        lp.frame(&mut target, None);

        let on_bar = ui_core::geom::Point::new(50.0, 30.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: on_bar,
            button: ui_core::PointerButton::Primary,
        });
        lp.frame(&mut target, Some(on_bar));
        assert!(*lp.app_mut().dragging.last().unwrap(), "pressed");

        // Far outside the bar, still holding the button: the gesture is still the bar's.
        // 远在长条之外、按钮仍按着：手势仍然属于长条。
        let outside = ui_core::geom::Point::new(190.0, 110.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: outside });
        lp.frame(&mut target, Some(outside));
        assert!(
            *lp.app_mut().dragging.last().unwrap(),
            "a drag outlives the pointer leaving its control"
        );
    }

    #[test]
    fn a_press_is_not_a_drag_until_the_pointer_travels() {
        // `dragging` is armed at the press so a control holds its value; a tap must not read
        // as a drag, or clicking a glass slider sends its thumb to the cursor.
        // `dragging` 在按下时即成立，供控件保持值；点击不得读作拖拽，
        // 否则点一下玻璃滑块，拇指就跳到光标处。
        struct Watch {
            armed: Vec<bool>,
            started: Vec<bool>,
        }
        impl App for Watch {
            fn view(&mut self, f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
                self.armed.push(f.dragging_within(Id::str("bar")));
                self.started.push(f.drag_started_within(Id::str("bar")));
                Demo {
                    expand: false,
                    draggable: true,
                }
                .view(f)
            }
        }

        let mut target = OffscreenTarget::new(200, 120);
        let mut lp = AppLoop::new(Watch {
            armed: Vec::new(),
            started: Vec::new(),
        });
        lp.frame(&mut target, None);

        let on_bar = ui_core::geom::Point::new(50.0, 30.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: on_bar,
            button: ui_core::PointerButton::Primary,
        });
        lp.frame(&mut target, Some(on_bar));
        assert!(*lp.app_mut().armed.last().unwrap(), "the press arms the gesture");
        assert!(!(*lp.app_mut().started.last().unwrap()), "a press alone is a tap");

        let moved = ui_core::geom::Point::new(on_bar.x + 20.0, on_bar.y);
        lp.dispatch(ui_core::Event::PointerMoved { pos: moved });
        lp.frame(&mut target, Some(moved));
        assert!(
            *lp.app_mut().started.last().unwrap(),
            "travelling past the threshold starts the drag"
        );
    }

    #[test]
    fn a_click_reports_the_pressed_node_but_a_drag_does_not() {
        // A click must reach `activate` with an identity, so an app never hit tests; a drag
        // must not, because it ends in `Dropped` instead.
        // 点击必须以身份到达 `activate`，app 因此不必命中测试；拖拽不得如此，它结束于 `Dropped`。
        let mut target = OffscreenTarget::new(200, 120);
        let mut lp = AppLoop::new(Counting {
            activated: Vec::new(),
            scrolled: Vec::new(),
            expand: false,
            draggable: true,
        });
        lp.frame(&mut target, None);

        let on_bar = ui_core::geom::Point::new(50.0, 30.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: on_bar,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos: on_bar,
            button: ui_core::PointerButton::Primary,
        });
        // The click is reported by the control after layout, not by the engine on release.
        // 点击由控件在布局之后上报，而不是引擎在松手时宣布。
        lp.frame(&mut target, Some(on_bar));
        assert_eq!(
            lp.app_mut().activated,
            vec![Id::str("bar")],
            "a click below the threshold activates the pressed node"
        );

        // The same press, but moved past the threshold: this is a drag, not a click.
        // 同样的按下，但移动越过阈值：这是拖拽，不是点击。
        lp.app_mut().activated.clear();
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: on_bar,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(on_bar.x + 20.0, on_bar.y),
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos: ui_core::geom::Point::new(on_bar.x + 20.0, on_bar.y),
            button: ui_core::PointerButton::Primary,
        });
        lp.frame(&mut target, Some(ui_core::geom::Point::new(on_bar.x + 20.0, on_bar.y)));
        assert!(
            lp.app_mut().activated.is_empty(),
            "a drag must not also count as a click: {:?}",
            lp.app_mut().activated
        );
    }

    #[test]
    fn a_press_that_travels_past_the_threshold_is_not_a_click_even_without_a_drag() {
        // A click-only node has no drag owner, so nothing else notices the pointer leaving:
        // without this rule, press → drag far away → release still activates the node the
        // pointer left behind.
        // 只订阅点击的节点没有拖拽所有者，别处不会察觉指针离开：缺了这条规则，
        // 按下 → 拖到很远 → 松手，仍会激活指针早已离开的节点。
        let mut target = OffscreenTarget::new(200, 120);
        let mut lp = AppLoop::new(Counting {
            activated: Vec::new(),
            scrolled: Vec::new(),
            expand: false,
            draggable: false,
        });
        lp.frame(&mut target, None);

        let on_bar = ui_core::geom::Point::new(50.0, 30.0);
        let far = ui_core::geom::Point::new(190.0, 110.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: on_bar,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerMoved { pos: far });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos: far,
            button: ui_core::PointerButton::Primary,
        });
        lp.frame(&mut target, Some(far));
        assert!(
            lp.app_mut().activated.is_empty(),
            "a press that left the node must not activate it: {:?}",
            lp.app_mut().activated
        );
    }

    #[test]
    fn a_release_far_from_the_press_is_not_a_click() {
        // A fast flick can deliver the release without a motion event in between; the path
        // still ends far from the press, so it is the same gesture, not a click.
        // 快速甩动可能只送来松手而没有中间的移动事件；路径终点仍远离按下点，
        // 因此它是同一个手势，而不是点击。
        let mut target = OffscreenTarget::new(200, 120);
        let mut lp = AppLoop::new(Counting {
            activated: Vec::new(),
            scrolled: Vec::new(),
            expand: false,
            draggable: false,
        });
        lp.frame(&mut target, None);

        let on_bar = ui_core::geom::Point::new(50.0, 30.0);
        let far = ui_core::geom::Point::new(190.0, 110.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: on_bar,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos: far,
            button: ui_core::PointerButton::Primary,
        });
        lp.frame(&mut target, Some(far));
        assert!(
            lp.app_mut().activated.is_empty(),
            "the release point is part of the pointer's path: {:?}",
            lp.app_mut().activated
        );
    }

    #[test]
    fn escape_cancels_the_drag_and_hands_the_gesture_back() {
        // `Cancelled` tells the app to restore its start state; a `dragging` that outlives
        // the cancel keeps every family gated on it frozen at the abandoned value.
        // `Cancelled` 要求 app 恢复起始状态；取消之后仍为真的 `dragging`
        // 会让所有以它为门控的家族停在被放弃的值上。
        struct Watch {
            dragging: Vec<bool>,
        }
        impl App for Watch {
            fn view(&mut self, f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
                self.dragging.push(f.dragging_within(Id::str("bar")));
                Demo {
                    expand: false,
                    draggable: true,
                }
                .view(f)
            }
        }

        let mut target = OffscreenTarget::new(200, 120);
        let mut lp = AppLoop::new(Watch {
            dragging: Vec::new(),
        });
        lp.frame(&mut target, None);

        let on_bar = ui_core::geom::Point::new(50.0, 30.0);
        let moved = ui_core::geom::Point::new(90.0, 30.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: on_bar,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerMoved { pos: moved });
        lp.frame(&mut target, Some(moved));
        assert!(*lp.app_mut().dragging.last().unwrap(), "a live drag");

        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Escape,
        });
        lp.frame(&mut target, Some(moved));
        assert!(
            !(*lp.app_mut().dragging.last().unwrap()),
            "the cancelled gesture must not keep the control"
        );
    }

    #[test]
    fn a_click_survives_an_event_before_the_next_frame() {
        // Events arrive in bursts between frames: the release, then a motion. A click is a
        // fact that lasts until a frame reads it, so a later event must not erase it first.
        // 事件在一帧之内成批到达：先松手，再移动。点击是「到下一帧为止」的事实，
        // 之后的事件不得在没有任何一帧读到它之前把它抹掉。
        let mut target = OffscreenTarget::new(200, 120);
        let mut lp = AppLoop::new(Counting {
            activated: Vec::new(),
            scrolled: Vec::new(),
            expand: false,
            draggable: false,
        });
        lp.frame(&mut target, None);

        let on_bar = ui_core::geom::Point::new(50.0, 30.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: on_bar,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos: on_bar,
            button: ui_core::PointerButton::Primary,
        });
        // The pointer twitches after the release, before anything has drawn.
        // 松手之后、还没画过一帧之前，指针抖了一下。
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(on_bar.x + 1.0, on_bar.y),
        });
        lp.frame(&mut target, Some(ui_core::geom::Point::new(on_bar.x + 1.0, on_bar.y)));
        assert_eq!(
            lp.app_mut().activated,
            vec![Id::str("bar")],
            "a click must survive the events that follow it"
        );
    }

    #[test]
    fn a_frame_sees_every_drag_step_since_the_last_frame() {
        // Several motion events can land between frames; a control accumulates `drag_step`,
        // so a frame must see their sum, not only the last slice.
        // 一帧之内可能落进多次移动事件；控件累加 `drag_step`，因此这一帧必须看到它们之和，
        // 而不是最后一小段。
        struct Watch {
            steps: Vec<Option<ui_core::geom::Point>>,
        }
        impl App for Watch {
            fn view(&mut self, f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
                self.steps.push(f.drag_step());
                Demo {
                    expand: false,
                    draggable: true,
                }
                .view(f)
            }
        }

        let mut target = OffscreenTarget::new(200, 120);
        let mut lp = AppLoop::new(Watch { steps: Vec::new() });
        lp.frame(&mut target, None);

        lp.dispatch(ui_core::Event::PointerPressed {
            pos: ui_core::geom::Point::new(20.0, 30.0),
            button: ui_core::PointerButton::Primary,
        });
        // The first move past the threshold starts the drag and carries no step.
        // 越过阈值的那一次移动开启拖拽，本身不带 step。
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(40.0, 30.0),
        });
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(60.0, 30.0),
        });
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(70.0, 30.0),
        });
        lp.frame(&mut target, Some(ui_core::geom::Point::new(70.0, 30.0)));
        assert_eq!(
            *lp.app_mut().steps.last().unwrap(),
            Some(ui_core::geom::Point::new(30.0, 0.0)),
            "40 -> 60 -> 70 is one frame's worth of movement"
        );
    }

    #[test]
    fn a_new_drag_does_not_inherit_the_previous_drags_step() {
        // Both gestures can fall inside one frame; the second must start from zero, or the
        // control jumps by however far the first one had travelled.
        // 两次手势可能落在同一帧里；第二次必须从零开始，否则控件会按第一次走过的距离跳一下。
        struct Watch {
            steps: Vec<Option<ui_core::geom::Point>>,
        }
        impl App for Watch {
            fn view(&mut self, f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
                self.steps.push(f.drag_step());
                Demo {
                    expand: false,
                    draggable: true,
                }
                .view(f)
            }
        }

        let mut target = OffscreenTarget::new(200, 120);
        let mut lp = AppLoop::new(Watch { steps: Vec::new() });
        lp.frame(&mut target, None);

        let press = ui_core::Event::PointerPressed {
            pos: ui_core::geom::Point::new(20.0, 30.0),
            button: ui_core::PointerButton::Primary,
        };
        let release = ui_core::Event::PointerReleased {
            pos: ui_core::geom::Point::new(60.0, 30.0),
            button: ui_core::PointerButton::Primary,
        };
        lp.dispatch(press.clone());
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(40.0, 30.0),
        });
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(60.0, 30.0),
        });
        lp.dispatch(release);

        lp.dispatch(press);
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(40.0, 30.0),
        });
        lp.frame(&mut target, Some(ui_core::geom::Point::new(40.0, 30.0)));
        assert_eq!(
            *lp.app_mut().steps.last().unwrap(),
            None,
            "the second drag has not moved yet"
        );
    }

    #[test]
    fn pressing_takes_focus_and_releasing_keeps_it() {
        let mut target = OffscreenTarget::new(200, 120);
        let mut lp = AppLoop::new(Demo {
            expand: false,
            draggable: true,
        });
        lp.frame(&mut target, None);

        let on_bar = ui_core::geom::Point::new(50.0, 30.0);
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: on_bar,
            button: ui_core::PointerButton::Primary,
        });
        assert_eq!(lp.pressed(), Some(Id::str("bar")));
        assert_eq!(lp.focused(), Some(Id::str("bar")));

        lp.dispatch(ui_core::Event::PointerReleased {
            pos: on_bar,
            button: ui_core::PointerButton::Primary,
        });
        assert_eq!(lp.pressed(), None, "release ends the press");
        assert_eq!(lp.focused(), Some(Id::str("bar")), "but not the focus");

        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Escape,
        });
        assert_eq!(lp.focused(), None, "escape releases focus");
    }
}

/// Direction an arrow key asks for.
/// 方向键请求的方向。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Direction {
    Left,
    Right,
    Up,
    Down,
}

/// How well `to` sits in `dir` from `from`, as (band miss, gap, misalignment).
/// `to` 相对 `from` 在 `dir` 方向上的合适程度，写作（错带, 间隙, 偏轴量）。
///
/// `None` means "not in that direction at all". Ordering is lexicographic, which encodes
/// the rule GTK and Flutter both use: stay in the current band if anything is there, then
/// take the smallest gap, then the best alignment.
/// `None` 表示「完全不在该方向」。按字典序比较，这正是 GTK 与 Flutter 共同的规则：
/// 同一带内优先，其次间隙最小，最后对齐最好。
fn spatial_score(from: Rect, to: Rect, dir: Direction) -> Option<(f32, f32, f32)> {
    let (a, b) = (from.center(), to.center());
    let (gap, misalign, band) = match dir {
        Direction::Right => (
            to.min_x() - from.max_x(),
            (b.y - a.y).abs(),
            to.min_y() < from.max_y() && to.max_y() > from.min_y(),
        ),
        Direction::Left => (
            from.min_x() - to.max_x(),
            (b.y - a.y).abs(),
            to.min_y() < from.max_y() && to.max_y() > from.min_y(),
        ),
        Direction::Down => (
            to.min_y() - from.max_y(),
            (b.x - a.x).abs(),
            to.min_x() < from.max_x() && to.max_x() > from.min_x(),
        ),
        Direction::Up => (
            from.min_y() - to.max_y(),
            (b.x - a.x).abs(),
            to.min_x() < from.max_x() && to.max_x() > from.min_x(),
        ),
    };
    // Overlapping rects have a negative gap: they are not "beyond" the current one, so
    // fall back to comparing centres. Without this a stacked layout would move nowhere.
    // 矩形相交时间隙为负，说明并未越过当前矩形，改用中心点比较。
    // 否则叠放布局会完全无法移动。
    let beyond = match dir {
        Direction::Right => b.x > a.x,
        Direction::Left => b.x < a.x,
        Direction::Down => b.y > a.y,
        Direction::Up => b.y < a.y,
    };
    if gap < 0.0 && !beyond {
        return None;
    }
    Some((
        if band { 0.0 } else { 1.0 },
        gap.max(0.0),
        misalign,
    ))
}

/// True when the node paints something a focus ring could attach to.
/// 当节点绘制了可承载焦点环的内容时返回 true。
fn node_paints(node: &ui_core::Node) -> bool {
    node.shapes.iter().any(|s| match s {
        ui_core::draw::Shape::Box {
            fill,
            gradient,
            border,
            image,
            ..
        } => fill.a > 0.0 || gradient.is_some() || border.is_some() || image.is_some(),
        _ => true,
    })
}

/// A Tab stop: it paints, or it declares the ring it paints once focused.
/// Tab 停靠点：自己会绘制，或声明了获得焦点时要画的焦点环。
///
/// A menu row rests on a transparent fill, so "paints nothing" would drop every command out
/// of the keyboard's reach; the declared ring is proof enough that it is a stop.
/// 菜单行静息时底色透明，只看「画了什么」会把每条命令都挤出键盘可达范围；
/// 声明了焦点环就足以证明它是一个停靠点。
fn focus_stop(node: &ui_core::Node) -> bool {
    node.data.params().is_some_and(|p| p.focus_stop)
        || node_paints(node)
        || matches!(node.kind, NodeKind::Text)
        || node
            .data
            .params()
            .is_some_and(|p| p.focus_visual.is_some())
}

/// The buffer as drawn: a live preedit is spliced in at the caret.
/// 绘制用的缓冲：组合进行中时，预编辑串插在插入符处。
fn composed_input(value: &str, preedit: Option<&ui_core::Preedit>, caret: usize) -> String {
    let Some(p) = preedit else {
        return value.to_owned();
    };
    let at = caret.min(value.len());
    format!("{}{}{}", &value[..at], p.text, &value[at..])
}

/// Corner shape this node clips and paints with; `Corners::ZERO` when it has none.
/// 本节点裁剪与绘制所用的圆角形状；没有时为 `Corners::ZERO`。
fn node_corners(node: &ui_core::Node) -> ui_core::Corners {
    // A declared curve wins: the shapes are what this frame happens to paint, and a hover
    // layer or a ripple outliving its state layer would otherwise move the curve.
    // 声明过的曲线优先：形状只是本帧碰巧画的东西，悬停层或活得比状态层久的涟漪
    // 否则会让曲线跟着变。
    if let Some(stated) = node.data.params().and_then(|p| p.corners) {
        return stated;
    }
    // The clip curve follows the node's own box shape; sub-shapes never clip children.
    // 裁剪曲线跟随节点自身的盒子形状；子形状从不裁剪子节点。
    node.shapes
        .iter()
        .find_map(|s| match s {
            ui_core::draw::Shape::Box { corners, .. } => Some(*corners),
            _ => None,
        })
        .unwrap_or(ui_core::Corners::ZERO)
}

/// The rect and curve of one painted shape, in the node's own space; a shadow has neither.
/// 一个已绘制形状在节点自身空间中的矩形与曲线；阴影没有这两样。
fn node_shape_rect(
    node: &ui_core::Node,
    visual: Rect,
    index: usize,
) -> Option<(Rect, ui_core::geom::Corners)> {
    match node.shapes.get(index)? {
        ui_core::draw::Shape::Box { corners, .. } => Some((
            Rect::from_origin_size(ui_core::geom::Point::ZERO, visual.size),
            *corners,
        )),
        ui_core::draw::Shape::Rect { rect, corners, .. } => Some((*rect, *corners)),
        ui_core::draw::Shape::Outline { corners, .. } => Some((
            Rect::from_origin_size(ui_core::geom::Point::ZERO, visual.size),
            *corners,
        )),
        // A shadow paints no box, and an arc is no mask for a ripple's ink.
        // 阴影没有盒子，弧也不适合作为涟漪墨迹的遮罩。
        ui_core::draw::Shape::Shadow { .. } | ui_core::draw::Shape::Sector { .. } => None,
    }
}

/// True when `ink` pokes out of `mask` by more than rounding noise.
/// 当 `ink` 超出 `mask` 超过取整噪声时返回 true。
///
/// `mask` is an accumulation of intersections, so it can be a hair smaller than the node's
/// own rect; treating that as overflow emits a useless clip and splits batches.
/// `mask` 是多次求交的累积结果，可能比节点自身矩形小一丝；
/// 把它当溢出会发出无用裁剪并拆散批处理。
fn exceeds(ink: Rect, mask: Rect) -> bool {
    const SLACK: f32 = 0.01;
    ink.min_x() < mask.min_x() - SLACK
        || ink.min_y() < mask.min_y() - SLACK
        || ink.max_x() > mask.max_x() + SLACK
        || ink.max_y() > mask.max_y() + SLACK
}

fn union_rect(a: Rect, b: Rect) -> Rect {
    if a.is_empty() {
        return b;
    }
    if b.is_empty() {
        return a;
    }
    let min_x = a.min_x().min(b.min_x());
    let min_y = a.min_y().min(b.min_y());
    let max_x = a.max_x().max(b.max_x());
    let max_y = a.max_y().max(b.max_y());
    Rect::new(min_x, min_y, max_x - min_x, max_y - min_y)
}

fn hash_rect(r: &Rect, h: &mut impl std::hash::Hasher) {
    use std::hash::Hash;
    r.origin.x.to_bits().hash(h);
    r.origin.y.to_bits().hash(h);
    r.size.w.to_bits().hash(h);
    r.size.h.to_bits().hash(h);
}

fn hash_color(c: &ui_core::geom::Color, h: &mut impl std::hash::Hasher) {
    use std::hash::Hash;
    for v in [c.r, c.g, c.b, c.a] {
        v.to_bits().hash(h);
    }
}

#[cfg(test)]
mod content_damage_tests {
    use super::*;
    use ui_core::Decl;
    use crate::present::OffscreenTarget;
    use ui_core::geom::{Color, Corners, Insets as InsetsT};
    use ui_core::layout::{AxisSize, Grow, SizeClass};

    /// Same geometry every frame, only the label text changes.
    /// 每帧几何相同，只有文案变化。
    struct Label {
        text: &'static str,
        color: Color,
    }

    fn text_node(id: &'static str, body: &'static str, color: Color) -> Decl {
        Decl {
            id: Id::str(id),
            kind: NodeKind::Text,
            shapes: Vec::new(),
            data: NodeData::Text {
                ink: color,
                block: ui_core::TextBlock::plain(body, ui_core::TextStyle::new(16.0)),
                caret: None,
                selection: None,
                composing: None,
                nowrap: false,
            },
            size_class: SizeClass {
                // Fixed box: a different label cannot change the geometry.
                // 固定盒：换文案不会改变几何。
                width: AxisSize::fixed(200.0),
                height: AxisSize::fixed(24.0),
                grow_x: Grow::No,
                grow_y: Grow::No,
            },
            ink_margin: InsetsT::ZERO,
            box_model: Default::default(),
            offset: ui_core::geom::Point::new(0.0, 0.0),
            cursor: None,
            sense: ui_core::Sense::NONE,
            disabled: false,
            grid: ui_core::GridItem::default(),
            placement: ui_core::layout::Placement::default(),
            env: None,
            children: Vec::new(),
        }
    }

    impl App for Label {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let decl = {
            Decl::container(Id::str("root"), NodeKind::Column)
                .background(Color::from_rgba8(20, 20, 24, 255), Corners::ZERO)
                .child(text_node("label", self.text, self.color))
        };
    crate::from_decl(decl)
}
}

    fn damage_is_none(outcome: &FrameOutcome) -> bool {
        outcome.damage.is_none()
    }

    #[test]
    fn identical_frames_produce_no_damage() {
        let mut target = OffscreenTarget::new(240, 60);
        let mut app = AppLoop::new(Label {
            text: "stable",
            color: Color::WHITE,
        });
        app.frame(&mut target, None);
        let second = app.frame(&mut target, None);
        assert!(
            damage_is_none(&second),
            "an unchanged frame must not repaint: {:?}",
            second.damage
        );
    }

    #[test]
    fn changing_only_the_text_dirties_the_node() {
        // Geometry is fixed, so a geometry-only damage check would miss this entirely.
        // 几何固定，所以只比几何的脏区判据会完全漏掉这次变化。
        let mut target = OffscreenTarget::new(240, 60);
        let mut app = AppLoop::new(Label {
            text: "aaaa",
            color: Color::WHITE,
        });
        app.frame(&mut target, None);
        app.app_mut().text = "bbbb";
        let changed = app.frame(&mut target, None);
        assert!(
            !damage_is_none(&changed),
            "a changed label must repaint even though the rect is identical"
        );
    }

    #[test]
    fn changing_only_the_colour_dirties_the_node() {
        let mut target = OffscreenTarget::new(240, 60);
        let mut app = AppLoop::new(Label {
            text: "same",
            color: Color::WHITE,
        });
        app.frame(&mut target, None);
        app.app_mut().color = Color::from_rgba8(255, 0, 0, 255);
        let changed = app.frame(&mut target, None);
        assert!(
            !damage_is_none(&changed),
            "a colour change with identical geometry must repaint"
        );
    }
}

#[cfg(test)]
mod layer_emission_tests {
    use super::*;
    use ui_core::Decl;
    use crate::present::OffscreenTarget;
    use ui_core::draw::Op;
    use ui_core::geom::{Color, Corners, Insets as InsetsT};
    use ui_core::layout::{AxisSize, Grow, SizeClass};

    fn white_box(id: &'static str) -> Decl {
        Decl {
            id: Id::str(id),
            kind: NodeKind::Box,
            shapes: vec![ui_core::draw::Shape::Box {
                corners: ui_core::geom::Corners::ZERO,
                fill: ui_core::geom::Color::WHITE,
                gradient: None,
                border: None,
                shadow: None,
                image: None,
            }],
            data: NodeData::Container(ui_core::tree::ContainerParams::default()),
            size_class: SizeClass {
                width: AxisSize::fixed(30.0),
                height: AxisSize::fixed(30.0),
                grow_x: Grow::No,
                grow_y: Grow::No,
            },
            ink_margin: InsetsT::ZERO,
            box_model: Default::default(),
            offset: ui_core::geom::Point::new(0.0, 0.0),
            cursor: None,
            sense: ui_core::Sense::NONE,
            disabled: false,
            grid: ui_core::GridItem::default(),
            placement: ui_core::layout::Placement::default(),
            env: None,
            children: Vec::new(),
        }
    }

    struct Faded {
        opacity: f32,
    }

    impl App for Faded {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let decl = {
            Decl::container(Id::str("root"), NodeKind::Column)
                .background(Color::from_rgba8(0, 0, 0, 255), Corners::ZERO)
                .child(
                    Decl::container(Id::str("group"), NodeKind::Row)
                        .opacity(self.opacity)
                        .child(white_box("a"))
                        .child(white_box("b")),
                )
        };
    crate::from_decl(decl)
}
}

    fn layer_count(list: &DrawList) -> usize {
        list.ops
            .iter()
            .filter(|op| matches!(op, Op::PushLayer(_)))
            .count()
    }

    struct Frosted;

    impl App for Frosted {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let decl = {
            Decl::container(Id::str("root"), NodeKind::Column)
                .background(Color::from_rgba8(0, 0, 0, 255), Corners::ZERO)
                .child(
                    Decl::container(Id::str("glass"), NodeKind::Box)
                        .size(ui_core::layout::SizeClass::fixed(80.0, 80.0))
                        .background(Color::from_rgba8(200, 200, 220, 120), Corners::all(8.0))
                        .backdrop_blur(6.0),
                )
        };
    crate::from_decl(decl)
}
}

    #[test]
    fn the_backdrop_blur_is_emitted_before_the_fill_it_frosts() {
        // Ordering is the whole contract: emit it after the fill and the node blurs its
        // own translucent box instead of the content behind it.
        // 顺序就是全部契约：若在填充之后发出，节点模糊的是自己那层半透明盒子而非背后的内容。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(Frosted);
        lp.frame(&mut target, None);
        let ops = &lp.draw_list().ops;
        let backdrop = ops.iter().position(|op| matches!(op, Op::Backdrop(_)));
        let last_rect = ops.iter().rposition(|op| matches!(op, Op::Prim(_)));
        let last_backdrop = ops.iter().rposition(|op| matches!(op, Op::Backdrop(_)));

        let b = backdrop.expect("a backdrop op must be emitted");
        let r = last_rect.expect("the glass fill must be emitted");
        assert!(b < r, "the backdrop must precede the fill it frosts");
        assert_eq!(last_backdrop, Some(b), "exactly one backdrop per node");
    }

    struct Canvas {
        frost: bool,
    }

    impl App for Canvas {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let mut canvas = Decl::container(Id::str("canvas"), NodeKind::Column)
                .size(ui_core::layout::SizeClass::fixed(100.0, 100.0))
                .offscreen()
                .child(white_box("inside"));
            if self.frost {
                canvas = canvas.child(
                    Decl::container(Id::str("frost"), NodeKind::Box)
                        .size(ui_core::layout::SizeClass::fixed(40.0, 40.0))
                        .backdrop_blur(4.0),
                );
            }
            crate::from_decl(
                Decl::container(Id::str("root"), NodeKind::Column)
                    .size(ui_core::layout::SizeClass::fixed(200.0, 200.0))
                    .child(canvas),
            )
        }
    }

    #[test]
    fn an_offscreen_subtree_reaches_the_renderer_as_one_cached_layer() {
        // The key is what lets the target outlive the frame; a layer without one is rebuilt
        // every frame, so caching it by bounds alone would freeze on the first stale subtree.
        // 键让目标跨帧存活；没有键的层每帧重建，只按边界缓存会在首次陈旧时把子树冻住。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(Canvas { frost: false });
        lp.frame(&mut target, None);
        let layers = &lp.draw_list().layers;
        assert_eq!(layers.len(), 1, "the canvas is the only layer");
        assert_eq!(layers[0].cache_key, Some(Id::str("canvas").as_u64()));
    }

    #[test]
    fn a_frost_inside_a_canvas_keeps_it_out_of_the_cache() {
        // The frost reads its parent, and a skipped frame paints no parent; caching the
        // subtree would freeze the frost the first time nothing inside it changed.
        // 磨砂读取父级，而跳过绘制的帧不画父级；缓存子树会在其内首次无变化时把磨砂冻住。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(Canvas { frost: true });
        lp.frame(&mut target, None);
        let layers = &lp.draw_list().layers;
        assert_eq!(layers.len(), 1, "the frost still composites as a group");
        assert_eq!(layers[0].cache_key, None, "a frost cannot ride a cache");
    }

    #[test]
    fn a_frost_is_cut_by_the_clip_that_cuts_its_box() {
        // A panel sliding inside its popup window is clipped at the window's edge; the
        // frost it asks for must stop there too, or it blurs the trigger it hangs from.
        // 在浮出窗口里滑动的面板被窗口边缘裁住；它所要求的磨砂也必须停在那里，
        // 否则会把挂靠的触发器一起模糊。
        struct FrostInClip;
        impl App for FrostInClip {
            fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
                let clipped = Decl::container(Id::str("window"), NodeKind::Column)
                    .size(ui_core::layout::SizeClass::fixed(40.0, 40.0))
                    .clip(ui_core::layout::Clip {
                        x: ui_core::layout::Overflow::Hidden,
                        y: ui_core::layout::Overflow::Hidden,
                    })
                    .child(
                        Decl::container(Id::str("panel"), NodeKind::Box)
                            .size(ui_core::layout::SizeClass::fixed(40.0, 80.0))
                            .backdrop_blur(6.0),
                    );
                crate::from_decl(
                    Decl::container(Id::str("root"), NodeKind::Column)
                        .size(ui_core::layout::SizeClass::fixed(200.0, 200.0))
                        .child(clipped),
                )
            }
        }
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(FrostInClip);
        lp.frame(&mut target, None);
        let list = lp.draw_list();
        let entry = list.backdrops.first().expect("one frost");
        assert_eq!(entry.rect.size.h, 80.0, "the box keeps its own height");
        assert_eq!(
            (entry.clip.origin.y, entry.clip.size.h),
            (0.0, 40.0),
            "the frost stops where the window cuts the panel"
        );
    }

    #[test]
    fn a_still_backdrop_node_claims_no_damage_of_its_own() {
        // A frost renders identically while nothing under it moves, so claiming damage
        // every frame would keep the loop awake for no visual reason.
        // 下方静止时磨砂渲染结果相同；每帧标脏会让循环白白空转。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(Frosted);
        lp.frame(&mut target, None);
        let second = lp.frame(&mut target, None);
        assert!(
            second.damage.is_none(),
            "a still frost must not request damage by itself"
        );
    }

    #[test]
    fn a_backdrop_node_inherits_damage_reaching_it_from_below() {
        // The case that washed the panel out: content under the frost changed, so the
        // frost's pixels changed even though its own declaration did not.
        // 面板褪色的那个案例：磨砂下方的内容变了，因此它的像素也变了，
        // 即使它自己的声明没变。
        let mut target = OffscreenTarget::new(240, 240);
        let mut lp = AppLoop::new(FrostOverMover { dx: 0.0, dy: 0.0 });
        lp.frame(&mut target, None);
        // Slide the block into the frost's kernel band (frost box starts at y=60) while
        // stopping short of the box itself, so only the pad connects them.
        // 让色块滑入磨砂的核读取带（磨砂盒从 y=60 开始）但止步于盒外，
        // 因此只有 pad 带能把两者联系起来。
        lp.app_mut().dy = 18.0;
        let out = lp.frame(&mut target, None);
        let rects = out.damage.rects(Rect::new(0.0, 0.0, 240.0, 240.0));
        let frost = Rect::new(0.0, 60.0, 80.0, 80.0);
        assert!(
            rects.iter().any(|r| r.intersection(frost).is_some()),
            "a change inside the kernel band must repaint the frost: {rects:?}"
        );
    }

    #[test]
    fn inherited_damage_never_extends_past_the_frost() {
        // The probe is widened by the kernel reach, but what gets painted is always
        // clipped back to the frost: painting outside it would be wasted work.
        // 求交用的探针会按核半径外延，但真正标脏的始终夹回磨砂矩形：
        // 画到外面只是白费功夫。
        let mut target = OffscreenTarget::new(240, 240);
        let mut lp = AppLoop::new(FrostOverMover { dx: 0.0, dy: 0.0 });
        lp.frame(&mut target, None);
        lp.app_mut().dx = 30.0;
        let out = lp.frame(&mut target, None);
        let rects = out.damage.rects(Rect::new(0.0, 0.0, 240.0, 240.0));
        let frost_rect = Rect::new(0.0, 0.0, 80.0, 80.0);
        // Every damaged rect must have some overlap with the mover or the frost; none may
        // be a slice that only the widened probe could have produced.
        // 每个脏矩形都必须与色块或磨砂有交集；不得出现只有外延探针才可能产生的片段。
        for r in &rects {
            let in_frost = r.intersection(frost_rect).is_some();
            let in_mover = r.intersection(Rect::new(0.0, 0.0, 70.0, 40.0)).is_some();
            assert!(
                in_frost || in_mover,
                "damage escaped both the frost and the mover: {r:?} in {rects:?}"
            );
        }
    }

    /// A frosted panel with a moving block underneath it.
    /// 一块磨砂面板，其下方有一个移动的色块。
    struct FrostOverMover {
        dx: f32,
        dy: f32,
    }

    impl App for FrostOverMover {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let decl = {
            Decl::container(Id::str("root"), NodeKind::Column)
                .background(Color::from_rgba8(0, 0, 0, 255), Corners::ZERO)
                .child(
                    Decl::container(Id::str("mover"), NodeKind::Box)
                        .offset(self.dx, self.dy)
                        .size(ui_core::layout::SizeClass::fixed(40.0, 40.0))
                        .background(Color::from_rgba8(255, 255, 255, 255), Corners::ZERO),
                )
                .child(
                    // Offset away from the mover so the two boxes do not touch: only the
                    // kernel's read distance can connect them.
                    // 用偏移把磨砂推离色块，使两个盒子互不相接：
                    // 只有卷积核的读取距离能把它们联系起来。
                    Decl::container(Id::str("frost"), NodeKind::Box)
                        .offset(0.0, 20.0)
                        .size(ui_core::layout::SizeClass::fixed(80.0, 80.0))
                        .background(Color::from_rgba8(200, 200, 220, 120), Corners::ZERO)
                        .backdrop_blur(3.0),
                )
        };
    crate::from_decl(decl)
}
}

    #[test]
    fn a_change_just_outside_the_frost_still_repaints_it() {
        // The kernel samples `radius` pixels around each output pixel, so a block that
        // stops short of the frost's own box still changes what the frost reads.
        // 卷积为每个输出像素采样周围 `radius` 个像素，因此止步于磨砂盒外的色块
        // 依然会改变磨砂读到的东西。
        let mut target = OffscreenTarget::new(240, 240);
        // The block sits above the frost and is shifted down by 60, so it lands partly in
        // the frost and partly in the pad band above it.
        // 色块位于磨砂上方，下移 60 后一部分落入磨砂、一部分落入其上方的 pad 带。
        let mut lp = AppLoop::new(FrostOverMover { dx: 0.0, dy: 0.0 });
        lp.frame(&mut target, None);
        lp.app_mut().dx = 0.0;
        lp.app_mut().dy = 60.0;
        let out = lp.frame(&mut target, None);
        let rects = out.damage.rects(Rect::new(0.0, 0.0, 240.0, 240.0));
        let frost = Rect::new(0.0, 0.0, 80.0, 80.0);
        assert!(
            rects.iter().any(|r| r.intersection(frost).is_some()),
            "a change reaching the frost's pad band must repaint the frost: {rects:?}"
        );
    }

    #[test]
    fn a_backdrop_carries_the_node_radius_and_kernel() {
        // A rectangular frost inside a rounded card leaves sharp corners of unblurred
        // content showing; the radius must travel with the blur.
        // 圆角卡片里的矩形模糊会在角落留下未模糊的锐利像素；圆角必须随模糊一起传下去。
        let mut target = OffscreenTarget::new(200, 200);
        let mut lp = AppLoop::new(Frosted);
        lp.frame(&mut target, None);
        let entry = lp.draw_list().backdrops.first().expect("one backdrop");
        assert_eq!(entry.radius, 18);
        assert_eq!(entry.sigma, 6.0);
        assert_eq!(entry.corners.tl, 8.0);
    }

    #[test]
    fn opacity_below_one_emits_a_layer() {
        let mut app = AppLoop::new(Faded { opacity: 0.5 });
        app.build((120, 60), None);
        assert_eq!(
            layer_count(app.draw_list()),
            1,
            "a 0.5 container must produce exactly one layer"
        );
    }

    #[test]
    fn opacity_one_emits_no_layer() {
        // Layer creation is a real cost; it must not happen for the common case.
        // 建层有真实开销；常见情况下不应发生。
        let mut app = AppLoop::new(Faded { opacity: 1.0 });
        app.build((120, 60), None);
        assert_eq!(
            layer_count(app.draw_list()),
            0,
            "an opaque container must not pay for a layer"
        );
    }

    #[test]
    fn layer_bounds_cover_the_whole_subtree() {
        let mut app = AppLoop::new(Faded { opacity: 0.5 });
        app.build((120, 60), None);
        let list = app.draw_list();
        let bounds = list
            .layers
            .first()
            .map(|l| l.bounds)
            .expect("one layer entry");
        // The two 30px boxes are side by side, so the layer must span both.
        // 两个 30px 方块并排，层必须覆盖两者。
        assert!(
            bounds.size.w >= 59.0,
            "layer must span both children, got {:?}",
            bounds
        );
    }

    #[test]
    fn group_opacity_keeps_overlaps_uniform_end_to_end() {
        // The whole pipeline: tree -> draw list -> CPU renderer. A grey group background
        // with a white child inside it gives two genuinely overlapping opaque rects.
        // 整条管线：树 -> 绘制列表 -> CPU 渲染器。灰色组背景 + 内部白色子节点，
        // 构成两个真正重叠的不透明矩形。
        //
        // Group opacity: both regions are 50% of their own colour (64 and 128).
        // Per-primitive alpha would darken the overlap to ~159 instead of 128.
        // 组不透明度：两处各是自己颜色的 50%（64 与 128）。
        // 逐图元 alpha 会把重叠处变成 ~159 而不是 128。
        struct Overlap;
        impl App for Overlap {
            fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
                let decl = {
                Decl::container(Id::str("root"), NodeKind::Column)
                    .background(Color::from_rgba8(0, 0, 0, 255), Corners::ZERO)
                    .child(
                        Decl::container(Id::str("group"), NodeKind::Column)
                            .opacity(0.5)
                            .background(Color::from_rgba8(128, 128, 128, 255), Corners::ZERO)
                            .padding(InsetsT::all(10.0))
                            .child(white_box("inner")),
                    )
            };
    crate::from_decl(decl)
}
        }

        let mut app = AppLoop::new(Overlap);
        let mut target = OffscreenTarget::new(200, 120);
        app.frame(&mut target, None);

        let pixels = &target.pixels;
        let luma = |x: u32, y: u32| {
            let i = ((y * pixels.width + x) * 4) as usize;
            // Premultiplied BGRA; the canvas is opaque so channels are final.
            pixels.data[i + 2]
        };

        let mut max = 0u8;
        let mut has_grey = false;
        for y in 0..pixels.height {
            for x in 0..pixels.width {
                let v = luma(x, y);
                if v > 40 {
                    max = max.max(v);
                    if (56..=72).contains(&v) {
                        has_grey = true;
                    }
                }
            }
        }
        assert!(has_grey, "the group background must show as ~50% grey (64)");
        assert!(
            (120..=136).contains(&max),
            "the overlap must be 50% of white (128), not per-primitive alpha (~159); got {max}"
        );
    }
}

#[cfg(test)]
mod sense_subscription_tests {
    use super::*;
    use crate::OffscreenTarget;
    use ui_core::geom::Color;
    use ui_core::layout::SizeClass;
    use ui_core::{Decl, Id, NodeData, NodeKind, Sense};

    /// Records what the engine reports, so each subscription bit can be asserted on.
    /// 记录引擎上报了什么，以便逐位断言。
    #[derive(Default)]
    struct Recorder {
        activated: Vec<Id>,
        scrolled: Vec<(Id, f32)>,
    }

    struct One {
        decl: Decl,
        rec: std::rc::Rc<std::cell::RefCell<Recorder>>,
    }

    impl App for One {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            crate::from_decl(self.decl.clone())
        }
        fn changed(&mut self, id: Id, change: ui_core::change::Change) -> bool {
            let mut rec = self.rec.borrow_mut();
            match change {
                ui_core::change::Change::Activated => rec.activated.push(id),
                ui_core::change::Change::Value(v) => rec.scrolled.push((id, v as f32)),
                _ => {}
            }
            true
        }
    }

    fn node(id: Id, sense: Sense, x: f32, y: f32, w: f32, h: f32) -> Decl {
        Decl {
            id,
            kind: NodeKind::Box,
            shapes: vec![ui_core::draw::Shape::Box {
                corners: ui_core::geom::Corners::ZERO,
                fill: ui_core::geom::Color::WHITE,
                gradient: None,
                border: None,
                shadow: None,
                image: None,
            }],
            data: NodeData::Container(ui_core::tree::ContainerParams::default()),
            size_class: SizeClass::fixed(w, h),
            ink_margin: Insets::ZERO,
            box_model: Default::default(),
            offset: ui_core::geom::Point::new(x, y),
            cursor: None,
            sense,
            disabled: false,
            grid: ui_core::GridItem::default(),
            placement: ui_core::layout::Placement::default(),
            env: None,
            children: Vec::new(),
        }
    }

    fn run(decl: Decl) -> (AppLoop<One>, std::rc::Rc<std::cell::RefCell<Recorder>>) {
        let rec = std::rc::Rc::new(std::cell::RefCell::new(Recorder::default()));
        let app = One {
            decl,
            rec: rec.clone(),
        };
        (AppLoop::new(app), rec)
    }

    /// A control that reports its own click, so the engine's job stays routing only.
    /// 自己上报点击的控件，引擎的职责因此只限于路由。
    struct ClickReporter {
        sense: Sense,
    }

    impl crate::Element for ClickReporter {
        fn decl(&self, _cx: &mut ui_core::cx::Cx<'_>) -> Decl {
            node(Id::str("go"), self.sense, 0.0, 0.0, 80.0, 40.0)
        }

        fn change(
            &self,
            state: &crate::WidgetState,
            _bounds: Rect,
        ) -> Option<ui_core::change::Change> {
            (state.clicked && !state.disabled).then_some(ui_core::change::Change::Activated)
        }
    }

    struct Clicks {
        sense: Sense,
        disabled: bool,
        rec: std::rc::Rc<std::cell::RefCell<Recorder>>,
    }

    impl App for Clicks {
        fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            Box::new(
                crate::Container::new(Id::str("root"), NodeKind::Column)
                    .disabled(self.disabled)
                    .child(Box::new(ClickReporter { sense: self.sense })),
            )
        }

        fn changed(&mut self, id: Id, change: ui_core::change::Change) -> bool {
            if let ui_core::change::Change::Activated = change {
                self.rec.borrow_mut().activated.push(id);
            }
            true
        }
    }

    fn click(lp: &mut AppLoop<Clicks>, target: &mut OffscreenTarget, at: ui_core::geom::Point) {
        lp.frame(target, Some(at));
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.dispatch(ui_core::Event::PointerPressed {
            button: ui_core::PointerButton::Primary,
            pos: at,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            button: ui_core::PointerButton::Primary,
            pos: at,
        });
        // The control speaks after layout, not during the event.
        // 控件在布局之后出声，而不是在事件进行中。
        lp.frame(target, Some(at));
    }

    /// A click reaches only a control that subscribes to clicks.
    /// 点击只会到达订阅了点击的控件。
    #[test]
    fn a_click_reports_only_from_a_node_that_subscribes_to_clicks() {
        let mut target = OffscreenTarget::new(200, 120);
        let at = ui_core::geom::Point::new(20.0, 20.0);

        let rec = std::rc::Rc::new(std::cell::RefCell::new(Recorder::default()));
        let mut lp = AppLoop::new(Clicks {
            sense: Sense::HOVER,
            disabled: false,
            rec: rec.clone(),
        });
        click(&mut lp, &mut target, at);
        assert!(
            rec.borrow().activated.is_empty(),
            "a hover-only node must not report a click"
        );

        let rec = std::rc::Rc::new(std::cell::RefCell::new(Recorder::default()));
        let mut lp = AppLoop::new(Clicks {
            sense: Sense::HOVER | Sense::CLICK,
            disabled: false,
            rec: rec.clone(),
        });
        click(&mut lp, &mut target, at);
        assert_eq!(
            rec.borrow().activated,
            vec![Id::str("go")],
            "a node that subscribes to clicks must report exactly one"
        );
    }

    /// A change handled during a frame lands after `view()` ran, so that frame paints the
    /// state before it. Without a follow-up frame the effect waits for an unrelated event.
    /// 帧内处理的变更发生在 `view()` 之后，该帧画的因而是变更前的状态。
    /// 没有后续帧，效果就要等一个无关事件才上屏。
    #[test]
    fn a_change_applied_mid_frame_asks_for_the_frame_that_shows_it() {
        let mut target = OffscreenTarget::new(200, 120);
        let at = ui_core::geom::Point::new(20.0, 20.0);
        let rec = std::rc::Rc::new(std::cell::RefCell::new(Recorder::default()));
        let mut lp = AppLoop::new(Clicks {
            sense: Sense::HOVER | Sense::CLICK,
            disabled: false,
            rec: rec.clone(),
        });
        lp.frame(&mut target, Some(at));
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.dispatch(ui_core::Event::PointerPressed {
            button: ui_core::PointerButton::Primary,
            pos: at,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            button: ui_core::PointerButton::Primary,
            pos: at,
        });
        // The clicks' own request: the change this frame applies has to earn its own.
        // 点击自身带来的请求：本帧应用的变更必须自己挣一个。
        assert!(lp.take_dispatched(), "a click asks for a frame");

        lp.frame(&mut target, Some(at));
        assert_eq!(rec.borrow().activated, vec![Id::str("go")], "the click landed");
        assert!(
            lp.take_dispatched(),
            "the frame that applies the change must ask for the one that shows it"
        );

        // A frame that applies nothing asks for nothing, or the loop never goes idle.
        // 什么都没应用的帧不提请求，否则循环永远闲不下来。
        lp.frame(&mut target, Some(at));
        assert!(!lp.take_dispatched(), "a quiet frame must not ask for another");
    }

    /// An inert subtree takes no click, no hover and no focus, whatever it declares.
    /// 惰性子树不接受点击、悬停与焦点，无论它自己声明了什么。
    #[test]
    fn an_inert_node_takes_no_click_and_is_no_tab_stop() {
        let mut target = OffscreenTarget::new(200, 120);
        let at = ui_core::geom::Point::new(20.0, 20.0);
        let rec = std::rc::Rc::new(std::cell::RefCell::new(Recorder::default()));
        let mut lp = AppLoop::new(Clicks {
            sense: Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE,
            disabled: true,
            rec: rec.clone(),
        });
        click(&mut lp, &mut target, at);
        assert!(rec.borrow().activated.is_empty(), "an inert subtree stays silent");
        assert_eq!(lp.hovered(), None, "and it must not take the hover either");

        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Tab,
        });
        lp.frame(&mut target, None);
        assert_eq!(lp.focused(), None, "nor may Tab reach into it");
    }

    /// Hover is a subscription: a node that never asked is never reported as hovered.
    /// 悬停是订阅：没订阅过的节点永远不会被报告为悬停。
    #[test]
    fn a_node_that_does_not_subscribe_to_hover_is_never_hovered() {
        let decl = Decl::container(Id::str("root"), NodeKind::Column)
            .child(node(Id::str("plain"), Sense::NONE, 0.0, 0.0, 80.0, 40.0));
        let (mut lp, _rec) = run(decl);
        let mut target = OffscreenTarget::new(200, 120);
        let at = ui_core::geom::Point::new(20.0, 20.0);
        lp.frame(&mut target, Some(at));
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.frame(&mut target, Some(at));
        assert_eq!(
            lp.hovered(),
            None,
            "a node with no hover subscription must not report itself hovered"
        );
    }

    /// Tab reaches a node only when it declares that it is focusable.
    /// 只有声明可聚焦的节点才会被 Tab 到达。
    #[test]
    fn tab_reaches_a_node_only_when_it_declares_focusable() {
        let plain = Decl::container(Id::str("root"), NodeKind::Column)
            .child(node(Id::str("plain"), Sense::HOVER, 0.0, 0.0, 80.0, 40.0));
        let (mut lp, _rec) = run(plain);
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Tab,
        });
        lp.frame(&mut target, None);
        assert_eq!(lp.focused(), None, "a hover-only node is not a keyboard stop");

        let focusable = Decl::container(Id::str("root"), NodeKind::Column)
            .child(node(
                Id::str("plain"),
                Sense::HOVER | Sense::FOCUSABLE,
                0.0,
                0.0,
                80.0,
                40.0,
            ));
        let (mut lp, _rec) = run(focusable);
        lp.frame(&mut target, None);
        lp.dispatch(ui_core::Event::KeyPressed {
            key: ui_core::Key::Tab,
        });
        lp.frame(&mut target, None);
        assert_eq!(
            lp.focused(),
            Some(Id::str("plain")),
            "a focusable node must be reachable with Tab"
        );
    }

    /// The border-only rects this node owns: the focus adorner, when it has one.
    /// 本节点拥有的纯描边矩形：有焦点装饰时就是它。
    fn ring_rects(lp: &AppLoop<One>, id: Id) -> Vec<(Rect, f32)> {
        let list = lp.draw_list();
        let mut out = Vec::new();
        for op in &list.ops {
            let ui_core::draw::Op::Prim(prim) = op else { continue };
            if prim.kind != PrimKind::Rect {
                continue;
            }
            let owner = list.owners.rects[prim.index as usize];
            if lp.tree.get(owner).map(|n| n.id) != Some(id) {
                continue;
            }
            let p = &list.prims.rects[prim.index as usize];
            if let Some((_, width)) = p.border
                && p.fill.a == 0.0 {
                    out.push((p.rect, width));
                }
        }
        out
    }

    #[test]
    fn a_focus_visual_is_drawn_outside_the_box_and_only_for_visible_focus() {
        // WinUI's adorner reaches 3 px past the control; a ring drawn on the edge would be a
        // different control. The engine, not the widget, knows the final rect.
        // WinUI 的焦点装饰伸出控件 3 像素；画在边缘是另一个控件。最终矩形只有引擎知道。
        let margin = ui_core::geom::Insets::all(-3.0);
        let control = node(Id::str("plain"), Sense::HOVER | Sense::FOCUSABLE, 0.0, 0.0, 80.0, 40.0)
            .focus_visual(Some(ui_core::draw::FocusVisual {
                outer: ui_core::geom::Color::rgba(1.0, 0.0, 0.0, 1.0),
                outer_width: 2.0,
                inner: ui_core::geom::Color::rgba(0.0, 0.0, 1.0, 1.0),
                inner_width: 1.0,
                margin,
                radius: 3.0,
            }));
        let (mut lp, _rec) = run(Decl::container(Id::str("root"), NodeKind::Column).child(control));
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        assert!(ring_rects(&lp, Id::str("plain")).is_empty(), "no focus, no ring");

        lp.dispatch(ui_core::Event::KeyPressed { key: ui_core::Key::Tab });
        lp.frame(&mut target, None);
        assert_eq!(lp.focused(), Some(Id::str("plain")), "Tab reaches the control");
        let rings = ring_rects(&lp, Id::str("plain"));
        assert_eq!(rings.len(), 2, "an outer and an inner stroke");
        let (outer, outer_w) = rings[0];
        assert_eq!(outer_w, 2.0);
        assert_eq!(outer.size.w, 86.0, "3 px past the box on each side");
        assert_eq!(outer.size.h, 46.0);
        assert_eq!(rings[1].1, 1.0, "the inner stroke is 1 px");
        assert_eq!(rings[1].0.size.w, 82.0, "and sits inside the outer one");
    }

    /// The sense bit is what turns a node into a pass-through hit target.
    /// 正是这个订阅位把节点变成透传的命中目标。
    #[test]
    fn a_pass_through_subscription_maps_to_the_pass_through_behavior() {
        assert_eq!(
            AppLoop::<One>::hit_behavior_of(NodeKind::Box, Sense::PASS_THROUGH, false),
            HitBehavior::PassThrough
        );
        assert_eq!(
            AppLoop::<One>::hit_behavior_of(NodeKind::Box, Sense::HOVER, false),
            HitBehavior::Opaque
        );
    }

    /// A control can subscribe to the wheel without setting the layout's overflow flag.
    /// 控件可以订阅滚轮，而无需设置布局的溢出标志。
    #[test]
    fn a_scroll_subscriber_receives_the_wheel_without_the_layout_flag() {
        let list = Decl::container(Id::str("list"), NodeKind::Column)
            .size(SizeClass::fixed(120.0, 80.0))
            .sense(Sense::SCROLL)
            .child(node(Id::str("row"), Sense::NONE, 0.0, 0.0, 120.0, 20.0));
        let decl = Decl::container(Id::str("root"), NodeKind::Column).child(list);
        let (mut lp, rec) = run(decl);
        let mut target = OffscreenTarget::new(200, 120);
        let at = ui_core::geom::Point::new(40.0, 10.0);
        lp.frame(&mut target, Some(at));
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.frame(&mut target, Some(at));
        lp.dispatch(ui_core::Event::wheel(at, -12.0));
        lp.frame(&mut target, Some(at));
        assert_eq!(
            rec.borrow().scrolled,
            vec![(Id::str("list"), 12.0)],
            "the wheel must land on the subscribing ancestor"
        );
    }

    #[test]
    fn a_scripted_step_does_not_let_the_wall_clock_rewind_time() {
        // A scripted frame jumps ahead of the wall clock; the next real frame must continue
        // from there. Rewinding instead freezes every running animation on handover.
        // 脚本帧会跳到墙钟前面；下一次真实帧必须从那里继续。若倒退，交接时所有在跑的动画都会冻住。
        let mut clock = FrameClock::default();
        clock.advance_by(30.0);
        let now = clock.tick();
        assert!(now >= 30.0, "tick rewound to {now} after a 30s scripted step");
    }

    const INK: Id = Id::str("ink");

    /// A 100x40 node at the origin that asks for ink of the given kind.
    /// 原点处 100x40、要求给定类型墨迹的节点。
    fn ink_node_with(radius: ui_core::InkRadius) -> Decl {
        node(INK, Sense::CLICK, 0.0, 0.0, 100.0, 40.0).press_ink(Some(ui_core::PressInk::new(
            Color::from_rgba8(0, 0, 0, 64),
            radius,
        )))
    }

    fn ink_node() -> Decl {
        ink_node_with(ui_core::InkRadius::Cover)
    }

    /// A node that paints no box at all: the text button's shape after its state layer left.
    /// 完全不画盒子的节点：文本按钮的状态层退去之后的形态。
    fn bare_ink_node(clip: ui_core::geom::Corners) -> Decl {
        Decl::container(INK, NodeKind::Box)
            .size(SizeClass::fixed(100.0, 40.0))
            .sense(Sense::CLICK)
            .press_ink(Some(ui_core::PressInk::new(
                Color::from_rgba8(0, 0, 0, 64),
                ui_core::InkRadius::Cover,
            )))
            .corners(clip)
    }

    /// The corners of the clip in force where the splat is painted, if the splat is painted.
    /// 墨迹绘制处生效的裁剪圆角；未绘制墨迹时为 `None`。
    fn splat_clip(lp: &AppLoop<One>) -> Option<ui_core::geom::Corners> {
        splat_clip_entry(lp).map(|e| e.corners)
    }

    /// The clip entry in force where the splat is painted, rect and curve together.
    /// 墨迹绘制处生效的裁剪条目，矩形与曲线一起。
    fn splat_clip_entry(lp: &AppLoop<One>) -> Option<ui_core::draw::ClipEntry> {
        let list = &lp.resolved;
        let mut clips = Vec::new();
        for op in &list.ops {
            match op {
                ui_core::draw::Op::PushClip(i) => {
                    clips.push(*list.clips.get(*i as usize)?)
                }
                ui_core::draw::Op::PopClip => {
                    clips.pop()?;
                }
                ui_core::draw::Op::Prim(prim) if prim.kind == PrimKind::Rect => {
                    let p = &list.prims.rects[prim.index as usize];
                    let black = p.fill.r == 0.0 && p.fill.g == 0.0 && p.fill.b == 0.0;
                    // The node's own box is white, so anything dark here is the splat.
                    // 节点自身的盒子是白色，因此这里的暗色就是墨迹。
                    if black && lp.tree.get(list.owners.rects[prim.index as usize])?.id == INK {
                        return clips.last().copied();
                    }
                }
                _ => {}
            }
        }
        None
    }

    #[test]
    fn a_declared_press_outline_survives_a_frame_that_paints_no_container() {
        // The outline the ink is clipped to is the control's claim, not a by-product of which
        // box it happened to paint: pointer out while still held must not square off the pill.
        // 墨迹裁剪所依据的轮廓是控件的主张，而不是它恰好画了哪个盒子的副产品：
        // 按住不动、指针移出时，胶囊不得变方。
        let (mut lp, _rec) = run(bare_ink_node(ui_core::geom::Corners::all(20.0)));
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(90.0, 35.0);
        press(&mut lp, at);
        // The pointer leaves, the press does not: this is the frame that used to lose the clip.
        // 指针移出而按下仍在：这一帧过去会丢掉裁剪。
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(150.0, 35.0),
        });
        lp.build_with_dt((200, 120), Some(ui_core::geom::Point::new(150.0, 35.0)), 0.30);
        assert!(
            ink_circles(&lp).len() == 1,
            "a held press still paints its ink after the pointer leaves"
        );
        let corners = splat_clip(&lp).expect("the ink node clips to its outline");
        assert_eq!(
            (corners.tl, corners.tr, corners.br, corners.bl),
            (20.0, 20.0, 20.0, 20.0),
            "the pill the control declared, whatever the node paints: {corners:?}"
        );
    }

    /// The clip the ink's batch carries, which is what the renderer actually applies.
    /// 墨迹批次携带的裁剪——渲染器实际应用的就是它。
    fn splat_batch_clip(lp: &AppLoop<One>) -> Option<ui_core::geom::Corners> {
        let list = &lp.resolved;
        for batch in list.plan_batches() {
            if batch.kind != PrimKind::Rect {
                continue;
            }
            for index in batch.range {
                let p = &list.prims.rects[index as usize];
                let black = p.fill.r == 0.0 && p.fill.g == 0.0 && p.fill.b == 0.0;
                if black && lp.tree.get(list.owners.rects[index as usize])?.id == INK {
                    return batch.clip.map(|c| c.corners);
                }
            }
        }
        None
    }

    #[test]
    fn a_square_mask_over_the_node_does_not_square_off_its_declared_curve() {
        // A node with children clips its subtree to a mask that can be a hair smaller than
        // itself; the batch then takes the mask's rect, so the mask must carry the curve too.
        // 有子节点的节点会按一道遮罩裁剪子树，遮罩可能比自己小一丝；批次取的是遮罩的矩形，
        // 因此遮罩也必须带上这条曲线。
        let ink = bare_ink_node(ui_core::geom::Corners::all(20.0)).child(
            Decl::container(Id::str("label"), NodeKind::Box).size(SizeClass::fixed(10.0, 10.0)),
        );
        // 38 tall under a 40-tall child: the mask is the smaller rect, as in a real button
        // whose row is one line box short of it.
        // 38 高、子节点 40 高：遮罩成了较小的那个矩形，正如真实按钮所在的行比它矮一截。
        let root = Decl::container(Id::str("root"), NodeKind::Column)
            .size(SizeClass::fixed(200.0, 38.0))
            .child(ink);
        let (mut lp, _rec) = run(root);
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        press(&mut lp, ui_core::geom::Point::new(40.0, 10.0));
        lp.build_with_dt((200, 120), Some(ui_core::geom::Point::new(40.0, 10.0)), 0.30);
        let corners = splat_batch_clip(&lp).expect("the ink is drawn in a batch");
        assert_eq!(
            (corners.tl, corners.tr, corners.br, corners.bl),
            (20.0, 20.0, 20.0, 20.0),
            "the curve survives the mask: {corners:?}"
        );
    }

    #[test]
    fn a_rounded_node_cut_by_its_parent_keeps_its_uncut_box_for_the_corners() {
        // A card wider than its clipping parent keeps its corners on its own uncut box:
        // the batch narrows the rect to the cut, but the cut edge stays square.
        // 比裁切父容器宽的卡片把圆角留在自己未裁切的盒子上：
        // 批次把矩形收窄到切口，切口保持方角。
        let card = Rect::new(0.0, 0.0, 100.0, 100.0);
        let root = Decl::container(Id::str("root"), NodeKind::Column)
            .size(SizeClass::fixed(60.0, 120.0))
            .clip(ui_core::layout::Clip {
                x: ui_core::layout::Overflow::Hidden,
                y: ui_core::layout::Overflow::Hidden,
            })
            .child(
                Decl::container(Id::str("card"), NodeKind::Column)
                    .size(SizeClass::fixed(100.0, 100.0))
                    .background(Color::from_rgba8(200, 40, 40, 255), ui_core::geom::Corners::all(20.0))
                    .child(
                        Decl::container(Id::str("inner"), NodeKind::Box)
                            .size(SizeClass::fixed(100.0, 100.0)),
                    ),
            );
        let (mut lp, _rec) = run(root);
        let mut target = OffscreenTarget::new(120, 160);
        lp.frame(&mut target, None);

        let clip = lp
            .resolved
            .plan_batches()
            .iter()
            .find_map(|b| b.clip)
            .expect("the card is cut by its parent");
        assert_eq!(
            (clip.rect.origin.x, clip.rect.origin.y, clip.rect.size.w, clip.rect.size.h),
            (0.0, 0.0, 60.0, 100.0),
            "the rect is cut to the parent"
        );
        assert_eq!(
            (clip.shape.origin.x, clip.shape.origin.y, clip.shape.size.w, clip.shape.size.h),
            (card.origin.x, card.origin.y, card.size.w, card.size.h),
            "the corners still belong to the uncut card"
        );
        assert_eq!(clip.corners, ui_core::geom::Corners::all(20.0));
    }

    /// A parent node whose ink is clipped to a named indicator child: the navigation
    /// bar's destination, where the capsule behind the icon is the effective background.
    /// 墨迹被裁到命名指示片子节点的父节点：导航栏目标，图标后的胶囊即有效背景。
    fn ink_clipped_to_indicator() -> Decl {
        let indicator = Id::str("indicator");
        let parent = Decl::container(INK, NodeKind::Column)
            .size(SizeClass::fixed(100.0, 40.0))
            .sense(Sense::CLICK)
            .press_ink(Some(ui_core::PressInk::with_target(
                Color::from_rgba8(0, 0, 0, 64),
                ui_core::InkRadius::Cover,
                ui_core::InkTarget::Descendant(indicator),
            )))
            .child(
                Decl::container(indicator, NodeKind::Box)
                    .size(SizeClass::fixed(20.0, 32.0))
                    // Left of centre: the indicator is the effective background, so the
                    // splash must settle on its centre, not the parent's.
                    // 偏左：指示片是有效背景，墨迹必须落在它的中心，而不是父节点的。
                    .offset(30.0, 4.0),
            );
        Decl::container(Id::str("root"), NodeKind::Column)
            .size(SizeClass::fixed(200.0, 60.0))
            .child(parent)
    }

    /// A node whose first painted shape is a smaller rect than its own box: the ripple's
    /// effective background is that shape, not the node's whole box.
    /// 第一个绘制形状比自身盒子小的节点：涟漪的有效背景是该形状，而不是整个节点盒子。
    fn ink_clipped_to_its_first_shape() -> Decl {
        Decl::container(INK, NodeKind::Column)
            .size(SizeClass::fixed(100.0, 40.0))
            .sense(Sense::CLICK)
            .press_ink(Some(ui_core::PressInk::with_target(
                Color::from_rgba8(0, 0, 0, 64),
                ui_core::InkRadius::Cover,
                ui_core::InkTarget::Shape(0),
            )))
            .shapes(vec![ui_core::draw::Shape::Rect {
                rect: Rect::new(30.0, 4.0, 20.0, 32.0),
                corners: ui_core::geom::Corners::all(10.0),
                fill: Color::from_rgba8(200, 40, 40, 255),
                gradient: None,
                border: None,
            }])
    }

    #[test]
    fn the_ink_clips_to_the_shape_it_names_not_the_node_box() {
        // `InkTarget::Shape` takes the rect and curve from that painted shape; the splash
        // is cut to it instead of the node's box.
        // `InkTarget::Shape` 从该绘制形状取矩形与曲线；墨迹裁到它，而不是节点盒子。
        let (mut lp, _rec) = run(ink_clipped_to_its_first_shape());
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        press(&mut lp, ui_core::geom::Point::new(50.0, 20.0));
        lp.build_with_dt((200, 120), Some(ui_core::geom::Point::new(50.0, 20.0)), 0.30);
        let entry = splat_clip_entry(&lp).expect("the ink is clipped to its shape");
        assert_eq!(
            (entry.rect.origin.x, entry.rect.origin.y, entry.rect.size.w, entry.rect.size.h),
            (30.0, 4.0, 20.0, 32.0),
            "the clip follows the named shape, not the 100x40 node: {:?}",
            entry.rect
        );
        assert_eq!(entry.corners, ui_core::geom::Corners::all(10.0));
    }

    /// A node that states its effective background as an explicit rect and paints nothing.
    /// 把有效背景声明为显式矩形、自身不画任何东西的节点。
    fn ink_clipped_to_a_declared_rect() -> Decl {
        Decl::container(INK, NodeKind::Column)
            .size(SizeClass::fixed(100.0, 40.0))
            .sense(Sense::CLICK)
            .press_ink(Some(ui_core::PressInk::with_target(
                Color::from_rgba8(0, 0, 0, 64),
                ui_core::InkRadius::Cover,
                ui_core::InkTarget::Rect {
                    rect: Rect::new(30.0, 4.0, 20.0, 32.0),
                    corners: ui_core::geom::Corners::all(16.0),
                },
            )))
    }

    #[test]
    fn a_declared_background_clips_the_ink_even_when_the_node_paints_nothing() {
        // The slot is stated, not inferred from what this frame happens to paint: an
        // unselected row paints no fill and still offers a capsule for the splash.
        // 槽位是声明出来的，而不是从本帧碰巧画了什么推断：未选中的行不画填充，
        // 仍提供胶囊给水花。
        let (mut lp, _rec) = run(ink_clipped_to_a_declared_rect());
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        press(&mut lp, ui_core::geom::Point::new(50.0, 20.0));
        lp.build_with_dt((200, 120), Some(ui_core::geom::Point::new(50.0, 20.0)), 0.30);
        let entry = splat_clip_entry(&lp).expect("the ink is clipped to the declared slot");
        assert_eq!(
            (entry.rect.origin.x, entry.rect.origin.y, entry.rect.size.w, entry.rect.size.h),
            (30.0, 4.0, 20.0, 32.0),
            "the clip is the declared rect, not the 100x40 node: {:?}",
            entry.rect
        );
        assert_eq!(entry.corners, ui_core::geom::Corners::all(16.0));
    }

    #[test]
    fn the_ink_clips_to_its_effective_background_instead_of_the_whole_node() {
        // A navigation destination's ripple covers the indicator capsule, not the whole
        // item: the clip is the child the control named, resolved per frame.
        // 导航目标的涟漪盖住指示胶囊，而不是整个条目：裁剪目标是控件命名的子节点，
        // 每帧解析。
        let (mut lp, _rec) = run(ink_clipped_to_indicator());
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        press(&mut lp, ui_core::geom::Point::new(80.0, 20.0));
        lp.build_with_dt((200, 120), Some(ui_core::geom::Point::new(80.0, 20.0)), 0.30);
        let entry = splat_clip_entry(&lp).expect("the ink is clipped");
        assert_eq!(
            (entry.rect.origin.x, entry.rect.origin.y, entry.rect.size.w, entry.rect.size.h),
            (30.0, 4.0, 20.0, 32.0),
            "the clip follows the indicator, not the 100x40 parent: {:?}",
            entry.rect
        );
    }

    #[test]
    fn a_clipped_ink_is_a_disc_around_the_effective_background_centre_not_the_node() {
        // The reference box moves with the clip: the splash drifts to the indicator's
        // centre (60, 20) and its final radius covers the indicator, so after settling the
        // circle is a disc the size of the indicator's diagonal, not the parent's.
        // 参考框跟着裁剪走：墨迹漂到指示片中心 (60, 20)，终点半径盖住指示片；
        // 落定后墨迹是沿指示片对角线的圆，而不是沿父节点的。
        let (mut lp, _rec) = run(ink_clipped_to_indicator());
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        press(&mut lp, ui_core::geom::Point::new(80.0, 20.0));
        lp.build_with_dt((200, 120), Some(ui_core::geom::Point::new(80.0, 20.0)), 0.30);
        let ink = ink_circles(&lp);
        assert_eq!(ink.len(), 1);
        let (rect, _) = ink[0];
        let (cx, cy) = (rect.origin.x + rect.size.w * 0.5, rect.origin.y + rect.size.h * 0.5);
        // Drifted to the indicator centre: a 20x32 indicator at (30, 4) has its centre at
        // (40, 20), left of the parent's (50, 20) — the telling distinction.
        // 漂到指示片中心：位于 (30, 4) 的 20x32 指示片其中心在 (40, 20)，
        // 在父节点中心 (50, 20) 的左边——这正是要区分的点。
        let want_cx = 40.0;
        let want_cy = 20.0;
        assert!(
            (cx - want_cx).abs() < 1.5 && (cy - want_cy).abs() < 1.5,
            "the splash settles on the indicator centre, not the parent's: ({cx:.1}, {cy:.1})"
        );
        let half_diag = (20.0_f32 * 20.0 + 32.0 * 32.0).sqrt() * 0.5;
        assert!(
            (rect.size.w * 0.5 - half_diag).abs() < 2.0,
            "the radius matches the indicator diagonal, not the 100x40 parent's: {}",
            rect.size.w * 0.5
        );
    }

    #[test]
    fn a_modal_owns_the_keyboard_so_tab_cannot_walk_out_of_it() {
        // A scrim that only blocks the pointer leaves Tab and Enter reaching the controls it
        // covers, which makes the modal a picture rather than a mode.
        // 只挡指针的遮罩会让 Tab 与 Enter 到达它所覆盖的控件，模态就成了一张画而不是一种模式。
        let root = Decl::container(Id::str("root"), NodeKind::Column)
            .size(SizeClass::fixed(200.0, 200.0))
            .child(node(Id::str("behind"), Sense::FOCUSABLE, 0.0, 0.0, 40.0, 40.0))
            .child(
                Decl::container(Id::str("modal"), NodeKind::Box)
                    .size(SizeClass::fixed(200.0, 200.0))
                    .modal(ui_core::ModalTarget::Global)
                    .child(node(Id::str("inside"), Sense::FOCUSABLE, 0.0, 0.0, 40.0, 40.0))
                    .child(node(Id::str("also-inside"), Sense::FOCUSABLE, 0.0, 0.0, 40.0, 40.0)),
            );
        let (mut lp, _rec) = run(root);
        let mut target = OffscreenTarget::new(200, 200);
        lp.frame(&mut target, None);
        let tab = || ui_core::Event::KeyPressed { key: ui_core::Key::Tab };
        // The modal takes focus as it opens, so the ring is already inside before any Tab.
        // 模态打开时即接管焦点，因此尚未按 Tab，焦点环就已经在它里面。
        assert_eq!(lp.focused(), Some(Id::str("inside")), "the modal owns the keyboard");
        lp.dispatch(tab());
        assert_eq!(lp.focused(), Some(Id::str("also-inside")), "Tab moves within it");
        lp.dispatch(tab());
        assert_eq!(lp.focused(), Some(Id::str("inside")), "and wraps inside it, never out");
        lp.dispatch(tab());
        assert_eq!(lp.focused(), Some(Id::str("also-inside")), "never reaching what it covers");
    }

    #[test]
    fn a_modal_takes_the_pointer_from_the_controls_it_covers() {
        // The walk defers a modal subtree, and hit z comes from the same order: the scrim is
        // then the topmost thing under the pointer, not the node painted under it.
        // 遍历把模态子树推后，而命中 z 出自同一顺序：遮罩因此是指针之下最靠上的东西，
        // 而不是画在它下面的那个节点。
        let root = Decl::container(Id::str("root"), NodeKind::Column)
            .size(SizeClass::fixed(200.0, 200.0))
            .child(node(Id::str("behind"), Sense::CLICK, 0.0, 0.0, 40.0, 40.0))
            .child(
                Decl::container(Id::str("modal"), NodeKind::Box)
                    .size(SizeClass::fixed(200.0, 200.0))
                    .sense(Sense::CLICK)
                    .modal(ui_core::ModalTarget::Global),
            );
        let (mut lp, _rec) = run(root);
        let mut target = OffscreenTarget::new(200, 200);
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(10.0, 10.0);
        press(&mut lp, at);
        lp.build_with_dt((200, 200), Some(at), 0.05);
        assert_eq!(lp.pressed(), Some(Id::str("modal")), "the scrim takes the press");
    }

    /// The order the given ids' rects appear in the resolved list; unknown ids are skipped.
    /// 这些 id 的矩形在已解析列表里出现的先后顺序；不认识的 id 跳过。
    fn rect_order(lp: &AppLoop<One>, ids: &[Id]) -> Vec<Id> {
        let list = &lp.resolved;
        let mut out = Vec::new();
        for i in 0..list.prims.rects.len() {
            let Some(node) = lp.tree.get(list.owners.rects[i]) else {
                continue;
            };
            if ids.contains(&node.id) && !out.contains(&node.id) {
                out.push(node.id);
            }
        }
        out
    }

    #[test]
    fn a_modal_paints_last_as_well_as_hitting_last() {
        // Hit z comes from `walk`, which defers modal subtrees; paint used to recurse the
        // child list in place, so a modal declared before its siblings was clickable while
        // drawn under them. The two orders must be one order.
        // 命中 z 来自会推后模态子树的 `walk`；而绘制过去就地把子节点列表递归下去，
        // 于是声明在兄弟之前的模态能点却画在下面。两个顺序必须是同一个顺序。
        let root = Decl::container(Id::str("root"), NodeKind::Column)
            .size(SizeClass::fixed(200.0, 200.0))
            .child(
                node(Id::str("modal"), Sense::NONE, 0.0, 0.0, 200.0, 200.0)
                    .modal(ui_core::ModalTarget::Global),
            )
            .child(node(Id::str("later"), Sense::NONE, 0.0, 0.0, 40.0, 40.0));
        let (mut lp, _rec) = run(root);
        let mut target = OffscreenTarget::new(200, 200);
        lp.frame(&mut target, None);
        let ids = [Id::str("later"), Id::str("modal")];
        assert_eq!(
            rect_order(&lp, &ids),
            vec![Id::str("later"), Id::str("modal")],
            "the modal is painted after the sibling declared after it"
        );
    }

    #[test]
    fn with_no_declared_outline_the_ink_clips_to_the_box_being_painted() {
        // The fallback must keep working, or every container that only states a background
        // would lose the clipping it has always had.
        // 回落路径必须继续有效，否则那些只声明了背景的容器会丢掉一直存在的裁剪。
        let (mut lp, _rec) = run(ink_node());
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(40.0, 10.0);
        press(&mut lp, at);
        lp.build_with_dt((200, 120), Some(at), 0.30);
        assert_eq!(
            splat_clip(&lp),
            Some(ui_core::geom::Corners::ZERO),
            "the white box this node paints has square corners"
        );
    }

    /// The splat circles painted on `id`, as rect and fill; the node's own box is white.
    /// 画在 `id` 上的墨迹圆（矩形与填充）；节点自身的盒子是白色。
    fn ink_circles(lp: &AppLoop<One>) -> Vec<(Rect, Color)> {
        let list = &lp.resolved;
        let mut out = Vec::new();
        for op in &list.ops {
            let ui_core::draw::Op::Prim(prim) = op else { continue };
            if prim.kind != PrimKind::Rect {
                continue;
            }
            let i = prim.index as usize;
            let Some(node) = lp.tree.get(list.owners.rects[i]) else { continue };
            let p = &list.prims.rects[i];
            let black_ink = p.fill.r == 0.0 && p.fill.g == 0.0 && p.fill.b == 0.0;
            if node.id == INK && black_ink {
                out.push((p.rect, p.fill));
            }
        }
        out
    }

    fn press(lp: &mut AppLoop<One>, at: ui_core::geom::Point) {
        lp.dispatch(ui_core::Event::PointerPressed {
            button: ui_core::PointerButton::Primary,
            pos: at,
        });
    }

    #[test]
    fn the_splat_starts_where_the_press_landed() {
        // The whole point of engine-owned ink: it knows the press point, which a control's
        // pure `decl` cannot remember. Starting at the node centre would put it at (50, 20).
        // 引擎持有墨迹的全部意义：它知道按下点，而控件的纯 `decl` 记不住。
        // 若从节点中心起步，圆心会落在 (50, 20)。
        let (mut lp, _rec) = run(ink_node());
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(40.0, 10.0);
        press(&mut lp, at);
        // One 8ms frame in: the drift towards the centre has barely begun.
        // 走一帧 8ms：朝中心的漂移才刚开始。
        lp.build_with_dt((200, 120), Some(at), 0.008);
        let ink = ink_circles(&lp);
        assert_eq!(ink.len(), 1, "one press, one splat");
        let (rect, colour) = ink[0];
        let (cx, cy) = (rect.origin.x + rect.size.w / 2.0, rect.origin.y + rect.size.h / 2.0);
        let from_press = ((cx - at.x).powi(2) + (cy - at.y).powi(2)).sqrt();
        assert!(from_press < 2.0, "the splat begins at the press point, not {rect:?}");
        assert!(rect.size.w > 0.0, "the splat has begun to grow");
        assert!(colour.a > 0.0, "and it has begun to fade in");
    }

    #[test]
    fn a_covering_splat_settles_on_the_node_centre_and_reaches_its_corners() {
        // Flutter's ripple drifts to the box centre and ends at half the diagonal, which is
        // exactly the radius that covers the box from there.
        // Flutter 的涟漪漂到盒子中心，终点半径取对角线的一半——正是从中心盖住盒子的半径。
        let (mut lp, _rec) = run(ink_node());
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(90.0, 35.0);
        press(&mut lp, at);
        lp.build_with_dt((200, 120), Some(at), 0.30);
        let ink = ink_circles(&lp);
        assert_eq!(ink.len(), 1);
        let (rect, _) = ink[0];
        let (cx, cy) = (rect.origin.x + rect.size.w / 2.0, rect.origin.y + rect.size.h / 2.0);
        assert!((cx - 50.0).abs() < 0.01 && (cy - 20.0).abs() < 0.01, "centre {rect:?}");
        let half_diagonal = (100.0f32 * 100.0 + 40.0 * 40.0).sqrt() * 0.5;
        assert!((rect.size.w * 0.5 - half_diagonal).abs() < 0.01, "radius {rect:?}");
    }

    #[test]
    fn a_covering_splat_settles_on_a_displaced_nodes_own_centre() {
        // The drift target is the node's box in node space; a displaced node must not shift
        // the splash by its surface origin.
        // 漂移目标是节点空间里的节点盒子；被位移的节点不得让墨迹差一个表面原点。
        let root = Decl::container(Id::str("root"), NodeKind::Column)
            .size(SizeClass::fixed(300.0, 200.0))
            .child(ink_node().offset(60.0, 40.0));
        let (mut lp, _rec) = run(root);
        let mut target = OffscreenTarget::new(300, 200);
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(90.0, 50.0);
        press(&mut lp, at);
        lp.build_with_dt((300, 200), Some(at), 0.30);
        let ink = ink_circles(&lp);
        assert_eq!(ink.len(), 1);
        let (rect, _) = ink[0];
        let (cx, cy) = (rect.origin.x + rect.size.w / 2.0, rect.origin.y + rect.size.h / 2.0);
        assert!(
            (cx - 110.0).abs() < 0.01 && (cy - 60.0).abs() < 0.01,
            "the splash settles on the node's own centre (110, 60), not shifted by its origin: {rect:?}"
        );
    }

    #[test]
    fn a_fixed_splat_stays_on_the_press_point() {
        // A fixed-radius splat is the unbounded case (Flutter's `defaultSplashRadius`): it
        // must not drift, or an icon-button ripple would slide out from under the pointer.
        // 固定半径的墨迹即无边界情形（Flutter 的 `defaultSplashRadius`）：它不得漂移，
        // 否则图标按钮的涟漪会从指针底下滑走。
        let (mut lp, _rec) = run(ink_node_with(ui_core::InkRadius::Fixed(20.0)));
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(40.0, 10.0);
        press(&mut lp, at);
        lp.build_with_dt((200, 120), Some(at), 0.30);
        let ink = ink_circles(&lp);
        assert_eq!(ink.len(), 1);
        let (rect, _) = ink[0];
        let (cx, cy) = (rect.origin.x + rect.size.w / 2.0, rect.origin.y + rect.size.h / 2.0);
        assert!((cx - at.x).abs() < 0.01 && (cy - at.y).abs() < 0.01, "centre {rect:?}");
        assert!((rect.size.w * 0.5 - 20.0).abs() < 0.01, "radius {rect:?}");
    }

    #[test]
    fn a_splat_outlives_the_release_then_disappears_without_waking_the_loop() {
        // Ink must survive the press that made it (its origin is already banked) and must
        // stop asking for frames once its fade is over, or the loop never idles.
        // 墨迹必须比产生它的按下活得久（落点已经存下），并在淡出结束后不再索取帧，
        // 否则循环永远不会空闲。
        let (mut lp, _rec) = run(ink_node());
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(40.0, 10.0);
        press(&mut lp, at);
        let grown = lp.build_with_dt((200, 120), Some(at), 0.10);
        assert!(grown.animating, "a growing splat is an animation");
        assert_eq!(ink_circles(&lp).len(), 1);

        lp.dispatch(ui_core::Event::PointerReleased {
            button: ui_core::PointerButton::Primary,
            pos: at,
        });
        let fading = lp.build_with_dt((200, 120), Some(at), 0.05);
        let during = ink_circles(&lp);
        assert_eq!(during.len(), 1, "the ink outlives the press");
        assert!(fading.animating, "a fading splat is still an animation");

        let after = lp.build_with_dt((200, 120), Some(at), 0.40);
        assert!(ink_circles(&lp).is_empty(), "the fade is over, the ink is gone");
        assert!(!after.animating, "a finished splat must not keep the loop awake");
    }

    /// An element whose declaration depends on the engine clock.
    /// 声明依赖引擎时钟的元素。
    struct Clocked {
        reading: std::rc::Rc<std::cell::Cell<bool>>,
    }

    impl crate::Element for Clocked {
        fn decl(&self, cx: &mut ui_core::cx::Cx<'_>) -> Decl {
            let age = if self.reading.get() {
                cx.age(Id::str("tick"))
            } else {
                0.0
            };
            // Width carries the age, so a frame that did not re-read the clock is visible.
            // 宽度携带年龄，因此没重新读时钟的帧会显形。
            node(
                Id::str("tick"),
                Sense::NONE,
                0.0,
                0.0,
                80.0 + age * 200.0,
                40.0,
            )
        }
    }

    struct Ticker {
        reading: std::rc::Rc<std::cell::Cell<bool>>,
    }

    impl App for Ticker {
        fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            Box::new(Clocked {
                reading: self.reading.clone(),
            })
        }

        fn changed(&mut self, _id: Id, _change: ui_core::change::Change) -> bool {
            false
        }
    }

    #[test]
    fn a_clock_read_asks_for_every_frame_and_stops_asking_when_it_stops() {
        // A procedural loop is not an animation in the store, so only the read itself can
        // tell the frame loop it still has work; a determinate widget must let it rest.
        // 程序化循环不是存储里的动画，只有这次读取本身能告诉帧循环还有活干；
        // 确定态的控件则必须让循环歇下来。
        let reading = std::rc::Rc::new(std::cell::Cell::new(true));
        let mut lp = AppLoop::new(Ticker {
            reading: reading.clone(),
        });
        let first = lp.build_with_dt((200, 120), None, 0.05);
        assert!(first.animating, "a clock read asks for the next frame");
        let second = lp.build_with_dt((200, 120), None, 0.05);
        assert!(second.animating, "and keeps asking while it keeps reading");
        let width = lp
            .tree
            .find_by_id(Id::str("tick"))
            .and_then(|n| lp.tree.get(n))
            .map(|n| n.rect.size.w)
            .unwrap_or(0.0);
        assert!(width > 85.0, "the element re-read a later clock: width {width}");

        reading.set(false);
        let idle = lp.build_with_dt((200, 120), None, 0.05);
        assert!(!idle.animating, "an element that stops reading lets the loop rest");
    }

    #[test]
    fn a_click_shorter_than_a_frame_still_shows_the_splat() {
        // Press and release can arrive in one event burst, before any frame advances the
        // clock. Freezing the fade-in at release freezes it at zero, so the ripple would
        // never appear — the "press sometimes does nothing" defect.
        // 按下与松手可能在同一批事件里到达，时钟还没走过任何一帧。若在松手处定格淡入，
        // 就定格在 0，涟漪永不出现——即「按下有时什么都不显示」的缺陷。
        let (mut lp, _rec) = run(ink_node());
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(40.0, 10.0);
        press(&mut lp, at);
        lp.dispatch(ui_core::Event::PointerReleased {
            button: ui_core::PointerButton::Primary,
            pos: at,
        });
        let frame = lp.build_with_dt((200, 120), Some(at), 0.02);
        assert_eq!(ink_circles(&lp).len(), 1, "a click shorter than a frame still splats");
        assert!(frame.animating, "and it is still fading");
    }
}

/// The declaration cache: what it reuses, and what must still rebuild.
/// 声明缓存：它复用哪些东西，以及哪些东西仍然必须重建。
#[cfg(test)]
mod decl_cache_tests {
    use super::*;
    use crate::present::OffscreenTarget;
    use ui_core::geom::Color;
    use ui_core::layout::SizeClass;
    use ui_core::Decl;

    /// Counts builds and depends on its own hover and an animation it drives.
    /// 统计构建次数，依赖自身的悬停状态与它驱动的一个动画。
    struct Tally {
        builds: std::rc::Rc<std::cell::Cell<usize>>,
        /// App state the engine cannot see: the fingerprint carries it into the cache key.
        /// 引擎看不见的应用状态：指纹把它带进缓存键。
        tint: Color,
    }

    /// A colour's bits, the way a control fingerprints its own inputs.
    /// 颜色的位模式，控件给自己的输入取指纹就是这个形状。
    fn tint_fp(c: Color) -> u64 {
        use std::hash::{Hash, Hasher};
        let mut h = std::collections::hash_map::DefaultHasher::new();
        [c.r.to_bits(), c.g.to_bits(), c.b.to_bits(), c.a.to_bits()].hash(&mut h);
        h.finish()
    }

    impl crate::Element for Tally {
        fn decl(&self, cx: &mut ui_core::cx::Cx<'_>) -> Decl {
            self.builds.set(self.builds.get() + 1);
            let id = Id::str("tally");
            let hovered = cx.hovered_within(id);
            let a = cx.animate(
                Id::str("tally/hover"),
                if hovered { 1.0 } else { 0.0 },
                ui_core::AnimSpec::new(0.1, ui_core::Easing::Linear),
            );
            Decl::container(id, NodeKind::Box)
                .size(SizeClass::fixed(80.0, 40.0))
                .sense(ui_core::Sense::HOVER | ui_core::Sense::CLICK)
                .offset(a * 10.0, 0.0)
                .background(self.tint, ui_core::geom::Corners::ZERO)
        }

        fn cache_key(&self) -> Option<ui_core::memo::CachedKey> {
            Some(ui_core::memo::CachedKey::new(Id::str("tally"), tint_fp(self.tint)))
        }

        fn change(
            &self,
            state: &crate::state::WidgetState,
            _bounds: Rect,
        ) -> Option<ui_core::Change> {
            state
                .clicked
                .then_some(ui_core::change::Change::Activated)
        }
    }

    struct Cached {
        builds: std::rc::Rc<std::cell::Cell<usize>>,
        tint: Color,
    }

    /// App state with no engine fact behind it: only a reported change can invalidate it.
    /// 背后没有引擎事实的应用状态：只有上报的变化能让它失效。
    struct Swatch {
        tint: Color,
    }

    impl crate::Element for Swatch {
        fn decl(&self, _cx: &mut ui_core::cx::Cx<'_>) -> Decl {
            Decl::container(Id::str("swatch"), NodeKind::Box)
                .size(SizeClass::fixed(40.0, 40.0))
                .background(self.tint, ui_core::geom::Corners::ZERO)
        }

        fn cache_key(&self) -> Option<ui_core::memo::CachedKey> {
            Some(ui_core::memo::CachedKey::new(Id::str("swatch"), tint_fp(self.tint)))
        }
    }

    /// A bare click target; the app reads nothing from it but the report.
    /// 一个纯点击目标；应用除了上报之外不从它读任何东西。
    struct Knob;

    impl crate::Element for Knob {
        fn decl(&self, _cx: &mut ui_core::cx::Cx<'_>) -> Decl {
            Decl::container(Id::str("knob"), NodeKind::Box)
                .size(SizeClass::fixed(40.0, 40.0))
                .sense(ui_core::Sense::CLICK)
        }

        fn cache_key(&self) -> Option<ui_core::memo::CachedKey> {
            // No inputs at all: a constant fingerprint is the whole truth.
            // 没有任何输入：常量指纹就是全部真相。
            Some(ui_core::memo::CachedKey::new(Id::str("knob"), 0))
        }

        fn change(
            &self,
            state: &crate::state::WidgetState,
            _bounds: Rect,
        ) -> Option<ui_core::Change> {
            state
                .clicked
                .then_some(ui_core::change::Change::Activated)
        }
    }

    impl App for Cached {
        fn view(&mut self, _cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            Box::new(
                crate::Container::new(Id::str("root"), NodeKind::Column)
                    .child(Box::new(Tally {
                        builds: std::rc::Rc::clone(&self.builds),
                        tint: self.tint,
                    }))
                    .child(Box::new(Swatch { tint: self.tint }))
                    .child(Box::new(Knob)),
            )
        }

        fn changed(&mut self, _id: Id, _change: ui_core::change::Change) -> bool {
            self.tint = if self.tint == Color::from_rgba8(200, 60, 60, 255) {
                Color::from_rgba8(60, 60, 200, 255)
            } else {
                Color::from_rgba8(200, 60, 60, 255)
            };
            true
        }
    }

    fn cached_loop() -> (AppLoop<Cached>, std::rc::Rc<std::cell::Cell<usize>>) {
        let builds = std::rc::Rc::new(std::cell::Cell::new(0));
        (
            AppLoop::new(Cached {
                builds: std::rc::Rc::clone(&builds),
                tint: Color::from_rgba8(200, 60, 60, 255),
            }),
            builds,
        )
    }

    #[test]
    fn a_cached_element_is_not_rebuilt_while_its_facts_hold() {
        let (mut lp, builds) = cached_loop();
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        assert_eq!(builds.get(), 1, "the first frame builds it once");
        lp.frame(&mut target, None);
        assert_eq!(builds.get(), 1, "nothing the declaration read has moved");
    }

    #[test]
    fn a_hover_change_rebuilds_the_element_that_read_it() {
        let (mut lp, builds) = cached_loop();
        let mut target = OffscreenTarget::new(200, 120);
        lp.frame(&mut target, None);
        lp.dispatch(ui_core::Event::PointerMoved {
            pos: ui_core::geom::Point::new(40.0, 20.0),
        });
        lp.frame(&mut target, None);
        assert_eq!(builds.get(), 2, "the hovered fact it read changed");
    }

    #[test]
    fn an_animation_inside_a_cached_element_keeps_advancing() {
        // Replaying a recorded animation call is what keeps it moving; skipping the
        // replay would freeze every cached control mid-fade.
        // 重放记录下来的动画调用才能让它继续走；不重放会让每个被缓存的控件停在半途。
        let (mut lp, builds) = cached_loop();
        let mut target = OffscreenTarget::new(200, 200);
        lp.frame(&mut target, None);
        let at = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.frame_with_dt(&mut target, Some(at), 0.02);
        let started = builds.get();
        lp.frame_with_dt(&mut target, Some(at), 0.02);
        assert!(builds.get() > started, "a moving value invalidates its element");
        for _ in 0..20 {
            lp.frame_with_dt(&mut target, Some(at), 0.05);
        }
        let settled = builds.get();
        lp.frame_with_dt(&mut target, Some(at), 0.05);
        assert_eq!(builds.get(), settled, "a settled animation stops rebuilding");
    }

    #[test]
    fn a_reported_change_drops_the_declaration_cache() {
        // The engine cannot see app state, so the app's own report must be enough.
        // 引擎看不见应用状态，因此应用自己上报的变化必须足以让缓存作废。
        let red = Color::from_rgba8(200, 60, 60, 255);
        let blue = Color::from_rgba8(60, 60, 200, 255);
        let (mut lp, _builds) = cached_loop();
        let mut target = OffscreenTarget::new(200, 200);
        lp.frame(&mut target, None);
        assert_eq!(swatch_fill(&lp), Some(red), "the first frame paints the seeded tint");
        let at = ui_core::geom::Point::new(20.0, 100.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.dispatch(ui_core::Event::PointerPressed {
            button: ui_core::PointerButton::Primary,
            pos: at,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            button: ui_core::PointerButton::Primary,
            pos: at,
        });
        for _ in 0..4 {
            lp.frame(&mut target, None);
        }
        assert_eq!(
            swatch_fill(&lp),
            Some(blue),
            "the click changed state the cache could not see"
        );
    }

    /// The fill the swatch's own node painted, straight from the resolved list.
    /// 色块节点自身绘制的填充色，直接取自解析后的绘制列表。
    fn swatch_fill(lp: &AppLoop<Cached>) -> Option<Color> {
        let list = &lp.resolved;
        for op in &list.ops {
            let ui_core::draw::Op::Prim(prim) = op else {
                continue;
            };
            if prim.kind != PrimKind::Rect {
                continue;
            }
            let i = prim.index as usize;
            let Some(node) = lp.tree.get(list.owners.rects[i]) else {
                continue;
            };
            if node.id == Id::str("swatch") {
                return Some(list.prims.rects[i].fill);
            }
        }
        None
    }

}

#[cfg(test)]
mod popup_scope_tests {
    use super::*;
    use crate::present::OffscreenTarget;
    use ui_core::geom::{Color, Corners};
    use ui_core::layout::SizeClass;
    use ui_core::Decl;

    /// A page with one focusable box and, when open, a panel that asks for the keyboard.
    /// 一个带可聚焦方框的页面；打开时还有一块索取键盘的面板。
    struct Flyout {
        open: bool,
        dismissed: Rc<RefCell<Vec<Id>>>,
        /// The row the panel should open onto, when it names one.
        /// 面板打开时应落在的行，若它指定了的话。
        opens_onto: Option<Id>,
        /// Whether the panel's rows sit displaced, as during its entrance.
        /// 面板的行是否被位移，正如开场期间那样。
        displaced: bool,
    }

    /// The panel: it asks for the keyboard on its rows' behalf and reports a light dismissal.
    /// 面板：替它的行索取键盘，并上报轻关闭。
    struct FlyoutPanel {
        focus_initial: Option<Id>,
        /// Whether the rows sit displaced, as they do while the panel slides into place.
        /// 行是否被位移，正如面板滑入到位时的样子。
        displaced: bool,
    }

    impl crate::Element for FlyoutPanel {
        fn decl(&self, _cx: &mut ui_core::cx::Cx<'_>) -> Decl {
            let row = |id: &'static str| {
                Decl::container(Id::str(id), NodeKind::Box)
                    .size(SizeClass::fixed(100.0, 30.0))
                    .background(Color::WHITE, Corners::ZERO)
                    .sense(ui_core::Sense::FOCUSABLE)
            };
            let mut rows = Decl::container(Id::str("rows"), NodeKind::Column)
                .child(row("a"))
                .child(row("b"));
            if self.displaced {
                rows = rows.offset(0.0, -35.0);
            }
            let mut panel = Decl::container(Id::str("panel"), NodeKind::Column)
                .size(SizeClass::fixed(100.0, 60.0))
                .background(Color::WHITE, Corners::ZERO)
                .overlay(ui_core::layout::OverlayPlacement::below(
                    ui_core::layout::Anchor::Point(ui_core::geom::Point::new(180.0, 10.0)),
                ))
                .sense(ui_core::Sense::FOCUSABLE)
                .child(rows);
            if let Some(id) = self.focus_initial {
                panel = panel.focus_initial(id);
            }
            panel
        }

        fn change(
            &self,
            state: &crate::WidgetState,
            _bounds: Rect,
        ) -> Option<ui_core::change::Change> {
            state
                .dismissed
                .then_some(ui_core::change::Change::Dismissed)
        }
    }

    impl App for Flyout {
        fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn crate::Element> {
            let mut root = crate::Container::new(Id::str("root"), NodeKind::Column)
                .size(SizeClass::fixed(300.0, 300.0))
                .background(Color::WHITE, Corners::ZERO)
                .child_decl(
                    Decl::container(Id::str("page"), NodeKind::Box)
                        .size(SizeClass::fixed(100.0, 40.0))
                        .background(Color::WHITE, Corners::ZERO)
                        .sense(ui_core::Sense::CLICK | ui_core::Sense::FOCUSABLE),
                );
            if self.open {
                root = root.child(Box::new(FlyoutPanel {
                    focus_initial: self.opens_onto,
                    displaced: self.displaced,
                }));
            }
            Box::new(root)
        }

        fn changed(&mut self, id: Id, change: ui_core::change::Change) -> bool {
            if matches!(change, ui_core::change::Change::Dismissed) {
                self.dismissed.borrow_mut().push(id);
            }
            true
        }
    }

    fn flyout(open: bool) -> (AppLoop<Flyout>, Rc<RefCell<Vec<Id>>>, OffscreenTarget) {
        let log = Rc::new(RefCell::new(Vec::new()));
        let mut lp = AppLoop::new(Flyout {
            open,
            dismissed: Rc::clone(&log),
            opens_onto: None,
            displaced: false,
        });
        let mut target = OffscreenTarget::new(300, 300);
        lp.frame(&mut target, None);
        (lp, log, target)
    }

    #[test]
    fn a_press_outside_the_open_panel_asks_that_panel_to_close() {
        // The page behind is a click target too; only the panel hears "you were dismissed".
        // 身后的页面同样是点击目标；只有面板听到「你被关闭了」。
        let (mut lp, log, mut target) = flyout(true);
        let at = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: at,
            button: ui_core::PointerButton::Primary,
        });
        lp.frame(&mut target, None);
        assert_eq!(*log.borrow(), vec![Id::str("panel")]);
    }

    #[test]
    fn the_tap_that_closes_a_panel_arms_no_press_underneath() {
        // A light-dismiss layer takes the first tap whole: it closes the surface and starts
        // no press, so the release cannot click. Pressing a combo box again closes its list
        // rather than closing and reopening it in one gesture.
        // 轻关闭遮罩整下接住第一击：它关掉表面，也不开启按下，于是松手不会成为点击。
        // 再次按下下拉框只关掉它的列表，而不会在同一手势里先关后开。
        let (mut lp, log, mut target) = flyout(true);
        let at = ui_core::geom::Point::new(20.0, 20.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: at,
            button: ui_core::PointerButton::Primary,
        });
        assert_eq!(lp.pressed(), None, "the dismissing tap arms nothing underneath");
        lp.dispatch(ui_core::Event::PointerReleased {
            pos: at,
            button: ui_core::PointerButton::Primary,
        });
        lp.frame(&mut target, None);
        assert_eq!(*log.borrow(), vec![Id::str("panel")]);
    }

    #[test]
    fn an_open_panel_takes_the_keyboard_and_hands_it_back_when_it_closes() {
        // Focus lands on the first row, not on the panel: a panel draws no focus ring.
        // 焦点落在第一行而不是面板上：面板不画焦点环。
        let (mut lp, _log, mut target) = flyout(false);
        let at = ui_core::geom::Point::new(10.0, 10.0);
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        lp.dispatch(ui_core::Event::PointerPressed {
            pos: at,
            button: ui_core::PointerButton::Primary,
        });
        lp.dispatch(ui_core::Event::PointerReleased {
            pos: at,
            button: ui_core::PointerButton::Primary,
        });
        lp.frame(&mut target, None);
        assert_eq!(lp.focused(), Some(Id::str("page")));

        lp.app.open = true;
        lp.frame(&mut target, None);
        assert_eq!(lp.focused(), Some(Id::str("a")));

        lp.app.open = false;
        lp.frame(&mut target, None);
        assert_eq!(lp.focused(), Some(Id::str("page")));
    }

    #[test]
    fn a_panel_can_name_the_row_it_opens_onto() {
        // A combo box opens onto its selected row; a hint outside the panel is ignored.
        // 下拉框打开时落在选中的行上；指向面板之外的提示被忽略。
        let log = Rc::new(RefCell::new(Vec::new()));
        let mut lp = AppLoop::new(Flyout {
            open: true,
            dismissed: Rc::clone(&log),
            opens_onto: Some(Id::str("b")),
            displaced: false,
        });
        let mut target = OffscreenTarget::new(300, 300);
        lp.frame(&mut target, None);
        assert_eq!(lp.focused(), Some(Id::str("b")));

        lp.app.open = false;
        lp.frame(&mut target, None);
        lp.app.opens_onto = Some(Id::str("page"));
        lp.app.open = true;
        lp.frame(&mut target, None);
        assert_eq!(lp.focused(), Some(Id::str("a")));
    }

    #[test]
    fn an_entrance_that_clips_the_first_row_does_not_move_the_initial_focus() {
        // A panel slides into place, so its first rows sit outside the window mid-entrance;
        // the take still lands on the first stop in document order, not the first visible one.
        // 面板滑入到位，开场期间最前面的几行落在窗口之外；接管仍落在文档序第一个停靠点，
        // 而不是当前看得见的第一个。
        let log = Rc::new(RefCell::new(Vec::new()));
        let mut lp = AppLoop::new(Flyout {
            open: false,
            dismissed: Rc::clone(&log),
            opens_onto: None,
            displaced: true,
        });
        let mut target = OffscreenTarget::new(300, 300);
        lp.frame(&mut target, None);
        lp.app.open = true;
        lp.frame(&mut target, None);
        assert_eq!(lp.focused(), Some(Id::str("a")));
    }

    #[test]
    fn the_navigation_keys_walk_the_panel_as_a_closed_loop() {
        // An open menu keeps the arrows: at either end they wrap instead of leaving it.
        // 打开的菜单留住方向键：走到任一端都绕回，而不是离开它。
        let (mut lp, _log, _target) = flyout(true);
        assert_eq!(lp.focused(), Some(Id::str("a")));
        let press = |lp: &mut AppLoop<Flyout>, key: ui_core::Key| {
            lp.dispatch(ui_core::Event::KeyPressed { key });
        };
        press(&mut lp, ui_core::Key::Down);
        assert_eq!(lp.focused(), Some(Id::str("b")));
        press(&mut lp, ui_core::Key::Down);
        assert_eq!(lp.focused(), Some(Id::str("a")));
        press(&mut lp, ui_core::Key::Up);
        assert_eq!(lp.focused(), Some(Id::str("b")));
        press(&mut lp, ui_core::Key::Home);
        assert_eq!(lp.focused(), Some(Id::str("a")));
        press(&mut lp, ui_core::Key::End);
        assert_eq!(lp.focused(), Some(Id::str("b")));
    }
}
