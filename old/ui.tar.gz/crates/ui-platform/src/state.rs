//! One frame's resolved interaction state for one node id.
//! 某一帧某个节点 id 的交互状态。

use ui_core::Id;

/// What one node knows about the user this frame.
/// 本帧某个节点所知的用户交互。
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct WidgetState {
    /// The pointer is over this node or a descendant that lets hover pass through.
    /// 指针在本节点上，或在允许悬停透传的后代上。
    pub hovered: bool,
    pub pressed: bool,
    /// A press and its release landed on this node with the pointer staying within
    /// `DRAG_THRESHOLD`; anything further is a drag, not a click.
    /// 按下与松手都落在本节点上，且指针始终在 `DRAG_THRESHOLD` 之内；
    /// 走得更远的按下是拖拽，不是点击。
    pub clicked: bool,
    /// A drag ended on this node within the last frame.
    /// 上一帧内有一次拖拽在本节点上结束。
    pub dropped: bool,
    /// The node this drag was released onto, when that node accepts drops.
    /// 这次拖拽释放到的节点，且该节点接受放下。
    pub drop_target: Option<ui_core::Id>,
    pub focused: bool,
    /// Focus arrived by keyboard, so a focus ring may be drawn; pointer focus may not.
    /// 焦点由键盘带来，因此可以画焦点环；指针带来的焦点不可以。
    pub focus_visible: bool,
    /// Enter or Space landed this frame on this node or a focused descendant; a pointer
    /// activation is `clicked`. Prefer `activation()`, which is either.
    /// 本帧在本节点或聚焦的后代上按下了 Enter 或 Space；指针激活走 `clicked`。
    /// 一般用 `activation()`，它表示两者之一。
    pub activated: bool,
    /// A press outside this popup asked it to close — the light-dismiss of every flyout.
    /// 浮层之外的一次按下要求它关闭——每个浮层都有的「点外面关掉」。
    pub dismissed: bool,
    /// A chord declared on this node fired this frame.
    /// 本节点声明的组合键本帧被触发。
    pub shortcut: Option<ui_core::ShortcutId>,
    /// The nearest drag subscriber owns the live press; armed at the press, not at the
    /// threshold, so a control can hold its value for the whole gesture.
    /// 最近的拖拽订阅者拥有这次按下；在按下时即成立而非越过阈值，使控件能在整个手势中保持值。
    pub dragging: bool,
    /// The press on this node has travelled past `DRAG_THRESHOLD`: a real drag, not a tap.
    /// 本节点上的按下已越过 `DRAG_THRESHOLD`：是真正的拖拽，不是点击。
    pub drag_started: bool,
    pub disabled: bool,
    pub selected: bool,
    /// The pointer in this node's own space while a press or drag is live here.
    /// 本节点上有按下或拖拽时，指针位于它自身空间中的位置。
    /// `change()` receives it per node; `decl()` sees the drag owner's space instead.
    /// `change()` 按节点换算；`decl()` 看到的是拖拽所有者的空间。
    pub local: Option<ui_core::geom::Point>,
    /// Pointer movement since the previous event while a drag is live.
    /// 拖拽进行中，指针相对上一次事件的位移。
    pub drag_step: Option<ui_core::geom::Point>,
    /// Held modifiers, for a control that shapes itself by them (Alt-drag, chord preview).
    /// 按住的修饰键，供按其改变行为的控件使用（Alt 拖拽、组合键预览）。
    pub modifiers: ui_core::Modifiers,
}

impl WidgetState {
    /// The one semantic activation a control answers: a click, or Enter/Space while focused.
    /// 控件应答的唯一语义激活：一次点击，或聚焦时的 Enter/Space。
    ///
    /// Controls map this to their own change (`Toggled`, `Selected`, …); a control that reads
    /// only `clicked` is deaf to the keyboard, and the engine never reports activation itself.
    /// 控件把它映射成自己的变化（`Toggled`、`Selected`…）；只读 `clicked` 的控件听不到键盘，
    /// 引擎也从不自己上报激活。
    pub fn activation(&self) -> bool {
        self.clicked || self.activated
    }

    /// Read one node's state from the frame's routing facts.
    /// 从本帧的路由事实读出某个节点的状态。
    pub fn of(core: &ui_core::cx::Cx<'_>, id: Id) -> Self {
        Self {
            // Containers see hover through children, so the ancestor path is the primary
            // read; the equality arm covers the hit node being this one.
            // 容器须透过子节点看悬停，故以祖先链为主；等值一侧覆盖最上层命中正是本节点。
            hovered: core.hovered_within(id) || core.hovered() == Some(id),
            pressed: core.pressed_within(id) || core.pressed() == Some(id),
            clicked: core.clicked_within(id),
            dropped: core.dropped_within(id),
            drop_target: core.drop_target(),
            focused: core.focused() == Some(id),
            focus_visible: core.focus_visible() && core.focused() == Some(id),
            activated: core.activated_within(id),
            dismissed: core.dismissed() == Some(id),
            shortcut: core
                .shortcut()
                .filter(|(owner, _)| *owner == id)
                .map(|(_, id)| id),
            dragging: core.dragging_within(id),
            drag_started: core.drag_started_within(id),
            // Folded by the engine: a disabled ancestor makes this node inert too.
            // 由引擎折入：被禁用的祖先会让本节点同样惰性。
            disabled: core.is_disabled(id),
            selected: false,
            local: core.local(),
            drag_step: core.drag_step(),
            modifiers: core.modifiers(),
        }
    }
}
