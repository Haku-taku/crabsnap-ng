//! Presentation targets: where rendered pixels go.
//! 呈现目标：渲染好的像素去哪里。

use ui_core::geom::Rect;
use ui_core::Damage;
use ui_paint::Pixels;

/// What kind of surface we are painting into.
/// 我们在往什么表面上画。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SurfaceKind {
    /// A regular window.
    /// 普通窗口。
    Window,
    /// A full-screen overlay layer.
    /// 全屏覆盖层。
    LayerSurface,
    /// Offscreen, for tests and export.
    /// 离屏，供测试与导出。
    Offscreen,
}

/// A target that accepts rendered pixels.
/// 接收渲染像素的目标。
pub trait PresentTarget {
    fn kind(&self) -> SurfaceKind;
    fn size(&self) -> (u32, u32);
    /// Pixel buffer to render into.
    /// 供渲染使用的像素缓冲。
    fn pixels_mut(&mut self) -> &mut Pixels;
    /// Commit `damage` to the screen (or to disk, or nowhere).
    /// 把 `damage` 提交到屏幕（或磁盘，或无操作）。
    fn present(&mut self, damage: &Damage) -> Result<(), String>;
    /// Apply the pointer shape this frame resolved. The cursor is a seat property that the
    /// client must re-assert on every enter, so a target that never sets it keeps whatever
    /// the previous application left behind.
    /// 应用本帧解析出的指针形状。光标是 seat 属性，每次进入都必须由客户端重新声明；
    /// 从不设置它的目标会一直显示上一个应用留下的形状。
    fn set_cursor(&mut self, _shape: ui_core::CursorShape) {}

    /// Apply this frame's input-method state. A target that never sets it simply never
    /// enables text input, which is the safe default for surfaces with no IME.
    /// 应用本帧的输入法状态。从不设置它的目标就是从不启用文本输入，
    /// 对没有输入法的表面这是安全的默认。
    fn set_ime(&mut self, _state: ImeState) {}
}

/// What a presented scene actually did, for the caller's own diagnostics.
/// 一帧场景实际做了什么，供调用方自己的诊断使用。
#[derive(Clone, Copy, Debug, Default)]
pub struct PresentStats {
    pub draw_calls: u32,
    /// The redrawn band in physical pixels, when the target knows it.
    /// 重绘带（物理像素），目标知道时才有。
    pub band: Option<[i32; 4]>,
}

/// A target that takes a whole frame: upload the atlas, draw the scene, commit.
/// 接收整帧的目标：上传图集、绘制场景、提交。
///
/// The engine decides when a frame is worth presenting and hands over only what the frame
/// produced, so an app never drives an upload, a draw or a commit itself.
/// 引擎决定一帧是否值得提交，只交出该帧的产物，因此应用从不亲自驱动上传、绘制或提交。
pub trait SceneTarget {
    /// Surface size in physical pixels.
    /// 表面尺寸，物理像素。
    fn size(&self) -> (u32, u32);

    /// Draw `scene` with `text`'s atlas and commit it; `damage` is what changed.
    /// 用 `text` 的图集绘制 `scene` 并提交；`damage` 是变化的部分。
    fn present_scene(
        &mut self,
        scene: &ui_core::draw::DrawList,
        text: &crate::text_pass::TextPass,
        damage: &Damage,
    ) -> Result<PresentStats, String>;

    /// Apply the pointer shape this frame resolved.
    /// 应用本帧解析出的指针形状。
    fn set_cursor(&mut self, _shape: ui_core::CursorShape) {}

    /// Apply this frame's input-method state.
    /// 应用本帧的输入法状态。
    fn set_ime(&mut self, _state: ImeState) {}

    /// Whether the surface owes a commit beyond the frame's own damage (input method state,
    /// for one): the engine must not skip a present that would carry it.
    /// 表面是否还欠一次提交（例如输入法状态），与画面脏区无关：引擎不能跳过承载它的提交。
    fn commit_pending(&self) -> bool {
        false
    }
}

/// What a compositor needs to place an input method's candidate window.
/// 合成器摆放输入法候选窗所需的信息。
#[derive(Clone, Debug, Default, PartialEq)]
pub struct ImeState {
    /// Enable text input only when `cursor` came from this frame; see
    /// `docs/ime-text-design.md` §6 for the stale-rectangle bug this prevents.
    /// 只有 `cursor` 来自本帧时才启用文本输入；它防的就是 `docs/ime-text-design.md` §6 的旧矩形缺陷。
    pub enabled: bool,
    /// The caret in surface coordinates, logical units.
    /// 插入符在表面坐标下的矩形，逻辑单位。
    pub cursor: Option<ui_core::geom::Rect>,
    /// The committed buffer with the caret and anchor offsets; the preedit is excluded,
    /// as the protocol requires.
    /// 已提交的缓冲以及插入符与锚点偏移；按协议要求，预编辑串不在其中。
    pub surrounding: Option<(String, usize, usize)>,
}

/// An offscreen target holding pixels in memory.
/// 内存中的离屏目标。
#[derive(Debug)]
pub struct OffscreenTarget {
    pub pixels: Pixels,
}

impl OffscreenTarget {
    pub fn new(width: u32, height: u32) -> Self {
        let mut pixels = Pixels::new(width, height);
        pixels.fill(ui_core::geom::Color::from_rgba8(28, 30, 34, 255));
        Self { pixels }
    }
}

impl PresentTarget for OffscreenTarget {
    fn kind(&self) -> SurfaceKind {
        SurfaceKind::Offscreen
    }

    fn size(&self) -> (u32, u32) {
        (self.pixels.width, self.pixels.height)
    }

    fn pixels_mut(&mut self) -> &mut Pixels {
        &mut self.pixels
    }

    fn present(&mut self, _damage: &Damage) -> Result<(), String> {
        Ok(())
    }
}

/// Where a target's content currently sits inside the surface.
/// 目标内容在表面中的位置。
pub fn full_rect(size: (u32, u32)) -> Rect {
    Rect::new(0.0, 0.0, size.0 as f32, size.1 as f32)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn offscreen_target_reports_its_size() {
        let t = OffscreenTarget::new(120, 80);
        assert_eq!(t.size(), (120, 80));
        assert_eq!(t.kind(), SurfaceKind::Offscreen);
    }

    #[test]
    fn offscreen_target_starts_with_a_background() {
        let t = OffscreenTarget::new(4, 4);
        assert_eq!(t.pixels.get(0, 0)[3], 255, "background must be opaque");
    }
}
