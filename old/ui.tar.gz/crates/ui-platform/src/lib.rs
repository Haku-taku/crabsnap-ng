//! Presentation targets and the headless windowed app loop.
//! 呈现目标与无头窗口应用循环。

/// Times a block with hotpath under the `profile` feature, and is the block itself otherwise.
/// 开启 `profile` 特性时用 hotpath 给该块计时，否则就是该块本身。
#[macro_use]
mod profile;

#[cfg(test)]
mod view_scroll_test;

pub mod clipboard;
pub mod driver;
pub mod element;
pub mod exit_probe;
pub mod hotkeys;
pub mod menu;
pub mod present;
pub mod shortcut;
pub mod state;
pub mod theme;
pub mod text_pass;
pub mod view;

pub use element::{from_decl, Container, Element, Leaf};
pub use present::{OffscreenTarget, PresentTarget, SurfaceKind};
pub use state::WidgetState;
pub use theme::{FixedTheme, ThemePreference, ThemeWatcher};
pub use text_pass::TextPass;
pub use view::{run_app, App, AppLoop, FrameInfo};
