//! The engine's fallback context menu: what a secondary click collects and how it is drawn.
//! 引擎自带的兜底上下文菜单：右键收集到什么，以及它如何绘制。
//!
//! A design system replaces the look through [`MenuStyle`]; the engine still owns the
//! collection, the placement, the hit test and the report.
//! 设计体系通过 [`MenuStyle`] 替换外观；收集、摆放、命中与上报仍归引擎。

use ui_core::geom::{Color, Corners, Point, Rect, Size};
use ui_core::menu::MenuItem;
use ui_core::text::{TextBlock, TextStyle, Weight};
use ui_core::Id;

/// How the fallback menu looks.
/// 兜底菜单的外观。
#[derive(Clone, Debug)]
pub struct MenuStyle {
    pub surface: Color,
    pub ink: Color,
    /// Rows that cannot be chosen.
    /// 不可选中的行。
    pub muted: Color,
    pub hover: Color,
    /// `None` paints no border; MD3's menu is bounded by its shadow alone.
    /// `None` 时不画描边；MD3 菜单只靠阴影界定。
    pub border: Option<(Color, f32)>,
    pub font_size: f32,
    /// The ink, size and weight of the chord shown at a row's trailing edge.
    /// 行尾缘所示组合键的墨色、字号与字重。
    pub shortcut_ink: Color,
    pub shortcut_size: f32,
    pub shortcut_weight: Weight,
    /// Space between a label and its shortcut, and the inset from the trailing edge.
    /// 标签与其组合键之间的空隙，以及距尾缘的内衬。
    pub shortcut_gap: f32,
    pub trailing_space: f32,
    pub row_height: f32,
    pub pad_x: f32,
    pub pad_y: f32,
    pub radius: f32,
    pub min_width: f32,
    /// The widest the menu gets before its labels wrap; MD3 caps it.
    /// 标签换行前菜单能达到的最大宽度；MD3 设有上限。
    pub max_width: f32,
    pub shadow: f32,
}

impl Default for MenuStyle {
    fn default() -> Self {
        let ink = Color::from_rgba8(232, 232, 236, 255);
        Self {
            surface: Color::from_rgba8(44, 46, 54, 255),
            ink,
            muted: Color::from_rgba8(140, 142, 150, 255),
            hover: Color::from_rgba8(255, 255, 255, 18),
            border: Some((Color::from_rgba8(255, 255, 255, 30), 1.0)),
            font_size: 14.0,
            // The chord is the row's own ink at reduced emphasis, so it follows whatever
            // theme supplied that ink instead of carrying a colour of its own.
            // 组合键是本行墨色的弱化版，因此跟随主题给出的墨色，而不是自带一种颜色。
            shortcut_ink: Color { a: ink.a * 0.7, ..ink },
            shortcut_size: 12.0,
            shortcut_weight: Weight::MEDIUM,
            shortcut_gap: 16.0,
            trailing_space: 12.0,
            row_height: 34.0,
            pad_x: 14.0,
            pad_y: 6.0,
            radius: 8.0,
            min_width: 180.0,
            max_width: f32::INFINITY,
            shadow: 10.0,
        }
    }
}

impl MenuStyle {
    /// The text block one row's label is shaped as.
    /// 一行标签被排版成的文本块。
    pub fn block(&self, label: &str) -> TextBlock {
        TextBlock::plain(label, TextStyle::new(self.font_size))
    }

    /// The text block one row's shortcut is shaped as.
    /// 一行组合键被排版成的文本块。
    pub fn shortcut_block(&self, shortcut: &str) -> TextBlock {
        TextBlock::plain(
            shortcut,
            TextStyle::new(self.shortcut_size).weight(self.shortcut_weight),
        )
    }
}

/// One built-in text row's words: what it says and, if it has one, the chord it runs.
/// 一条内建文本行的措辞：它写的字，以及（若有）它执行的组合键。
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct MenuRowText {
    pub label: String,
    /// Already in the app's words; the engine only right-aligns it.
    /// 已由应用给出文字；引擎只负责靠右摆放。
    pub shortcut: Option<String>,
}

/// The app's words for the engine's built-in text rows.
/// 引擎内建文本行在应用里的措辞。
///
/// The engine owns *which* rows exist and whether each is enabled; an app owns every word.
/// Until an app supplies these, the engine contributes no text rows at all — it never
/// invents text.
/// 行有哪些、各自是否可用由引擎决定；每一个字都由应用给出。
/// 应用未提供之前，引擎不添加任何文本行——它从不自己编文字。
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct TextMenuLabels {
    pub select_all: MenuRowText,
    pub copy: MenuRowText,
    pub cut: MenuRowText,
    pub paste: MenuRowText,
}

/// One open menu, owned by the engine until it closes.
/// 一个打开的菜单，关闭之前归引擎所有。
#[derive(Clone, Debug)]
pub(crate) struct OpenMenu {
    /// The node whose menu this is; the pick is reported to it.
    /// 菜单属于哪个节点；选中的结果上报给它。
    pub owner: Id,
    pub items: Vec<MenuItem>,
    pub rect: Rect,
    /// One rect per item, top to bottom.
    /// 每项一个矩形，自上而下。
    pub rows: Vec<Rect>,
    /// Where each row's shortcut sits, right-aligned; `None` for a row without one.
    /// 各行组合键的位置，靠右对齐；没有组合键的行为 `None`。
    pub shortcuts: Vec<Option<Rect>>,
    pub hovered: Option<usize>,
    /// The point that opened it; the entrance travels toward it.
    /// 打开它的那个点；开场朝它移动。
    pub at: Point,
    /// The engine clock when it opened: the entrance's zero.
    /// 它打开时的引擎时钟：开场的零点。
    pub opened_at: f64,
}

/// WinUI's `ControlFastAnimationDuration`, decelerating on (0,0,0,1).
/// WinUI 的 `ControlFastAnimationDuration`，按 (0,0,0,1) 减速。
const ENTRANCE: ui_core::anim::AnimSpec =
    ui_core::anim::AnimSpec::new(0.167, ui_core::anim::Easing::Cubic(0.0, 0.0, 0.0, 1.0));
/// The surface starts half its own height toward the pointer, then travels to rest.
/// 表面起始于朝指针方向半个自身高度处，再走回原位。
const TRAVEL: f32 = 0.5;

impl OpenMenu {
    /// Place the menu at `at`, kept inside the surface.
    /// 把菜单摆在 `at`，并留在表面之内。
    pub fn open(
        style: &MenuStyle,
        owner: Id,
        items: Vec<MenuItem>,
        at: Point,
        opened_at: f64,
        surface: Size,
        mut width_of: impl FnMut(&TextBlock) -> f32,
    ) -> Self {
        let widest = items
            .iter()
            .map(|item| {
                let shortcut = item.shortcut.as_deref().map_or(0.0, |s| {
                    style.shortcut_gap + width_of(&style.shortcut_block(s))
                });
                width_of(&style.block(&item.label))
                    + shortcut
                    + style.pad_x
                    + style.pad_x.max(style.trailing_space)
            })
            .fold(style.min_width, f32::max);
        let width = widest
            .min(style.max_width)
            .min((surface.w - 8.0).max(style.min_width));
        let height = items.len() as f32 * style.row_height + 2.0 * style.pad_y;
        // A menu near the edge opens inward rather than off-screen.
        // 靠近边缘的菜单向内打开，而不是跑到屏幕外。
        let x = at.x.min(surface.w - width - 4.0).max(4.0);
        let y = at.y.min(surface.h - height - 4.0).max(4.0);
        let rect = Rect::new(x, y, width, height);
        // The row is inset so its own rounded shape reads inside the container's.
        // 行向内缩，使它自己的圆角在容器之内可辨。
        let rows = (0..items.len())
            .map(|i| {
                Rect::new(
                    x + 4.0,
                    y + style.pad_y + i as f32 * style.row_height,
                    width - 8.0,
                    style.row_height,
                )
            })
            .collect();
        // Shortcuts are right-aligned against the container's own trailing inset.
        // 组合键靠右对齐到容器自身的尾缘内衬。
        let shortcuts = items
            .iter()
            .enumerate()
            .map(|(i, item)| {
                let shortcut = item.shortcut.as_deref()?;
                let w = width_of(&style.shortcut_block(shortcut));
                Some(Rect::new(
                    x + width - style.trailing_space - w,
                    y + style.pad_y + i as f32 * style.row_height,
                    w,
                    style.row_height,
                ))
            })
            .collect();
        Self {
            owner,
            items,
            rect,
            rows,
            shortcuts,
            hovered: None,
            at,
            opened_at,
        }
    }

    /// How far the entrance has come: presence `0..=1` and the vertical shift to draw with.
    /// 开场走到何处：在场程度 `0..=1`，以及绘制时使用的纵向位移。
    pub fn entrance(&self, now: f64) -> (f32, f32) {
        let t = ((now - self.opened_at) / ENTRANCE.duration as f64).clamp(0.0, 1.0) as f32;
        let presence = ENTRANCE.easing.apply(t);
        // A menu below the pointer unfolds downward out of its top edge, and vice versa.
        // 指针下方的菜单自顶缘向下展开，反之亦然。
        let toward_pointer = match self.rect.center().y < self.at.y {
            true => 1.0,
            false => -1.0,
        };
        (
            presence,
            (1.0 - presence) * self.rect.size.h * TRAVEL * toward_pointer,
        )
    }

    /// The row under `p`, if the menu is even hit, as it is drawn at `now`.
    /// `now` 时刻画出来的菜单里，`p` 之下的那一行（若菜单被命中）。
    pub fn row_at(&self, p: Point, now: f64) -> Option<usize> {
        let (_, shift) = self.entrance(now);
        if !self.rect.translate(Point::new(0.0, shift)).contains(p) {
            return None;
        }
        self.rows
            .iter()
            .position(|row| row.translate(Point::new(0.0, shift)).contains(p))
    }

    /// The enabled row under `p`.
    /// `p` 之下可用的那一行。
    pub fn enabled_row_at(&self, p: Point, now: f64) -> Option<usize> {
        self.row_at(p, now)
            .filter(|i| self.items.get(*i).is_some_and(|item| item.enabled))
    }

    pub fn corners(style: &MenuStyle) -> Corners {
        Corners::all(style.radius)
    }
}
