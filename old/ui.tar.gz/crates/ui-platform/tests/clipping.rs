//! Layout computes a content mask; paint must honour it.
//! 布局算出内容遮罩，绘制必须落实它。
//!
//! Before this was wired, a child larger than its parent painted straight over the
//! parent's bounds — the mask existed on every node but never reached the renderer.
//! 在接上之前，超出父容器的子节点会直接画到父边界之外——
//! 遮罩存在于每个节点上，却从未到达渲染器。

use ui_core::geom::{Color, Corners, Insets};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::tree::ContainerParams;
use ui_platform::present::OffscreenTarget;
use ui_core::{Decl, Id, NodeData, NodeKind};

use ui_platform::{App, AppLoop};

fn fixed_box(id: &'static str, w: f32, h: f32, color: Color) -> Decl {
    Decl {
        id: Id::str(id),
        kind: NodeKind::Box,
        shapes: vec![ui_core::draw::Shape::Box {
            corners: Corners::ZERO,
            fill: color,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }],
        data: NodeData::Container(ContainerParams::default()),
        size_class: SizeClass {
            width: AxisSize::fixed(w),
            height: AxisSize::fixed(h),
            grow_x: Grow::No,
            grow_y: Grow::No,
        },
        ink_margin: Insets::ZERO,
        box_model: Default::default(),
        offset: ui_core::geom::Point::new(0.0, 0.0),
        cursor: None,
        sense: ui_core::Sense::NONE,
        disabled: false,
        grid: Default::default(),
        placement: Default::default(),
            env: None,
        children: Vec::new(),
    }
}

/// A 40x40 container holding a 100x100 child.
/// 40x40 的容器里放一个 100x100 的子节点。
struct Overflow;

impl App for Overflow {
    fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn ui_platform::Element> {
        let decl = {
        let parent = Decl {
            id: Id::str("parent"),
            kind: NodeKind::Column,
            shapes: vec![ui_core::draw::Shape::Box {
                corners: Corners::ZERO,
                fill: Color::from_rgba8(40, 40, 40, 255),
                gradient: None,
                border: None,
                shadow: None,
                image: None,
            }],
            // Clipping is opt-in: this container declares it, so its box is the viewport.
            // 裁剪需显式声明：本容器声明了它，因此它的盒子就是视口。
            data: NodeData::Container(ContainerParams {
                clip: ui_core::layout::Clip {
                    x: ui_core::layout::Overflow::Hidden,
                    y: ui_core::layout::Overflow::Hidden,
                },
                ..Default::default()
            }),
            size_class: SizeClass {
                width: AxisSize::fixed(40.0),
                height: AxisSize::fixed(40.0),
                grow_x: Grow::No,
                grow_y: Grow::No,
            },
            ink_margin: Insets::ZERO,
            box_model: Default::default(),
            offset: ui_core::geom::Point::new(0.0, 0.0),
            cursor: None,
            sense: ui_core::Sense::NONE,
            disabled: false,
            grid: Default::default(),
            placement: Default::default(),
            env: None,
            children: vec![fixed_box("child", 100.0, 100.0, Color::from_rgba8(255, 0, 0, 255)).into()],
        };
        Decl::container(Id::str("root"), NodeKind::Column)
            .background(Color::from_rgba8(0, 0, 0, 255), Corners::ZERO)
            .child(parent)
    };
    ui_platform::from_decl(decl)
}

}
fn red_outside_parent() -> usize {
    let mut app = AppLoop::new(Overflow);
    let mut target = OffscreenTarget::new(160, 160);
    app.frame(&mut target, None);
    let px = &target.pixels;
    let red_at = |x: u32, y: u32| {
        let i = ((y * px.width + x) * 4) as usize;
        px.data[i + 2] > 100 && px.data[i + 1] < 60
    };
    (44..120)
        .flat_map(|y| (44..120).map(move |x| (x, y)))
        .filter(|(x, y)| red_at(*x, *y))
        .count()
}

#[test]
fn a_child_larger_than_its_parent_is_clipped() {
    assert_eq!(
        red_outside_parent(),
        0,
        "the 100x100 child must not paint outside the 40x40 parent"
    );
}

#[test]
fn a_fixed_size_child_keeps_its_size() {
    // `fixed` is a hard cap; the column's default cross-axis stretch must not override it.
    // `fixed` 是硬上限；列的默认交叉轴撑满不得覆盖它。
    let mut app = AppLoop::new(Overflow);
    let mut target = OffscreenTarget::new(160, 160);
    app.frame(&mut target, None);
    let child = app
        .tree()
        .walk()
        .into_iter()
        .filter_map(|nid| app.tree().get(nid))
        .find(|n| n.id == Id::str("child"))
        .expect("child node");
    assert_eq!(
        (child.rect.size.w, child.rect.size.h),
        (100.0, 100.0),
        "a fixed-size child must not be stretched to the parent's width"
    );
}

/// A 80x80 rounded container (radius 40, squircle) with a child that fills it.
/// 80x80 的圆角容器（半径 40，超圆角），子节点铺满它。
struct Rounded;

impl App for Rounded {
    fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn ui_platform::Element> {
        let decl = {
        let parent = Decl {
            id: Id::str("parent"),
            kind: NodeKind::Column,
            shapes: vec![ui_core::draw::Shape::Box {
                corners: Corners::all(40.0).squircle(),
                fill: Color::from_rgba8(40, 40, 40, 255),
                gradient: None,
                border: None,
                shadow: None,
                image: None,
            }],
            // The curve cuts only where the container declares a clip.
            // 曲线只在容器声明了裁剪的地方裁切。
            data: NodeData::Container(ContainerParams {
                clip: ui_core::layout::Clip {
                    x: ui_core::layout::Overflow::Hidden,
                    y: ui_core::layout::Overflow::Hidden,
                },
                ..Default::default()
            }),
            size_class: SizeClass {
                width: AxisSize::fixed(80.0),
                height: AxisSize::fixed(80.0),
                grow_x: Grow::No,
                grow_y: Grow::No,
            },
            ink_margin: Insets::ZERO,
            box_model: Default::default(),
            offset: ui_core::geom::Point::new(0.0, 0.0),
            cursor: None,
            sense: ui_core::Sense::NONE,
            disabled: false,
            grid: Default::default(),
            placement: Default::default(),
            env: None,
            children: vec![fixed_box("child", 80.0, 80.0, Color::from_rgba8(255, 0, 0, 255)).into()],
        };
        Decl::container(Id::str("root"), NodeKind::Column)
            .background(Color::from_rgba8(0, 0, 0, 255), Corners::ZERO)
            .child(parent)
    };
    ui_platform::from_decl(decl)
}

}
#[test]
fn a_rounded_parent_clips_its_child_to_the_curve() {
    // The child fills the parent's rect, so a rectangular clip would leave the corner
    // red; only a clip that follows the curve can empty it.
    // 子节点铺满父矩形，矩形裁剪会让角落保持红色；只有跟随曲线的裁剪才能让它空掉。
    let mut app = AppLoop::new(Rounded);
    let mut target = OffscreenTarget::new(120, 120);
    app.frame(&mut target, None);
    let px = &target.pixels;
    let at = |x: u32, y: u32| {
        let i = ((y * px.width + x) * 4) as usize;
        px.data[i + 2]
    };
    assert!(
        at(2, 2) < 60,
        "the corner must follow the curve, got red {}",
        at(2, 2)
    );
    assert!(
        at(40, 40) > 200,
        "the centre must stay painted, got red {}",
        at(40, 40)
    );
}

/// Focus style must reach the pixels, not just the declaration.
/// 焦点样式必须落到像素上，而不只是落在声明里。
#[test]
fn focusing_a_node_repaints_its_border_colour() {
    use ui_core::geom::Point;
    use ui_platform::AppLoop;
    struct Focusable;
    impl ui_platform::App for Focusable {
        fn view(&mut self, f: &mut ui_core::cx::Cx<'_>) -> Box<dyn ui_platform::Element> {
            let decl = {
            Decl::container(Id::str("card"), NodeKind::Column)
                .size(SizeClass::fixed(100.0, 60.0))
                // A press moves focus only to a node that subscribes to it.
                // 按下只会把焦点移给订阅了焦点的节点。
                .sense(ui_core::Sense::FOCUSABLE)
                .background(Color::from_rgba8(60, 130, 220, 255), Corners::ZERO)
                .border(
                    if f.focused() == Some(Id::str("card")) {
                        Color::from_rgba8(255, 220, 120, 255)
                    } else {
                        Color::from_rgba8(210, 225, 245, 255)
                    },
                    4.0,
                )
                .padding(Insets::all(4.0))
        };
    ui_platform::from_decl(decl)
}
}

    let mut target = OffscreenTarget::new(120, 80);
    let mut lp = AppLoop::new(Focusable);
    lp.frame(&mut target, None);
    let plain = target.pixels.data.clone();

    // Focus it the way a click would: press inside the card.
    // 按点击的方式聚焦：在卡片内按下。
    lp.dispatch(ui_core::Event::PointerMoved {
        pos: Point::new(60.0, 40.0),
    });
    lp.dispatch(ui_core::Event::PointerPressed {
        pos: Point::new(60.0, 40.0),
        button: ui_core::PointerButton::Primary,
    });
    lp.dispatch(ui_core::Event::PointerReleased {
        pos: Point::new(60.0, 40.0),
        button: ui_core::PointerButton::Primary,
    });
    assert_eq!(lp.focused(), Some(Id::str("card")), "click focuses");
    let changed = lp.frame(&mut target, Some(Point::new(60.0, 40.0)));
    let lit = &target.pixels.data;

    // The border pixel must actually change colour.
    // 边框像素必须真的变色。
    let at = |px: &[u8], x: usize, y: usize| [px[(y * 120 + x) * 4], px[(y * 120 + x) * 4 + 1], px[(y * 120 + x) * 4 + 2]];
    let edge_before = at(&plain, 2, 40);
    let edge_after = at(lit, 2, 40);
    assert_ne!(edge_before, edge_after, "focus did not repaint the border");
    // Pixels are BGRA; the focus colour is rgba(255,220,120).
    // 像素是 BGRA；焦点色为 rgba(255,220,120)。
    assert!(
        edge_after[2] > 200 && edge_after[1] > 180 && edge_after[0] < 160,
        "border is not the focus colour (BGRA): {edge_after:?}"
    );
    assert!(
        changed.damage != ui_core::Damage::None,
        "the frame reported no damage despite a style change"
    );
}

/// A clipped 40x40 parent holding a lifted 30x30 child drawn 80 px away, under a full-size
/// sibling declared after the parent: the child must still show, above that sibling.
/// 40x40 的裁剪容器里放一个被抬起、画到 80px 之外的 30x30 子节点，父之后还声明了一整幅兄弟：
/// 它仍须显示在那个兄弟之上。
struct Lifted;

impl App for Lifted {
    fn view(&mut self, _f: &mut ui_core::cx::Cx<'_>) -> Box<dyn ui_platform::Element> {
        let parent = Decl {
            id: Id::str("parent"),
            kind: NodeKind::Column,
            shapes: Vec::new(),
            data: NodeData::Container(ContainerParams {
                clip: ui_core::layout::Clip {
                    x: ui_core::layout::Overflow::Hidden,
                    y: ui_core::layout::Overflow::Hidden,
                },
                ..Default::default()
            }),
            size_class: SizeClass {
                width: AxisSize::fixed(40.0),
                height: AxisSize::fixed(40.0),
                grow_x: Grow::No,
                grow_y: Grow::No,
            },
            ink_margin: Insets::ZERO,
            box_model: Default::default(),
            offset: ui_core::geom::Point::new(0.0, 0.0),
            cursor: None,
            sense: ui_core::Sense::NONE,
            disabled: false,
            grid: Default::default(),
            placement: Default::default(),
            env: None,
            children: vec![fixed_box("lifted", 30.0, 30.0, Color::from_rgba8(255, 0, 0, 255))
                .offset(80.0, 80.0)
                .lifted()
                .into()],
        };
        ui_platform::from_decl(
            Decl::container(Id::str("root"), NodeKind::Column)
                .background(Color::from_rgba8(0, 0, 0, 255), Corners::ZERO)
                .child(parent)
                .child(fixed_box(
                    "cover",
                    160.0,
                    160.0,
                    Color::from_rgba8(0, 0, 255, 255),
                )),
        )
    }
}

#[test]
fn a_lifted_child_escapes_its_clip_and_paints_above_later_siblings() {
    let mut app = AppLoop::new(Lifted);
    let mut target = OffscreenTarget::new(160, 160);
    app.frame(&mut target, None);
    let px = &target.pixels;
    let i = ((90 * px.width + 90) * 4) as usize;
    // Pixels are BGRA.
    // 像素是 BGRA。
    let (blue, green, red) = (px.data[i], px.data[i + 1], px.data[i + 2]);
    assert!(
        red > 150 && green < 80 && blue < 80,
        "the lifted child must show above the sibling painted after its parent, got ({red},{green},{blue})"
    );
}
