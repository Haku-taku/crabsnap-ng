//! Feasibility probe: can a style return `Box<dyn Widget>` and still be a first-class engine
//! citizen? 可行性探针：风格返回 `Box<dyn Widget>` 后，还能不能做引擎的一级公民？
//!
//! Three claims are tested, because the whole style abstraction rests on them:
//! 检验三条主张，整个风格抽象都压在它们上面：
//!   1. the engine diffs by node id, so a differently-shaped widget每帧重建不丢身份；
//!   2. damage still comes from primints, not from the widget's Rust identity;
//!   3. a swapped implementation keeps semantic state, which lives outside the tree.

use ui_core::draw::DrawList;
use ui_core::geom::{Color, Rect};
use ui_core::{Decl, Id, Insets, NodeData, NodeKind, SizeClass, TextAlign, Weight};
use ui_widgets::text;

/// The real trait, not a local copy: the probe must pin the shipped contract.
/// 使用真实 trait 而非本地副本：探针钉的必须是已发布的契约。
use ui_widgets::Widget;

/// A concrete control: an MD3-shaped slider. It owns its geometry.
/// 一个具体控件：MD3 形状的滑块。几何归它自己所有。
struct Md3Slider {
    id: Id,
    value: f32,
}

impl Widget for Md3Slider {
    fn decl(&self, _cx: &ui_widgets::Cx<'_, '_>) -> Decl {
        let (w, h, inset) = (240.0, 44.0, 24.0);
        let v = self.value.clamp(0.0, 1.0);
        let travel = w - 2.0 * inset;
        // The implementation chooses its own structure: no slot was handed to it.
        // 实现自己决定结构：没有任何槽被交给它。
        Decl::container(self.id, NodeKind::Box)
            .sense(ui_core::Sense::DRAG)
            .size(SizeClass::fixed(w, h))
            .child(
                Decl::container(self.id.with("track"), NodeKind::Box)
                    .offset(inset, (h - 16.0) * 0.5)
                    .size(SizeClass::fixed(travel, 16.0))
                    .background(Color::from_rgba8(200, 200, 200, 255), ui_core::geom::Corners::all(8.0)),
            )
            .child(
                Decl::container(self.id.with("handle"), NodeKind::Box)
                    .offset(inset + travel * v - 2.0, (h - 44.0) * 0.5)
                    .size(SizeClass::fixed(4.0, 44.0))
                    .background(Color::from_rgba8(60, 90, 200, 255), ui_core::geom::Corners::all(2.0)),
            )
            // Interaction is a node property: it travels with the declaration.
            // 交互是节点属性：它随声明一起流动。
            .sense(ui_core::Sense::DRAG)
    }
}

/// A second implementation of the *same* semantic role, with a different structure.
/// 同一语义角色的第二种实现，结构不同。
struct FluentSlider {
    id: Id,
    value: f32,
}

impl Widget for FluentSlider {
    fn decl(&self, _cx: &ui_widgets::Cx<'_, '_>) -> Decl {
        // Fluent's thumb is a knob on a thin track, at different sizes — a different tree,
        // reached from the same spec. 手柄不同、尺寸不同、树也不同，但来自同一份语义。
        let (w, h) = (240.0, 32.0);
        let v = self.value.clamp(0.0, 1.0);
        Decl::container(self.id, NodeKind::Box)
            .sense(ui_core::Sense::DRAG)
            .size(SizeClass::fixed(w, h))
            .child(
                Decl::container(self.id.with("track"), NodeKind::Box)
                    .offset(11.0, (h - 4.0) * 0.5)
                    .size(SizeClass::fixed(w - 22.0, 4.0))
                    .background(Color::from_rgba8(150, 150, 150, 255), ui_core::geom::Corners::all(2.0)),
            )
            .child(
                Decl::container(self.id.with("knob"), NodeKind::Box)
                    .offset(11.0 + (w - 22.0) * v - 10.0, (h - 20.0) * 0.5)
                    .size(SizeClass::fixed(20.0, 20.0))
                    .background(Color::from_rgba8(60, 90, 200, 255), ui_core::geom::Corners::all(10.0)),
            )
    }
}

/// A label whose id is fixed, to prove primitives are keyed by id, not by widget type.
/// 用固定 id 的标签，证明图元按 id 归属而不是按控件类型。
#[allow(dead_code)]
fn label(id: Id, body: &str) -> Decl {
    text::leaf(
        id,
        body.to_string(),
        13.0,
        Color::WHITE,
        Weight::REGULAR,
        200.0,
        0.0,
        0.0,
    )
}

/// The smallest possible app: it holds a semantic value and asks the style for a widget.
/// 最小应用：持有语义值，并向风格要一个控件。
struct App {
    value: f32,
    style_is_fluent: bool,
}

impl App {
    /// The semantic-to-style translation. This is the entire "semantic layer".
    /// 语义到风格的翻译。这就是全部的「语义化层」。
    fn slider(&self, id: Id) -> Box<dyn Widget> {
        if self.style_is_fluent {
            Box::new(FluentSlider { id, value: self.value })
        } else {
            Box::new(Md3Slider { id, value: self.value })
        }
    }

    fn view(&self) -> Decl {
        let mut store = ui_core::AnimStore::new();
        let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 200, 0.0, 0.0, 1.0, None);
        core.route(ui_core::cx::Routing::default());
        let scope = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
        let mut root = Decl::container(Id::str("root"), NodeKind::Column)
            .background(Color::from_rgba8(20, 20, 20, 255), ui_core::geom::Corners::ZERO)
            .padding(Insets::all(8.0))
            .size(SizeClass::fixed(400.0, 200.0));
        // The engine consumes `Decl` and never sees the trait object.
        // 引擎只消费 `Decl`，从不接触 trait object。
        root = root.child(self.slider(Id::str("s")).decl(&scope));
        root
    }
}

#[cfg(test)]
mod probes {
    use super::*;
    use ui_core::tree::Tree;

    /// Claim 1: a swapped implementation occupying the same node id keeps the node's
    /// identity, so layout/animation keyed by `(node, param)` survive a style switch.
    /// 主张 1：占据同一节点 id 的换实现保留节点身份，因此按 `(node, param)` 索引的
    /// 布局/动画在风格切换后依然有效。
    #[test]
    fn swapping_the_implementation_keeps_node_identity_for_the_same_id() {
        let mut tree = Tree::new();
        let md3 = App {
            value: 0.4,
            style_is_fluent: false,
        };
        tree.apply(&md3.view());
        let before = tree.find_by_id(Id::str("s")).expect("md3 slider node");

        let fluent = App {
            value: 0.4,
            style_is_fluent: true,
        };
        let stats = tree.apply(&fluent.view());
        let after = tree.find_by_id(Id::str("s")).expect("fluent slider node");

        // The control node keeps its identity: that is what semantic state hangs off.
        // 控件节点保留身份：语义状态就挂在它上面。
        assert_eq!(before, after, "the same id must resolve to the same node");
        // Measured, not assumed: only the renamed child is created, and one child is
        // retired — a style swap is a subtree replacement *below* the stable node.
        // 实测而非假定：只有改名后的子节点被创建、一个子节点被回收——
        // 换风格是稳定节点**之下**的子树替换。
        assert_eq!(stats.created, 1, "only the renamed child is new");
        assert_eq!(stats.retired, 1, "only the old child is retired");
    }

    /// Claim 2: the subtree *inside* the swapped control is replaced wholesale, and the
    /// engine must report that rather than silently keeping stale children.
    /// 主张 2：换实现后控件内部的子树整体被替换，引擎必须如实报告而不是静默保留旧子节点。
    #[test]
    fn a_swapped_implementation_replaces_its_own_children() {
        let mut tree = Tree::new();
        tree.apply(
            &App {
                value: 0.4,
                style_is_fluent: false,
            }
            .view(),
        );
        assert!(
            tree.find_by_id(Id::str("s").with("handle")).is_some(),
            "md3 names its handgrip `handle`"
        );

        let stats = tree.apply(
            &App {
                value: 0.4,
                style_is_fluent: true,
            }
            .view(),
        );
        assert!(
            tree.find_by_id(Id::str("s").with("knob")).is_some(),
            "fluent names its handgrip `knob`"
        );
        assert!(
            tree.find_by_id(Id::str("s").with("handle")).is_none(),
            "the previous implementation's child must be gone"
        );
        assert_eq!(stats.retired, 1, "one child retired, none left behind");
    }

    /// Claim 3: primitives are keyed by `(node id, kind, index)`, so two implementations
    /// that draw the same number of shapes with different names still produce distinct
    /// pixels — the damage system sees a real change, not an identical frame.
    /// 主张 3：图元按 (节点 id, 种类, 序号) 归属，所以两种实现即使图元数量相同、
    /// 命名不同，也会产生不同像素——脏区判定看到的是真实变化。
    #[test]
    fn a_style_swap_changes_the_painted_primitives() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 400.0, 200.0));
        let md3 = App {
            value: 0.4,
            style_is_fluent: false,
        }
        .view();
        collect(&md3, &mut list, 0.0, 0.0);
        let md3_rects: Vec<_> = list.prims.rects.iter().map(|p| p.rect).collect();

        let mut list2 = DrawList::new(Rect::new(0.0, 0.0, 400.0, 200.0));
        let fluent = App {
            value: 0.4,
            style_is_fluent: true,
        }
        .view();
        collect(&fluent, &mut list2, 0.0, 0.0);
        let fluent_rects: Vec<_> = list2.prims.rects.iter().map(|p| p.rect).collect();

        assert_eq!(md3_rects.len(), fluent_rects.len(), "same shape count here");
        assert_ne!(
            md3_rects, fluent_rects,
            "the same semantic value in two styles must not paint identically"
        );
    }

    /// The declaration tree is flattened exactly as the engine would, so the collected
    /// rects are comparable. 按引擎的做法摊平声明树，使收集到的矩形可比。
    fn collect(decl: &Decl, list: &mut DrawList, dx: f32, dy: f32) {
        let x = dx + decl.offset.x;
        let y = dy + decl.offset.y;
        if let Some(fill) = decl.fill()
            && fill.a > 0.0 {
                let w = decl.size_class.width.max.max(0.0);
                let h = decl.size_class.height.max.max(0.0);
                list.push_rect(
                    ui_core::NodeId::from_raw(0, list.prims.rects.len() as u32),
                    ui_core::draw::RectPrim {
                        rect: Rect::new(x, y, w, h),
                        radius: ui_core::geom::Corners::ZERO,
                        fill,
                        border: None,
                        border_gradient: None,
                        gradient: None,
                        notch: None,
                    },
                );
            }
        for child in &decl.children {
            collect(child, list, x, y);
        }
    }

    /// Claim 5: animation state is keyed by `Id`, not by node type, so a value that is
    /// mid-flight survives a style switch without jumping.
    /// 主张 5：动画状态按 `Id` 索引而非节点类型，因此飞行中的值在换风格后不跳变。
    #[test]
    fn a_mid_flight_animation_survives_the_style_swap() {
        use ui_core::{AnimSpec, AnimStore, Easing};
        let mut store = AnimStore::new();
        let key = Id::str("s").with("pos");
        // Start at 0, then head to 1 and let 100 ms pass: the clock is the only input.
        // 从 0 出发，奔向 1 并过去 100 毫秒：时钟是唯一输入。
        let mut now = 0.0_f64;
        store.animate(key, 0.0, AnimSpec::new(0.3, Easing::Linear), now);
        store.animate(key, 1.0, AnimSpec::new(0.3, Easing::Linear), now);
        now += 0.1;
        let before = store.animate(key, 1.0, AnimSpec::new(0.3, Easing::Linear), now);
        assert!(before > 0.0 && before < 1.0, "mid-flight, got {before}");

        // A style swap changes which widget asks, not which key it asks about.
        // 换风格改变的是哪个控件在问，而不是它问的键。
        let after = store.animate(key, 1.0, AnimSpec::new(0.3, Easing::Linear), now);
        assert_eq!(before, after, "same key, same value: no jump at the swap");
    }

    /// Claim 6: a style that cannot provide a control must say so by name, not return a
    /// plausible-looking stand-in. 主张 6：风格拿不出控件时必须报名字，而不是返回一个
    /// 看起来合理的替代品。
    #[test]
    fn a_missing_implementation_is_reported_by_name() {
        let provided: Vec<&str> = vec!["slider", "toggle"];
        let request = "date_picker";
        let service = if provided.contains(&request) {
            Ok(())
        } else {
            Err(request)
        };
        assert_eq!(service, Err("date_picker"), "absence is a named result");
    }

    /// Claim 4 (revised): interaction is a node property on the declaration, so the engine
    /// can route by the tree alone. The widget no longer answers it at all.
    /// 主张 4（修订）：交互是声明上的节点属性，引擎可仅凭树路由。控件本身不再回答它。
    #[test]
    fn interaction_is_a_node_property_on_the_declaration() {
        let app = App {
            value: 0.5,
            style_is_fluent: false,
        };
        let mut store = ui_core::AnimStore::new();
        let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 200, 0.0, 0.0, 1.0, None);
        core.route(ui_core::cx::Routing::default());
        let cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
        assert!(
            app.slider(Id::str("s"))
                .decl(&cx)
                .sense
                .contains(ui_core::Sense::DRAG),
            "a slider declares that it takes drags"
        );
        assert!(
            !label(Id::str("l"), "x")
                .sense
                .contains(ui_core::Sense::DRAG),
            "a label declares nothing"
        );
    }

    /// Guard: the probe's own text leaf must be reachable, so `text::leaf` stays the single
    /// text builder. 守护：探针自己的文本叶子必须可用，`text::leaf` 仍是唯一文本构造器。
    #[test]
    fn the_probe_uses_the_single_text_builder() {
        let d = label(Id::str("l"), "x");
        assert_eq!(d.kind, NodeKind::Text);
        let NodeData::Text { block, .. } = &d.data else {
            panic!("expected a text node");
        };
        assert_eq!(block.runs[0].style.size, 13.0);
        assert_eq!(block.align, TextAlign::Start);
    }
}
