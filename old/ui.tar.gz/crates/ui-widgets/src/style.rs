//! Style selection and the one-frame channel a style builds through.
//! 风格选择，以及风格构建所用的一次性通道。

use ui_style::{SliderSpec, ToggleSpec};


use crate::widget::Widget;
use crate::scaffold::ScaffoldSpec;

/// A style kit: a design language asked for concrete controls; the engine only sees the `Decl`.
/// 风格包：被索取具体控件的设计语言；引擎只会看到它产出的 `Decl`。
///
/// None of these take a scope argument: the scope travels on the declaration tree, so a
/// control reads the one in force where it is built. Passing it by hand let a caller hold
/// two of them at once, which is exactly the bug this shape removes.
/// 这些方法都不收作用域参数：作用域随声明树流动，控件读到的是构建所在地生效的那一层。
/// 手工传参会让调用方同时持有两份，这个形状把那个缺陷直接消除。
pub trait StyleKit {
    /// A slider for `spec`.
    /// 按 `spec` 产出一个滑块。
    fn slider(&self, spec: &SliderSpec<'_>, cx: &mut crate::cx::Cx<'_, '_>) -> Box<dyn Widget>;

    /// A toggle for `spec`.
    /// 按 `spec` 产出一个开关。
    fn toggle(&self, spec: &ToggleSpec<'_>, cx: &mut crate::cx::Cx<'_, '_>) -> Box<dyn Widget>;

    /// A page skeleton that places the six regions itself.
    /// 自行摆放六个区域的页面骨架。
    fn scaffold(&self, spec: &ScaffoldSpec<'_>, cx: &mut crate::cx::Cx<'_, '_>) -> Box<dyn Widget>;
}

