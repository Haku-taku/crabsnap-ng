//! Bridges a style-aware control to the engine's element contract.
//! 把带样式的控件接到引擎的元素契约上。

use std::sync::Arc;

use ui_core::change::Change;
use ui_core::geom::Rect;
use ui_core::Decl;
use ui_style::Env;

use crate::cx::Cx;
use crate::widget::Widget;

/// A control plus the scope it was built under, as the engine sees it.
/// 控件及其构建时所用作用域，即引擎所见的形态。
pub struct Styled {
    control: Box<dyn Widget>,
    env: Arc<Env>,
}

impl Styled {
    pub fn new(control: Box<dyn Widget>, env: Arc<Env>) -> Self {
        Self { control, env }
    }
}

impl ui_platform::Element for Styled {
    fn decl(&self, core: &mut ui_core::cx::Cx<'_>) -> Decl {
        let cx = Cx::new(core, self.env.clone());
        let mut decl = self.control.decl(&cx);
        // A control that paints its own disabled colours must not be faded again.
        // 自行绘制禁用颜色的控件，不得被适配器再淡化一次。
        if cx.state(decl.id).disabled && !self.control.handles_disabled() {
            let base = decl_opacity(&decl);
            decl = decl.opacity(base * DISABLED_OPACITY);
        }
        decl
    }

    fn cache_key(&self) -> Option<ui_core::CachedKey> {
        // The scope travels in `env`; the app announces a theme change by invalidating
        // declarations, which is the same contract the engine already documents.
        // 作用域在 `env` 里；主题变化由 app 作废声明来通报，引擎的契约本就如此。
        self.control.cache_key()
    }

    fn change(&self, state: &ui_platform::WidgetState, bounds: Rect) -> Option<Change> {
        // One choke point: an inert control never reports, whatever its own code says.
        // 唯一的收口：惰性控件绝不上报，无论自己的代码怎么写。
        if state.disabled {
            return None;
        }
        self.control.change(state, bounds)
    }
}

/// Reference opacity for disabled content: MD3 states `onSurface` at 38%.
/// 禁用内容的参考不透明度：MD3 规定 `onSurface` 取 38%。
const DISABLED_OPACITY: f32 = 0.38;

/// The root's own group opacity, so the fade composes with what the control already set.
/// 根节点自身的组不透明度，使淡出与控件已设的值复合而非覆盖。
fn decl_opacity(decl: &Decl) -> f32 {
    decl.data.params().map(|p| p.opacity).unwrap_or(1.0)
}

#[cfg(test)]
mod tests {
    use super::*;
    use ui_core::{Id, NodeKind};
    use ui_platform::Element;

    struct Block(Id);

    impl Widget for Block {
        fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
            Decl::container(self.0, NodeKind::Box).sense(ui_core::Sense::HOVER)
        }
    }

    /// A control reports only when it is live; the adapter enforces that, not the control.
    /// 控件只在存活时上报；这件事由适配器保证，而不是靠控件自觉。
    #[test]
    fn an_inert_control_reports_nothing() {
        struct Reports(Id);

        impl Widget for Reports {
            fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
                Decl::container(self.0, NodeKind::Box)
            }
            fn change(
                &self,
                _state: &ui_platform::WidgetState,
                _bounds: Rect,
            ) -> Option<Change> {
                Some(Change::Activated)
            }
        }

        let styled = Styled::new(Box::new(Reports(Id::str("r"))), Env::root());
        let live = ui_platform::WidgetState::default();
        assert!(styled.change(&live, Rect::ZERO).is_some(), "a live control speaks");
        let inert = ui_platform::WidgetState {
            disabled: true,
            ..Default::default()
        };
        assert!(
            styled.change(&inert, Rect::ZERO).is_none(),
            "an inert control must stay silent"
        );
    }

    /// The adapter must not lose what the control declared.
    /// 适配器不得丢失控件声明的内容。
    #[test]
    fn a_styled_control_declares_what_the_control_declared() {
        let control = Block(Id::str("b"));
        let direct = Cx::for_test(|cx| control.decl(cx));
        let styled = Styled::new(Box::new(Block(Id::str("b"))), Env::root());
        let mut store = ui_core::AnimStore::new();
        let mut core = ui_core::cx::Cx::new(&mut store, 0, 100, 100, 0.0, 0.0, 1.0, None);
        let via_element = styled.decl(&mut core);
        assert_eq!(via_element.id, direct.id);
        assert_eq!(via_element.kind, direct.kind);
        assert_eq!(via_element.sense, direct.sense);
    }

    #[test]
    fn a_control_that_handles_disabled_is_not_faded_a_second_time() {
        // The whole point of `handles_disabled`: a control that already paints 12%/38% must
        // reach the engine at full opacity, or it is dimmed twice.
        // `handles_disabled` 的意义：已自行画 12%/38% 的控件，到引擎时必须保持原不透明度，否则被二次压暗。
        struct SelfDrawn(Id);
        impl Widget for SelfDrawn {
            fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
                Decl::container(self.0, NodeKind::Box)
            }
            fn handles_disabled(&self) -> bool {
                true
            }
        }
        let opacity = |d: &Decl| d.data.params().map(|p| p.opacity).unwrap_or(1.0);
        let run = |widget: Box<dyn Widget>| {
            let mut store = ui_core::AnimStore::new();
            let mut core = ui_core::cx::Cx::new(&mut store, 0, 100, 100, 0.0, 0.0, 1.0, None);
            core.route(ui_core::cx::Routing {
                disabled: vec![Id::str("x")],
                ..ui_core::cx::Routing::default()
            });
            opacity(&Styled::new(widget, Env::root()).decl(&mut core))
        };
        assert!(
            (run(Box::new(SelfDrawn(Id::str("x")))) - 1.0).abs() < 1e-6,
            "a self-drawing control keeps its opacity"
        );
        assert!(
            (run(Box::new(Block(Id::str("x")))) - 0.38).abs() < 1e-6,
            "a plain control still fades to 38%"
        );
    }
}
