//! The one build context: engine facts, derived routing queries, and the two writable doors.
//! 唯一的构建上下文：引擎事实、派生的路由查询，以及两扇可写之门。
//!
//! Everything that used to be four near-duplicate structs (`FrameInfo`, `Fx`, `BuildCtx`,
//! `Frame`) is one type here. A narrower capability is *derived* from it, never declared
//! beside it, so `now` and `scale` can only be wrong in one place.
//! 过去四个近似重复的结构（`FrameInfo`、`Fx`、`BuildCtx`、`Frame`）在这里合成一个类型。
//! 更窄的能力是从它**派生**的，而不是在它旁边另立一个，因此 `now` 与 `scale` 只可能错在一处。

use std::sync::Arc;

use ui_core::{AnimStore, AnimSpec, Id};
use ui_i18n::{Args, Catalog, Msg};
use ui_style::Env;

use crate::state::WidgetState;

/// Engine facts for one build, plus what may be written during it.
/// 一次构建的引擎事实，以及构建期间可写的东西。
pub struct Cx<'a, 'b> {
    /// Everything the engine knows and the one door it opens, owned by `ui-core`.
    /// 引擎知道的一切以及它打开的唯一一道门，由 `ui-core` 拥有。
    core: &'b mut ui_core::cx::Cx<'a>,
    env: Arc<Env>,
    /// Resolved once per element build; the Env chain is not walked per lookup.
    /// 每个元素构建时解析一次；每次查字符串不再走 Env 链。
    i18n: Option<Arc<Catalog>>,
}

impl<'a, 'b> Cx<'a, 'b> {
    /// Wrap the engine context the app was handed; the widget layer adds scope and state.
    /// 包住交到 app 手上的引擎上下文；控件层在此之上加作用域与状态。
    pub fn new(core: &'b mut ui_core::cx::Cx<'a>, env: Arc<Env>) -> Cx<'a, 'b> {
        let i18n = env.find::<Arc<Catalog>>().cloned();
        Cx {
            core,
            env,
            i18n,
        }
    }

    /// A built-in message: one array index and one refcount bump.
    /// 一条内置消息：一次数组索引加一次引用计数。
    pub fn t(&self, msg: Msg) -> Arc<str> {
        self.catalog().text(msg)
    }

    /// A built-in message with arguments, formatted on demand.
    /// 带参数的内置消息，按需格式化。
    pub fn t_args(&self, msg: Msg, args: &Args<'_>) -> Arc<str> {
        self.catalog().text_with(msg, args)
    }

    /// The app's catalog, or the built-in English one for tests and bare `Env::root()`.
    /// 应用 catalog；测试与裸 `Env::root()` 使用内置英文 catalog。
    pub(crate) fn catalog(&self) -> &Catalog {
        if let Some(catalog) = self.i18n.as_deref() {
            return catalog;
        }
        static WARNED: std::sync::atomic::AtomicBool =
            std::sync::atomic::AtomicBool::new(false);
        if !WARNED.swap(true, std::sync::atomic::Ordering::Relaxed) {
            log::warn!("ui-widgets: no i18n catalog in Env; using built-in English");
        }
        Catalog::english()
    }

    /// A throwaway context for tests: no routing, one frame, its own store.
    /// 测试用的临时上下文：无路由、单帧、自有存储。
    pub fn for_test<R>(f: impl FnOnce(&Cx<'_, '_>) -> R) -> R {
        let mut store = ui_core::AnimStore::new();
        let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 200, 0.0, 0.0, 1.0, None);
        core.route(ui_core::cx::Routing::default());
        let cx = Cx::new(&mut core, Env::root());
        f(&cx)
    }

    /// The same as `for_test`, for callers that build controls and need `&mut`.
    /// 与 `for_test` 相同，供需要 `&mut` 来构建控件的调用方使用。
    pub fn for_test_mut<R>(f: impl FnOnce(&mut Cx<'_, '_>) -> R) -> R {
        let mut store = ui_core::AnimStore::new();
        let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 200, 0.0, 0.0, 1.0, None);
        core.route(ui_core::cx::Routing::default());
        let mut cx = Cx::new(&mut core, Env::root());
        f(&mut cx)
    }

    /// The engine facts, for code that only needs routing or the clock.
    /// 引擎事实，供只需要路由或时钟的代码使用。
    pub fn core(&self) -> &ui_core::cx::Cx<'a> {
        self.core
    }

    /// The size `block` takes at `max_width`, from the host's own text measurer.
    /// 宿主自带测量器量出的 `block` 在 `max_width` 下的尺寸。
    ///
    /// `None` where no measurer is attached, which is every test context.
    /// 未接入测量器时（所有测试上下文）为 `None`。
    pub fn text_size(
        &self,
        block: &ui_core::text::TextBlock,
        max_width: f32,
    ) -> Option<ui_core::geom::Size> {
        self.core.text_size(block, max_width)
    }

    /// The rect `id` took in the last layout, for a control that measures its siblings.
    /// `id` 在上一帧布局里占的矩形，供需要量兄弟节点的控件使用。
    ///
    /// `None` before the first layout, or when the host attached no retained tree.
    /// 首次布局之前，或宿主未挂上保留树时为 `None`。
    pub fn rect_of(&self, id: Id) -> Option<ui_core::geom::Rect> {
        self.core.rect_of(id)
    }

    /// The same frame under a narrower scope; store, clock and routing are shared.
    /// 同一帧在更窄作用域下的视图；存储、时钟与路由共享。
    pub fn at_scope<'c>(&'c mut self, env: Arc<Env>) -> Cx<'a, 'c> {
        let i18n = env.find::<Arc<Catalog>>().cloned();
        Cx {
            core: &mut *self.core,
            env,
            i18n,
        }
    }

    /// Turn a control into an engine element bound to the scope in force here.
    /// 把控件变成绑定到当前作用域的引擎元素。
    pub fn element(&self, control: Box<dyn crate::widget::Widget>) -> Box<dyn ui_platform::Element> {
        Box::new(crate::styled::Styled::new(control, self.env.clone()))
    }

    /// Run a closure over a context of the same frame, for building a subtree once.
    /// 在同一帧的上下文上运行闭包，用于一次性构建子树。
    pub fn with_cx<R>(&mut self, f: impl FnOnce(&Cx<'_, '_>) -> R) -> R {
        let env = self.env.clone();
        let i18n = env.find::<Arc<Catalog>>().cloned();
        let cx = Cx { core: &mut *self.core, env, i18n };
        f(&cx)
    }

    pub fn now(&self) -> f64 {
        self.core.now()
    }

    pub fn scale(&self) -> f32 {
        self.core.scale()
    }

    /// This node's interaction state.
    /// 本节点的交互状态。
    pub fn state(&self, id: Id) -> WidgetState {
        WidgetState::of(self.core(), id)
    }

    /// The scope in force, for a style to resolve its parameters against.
    /// 当前生效的作用域，供风格解析自己的参数。
    pub fn env(&self) -> &Env {
        &self.env
    }

    /// The scope as a handle, for code that needs to share or re-layer it.
    /// 以句柄形式给出作用域，供需要共享或重新分层的代码使用。
    pub fn env_handle(&self) -> &Arc<Env> {
        &self.env
    }

    /// Scene `id` to one node: animation writes and state reads are all it exposes.
    /// 把 `id` 限定到单个节点：只暴露它的动画写入与状态读取。
    pub fn at(&mut self, id: Id) -> NodeCx<'_> {
        let state = self.state(id);
        let scale = self.core.scale();
        // The clock is snapshotted, not recorded: the values derived from it are recorded
        // per animation below, which is what actually decides whether the decl changed.
        // 时钟只取快照而不记录：真正决定声明是否变化的是下面逐个动画记录的取值。
        let now = self.core.clock();
        let rec = self.core.recorder_handle();
        // Text editing facts belong to the node being built, so they are snapshotted here;
        // a control must not have to reach past its own node view for its own caret.
        // 文本编辑事实属于正在构建的节点，因此在此快照；控件不必为自己的插入符越出节点视图。
        let caret = self.core.caret_for(id);
        let preedit = self.core.preedit_for(id);
        let selection = self.core.selection_for(id);
        NodeCx {
            id,
            state,
            scale,
            now,
            anim: self.core.anim_mut(),
            rec: Some(rec),
            caret,
            preedit,
            selection,
        }
    }
}

/// One node's slice of the build: its state, and the animations it owns.
/// 单个节点在构建中的切片：它的状态，以及它拥有的动画。
pub struct NodeCx<'a> {
    id: Id,
    state: WidgetState,
    scale: f32,
    anim: &'a mut ui_core::AnimStore,
    now: f64,
    /// Where animation reads are recorded, so a cached subtree can tell it went stale.
    /// 动画读取的记录处，使缓存的子树能判断自己已过期。
    rec: Option<std::rc::Rc<std::cell::RefCell<ui_core::memo::Recorder>>>,
    /// This node's caret, composition and selection, as the engine holds them.
    /// 引擎持有的本节点插入符、组合与选区。
    caret: Option<usize>,
    preedit: Option<ui_core::ime::Preedit>,
    selection: Option<ui_core::TextSelection>,
}

impl<'a> NodeCx<'a> {
    /// Build a node view directly from the pieces the engine context holds.
    /// 直接由引擎上下文持有的各部分构造节点视图。
    pub fn new(id: Id, state: WidgetState, scale: f32, now: f64, anim: &'a mut AnimStore) -> Self {
        Self {
            id,
            state,
            scale,
            anim,
            now,
            rec: None,
            caret: None,
            preedit: None,
            selection: None,
        }
    }

    /// This node's caret offset, when it holds focus.
    /// 本节点的插入符位置，持有焦点时才有。
    pub fn caret(&self) -> Option<usize> {
        self.caret
    }

    /// The input method's composition for this node, never merged into the buffer.
    /// 本节点的输入法组合内容，绝不并入缓冲。
    pub fn preedit(&self) -> Option<&ui_core::ime::Preedit> {
        self.preedit.as_ref()
    }

    /// This node's text selection, when it has one.
    /// 本节点的文本选区，有时才有。
    pub fn selection(&self) -> Option<ui_core::TextSelection> {
        self.selection
    }

    fn record(&self, dep: ui_core::Dep) {
        if let Some(rec) = self.rec.as_ref()
            && let Ok(mut rec) = rec.try_borrow_mut() {
                rec.push(dep);
            }
    }

    pub fn id(&self) -> Id {
        self.id
    }

    /// Interaction state of the node being built.
    /// 正在构建的节点的交互状态。
    pub fn state(&self) -> WidgetState {
        self.state
    }

    pub fn scale(&self) -> f32 {
        self.scale
    }

    /// The frame's time in seconds, for a widget that turns a delta into a rate.
    /// 本帧时间（秒），供把位移换算成速率的控件使用。
    pub fn now(&self) -> f64 {
        self.now
    }

    /// Drive one atomic animation instance and read what to draw this frame.
    /// 推进一个原子动画实例，并读出本帧应绘制的值。
    pub fn animate(&mut self, id: Id, target: f32, spec: AnimSpec) -> f32 {
        let v = self.anim.animate(id, target, spec, self.now);
        self.record(ui_core::Dep::Anim {
            id,
            target,
            spec,
            value: v,
        });
        v
    }

    /// Drive one spring instance in engine seconds; its velocity is units per second.
    /// 以引擎秒推进一个弹簧实例；速度单位为每秒。
    ///
    /// The spring keeps the frame loop awake until it rests, so it never freezes mid-ring.
    /// 弹簧落定前会一直唤醒帧循环，因此绝不会停在振铃中途。
    pub fn spring(
        &mut self,
        id: Id,
        target: f32,
        stiffness: f32,
        damping: f32,
    ) -> ui_core::anim::SpringState {
        let state = self.anim.spring(id, target, stiffness, damping, self.now);
        self.record(ui_core::Dep::Value {
            id,
            value: state.x,
        });
        state
    }

    /// The spring's current value, unadvanced: for choosing which spring to hand it to.
    /// 弹簧当前值，不推进：供决定把它交给哪条弹簧使用。
    pub fn spring_value(&self, id: Id) -> Option<f32> {
        self.anim.spring_value(id).map(|s| s.x)
    }

    /// Drop a spring so the next drive starts at its target, not on the old trajectory.
    /// 丢弃一条弹簧，下次驱动从目标起步而不是延续旧轨迹。
    pub fn forget_spring(&mut self, id: Id) {
        self.anim.forget_spring(id);
    }

    /// [`spring`](Self::spring) that starts at `hint` units/s when the target changes.
    /// 目标变化时以 `hint` 单位/秒出发的 [`spring`](Self::spring)。
    pub fn spring_hinted(
        &mut self,
        id: Id,
        target: f32,
        stiffness: f32,
        damping: f32,
        hint: f32,
    ) -> ui_core::anim::SpringState {
        let state = self
            .anim
            .spring_hinted(id, target, stiffness, damping, hint, self.now);
        self.record(ui_core::Dep::Value {
            id,
            value: state.x,
        });
        state
    }

    /// Drive a colour; the engine carries the blend on one clock.
    /// 推进一个颜色；过渡由引擎在一个时钟上完成。
    pub fn animate_colour(
        &mut self,
        id: Id,
        target: ui_core::geom::Color,
        spec: AnimSpec,
    ) -> ui_core::geom::Color {
        let v = self.anim.animate_colour(id, target, spec, self.now);
        self.record(ui_core::Dep::AnimColour {
            id,
            target,
            spec,
            value: v,
        });
        v
    }

    /// Drive a parameter along keyframes; the last stop is its target.
    /// 沿关键帧推进一个参数；最后一个关键帧就是它的目标。
    pub fn animate_stops(
        &mut self,
        id: Id,
        stops: &[ui_core::anim::Stop],
        spec: AnimSpec,
    ) -> f32 {
        let v = self.anim.animate_stops(id, stops, spec, self.now);
        self.record(ui_core::Dep::AnimStops {
            id,
            stops: stops.to_vec(),
            spec,
            value: v,
        });
        v
    }

    /// The current value without asking it to move.
    /// 只读当前值，不要求它移动。
    pub fn value(&self, id: Id) -> f32 {
        let v = self.anim.value(id, self.now).unwrap_or(0.0);
        self.record(ui_core::Dep::Value { id, value: v });
        v
    }

    /// Seconds since this id first asked: a loop's own clock, zero on the first frame.
    /// 本 id 首次询问至今的秒数：循环自己的时钟，首帧为零。
    ///
    /// Reading it asks for every frame; a control that stops reading stops asking.
    /// 读取它即要求每一帧；不再读取的控件也就不再要求。
    pub fn age(&mut self, id: Id) -> f32 {
        let age = self.anim.age(id, self.now) as f32;
        self.record(ui_core::Dep::Age { id, age });
        age
    }

    /// Forget an id's age, so the next [`age`] read counts from zero: a gesture that
    /// ended must not leave its clock running into the next one.
    /// 忘掉某 id 的年龄，下次 [`age`] 从零计时：结束的手势不该把时钟留给下一次。
    pub fn forget_age(&mut self, id: Id) {
        self.anim.forget_age(id);
    }

    /// One instance's state; read it *after* retargeting so it describes this frame.
    /// 单个实例的状态；要在重定向**之后**读取，它描述的才是本帧。
    pub fn status(&self, id: Id) -> Option<ui_core::anim::Status> {
        let status = self.anim.status(id, self.now);
        self.record(ui_core::Dep::Status { id, status });
        status
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ui_core::Easing;

    /// Tests hold the engine context on the stack so both lives are concrete.
    /// 测试把引擎上下文放在栈上，使两个生命周期都是具体的。
    fn wrap<'a>(
        core: &'a mut ui_core::cx::Cx<'a>,
        env: Arc<Env>,
    ) -> Cx<'a, 'a> {
        Cx::new(core, env)
    }

    #[test]
    fn one_node_view_writes_the_engine_store() {
        // `at` borrows the engine store, it does not copy it: a write must be visible.
        // `at` 借用引擎存储而不是复制它：写入必须看得见。
        let mut anim = AnimStore::new();
        let mut core = ui_core::cx::Cx::new(&mut anim, 3, 200, 100, 5.0, 0.016, 2.0, None);
        let mut cx = wrap(&mut core, Env::root());
        let key = Id::str("k");
        {
            let mut node = cx.at(Id::str("node"));
            node.animate(key, 1.0, AnimSpec::new(0.1, Easing::Linear));
        }
        let node = cx.at(Id::str("node"));
        assert_eq!(node.value(key), 1.0);
    }

    #[test]
    fn a_catalog_on_the_env_reaches_the_widget_context() {
        // The Env layer is the only wiring point; a widget asks `cx`, never a global.
        // Env 层是唯一的接线点；控件只问 `cx`，从不问全局。
        let zh: ui_i18n::LanguageIdentifier = "zh-CN".parse().expect("zh-CN");
        let en: ui_i18n::LanguageIdentifier = "en".parse().expect("en");
        let catalog = Arc::new(ui_i18n::Catalog::builtin(zh, en).expect("catalog"));
        let env = Env::with(Some(Env::root()), catalog);
        let mut anim = AnimStore::new();
        let mut core = ui_core::cx::Cx::new(&mut anim, 0, 200, 100, 0.0, 0.0, 1.0, None);
        let cx = wrap(&mut core, env);
        assert_eq!(
            &*cx.t(ui_i18n::Msg::MD3_DATE_PICKER_HEADER),
            "选择日期"
        );
        let mut args = ui_i18n::Args::new();
        args.set("count", 3);
        assert_eq!(
            &*cx.t_args(ui_i18n::Msg::WIDGETS_LIST_SELECTED_COUNT, &args),
            "已选择 3 个项目"
        );
    }

    #[test]
    fn the_wrapper_does_not_fork_the_engine_facts() {
        // A wrapper adds a scope; it must not invent its own clock or frame number.
        // 包装层只加作用域；不得自造时钟或帧号。
        let mut anim = AnimStore::new();
        let mut core = ui_core::cx::Cx::new(&mut anim, 3, 200, 100, 5.0, 0.016, 2.0, None);
        let cx = wrap(&mut core, Env::root());
        assert_eq!(cx.now(), 5.0);
        assert_eq!(cx.scale(), 2.0);
        assert_eq!(cx.core().frame(), 3);
    }
}
