//! A unified scroll container: fixed or filling size, engine-owned offset, optional scrollbar.
//! 统一滚动容器：固定或填满尺寸、引擎管理的偏移、可选滚动条。

use std::rc::Rc;

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Rect};
use ui_core::{AxisSize, Decl, Grow, Id, NodeKind, Sense, SizeClass};

use crate::cx::Cx;

/// The visible thumb's length and travel for a viewport and content, GPUI's sizing rule:
/// the thumb is the content's visible fraction, floored to `min`, and it travels the
/// leftover track exactly as the offset travels the content's overflow.
/// thumb 的可见长度与行程，取 GPUI 的定寸规则：thumb 是内容可见比例，下限 `min`，
/// 它在剩余轨道上的行程恰与偏移在内容溢出量上的行程成正比。
pub fn thumb_geometry(viewport: f32, extent: f32, offset: f32, min: f32) -> (f32, f32) {
    let overflow = (extent - viewport).max(0.0);
    if overflow <= 0.0 {
        // Nothing to scroll: a full-length, pinned thumb would be a lie.
        // 无滚动余地：全长、钉死的 thumb 是在撒谎。
        return (0.0, 0.0);
    }
    let size = (viewport * viewport / extent).max(min);
    let travel = (viewport - size).max(0.0);
    let start = (offset / overflow) * travel;
    (size, start)
}

/// When the scrollbar is drawn.
/// 滚动条何时绘制。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ScrollbarVisibility {
    /// Show while the pointer is over the container or a wheel moved it recently, fade out
    /// after the activity stops. The default, matching GPUI's `Auto`.
    /// 指针悬停于容器或滚轮最近移动过它时显示，活动停止后淡出。默认值，对齐 GPUI 的 `Auto`。
    Auto,
    /// Always drawn, even when the content fits.
    /// 始终绘制，即使内容没有溢出。
    Always,
    /// Never drawn; scrolling stays a wheel-only interaction.
    /// 从不绘制；滚动保持纯滚轮交互。
    Never,
}

/// The scrollbar's visual treatment.
/// 滚动条的视觉样式。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ScrollbarStyle {
    /// A slim floating thumb over the content. The default, matching GPUI's `Thin`.
    /// 悬浮在内容之上的细长 thumb。默认值，对齐 GPUI 的 `Thin`。
    Thin,
    /// A sturdier thumb that reserves its own track.
    /// 更粗壮的 thumb，占用自己的轨道。
    Solid,
}

/// Scrollbar appearance and behaviour; the geometry is computed fresh each frame from the
/// engine's scroll state, never stored.
/// 滚动条的外观与行为；几何每帧从引擎滚动状态现算，从不存储。
#[derive(Clone, Copy, Debug)]
pub struct ScrollbarConf {
    pub visibility: ScrollbarVisibility,
    pub style: ScrollbarStyle,
    /// The shortest a thumb may be, so a huge content does not shrink it to nothing.
    /// thumb 的最小长度，使海量内容不至于把它缩成一点。
    pub thumb_min: f32,
    /// The thumb and track colours when the pack does not provide roles for them.
    /// 包未提供相应角色时 thumb 与轨道的默认颜色。
    pub thumb: Color,
    pub track: Color,
}

impl Default for ScrollbarConf {
    fn default() -> Self {
        Self {
            visibility: ScrollbarVisibility::Auto,
            style: ScrollbarStyle::Thin,
            thumb_min: 25.0,
            thumb: Color::from_rgba8(0, 0, 0, 64),
            track: Color::TRANSPARENT,
        }
    }
}

impl ScrollbarConf {
    /// A thin floating scrollbar that fades in on interaction (the default).
    /// 悬停/滚动时淡入的细悬浮滚动条（默认）。
    pub fn auto() -> Self {
        Self::default()
    }

    /// A scrollbar that is always visible, no matter the scroll state.
    /// 无论滚动状态如何都始终可见的滚动条。
    pub fn always() -> Self {
        Self {
            visibility: ScrollbarVisibility::Always,
            ..Self::default()
        }
    }

    /// No scrollbar: wheel-only scrolling.
    /// 无滚动条：纯滚轮滚动。
    pub fn never() -> Self {
        Self {
            visibility: ScrollbarVisibility::Never,
            ..Self::default()
        }
    }

    /// Raise the minimum thumb length; long content otherwise shrinks it to a dot.
    /// 提高 thumb 的最小长度；否则海量内容会把它缩成一点。
    pub fn thumb_min(mut self, min: f32) -> Self {
        self.thumb_min = min;
        self
    }
}

/// A scroll container. The engine owns the offset: a wheel routes here, the engine
/// accumulates and clamps it, and the app never sees a `Value` change for it.
/// 一个滚动容器。偏移由引擎管理：滚轮送到这里，引擎累计并钳位，
/// 应用不会收到与之相关的 `Value` 变化。
#[derive(Clone)]
pub struct Scroll {
    id: Id,
    size: SizeClass,
    /// Scroll axes enabled; `[x, y]`. Default `[false, true]`.
    /// 启用的滚动轴；`[x, y]`。默认 `[false, true]`。
    axis: [bool; 2],
    children: Vec<Rc<Decl>>,
    scrollbar: ScrollbarConf,
    /// A fill behind the content, so a list need not wrap the container to paint one.
    /// 内容之后的填充，列表因此不必为了上色再包一层容器。
    background: Option<(Color, Corners)>,
}

impl Scroll {
    /// A vertical scroll container sized by its content height up to `max_height`.
    /// 一个纵向滚动容器，高度适应内容、上限 `max_height`。
    pub fn vertical(id: Id, max_height: f32) -> Self {
        Self {
            id,
            size: SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::hug(0.0, max_height),
                grow_x: Grow::No,
                grow_y: Grow::No,
            },
            axis: [false, true],
            children: Vec::new(),
            scrollbar: ScrollbarConf::default(),
            background: None,
        }
    }

    /// Both axes scrollable, filling the parent on both axes.
    /// 双轴可滚，两轴都填满父容器。
    pub fn both(id: Id) -> Self {
        Self {
            id,
            size: SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fill(0.0, 0.0),
                grow_x: Grow::No,
                grow_y: Grow::No,
            },
            axis: [true, true],
            children: Vec::new(),
            scrollbar: ScrollbarConf::default(),
            background: None,
        }
    }

    /// A fixed-size scroll container (Qt's `widgetResizable=false`: content is its own size,
    /// the viewport clips it).
    /// 固定尺寸的滚动容器（Qt 的 `widgetResizable=false`：内容固有尺寸，视口裁剪）。
    pub fn fixed(id: Id, width: f32, height: f32) -> Self {
        Self {
            id,
            size: SizeClass::fixed(width, height),
            axis: [false, true],
            children: Vec::new(),
            scrollbar: ScrollbarConf::default(),
            background: None,
        }
    }

    /// Add a child; call repeatedly for several.
    /// 添加一个子节点；可连续调用多次。
    pub fn child(mut self, child: Decl) -> Self {
        self.children.push(Rc::new(child));
        self
    }

    /// Configure the scrollbar; defaults to an auto-fading thin one.
    /// 配置滚动条；默认为自动淡出的细滚动条。
    pub fn with_scrollbar(mut self, conf: ScrollbarConf) -> Self {
        self.scrollbar = conf;
        self
    }

    /// Hide the scrollbar entirely.
    /// 完全隐藏滚动条。
    pub fn no_scrollbar(mut self) -> Self {
        self.scrollbar = ScrollbarConf::never();
        self
    }

    /// Paint a fill behind the content, with the container's own corners.
    /// 在内容之后画一层填充，使用容器自身的圆角。
    pub fn background(mut self, fill: Color, corners: Corners) -> Self {
        self.background = Some((fill, corners));
        self
    }

    /// Resolve to this frame's declaration. The node takes the wheel itself. No scrollbar
    /// is drawn: without a context there is no geometry to compute one from.
    /// 解析为本帧的声明。节点自己接收滚轮。不绘制滚动条：
    /// 没有上下文就没有可据以现算的几何。
    pub fn resolve(&self) -> Decl {
        self.base()
    }

    /// Resolve against this frame's context, so a scrollbar can read the engine's scroll
    /// geometry and draw itself. Prefer this in a build.
    /// 结合本帧上下文解析，使滚动条能读取引擎滚动几何并绘制。构建中优先用这个。
    pub fn resolve_in(&self, cx: &Cx<'_, '_>) -> Decl {
        let decl = self.base();
        self.decorate(decl, cx)
    }

    /// The container as an element, so a live control can sit inside it. A `Decl` has
    /// nowhere to carry `change()`, so content built as declarations is paint-only.
    /// 把容器作为元素产出，其中的实时控件因此得以存在。`Decl` 无处承载 `change()`，
    /// 以声明构建的内容因此只画不上报。
    pub fn element_in(&self, cx: &Cx<'_, '_>) -> crate::Container {
        crate::Container::from_decl(self.decorate(self.frame(), cx))
    }

    /// The container declaration without any scrollbar decoration.
    /// 不带滚动条装饰的容器声明。
    fn base(&self) -> Decl {
        let mut decl = self.frame();
        for child in &self.children {
            decl = decl.child(child.clone());
        }
        decl
    }

    /// The container's own declaration, childless: the one definition of what a scroller is.
    /// 容器自身的声明，不含子节点：滚动容器是什么，只在这里定义一次。
    fn frame(&self) -> Decl {
        let mut clip = ui_core::layout::Clip {
            x: ui_core::layout::Overflow::Hidden,
            y: ui_core::layout::Overflow::Hidden,
        };
        if self.axis[0] {
            clip.x = ui_core::layout::Overflow::Scroll;
        }
        if self.axis[1] {
            clip.y = ui_core::layout::Overflow::Scroll;
        }
        let mut decl = Decl::container(self.id, NodeKind::Column)
            .size(self.size)
            // `HOVER` puts the container on the hover path so the auto scrollbar can
            // answer `hovered_within`; it does not change how the wheel routes.
            // `HOVER` 让容器进入悬停路径，自动滚动条才能回答 `hovered_within`；
            // 它不改变滚轮的走向。
            .sense(Sense::HOVER | Sense::SCROLL_OWNED)
            .clip(clip);
        if let Some((fill, corners)) = self.background {
            decl = decl.background(fill, corners);
        }
        decl
    }

    /// Lay the scrollbar over the container as drawn shapes, in the container's own space.
    /// 以绘制形状的方式把滚动条叠加在容器上，使用容器自身坐标系。
    fn decorate(&self, decl: Decl, cx: &Cx<'_, '_>) -> Decl {
        if self.scrollbar.visibility == ScrollbarVisibility::Never {
            return decl;
        }
        // The axis that scrolls gets the thumb; with both, only the vertical one for now.
        // 可滚的那根轴画 thumb；双轴时目前只画纵向。
        if !self.axis[1] {
            return decl;
        }
        let Some(geom) = cx.core().scroll_of(self.id) else {
            return decl;
        };
        if geom.extent_h <= geom.viewport_h {
            // Content fits: nothing to scroll, so nothing to show.
            // 内容不溢出：无滚动可言，也就无可显示。
            return decl;
        }
        let visible = match self.scrollbar.visibility {
            ScrollbarVisibility::Never => false,
            ScrollbarVisibility::Always => true,
            ScrollbarVisibility::Auto => cx.core().hovered_within(self.id) || geom.active,
        };
        if !visible {
            return decl;
        }
        // The thumb travels the track as the offset travels its range, GPUI's rule; its
        // length is the visible fraction of the content, floored to a minimum. The geometry
        // is the previous frame's (see `set_scrolls`), which is the right anchor for the
        // shapes: they land in the container's own space, and the layout shift of scrolled
        // children never touches them.
        // thumb 在轨道上的行程与偏移在值域上的行程成正比，GPUI 的规则；它的长度是
        // 内容的可见比例，下限钳位。几何取自上一帧（见 `set_scrolls`），这对形状是
        // 正确的锚：它们落在容器自身坐标系，滚动子内容的布局平移碰不到它们。
        let (viewport_w, viewport_h) = (geom.viewport_w, geom.viewport_h);
        let (thumb_size, thumb_start) =
            thumb_geometry(viewport_h, geom.extent_h, geom.offset_y, self.scrollbar.thumb_min);
        let thin = self.scrollbar.style == ScrollbarStyle::Thin;
        let track_w = if thin { 4.0 } else { 8.0 };
        let x = (viewport_w - track_w).max(0.0);
        let mut shapes = Vec::new();
        if self.scrollbar.track.a != 0.0 {
            shapes.push(Shape::Rect {
                rect: Rect::new(x, 0.0, track_w, viewport_h),
                corners: Corners::all(track_w * 0.5),
                fill: self.scrollbar.track,
                gradient: None,
                border: None,
            });
        }
        shapes.push(Shape::Rect {
            rect: Rect::new(x, thumb_start, track_w, thumb_size),
            corners: Corners::all(track_w * 0.5),
            fill: self.scrollbar.thumb,
            gradient: None,
            border: None,
        });
        let mut decl = decl.shapes(shapes);
        // The painted bar is also the hit area: a press there drags the thumb instead of
        // reaching the content underneath.
        // 画出的条同时也是命中区：那里的按下拖拽 thumb，而不会落到下面的内容上。
        if let Some(params) = decl.data.params_mut() {
            params.scrollbar = Some(ui_core::ScrollbarHit {
                thumb: Rect::new(x, thumb_start, track_w, thumb_size),
                track: Rect::new(x, 0.0, track_w, viewport_h),
            });
        }
        decl
    }
}

/// A scroll container is a widget too: `cx.at_scope(..).element(Box::new(scroll))` turns it
/// into an element, and the scrollbar then reads this frame's context when built.
/// 滚动容器同样是一种控件：`cx.at_scope(..).element(Box::new(scroll))` 把它变成元素，
/// 滚动条在构建时就能读取本帧的上下文。
impl crate::widget::Widget for Scroll {
    fn decl(&self, cx: &Cx<'_, '_>) -> Decl {
        self.resolve_in(cx)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_vertical_scroll_is_engine_owned_and_clips_y() {
        let scroll = Scroll::vertical(Id::str("s"), 200.0);
        let decl = scroll.resolve();
        assert!(
            decl.sense.contains(Sense::SCROLL_OWNED),
            "the engine must own this container's offset"
        );
        let params = decl.data.params();
        assert!(
            params.map(|p| p.clip.scrolls()).unwrap_or(false),
            "a scroll container must declare a scrolling clip"
        );
    }

    #[test]
    fn children_keep_their_own_ids() {
        let scroll = Scroll::vertical(Id::str("s"), 200.0)
            .child(Decl::container(Id::str("a"), NodeKind::Box))
            .child(Decl::container(Id::str("b"), NodeKind::Box));
        let ids: Vec<Id> = scroll.children.iter().map(|c| c.id).collect();
        assert_ne!(ids[0], ids[1]);
    }

    #[test]
    fn a_thumb_tracks_the_offset_over_the_overflow_and_shrinks_with_visible_fraction() {
        // GPUI's rule: the thumb is the content's visible fraction of the viewport, floored
        // to a minimum, and it travels the leftover track exactly as the offset travels the
        // overflow. At the top it sits at 0; at the bottom it reaches `viewport - size`.
        // GPUI 的规则：thumb 是内容可见比例对应的视口长度，下限钳位，它在剩余轨道上
        // 的行程恰与偏移在溢出量上的行程成正比。顶部时停在 0，底部时到达
        // `viewport - size`。
        let (size, start) = thumb_geometry(100.0, 300.0, 0.0, 25.0);
        assert!((size - 33.333).abs() < 0.01, "visible fraction of the viewport, got {size}");
        assert!(start == 0.0, "top offset pins the thumb at the top");
        // Half the overflow, half the travel.
        // 溢出过半，行程过半。
        let (_, mid) = thumb_geometry(100.0, 300.0, 100.0, 25.0);
        let travel = 100.0 - size;
        assert!((mid - travel * 0.5).abs() < 0.01, "half overflow, half travel, got {mid}");
        // At the bottom, the thumb's tail touches the track's end.
        // 到底部时，thumb 的尾端顶到轨道末端。
        let (_, bottom) = thumb_geometry(100.0, 300.0, 200.0, 25.0);
        assert!((bottom + size - 100.0).abs() < 0.01, "bottom offset bottoms the thumb");
    }

    #[test]
    fn a_minimum_thumb_survives_a_huge_content() {
        // A 5000-tall content in a 100-tall viewport would shrink the thumb to a dot; the
        // minimum floors it.
        // 5000 高的内容放进 100 高的视口会把 thumb 缩成一点；下限把它钳住。
        let (size, _) = thumb_geometry(100.0, 5000.0, 0.0, 25.0);
        assert_eq!(size, 25.0, "the minimum thumb length must hold");
    }

    #[test]
    fn no_overflow_means_no_thumb() {
        // A scrollbar on a container whose content fits would claim scrollable space that
        // does not exist; the geometry says "draw nothing".
        // 内容放得下的容器上画滚动条，等于宣称不存在的可滚空间；几何应说「什么都不画」。
        let (size, start) = thumb_geometry(100.0, 80.0, 0.0, 25.0);
        assert_eq!((size, start), (0.0, 0.0));
    }

    #[test]
    fn a_never_scrollbar_adds_no_shapes_even_when_content_overflows() {
        // `Never` is a promise: no geometry lookup, no shapes, in any scroll state.
        // `Never` 是一种承诺：任何滚动状态下都不查几何、不画形状。
        let scroll = Scroll::vertical(Id::str("s"), 200.0)
            .child(Decl::container(Id::str("c"), NodeKind::Box))
            .no_scrollbar();
        let decl = scroll.resolve();
        assert_eq!(decl.shapes.len(), 0, "no scrollbar, no shapes");
    }

    #[test]
    fn an_active_scroller_draws_its_thumb_in_the_containers_space() {
        // The engine fed geometry for the scroller (content 300 in a 100 viewport) and a
        // wheel marked it active: the auto scrollbar must draw one thumb shape, anchored to
        // the viewport's right edge, not to the scrolled content.
        // 引擎为滚动容器提供了几何（100 视口装 300 内容）且滚轮把它标为活动：
        // 自动滚动条必须画出一条 thumb 形状，锚在视口右缘，而非滚动的内容上。
        let mut store = ui_core::AnimStore::new();
        let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 200, 0.0, 0.0, 1.0, None);
        core.route(ui_core::cx::Routing::default());
        core.set_scrolls(vec![ui_core::cx::ScrollGeom {
            id: Id::str("s"),
            extent_w: 200.0,
            extent_h: 300.0,
            viewport_w: 200.0,
            viewport_h: 100.0,
            offset_x: 0.0,
            offset_y: 40.0,
            active: true,
        }]);
        let cx = Cx::new(&mut core, ui_style::Env::root());
        let scroll = Scroll::fixed(Id::str("s"), 200.0, 100.0)
            .child(Decl::container(Id::str("c"), NodeKind::Box));
        let decl = scroll.resolve_in(&cx);
        assert_eq!(
            decl.shapes.len(),
            1,
            "one thumb, one shape; the track is transparent by default"
        );
        // The thumb is a capsule hugging the right edge, sized and placed by the geometry.
        // thumb 是贴在右缘的胶囊，尺寸与位置由几何决定。
        let Shape::Rect { rect, fill, .. } = decl.shapes[0] else {
            panic!("the thumb must be an explicit rect");
        };
        assert_eq!(rect.size.w, 4.0, "thin thumb");
        assert!(
            (rect.origin.x - 196.0).abs() < 0.01,
            "hugging the right edge, got {}",
            rect.origin.x
        );
        assert_eq!(fill, ScrollbarConf::default().thumb);
        let (want_size, want_start) = thumb_geometry(100.0, 300.0, 40.0, 25.0);
        assert!((rect.size.h - want_size).abs() < 0.01, "thumb size from the geometry");
        assert!((rect.origin.y - want_start).abs() < 0.01, "thumb start from the geometry");
        // The painted bar is also the hit area the engine drags; without it the thumb is
        // decoration the pointer falls straight through.
        // 画出的条同时也是引擎拖拽的命中区；没有它，thumb 只是指针能穿过的装饰。
        let bar = decl
            .data
            .params()
            .and_then(|p| p.scrollbar)
            .expect("the visible bar declares its hit geometry");
        assert_eq!(bar.thumb, rect, "the hit thumb is the painted thumb");
        assert_eq!(bar.track.size.h, 100.0, "the track spans the viewport");
    }

    #[test]
    fn an_idle_scroller_draws_no_thumb_even_when_hover_is_unavailable() {
        // Auto without activity and without hover draws nothing: the scrollbar only exists
        // while the user is touching the scroll in some way.
        // 无活动且无悬停的 Auto 什么都不画：滚动条只在用户以某种方式接触滚动时存在。
        let mut store = ui_core::AnimStore::new();
        let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 200, 0.0, 0.0, 1.0, None);
        core.route(ui_core::cx::Routing::default());
        core.set_scrolls(vec![ui_core::cx::ScrollGeom {
            id: Id::str("s"),
            extent_w: 200.0,
            extent_h: 300.0,
            viewport_w: 200.0,
            viewport_h: 100.0,
            offset_x: 0.0,
            offset_y: 40.0,
            active: false,
        }]);
        let cx = Cx::new(&mut core, ui_style::Env::root());
        let scroll = Scroll::fixed(Id::str("s"), 200.0, 100.0)
            .child(Decl::container(Id::str("c"), NodeKind::Box));
        let decl = scroll.resolve_in(&cx);
        assert_eq!(decl.shapes.len(), 0, "no activity, no hover, no thumb");
    }
}
