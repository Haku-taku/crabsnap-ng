//! The pressed/hovered/focused control. Its look comes entirely from the pack.
//! 会响应按下/悬停/焦点的控件。外观完全来自风格包。

use ui_core::geom::Corners;

use ui_core::{Decl, Id, NodeKind};
use ui_style::{RoleDict, RoleName, Style};

use crate::state::WidgetState;

/// The roles a button reads from its pack. A pack that lacks one draws transparent,
/// which is how a custom pack opts out of a part instead of crashing.
/// 按钮从包读取的角色。缺某个角色就画成透明，自定义包据此跳过某部分而非崩。
pub mod roles {
    pub const FILL: &str = "buttonFill";
    pub const FILL_HOVER: &str = "buttonFillHover";
    pub const FILL_PRESSED: &str = "buttonFillPressed";
    pub const FOREGROUND: &str = "buttonText";
    pub const BORDER: &str = "buttonBorder";
    pub const FOCUS: &str = "focusStroke";
    pub const FILL_DISABLED: &str = "buttonFillDisabled";
    pub const FOREGROUND_DISABLED: &str = "buttonTextDisabled";
    pub const BORDER_DISABLED: &str = "buttonBorderDisabled";
}

/// A push button: semantics in, `Decl` out, no style of its own.
/// 按钮：输入语义，输出 `Decl`，自己不带任何外观。
pub struct Button {
    pub id: Id,
    pub label: String,
}

impl Button {
    pub fn new(id: Id, label: impl Into<String>) -> Self {
        Self {
            id,
            label: label.into(),
        }
    }

    /// Resolve this frame's look from the routed state plus the fade the app advanced.
    /// 从路由好的状态加上 app 推进的淡入值解析本帧外观。
    pub fn resolve(&self, state: WidgetState, pack: &Style, hover: f32) -> Decl {
        let metrics = &pack.metrics;
        // A pack that names a design system answers these in the common vocabulary; a
        // hand-written one only has its own roles, so the legacy names stay the fallback.
        // 指名了设计体系的包用公共词汇作答；手写包只有自己的角色，故旧名字仍是回落。
        let mut fill = pick_fill(&pack.roles, state, hover)
            .unwrap_or_else(|| pack.colour_or(ui_design::CommonColor::Accent, ui_core::geom::Color::TRANSPARENT));
        let mut foreground = pack
            .roles
            .get(RoleName(roles::FOREGROUND))
            .unwrap_or_else(|| pack.colour_or(ui_design::CommonColor::OnAccent, ui_core::geom::Color::TRANSPARENT));
        let mut border = if state.focus_visible {
            pack.roles
                .get(RoleName(roles::FOCUS))
                .unwrap_or(ui_core::geom::Color::TRANSPARENT)
        } else {
            pack.roles
                .get(RoleName(roles::BORDER))
                .unwrap_or(ui_core::geom::Color::TRANSPARENT)
        };
        // Disabled: prefer the pack's disabled roles; otherwise dim the live colours.
        // 禁用：优先用包的禁用角色；否则把当前色淡化。
        if state.disabled {
            fill = disabled_role(pack, roles::FILL_DISABLED, fill);
            foreground = disabled_role(pack, roles::FOREGROUND_DISABLED, foreground);
            border = disabled_role(pack, roles::BORDER_DISABLED, border);
        }
        let token = &pack.type_table;
        let caption = token.get(ui_style::TextRole::Caption);

        Decl::container(self.id, NodeKind::Column)
            // A button is a keyboard stop that takes clicks and shows hover.
            // 按钮是可聚焦的键盘停靠点，接受点击并显示悬停。
            .sense(
                ui_core::Sense::HOVER | ui_core::Sense::CLICK | ui_core::Sense::FOCUSABLE,
            )
            .background(fill, corners(pack, state))
            .border(border, metrics.control.border)
            .padding(metrics.control.padding)
            .cursor(ui_core::CursorShape::PointingHand)
            .child(crate::text::leaf(
                self.id.with("label"),
                self.label.clone(),
                caption.size,
                foreground,
                caption.weight,
                f32::INFINITY,
                caption.line_gap,
                caption.indent,
            ))
    }
}

/// Press wins outright; hover blends the base toward the hover role by `hover`.
/// `None` when the pack names no fill at all, so the caller can ask the common plane.
/// 按下直接胜出；悬停把底色按 `hover` 向悬停角色混合。包根本没给填充时为 `None`，
/// 好让调用方去问公共平面。
fn pick_fill(dict: &RoleDict, state: WidgetState, hover: f32) -> Option<ui_core::geom::Color> {
    let base = dict.get(RoleName(roles::FILL))?;
    if state.pressed {
        return Some(dict.get(RoleName(roles::FILL_PRESSED)).unwrap_or(base));
    }
    let lifted = dict.get(RoleName(roles::FILL_HOVER)).unwrap_or(base);
    Some(base.lerp(lifted, hover))
}

/// A disabled role from the pack, or `fallback` dimmed to 38% when the pack has none.
/// 取包的禁用角色；包未提供时把 `fallback` 淡到 38%。
fn disabled_role(pack: &Style, id: &'static str, fallback: ui_core::geom::Color) -> ui_core::geom::Color {
    match pack.roles.get(RoleName(id)) {
        Some(c) => c,
        None => ui_core::geom::Color { a: fallback.a * 0.38, ..fallback },
    }
}

fn corners(pack: &Style, state: WidgetState) -> Corners {
    let metrics = &pack.metrics;
    let radius = pack.metric_or(ui_design::CommonMetric::Radius, metrics.control.radius);
    if state.pressed {
        // Pressed flattens in Fluent and MD3 alike; the pack's own radius still rules.
        // 按下时 Fluent 与 MD3 都会压平，但半径仍由包决定。
        Corners::all(radius).with_shape(ui_core::geom::CornerShape::ROUND)
    } else {
        Corners::all(radius).with_shape(metrics.control.corner)
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use ui_style::MotionName;
    use ui_core::geom::Color;
    use ui_core::{AnimStore, Id};
    use ui_style::{MetricsSet, MotionTable, RoleDict};

    fn pack() -> Style {
        let mut roles = RoleDict::new();
        roles.set(RoleName(roles::FILL), Color::from_rgba8(60, 130, 220, 255));
        roles.set(RoleName(roles::FILL_HOVER), Color::from_rgba8(110, 175, 245, 255));
        roles.set(RoleName(roles::FILL_PRESSED), Color::from_rgba8(30, 70, 140, 255));
        roles.set(RoleName(roles::FOREGROUND), Color::WHITE);
        Style {
            common: None,
            roles,
            motion: MotionTable::fluent(),
            metrics: MetricsSet::NONE,
            controls: ui_style::ControlMetricsTable::EMPTY,
            type_table: ui_style::stub_type_table(),
            material: None,
            device: ui_style::Capability::GPU_BASELINE,
            palette: None,
            selection: None,
        }
    }

    fn pressed_state() -> WidgetState {
        WidgetState { pressed: true, hovered: true, ..Default::default() }
    }

    fn idle_state() -> WidgetState {
        WidgetState::default()
    }

    fn fill_of(decl: &Decl) -> Color {
        decl.fill().expect("a background")
    }

    #[test]
    fn pressing_beats_a_full_hover() {
        let p = pack();
        let b = Button::new(Id::str("pill"), "go");
        let decl = b.resolve(pressed_state(), &p, 1.0);
        assert_eq!(fill_of(&decl), Color::from_rgba8(30, 70, 140, 255));
    }

    #[test]
    fn the_hover_value_blends_instead_of_switching() {
        // A hard switch reads as a different widget; the fade must be continuous.
        // 硬切换像是换了控件；淡入必须连续。
        let p = pack();
        let b = Button::new(Id::str("pill"), "go");
        let half = fill_of(&b.resolve(idle_state(), &p, 0.5));
        // Midpoint of the two roles' channels, in 8-bit terms: 85, 152.5, 232.5 — the
        // lerp keeps the halves, so the expectation must too.
        // 两角色通道的中点：85、152.5、232.5 —— lerp 保留小数，期望值也必须保留。
        let want = Color::rgb(85.0 / 255.0, 152.5 / 255.0, 232.5 / 255.0);
        for (v, w) in [(half.r, want.r), (half.g, want.g), (half.b, want.b), (half.a, want.a)] {
            assert!((v - w).abs() < 1e-5, "{half:?} vs {want:?}");
        }
    }

    #[test]
    fn the_fade_lengthens_or_shortens_with_the_pack_not_a_literal() {
        // The token drives the store: fluent's 83 ms state change, not the widget's own.
        // 令牌驱动存储：Fluent 的 83 毫秒状态档，而不是控件自带的数。
        let p = pack();
        let spec = p.motion.get(MotionName::StateChange).spec;
        let id = Id::str("pill");
        let mut anim = AnimStore::new();
        let mut now = 0.0_f64;
        {
            let mut node = crate::cx::NodeCx::new(
                id,
                WidgetState::default(),
                1.0,
                now,
                &mut anim,
            );
            node.animate(id.with("hover"), 0.0, ui_core::AnimSpec::new(0.0, ui_core::Easing::Linear));
        }
        // The fade starts at t=0 and, one token duration later, must have landed on 1.0.
        // 淡入从 t=0 开始，过一个令牌时长后必须恰好落在 1.0。
        {
            let mut node = crate::cx::NodeCx::new(id, WidgetState::default(), 1.0, now, &mut anim);
            node.animate(id.with("hover"), 1.0, spec);
        }
        now += 0.083;
        let v = anim.value(id.with("hover"), now).unwrap();
        assert!((v - 1.0).abs() < 1e-3, "expected settle at 83 ms, got {v}");
    }

    #[test]
    fn a_disabled_button_prefers_pack_disabled_roles_else_dims() {
        // No disabled role: dim the live fill to 38%.
        // 无禁用角色：把当前填充淡到 38%。
        let p = pack();
        let base = p.roles.get(RoleName(roles::FILL)).unwrap();
        let dimmed = Button::new(Id::str("b"), "go").resolve(
            WidgetState { disabled: true, ..Default::default() },
            &p,
            0.0,
        );
        assert!((fill_of(&dimmed).a - base.a * 0.38).abs() < 1e-6, "fallback dims to 38%");

        // A pack that defines the disabled role wins outright.
        // 定义了禁用角色的包直接生效。
        let mut p2 = pack();
        p2.roles.set(RoleName(roles::FILL_DISABLED), Color::from_rgba8(200, 10, 10, 255));
        let d2 = Button::new(Id::str("b"), "go").resolve(
            WidgetState { disabled: true, ..Default::default() },
            &p2,
            0.0,
        );
        assert_eq!(fill_of(&d2), Color::from_rgba8(200, 10, 10, 255));
    }
}


