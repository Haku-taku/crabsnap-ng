//! Where a control sits inside a group its parent built.
//! 控件在父容器所建分组中的位置。
//!
//! The parent pushes this down, the child decides what it means: the same model Flutter and
//! GPUI use, and the reason the engine needs no "sibling style" machinery.
//! 父容器把它推下来，由子控件决定其含义：与 Flutter、GPUI 同一模型，
//! 也正是引擎不需要「兄弟样式」机制的原因。

use ui_core::geom::Corners;

/// A control's slot in a connected group.
/// 控件在连通分组中的位置。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct GroupPosition {
    pub index: usize,
    pub len: usize,
}

impl GroupPosition {
    pub fn new(index: usize, len: usize) -> Self {
        Self { index, len }
    }

    pub fn is_first(&self) -> bool {
        self.index == 0
    }

    pub fn is_last(&self) -> bool {
        self.index + 1 == self.len
    }

    /// The only member: both ends are outer.
    /// 唯一成员：两端都是外侧。
    pub fn is_only(&self) -> bool {
        self.len <= 1
    }

    /// Corners for a pill: `outer` where the group ends, `inner` where it meets a neighbour.
    /// 胶囊的圆角：分组两端用 `outer`，与邻居相接处用 `inner`。
    pub fn corners(&self, outer: f32, inner: f32) -> Corners {
        Corners {
            tl: if self.is_first() { outer } else { inner },
            bl: if self.is_first() { outer } else { inner },
            tr: if self.is_last() { outer } else { inner },
            br: if self.is_last() { outer } else { inner },
            ..Corners::ZERO
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_middle_of_a_group_has_two_inner_corners_and_the_ends_two_outer_ones() {
        let middle = GroupPosition::new(1, 3).corners(20.0, 8.0);
        assert_eq!((middle.tl, middle.bl, middle.tr, middle.br), (8.0, 8.0, 8.0, 8.0));
        let first = GroupPosition::new(0, 3).corners(20.0, 8.0);
        assert_eq!((first.tl, first.bl, first.tr, first.br), (20.0, 20.0, 8.0, 8.0));
        let last = GroupPosition::new(2, 3).corners(20.0, 8.0);
        assert_eq!((last.tl, last.bl, last.tr, last.br), (8.0, 8.0, 20.0, 20.0));
        // A lone member is a plain pill, not a group with one inner side.
        // 唯一成员是一颗普通胶囊，而不是有一侧内圆角的分组。
        let only = GroupPosition::new(0, 1).corners(20.0, 8.0);
        assert_eq!((only.tl, only.tr), (20.0, 20.0));
    }
}
