//! Built-in widgets: state machines and semantics, resolved into `Decl` through a
//! style pack. No colour, duration or radius literal may appear in this crate.
//! 内置控件：状态机与语义，经风格包解析成 `Decl`。本 crate 不得出现颜色、时长或半径的字面量。

pub mod build;
pub mod cx;
pub mod fingerprint;
pub mod group;
pub mod button;
pub mod icon;
mod icon_codepoints;
mod sf_symbol_codepoints;
pub mod list;
pub mod scaffold;
pub mod scroll;
pub mod shortcut;
pub mod state;
pub mod styled;
pub mod tween;
pub mod surface;
pub mod style;
pub mod text;
pub mod widget;

pub use button::Button;
pub use cx::{Cx, NodeCx};
pub use group::GroupPosition;
pub use icon::{Icon, IconSet, IconSource, SF_SYMBOLS_FAMILY};
pub use scroll::Scroll;
pub use ui_core::change::Change;
pub use ui_platform::{from_decl, Container, Element};
pub use ui_platform::menu::{MenuRowText, MenuStyle, TextMenuLabels};
pub use list::List;
pub use scaffold::ScaffoldSpec;
pub use shortcut::{modifiers_label, shortcut_label, shortcut_label_in};
pub use state::WidgetState;
pub use surface::{Card, Panel};
pub use text::{icon_extent, leaf, Text, LINE_HINT};
pub use style::StyleKit;
pub use widget::{decl_only, Widget};
pub use styled::Styled;
