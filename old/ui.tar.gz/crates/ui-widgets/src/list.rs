//! A fixed-height scroll container of rows; the engine owns the wheel offset.
//! 高度固定、由行组成的滚动容器；滚轮偏移归引擎管理。

use ui_core::geom::Corners;

use ui_core::{Decl, Id, NodeKind};
use ui_style::{RoleName, Style};

use crate::scroll::Scroll;

pub mod roles {
    pub const FILL: &str = "scrollerFill";
    pub const ROW_TEXT: &str = "rowText";
}

/// One scrollable list; the engine owns the offset and the caller owns the rows.
/// 一个可滚动列表；偏移归引擎管理，行内容归调用方。
pub struct List<'a> {
    pub id: Id,
    pub width: f32,
    pub height: f32,
    pub row_height: f32,
    /// Rows by index; the caller owns their content.
    /// 按序号的行；内容由调用方决定。
    pub rows: Vec<String>,
    pub pack: &'a Style,
}

impl<'a> List<'a> {
    pub fn resolve(&self) -> Decl {
        self.build().resolve()
    }

    /// Resolve against the frame's context, so the engine-owned scrollbar draws itself.
    /// 结合本帧上下文解析，使引擎自有的滚动条绘制自身。
    pub fn resolve_in(&self, cx: &crate::cx::Cx<'_, '_>) -> Decl {
        self.build().resolve_in(cx)
    }

    /// The scroll container with this list's rows, before any scrollbar decoration.
    /// 装着本列表各行、尚未加滚动条装饰的滚动容器。
    fn build(&self) -> Scroll {
        // Same rule as `Button`: the pack's own roles first, then the common plane.
        // 与 `Button` 同一规则：先问包自己的角色，再问公共平面。
        let fill = self
            .pack
            .roles
            .get(RoleName(roles::FILL))
            .unwrap_or_else(|| self.pack.colour_or(ui_design::CommonColor::Surface, ui_core::geom::Color::TRANSPARENT));
        let text = self
            .pack
            .roles
            .get(RoleName(roles::ROW_TEXT))
            .unwrap_or_else(|| self.pack.colour_or(ui_design::CommonColor::OnSurface, ui_core::geom::Color::WHITE));
        let size = self.pack.type_table.get(ui_style::TextRole::Caption).size;
        let radius = self.pack.metric_or(ui_design::CommonMetric::Radius, self.pack.metrics.control.radius);

        // The unified scroll container owns the clip, the wheel and the offset; the list
        // only contributes its rows and a background.
        // 统一滚动容器负责裁剪、滚轮与偏移；列表只提供行与背景。
        // The default thumb is translucent black, which vanishes on a dark list; it takes
        // the pack's own ink instead.
        // 默认 thumb 是半透明黑，在深色列表上看不见；改为取包自身的墨色。
        let thumb = ui_core::geom::Color {
            a: 0.4,
            ..self
                .pack
                .colour_or(ui_design::CommonColor::OnSurface, ui_core::geom::Color::WHITE)
        };
        let bar = crate::scroll::ScrollbarConf { thumb, ..crate::scroll::ScrollbarConf::default() };
        let mut list = Scroll::fixed(self.id, self.width, self.height)
            .background(fill, Corners::all(radius))
            .with_scrollbar(bar);
        for (i, body) in self.rows.iter().enumerate() {
            // Each row needs its own id: the tree keys nodes by `Id`, so duplicates
            // silently collapse into one node and only the last text survives.
            // 每行必须有自己的 id：树按 `Id` 索引节点，重复会静默塌成一个，只剩最后写入的文本。
            let row_id = self.id.with(i);
            list = list.child(
                Decl::container(row_id, NodeKind::Column)
                    .size(ui_core::SizeClass::fixed(
                        self.width
                            - self.pack.metrics.control.padding.left
                            - self.pack.metrics.control.padding.right,
                        self.row_height,
                    ))
                    .child(crate::text::leaf(
                        row_id.with("label"),
                        body.clone(),
                        size,
                        text,
                        ui_core::Weight::REGULAR,
                        self.width,
                        0.0,
                        0.0,
                    )),
            );
        }
        list
    }
}


#[cfg(test)]
mod tests {
    use super::*;

    fn pack() -> Style {
        Style {
            common: None,
            roles: ui_style::RoleDict::with_pairs(&[
                (RoleName(roles::FILL), ui_core::geom::Color::from_rgba8(10, 20, 30, 255)),
                (RoleName(roles::ROW_TEXT), ui_core::geom::Color::WHITE),
            ]),
            motion: ui_style::MotionTable::legacy(),
            metrics: ui_style::MetricsSet::NONE,
            controls: ui_style::ControlMetricsTable::EMPTY,
            type_table: ui_style::stub_type_table(),
            material: None,
            device: ui_style::Capability::GPU_BASELINE,
            palette: None,
            selection: None,
        }
    }

    #[test]
    fn every_row_gets_a_distinct_id() {
        let list = List {
            id: Id::str("scroller"),
            width: 200.0,
            height: 60.0,
            row_height: 20.0,
            rows: vec!["a".into(), "b".into(), "c".into()],
            pack: &pack(),
        };
        let decl = list.resolve();
        let ids: Vec<Id> = decl.children.iter().map(|c| c.id).collect();
        let mut unique = ids.clone();
        unique.sort_by_key(|i| i.as_u64());
        unique.dedup();
        assert_eq!(unique.len(), 3, "row ids must not collide: {ids:?}");
        assert_eq!(decl.children.len(), 3);
    }

    #[test]
    fn the_container_clips_its_rows_and_owns_the_offset() {
        // A scroll container without the scroll clip compresses its children to fit, so
        // panning would move a squeezed pile instead of a list; the engine must own the
        // offset, or the app would have to feed it back every frame.
        // 没有滚动裁剪的滚动容器会把子节点压到装得下，平移的就是一坨挤扁的东西；
        // 偏移必须归引擎，否则应用每帧都要把它喂回来。
        let list = List {
            id: Id::str("s"),
            width: 100.0,
            height: 40.0,
            row_height: 20.0,
            rows: vec!["x".into(), "y".into()],
            pack: &pack(),
        };
        let decl = list.resolve();
        let dumped = format!("{:?}", decl.data);
        assert!(
            dumped.contains("clip: Clip { x: Hidden, y: Scroll }"),
            "{dumped}"
        );
        assert!(
            decl.sense.contains(ui_core::Sense::SCROLL_OWNED),
            "the engine must own the list's offset"
        );
    }
}
