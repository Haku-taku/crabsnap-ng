//! Shared tween helpers the style crates build their animation sequences from.
//! 各风格 crate 用来搭建动画序列的共享插值工具。

/// A curve a family may name; mirrors `ui_core::Easing` so tests stay readable.
/// 家族可用的曲线；镜像 `ui_core::Easing`，使测试可读。
pub type Curve = ui_core::Easing;

/// Piecewise interpolation over weighted stops, in order; weights are cumulative ends.
/// 按权重分段的插值，按顺序给出；权重是该段的累计终点。
pub fn weighted<T: Copy>(
    t: f32,
    stops: &[(f32, Curve, T)],
    from: T,
    lerp: impl Fn(T, T, f32) -> T,
) -> T {
    let t = t.clamp(0.0, 1.0);
    let mut prev = 0.0;
    let mut start = from;
    for (end, curve, target) in stops {
        if t <= *end {
            let span = (end - prev).max(1e-6);
            return lerp(start, *target, curve.apply((t - prev) / span));
        }
        prev = *end;
        start = *target;
    }
    start
}

/// 0..1 bump peaking at the middle: the travel bloom several styles share.
/// 中间达到峰值的 0..1 鼓包：多种风格共有的行程膨胀。
pub fn bump(t: f32) -> f32 {
    (t.clamp(0.0, 1.0) * std::f32::consts::PI).sin()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn weighted_hits_every_stop_exactly() {
        let stops = [(0.11, Curve::Linear, 34.0_f32), (0.83, Curve::Linear, 24.0)];
        let lerp = |a: f32, b: f32, t: f32| a + (b - a) * t;
        assert_eq!(weighted(0.0, &stops, 16.0, lerp), 16.0);
        assert!((weighted(0.11, &stops, 16.0, lerp) - 34.0).abs() < 1e-4);
        assert!((weighted(0.83, &stops, 16.0, lerp) - 24.0).abs() < 1e-4);
        assert_eq!(weighted(1.0, &stops, 16.0, lerp), 24.0);
    }

    #[test]
    fn the_bump_is_zero_at_both_ends_and_one_in_the_middle() {
        assert!(bump(0.0).abs() < 1e-6);
        assert!((bump(0.5) - 1.0).abs() < 1e-6);
        assert!(bump(1.0).abs() < 1e-6);
    }
}
