//! What a control gives the engine: this frame's declaration, and any semantic change.
//! 控件交给引擎的东西：本帧的声明，以及本帧的语义变化。
//!
//! A widget is *code*: it holds the facts it was built with and answers two questions —
//! what to draw this frame, and whether the user changed anything. It holds no state and
//! keeps no value between frames; the engine owns all of that.
//! 控件是**代码**：它持有构造时的事实，回答两个问题——本帧画什么，用户是否改变了什么。
//! 它不持有状态，也不跨帧保留值；那些都归引擎所有。
//!
//! Node properties (cursor, `Sense`, offset) travel with the `Decl`, so the engine routes
//! by them and never has to ask a widget that has moved on.
//! 节点属性（光标、`Sense`、偏移）随 `Decl` 流动，引擎据此路由，无需回头问控件。

use ui_core::Decl;

use crate::cx::Cx;

/// A control that can describe itself to the engine.
/// 能向引擎描述自身的控件。
pub trait Widget {
    /// Build this frame's declaration from the engine context.
    /// 由引擎上下文生成这一帧的声明。
    ///
    /// Everything the control may use — scope, interaction state, animations — comes
    /// through `cx`, so the result is a function of `(self, cx)` and stays reentrant.
    /// 控件可用的一切——作用域、交互状态、动画——都经 `cx` 到达，
    /// 因此结果是 `(self, cx)` 的函数，且保持可重入。
    fn decl(&self, cx: &Cx<'_, '_>) -> Decl;

    /// Report a semantic change for this frame, or `None` when nothing happened.
    /// 上报本帧的语义变化；没有变化时返回 `None`。
    ///
    /// Called once after layout, so `bounds` is this frame's final geometry and `state`
    /// carries the press point in this control's own space. A widget that only draws
    /// leaves this default in place.
    /// 在布局之后调用一次，因此 `bounds` 是本帧最终几何，`state` 带着按下点在本控件
    /// 自身空间中的位置。只负责绘制的控件保留此默认实现。
    fn change(
        &self,
        _state: &crate::state::WidgetState,
        _bounds: ui_core::geom::Rect,
    ) -> Option<ui_core::Change> {
        None
    }

    /// Whether this control already paints its own disabled appearance. When true the adapter
    /// must not fade the whole subtree again, or the control is dimmed twice.
    /// 本控件是否已自行绘制禁用外观。为真时，适配器不得再对整棵子树淡化一次，否则会被双重压暗。
    fn handles_disabled(&self) -> bool {
        false
    }

    /// Identity and a fingerprint of everything this control was built with, when `decl`
    /// reads nothing beyond `cx` and `self`. Anything left out of the fingerprint is a
    /// change the engine will never see.
    /// 不构建即可给出的身份与自身输入指纹；前提是 `decl` 除 `cx` 与 `self` 之外什么都不读。
    /// 指纹漏掉的字段，就是引擎永远看不见的变化。
    fn cache_key(&self) -> Option<ui_core::CachedKey> {
        None
    }
}

/// Resolve a control into this frame's declaration without placing it as an element.
/// 在不把控件作为元素摆放的前提下，产出它本帧的声明。
///
/// For tests that inspect a declaration. A placed control must go through
/// `Cx::element`, the only route that carries `change()` to the engine — a `Decl` has
/// nowhere to put it, so a control placed as a bare declaration silently stops reporting.
/// 供检查声明的测试使用。真正摆放控件必须走 `Cx::element`：只有那条路把 `change()`
/// 带到引擎——`Decl` 无处安放它，以裸声明摆放的控件会静默停止上报。
pub fn decl_only(control: &dyn Widget, cx: &mut crate::cx::Cx<'_, '_>) -> Decl {
    cx.with_cx(|inner| control.decl(inner))
}

/// Blanket forwarding, so `Box<dyn Widget>` and `&dyn Widget` compose without ceremony.
/// 泛型转发，使 `Box<dyn Widget>` 与 `&dyn Widget` 无需额外包装即可组合。
impl<T: Widget + ?Sized> Widget for Box<T> {
    fn decl(&self, cx: &Cx<'_, '_>) -> Decl {
        (**self).decl(cx)
    }

    fn change(
        &self,
        state: &crate::state::WidgetState,
        bounds: ui_core::geom::Rect,
    ) -> Option<ui_core::Change> {
        (**self).change(state, bounds)
    }

    fn handles_disabled(&self) -> bool {
        (**self).handles_disabled()
    }

    fn cache_key(&self) -> Option<ui_core::CachedKey> {
        (**self).cache_key()
    }
}

impl<T: Widget + ?Sized> Widget for &T {
    fn decl(&self, cx: &Cx<'_, '_>) -> Decl {
        (**self).decl(cx)
    }

    fn change(
        &self,
        state: &crate::state::WidgetState,
        bounds: ui_core::geom::Rect,
    ) -> Option<ui_core::Change> {
        (**self).change(state, bounds)
    }

    fn handles_disabled(&self) -> bool {
        (**self).handles_disabled()
    }

    fn cache_key(&self) -> Option<ui_core::CachedKey> {
        (**self).cache_key()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ui_core::{Id, NodeKind};
    use ui_style::Env;

    /// A bare context for tests that do not care which node is hot.
    /// 不关心哪个节点被命中的测试用裸上下文。
    pub(crate) fn test_env() -> std::sync::Arc<Env> {
        Env::root()
    }

    struct Block {
        id: Id,
        draggable: bool,
    }

    impl Widget for Block {
        fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
            Decl::container(self.id, NodeKind::Box).sense(if self.draggable {
                ui_core::Sense::DRAG
            } else {
                ui_core::Sense::NONE
            })
        }
    }

    #[test]
    fn a_node_property_travels_with_the_declaration_not_with_the_widget() {
        // The point of keeping `Widget` to one method: the engine can answer "may this be
        // dragged?" from the tree alone, long after the widget is gone.
        // 把 `Widget` 收成一个方法的意义：控件早已销毁，引擎仍能仅凭树回答「这能拖吗」。
        // A boxed widget must forward without losing the declaration's node properties.
        // 装箱后的控件转发声明时不得丢掉节点属性。
        let mut store = ui_core::AnimStore::new();
        let mut core = ui_core::cx::Cx::new(&mut store, 0, 100, 100, 0.0, 0.0, 1.0, None);
        let cx = crate::cx::Cx::new(&mut core, test_env());
        let boxed: Box<dyn Widget> = Box::new(Block {
            id: Id::str("b"),
            draggable: true,
        });
        let forwarded = boxed.decl(&cx);
        assert!(
            forwarded.sense.contains(ui_core::Sense::DRAG),
            "the box forwards without losing it"
        );
        assert_eq!(forwarded.id, Id::str("b"));
        assert_eq!(forwarded.kind, NodeKind::Box);
    }

    #[test]
    fn a_styles_structure_is_entirely_its_own() {
        // Two widgets for the same role, one flat and one nested: nothing in the trait
        // constrains the shape. 同一角色的两个控件，一个平铺一个嵌套：trait 不约束形状。
        struct Flat;
        impl Widget for Flat {
            fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
                Decl::container(Id::str("f"), NodeKind::Box)
            }
        }
        struct Nested;
        impl Widget for Nested {
            fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
                Decl::container(Id::str("n"), NodeKind::Box)
                    .child(Decl::container(Id::str("n.a"), NodeKind::Box))
                    .child(Decl::container(Id::str("n.b"), NodeKind::Box))
            }
        }
        // Both are legal widgets for the same role; only the visual result differs.
        // 两者对同一角色都是合法控件，差别只在视觉结果。
        assert_eq!(crate::cx::Cx::for_test(|cx| Flat.decl(cx)).children.len(), 0);
        assert_eq!(crate::cx::Cx::for_test(|cx| Nested.decl(cx)).children.len(), 2);
    }

    #[test]
    fn a_control_that_handles_disabled_forwards_that_through_the_box() {
        // The adapter asks the boxed widget; the answer must survive the box, or the control
        // gets faded twice. 适配器询问装箱控件；答案必须穿过装箱，否则控件会被二次压暗。
        struct SelfDrawn;
        impl Widget for SelfDrawn {
            fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
                Decl::container(Id::str("s"), NodeKind::Box)
            }
            fn handles_disabled(&self) -> bool {
                true
            }
        }
        let boxed: Box<dyn Widget> = Box::new(SelfDrawn);
        assert!(boxed.handles_disabled(), "Box must forward handles_disabled");
        assert!(!Block { id: Id::str("b"), draggable: false }.handles_disabled(), "default is false");
    }
}
