//! Fingerprints for `Widget::cache_key`: one `u64` over every input `decl` reads.
//! 供 `Widget::cache_key` 用的指纹：把 `decl` 读到的每一项输入压成一个 `u64`。
//!
//! Floating point is the reason this exists: `f32` is not `Hash`, and a control is mostly
//! floats and colours. Everything is hashed by bit pattern, so `0.1 + 0.2` and `0.3` are
//! different fingerprints — which is what a cache needs, not what arithmetic needs.
//! 存在的理由是浮点：`f32` 不实现 `Hash`，而控件的输入大半是浮点与颜色。一律按位模式
//! 哈希，因此 `0.1 + 0.2` 与 `0.3` 指纹不同——缓存要的正是这个，算术要的不是。

use core::hash::Hasher;

use ui_core::Id;
use ui_core::collections::FastHasher;
use ui_core::geom::Color;

/// An input a control can fingerprint.
/// 控件能取指纹的一项输入。
pub trait Fingerprint {
    fn fingerprint(&self, h: &mut FastHasher);
}

impl Fingerprint for f32 {
    fn fingerprint(&self, h: &mut FastHasher) {
        h.write_u32(self.to_bits());
    }
}

impl Fingerprint for f64 {
    fn fingerprint(&self, h: &mut FastHasher) {
        h.write_u64(self.to_bits());
    }
}

macro_rules! integer_fingerprint {
    ($($t:ty),* $(,)?) => {
        $(impl Fingerprint for $t {
            fn fingerprint(&self, h: &mut FastHasher) {
                h.write_u64(*self as u64);
            }
        })*
    };
}

integer_fingerprint!(u8, u16, u32, u64, usize, i32, i64);

impl Fingerprint for bool {
    fn fingerprint(&self, h: &mut FastHasher) {
        h.write_u8(*self as u8);
    }
}

impl Fingerprint for char {
    fn fingerprint(&self, h: &mut FastHasher) {
        h.write_u32(*self as u32);
    }
}

impl Fingerprint for Id {
    fn fingerprint(&self, h: &mut FastHasher) {
        h.write_u64(self.as_u64());
    }
}

impl Fingerprint for Color {
    fn fingerprint(&self, h: &mut FastHasher) {
        self.r.fingerprint(h);
        self.g.fingerprint(h);
        self.b.fingerprint(h);
        self.a.fingerprint(h);
    }
}

impl Fingerprint for str {
    fn fingerprint(&self, h: &mut FastHasher) {
        h.write_usize(self.len());
        h.write(self.as_bytes());
    }
}

impl Fingerprint for String {
    fn fingerprint(&self, h: &mut FastHasher) {
        self.as_str().fingerprint(h);
    }
}

impl<T: Fingerprint> Fingerprint for Option<T> {
    fn fingerprint(&self, h: &mut FastHasher) {
        match self {
            Some(v) => {
                h.write_u8(1);
                v.fingerprint(h);
            }
            None => h.write_u8(0),
        }
    }
}

impl<T: Fingerprint> Fingerprint for [T] {
    fn fingerprint(&self, h: &mut FastHasher) {
        h.write_usize(self.len());
        for v in self {
            v.fingerprint(h);
        }
    }
}

impl<T: Fingerprint> Fingerprint for Vec<T> {
    fn fingerprint(&self, h: &mut FastHasher) {
        self.as_slice().fingerprint(h);
    }
}

impl<A: Fingerprint, B: Fingerprint> Fingerprint for (A, B) {
    fn fingerprint(&self, h: &mut FastHasher) {
        self.0.fingerprint(h);
        self.1.fingerprint(h);
    }
}

impl<A: Fingerprint, B: Fingerprint, C: Fingerprint> Fingerprint for (A, B, C) {
    fn fingerprint(&self, h: &mut FastHasher) {
        self.0.fingerprint(h);
        self.1.fingerprint(h);
        self.2.fingerprint(h);
    }
}

impl<A: Fingerprint, B: Fingerprint, C: Fingerprint, D: Fingerprint> Fingerprint for (A, B, C, D) {
    fn fingerprint(&self, h: &mut FastHasher) {
        self.0.fingerprint(h);
        self.1.fingerprint(h);
        self.2.fingerprint(h);
        self.3.fingerprint(h);
    }
}

/// Hash the listed expressions into one fingerprint.
/// 把列出的表达式哈希成一个指纹。
///
/// The list is the contract: anything `decl` reads that is missing here is a change no
/// frame will ever show.
/// 这个列表就是契约：`decl` 读到而这里漏掉的，就是永远显示不出来的变化。
#[macro_export]
macro_rules! fingerprint {
    ($($e:expr),* $(,)?) => {{
        use $crate::fingerprint::Fingerprint as _;
        use core::hash::Hasher as _;
        let mut h = ui_core::collections::FastHasher::default();
        $( $e.fingerprint(&mut h); )*
        h.finish()
    }};
}
