//! Semantic page skeleton; every style exposes regions as `id.with("nav")`…`id.with("overlay")`.
//! 语义化页面骨架；每种风格都用 `id.with("nav")`…`id.with("overlay")` 暴露六个区域。

use std::sync::Arc;

use ui_core::Id;
use ui_style::Env;

use crate::widget::Widget;

/// Six named regions; `main` is required, `None` means the caller has nothing there.
/// 六个具名区域；`main` 必需，`None` 表示调用方那里没有内容。
pub struct ScaffoldSpec<'a> {
    /// The skeleton's own node; content ids stay independent of it.
    /// 骨架自身的节点；内容 id 与它无关。
    pub id: Id,
    /// Leading navigation rail or pane.
    /// 左侧导航栏或窗格。
    pub nav: Option<&'a dyn Widget>,
    /// Top bar above the content area.
    /// 内容区上方的顶栏。
    pub header: Option<&'a dyn Widget>,
    /// The one required region.
    /// 唯一必需的区域。
    pub main: &'a dyn Widget,
    /// Trailing context panel.
    /// 右侧上下文面板。
    pub context: Option<&'a dyn Widget>,
    /// A strip that sits at the top of `main`.
    /// 位于 `main` 顶部的条带。
    pub inline: Option<&'a dyn Widget>,
    /// A layer floating above `main` without taking a slot.
    /// 浮在 `main` 上方、不占位的浮层。
    pub overlay: Option<&'a dyn Widget>,
    /// The bottom bar; each style places it the way its own system does.
    /// 底部栏；各风格按自己体系的做法摆放它。
    pub bottom: Option<&'a dyn Widget>,
    /// The parameter scope this page's subtree was built under.
    /// 这个页面子树构建时所用的参数作用域。
    pub env: Arc<Env>,
}

impl<'a> ScaffoldSpec<'a> {
    /// Content only: the shape most callers need.
    /// 只有内容的最小形态：多数调用方需要的样子。
    pub fn main_only(id: Id, main: &'a dyn Widget) -> Self {
        Self {
            id,
            nav: None,
            header: None,
            main,
            context: None,
            inline: None,
            overlay: None,
            bottom: None,
            env: Env::root(),
        }
    }

    pub fn nav(mut self, nav: &'a dyn Widget) -> Self {
        self.nav = Some(nav);
        self
    }

    pub fn header(mut self, header: &'a dyn Widget) -> Self {
        self.header = Some(header);
        self
    }

    pub fn context(mut self, context: &'a dyn Widget) -> Self {
        self.context = Some(context);
        self
    }

    pub fn inline(mut self, inline: &'a dyn Widget) -> Self {
        self.inline = Some(inline);
        self
    }

    pub fn overlay(mut self, overlay: &'a dyn Widget) -> Self {
        self.overlay = Some(overlay);
        self
    }

    pub fn bottom(mut self, bottom: &'a dyn Widget) -> Self {
        self.bottom = Some(bottom);
        self
    }
    /// Push a parameter scope for this page's subtree. The scope rides on the declarations,
    /// so every control built under it inherits it without being told.
    /// 给本页子树压入参数作用域。作用域随声明流动，其下的每个控件自动继承，无需被告知。
    pub fn scoped<P: 'static + Send + Sync>(mut self, params: P) -> Self {
        self.env = Env::with(Some(self.env.clone()), params);
        self
    }

    /// The scope `StyleKit::scaffold` and the page's controls should be built under.
    /// 构建骨架与该页控件时应使用的作用域。
    pub fn env(&self) -> &Env {
        &self.env
    }

}

#[cfg(test)]
mod tests {
    use super::*;

    struct Square(Id, f32);

    impl Widget for Square {
        fn decl(&self, _cx: &crate::cx::Cx<'_, '_>) -> ui_core::Decl {
            ui_core::Decl::container(self.0, ui_core::NodeKind::Box)
                .size(ui_core::SizeClass::fixed(self.1, self.1))
        }
    }

    #[test]
    fn a_builder_chain_sets_exactly_the_regions_it_names() {
        // `main_only` must leave the other five empty, or callers would draw ghosts.
        // `main_only` 必须让其余五个为空，否则调用方会画出幽灵区域。
        let main = Square(Id::str("m"), 10.0);
        let nav = Square(Id::str("n"), 10.0);
        let overlay = Square(Id::str("o"), 10.0);
        let bare = ScaffoldSpec::main_only(Id::str("r"), &main);
        assert!(bare.nav.is_none() && bare.header.is_none() && bare.context.is_none());
        assert!(bare.inline.is_none() && bare.overlay.is_none());
        let chained = ScaffoldSpec::main_only(Id::str("r"), &main)
            .nav(&nav)
            .overlay(&overlay);
        assert!(chained.nav.is_some() && chained.overlay.is_some());
        assert!(chained.header.is_none() && chained.context.is_none() && chained.inline.is_none());
    }
}
