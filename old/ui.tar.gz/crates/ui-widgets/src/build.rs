//! Names every style shares for its atomic animation instances, plus the drag follow spec.
//! 所有风格共用的原子动画实例名，以及拖拽跟随规格。

use crate::NodeCx;
use ui_core::{AnimSpec, Easing, Id};

pub mod param {
    /// 0..=1 travel of the semantic value.
    /// 语义值 0..=1 的行程。
    pub const POSITION: &str = "position";
    /// 0..=1 raw progress of the semantic value, linear in time.
    /// 语义值 0..=1 的原始进度，随时间线性。
    pub const PROGRESS: &str = "progress";
    /// 0..=1 palette blend; styles that fade colours separately use this.
    /// 0..=1 的调色板混合；把颜色单独淡变的风格使用它。
    pub const COLOUR: &str = "colour";
    /// 0..=1 press intensity.
    /// 0..=1 的按压强度。
    pub const PRESS: &str = "press";
    /// Diameter the thumb has at the off end, latched there by styles that need it.
    /// 滑块在关闭端的直径，由需要它的风格在那一端锁存。
    pub const SIZE_OFF: &str = "sizeOff";
    /// Diameter the thumb has at the on end.
    /// 滑块在开启端的直径。
    pub const SIZE_ON: &str = "sizeOn";
    /// Thumb width in px, animated on its own so a squash needs no derived sequence.
    /// 滑块宽度（px），独立动画，形变因此不需要派生序列。
    pub const WIDTH: &str = "width";
    /// Thumb height in px.
    /// 滑块高度（px）。
    pub const HEIGHT: &str = "height";
    /// Track colour, animated as one colour instance.
    /// 轨道颜色，作为一个颜色实例推进。
    pub const TRACK: &str = "track";
    /// Outline colour.
    /// 描边颜色。
    pub const OUTLINE: &str = "outline";
    /// 0..=1 hover overlay fade.
    /// 0..=1 的悬停状态层淡入淡出。
    pub const HOVER: &str = "hover";
    /// 0..=1 focus overlay fade.
    /// 0..=1 的聚焦状态层淡入淡出。
    pub const FOCUS: &str = "focus";
    /// 0..=1 glass bloom thickness.
    /// 0..=1 的玻璃膨胀厚度。
    pub const THICKNESS: &str = "thickness";
}

/// The finger is the clock: a zero-duration write, so a held gesture is not smoothed.
/// 手指就是时钟：零时长写入，按住的手势因此不被平滑。
pub const IMMEDIATE: AnimSpec = AnimSpec::new(0.0, Easing::Linear);

/// The shortest follow that still smooths hand jitter: a drag sets a *target*, never a value.
/// 仍能平滑手抖的最短跟随：拖拽设置的是**目标**，而不是值。
///
/// A zero-duration write looks identical on a still frame and jumps when the target moves.
/// 零时长写入在静止帧上看不出区别，但目标一变就会跳。
pub const DRAG_FOLLOW: AnimSpec = AnimSpec::new(0.024, Easing::Linear);

/// Where a dragged element sits: a press never moves it, the first drag frame glides from
/// `value` to the finger and later frames track it; a tap glides to its value over `settle`.
/// 被拖元素的位置：按下不动，拖拽第一帧从 `value` 滑向手指、随后跟手；点击则按 `settle` 滑过去。
pub fn drag_follow(
    ctx: &mut NodeCx<'_>,
    id: Id,
    value: f32,
    finger: f32,
    dragging: bool,
    glide: AnimSpec,
    settle: AnimSpec,
) -> f32 {
    let live = id.with("drag-live");
    let offset = id.with("drag-offset");
    let progress = id.with("drag-progress");
    let rest = id.with("drag-rest");
    if dragging {
        if ctx.value(live) <= 0.5 {
            // First drag frame: the element stays where it is, the gap to the finger is banked,
            // and the glide's clock starts here rather than a frame later.
            // 拖拽第一帧：元素留在原处，记下与手指的差距，滑行的时钟从这一帧起算而非下一帧。
            ctx.animate(live, 1.0, IMMEDIATE);
            ctx.animate(offset, value - finger, IMMEDIATE);
            ctx.animate(progress, 0.0, IMMEDIATE);
            ctx.animate(progress, 1.0, glide);
            ctx.animate(rest, value, IMMEDIATE);
            return value;
        }
        let p = ctx.animate(progress, 1.0, glide);
        let pos = finger + ctx.value(offset) * (1.0 - p);
        // The settled value is wherever the finger has the element, so letting go changes nothing.
        // 落定值就是手指把它带到的位置，松手因此不产生跳变。
        ctx.animate(rest, pos, IMMEDIATE);
        return pos;
    }
    if ctx.value(live) > 0.5 {
        let p = ctx.animate(progress, 1.0, glide);
        // The release frame reports where the finger left the element, never `value`: the app
        // has not applied the change yet, so a control that commits by position must see the
        // finger's, not the stale semantic value. A release before the glide is spent keeps
        // the branch armed until the element has caught up, then the idle path takes over.
        // 松手这一帧报的是手指离开的位置，绝不是 `value`：应用尚未落值，
        // 按位置提交的控件必须看到手指的位置。滑行未走完就松手时留在本支直到追上手指，
        // 之后交给空闲路径。
        let pos = finger + ctx.value(offset) * (1.0 - p);
        ctx.animate(rest, pos, IMMEDIATE);
        if p > 0.999 {
            ctx.animate(live, 0.0, IMMEDIATE);
        }
        return pos;
    }
    // Idle: a tap or a value set from outside glides to it, it does not snap.
    // 空闲：点击或外部设值都滑向目标，不瞬移。
    ctx.animate(rest, value, settle)
}

#[cfg(test)]
mod tests {
    use super::*;
    use ui_core::AnimStore;

    fn at(anim: &mut AnimStore, now: f64, value: f32, finger: f32, dragging: bool) -> f32 {
        let id = Id::str("thumb");
        let mut node = crate::cx::NodeCx::new(id, Default::default(), 1.0, now, anim);
        drag_follow(
            &mut node,
            id,
            value,
            finger,
            dragging,
            DRAG_FOLLOW_GLIDE,
            DRAG_FOLLOW_GLIDE,
        )
    }

    const DRAG_FOLLOW_GLIDE: AnimSpec = AnimSpec::new(0.150, Easing::Linear);

    #[test]
    fn a_release_before_the_glide_is_spent_reports_the_element_not_the_old_value() {
        // The app has not applied the drag yet on the release frame, so reporting `value`
        // there rewinds the element to where it started — a quick flick snapped back and
        // committed nothing. The frame must report the element's own travel so far.
        // 松手那一帧应用还没落值，此时报 `value` 就是把元素倒回起点——快速一甩会弹回去
        // 且什么都没提交。这一帧必须报元素自己已经走到的位置。
        let mut anim = AnimStore::new();
        assert_eq!(at(&mut anim, 0.0, 0.0, 0.0, false), 0.0, "closed at rest");
        assert_eq!(at(&mut anim, 0.0, 0.0, 0.9, true), 0.0, "the drag starts where it was");
        let released = at(&mut anim, 0.017, 0.0, 0.9, false);
        assert!(released > 0.0, "the release keeps the travel, got {released}");
        assert!(released < 0.9, "and the glide is still under way, got {released}");
    }

    #[test]
    fn a_drag_glides_to_the_finger_and_only_then_tracks_it() {
        // A press must not move the element, and the first drag frame must not either: the
        // gap is banked and spent over the spec, or the thumb teleports under the cursor.
        // 按下不得移动元素，拖拽第一帧同样不得：差距先记下，再按规格花掉，
        // 否则拇指会瞬移到光标下。
        let mut anim = AnimStore::new();
        assert_eq!(at(&mut anim, 0.0, 0.2, 0.8, false), 0.2, "a press moves nothing");
        assert_eq!(at(&mut anim, 0.0, 0.2, 0.8, true), 0.2, "the drag starts where it was");
        let mid = at(&mut anim, 0.075, 0.2, 0.8, true);
        assert!(mid > 0.2 && mid < 0.8, "half way through the glide, got {mid}");
        assert!((at(&mut anim, 0.150, 0.2, 0.8, true) - 0.8).abs() < 1e-3, "landed");
        assert!(
            (at(&mut anim, 0.200, 0.2, 0.9, true) - 0.9).abs() < 1e-3,
            "a moved finger is tracked exactly once the glide is spent"
        );
        // The app has reported the finger's value all along, so the semantic value is the
        // finger's when the press ends.
        // 应用一路按手指上报值，因此松手时语义值就是手指所在处。
        assert!(
            (at(&mut anim, 0.200, 0.9, 0.9, false) - 0.9).abs() < 1e-3,
            "letting go leaves the element under the finger"
        );
        // A tap sets the value outright; the element travels there instead of snapping.
        // 点击直接设定值，元素滑过去而不是瞬移。
        assert_eq!(at(&mut anim, 0.275, 0.0, 0.0, false), 0.9, "a tap starts where it was");
        let tapped = at(&mut anim, 0.350, 0.0, 0.0, false);
        assert!(
            (tapped - 0.45).abs() < 1e-3,
            "half way to a tapped value, got {tapped}"
        );
        assert!(
            at(&mut anim, 0.425, 0.0, 0.0, false).abs() < 1e-3,
            "a tap's value is reached"
        );
    }
}
