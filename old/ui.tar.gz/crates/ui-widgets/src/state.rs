//! The interaction state a control resolves its look from, re-exported from the engine.
//! 控件据此解析外观的交互状态，从引擎层再导出。

pub use ui_platform::WidgetState;

#[cfg(test)]
mod tests {
    use super::*;
    use ui_core::Id;

    #[test]
    fn state_reports_press_only_for_the_exact_id() {
        let id = Id::str("a");
        let other = Id::str("b");
        let mut anim = ui_core::AnimStore::new();
        let mut core = ui_core::cx::Cx::new(&mut anim, 0, 100, 100, 0.0, 0.0, 1.0, None);
        core.route(ui_core::cx::Routing {
            pressed: Some(id),
            focused: Some(other),
            ..ui_core::cx::Routing::default()
        });
        let s = WidgetState::of(&core, id);
        assert!(s.pressed);
        assert!(!s.focused);
        let t = WidgetState::of(&core, other);
        assert!(t.focused);
        assert!(!t.pressed);
    }
}
