//! The text control: the one place a widget states *what* it is drawing and *in what font*.
//! 文本控件：控件声明「画什么、用什么字体」的唯一地方。

use ui_core::geom::{Color, Insets};
use ui_core::layout::{AxisSize, Grow};
use ui_core::{
    Decl, Family, Features, Id, NodeData, NodeKind, SizeClass, TextAlign, TextBlock, TextRun,
    TextStyle, Variations, Weight,
};

/// A text node's height per em of type size: the box its glyphs are centred in.
/// 每 em 字号的文本节点高度：字形居于其中的盒子。
pub const LINE_HINT: f32 = 1.4;

/// The box an icon of `size` occupies: its em square, so a caller centres the box.
/// 一个 `size` 号图标占据的盒子：它的 em 方盒，调用方居中的就是这个盒子。
pub fn icon_extent(size: f32) -> f32 {
    size
}

/// The role names this control reads from a pack.
/// 本控件从包中读取的角色名。
pub mod roles {
    /// The wash behind selected text.
    /// 被选中文字背后的底色。
    pub const SELECTION: &str = "textSelection";
}

/// A run of text as a control: body plus every font-bearing setting it takes.
/// 作为控件的文本：正文加上它接受的全部字体相关设置。
///
/// Ink is here, not on the type ramp: the widget that owns the surface knows its background
/// and so chooses the role; the text control only carries that choice down to the prim.
/// 墨色在这里，不在字阶上：拥有该表面的控件知道背景，因而选角色；文本控件只把选择带到图元。
pub struct Text {
    pub id: Id,
    pub body: String,
    pub size: f32,
    pub weight: Weight,
    /// Family, variable axes and features: everything a font request carries besides size.
    /// 字体族、可变轴与特性：字体请求除字号之外携带的全部内容。
    pub family: Family,
    pub variations: Variations,
    pub features: Features,
    pub ink: Color,
    /// Wrap width: the most this text may take before it breaks a line.
    /// 换行宽度：本文本在断行之前最多可占用的宽度。
    pub max_width: f32,
    /// One line, however narrow the box: the node overflows and the caller scrolls it.
    /// 单行，无论盒子多窄：节点溢出，由调用方按滚动处理。
    pub nowrap: bool,
    /// Stop after this many lines; the painter ends the last one with an ellipsis.
    /// 排到这么多行就停；绘制端在最后一行末尾加省略号。
    pub max_lines: Option<u32>,
    pub line_gap: f32,
    pub indent: f32,
    /// How lines sit inside the wrap width; the painter honours it via `aligned_x`.
    /// 各行在换行宽度内的位置；绘制端经 `aligned_x` 落实它。
    pub align: TextAlign,
    /// Draw an insertion caret at this byte offset, in this ink.
    /// 在该字节偏移处以给定墨色绘制插入符。
    pub caret: Option<ui_core::Caret>,
    /// Pointer selection, when this text takes it.
    /// 本文本接受指针选择时的选区外观。
    pub selectable: Option<Selectable>,
    /// A selection to paint without taking pointer selection: an input's own selection.
    /// 只绘制、不接受指针选择的选区：文本输入自己的选区。
    pub painted: Option<ui_core::SelectionPrim>,
    /// Bytes the input method is composing, underlined by the text pass.
    /// 输入法正在组合的字节，由文本那一趟加下划线。
    pub composing: Option<std::ops::Range<usize>>,
}

/// A text control that takes pointer selection, and how its style draws it.
/// 接受指针选择的文本控件，以及它的风格如何绘制选区。
#[derive(Clone, Copy, Debug)]
pub struct Selectable {
    pub fill: Color,
    pub painter: Option<ui_core::SelectionPainterRef>,
}

impl Text {
    pub fn new(id: Id, body: impl Into<String>, size: f32, ink: Color) -> Self {
        Self {
            id,
            body: body.into(),
            size,
            weight: Weight::REGULAR,
            family: Family::default(),
            variations: Variations::NONE,
            features: Features::NONE,
            ink,
            max_width: f32::INFINITY,
            nowrap: false,
            max_lines: None,
            line_gap: 0.0,
            indent: 0.0,
            align: TextAlign::Start,
            caret: None,
            selectable: None,
            painted: None,
            composing: None,
        }
    }

    /// Builder: this text asks for weight `w`.
    /// 构造器：本文本请求字重 `w`。
    pub fn weight(mut self, w: Weight) -> Self {
        self.weight = w;
        self
    }

    /// Builder: this text asks for `family`.
    /// 构造器：本文本请求 `family`。
    pub fn family(mut self, family: Family) -> Self {
        self.family = family;
        self
    }

    /// Builder: variable-font axes beyond weight.
    /// 构造器：字重之外的可变字体轴。
    pub fn variations(mut self, variations: Variations) -> Self {
        self.variations = variations;
        self
    }

    /// Builder: OpenType features.
    /// 构造器：OpenType 特性。
    pub fn features(mut self, features: Features) -> Self {
        self.features = features;
        self
    }

    /// Builder: wrap at `width` logical units.
    /// 构造器：在 `width` 逻辑单位处换行。
    pub fn max_width(mut self, width: f32) -> Self {
        self.max_width = width;
        self
    }

    /// Builder: lay this text out on one line, overflowing instead of wrapping.
    /// 构造器：把本文本排成一行，溢出而不换行。
    pub fn nowrap(mut self) -> Self {
        self.nowrap = true;
        self
    }

    /// Builder: stop after `lines`, ending the last one with an ellipsis.
    /// 构造器：排到 `lines` 行即止，最后一行末尾加省略号。
    pub fn max_lines(mut self, lines: u32) -> Self {
        self.max_lines = Some(lines);
        self
    }

    /// Builder: extra leading between lines.
    /// 构造器：行间额外空隙。
    pub fn line_gap(mut self, gap: f32) -> Self {
        self.line_gap = gap;
        self
    }

    /// Builder: first-line indent.
    /// 构造器：首行缩进。
    pub fn indent(mut self, indent: f32) -> Self {
        self.indent = indent;
        self
    }

    /// Builder: how lines sit inside the wrap width.
    /// 构造器：各行在换行宽度内的位置。
    pub fn align(mut self, align: TextAlign) -> Self {
        self.align = align;
        self
    }

    /// Builder: draw the insertion caret at byte `offset` in `ink`.
    /// 构造器：在字节 `offset` 处以 `ink` 绘制插入符。
    pub fn caret(mut self, offset: usize, ink: Color) -> Self {
        self.caret = Some(ui_core::Caret { offset, color: ink });
        self
    }

    /// Builder: take pointer selection, drawn by `painter` in `fill`.
    /// 构造器：接受指针选择，由 `painter` 用 `fill` 绘制。
    pub fn selectable(mut self, fill: Color, painter: Option<ui_core::SelectionPainterRef>) -> Self {
        self.selectable = Some(Selectable { fill, painter });
        self
    }

    /// Builder: take pointer selection, with the wash and painter `pack` resolved.
    /// 构造器：接受指针选择，底色与绘制程序取自 `pack` 的解析结果。
    pub fn selectable_in(self, pack: &ui_style::Style) -> Self {
        let fill = pack
            .ink(roles::SELECTION)
            .expect("pack has no textSelection role");
        self.selectable(fill, pack.selection)
    }

    /// Builder: underline this byte range as input-method composition.
    /// 构造器：把这段字节作为输入法组合内容加下划线。
    pub fn composing(mut self, range: Option<std::ops::Range<usize>>) -> Self {
        self.composing = range;
        self
    }

    /// Builder: paint `selection` under this text, without taking pointer selection.
    /// 构造器：在文本下绘制 `selection`，但不接受指针选择。
    pub fn painting(mut self, selection: Option<ui_core::SelectionPrim>) -> Self {
        self.painted = selection;
        self
    }

    /// The declaration for a frame, with this node's selection read from the engine.
    /// 本帧的声明，其中选区由引擎为这个节点记录。
    pub fn resolve_in(&self, cx: &crate::cx::Cx<'_, '_>) -> Decl {
        let selection = self.selectable.as_ref().and_then(|style| {
            cx.core()
                .selection_for(self.id)
                .filter(|selection| !selection.is_collapsed())
                .map(|selection| ui_core::SelectionPrim {
                    range: selection.range(),
                    fill: style.fill,
                    painter: style.painter,
                })
        });
        self.build(selection)
    }

    pub fn resolve(&self) -> Decl {
        self.build(None)
    }

    /// The box this text takes on one line, measured as layout will measure it.
    /// 这段文本单行占用的盒子，与布局所用的同一次测量。
    ///
    /// `None` when the host supplied no measurer: a caller that needs a number must then
    /// fall back to geometry it already has, never to a guessed advance.
    /// 宿主未提供测量器时为 `None`：需要数值的调用方必须回落到已有的几何，绝不猜字宽。
    pub fn size_in(&self, cx: &crate::cx::Cx<'_, '_>) -> Option<ui_core::geom::Size> {
        let decl = self.build(None);
        let ui_core::NodeData::Text { block, .. } = &decl.data else {
            return None;
        };
        cx.text_size(block, self.max_width)
    }

    /// The width this text takes on one line.
    /// 这段文本单行占用的宽度。
    pub fn width_in(&self, cx: &crate::cx::Cx<'_, '_>) -> Option<f32> {
        self.size_in(cx).map(|size| size.w)
    }

    fn build(&self, selection: Option<ui_core::SelectionPrim>) -> Decl {
        Decl {
            id: self.id,
            kind: NodeKind::Text,
            shapes: Vec::new(),
            data: NodeData::Text {
                ink: self.ink,
                block: TextBlock {
                    runs: vec![TextRun::new(
                        self.body.clone(),
                        TextStyle::new(self.size)
                            .weight(self.weight)
                            .family(self.family)
                            .variations(self.variations)
                            .features(self.features),
                    )],
                    align: self.align,
                    max_lines: self.max_lines,
                    line_gap: self.line_gap,
                    indent: self.indent,
                    atoms: Vec::new(),
                },
                caret: self.caret,
                selection: selection.or_else(|| self.painted.clone()),
                composing: self.composing.clone(),
                nowrap: self.nowrap,
            },
            size_class: SizeClass {
                width: AxisSize::hug(0.0, self.max_width),
                height: AxisSize::hug(self.size, self.size * LINE_HINT),
                grow_x: Grow::No,
                grow_y: Grow::No,
            },
            ink_margin: Insets::ZERO,
            box_model: Default::default(),
            offset: ui_core::geom::Point::new(0.0, 0.0),
            cursor: None,
            sense: if self.selectable.is_some() {
                ui_core::Sense::SELECT
            } else {
                ui_core::Sense::NONE
            },
            disabled: false,
            grid: Default::default(),
            placement: Default::default(),
            env: None,
            children: Vec::new(),
        }
    }
}

/// Thin positional wrapper kept for callers that built one line inline; delegates to `Text`.
/// 供内联单行构造的薄封装；委托给 `Text`。
pub fn leaf(
    id: Id,
    body: String,
    size: f32,
    color: Color,
    weight: Weight,
    max_width: f32,
    line_gap: f32,
    indent: f32,
) -> Decl {
    Text::new(id, body, size, color)
        .weight(weight)
        .max_width(max_width)
        .line_gap(line_gap)
        .indent(indent)
        .resolve()
}

/// What an editor draws: the buffer with the composition spliced in at the caret, plus the
/// composed range and where the caret sits in the shown text.
/// 编辑器要画的东西：在插入符处拼上组合内容的缓冲，以及组合范围与插入符在所示文本中的位置。
pub fn typed_input(
    text: &str,
    caret: Option<usize>,
    preedit: Option<&ui_core::Preedit>,
) -> (String, Option<std::ops::Range<usize>>, Option<usize>) {
    match preedit {
        Some(p) if !p.is_empty() => {
            let at = caret.unwrap_or(text.len()).min(text.len());
            let mut shown = String::with_capacity(text.len() + p.text.len());
            shown.push_str(&text[..at]);
            shown.push_str(&p.text);
            shown.push_str(&text[at..]);
            (
                shown,
                Some(at..at + p.text.len()),
                Some(at + p.cursor.min(p.text.len())),
            )
        }
        _ => (text.to_string(), None, caret),
    }
}

/// How far a single-line editor must shift left so its caret clears the right edge.
/// 单行编辑器需要左移多少，才能让插入符越过右边缘。
pub fn caret_scroll(
    cx: &crate::Cx<'_, '_>,
    text_id: Id,
    width: f32,
    caret_width: f32,
    slack: f32,
) -> f32 {
    cx.core()
        .caret_in_text_for(text_id)
        .map(|x| (x + caret_width + slack - width).max(0.0))
        .unwrap_or(0.0)
}

/// Everything one editable line draws; the surface, label and icons belong to the field.
/// 一条可编辑行要画的一切；表面、标签与图标归字段所有。
pub struct LineEdit<'a> {
    pub id: Id,
    pub text: &'a str,
    pub caret: Option<usize>,
    pub preedit: Option<&'a ui_core::Preedit>,
    /// The selection, painted by the pack's own painter.
    /// 选区，由包自己的绘制程序绘制。
    pub painted: Option<ui_core::SelectionPrim>,
    pub placeholder: &'a str,
    /// Cupertino shows the hint whenever the buffer is empty; Material only while focused.
    /// Cupertino 在缓冲为空时总显示提示；Material 只在聚焦时显示。
    pub hint_always: bool,
    pub focused: bool,
    pub size: f32,
    pub weight: Weight,
    pub ink: Color,
    pub placeholder_ink: Color,
    pub caret_ink: Color,
    pub caret_width: f32,
    pub slack: f32,
    /// The text box's width between the field's insets.
    /// 字段内衬之间文本框的宽度。
    pub width: f32,
    pub left_inset: f32,
    pub right_inset: f32,
}

impl LineEdit<'_> {
    /// The line: one nowrap run scrolled just far enough, plus the hint and caret when empty.
    /// 这一行：一条只滚到刚好的单行文本；为空时另有提示文字与插入符。
    pub fn resolve(&self, cx: &crate::Cx<'_, '_>) -> Decl {
        let (shown, composing, caret_at) = typed_input(self.text, self.caret, self.preedit);
        let mut input = Text::new(self.id.with("input"), shown.clone(), self.size, self.ink)
            .weight(self.weight)
            .nowrap()
            .max_width(self.width)
            .painting(self.painted.clone())
            .composing(composing);
        if let Some(offset) = caret_at.filter(|_| !shown.is_empty()) {
            input = input.caret(offset, self.caret_ink);
        }
        let scroll = caret_scroll(cx, self.id.with("input"), self.width, self.caret_width, self.slack);
        let input = input.resolve().offset(-scroll, 0.0);
        // A nowrap line runs past the field; cutting it here keeps the overflow out of sight.
        // 单行文本会跑出字段之外；在这里裁剪才能挡住溢出。
        let mut content = Decl::container(self.id.with("content"), NodeKind::Stack)
            .size(SizeClass {
                width: AxisSize::fixed(self.width + self.left_inset + self.right_inset),
                height: AxisSize::hug(0.0, 0.0),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .clip(ui_core::layout::Clip {
                x: ui_core::layout::Overflow::Hidden,
                y: ui_core::layout::Overflow::Visible,
            })
            .padding(Insets {
                left: self.left_inset,
                top: 0.0,
                right: self.right_inset,
                bottom: 0.0,
            })
            .child(input);
        let empty = self.text.is_empty() && self.preedit.is_none();
        if (self.focused || self.hint_always) && empty && !self.placeholder.is_empty() {
            content = content.child(
                Text::new(
                    self.id.with("hint"),
                    self.placeholder.to_string(),
                    self.size,
                    self.placeholder_ink,
                )
                .weight(self.weight)
                .max_width(self.width)
                .resolve(),
            );
        }
        if self.focused && empty {
            // An empty buffer has no span to shape, so its caret is a plain box at the origin.
            // 空缓冲没有可整形的区间，因此它的插入符是原点处的一个实心盒。
            content = content.child(
                Decl::container(self.id.with("caret"), NodeKind::Box)
                    .size(SizeClass::fixed(self.caret_width, self.size * LINE_HINT))
                    .background(self.caret_ink, ui_core::geom::Corners::ZERO),
            );
        }
        content
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_text_control_carries_the_size_line_gap_and_indent_it_was_handed() {
        let d = lead();
        match &d.data {
            NodeData::Text { block, .. } => {
                assert_eq!(block.indent, 24.0);
                assert_eq!(block.line_gap, 2.0);
                assert_eq!(block.runs[0].style.size, 13.0);
                assert_eq!(block.runs[0].style.weight, Weight::BOLD);
            }
            other => panic!("expected text, got {other:?}"),
        }
    }

    #[test]
    fn a_text_control_keeps_the_ink_the_owner_chose() {
        // The ink rides on the text node, so a painter reads one field, not the type ramp.
        // 墨色携带在文本节点上，绘制端只读一个字段，而不是字阶。
        let d = Text::new(Id::str("t"), "x", 13.0, Color::from_rgba8(1, 2, 3, 255)).resolve();
        match &d.data {
            NodeData::Text { ink, .. } => assert_eq!(*ink, Color::from_rgba8(1, 2, 3, 255)),
            other => panic!("expected text, got {other:?}"),
        }
    }

    #[test]
    fn a_text_control_honours_a_regular_weight_without_second_guessing() {
        let d = Text::new(Id::str("b"), "x", 13.0, Color::WHITE)
            .weight(Weight(400))
            .resolve();
        match &d.data {
            NodeData::Text { block, .. } => assert_eq!(block.runs[0].style.weight, Weight(400)),
            other => panic!("expected text, got {other:?}"),
        }
    }

    fn lead() -> Decl {
        leaf(Id::str("c"), "x".into(), 13.0, Color::WHITE, Weight::BOLD, 100.0, 2.0, 24.0)
    }
}
