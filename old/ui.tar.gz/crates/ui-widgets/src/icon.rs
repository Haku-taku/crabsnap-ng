//! Icon primitives: a glyph source described independently of any icon set.
//! 图标原语：与任何图标集解耦的"字形源"描述。

use ui_core::geom::Color;
use ui_core::{AxisSize, Decl, Family, Id, Variations, Weight};

use crate::text::Text;

/// The three Material Symbols families, i.e. the shape of the icon set.
/// 三套 Material Symbols 字族，也就是图标集的形状。
///
/// This stays as the convenience entrance for Material Symbols; an icon itself no longer
/// carries one — it carries a `Family` instead, so any glyph font can drive the slot.
/// 这里保留为 Material Symbols 的便捷入口；图标本身不再携带它——图标携带的是
/// `Family`，于是任何字形字体都能驱动图标槽位。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum IconSet {
    #[default]
    Outlined,
    Rounded,
    Sharp,
}

impl IconSet {
    /// The family name the font provider resolves.
    /// 字体提供者解析的族名。
    pub const fn family(self) -> &'static str {
        match self {
            Self::Outlined => "Material Symbols Outlined",
            Self::Rounded => "Material Symbols Rounded",
            Self::Sharp => "Material Symbols Sharp",
        }
    }
}

/// The family the vendored SF Symbols font must be registered under.
/// 随仓库分发的 SF Symbols 字体必须注册到的族名。
pub const SF_SYMBOLS_FAMILY: &str = "SFSymbols";

/// What fills an icon slot: one glyph in a family, or an app-drawn mark.
/// 填充图标槽位的东西：某个族里的一个字形，或应用自绘的标记。
///
/// This is the source *description* the slot stores — the same role Flutter's `IconData`,
/// GPUI's `IconSource` and Qt's `icon.name` play. It is `Copy`, so controls can hold it and
/// re-resolve it per state: a selected destination resolves its `FILL` axis to 1, an
/// unselected one to 0, without the caller swapping objects.
/// 这是槽位保存的"源描述"——与 Flutter 的 `IconData`、GPUI 的 `IconSource`、Qt 的
/// `icon.name` 同角色。它可 `Copy`，控件持有它并按状态重新解析：选中目标把 `FILL`
/// 轴解析为 1、未选中为 0，调用方无需换对象。
#[derive(Clone, Copy, Debug)]
pub enum IconSource {
    /// One glyph in a named family plus the variable axes that shape it.
    /// 具名族里的一个字形，外加决定形状的可变轴。
    Glyph {
        family: Family,
        glyph: char,
        /// `FILL` axis: 0 outlined, 1 filled; fractional values animate.
        /// `FILL` 轴：0 空心，1 实心；小数值用于动画。
        fill: f32,
        /// `wght` axis: stroke width, not a face choice.
        /// `wght` 轴：笔画粗细，不是选字面。
        weight: Weight,
        /// `GRAD` axis: emphasis, typically -50..200.
        /// `GRAD` 轴：强调程度，通常 -50..200。
        grade: f32,
    },
    /// An app-drawn mark: given a slot id and its ink, produce the declaration.
    /// 应用自绘的标记：给定槽位 id 与其墨水色，产出一个声明。
    Custom(fn(Id, Color) -> Decl),
}

impl IconSource {
    /// A Material Symbols glyph by name, resolved to its PUA codepoint.
    /// 按名字取 Material Symbols 字形，解析成 PUA 码点。
    pub fn glyph(name: &str, set: IconSet) -> Self {
        Self::Glyph {
            family: Family::Named(set.family()),
            glyph: lookup(name),
            fill: 0.0,
            weight: Weight::REGULAR,
            grade: 0.0,
        }
    }

    /// An SF Symbols glyph by Apple's name; `.` and `_` are interchangeable, so
    /// `house.fill` and `house_fill` both land.
    /// 按 Apple 的名字取 SF Symbols 字形；`.` 与 `_` 等价，`house.fill` 与 `house_fill` 都行。
    pub fn sf(name: &str) -> Self {
        Self::from_parts(Family::Named(SF_SYMBOLS_FAMILY), sf_lookup(name))
    }

    /// Any glyph at a raw codepoint in `family` — the custom-font entrance.
    /// `family` 族里按裸码点取字形——自定义字体的入口。
    pub fn from_parts(family: Family, glyph: char) -> Self {
        Self::Glyph {
            family,
            glyph,
            fill: 0.0,
            weight: Weight::REGULAR,
            grade: 0.0,
        }
    }

    /// Builder: the `FILL` axis; the slot resolves it per state.
    /// 构造器：`FILL` 轴；槽位按状态解析它。
    pub fn fill(mut self, fill: f32) -> Self {
        if let Self::Glyph { fill: f, .. } = &mut self {
            *f = fill;
        }
        self
    }

    /// Builder: stroke width, per the `wght` axis.
    /// 构造器：按 `wght` 轴设定笔画粗细。
    pub fn weight(mut self, weight: Weight) -> Self {
        if let Self::Glyph { weight: w, .. } = &mut self {
            *w = weight;
        }
        self
    }

    /// Builder: emphasis, per the `GRAD` axis.
    /// 构造器：按 `GRAD` 轴设定强调程度。
    pub fn grade(mut self, grade: f32) -> Self {
        if let Self::Glyph { grade: g, .. } = &mut self {
            *g = grade;
        }
        self
    }

    /// Resolve into `id`'s slot at the MD3 icon size.
    /// 在 `id` 的槽位里按 MD3 图标尺寸解析。
    pub fn resolve(&self, id: Id, ink: Color) -> Decl {
        self.resolve_with_size(id, ink, 24.0)
    }

    /// Resolve into `id`'s slot at `size` points, in a `size`-square em box.
    /// 在 `id` 的槽位里按 `size` 磅值解析，盒子就是 `size` 见方的 em 盒。
    pub fn resolve_with_size(&self, id: Id, ink: Color, size: f32) -> Decl {
        match *self {
            Self::Glyph { family, glyph, fill, weight, grade } => {
                let variations = Variations::NONE
                    .fill(fill)
                    .optical_size(size)
                    .grade(grade);
                let mut decl = Text::new(id, glyph.to_string(), size, ink)
                    .family(family)
                    .weight(weight)
                    .variations(variations)
                    .resolve();
                // An icon occupies its em box, not a text line box: a 1.4 em slot hangs the
                // glyph below the centre of a `size`-square slot. 图标占据 em 盒而非文本行盒：
                // 1.4em 的槽会让字形挂在 `size` 见方槽位的中心之下。
                decl.size_class.width = AxisSize::fixed(size);
                decl.size_class.height = AxisSize::fixed(size);
                decl
            }
            Self::Custom(build) => build(id, ink),
        }
    }
}

/// One icon in a slot: a source, a size and an ink.
/// 一个图标：源、尺寸与墨水色。
///
/// The glyph is addressed by codepoint rather than by ligature name, so drawing it needs
/// no shaping features and its advance is exactly one em — Flutter's `Icons` does the same.
/// 字形按码点而非连字名寻址，因此绘制不依赖整形特性，前进宽度恰好一个 em——
/// Flutter 的 `Icons` 也是这么做的。
#[derive(Clone, Copy, Debug)]
pub struct Icon {
    pub id: Id,
    pub source: IconSource,
    pub size: f32,
    pub ink: Color,
}

impl Icon {
    /// The Material Symbols icon named `name`; an unknown name panics instead of drawing
    /// `.notdef`. A convenience over `IconSource::glyph` for callers that want one line.
    /// 名为 `name` 的 Material Symbols 图标；未知名字直接 panic，而不是画 `.notdef`。
    /// 是 `IconSource::glyph` 的便捷形式，让调用方只需一行。
    pub fn new(id: Id, name: &str, size: f32, ink: Color) -> Self {
        Self {
            id,
            source: IconSource::glyph(name, IconSet::Outlined),
            size,
            ink,
        }
    }

    /// The icon at a raw PUA codepoint, for names the generated table does not carry.
    /// 按裸 PUA 码点构造图标，供生成的码点表未收录的名字使用。
    pub fn from_char(id: Id, glyph: char, size: f32, ink: Color) -> Self {
        Self {
            id,
            source: IconSource::from_parts(Family::Named(IconSet::Outlined.family()), glyph),
            size,
            ink,
        }
    }

    /// Builder: Outlined / Rounded / Sharp.
    /// 构造器：Outlined / Rounded / Sharp。
    pub fn set(mut self, set: IconSet) -> Self {
        if let IconSource::Glyph { family, .. } = &mut self.source {
            *family = Family::Named(set.family());
        }
        self
    }

    /// Builder: filled or outlined, per the `FILL` axis; fractional values animate.
    /// 构造器：按 `FILL` 轴设定实心或空心；小数值用于动画。
    pub fn fill(mut self, fill: f32) -> Self {
        self.source = self.source.fill(fill);
        self
    }

    /// Builder: stroke width, per the `wght` axis.
    /// 构造器：按 `wght` 轴设定笔画粗细。
    pub fn weight(mut self, weight: Weight) -> Self {
        self.source = self.source.weight(weight);
        self
    }

    /// Builder: emphasis, per the `GRAD` axis.
    /// 构造器：按 `GRAD` 轴设定强调程度。
    pub fn grade(mut self, grade: f32) -> Self {
        self.source = self.source.grade(grade);
        self
    }

    /// The box is the glyph's em square: the font centres the outline inside it, and a
    /// larger slot centres that box with `stack_align`, never with padding.
    /// 盒子是字形的 em 方盒：字体让轮廓在其中居中，更大的槽位用 `stack_align` 把这个
    /// 盒子居中，绝不用内衬去凑。
    pub fn resolve(&self) -> Decl {
        self.source.resolve_with_size(self.id, self.ink, self.size)
    }
}

/// The PUA codepoint for `name`, from the generated table.
/// `name` 对应的 PUA 码点，取自生成的码点表。
fn lookup(name: &str) -> char {
    match crate::icon_codepoints::ICONS.binary_search_by_key(&name, |(n, _)| *n) {
        Ok(index) => crate::icon_codepoints::ICONS[index].1,
        Err(_) => panic!("unknown Material Symbols icon: {name}"),
    }
}

/// The codepoint for an SF Symbols name, accepting Apple's dotted spelling.
/// SF Symbols 名字对应的码点，接受 Apple 的点分写法。
fn sf_lookup(name: &str) -> char {
    let table = crate::sf_symbol_codepoints::SF_SYMBOLS;
    let found = |n: &str| table.binary_search_by_key(&n, |(k, _)| *k).ok();
    let index = found(name).or_else(|| found(&name.replace('.', "_")));
    match index {
        Some(i) => table[i].1,
        None => panic!("unknown SF Symbols icon: {name}"),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ui_core::NodeData;

    #[test]
    fn a_known_icon_name_maps_to_the_codepoint_the_font_assigns() {
        // The font's own cmap is the authority; a table that drifts from it would draw
        // a different icon under this name without any compile error.
        // 字体自己的 cmap 才是权威；码点表偏离它时，这个名字会画成别的图标，且不会报错。
        assert_eq!(lookup("home"), '\u{e88a}');
        assert_eq!(lookup("add"), '\u{e145}');
        assert_eq!(lookup("close"), '\u{e14c}');
    }

    #[test]
    fn every_name_in_the_generated_table_is_found_by_the_binary_search() {
        // Binary search needs the table sorted; an unsorted or truncated table would still
        // compile and silently stop finding names near the ends.
        // 二分查找要求表有序；未排序或被截断的表照样能编译，却会悄悄找不到靠两端的名字。
        let table = crate::icon_codepoints::ICONS;
        for (name, glyph) in table {
            assert_eq!(lookup(name), *glyph, "{name}");
        }
    }

    #[test]
    fn a_known_sf_symbol_maps_to_the_codepoint_the_font_assigns() {
        // Same authority as the Material table: the vendored font's cmap. A regenerated
        // table that drifts would draw another symbol with no compile error.
        // 与 Material 表同一位权威：随仓库分发的字体 cmap。重新生成时若漂移，
        // 会画成另一个符号且不报错。
        assert_eq!(sf_lookup("house"), '\u{ffc1}');
        assert_eq!(sf_lookup("magnifyingglass"), '\u{fc5e}');
        assert_eq!(sf_lookup("person"), '\u{fa74}');
        assert_eq!(sf_lookup("house.fill"), '\u{ffb6}', "the dotted spelling must land too");
    }

    #[test]
    fn every_name_in_the_sf_table_is_found_by_the_binary_search() {
        // Binary search needs the table sorted; an unsorted table compiles and silently
        // stops finding names near the ends.
        // 二分查找要求表有序；未排序的表照样编译，却会悄悄找不到靠两端的名字。
        for (name, glyph) in crate::sf_symbol_codepoints::SF_SYMBOLS {
            assert_eq!(sf_lookup(name), *glyph, "{name}");
        }
    }

    #[test]
    fn a_custom_family_carries_its_own_codepoint_without_the_ms_table() {
        // The whole point of `IconSource::from_parts`: a glyph font that is not Material
        // Symbols never consults the generated table, so an unlisted codepoint is fine.
        // `IconSource::from_parts` 的全部意义：非 Material Symbols 的字形字体不查生成表，
        // 因此未收录的码点也能用。
        let src = IconSource::from_parts(Family::Named("My Icons"), '\u{e900}');
        assert!(matches!(
            src,
            IconSource::Glyph { glyph: '\u{e900}', fill: 0.0, .. }
        ));
        let decl = src.resolve(Id::str("t"), Color::BLACK);
        // The source is a glyph text run; a container would be a custom mark.
        // 字形源产出的是文本 run；容器则属于自定义标记。
        assert!(matches!(decl.data, NodeData::Text { .. }));
    }

    #[test]
    fn the_space_reserved_for_an_icon_is_the_box_it_declares() {
        // `icon_extent` is what a caller uses to centre an icon in a slot; a 1.4 em text
        // line box would leave the glyph half the difference below the centre.
        // 调用方用 `icon_extent` 在槽位里居中图标；1.4em 的文本行盒会让字形低半个差值。
        let size = 16.0;
        let decl = IconSource::from_parts(Family::Named("Fluent System Icons"), '\u{e900}')
            .resolve_with_size(Id::str("i"), Color::BLACK, size);
        assert_eq!(crate::icon_extent(size), decl.size_class.height.max);
        assert_eq!(decl.size_class.height.min, decl.size_class.height.max, "a fixed em box");
        assert_eq!(decl.size_class.width.min, decl.size_class.width.max, "square, not a line");
    }

    #[test]
    fn a_custom_mark_resolves_through_the_custom_branch() {
        // A `Custom` source ignores the axes and calls its builder — the escape hatch that
        // keeps the slot open to anything the app can paint.
        // `Custom` 源忽略轴、调用自己的构造器——这条逃生门让槽位对应用能画的任何东西开放。
        let src = IconSource::Custom(|id, ink| {
            Decl::container(id, ui_core::NodeKind::Box).shapes(vec![ui_core::draw::Shape::Box {
                corners: ui_core::Corners::all(0.0),
                fill: ink,
                gradient: None,
                border: None,
                shadow: None,
                image: None,
            }])
        });
        let decl = src.fill(1.0).resolve(Id::str("c"), Color::WHITE);
        // A custom mark resolves to whatever its builder produced — here a container.
        // 自定义标记解析成构造器产出的东西——这里是容器。
        assert!(matches!(decl.data, NodeData::Container(_)));
    }
}
