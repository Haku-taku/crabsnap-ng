//! Shaped text end to end: shaping -> glyph ids -> atlas -> pixels.
//! 整形文本端到端：整形 -> 字形 id -> 图集 -> 像素。
//!
//! Shows the difference shaping makes: kerning, ligatures and CJK runs land
//! where a per-character layout could never put them.
//! 展示整形的差别：kerning、连字与中日韩文本落在逐字符排版绝无可能的正确位置。
//!
//! Run: `cargo run -p ui-platform-wayland --example text_shaped --features system-fonts`

use std::io::Write;

use ui_core::draw::{DrawList, GlyphPrim, RectPrim};
use ui_core::geom::{Color, Corners, Rect};
use ui_paint::{CoverageAtlas, CpuRenderer, Pixels};
use ui_text::{FontProvider, FontRequest, GenericFamily, Script};
use ui_text_fontique::glyph::GlyphCache;
use ui_text_fontique::system_or_isolated;
use ui_text_fontique::{place_run, Shaper};

const W: u32 = 720;
const H: u32 = 300;
const SIZE: f32 = 40.0;
const PAD: f32 = 18.0;

fn write_ppm(path: &str, pixels: &Pixels) -> std::io::Result<()> {
    let mut f = std::fs::File::create(path)?;
    write!(f, "P6\n{} {}\n255\n", pixels.width, pixels.height)?;
    let mut rgb = Vec::with_capacity((pixels.width * pixels.height * 3) as usize);
    for px in pixels.as_bytes().as_chunks::<4>().0 {
        rgb.push(px[2]);
        rgb.push(px[1]);
        rgb.push(px[0]);
    }
    f.write_all(&rgb)
}

fn main() {
    let provider = system_or_isolated();
    if !provider.has_system_fonts() {
        eprintln!("no system fonts; build with --features system-fonts");
        return;
    }

    let face = ui_text::FaceId(0);
    let resolved = provider
        .resolve(&FontRequest::new(GenericFamily::SansSerif))
        .expect("a sans-serif face");
    let data = provider.face_data(resolved).expect("font bytes");
    let family = provider.face_family_name(resolved).unwrap_or("?").to_string();

    let mut cache = GlyphCache::new(1024, 1024);
    cache.add_face(face, data.clone());
    let mut shaper = Shaper::new(data, 0).expect("font parses");
    let metrics = cache.face_metrics(face).expect("metrics");

    println!("font: {family}");
    println!(
        "metrics: upem={} ascent={:.3} descent={:.3}",
        metrics.units_per_em, metrics.ascent, metrics.descent
    );

    let owner = ui_core::NodeId::from_raw(0, 0);
    let mut list = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    list.push_rect(
        owner,
        RectPrim {
            rect: Rect::new(0.0, 0.0, W as f32, H as f32),
            radius: Corners::ZERO,
            fill: Color::from_rgba8(24, 26, 30, 255),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );

    let runs = ["AVATAR Wave", "office fjord", "中文字体测试", "Sans 混排 text"];
    let line_height = (metrics.ascent - metrics.descent).max(1.0) * SIZE;
    let mut y = PAD + metrics.ascent * SIZE;
    let mut total_glyphs = 0usize;

    for text in runs {
        let script = Script::dominant(text);
        let run = shaper.shape(text, SIZE, script);
        println!(
            "\n{text:16} glyphs={:2} width={:7.2} script={}",
            run.glyphs.len(),
            run.width,
            script.tag()
        );

        for placed in place_run(&run, PAD, y, ui_text::subpixel::should_subpixel(script)) {
            let Some((slot, _)) =
                cache.glyph_for_id_phased(face, placed.glyph_id, SIZE, placed.bin)
            else {
                continue;
            };
            list.push_glyph(
                owner,
                GlyphPrim {
                    rect: Rect::new(
                        (placed.origin_x + slot.left) as f32,
                        (placed.baseline_y - slot.top) as f32,
                        slot.width as f32,
                        slot.height as f32,
                    ),
                    atlas: Rect::new(
                        slot.x as f32,
                        slot.y as f32,
                        slot.width as f32,
                        slot.height as f32,
                    ),
                    alpha: 1.0,
                    color: Color::from_rgba8(234, 238, 246, 255),
                    kind: ui_core::draw::GlyphKind::Coverage,
                },
            );
            total_glyphs += 1;
        }
        y += line_height;
    }

    let (aw, ah) = cache.dimensions();
    let mut renderer = CpuRenderer::new();
    renderer.set_atlas(CoverageAtlas {
        width: aw,
        height: ah,
        data: cache.atlas().to_vec(),
    });
    let mut target = Pixels::new(W, H);
    renderer.render(&list, &mut target, &ui_core::Damage::Full);

    println!(
        "\nglyphs drawn: {total_glyphs}  cache: {:?}",
        cache.stats
    );
    match write_ppm("text_shaped.ppm", &target) {
        Ok(()) => println!("wrote text_shaped.ppm"),
        Err(e) => eprintln!("write failed: {e}"),
    }
}
