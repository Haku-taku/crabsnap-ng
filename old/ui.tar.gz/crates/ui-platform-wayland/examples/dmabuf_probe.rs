//! Present a GBM-allocated dma-buf through `zwp_linux_dmabuf_v1` and report acceptance.
//! 通过 `zwp_linux_dmabuf_v1` 呈现 GBM 分配的 dma-buf，并报告 compositor 是否接受。
//!
//! Run: `cargo run -p ui-platform-wayland --example dmabuf_probe`

use std::io::Write;
use std::path::{Path, PathBuf};
use std::time::{Duration, Instant};

use ui_core::Damage;
use ui_platform_wayland::dmabuf::{DmaBufFormats, DmaBufImage, FormatSupport, FORMAT_ARGB8888};
use ui_platform_wayland::{WaylandWindow, WindowConfig};

mod gbm {
    use std::ffi::c_void;
    use std::fs::{File, OpenOptions};
    use std::os::fd::{FromRawFd, IntoRawFd, OwnedFd};

    use libloading::Library;

    type DevicePtr = *mut c_void;
    type BoPtr = *mut c_void;

    /// `GBM_BO_USE_RENDERING`, the only flag the probe needs.
    /// `GBM_BO_USE_RENDERING`，探针唯一需要的标志。
    pub const USE_RENDERING: u32 = 1 << 2;

    struct Api {
        /// Declared last so the handle outlives the copied function pointers.
        /// 声明在最后，使句柄比复制出的函数指针活得更久。
        _lib: Library,
        create_device: unsafe extern "C" fn(i32) -> DevicePtr,
        device_destroy: unsafe extern "C" fn(DevicePtr),
        bo_create: unsafe extern "C" fn(DevicePtr, u32, u32, u32, u32) -> BoPtr,
        bo_destroy: unsafe extern "C" fn(BoPtr),
        bo_get_fd: unsafe extern "C" fn(BoPtr) -> i32,
        bo_get_stride: unsafe extern "C" fn(BoPtr) -> u32,
        bo_get_offset: unsafe extern "C" fn(BoPtr, i32) -> u32,
        bo_get_modifier: unsafe extern "C" fn(BoPtr) -> u64,
        bo_get_plane_count: unsafe extern "C" fn(BoPtr) -> i32,
    }

    impl Api {
        fn load() -> Result<Self, String> {
            // SAFETY: every signature below is copied from gbm.h.
            // 安全性：以下每个签名都取自 gbm.h。
            unsafe {
                let lib =
                    Library::new("libgbm.so.1").map_err(|e| format!("dlopen libgbm.so.1: {e}"))?;
                let missing = |e: libloading::Error| format!("libgbm symbol: {e}");
                Ok(Self {
                    create_device: *lib.get(b"gbm_create_device\0").map_err(missing)?,
                    device_destroy: *lib.get(b"gbm_device_destroy\0").map_err(missing)?,
                    bo_create: *lib.get(b"gbm_bo_create\0").map_err(missing)?,
                    bo_destroy: *lib.get(b"gbm_bo_destroy\0").map_err(missing)?,
                    bo_get_fd: *lib.get(b"gbm_bo_get_fd\0").map_err(missing)?,
                    bo_get_stride: *lib.get(b"gbm_bo_get_stride\0").map_err(missing)?,
                    bo_get_offset: *lib.get(b"gbm_bo_get_offset\0").map_err(missing)?,
                    bo_get_modifier: *lib.get(b"gbm_bo_get_modifier\0").map_err(missing)?,
                    bo_get_plane_count: *lib.get(b"gbm_bo_get_plane_count\0").map_err(missing)?,
                    _lib: lib,
                })
            }
        }
    }

    pub struct Device {
        api: Api,
        dev: DevicePtr,
    }

    impl Device {
        pub fn open(path: &str) -> Result<Self, String> {
            let api = Api::load()?;
            let node = OpenOptions::new()
                .read(true)
                .write(true)
                .open(path)
                .map_err(|e| format!("open {path}: {e}"))?;
            // gbm_create_device takes ownership of the opened render node.
            // gbm_create_device 接管已打开的 render 节点。
            let raw = node.into_raw_fd();
            let dev = unsafe { (api.create_device)(raw) };
            if dev.is_null() {
                drop(unsafe { OwnedFd::from_raw_fd(raw) });
                return Err(format!("gbm_create_device({path}) returned null"));
            }
            Ok(Self { api, dev })
        }

        pub fn create_bo(&self, width: u32, height: u32, format: u32) -> Result<Bo<'_>, String> {
            let bo =
                unsafe { (self.api.bo_create)(self.dev, width, height, format, USE_RENDERING) };
            if bo.is_null() {
                return Err(format!("gbm_bo_create({width}x{height}) returned null"));
            }
            Ok(Bo {
                api: &self.api,
                bo,
            })
        }
    }

    impl Drop for Device {
        fn drop(&mut self) {
            unsafe { (self.api.device_destroy)(self.dev) };
        }
    }

    pub struct Bo<'a> {
        api: &'a Api,
        bo: BoPtr,
    }

    impl Bo<'_> {
        pub fn fd(&self) -> Result<OwnedFd, String> {
            let fd = unsafe { (self.api.bo_get_fd)(self.bo) };
            if fd < 0 {
                return Err("gbm_bo_get_fd failed".into());
            }
            Ok(unsafe { OwnedFd::from_raw_fd(fd) })
        }

        pub fn stride(&self) -> u32 {
            unsafe { (self.api.bo_get_stride)(self.bo) }
        }

        pub fn offset(&self) -> u32 {
            unsafe { (self.api.bo_get_offset)(self.bo, 0) }
        }

        pub fn modifier(&self) -> u64 {
            unsafe { (self.api.bo_get_modifier)(self.bo) }
        }

        pub fn plane_count(&self) -> i32 {
            unsafe { (self.api.bo_get_plane_count)(self.bo) }
        }

        /// Fill the whole mapping with one pixel; any layout yields a solid colour.
        /// 用同一个像素填满整个映射；任何布局都得到纯色。
        pub fn fill_solid(&self, pixel: [u8; 4]) -> Result<usize, String> {
            let file = File::from(self.fd()?);
            let mut map = unsafe { memmap2::MmapMut::map_mut(&file) }
                .map_err(|e| format!("mmap dma-buf: {e}"))?;
            for px in map.as_chunks_mut::<4>().0 {
                px.copy_from_slice(&pixel);
            }
            Ok(map.len())
        }
    }

    impl Drop for Bo<'_> {
        fn drop(&mut self) {
            unsafe { (self.api.bo_destroy)(self.bo) };
        }
    }
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    let forced = args.iter().find(|a| a.starts_with('/')).cloned();
    let hold_ms = args
        .iter()
        .find_map(|a| a.strip_prefix("--hold="))
        .and_then(|v| v.parse::<u64>().ok())
        .unwrap_or(1200);

    println!("== crabsnap dmabuf probe ==");
    println!(
        "WAYLAND_DISPLAY={:?} forced_node={forced:?}",
        std::env::var("WAYLAND_DISPLAY").ok()
    );
    flush();

    let mut window = match WaylandWindow::new(WindowConfig {
        title: "crabsnap dmabuf probe".into(),
        app_id: "dev.crabsnap.dmabuf-probe".into(),
        ..WindowConfig::default()
    }) {
        Ok(w) => w,
        Err(e) => fail(&format!("window creation failed: {e}")),
    };
    let Some(version) = window.dmabuf_version() else {
        fail("compositor does not expose zwp_linux_dmabuf_v1");
    };
    println!("zwp_linux_dmabuf_v1 bound at v{version}");

    let (lw, lh) = window.logical_size();
    let scale = window.scale();
    let width = ((lw as f32) * scale).round().max(1.0) as u32;
    let height = ((lh as f32) * scale).round().max(1.0) as u32;
    println!("surface {lw}x{lh} logical at {scale}x -> buffer {width}x{height}");

    let formats = window.dmabuf_formats().clone();
    println!(
        "advertised: {} formats, {} format/modifier pairs",
        formats.format_count(),
        formats.pair_count()
    );
    flush();

    // Control path: the same window and wait loop, but with shm pixels.
    // 对照路径：同一个窗口与等待循环，但走 shm 像素。
    if args.iter().any(|a| a == "--shm") {
        println!("\n-- shm control path --");
        window
            .present_now(&Damage::Full)
            .map_err(|e| e.to_string())
            .unwrap_or_else(|e| fail(&format!("shm present failed: {e}")));
        match wait_frame(&mut window, Duration::from_secs(2)) {
            Ok(()) => println!("PASS control: shm frame callback arrived"),
            Err(e) => println!("FAIL control: {e}"),
        }
        flush();
        hold_window(&mut window, hold_ms);
        std::process::exit(0);
    }

    let nodes = match forced {
        Some(node) => vec![node],
        None => candidate_nodes(),
    };
    if nodes.is_empty() {
        fail("no DRM render node under /dev/dri");
    }

    let mut last_error = String::new();
    for node in &nodes {
        println!("\n-- trying {node} --");
        flush();
        match present_on(&mut window, node, width, height, &formats) {
            Ok(()) => {
                println!("PASS: compositor imported the dma-buf and released the wl_buffer");
                flush();
                hold_window(&mut window, hold_ms);
                std::process::exit(0);
            }
            Err(e) => {
                println!("FAIL on {node}: {e}");
                last_error = format!("{node}: {e}");
                flush();
            }
        }
    }
    fail(&format!("no render node was accepted; last error: {last_error}"));
}

fn present_on(
    window: &mut WaylandWindow,
    node: &str,
    width: u32,
    height: u32,
    formats: &DmaBufFormats,
) -> Result<(), String> {
    let device = gbm::Device::open(node)?;
    // A retained dmabuf may never be released while it stays on screen.
    // 仍在屏幕上的 dma-buf 可能一直不被释放。
    let first = allocate(&device, width, height, formats)?;
    let releases_before = window.dmabuf_releases();
    window
        .present_dmabuf(&first.image, &Damage::Full, None, 1)
        .map_err(|e| e.to_string())?;
    wait_frame(window, Duration::from_secs(2))?;

    // Committing a replacement is what makes the compositor release the first.
    // 提交替代缓冲才会让 compositor 释放前一个。
    let second = allocate(&device, width, height, formats)?;
    window
        .present_dmabuf(&second.image, &Damage::Full, None, 2)
        .map_err(|e| e.to_string())?;
    wait_release(window, releases_before, Duration::from_secs(3))?;
    println!(
        "wl_buffer.release arrived after the replacement commit, inflight={}",
        window.dmabuf_inflight()
    );
    Ok(())
}

/// One GBM bo plus the fd/stride/offset/modifier the protocol layer needs.
/// 一块 GBM bo，以及协议层需要的 fd/stride/offset/modifier。
struct Alloc<'a> {
    /// Kept only so the buffer outlives the `wl_buffer`.
    /// 仅为让缓冲比 `wl_buffer` 活得更久而保留。
    _bo: gbm::Bo<'a>,
    image: DmaBufImage,
}

fn allocate<'a>(
    device: &'a gbm::Device,
    width: u32,
    height: u32,
    formats: &DmaBufFormats,
) -> Result<Alloc<'a>, String> {
    let bo = device.create_bo(width, height, FORMAT_ARGB8888)?;
    let (stride, offset, modifier, planes) =
        (bo.stride(), bo.offset(), bo.modifier(), bo.plane_count());
    println!("gbm: stride={stride} offset={offset} modifier={modifier:#x} planes={planes}");
    if planes != 1 {
        return Err(format!("ARGB8888 is single-plane, gbm reported {planes}"));
    }
    let support = formats.support(FORMAT_ARGB8888, modifier);
    println!("compositor support for ARGB8888 + modifier {modifier:#x}: {support:?}");
    if support == FormatSupport::Unsupported {
        return Err("format/modifier pair was never advertised".into());
    }
    let mapped = bo.fill_solid([0x80, 0x80, 0x00, 0xff])?;
    println!("mapped and filled {mapped} bytes of solid teal");
    let image = DmaBufImage {
        fd: bo.fd()?,
        width,
        height,
        stride,
        offset,
        format: FORMAT_ARGB8888,
        modifier,
    };
    Ok(Alloc { _bo: bo, image })
}

fn wait_frame(window: &mut WaylandWindow, timeout: Duration) -> Result<(), String> {
    let rejections_before = window.dmabuf_rejections();
    let deadline = Instant::now() + timeout;
    while Instant::now() < deadline {
        if let Err(e) = window.pump_checked() {
            return Err(format!("protocol error: {e}"));
        }
        if window.dmabuf_rejections() > rejections_before {
            return Err("compositor sent zwp_linux_buffer_params_v1.failed".into());
        }
        if window.can_draw() {
            return Ok(());
        }
        std::thread::sleep(Duration::from_millis(5));
    }
    Err("timed out waiting for the frame callback".into())
}

fn wait_release(
    window: &mut WaylandWindow,
    releases_before: u32,
    timeout: Duration,
) -> Result<(), String> {
    let rejections_before = window.dmabuf_rejections();
    let deadline = Instant::now() + timeout;
    let mut framed = false;
    while Instant::now() < deadline {
        if let Err(e) = window.pump_checked() {
            return Err(format!("protocol error: {e}"));
        }
        if window.dmabuf_rejections() > rejections_before {
            return Err("compositor sent zwp_linux_buffer_params_v1.failed".into());
        }
        framed |= window.can_draw();
        if framed && window.dmabuf_releases() > releases_before {
            return Ok(());
        }
        std::thread::sleep(Duration::from_millis(5));
    }
    if !framed {
        return Err("timed out waiting for the frame callback".into());
    }
    Err(format!(
        "frame done but no wl_buffer.release (inflight={})",
        window.dmabuf_inflight()
    ))
}

fn hold_window(window: &mut WaylandWindow, millis: u64) {
    println!("holding the window open for {millis} ms (screenshot window)");
    flush();
    let deadline = Instant::now() + Duration::from_millis(millis);
    while Instant::now() < deadline {
        if window.pump_checked().is_err() || window.should_close() {
            return;
        }
        std::thread::sleep(Duration::from_millis(16));
    }
}

/// Render nodes to try, with the GPU driving a connected output first.
/// 要尝试的 render 节点，驱动已连接输出的 GPU 排在最前。
fn candidate_nodes() -> Vec<String> {
    let mut nodes = Vec::new();
    if let Some(node) = output_render_node() {
        nodes.push(node);
    }
    for fallback in ["/dev/dri/renderD129", "/dev/dri/renderD128"] {
        if Path::new(fallback).exists() && !nodes.iter().any(|n| n == fallback) {
            nodes.push(fallback.to_string());
        }
    }
    nodes
}

/// The GPU behind a connected output; that is where the compositor imports from.
/// 已连接输出背后的 GPU，也就是 compositor 导入 dma-buf 的那块。
fn output_render_node() -> Option<String> {
    let mut renders: Vec<(String, PathBuf)> = Vec::new();
    let mut connected: Vec<PathBuf> = Vec::new();
    for entry in std::fs::read_dir("/sys/class/drm").ok()?.flatten() {
        let path = entry.path();
        let Some(name) = path.file_name().and_then(|n| n.to_str()) else {
            continue;
        };
        if let Some(rest) = name.strip_prefix("renderD") {
            if rest.chars().all(|c| c.is_ascii_digit())
                && let Ok(dev) = std::fs::canonicalize(path.join("device")) {
                    renders.push((format!("/dev/dri/{name}"), dev));
                }
        } else if name.starts_with("card") && !name.contains('-') {
            let card_connected = std::fs::read_dir(&path).ok().is_some_and(|connectors| {
                connectors.flatten().any(|connector| {
                    let connector = connector.path();
                    let is_port = connector
                        .file_name()
                        .and_then(|n| n.to_str())
                        .is_some_and(|n| n.contains('-'));
                    is_port
                        && std::fs::read_to_string(connector.join("status"))
                            .is_ok_and(|s| s.trim() == "connected")
                })
            });
            if card_connected
                && let Ok(dev) = std::fs::canonicalize(path.join("device")) {
                    connected.push(dev);
                }
        }
    }
    renders
        .into_iter()
        .find(|(_, dev)| connected.contains(dev))
        .map(|(node, _)| node)
}

fn flush() {
    let _ = std::io::stdout().flush();
}

fn fail(message: &str) -> ! {
    println!("FAIL: {message}");
    flush();
    std::process::exit(1);
}
