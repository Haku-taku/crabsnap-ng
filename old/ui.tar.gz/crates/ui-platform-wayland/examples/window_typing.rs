//! Type into a real window: keyboard events drive a text buffer that re-renders.
//! 在真实窗口里打字：键盘事件驱动文本缓冲并重绘。
//!
//! Run: `cargo run -p ui-platform-wayland --example window_typing`
//! Press Escape or close the window to exit.
//! 按 Escape 或关闭窗口退出。

use std::time::{Duration, Instant};

use ui_core::geom::{Color, Corners, Insets, Rect, Size};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::{BuiltinLayout, Constraints, Damage, Decl, Id, LayoutEngine, NodeData, NodeKind};
use ui_paint::{CoverageAtlas, CpuRenderer};
use ui_platform::present::PresentTarget;
use ui_platform_wayland::{WaylandWindow, WindowConfig};
use ui_text::{FontProvider, FontRequest, GenericFamily};
use ui_text_fontique::glyph::GlyphCache;
use ui_text_fontique::system_or_isolated;

struct Typing {
    text: String,
    caret_on: bool,
}

impl Typing {
    fn view(&self) -> Decl {
        let shown = if self.text.is_empty() {
            "type something...".to_string()
        } else {
            self.text.clone()
        };
        let color = if self.text.is_empty() {
            Color::from_rgba8(120, 126, 138, 255)
        } else {
            Color::from_rgba8(232, 236, 244, 255)
        };

        Decl::container(Id::str("root"), NodeKind::Column)
            .padding(Insets::all(20.0))
            .background(Color::from_rgba8(22, 24, 28, 255), Corners::ZERO)
            .child(
                Decl::container(Id::str("field"), NodeKind::Column)
                    .padding(Insets::all(14.0))
                    .background(Color::from_rgba8(40, 44, 52, 255), Corners::all(10.0))
                    .border(Color::from_rgba8(96, 104, 120, 255), 1.0)
                    .child(Decl {
                        id: Id::str("line"),
                        kind: NodeKind::Text,
                        shapes: Vec::new(),
                        data: NodeData::Text {
                            ink: color,
                            block: ui_core::TextBlock {
                                runs: vec![ui_core::TextRun::new(
                                    shown,
                                    ui_core::TextStyle::new(18.0),
                                )],
                                align: ui_core::TextAlign::Start,
                                max_lines: None,
                                line_gap: 0.0,
                                indent: 0.0,
                                atoms: Vec::new(),
                            },
                            caret: None,
                            selection: None,
                            composing: None,
                            nowrap: false,
                        },
                        size_class: SizeClass {
                            width: AxisSize::hug(0.0, 400.0),
                            height: AxisSize::hug(18.0, 24.0),
                            grow_x: Grow::No,
                            grow_y: Grow::No,
                        },
                        ink_margin: Insets::ZERO,
                        box_model: Default::default(),
                        offset: ui_core::geom::Point::new(0.0, 0.0),
                        cursor: None,
                        sense: ui_core::Sense::NONE,
            disabled: false,
            grid: Default::default(),
            placement: Default::default(),
            env: None,
                        children: Vec::new(),
                    })
                    .child(Decl {
                        id: Id::str("hint"),
                        kind: NodeKind::Text,
                        shapes: Vec::new(),
                        data: NodeData::Text {
                            ink: Color::from_rgba8(140, 146, 160, 255),
                            block: ui_core::TextBlock {
                                runs: vec![ui_core::TextRun::new(
                                    format!(
                                        "{} chars   caret {}   Esc to quit",
                                        self.text.chars().count(),
                                        if self.caret_on { "on" } else { "off" }
                                    ),
                                    ui_core::TextStyle::new(12.0),
                                )],
                                align: ui_core::TextAlign::Start,
                                max_lines: None,
                                line_gap: 0.0,
                                indent: 0.0,
                                atoms: Vec::new(),
                            },
                            caret: None,
                            selection: None,
                            composing: None,
                            nowrap: false,
                        },
                        size_class: SizeClass {
                            width: AxisSize::hug(0.0, 300.0),
                            height: AxisSize::hug(12.0, 16.0),
                            grow_x: Grow::No,
                            grow_y: Grow::No,
                        },
                        ink_margin: Insets::ZERO,
                        box_model: Default::default(),
                        offset: ui_core::geom::Point::new(0.0, 0.0),
                        cursor: None,
                        sense: ui_core::Sense::NONE,
            disabled: false,
            grid: Default::default(),
            placement: Default::default(),
            env: None,
                        children: Vec::new(),
                    }),
            )
    }
}

fn main() {
    let mut win = match WaylandWindow::new(WindowConfig {
        title: "crabsnap-ui   typing".into(),
        app_id: "dev.crabsnap.ui.typing".into(),
        width: 520,
        height: 200,
    }) {
        Ok(w) => w,
        Err(e) => {
            eprintln!("cannot open a Wayland window: {e}");
            std::process::exit(1);
        }
    };
    println!("window ready, logical {:?}", win.logical_size());

    let mut tree = ui_core::Tree::new();
    let mut engine = BuiltinLayout::new(ui_core::MonospaceMeasure::default());
    let mut renderer = CpuRenderer::new();
    let mut app = Typing {
        text: String::new(),
        caret_on: true,
    };

    // A real face for the glyph atlas, when the OS font stack is available.
    // 系统字体栈可用时，为字形图集准备真实字面。
    let face = ui_text::FaceId(0);
    let mut font_cache: Option<GlyphCache> = None;
    {
        let provider = system_or_isolated();
        // Prefer a face that covers RTL scripts so bidi is visible when typing.
        // 优先选择覆盖 RTL 的字面，使输入时能看到 bidi 效果。
        let rtl = provider
            .fallback_chain(ui_text::Script::ARABIC)
            .first()
            .and_then(|f| provider.face_data(*f));
        let latin = provider
            .resolve(&FontRequest::new(GenericFamily::SansSerif))
            .and_then(|f| provider.face_data(f));
        for data in [rtl, latin].into_iter().flatten() {
            let mut cache = GlyphCache::new(1024, 1024);
            if cache.add_face(face, data.clone()) {
                font_cache = Some(cache);
                break;
            }
        }
    }
    let mut last_geometry = (0u32, 0u32);
    let mut last_scale = 0.0f32;
    let mut frames = 0u32;
    let mut dirty = true;
    let mut last_caret = Instant::now();
    let start = Instant::now();
    let mut keymap_seen = false;

    while !win.should_close() && start.elapsed() < Duration::from_secs(60) {
        // Blink the caret so keyboard focus is visibly working.
        // 让光标闪烁，使键盘焦点可见。
        if last_caret.elapsed() >= Duration::from_millis(530) {
            app.caret_on = !app.caret_on;
            last_caret = Instant::now();
            dirty = true;
        }

        let (lw, lh) = win.logical_size();
        let scale = win.scale();
        if (lw, lh) != last_geometry || (scale - last_scale).abs() > 0.001 {
            last_geometry = (lw, lh);
            last_scale = scale;
            dirty = true;
        }

        if !win.has_keymap() {
            win.pump();
            if !win.has_keymap() {
                win.wait();
                continue;
            }
            if !keymap_seen {
                println!("keymap installed: typing now works");
                keymap_seen = true;
            }
            dirty = true;
        }

        // Consume typed characters.
        // 消费输入的字符。
        let typed = win.take_typed();
        if !typed.is_empty() {
            for c in typed {
                app.text.push(c);
            }
            dirty = true;
        }

        if !dirty && !win.redraw_requested() {
            win.wait();
            continue;
        }

        if lw == 0 || lh == 0 {
            win.wait();
            continue;
        }

        let decl = app.view();
        tree.apply(&decl);
        let root = tree.root().expect("root");
        engine.solve(
            &mut tree,
            root,
            Constraints::loose(Size::new(lw as f32, lh as f32)),
        );

        let list = ui_core::draw::list_from_tree(&tree, Rect::new(0.0, 0.0, lw as f32, lh as f32));

        if !win.can_draw() {
            win.wait_for_frame();
        }

        renderer.set_scale(scale);
        if let Some(cache) = font_cache.as_ref() {
            let (aw, ah) = cache.dimensions();
            renderer.set_atlas(CoverageAtlas {
                width: aw,
                height: ah,
                data: cache.atlas().to_vec(),
            });
        }
        let target = win.pixels_mut();
        renderer.render(&list, target, &Damage::Full);
        if let Err(e) = win.present(&Damage::Full) {
            eprintln!("present failed: {e}");
            break;
        }
        frames += 1;
        dirty = false;
        if frames.is_multiple_of(20) {
            println!("frames {frames}, text {:?}", app.text);
        }
        win.pump();
    }

    println!("closed after {frames} frames, final text {:?}", app.text);
}
