//! Probe which HDR buffer formats this compositor and GPU actually accept.
//! 探测本机 compositor 与 GPU 实际接受哪些 HDR 缓冲格式。
//!
//! Run: `cargo run -p ui-platform-wayland --example hdr_probe --features gpu`
//!
//! Three separate questions, reported separately because they fail for different reasons:
//! advertised by the compositor, allocatable by the GPU, and importable as a texture.
//! 三个独立问题分开报告，因为它们的失败原因不同：compositor 是否通告、GPU 能否分配、
//! 能否作为纹理导入。

use std::ffi::CString;

use ui_core::colour::{BufferFormat, TransferFunction};
use ui_paint_gpu::{EglContext, GpuRenderer, GpuTarget};
use ui_platform_wayland::dmabuf::FormatSupport;
use ui_platform_wayland::{WaylandWindow, WindowConfig};

fn main() {
    let mut win = match WaylandWindow::new(WindowConfig {
        title: "hdr probe".into(),
        app_id: "dev.crabsnap.ui.hdrprobe".into(),
        width: 320,
        height: 200,
    }) {
        Ok(w) => w,
        Err(e) => {
            eprintln!("no window: {e}");
            std::process::exit(1);
        }
    };
    // Round-trip so the compositor's format events have arrived.
    // 往返一次，让 compositor 的格式事件到达。
    for _ in 0..8 {
        let _ = win.pump_checked();
    }

    let node = std::env::var("CRABSNAP_DRM_NODE")
        .unwrap_or_else(|_| "/dev/dri/renderD128".to_string());
    let cnode = CString::new(node.clone()).expect("node path");
    let ctx = match EglContext::new(cnode.as_c_str()) {
        Ok(c) => c,
        Err(e) => {
            eprintln!("no GPU context: {e}");
            std::process::exit(1);
        }
    };
    let mut renderer = GpuRenderer::new(ctx.gl(), ctx.is_gles()).expect("renderer");

    println!("GPU: {} ({node})", ctx.renderer());
    println!("dmabuf protocol version: {:?}", win.dmabuf_version());
    println!();

    let mut usable = Vec::new();
    for format in [
        BufferFormat::Bgra8Srgb,
        BufferFormat::Rgb10a2,
        BufferFormat::Rgba16Float,
    ] {
        let fourcc = format.drm_fourcc();
        // Ask about the format with no modifier first; the real pair is checked after
        // allocation, because only the allocator knows which modifier it used.
        // 先问不带 modifier 的格式；真正的组合要等分配之后，因为只有分配器知道用了哪个。
        let advertised = !matches!(
            win.dmabuf_formats().support(fourcc, 0),
            FormatSupport::Unsupported
        );

        let allocated = GpuTarget::new_with_fourcc(&ctx, 64, 64, fourcc);
        let (alloc_ok, detail) = match &allocated {
            Ok(t) => {
                let d = t.desc();
                (true, format!("stride {} modifier {:#x}", d.stride, d.modifier))
            }
            Err(e) => (false, format!("{e}")),
        };

        // The pair check must use the modifier gbm actually returned, not 0.
        // 组合检查必须用 gbm 实际返回的 modifier，而不是 0。
        let pair = match &allocated {
            Ok(t) => {
                let d = t.desc();
                match win.dmabuf_formats().support(fourcc, d.modifier) {
                    FormatSupport::Explicit => "explicit",
                    FormatSupport::ImplicitOnly => "implicit-only",
                    FormatSupport::Unsupported => "UNSUPPORTED",
                }
            }
            Err(_) => "n/a",
        };
        println!(
            "{:?} fourcc {:#010x} bits {}: format={advertised} pair={pair} allocated={alloc_ok} ({detail})",
            format,
            fourcc,
            format.bits_per_channel()
        );

        if let Ok(target) = &allocated {
            // Rendering into it proves the EGLImage import actually works, which the
            // protocol accepting the format does not.
            // 能画进去才证明 EGLImage 导入成功，协议接受格式并不代表这点。
            renderer.clear(ctx.gl(), target, [0.0, 0.0, 0.0, 1.0]);
            let px = renderer.read_pixels(ctx.gl(), target);
            match px {
                Ok(p) => println!("    import + readback: {} bytes", p.len()),
                Err(e) => println!("    import + readback FAILED: {e}"),
            }
            target.release(&ctx);
        }

        // Implicit-only is a real path: the pair is sent as MODIFIER_INVALID.
        // implicit-only 也是合法路径：该组合以 MODIFIER_INVALID 发送。
        if pair != "UNSUPPORTED" && pair != "n/a" && alloc_ok {
            usable.push((format, pair));
        }
    }

    println!();
    if usable.is_empty() {
        println!("no HDR format usable here; SDR only");
    } else {
        println!("usable formats: {usable:?}");
        let hdr = usable.iter().any(|(f, _)| *f != BufferFormat::Bgra8Srgb);
        println!("HDR presentation possible: {hdr}");
        let _ = TransferFunction::Pq;
    }

    renderer.release(ctx.gl());
    win.pump_checked().ok();
}
