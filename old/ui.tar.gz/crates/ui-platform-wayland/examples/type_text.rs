//! Types a string through `zwp_virtual_keyboard_v1`, so an input method can be exercised
//! without a physical keyboard. Use it inside the nested session the app runs in.
//! 经 `zwp_virtual_keyboard_v1` 输入字符串，使输入法在没有物理键盘时也能被驱动。
//! 在应用所在的嵌套会话里使用。
//!
//! `cargo run -p ui-platform-wayland --example type_text -- nihao`

use std::io::Write;
use std::os::unix::io::AsFd;
use std::time::Duration;

use wayland_client::globals::{registry_queue_init, GlobalListContents};
use wayland_client::protocol::{wl_keyboard, wl_registry, wl_seat};
use wayland_client::{Connection, Dispatch, QueueHandle};
use wayland_protocols_misc::zwp_virtual_keyboard_v1::client::{
    zwp_virtual_keyboard_manager_v1::ZwpVirtualKeyboardManagerV1,
    zwp_virtual_keyboard_v1::ZwpVirtualKeyboardV1,
};

struct State {
    seat: Option<wl_seat::WlSeat>,
}

impl Dispatch<wl_registry::WlRegistry, GlobalListContents> for State {
    fn event(
        _: &mut Self,
        _: &wl_registry::WlRegistry,
        _: wl_registry::Event,
        _: &GlobalListContents,
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

impl Dispatch<wl_seat::WlSeat, ()> for State {
    fn event(
        _: &mut Self,
        _: &wl_seat::WlSeat,
        _: wl_seat::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

impl Dispatch<ZwpVirtualKeyboardManagerV1, ()> for State {
    fn event(
        _: &mut Self,
        _: &ZwpVirtualKeyboardManagerV1,
        _: <ZwpVirtualKeyboardManagerV1 as wayland_client::Proxy>::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

impl Dispatch<ZwpVirtualKeyboardV1, ()> for State {
    fn event(
        _: &mut Self,
        _: &ZwpVirtualKeyboardV1,
        _: <ZwpVirtualKeyboardV1 as wayland_client::Proxy>::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

/// Linux input-event-codes for the US layout, which is the keymap sent below.
/// 美式布局的 Linux input-event-codes，与下面发送的键位表一致。
fn evdev(c: char) -> Option<u32> {
    const LETTERS: [u32; 26] = [
        30, 48, 46, 32, 18, 33, 34, 35, 23, 36, 37, 38, 50, 49, 24, 25, 16, 19, 31, 20, 22, 47,
        17, 45, 21, 44,
    ];
    const DIGITS: [u32; 10] = [11, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    Some(match c {
        'a'..='z' => LETTERS[c as usize - 'a' as usize],
        '0'..='9' => DIGITS[c as usize - '0' as usize],
        ' ' => 57,
        '\n' => 28,
        '\t' => 15,
        '\u{8}' => 14,
        _ => return None,
    })
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    // `--trigger` sends Ctrl+Space first, which is fcitx5's default input-method switch.
    // `--trigger` 先发 Ctrl+Space，那是 fcitx5 默认的输入法切换键。
    let trigger = args.iter().any(|a| a == "--trigger");
    let text: String = args
        .iter()
        .filter(|a| *a != "--trigger")
        .cloned()
        .collect::<Vec<_>>()
        .join(" ");
    if text.is_empty() && !trigger {
        eprintln!("usage: type_text [--trigger] <text>   (\\n commits, \\t tabs, \\x08 backspaces)");
        std::process::exit(2);
    }
    if let Err(e) = run(&text, trigger) {
        eprintln!("type_text: {e}");
        std::process::exit(1);
    }
}

fn run(text: &str, trigger: bool) -> Result<(), String> {
    let conn = Connection::connect_to_env().map_err(|e| e.to_string())?;
    let (globals, mut queue) =
        registry_queue_init::<State>(&conn).map_err(|e| e.to_string())?;
    let qh = queue.handle();
    let mut state = State { seat: None };
    let manager: ZwpVirtualKeyboardManagerV1 = globals
        .bind(&qh, 1..=1, ())
        .map_err(|_| "compositor has no zwp_virtual_keyboard_manager_v1".to_string())?;
    let seat: wl_seat::WlSeat = globals
        .bind(&qh, 1..=9, ())
        .map_err(|_| "compositor has no wl_seat".to_string())?;
    state.seat = Some(seat.clone());
    // The registry answers arrive as events; a roundtrip makes the seat usable.
    // registry 的回答以事件到达；一次往返让 seat 可用。
    queue.roundtrip(&mut state).map_err(|e| e.to_string())?;

    let keyboard = manager.create_virtual_keyboard(&seat, &qh, ());

    // A real keymap is mandatory: without one the compositor cannot decode the codes.
    // 必须给出真实键位表：没有它 compositor 无法解释这些键码。
    let ctx = xkbcommon::xkb::Context::new(0);
    let keymap = xkbcommon::xkb::Keymap::new_from_names(
        &ctx,
        "",
        "",
        "us",
        "",
        None,
        xkbcommon::xkb::KEYMAP_COMPILE_NO_FLAGS,
    )
    .ok_or("xkbcommon could not build a us keymap")?;
    let keymap_text = keymap.get_as_string(xkbcommon::xkb::KEYMAP_FORMAT_TEXT_V1);
    let mut file = tempfile::tempfile().map_err(|e| e.to_string())?;
    file.write_all(keymap_text.as_bytes()).map_err(|e| e.to_string())?;
    file.flush().map_err(|e| e.to_string())?;
    keyboard.keymap(
        wl_keyboard::KeymapFormat::XkbV1 as u32,
        file.as_fd(),
        keymap_text.len() as u32,
    );
    // Start from a clean modifier state: a previous client can leave Shift latched, and
    // then every key arrives as its shifted symbol.
    // 从干净的修饰键状态开始：上一个客户端可能留下按住的 Shift，
    // 之后每个键都会以带 Shift 的符号到达。
    keyboard.modifiers(0, 0, 0, 0);

    // One strictly increasing timestamp per event: two events sharing a millisecond can be
    // coalesced, and then the modifier never looks held when the next key arrives.
    // 每个事件一个严格递增的时间戳：同一毫秒的两个事件可能被合并，
    // 下一个按键到来时修饰键就不再是「按住」。
    let clock = std::cell::Cell::new(0u32);
    let time = || {
        let next = clock.get() + 1;
        clock.set(next);
        next
    };
    let tap = |code: u32| {
        keyboard.key(time(), code, wl_keyboard::KeyState::Pressed as u32);
        keyboard.key(time(), code, wl_keyboard::KeyState::Released as u32);
    };
    if trigger {
        // Control_L, Space, then release the modifier: fcitx5 switches input method.
        // Control_L、Space，再松开修饰键：fcitx5 借此切换输入法。
        const CTRL_L: u32 = 29;
        const SPACE: u32 = 57;
        keyboard.key(time(), CTRL_L, wl_keyboard::KeyState::Pressed as u32);
        conn.flush().map_err(|e| e.to_string())?;
        std::thread::sleep(Duration::from_millis(30));
        tap(SPACE);
        conn.flush().map_err(|e| e.to_string())?;
        std::thread::sleep(Duration::from_millis(30));
        keyboard.key(time(), CTRL_L, wl_keyboard::KeyState::Released as u32);
        conn.flush().map_err(|e| e.to_string())?;
        std::thread::sleep(Duration::from_millis(200));
    }
    for c in text.chars() {
        let Some(code) = evdev(c) else {
            return Err(format!("no key for {c:?}"));
        };
        tap(code);
        conn.flush().map_err(|e| e.to_string())?;
        // The input method is a separate process: give it a beat between keys.
        // 输入法是独立进程：按键之间给它一点时间。
        std::thread::sleep(Duration::from_millis(30));
    }
    conn.flush().map_err(|e| e.to_string())?;
    // Let the compositor read the last events before this client disappears.
    // 让 compositor 在这个客户端消失前读完最后的事件。
    std::thread::sleep(Duration::from_millis(100));
    Ok(())
}
