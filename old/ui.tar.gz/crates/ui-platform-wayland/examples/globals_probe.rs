//! List what this compositor offers, and whether colour management is among it.
//! 列出本 compositor 提供了什么，以及色彩管理是否在其中。
//!
//! Run: `cargo run -p ui-platform-wayland --example globals_probe`
//!
//! Binding a protocol needs its generated bindings; asking "does the global exist" does not.
//! 绑定协议需要生成的绑定代码；而问「这个全局对象存在吗」不需要。

use wayland_client::globals::{registry_queue_init, GlobalListContents};
use wayland_client::protocol::wl_registry;
use wayland_client::{Connection, Dispatch, QueueHandle};

/// Minimal state: this probe only wants the registry contents.
/// 最小状态：本探针只关心 registry 的内容。
struct Nothing;

impl Dispatch<wl_registry::WlRegistry, GlobalListContents> for Nothing {
    fn event(
        _: &mut Self,
        _: &wl_registry::WlRegistry,
        _: wl_registry::Event,
        _: &GlobalListContents,
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

fn main() {
    let conn = match Connection::connect_to_env() {
        Ok(c) => c,
        Err(e) => {
            eprintln!("no session: {e}");
            std::process::exit(1);
        }
    };
    let (globals, _queue) = match registry_queue_init::<Nothing>(&conn) {
        Ok(g) => g,
        Err(e) => {
            eprintln!("no registry: {e}");
            std::process::exit(1);
        }
    };

    let mut names: Vec<(String, u32)> = globals
        .contents()
        .clone_list()
        .into_iter()
        .map(|g| (g.interface, g.version))
        .collect();
    names.sort();

    println!("{} globals", names.len());
    for (iface, ver) in &names {
        println!("  {iface} v{ver}");
    }

    // The features this project cares about, by topic rather than by protocol name.
    // 本项目关心的能力，按主题而非协议名归类。
    let topics: &[(&str, &[&str])] = &[
        (
            "colour management",
            &[
                "wp_color_manager_v1",
                "wp_color_representation_manager_v1",
                "hyprland_ctm_control_manager_v1",
            ],
        ),
        (
            "HDR metadata",
            &["wp_hdr_metadata_v1", "wp_color_manager_v1"],
        ),
        (
            "background effect",
            &["ext_background_effect_manager_v1", "org_kde_kwin_blur"],
        ),
        ("text input", &["zwp_text_input_v3", "zwp_text_input_manager_v3"]),
        ("dma-buf", &["zwp_linux_dmabuf_v1"]),
        ("fractional scale", &["wp_fractional_scale_manager_v1"]),
    ];

    println!();
    for (topic, candidates) in topics {
        let found: Vec<&str> = names
            .iter()
            .filter(|(n, _)| candidates.contains(&n.as_str()))
            .map(|(n, _)| n.as_str())
            .collect();
        if found.is_empty() {
            println!("{topic}: NOT available");
        } else {
            println!("{topic}: {found:?}");
        }
    }
}
