//! Open a real Wayland window and run the UI loop against it.
//! 打开真实 Wayland 窗口并在这上面跑 UI 循环。
//!
//! Run: `cargo run -p ui-platform-wayland --example window_live --features ui-platform-wayland/system-fonts`

use std::time::{Duration, Instant};

use ui_core::geom::{Color, Corners, Insets, Rect, Size};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::{BuiltinLayout, Constraints, Damage, Decl, Id, LayoutEngine, NodeData, NodeKind};
use ui_paint::{CoverageAtlas, CpuRenderer};
use ui_platform::present::PresentTarget;
use ui_platform_wayland::{WaylandWindow, WindowConfig};

struct Demo {
    hover: Option<Id>,
}

fn swatch(id: Id, color: Color) -> Decl {
    Decl {
        id,
        kind: NodeKind::Box,
        data: NodeData::Container(ui_core::tree::ContainerParams::default()),
        shapes: vec![ui_core::draw::Shape::Box {
            corners: Corners::all(6.0),
            fill: color,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }],
        size_class: SizeClass {
            width: AxisSize::fill(0.0, 40.0),
            height: AxisSize::fixed(40.0),
            grow_x: Grow::Yes,
            grow_y: Grow::No,
        },
        ink_margin: Insets::ZERO,
        box_model: Default::default(),
        offset: ui_core::geom::Point::new(0.0, 0.0),
        cursor: None,
        sense: ui_core::Sense::NONE,
            disabled: false,
            grid: Default::default(),
            placement: Default::default(),
            env: None,
        children: Vec::new(),
    }
}

impl Demo {
    fn view(&self) -> Decl {
        let hot = self.hover.is_some();
        let card = if hot {
            Color::from_rgba8(54, 58, 68, 255)
        } else {
            Color::from_rgba8(42, 45, 52, 255)
        };
        Decl::container(Id::str("root"), NodeKind::Column)
            .padding(Insets::all(18.0))
            .background(Color::from_rgba8(22, 24, 28, 255), Corners::ZERO)
            .child(
                Decl::container(Id::str("card"), NodeKind::Column)
                    .padding(Insets::all(16.0))
                    .gap(12.0)
                    .background(card, Corners::all(12.0))
                    .border(Color::from_rgba8(96, 102, 116, 255), 1.0)
                    .child(Decl {
                        id: Id::str("title"),
                        kind: NodeKind::Text,
                        shapes: Vec::new(),
                        data: NodeData::Text {
                            ink: Color::from_rgba8(228, 232, 240, 255),
                            block: ui_core::TextBlock {
                                runs: vec![ui_core::TextRun::new(
                                    if hot { "pointer inside" } else { "crabsnap ui" },
                                    ui_core::TextStyle::new(16.0),
                                )],
                                align: ui_core::TextAlign::Start,
                                max_lines: None,
                                line_gap: 0.0,
                                indent: 0.0,
                                atoms: Vec::new(),
                            },
                            caret: None,
                            selection: None,
                            composing: None,
                            nowrap: false,
                        },
                        size_class: SizeClass {
                            width: AxisSize::hug(0.0, 120.0),
                            height: AxisSize::hug(16.0, 20.0),
                            grow_x: Grow::No,
                            grow_y: Grow::No,
                        },
                        ink_margin: Insets::ZERO,
                        box_model: Default::default(),
                        offset: ui_core::geom::Point::new(0.0, 0.0),
                        cursor: None,
                        sense: ui_core::Sense::NONE,
            disabled: false,
            grid: Default::default(),
            placement: Default::default(),
            env: None,
                        children: Vec::new(),
                    })
                    .child(
                        Decl::container(Id::str("row"), NodeKind::Row)
                            .gap(10.0)
                            .child(swatch(Id::str("red"), Color::from_rgba8(216, 74, 74, 255)))
                            .child(swatch(Id::str("green"), Color::from_rgba8(74, 180, 114, 255)))
                            .child(swatch(Id::str("blue"), Color::from_rgba8(76, 132, 216, 255))),
                    ),
            )
    }
}

fn main() {
    let config = WindowConfig {
        title: "crabsnap-ui   live".into(),
        app_id: "dev.crabsnap.ui.live".into(),
        width: 420,
        height: 240,
    };
    let mut win = match WaylandWindow::new(config) {
        Ok(w) => w,
        Err(e) => {
            eprintln!("cannot open a Wayland window: {e}");
            std::process::exit(1);
        }
    };
    println!(
        "window created: logical {:?} scale {:.2} buffer {:?}",
        win.logical_size(),
        win.scale(),
        win.size()
    );

    let mut tree = ui_core::Tree::new();
    let mut engine = BuiltinLayout::new(ui_core::MonospaceMeasure::default());
    let mut renderer = CpuRenderer::new();
    let mut demo = Demo { hover: None };

    let start = Instant::now();
    let mut frames = 0u32;
    // Last geometry/scale we drew at; a change here forces a repaint.
    // 上一次绘制时的几何与缩放；变化即强制重绘。
    let mut last_geometry = (0u32, 0u32);
    let mut last_scale = 0.0f32;
    while !win.should_close() && start.elapsed() < Duration::from_secs(20) {
        // Layout works in logical points; the buffer is larger by the scale.
        // 布局用逻辑 point；缓冲区按缩放放大。
        let (w, h) = win.logical_size();
        let scale = win.scale();
        if w == 0 || h == 0 {
            win.wait();
            continue;
        }

        let pointer = win.pointer();
        let hover = pointer.map(|_| Id::str("card"));
        let hover_changed = hover != demo.hover;
        demo.hover = hover;

        let geometry_changed = (w, h) != last_geometry || (scale - last_scale).abs() > 0.001;
        last_geometry = (w, h);
        last_scale = scale;
        let changed = hover_changed || geometry_changed;

        let decl = demo.view();
        tree.apply(&decl);
        let root = tree.root().expect("root");
        engine.solve(&mut tree, root, Constraints::loose(Size::new(w as f32, h as f32)));

        // Build the draw list in logical units, then scale primitives on emit.
        // 在逻辑单位下构建绘制列表，落地时再缩放图元。
        let list = ui_core::draw::list_from_tree(&tree, Rect::new(0.0, 0.0, w as f32, h as f32));

        // Repaint only when something changed; otherwise block on the compositor.
        // 仅在状态变化时重绘；否则阻塞等待 compositor 事件。
        let damage = if frames == 0 || changed {
            Damage::Full
        } else {
            Damage::None
        };
        if damage.is_none() {
            win.wait();
            // A configure or scale change may have arrived while waiting.
            // 等待期间可能收到 configure 或缩放变化。
            if win.logical_size() != (w, h) || (win.scale() - scale).abs() > 0.001 {
                continue;
            }
            continue;
        }

        // Never draw faster than the compositor consumes frames.
        // 绘制速度不得超过 compositor 消费帧的速度。
        if !win.can_draw() {
            win.wait_for_frame();
        }

        renderer.set_scale(scale);
        let target = win.pixels_mut();
        renderer.render(&list, target, &damage);
        let _ = renderer.stats;
        // Full repaint means full damage: reporting only the diff would leave the
        // compositor showing its cached copy where we repainted without reporting.
        // 整帧重画即全量脏区：只上报差分会让合成器在我们重画过却没上报处显示缓存副本。
        if let Err(e) = win.present(&ui_core::damage::Damage::Full) {
            eprintln!("present failed: {e}");
            break;
        }
        frames += 1;
        // Keep the atlas empty: text uses the placeholder bar in this example.
        // 保持图集为空：本示例文字用占位条。
        renderer.set_atlas(CoverageAtlas {
            width: 1,
            height: 1,
            data: vec![0],
        });
        if frames <= 12 || frames.is_multiple_of(20) {
            println!(
                "frame {frames}: logical {w}x{h} @ {scale:.2}x -> buffer {}x{}, hover {}",
                ((w as f32) * scale).round() as u32,
                ((h as f32) * scale).round() as u32,
                demo.hover.is_some()
            );
        }
        win.pump();
    }
    println!("closed after {frames} frames");
}
