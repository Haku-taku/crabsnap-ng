//! Bidirectional text end to end: bidi itemization -> shaping -> visual order.
//! 双向文本端到端：bidi 分段 -> 整形 -> 视觉顺序。
//!
//! Run: `cargo run -p ui-platform-wayland --example text_bidi --features system-fonts`

use std::io::Write;

use ui_core::draw::{DrawList, GlyphPrim, RectPrim};
use ui_core::geom::{Color, Corners, Rect};
use ui_paint::{CoverageAtlas, CpuRenderer, Pixels};
use ui_text::Direction;
use ui_text_fontique::glyph::GlyphCache;
use ui_text_fontique::{place_run_scaled, Shaper};

const W: u32 = 760;
const H: u32 = 400;
const SIZE: f32 = 34.0;
const PAD: f32 = 20.0;

/// Tahoma covers Arabic and Hebrew on this machine.
/// 本机的 tahoma 覆盖阿拉伯文与希伯来文。
const FONT: &str = "/usr/share/fonts/TTF/tahoma.ttf";

fn write_ppm(path: &str, pixels: &Pixels) -> std::io::Result<()> {
    let mut f = std::fs::File::create(path)?;
    write!(f, "P6\n{} {}\n255\n", pixels.width, pixels.height)?;
    let mut rgb = Vec::with_capacity((pixels.width * pixels.height * 3) as usize);
    for px in pixels.as_bytes().as_chunks::<4>().0 {
        rgb.push(px[2]);
        rgb.push(px[1]);
        rgb.push(px[0]);
    }
    f.write_all(&rgb)
}

fn main() {
    let data: std::sync::Arc<[u8]> = match std::fs::read(FONT) {
        Ok(d) => std::sync::Arc::from(d.into_boxed_slice()),
        Err(e) => {
            eprintln!("cannot read {FONT}: {e}");
            return;
        }
    };

    let face = ui_text::FaceId(0);
    let mut cache = GlyphCache::new(1024, 1024);
    if !cache.add_face(face, data.clone()) {
        eprintln!("font did not parse");
        return;
    }
    let mut shaper = Shaper::new(data, 0).expect("font parses");
    let metrics = cache.face_metrics(face).expect("metrics");

    let owner = ui_core::NodeId::from_raw(0, 0);
    let mut list = DrawList::new(Rect::new(0.0, 0.0, W as f32, H as f32));
    list.push_rect(
        owner,
        RectPrim {
            rect: Rect::new(0.0, 0.0, W as f32, H as f32),
            radius: Corners::ZERO,
            fill: Color::from_rgba8(24, 26, 30, 255),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );

    // Each line shows the base direction in effect.
    // 每行展示当前生效的基方向。
    let lines: [(&str, Option<Direction>); 6] = [
        ("Latin only: hello", Some(Direction::LeftToRight)),
        ("Arabic: مرحبا بالعالم", None),
        ("Hebrew: שלום עולם", None),
        ("Mixed: abc مرحبا xyz", Some(Direction::LeftToRight)),
        ("Mixed RTL base: abc مرحبا xyz", Some(Direction::RightToLeft)),
        ("Mirroring: (abc) vs (مرحبا)", None),
    ];

    let line_height = (metrics.ascent - metrics.descent).max(1.0) * SIZE * 1.25;
    let mut baseline = PAD + metrics.ascent * SIZE;
    let mut total = 0usize;

    for (text, base) in lines {
        let runs = shaper.shape_bidi(text, SIZE, base);
        println!(
            "\n{text:34} base={:?} runs={}",
            base.map(|d| if d.is_rtl() { "RTL" } else { "LTR" }),
            runs.len()
        );

        // Lay out visual runs left to right with one pen; no per-run special case.
        // 用一个笔位从左到右排视觉段；无需逐段特判。
        let mut pen_x = PAD;
        for run in &runs {
            let slice = text.get(run.range.clone()).unwrap_or("");
            println!(
                "  run {:?} rtl={} width={:.1} glyphs={}",
                run.range,
                run.is_rtl(),
                run.width(),
                run.run.glyphs.len()
            );
            let placed = place_run_scaled(&run.run, pen_x, baseline, true, 1.0);
            for blit in cache.blit_run(face, &placed, SIZE, 1.0) {
                list.push_glyph(
                    owner,
                    GlyphPrim {
                        rect: blit.dest,
                        atlas: blit.atlas,
                        alpha: 1.0,
                        color: Color::from_rgba8(234, 238, 246, 255),
                        kind: blit.kind,
                    },
                );
                total += 1;
            }
            let _ = slice;
            pen_x += run.width();
        }
        baseline += line_height;
    }

    let (aw, ah) = cache.dimensions();
    let mut renderer = CpuRenderer::new();
    renderer.set_atlas(CoverageAtlas {
        width: aw,
        height: ah,
        data: cache.atlas().to_vec(),
    });
    let mut target = Pixels::new(W, H);
    renderer.render(&list, &mut target, &ui_core::Damage::Full);

    println!("\nglyphs drawn: {total}");
    match write_ppm("text_bidi.ppm", &target) {
        Ok(()) => println!("wrote text_bidi.ppm"),
        Err(e) => eprintln!("write failed: {e}"),
    }
}
