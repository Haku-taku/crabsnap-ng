//! Draw into a wlr-layer-shell surface: an overlay the compositor places itself.
//! 在 wlr-layer-shell 表面上绘制：一个由 compositor 摆放的浮层。
//!
//! No window manager, no decoration, no taskbar entry: this is the surface a screenshot
//! and annotation tool puts over the screen.
//! 不经窗口管理器、无装饰、不进任务栏：截图与标注工具盖在屏幕上的就是这种表面。
//!
//! Run: `cargo run -p ui-platform-wayland --example layer_overlay --features ui-platform-wayland/system-fonts`

use std::time::{Duration, Instant};

use ui_core::geom::{Color, Corners, Insets};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::{Id, NodeKind};
use ui_platform::element::Element;
use ui_platform::view::{App, AppLoop};
use ui_platform_wayland::{Anchor, Layer, LayerConfig, WaylandWindow, WindowConfig};

/// How long to stay on screen; `LAYER_SECONDS` overrides it.
/// 停留时长；`LAYER_SECONDS` 可覆盖。
fn lifetime() -> f32 {
    std::env::var("LAYER_SECONDS")
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(8.0)
}

fn text(id: Id, body: String, size: f32, ink: Color) -> ui_core::Decl {
    let mut decl = ui_core::Decl::container(id, NodeKind::Text).size(SizeClass {
        width: AxisSize::hug(0.0, 0.0),
        height: AxisSize::hug(size, size * 1.4),
        grow_x: Grow::No,
        grow_y: Grow::No,
    });
    decl.data = ui_core::NodeData::Text {
        block: ui_core::TextBlock::plain(body, ui_core::TextStyle::new(size)),
        ink,
        caret: None,
        selection: None,
        composing: None,
        nowrap: false,
    };
    decl
}

fn swatch(id: Id, fill: Color) -> ui_core::Decl {
    ui_core::Decl::container(id, NodeKind::Box)
        .size(SizeClass::fixed(36.0, 36.0))
        .background(fill, Corners::all(8.0))
}

struct Overlay;

impl App for Overlay {
    fn view(&mut self, cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn Element> {
        let (w, h) = (cx.width() as f32, cx.height() as f32);
        let panel_h = 190.0;
        let top = ((h - panel_h) * 0.5).max(16.0);
        let panel = ui_core::Decl::container(Id::str("overlay/panel"), NodeKind::Column)
            .size(SizeClass::fixed(560.0, panel_h))
            .padding(Insets::all(22.0))
            .gap(12.0)
            .background(Color::from_rgba8(24, 26, 32, 240), Corners::all(16.0))
            .border(Color::from_rgba8(96, 102, 116, 255), 1.0)
            .child(text(
                Id::str("overlay/title"),
                "crabsnap · layer-shell overlay".into(),
                20.0,
                Color::from_rgba8(232, 236, 244, 255),
            ))
            .child(text(
                Id::str("overlay/sub"),
                format!(
                    "overlay layer · anchored to all edges · surface {w:.0}×{h:.0} @ {:.2}x",
                    cx.scale()
                ),
                13.0,
                Color::from_rgba8(150, 158, 172, 255),
            ))
            .child(
                ui_core::Decl::container(Id::str("overlay/row"), NodeKind::Row)
                    .gap(10.0)
                    .child(swatch(Id::str("overlay/red"), Color::from_rgba8(216, 74, 74, 255)))
                    .child(swatch(Id::str("overlay/green"), Color::from_rgba8(74, 180, 114, 255)))
                    .child(swatch(Id::str("overlay/blue"), Color::from_rgba8(76, 132, 216, 255))),
            );
        Box::new(
            ui_platform::Container::new(Id::str("overlay/root"), NodeKind::Column)
                .size(SizeClass {
                    width: AxisSize::fill(0.0, 0.0),
                    height: AxisSize::fill(0.0, 0.0),
                    grow_x: Grow::Yes,
                    grow_y: Grow::Yes,
                })
                .padding(Insets {
                    top,
                    right: 0.0,
                    bottom: 0.0,
                    left: 0.0,
                })
                .cross_align(0.0)
                // `cross_align` is how much spare cross space the child takes; where the
                // leftover goes is `cross_pos`. Both are the parent's parameters.
                // `cross_align` 是子节点占用的交叉剩余空间比例；剩下的往哪放是 `cross_pos`。
                // 两者都是父容器的参数。
                .cross_pos(0.5)
                // A scrim proves the surface really covers the output; the panel proves
                // text, shapes and the engine's layout all work on this role.
                // 遮罩证明表面确实覆盖了整个输出；面板证明文本、形状与布局在这个角色上都成立。
                .background(Color::from_rgba8(8, 10, 14, 150), Corners::ZERO)
                .child_decl(panel),
        )
    }
}

fn main() {
    let config = WindowConfig {
        title: "crabsnap layer overlay".into(),
        app_id: "dev.crabsnap.ui.overlay".into(),
        width: 640,
        height: 320,
    };
    let layer = LayerConfig {
        layer: Layer::Overlay,
        anchor: Anchor::ALL,
        size: None,
        exclusive_zone: -1,
        keyboard: false,
        namespace: "crabsnap-overlay".into(),
    };
    let mut win = match WaylandWindow::new_layer(config, layer) {
        Ok(w) => w,
        Err(e) => {
            eprintln!("cannot open a layer surface: {e}");
            std::process::exit(1);
        }
    };
    println!(
        "layer surface created: logical {:?} scale {:.2}",
        win.logical_size(),
        win.scale()
    );

    let mut lp = AppLoop::with_stack(Overlay, &[]);
    let start = Instant::now();
    let mut frames = 0u32;
    while !win.should_close() && start.elapsed().as_secs_f32() < lifetime() {
        for ev in win.take_events() {
            lp.dispatch(ev);
        }
        lp.set_scale(win.scale());
        let pointer = win.pointer();
        let outcome = lp.frame(&mut win, pointer);
        frames += 1;
        if frames == 1 {
            println!(
                "first frame: {} nodes, damage {:?}",
                outcome.nodes, outcome.damage
            );
        }
        // Static after the first frame: one commit, then idle until the deadline.
        // 首帧之后静止：提交一次，然后空转到截止时间。
        std::thread::sleep(Duration::from_millis(16));
    }
    println!("closed after {frames} frames");
}
