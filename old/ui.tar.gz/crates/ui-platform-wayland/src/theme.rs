//! System light/dark preference on Wayland, read from the XDG desktop portal.
//! Wayland 上的系统明/暗偏好，取自 XDG 桌面门户。
//!
//! `org.freedesktop.appearance color-scheme` is the cross-DE standard (0 no preference,
//! 1 prefer dark, 2 prefer light). A background thread polls it; no long-lived child process.
//! `org.freedesktop.appearance color-scheme` 是跨桌面标准（0 无偏好，1 偏深，2 偏浅）。
//! 后台线程轮询它；不留长期子进程。

use std::process::Command;
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::Duration;

use ui_platform::theme::{ThemePreference, ThemeWatcher};

/// How often the background thread re-reads the portal.
/// 后台线程重读门户的间隔。
const POLL: Duration = Duration::from_millis(1000);

/// A watcher backed by the XDG portal's `color-scheme`, falling back to GNOME gsettings.
/// 基于 XDG 门户 `color-scheme` 的监视器，回退到 GNOME gsettings。
pub struct PortalThemeWatcher {
    shared: Arc<Mutex<ThemePreference>>,
    last: ThemePreference,
}

impl PortalThemeWatcher {
    /// Read the current value and start a background thread that follows changes.
    /// 读取当前值，并起一个后台线程跟踪变化。
    pub fn new() -> Self {
        let initial = read_current().unwrap_or(ThemePreference::NoPreference);
        let shared = Arc::new(Mutex::new(initial));
        let sink = Arc::clone(&shared);
        let _ = thread::Builder::new()
            .name("xdg-appearance".into())
            .spawn(move || watch_loop(sink));
        Self { shared, last: initial }
    }
}

impl Default for PortalThemeWatcher {
    fn default() -> Self {
        Self::new()
    }
}

impl ThemeWatcher for PortalThemeWatcher {
    fn preference(&self) -> ThemePreference {
        *self.shared.lock().unwrap_or_else(|e| e.into_inner())
    }

    fn poll(&mut self) -> Option<ThemePreference> {
        let now = self.preference();
        if now != self.last {
            self.last = now;
            Some(now)
        } else {
            None
        }
    }
}

/// Parse a portal reply: `<uint32 N>` -> preference.
/// 解析门户回复里的 `<uint32 N>` —— 得到偏好。
pub fn parse_portal_colorscheme(text: &str) -> Option<ThemePreference> {
    let at = text.find("uint32")?;
    let digits: String = text[at + 6..]
        .trim_start()
        .chars()
        .take_while(|c| c.is_ascii_digit())
        .collect();
    let n: u32 = digits.parse().ok()?;
    Some(match n {
        1 => ThemePreference::PreferDark,
        2 => ThemePreference::PreferLight,
        _ => ThemePreference::NoPreference,
    })
}

/// Parse `gsettings get org.gnome.desktop.interface color-scheme`.
/// 解析 `gsettings get org.gnome.desktop.interface color-scheme`。
pub fn parse_gsettings_colorscheme(text: &str) -> ThemePreference {
    if text.contains("prefer-dark") {
        ThemePreference::PreferDark
    } else if text.contains("prefer-light") {
        ThemePreference::PreferLight
    } else {
        ThemePreference::NoPreference
    }
}

fn read_current() -> Option<ThemePreference> {
    read_portal().or_else(read_gsettings)
}

fn read_portal() -> Option<ThemePreference> {
    let out = Command::new("gdbus")
        .args([
            "call",
            "--session",
            "--dest",
            "org.freedesktop.portal.Desktop",
            "--object-path",
            "/org/freedesktop/portal/desktop",
            "--method",
            "org.freedesktop.portal.Settings.ReadOne",
            "org.freedesktop.appearance",
            "color-scheme",
        ])
        .output()
        .ok()?;
    if !out.status.success() {
        return None;
    }
    parse_portal_colorscheme(&String::from_utf8_lossy(&out.stdout))
}

fn read_gsettings() -> Option<ThemePreference> {
    let out = Command::new("gsettings")
        .args(["get", "org.gnome.desktop.interface", "color-scheme"])
        .output()
        .ok()?;
    if !out.status.success() {
        return None;
    }
    let text = String::from_utf8_lossy(&out.stdout);
    Some(parse_gsettings_colorscheme(&text))
}

fn watch_loop(shared: Arc<Mutex<ThemePreference>>) {
    loop {
        thread::sleep(POLL);
        if let Some(pref) = read_current() {
            let mut guard = shared.lock().unwrap_or_else(|e| e.into_inner());
            if *guard != pref {
                *guard = pref;
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_portal_reply_maps_the_three_codes() {
        assert_eq!(parse_portal_colorscheme("(<uint32 1>,)"), Some(ThemePreference::PreferDark));
        assert_eq!(parse_portal_colorscheme("(<uint32 2>,)"), Some(ThemePreference::PreferLight));
        assert_eq!(parse_portal_colorscheme("(<uint32 0>,)"), Some(ThemePreference::NoPreference));
        assert_eq!(parse_portal_colorscheme("no number here"), None);
    }

    #[test]
    fn gsettings_text_maps_dark_light_and_default() {
        assert_eq!(parse_gsettings_colorscheme("'prefer-dark'\n"), ThemePreference::PreferDark);
        assert_eq!(parse_gsettings_colorscheme("'prefer-light'\n"), ThemePreference::PreferLight);
        assert_eq!(parse_gsettings_colorscheme("'default'\n"), ThemePreference::NoPreference);
    }
}
