//! `KeyChord` to-and-from the portal's `preferred_trigger` string, with no D-Bus involved.
//! `KeyChord` 与门户 `preferred_trigger` 字符串之间的互转，不涉及 D-Bus。
//!
//! Grammar is the freedesktop Shortcuts spec: `CTRL`/`ALT`/`SHIFT`/`NUM`/`LOGO` joined by `+`,
//! then a keysym name from `xkbcommon-keysyms.h` minus the `XKB_KEY_` prefix.
//! 文法来自 freedesktop Shortcuts 规范：`CTRL`/`ALT`/`SHIFT`/`NUM`/`LOGO` 以 `+` 连接，
//! 再接一个取自 `xkbcommon-keysyms.h`（去掉 `XKB_KEY_` 前缀）的 keysym 名。

use ui_core::event::{Key, Modifiers};
use ui_core::shortcut::KeyChord;

/// Modifier token for the control key.
/// 控制键的修饰 token。
const CTRL: &str = "CTRL";
/// Modifier token for the alt key.
/// alt 键的修饰 token。
const ALT: &str = "ALT";
/// Modifier token for the shift key.
/// shift 键的修饰 token。
const SHIFT: &str = "SHIFT";
/// Modifier token for the super/meta key.
/// super/meta 键的修饰 token。
const LOGO: &str = "LOGO";

/// The keysym name for a named (non-character) key, from `xkbcommon-keysyms.h`, or `None`
/// when this engine has no spelling for it. Characters go through [`char_keysym`].
/// 命名（非字符）键的 keysym 名，取自 `xkbcommon-keysyms.h`；本引擎叫不出名时 `None`。
/// 字符键走 [`char_keysym`]。
fn named_keysym(key: Key) -> Option<&'static str> {
    Some(match key {
        Key::Escape => "Escape",
        Key::Enter => "Return",
        Key::Space => "space",
        Key::Tab => "Tab",
        Key::Backspace => "BackSpace",
        Key::Delete => "Delete",
        Key::Home => "Home",
        Key::End => "End",
        Key::Left => "Left",
        Key::Right => "Right",
        Key::Up => "Up",
        Key::Down => "Down",
        Key::Char(_) => return None,
    })
}

/// Keysym name for a character: ASCII letters lowercase (unshifted, as `shortcut.rs` stores
/// them), digits themselves, punctuation by its spec name. Unmapped characters give `None`.
/// 字符的 keysym 名：ASCII 字母取小写（未加 Shift，与 `shortcut.rs` 一致），数字即其本身，
/// 标点取规范名。未覆盖的字符返回 `None`。
fn char_keysym(c: char) -> Option<&'static str> {
    if c.is_ascii_alphabetic() {
        return Some(LETTER_NAMES[(c.to_ascii_lowercase() as u8 - b'a') as usize]);
    }
    if c.is_ascii_digit() {
        return Some(DIGIT_NAMES[(c as u8 - b'0') as usize]);
    }
    Some(match c {
        ' ' => "space",
        '!' => "exclam",
        '"' => "quotedbl",
        '#' => "numbersign",
        '$' => "dollar",
        '%' => "percent",
        '&' => "ampersand",
        '\'' => "apostrophe",
        '(' => "parenleft",
        ')' => "parenright",
        '*' => "asterisk",
        '+' => "plus",
        ',' => "comma",
        '-' => "minus",
        '.' => "period",
        '/' => "slash",
        ':' => "colon",
        ';' => "semicolon",
        '<' => "less",
        '=' => "equal",
        '>' => "greater",
        '?' => "question",
        '@' => "at",
        '[' => "bracketleft",
        '\\' => "backslash",
        ']' => "bracketright",
        '^' => "asciicircum",
        '_' => "underscore",
        '`' => "grave",
        '{' => "braceleft",
        '|' => "bar",
        '}' => "braceright",
        '~' => "asciitilde",
        _ => return None,
    })
}

/// Lowercase letters, indexed `a..z`; each keysym name is the letter itself.
/// 小写字母，按 `a..z` 索引；每个 keysym 名即字母本身。
const LETTER_NAMES: [&str; 26] = [
    "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r",
    "s", "t", "u", "v", "w", "x", "y", "z",
];

/// Digits, indexed `0..9`; each keysym name is the digit itself (`XKB_KEY_0` .. `XKB_KEY_9`).
/// 数字，按 `0..9` 索引；每个 keysym 名即数字本身（`XKB_KEY_0` .. `XKB_KEY_9`）。
const DIGIT_NAMES: [&str; 10] = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"];

/// The keysym name for a chord's key, `None` if none is known.
/// 组合键主键的 keysym 名；无名时 `None`。
fn key_keysym(key: Key) -> Option<&'static str> {
    match key {
        Key::Char(c) => char_keysym(c),
        other => named_keysym(other),
    }
}

/// Encode a chord as a portal `preferred_trigger`, or `None` if the key has no known name.
/// 把组合键编码为门户 `preferred_trigger`；主键无名时 `None`。
///
/// Locks (`Num`/`Caps`) are never emitted, matching the engine's exact-match rule; `Shift`
/// stays because it selects a different chord, not a lock state.
/// 锁键（`NUM`/`Caps`）从不发出，与引擎的精确匹配一致；`Shift` 保留，因为它区分的是组合键
/// 而非锁定态。
pub fn chord_to_trigger(chord: KeyChord) -> Option<String> {
    let key = key_keysym(chord.key)?;
    // Order fixed by the spec's `CTRL, ALT, SHIFT, NUM, LOGO` enumeration, so output is stable.
    // 顺序按规范 `CTRL, ALT, SHIFT, NUM, LOGO` 固定，保证输出稳定。
    let mut parts: Vec<&str> = Vec::with_capacity(5);
    if chord.mods.ctrl {
        parts.push(CTRL);
    }
    if chord.mods.alt {
        parts.push(ALT);
    }
    if chord.mods.shift {
        parts.push(SHIFT);
    }
    if chord.mods.logo {
        parts.push(LOGO);
    }
    parts.push(key);
    Some(parts.join("+"))
}

/// Reverse of [`chord_to_trigger`]: parse a `preferred_trigger` back into a chord.
/// [`chord_to_trigger`] 的逆：把 `preferred_trigger` 解析回组合键。
///
/// `None` for any token outside the recognized vocabulary, so a trigger the portal chose that
/// this engine cannot name never fabricates a bogus chord.
/// 词表外的 token 一律 `None`，于是门户挑出的、本引擎叫不出名的触发键不会被拼成假组合键。
pub fn trigger_to_chord(trigger: &str) -> Option<KeyChord> {
    let mut tokens = trigger.split('+').peekable();
    let mut mods = Modifiers::default();
    let mut key: Option<Key> = None;
    while let Some(tok) = tokens.next() {
        match tok {
            CTRL => mods.ctrl = true,
            ALT => mods.alt = true,
            SHIFT => mods.shift = true,
            LOGO => mods.logo = true,
            // The key is the last token; a name here that we can't resolve rejects the whole
            // string, so a modifier never stands alone as the trigger.
            // 主键是末位 token；此处解析不出就否掉整串，修饰键不会单独成为触发键。
            _ if tokens.peek().is_none() => key = Some(keysym_to_key(tok)?),
            _ => return None,
        }
    }
    Some(KeyChord::new(key?, mods))
}

/// A keysym name back to a `Key`, the inverse of [`key_keysym`] over the mapped set.
/// 把 keysym 名还原为 `Key`，即 [`key_keysym`] 在已映射集合上的逆。
fn keysym_to_key(name: &str) -> Option<Key> {
    match name {
        "Escape" => return Some(Key::Escape),
        "Return" => return Some(Key::Enter),
        "space" => return Some(Key::Space),
        "Tab" => return Some(Key::Tab),
        "BackSpace" => return Some(Key::Backspace),
        "Delete" => return Some(Key::Delete),
        "Home" => return Some(Key::Home),
        "End" => return Some(Key::End),
        "Left" => return Some(Key::Left),
        "Right" => return Some(Key::Right),
        "Up" => return Some(Key::Up),
        "Down" => return Some(Key::Down),
        _ => {}
    }
    // A single lowercase letter or digit is its own character; otherwise punctuation.
    // 单个小写字母或数字即其字符；其余按标点查表。
    let bytes = name.as_bytes();
    if bytes.len() == 1 {
        let b = bytes[0];
        if b.is_ascii_lowercase() || b.is_ascii_digit() {
            return Some(Key::Char(b as char));
        }
    }
    let c = match name {
        "exclam" => '!',
        "quotedbl" => '"',
        "numbersign" => '#',
        "dollar" => '$',
        "percent" => '%',
        "ampersand" => '&',
        "apostrophe" => '\'',
        "parenleft" => '(',
        "parenright" => ')',
        "asterisk" => '*',
        "plus" => '+',
        "comma" => ',',
        "minus" => '-',
        "period" => '.',
        "slash" => '/',
        "colon" => ':',
        "semicolon" => ';',
        "less" => '<',
        "equal" => '=',
        "greater" => '>',
        "question" => '?',
        "at" => '@',
        "bracketleft" => '[',
        "backslash" => '\\',
        "bracketright" => ']',
        "asciicircum" => '^',
        "underscore" => '_',
        "grave" => '`',
        "braceleft" => '{',
        "bar" => '|',
        "braceright" => '}',
        "asciitilde" => '~',
        _ => return None,
    };
    Some(Key::Char(c))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn chord(key: Key, ctrl: bool, alt: bool, shift: bool, logo: bool) -> KeyChord {
        KeyChord::new(
            key,
            Modifiers {
                ctrl,
                alt,
                shift,
                logo,
            },
        )
    }

    #[test]
    fn a_chord_encodes_to_portal_trigger_string() {
        // Ctrl+Shift+K: spec modifier order, key as the lowercase keysym name.
        // Ctrl+Shift+K：规范里的修饰键顺序，主键用小写 keysym 名。
        assert_eq!(
            chord_to_trigger(chord(Key::Char('k'), true, false, true, false)).as_deref(),
            Some("CTRL+SHIFT+k")
        );
        // Ctrl+1 is a digit key whose keysym name is the digit itself.
        // Ctrl+1 的主键是数字，keysym 名即数字本身。
        assert_eq!(
            chord_to_trigger(chord(Key::Char('1'), true, false, false, false)).as_deref(),
            Some("CTRL+1")
        );
        // Alt+Slash: the symbol key is `slash`, not the `/` character.
        // Alt+斜杠：符号键名是 `slash`，不是 `/` 字符。
        assert_eq!(
            chord_to_trigger(chord(Key::Char('/'), false, true, false, false)).as_deref(),
            Some("ALT+slash")
        );
        // Meta+Enter: `LOGO` for the super key, `Return` for the enter keysym name.
        // Meta+Enter：super 键用 `LOGO`，回车 keysym 名是 `Return`。
        assert_eq!(
            chord_to_trigger(chord(Key::Enter, false, false, false, true)).as_deref(),
            Some("LOGO+Return")
        );
    }

    #[test]
    fn a_shift_only_letter_keeps_the_lowercase_key_and_shift_token() {
        // `shortcut.rs` stores letters unshifted, so Shift+A spells the `a` keysym + SHIFT.
        // `shortcut.rs` 把字母按未加 Shift 存放，故 Shift+A 拼成 `a` keysym 加 SHIFT。
        assert_eq!(
            chord_to_trigger(chord(Key::Char('a'), false, false, true, false)).as_deref(),
            Some("SHIFT+a")
        );
    }

    #[test]
    fn a_chord_with_no_portal_spelling_is_rejected_not_guessed() {
        // No `Key` variant exists for a compose/insert-style key, so a Char outside the
        // ASCII table (e.g. a non-ASCII glyph) has no keysym name and must not be sent.
        // 组合/插入类键没有对应 `Key` 变体，故 ASCII 表外的 Char（如非 ASCII 字形）
        // 没有 keysym 名，绝不能臆测后发出。
        assert_eq!(chord_to_trigger(chord(Key::Char('é'), true, false, false, false)), None);
    }

    #[test]
    fn decoding_a_trigger_returns_the_chord_that_encoded_to_it() {
        // Round-trip is the invariant the registry relies on: what we bind is what Activated
        // would name, and the decode must land back on the exact chord.
        // 往返是注册表依赖的不变量：我们绑定的键名，Activated 会用它回报，解码须回到原组合。
        let cases = [
            chord(Key::Char('k'), true, false, true, false),
            chord(Key::Char('/'), false, true, false, false),
            chord(Key::Enter, false, false, false, true),
            chord(Key::Up, true, false, false, false),
            chord(Key::Char('a'), false, false, false, false),
        ];
        for c in cases {
            let t = chord_to_trigger(c).expect("encodable");
            assert_eq!(trigger_to_chord(&t), Some(c), "round-trip of {t}");
        }
    }

    #[test]
    fn decoding_an_unknown_modifier_or_key_fails_cleanly() {
        // `NUM` is a spec modifier this engine never emits (lock masked out); an unknown name
        // must reject the string rather than silently drop the token.
        // `NUM` 是本引擎从不发出的规范修饰键（锁键已掩掉）；未知名必须否掉整串而非
        // 悄悄丢弃 token。
        assert_eq!(trigger_to_chord("NUM+k"), None);
        assert_eq!(trigger_to_chord("CTRL+F13"), None);
        assert_eq!(trigger_to_chord(""), None);
        assert_eq!(trigger_to_chord("CTRL+"), None);
    }

    #[test]
    fn breaking_the_modifier_order_flips_the_encoded_string() {
        // Guards the token order against accidental reordering: CTRL must lead SHIFT.
        // 防止 token 顺序被无意调换：CTRL 必须排在 SHIFT 之前。
        assert_eq!(
            chord_to_trigger(chord(Key::Char('a'), true, true, true, true)).as_deref(),
            Some("CTRL+ALT+SHIFT+LOGO+a")
        );
    }
}

