//! Global hotkeys over the XDG desktop portal's `GlobalShortcuts`.
//! 经由 XDG 桌面门户 `GlobalShortcuts` 实现的系统级热键。
//!
//! Transport only; the `KeyChord` <-> `preferred_trigger` encoding lives in [`codec`].
//! 只负责传输；`KeyChord` <-> `preferred_trigger` 的编码在 [`codec`]。

mod codec;

use std::collections::HashMap;
use std::sync::atomic::{AtomicU32, Ordering};
use std::sync::{Arc, Mutex};
use std::thread;

use ui_core::shortcut::{KeyChord, ShortcutId};
use ui_platform::hotkeys::{GlobalHotkeyError, GlobalHotkeys};
use zbus::zvariant::{OwnedObjectPath, OwnedValue, Value};

pub use codec::{chord_to_trigger, trigger_to_chord};

/// Bus name owning every portal object.
/// 拥有所有门户对象的总线名。
const DESKTOP_DEST: &str = "org.freedesktop.portal.Desktop";
/// Object path of the portal's desktop root.
/// 门户桌面根对象的路径。
const DESKTOP_PATH: &str = "/org/freedesktop/portal/desktop";
/// Interface for global shortcut binding.
/// 全局快捷键绑定接口。
const GS_IFACE: &str = "org.freedesktop.portal.GlobalShortcuts";
/// Interface for a portal request's completion.
/// 门户请求完成的接口。
const REQUEST_IFACE: &str = "org.freedesktop.portal.Request";
/// Interface for a portal session, used to close it.
/// 门户会话接口，用于关闭会话。
const SESSION_IFACE: &str = "org.freedesktop.portal.Session";
/// Portal version that first defines the methods we use.
/// 首次定义我们用到的方法的门户版本。
const MIN_VERSION: u32 = 1;

/// The shared mailbox between the D-Bus reader thread and the frame's `poll`.
/// D-Bus 读取线程与每帧 `poll` 之间的共享信箱。
#[derive(Default)]
struct Shared {
    /// Bound shortcut id strings mapped back to the ids the app registered with.
    /// 已绑定的 shortcut id 字符串，映射回应用注册时用的 id。
    lookup: HashMap<String, ShortcutId>,
    /// Session paths we own; an `Activated` naming another is not ours.
    /// 我方拥有的会话路径；指向别处的 `Activated` 不属于我们。
    sessions: Vec<String>,
    /// Activations queued by the reader thread, drained by `poll`.
    /// 读取线程排入的激活事件，由 `poll` 取空。
    activated: Vec<ShortcutId>,
}

/// Global hotkeys backed by `org.freedesktop.portal.GlobalShortcuts`.
/// 由 `org.freedesktop.portal.GlobalShortcuts` 支撑的全局热键。
///
/// A background thread owns the D-Bus `Activated` signal stream, matching the polling thread in
/// `theme.rs`; `poll` reads what that thread queued and never blocks.
/// 后台线程持有 D-Bus `Activated` 信号流，与 `theme.rs` 的轮询线程同构；`poll` 读取该线程
/// 排入的内容，绝不阻塞。
pub struct PortalHotkeys {
    /// Blocking D-Bus connection, cloned into the reader thread.
    /// 同步 D-Bus 连接，克隆一份交给读取线程。
    conn: zbus::blocking::Connection,
    /// Mailbox shared with the reader thread; see [`Shared`].
    /// 与读取线程共享的信箱；见 [`Shared`]。
    shared: Arc<Mutex<Shared>>,
    /// Counter making each request's handle path unique.
    /// 使每个请求的 handle 路径唯一的计数器。
    token: AtomicU32,
}

impl PortalHotkeys {
    /// Read the portal version and start the `Activated` reader thread; sessions come later,
    /// one per bind. `Unsupported` if the portal is absent or too old, `Failed` on D-Bus error.
    /// 读取门户版本并启动 `Activated` 读取线程；会话留到之后每次绑定各开一个。门户缺失或
    /// 版本过旧返回 `Unsupported`，D-Bus 错误返回 `Failed`。
    pub fn new() -> Result<Self, GlobalHotkeyError> {
        let conn = zbus::blocking::Connection::session().map_err(bus_error)?;
        Self::open(conn)
    }

    /// Open against an explicit bus address, for a non-default bus or a headless test of the
    /// no-portal path; an unreachable address yields `Failed` or `Unsupported` without blocking.
    /// 按给定总线地址开启，用于非默认总线或无头环境下测「无门户」路径；地址不可达时返回
    /// `Failed` 或 `Unsupported`，不阻塞。
    pub fn with_address(address: &str) -> Result<Self, GlobalHotkeyError> {
        let conn = zbus::blocking::connection::Builder::address(address)
            .map_err(bus_error)?
            .build()
            .map_err(bus_error)?;
        Self::open(conn)
    }

    fn open(conn: zbus::blocking::Connection) -> Result<Self, GlobalHotkeyError> {
        let version: u32 = portal_proxy(&conn)?
            .get_property("version")
            .map_err(bus_error)?;
        if version < MIN_VERSION {
            return Err(GlobalHotkeyError::Unsupported);
        }
        let shared = Arc::new(Mutex::new(Shared::default()));
        spawn_reader(&conn, Arc::clone(&shared));
        Ok(Self {
            conn,
            shared,
            token: AtomicU32::new(0),
        })
    }

    /// A path-safe token unique to this process, appended to the request handle path.
    /// 本进程内唯一、路径安全的 token，附加在请求 handle 路径末尾。
    fn next_token(&self) -> String {
        let n = self.token.fetch_add(1, Ordering::Relaxed);
        format!("ui-{n}")
    }

    /// Close every session we opened, releasing the bindings they hold. Best-effort: an error is
    /// swallowed because there is nothing the caller can still do at teardown.
    /// 关闭我们开过的每个会话，释放其名下绑定。尽力而为：错误被吞掉，因为拆除阶段调用方
    /// 已无能为力。
    pub fn close(&self) {
        let sessions = self
            .shared
            .lock()
            .map(|g| g.sessions.clone())
            .unwrap_or_default();
        for session in sessions {
            if let Ok(proxy) =
                zbus::blocking::Proxy::new(&self.conn, DESKTOP_DEST, session.as_str(), SESSION_IFACE)
            {
                let _ = proxy.call_noreply("Close", &());
            }
        }
    }
}

impl GlobalHotkeys for PortalHotkeys {
    /// Bind `chord` to `id`. The portal shows its confirmation dialog and this call waits on it:
    /// a dismissed dialog is `Refused`; anything the bus rejects is `Failed`/`Unsupported`.
    /// 把 `chord` 绑到 `id`。门户弹出确认对话框，本调用等待它：对话框被关回 `Refused`，
    /// 总线拒绝的其它情况是 `Failed`/`Unsupported`。
    ///
    /// `BindShortcuts` is accepted once per session, so each call opens its own.
    /// `BindShortcuts` 每个会话只被接受一次，故每次调用各开一个会话。
    fn register(&mut self, chord: KeyChord, id: ShortcutId) -> Result<(), GlobalHotkeyError> {
        let trigger = chord_to_trigger(chord)
            .ok_or_else(|| GlobalHotkeyError::Failed(format!("no portal name for {id:?}")))?;
        // Register the lookup before binding so an `Activated` racing the reply is not lost.
        // 绑定前先登记映射，避免抢在回复之前的 `Activated` 丢失。
        self.shared
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .lookup
            .insert(id.0.to_string(), id);

        let session = match self.spawn_session() {
            Ok(session) => session,
            Err(e) => {
                self.forget(id);
                return Err(e);
            }
        };
        let token = self.next_token();
        match bind_shortcuts(&self.conn, &session, &token, id, &trigger) {
            Ok(true) => Ok(()),
            Ok(false) => {
                self.forget(id);
                Err(GlobalHotkeyError::Refused)
            }
            Err(e) => {
                self.forget(id);
                Err(e)
            }
        }
    }

    /// Drop the local id: the portal offers no unbind, so this only stops `poll` from reporting
    /// it; the real key stays grabbed until the session closes or the app exits.
    /// 丢弃本地 id：门户不提供解绑，故这里只让 `poll` 不再上报它；真实按键仍被占用，直到
    /// 会话关闭或应用退出。
    fn unregister(&mut self, id: ShortcutId) {
        self.forget(id);
    }

    /// Drain activations the reader thread queued since the last call; never blocks.
    /// 取空自上次调用以来读取线程排入的激活；绝不阻塞。
    fn poll(&mut self) -> Vec<ShortcutId> {
        let mut guard = self.shared.lock().unwrap_or_else(|e| e.into_inner());
        std::mem::take(&mut guard.activated)
    }
}

impl PortalHotkeys {
    /// Open a fresh session for one bind and record it, so both `Activated` filtering and
    /// [`Self::close`] know about it.
    /// 为单次绑定开一个新会话并登记，让 `Activated` 的过滤与 [`Self::close`] 都能认得它。
    fn spawn_session(&self) -> Result<OwnedObjectPath, GlobalHotkeyError> {
        // Each portal request gets its own token: the token names the request's object path,
        // so reusing one would put two requests at the same path.
        // 每个门户请求各有 token：token 决定请求的对象路径，复用会把两个请求放到同一路径。
        let token = self.next_token();
        let session = create_session(&self.conn, &token)?;
        self.shared
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .sessions
            .push(session.as_str().to_string());
        Ok(session)
    }

    /// Forget a bound id from the shared lookup, used by register's error paths and unregister.
    /// 从共享映射里遗忘一个已绑定 id，供 register 的错误路径与 unregister 使用。
    fn forget(&mut self, id: ShortcutId) {
        self.shared
            .lock()
            .unwrap_or_else(|e| e.into_inner())
            .lookup
            .remove(id.0);
    }
}

/// A proxy on the desktop root for the `GlobalShortcuts` interface.
/// 指向桌面根、`GlobalShortcuts` 接口的代理。
fn portal_proxy(
    conn: &zbus::blocking::Connection,
) -> Result<zbus::blocking::Proxy<'static>, GlobalHotkeyError> {
    zbus::blocking::Proxy::new(conn, DESKTOP_DEST, DESKTOP_PATH, GS_IFACE).map_err(bus_error)
}

/// `CreateSession` and follow its `Response` to the returned `session_handle`. `token` must
/// match the one used to build the request path.
/// 调用 `CreateSession` 并顺着其 `Response` 取回 `session_handle`；`token` 要与构造请求
/// 路径用的一致。
fn create_session(
    conn: &zbus::blocking::Connection,
    token: &str,
) -> Result<OwnedObjectPath, GlobalHotkeyError> {
    let mut options: HashMap<String, OwnedValue> = HashMap::new();
    options.insert("handle_token".into(), owned_str(token)?);
    options.insert("session_handle_token".into(), owned_str(token)?);

    // Subscribe to this request's response before the call, so a fast reply is never missed.
    // 在调用之前先订阅本请求的回复，快回复也不会漏掉。
    let request_proxy = request_proxy(conn, request_path(conn, token))?;
    let mut response = response_stream(&request_proxy)?;
    portal_proxy(conn)?
        .call_noreply("CreateSession", &options)
        .map_err(bus_error)?;
    let reply = read_response(&mut response)?;
    if reply.code != 0 {
        return Err(GlobalHotkeyError::Failed(format!("CreateSession code {}", reply.code)));
    }
    // `session_handle` is typed `o` in the XML but backends emit it as `s`.
    // `session_handle` 在 XML 里写作 `o`，但后端实际按 `s` 发出。
    let handle = reply
        .results
        .get("session_handle")
        .and_then(|v| <&str>::try_from(v).ok())
        .ok_or_else(|| GlobalHotkeyError::Failed("session_handle missing".into()))?;
    OwnedObjectPath::try_from(handle).map_err(dbus_error)
}

/// `BindShortcuts` for one shortcut and await the confirmation dialog's response. `Ok(true)` if
/// the desktop accepted, `Ok(false)` if the user dismissed the dialog.
/// 对单个快捷键调用 `BindShortcuts` 并等待确认对话框的回复。桌面接受为 `Ok(true)`，
/// 用户关回为 `Ok(false)`。
fn bind_shortcuts(
    conn: &zbus::blocking::Connection,
    session: &OwnedObjectPath,
    token: &str,
    id: ShortcutId,
    trigger: &str,
) -> Result<bool, GlobalHotkeyError> {
    let mut info: HashMap<String, OwnedValue> = HashMap::new();
    info.insert("description".into(), owned_str(id.0)?);
    info.insert("preferred_trigger".into(), owned_str(trigger)?);
    let shortcuts: Vec<(String, HashMap<String, OwnedValue>)> = vec![(id.0.to_string(), info)];
    let mut options: HashMap<String, OwnedValue> = HashMap::new();
    options.insert("handle_token".into(), owned_str(token)?);

    // `BindShortcuts(o session, a(sa{sv}) shortcuts, s parent_window, a{sv} options)`.
    // `BindShortcuts(o 会话, a(sa{sv}) 快捷键, s 父窗口, a{sv} 选项)`。
    let body = (session, &shortcuts, "", &options);
    let request_proxy = request_proxy(conn, request_path(conn, token))?;
    let mut response = response_stream(&request_proxy)?;
    portal_proxy(conn)?
        .call_noreply("BindShortcuts", &body)
        .map_err(bus_error)?;
    let reply = read_response(&mut response)?;
    // Code 1 is the documented "user cancelled"; other codes are refusals we cannot retry.
    // 码 1 是文档记载的「用户取消」；其它码是无法重试的拒绝。
    Ok(reply.code == 0)
}

/// A proxy on the portal `Request` object at `path`, to read its `Response`.
/// 指向 `path` 上门户 `Request` 对象的代理，用于读取其 `Response`。
fn request_proxy(
    conn: &zbus::blocking::Connection,
    path: String,
) -> Result<zbus::blocking::Proxy<'static>, GlobalHotkeyError> {
    // `new_owned` keeps the arguments `'static`, so the path (built per call) does not borrow.
    // `new_owned` 让参数保持 `'static`，于是逐次构造的路径不会借用。
    zbus::blocking::Proxy::new_owned(conn.clone(), DESKTOP_DEST, path, REQUEST_IFACE)
        .map_err(bus_error)
}

/// Install the `Response` signal stream on `request_proxy`.
/// 在 `request_proxy` 上安装 `Response` 信号流。
fn response_stream(
    request_proxy: &zbus::blocking::Proxy<'static>,
) -> Result<zbus::blocking::proxy::SignalIterator<'static>, GlobalHotkeyError> {
    request_proxy
        .receive_signal("Response")
        .map_err(|_| GlobalHotkeyError::Failed("cannot watch the portal request".into()))
}

/// A decoded portal `Request::Response` (`(u code, a{sv} results)`).
/// 已解码的门户 `Request::Response`（`(u 码, a{sv} 结果)`）。
struct PortalResponse {
    /// The numeric response code.
    /// 数值响应码。
    code: u32,
    /// The results vardict.
    /// 结果 vardict。
    results: HashMap<String, OwnedValue>,
}

/// Read one `Response` signal from a stream the caller installed before the request.
/// 从调用方在请求前装好的流里读一条 `Response` 信号。
fn read_response(
    stream: &mut zbus::blocking::proxy::SignalIterator<'_>,
) -> Result<PortalResponse, GlobalHotkeyError> {
    let message = stream
        .next()
        .ok_or_else(|| GlobalHotkeyError::Failed("portal request stream closed".into()))?;
    let (code, results): (u32, HashMap<String, OwnedValue>) = message
        .body()
        .deserialize()
        .map_err(|_| GlobalHotkeyError::Failed("malformed portal response".into()))?;
    Ok(PortalResponse { code, results })
}

/// Start a detached thread that turns portal `Activated` signals into queued `ShortcutId`s.
/// 启动一个分离线程，把门户 `Activated` 信号转成排队的 `ShortcutId`。
fn spawn_reader(conn: &zbus::blocking::Connection, shared: Arc<Mutex<Shared>>) {
    let conn = conn.clone();
    let _ = thread::Builder::new()
        .name("portal-hotkeys".into())
        .spawn(move || reader_loop(&conn, shared));
}

/// Block on `Activated`; each activation naming a session we opened is looked up by id and queued.
/// 阻塞等待 `Activated`；凡指向我们开过的会话的激活，按 id 查表后入队。
fn reader_loop(conn: &zbus::blocking::Connection, shared: Arc<Mutex<Shared>>) {
    let Ok(proxy) = portal_proxy(conn) else {
        return;
    };
    let Ok(mut signals) = proxy.receive_signal("Activated") else {
        return;
    };
    while let Some(message) = signals.next() {
        // `Activated(o session_handle, s shortcut_id, t timestamp, a{sv} options)`.
        let Ok(body) = message.body().deserialize::<(OwnedObjectPath, String, u64)>() else {
            continue;
        };
        let mut guard = shared.lock().unwrap_or_else(|e| e.into_inner());
        if !guard.sessions.iter().any(|s| *s == body.0.as_str()) {
            continue;
        }
        if let Some(id) = guard.lookup.get(&body.1).copied() {
            guard.activated.push(id);
        }
    }
}

/// The object path a portal request handle will live at for `token`.
/// 门户请求 handle 在 `token` 下所对应的对象路径。
fn request_path(conn: &zbus::blocking::Connection, token: &str) -> String {
    // Request handles are `/…/request/<unique-id-with-dashes>/<token>`, keyed off our own bus
    // unique name; mirror how the portal derives the path from it.
    // 请求 handle 为 `/…/request/<去点号的唯一名>/<token>`，以我方总线唯一名为键；
    // 照门户由它推路径的方式处理。
    let unique = conn
        .unique_name()
        .map(|n| n.as_str().to_string())
        .unwrap_or_else(|| "unknown".into());
    format!(
        "{DESKTOP_PATH}/request/{}/{}",
        unique.trim_start_matches(':').replace('.', "_"),
        token
    )
}

/// Build an `OwnedValue` holding a string, for the vardicts the portal methods take.
/// 构造承载字符串的 `OwnedValue`，供门户方法接收的 vardict 使用。
fn owned_str(s: &str) -> Result<OwnedValue, GlobalHotkeyError> {
    Value::from(s).try_to_owned().map_err(dbus_error)
}

/// Map a "name/object/interface not found" bus error to `Unsupported`, everything else to
/// `Failed`: the distinction the trait asks for on a machine without the portal.
/// 把「名字/对象/接口未找到」的总线错误映射为 `Unsupported`，其余映射为 `Failed`：
/// 正是 trait 要求在无门户机器上作出的区分。
fn bus_error(error: zbus::Error) -> GlobalHotkeyError {
    let text = error.to_string();
    if text.contains("org.freedesktop.DBus.Error.ServiceUnknown")
        || text.contains("org.freedesktop.DBus.Error.NameHasNoOwner")
        || text.contains("org.freedesktop.DBus.Error.UnknownObject")
        || text.contains("org.freedesktop.DBus.Error.UnknownInterface")
        || text.contains("No such")
        || text.contains("does not exist")
    {
        GlobalHotkeyError::Unsupported
    } else {
        GlobalHotkeyError::Failed(text)
    }
}

/// Map a zvariant conversion error to `Failed` with the message it gave.
/// 把 zvariant 转换错误映射为 `Failed`，并附上它给出的信息。
fn dbus_error(error: zbus::zvariant::Error) -> GlobalHotkeyError {
    GlobalHotkeyError::Failed(error.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    // A bus address that resolves to nothing proves the no-portal path degrades without panic.
    // 指向空处的总线地址，用「无门户」路径证明它不 panic 地降级。
    #[test]
    fn an_unreachable_bus_degrades_instead_of_panicking() {
        // `unix:path=` to a file we never created: connecting fails, `new` must return Err.
        // `unix:path=` 指向我方从未创建的文件：连接失败，`new` 必须返回 Err。
        let result = PortalHotkeys::with_address("unix:path=/nonexistent/xdg-portal-bus");
        let error = result.err().expect("no bus, so construction fails");
        assert!(
            matches!(error, GlobalHotkeyError::Unsupported | GlobalHotkeyError::Failed(_)),
            "expected Unsupported/Failed, got {error:?}"
        );
    }
}
