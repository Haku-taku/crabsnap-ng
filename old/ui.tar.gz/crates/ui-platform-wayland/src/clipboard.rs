//! The seat's clipboard: `wl_data_device`, and the pipes a copy or a paste runs through.
//! 座位的剪贴板：`wl_data_device`，以及复制、粘贴所经的管道。
//!
//! Wayland's clipboard is pull-based: the copy side must stay alive and answer `send`, and
//! a paste side asks an offer for bytes down a pipe. Neither may block the event loop, so
//! reads and writes are non-blocking and the window's wait polls their fds.
//! Wayland 的剪贴板是拉取式的：复制方必须活着并回应 `send`，粘贴方经管道向 offer 要字节。
//! 两者都不得阻塞事件循环，因此读写都是非阻塞的，由窗口的等待把它们的 fd 一并 poll。

use std::fs::File;
use std::io::{Read, Write};
use std::os::fd::{AsFd, BorrowedFd, OwnedFd};
use std::time::{Duration, Instant};

use wayland_client::protocol::{
    wl_data_device, wl_data_device_manager, wl_data_offer, wl_data_source,
};
use wayland_client::{Connection, Dispatch, QueueHandle};

use crate::window::WindowState;

/// The mime types we offer, most specific first; a peer picks the first it understands.
/// 我们提供的 mime 类型，最具体的在前；对方挑第一个它认识的。
const MIMES: [&str; 3] = ["text/plain;charset=utf-8", "UTF8_STRING", "text/plain"];
/// How long a paste waits for the other side before giving up.
/// 一次粘贴等待对方多久，超时就放弃。
const READ_TIMEOUT: Duration = Duration::from_secs(2);

/// A pipe we are reading a peer's clipboard text from.
/// 我们正在从中读取对方剪贴板文本的管道。
struct ReadJob {
    fd: File,
    bytes: Vec<u8>,
    deadline: Instant,
}

/// A pipe a peer asked us to write our clipboard text into.
/// 对方要求我们把剪贴板文本写进去的管道。
struct WriteJob {
    fd: File,
    bytes: Vec<u8>,
    at: usize,
    deadline: Instant,
}

/// Everything the seat's clipboard owns.
/// 座位剪贴板拥有的一切。
pub(crate) struct Clipboard {
    manager: Option<wl_data_device_manager::WlDataDeviceManager>,
    device: Option<wl_data_device::WlDataDevice>,
    /// What the compositor last offered us; invalid once we lose keyboard focus.
    /// compositor 最近给我们的 offer；失去键盘焦点后即失效。
    offer: Option<wl_data_offer::WlDataOffer>,
    mimes: Vec<String>,
    /// The source we are serving, while our text is on the clipboard.
    /// 我们正在服务的 source，即我们的文本在剪贴板上期间。
    source: Option<wl_data_source::WlDataSource>,
    contents: Option<String>,
    /// Serial of the latest input event; `set_selection` is ignored without a fresh one.
    /// 最近一次输入事件的 serial；没有新鲜的 serial，`set_selection` 会被忽略。
    serial: u32,
    read: Option<ReadJob>,
    writes: Vec<WriteJob>,
}

impl Clipboard {
    pub(crate) fn new() -> Self {
        Self {
            manager: None,
            device: None,
            offer: None,
            mimes: Vec::new(),
            source: None,
            contents: None,
            serial: 0,
            read: None,
            writes: Vec::new(),
        }
    }

    /// Take the seat's data device, which is what every copy and paste goes through.
    /// 取走座位的数据设备；每次复制与粘贴都经过它。
    pub(crate) fn attach(
        &mut self,
        manager: wl_data_device_manager::WlDataDeviceManager,
        device: wl_data_device::WlDataDevice,
    ) {
        self.manager = Some(manager);
        self.device = Some(device);
    }

    pub(crate) fn note_serial(&mut self, serial: u32) {
        self.serial = serial;
    }

    /// The fds a wait should poll, alongside the connection, and whether each wants write.
    /// 等待时除连接之外还要 poll 的 fd，以及每个 fd 是否等可写。
    pub(crate) fn fds(&self) -> Vec<(BorrowedFd<'_>, bool)> {
        let mut out: Vec<(BorrowedFd<'_>, bool)> = Vec::new();
        if let Some(read) = &self.read {
            out.push((read.fd.as_fd(), false));
        }
        for write in &self.writes {
            out.push((write.fd.as_fd(), true));
        }
        out
    }

    /// How long until the nearest deadline, so a wait never sleeps past it.
    /// 距最近的截止时间还有多久，等待因此不会睡过头。
    pub(crate) fn timeout(&self) -> Option<Duration> {
        let now = Instant::now();
        let mut nearest: Option<Instant> = self.read.as_ref().map(|r| r.deadline);
        for write in &self.writes {
            nearest = Some(nearest.map_or(write.deadline, |n| n.min(write.deadline)));
        }
        nearest.map(|at| at.saturating_duration_since(now))
    }

    /// Offer `text` as the selection. Returns false when the compositor gave us no device.
    /// 把 `text` 作为选区提供出去。compositor 没给设备时返回 false。
    pub(crate) fn copy(
        &mut self,
        text: &str,
        conn: &Connection,
        qh: &QueueHandle<WindowState>,
    ) -> bool {
        let (Some(device), Some(manager)) = (self.device.clone(), self.manager.clone()) else {
            return false;
        };
        if let Some(old) = self.source.take() {
            old.destroy();
        }
        let source = manager.create_data_source(qh, ());
        for mime in MIMES {
            source.offer(mime.to_string());
        }
        device.set_selection(Some(&source), self.serial);
        // The text stays here: the peer will ask for it later, through `send`.
        // 文本留在这里：对方稍后会经 `send` 来要。
        self.contents = Some(text.to_string());
        self.source = Some(source);
        let _ = conn.flush();
        true
    }

    /// Ask the current offer for its text; the answer arrives as `Event::Paste`.
    /// 向当前 offer 索要文本；答案以 `Event::Paste` 到达。
    pub(crate) fn request_paste(&mut self, conn: &Connection) -> bool {
        let Some(offer) = self.offer.clone() else {
            return false;
        };
        let Some(mime) = self
            .mimes
            .iter()
            .find(|m| MIMES.contains(&m.as_str()))
            .cloned()
        else {
            return false;
        };
        let Ok((read_fd, write_fd)) = rustix::pipe::pipe_with(
            rustix::pipe::PipeFlags::NONBLOCK | rustix::pipe::PipeFlags::CLOEXEC,
        ) else {
            return false;
        };
        offer.receive(mime, write_fd.as_fd());
        // Our end of the write side must close, or the reader never sees EOF.
        // 我们这一端的写端必须关掉，否则读端永远等不到 EOF。
        drop(write_fd);
        self.read = Some(ReadJob {
            fd: File::from(read_fd),
            bytes: Vec::new(),
            deadline: Instant::now() + READ_TIMEOUT,
        });
        let _ = conn.flush();
        true
    }

    /// Move bytes on every pipe we hold. Returns the text of a paste that finished.
    /// 推进我们持有的每个管道。返回刚刚读完的粘贴文本。
    pub(crate) fn service(&mut self) -> Option<String> {
        let mut done = None;
        if let Some(read) = &mut self.read {
            let mut buf = [0u8; 8192];
            loop {
                match (&read.fd).read(&mut buf) {
                    Ok(0) => {
                        // EOF: the peer closed its side, so the text is complete.
                        // EOF：对方关闭了写端，文本已完整。
                        done = Some(String::from_utf8_lossy(&read.bytes).into_owned());
                        break;
                    }
                    Ok(n) => read.bytes.extend_from_slice(&buf[..n]),
                    Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => break,
                    Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
                    Err(_) => {
                        // A broken pipe is an empty paste, not a stuck one.
                        // 管道断了就是一次空粘贴，而不是卡住。
                        done = Some(String::new());
                        break;
                    }
                }
            }
            if done.is_none() && Instant::now() > read.deadline {
                // A peer that never answers must not hold the clipboard hostage.
                // 从不回应的对方不能一直占着剪贴板。
                done = Some(String::new());
            }
        }
        if done.is_some() {
            self.read = None;
        }
        // Serve the peers waiting on our own text, then close each pipe.
        // 服务等着我们文本的对方，写完就关掉管道。
        let mut i = 0;
        while i < self.writes.len() {
            let write = &mut self.writes[i];
            let mut finished = false;
            while write.at < write.bytes.len() {
                match (&write.fd).write(&write.bytes[write.at..]) {
                    Ok(0) => {
                        finished = true;
                        break;
                    }
                    Ok(n) => write.at += n,
                    Err(e) if e.kind() == std::io::ErrorKind::WouldBlock => break,
                    Err(e) if e.kind() == std::io::ErrorKind::Interrupted => continue,
                    Err(_) => {
                        finished = true;
                        break;
                    }
                }
            }
            if finished || write.at >= write.bytes.len() || Instant::now() > write.deadline {
                self.writes.remove(i);
            } else {
                i += 1;
            }
        }
        done
    }

    /// Queue our text for a peer's `send` request.
    /// 把我们的文本排进对方 `send` 请求的管道。
    fn serve(&mut self, fd: OwnedFd) {
        let bytes = self.contents.clone().unwrap_or_default().into_bytes();
        self.writes.push(WriteJob {
            fd: File::from(fd),
            bytes,
            at: 0,
            deadline: Instant::now() + READ_TIMEOUT,
        });
    }

    fn set_offer(&mut self, offer: Option<wl_data_offer::WlDataOffer>) {
        // `data_offer` and `selection` announce the same object; destroying it twice kills it.
        // `data_offer` 与 `selection` 宣布同一个对象；销毁两次会把它弄没。
        if let (Some(old), Some(new)) = (self.offer.as_ref(), offer.as_ref())
            && old == new {
                return;
            }
        if let Some(old) = self.offer.take() {
            old.destroy();
        }
        self.mimes.clear();
        self.offer = offer;
    }
}

impl Drop for Clipboard {
    fn drop(&mut self) {
        if let Some(offer) = self.offer.take() {
            offer.destroy();
        }
        if let Some(source) = self.source.take() {
            source.destroy();
        }
    }
}

impl Dispatch<wl_data_device_manager::WlDataDeviceManager, ()> for WindowState {
    fn event(
        _: &mut Self,
        _: &wl_data_device_manager::WlDataDeviceManager,
        _: <wl_data_device_manager::WlDataDeviceManager as wayland_client::Proxy>::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        // The manager has no events; it only creates data devices.
        // 管理器没有事件；它只负责创建设备。
    }
}

impl Dispatch<wl_data_device::WlDataDevice, ()> for WindowState {
    // `data_offer` is the only event that creates an object; without this the client panics.
    // `data_offer` 是唯一创建对象的事件；不写这个客户端会 panic。
    wayland_client::event_created_child!(WindowState, wl_data_device::WlDataDevice, [
        wl_data_device::EVT_DATA_OFFER_OPCODE => (wl_data_offer::WlDataOffer, ()),
    ]);

    fn event(
        state: &mut Self,
        _: &wl_data_device::WlDataDevice,
        event: wl_data_device::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        match event {
            wl_data_device::Event::DataOffer { id } => state.clipboard.set_offer(Some(id)),
            wl_data_device::Event::Selection { id } => state.clipboard.set_offer(id),
            // `leave` ends a drag-and-drop session, not the selection; paste must survive it.
            // `leave` 结束的是拖放会话而非选区；粘贴必须活过它。
            wl_data_device::Event::Leave => {}
            _ => {}
        }
    }
}

impl Dispatch<wl_data_offer::WlDataOffer, ()> for WindowState {
    fn event(
        state: &mut Self,
        _: &wl_data_offer::WlDataOffer,
        event: wl_data_offer::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        if let wl_data_offer::Event::Offer { mime_type } = event {
            state.clipboard.mimes.push(mime_type);
        }
    }
}

impl Dispatch<wl_data_source::WlDataSource, ()> for WindowState {
    fn event(
        state: &mut Self,
        _: &wl_data_source::WlDataSource,
        event: wl_data_source::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        match event {
            wl_data_source::Event::Send { fd, .. } => state.clipboard.serve(fd),
            wl_data_source::Event::Cancelled => {
                // Someone else took the selection: stop serving and forget the text.
                // 选区被别人拿走了：停止服务并忘掉文本。
                state.clipboard.contents = None;
                if let Some(source) = state.clipboard.source.take() {
                    source.destroy();
                }
            }
            _ => {}
        }
    }
}
