//! The XDG toplevel window.
//! XDG 顶层窗口。

use std::collections::HashMap;
use std::os::unix::io::AsFd;

/// Startup chatter about scales and colour management, only under `WAYLAND_TRACE=1`.
/// 关于缩放与色彩管理的启动噪音，仅在 `WAYLAND_TRACE=1` 时输出。
fn trace(args: std::fmt::Arguments<'_>) {
    if std::env::var_os("WAYLAND_TRACE").is_some() {
        eprintln!("[wayland] {args}");
    }
}

use ui_core::Damage;
use ui_paint::Pixels;
use ui_platform::present::{PresentTarget, SurfaceKind};
use wayland_client::protocol::{
    wl_buffer, wl_callback, wl_compositor, wl_keyboard, wl_output, wl_pointer, wl_seat, wl_shm,
    wl_shm_pool, wl_surface,
};
use wayland_client::{Connection, Dispatch, EventQueue, Proxy, QueueHandle};
use wayland_protocols::wp::fractional_scale::v1::client::{
    wp_fractional_scale_manager_v1, wp_fractional_scale_v1,
};
use wayland_protocols::wp::linux_dmabuf::zv1::client::zwp_linux_buffer_params_v1::{
    Event as ParamsEvent, ZwpLinuxBufferParamsV1,
};
use wayland_protocols::wp::linux_drm_syncobj::v1::client::{
    wp_linux_drm_syncobj_manager_v1::WpLinuxDrmSyncobjManagerV1,
    wp_linux_drm_syncobj_surface_v1::WpLinuxDrmSyncobjSurfaceV1,
    wp_linux_drm_syncobj_timeline_v1::WpLinuxDrmSyncobjTimelineV1,
};
use wayland_protocols::wp::linux_dmabuf::zv1::client::zwp_linux_dmabuf_v1::{
    Event as DmaBufEvent, ZwpLinuxDmabufV1,
};
use wayland_protocols::wp::text_input::zv3::client::zwp_text_input_v3::{
    self, Event as TextInputEvent, ZwpTextInputV3,
};
use wayland_protocols::wp::viewporter::client::{wp_viewport, wp_viewporter};
use crate::conn::shape_device;
use ui_core::CursorShape;
use wayland_protocols::xdg::shell::client::{xdg_surface, xdg_toplevel, xdg_wm_base};
use wayland_protocols_wlr::layer_shell::v1::client::{zwlr_layer_shell_v1, zwlr_layer_surface_v1};

use crate::dmabuf::{self, DmaBufBuffer, DmaBufError, DmaBufFormats, DmaBufImage};
use crate::input::InputState;
use crate::shm::ShmBuffer;

/// Why window creation failed.
/// 窗口创建失败的原因。
#[derive(Debug)]
pub enum WindowError {
    /// No Wayland session.
    /// 没有 Wayland 会话。
    Connect(String),
    /// A required global is missing.
    /// 缺少必需全局。
    MissingGlobal(&'static str),
    /// Buffer allocation failed.
    /// 缓冲分配失败。
    Buffer,
    /// Protocol error while round-tripping.
    /// 往返时协议错误。
    Protocol(String),
    /// The dma-buf path could not present this frame.
    /// 本帧无法通过 dma-buf 路径呈现。
    DmaBuf(DmaBufError),
}

impl std::fmt::Display for WindowError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            WindowError::Connect(e) => write!(f, "wayland connect failed: {e}"),
            WindowError::MissingGlobal(g) => write!(f, "missing global: {g}"),
            WindowError::Buffer => write!(f, "could not allocate a shm buffer"),
            WindowError::Protocol(e) => write!(f, "protocol error: {e}"),
            WindowError::DmaBuf(e) => write!(f, "dma-buf import failed: {e}"),
        }
    }
}

impl std::error::Error for WindowError {}
/// Device pixels for a logical size: round to nearest and never ask for zero.
/// 逻辑尺寸换算成设备像素：四舍五入，且绝不请求零尺寸。
pub(crate) fn device_size(logical: (u32, u32), scale: f32) -> (u32, u32) {
    let px = |v: u32| (v as f32 * scale).round().max(1.0) as u32;
    (px(logical.0), px(logical.1))
}

/// Window geometry and identity.
/// 窗口几何与身份。
#[derive(Clone, Debug)]
pub struct WindowConfig {
    pub title: String,
    pub app_id: String,
    pub width: u32,
    pub height: u32,
}

impl Default for WindowConfig {
    fn default() -> Self {
        Self {
            title: "crabsnap-ui".into(),
            app_id: "dev.crabsnap.ui".into(),
            width: 480,
            height: 280,
        }
    }
}

/// Which stack a layer surface is drawn in; higher layers cover lower ones.
/// Which stack a layer surface is drawn in; later layers cover earlier ones.
/// 浮层表面所在的层；越靠后的层盖住越靠前的。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum Layer {
    Background,
    Bottom,
    #[default]
    Top,
    Overlay,
}

/// Which edges a layer surface is pinned to; pinned to all four it takes the output.
/// 浮层表面贴住哪些边；四边全贴时它占满该输出。
#[derive(Clone, Copy, Debug, Default)]
pub struct Anchor {
    pub top: bool,
    pub bottom: bool,
    pub left: bool,
    pub right: bool,
}

impl Anchor {
    /// All four edges: the surface fills the output.
    /// 四边全贴：表面占满输出。
    pub const ALL: Self = Self {
        top: true,
        bottom: true,
        left: true,
        right: true,
    };
}

/// How a layer surface should be placed; the compositor owns the geometry.
/// 浮层表面如何摆放；几何归 compositor。
#[derive(Clone, Debug)]
pub struct LayerConfig {
    pub layer: Layer,
    pub anchor: Anchor,
    /// Logical size, or `None` to take whatever the anchors leave.
    /// 逻辑尺寸；`None` 表示取锚点剩下的全部空间。
    pub size: Option<(u32, u32)>,
    /// Space reserved for other windows; negative keeps the surface out of layout entirely.
    /// 为其他窗口预留的空间；负数表示完全不影响布局。
    pub exclusive_zone: i32,
    /// Whether the surface takes the keyboard exclusively.
    /// 是否独占键盘。
    pub keyboard: bool,
    /// Compositor-side name, used by rules and debugging.
    /// compositor 侧的命名，供规则与调试使用。
    pub namespace: String,
}

impl Default for LayerConfig {
    fn default() -> Self {
        Self {
            layer: Layer::Overlay,
            anchor: Anchor::ALL,
            size: None,
            exclusive_zone: -1,
            keyboard: false,
            namespace: "crabsnap-overlay".into(),
        }
    }
}

/// State the compositor and input drive.
/// 由 compositor 与输入驱动的状态。
pub(crate) struct WindowState {
    /// Set when the compositor rejects an image description.
    /// compositor 拒绝 image description 时置位。
    pub(crate) colour_failed: Option<u32>,
    /// (min, max, reference) luminance from the compositor's preferred description.
    /// compositor 首选描述里的（最小、最大、参考白）亮度。
    pub(crate) preferred_luminances: Option<(u32, u32, u32)>,
    /// Transfer function and primaries code points from the same description.
    /// 同一描述里的传输函数与基色码点。
    pub(crate) preferred_tf: Option<u32>,
    pub(crate) preferred_primaries: Option<u32>,
    /// Exact primaries from the same description, when it carries coordinates.
    /// 同一描述里的精确基色（当它携带坐标时）。
    pub(crate) preferred_chromaticities: Option<ui_core::colour::Chromaticities>,
    /// Only client-created descriptions accept `get_information` on this compositor.
    /// 本机上只有客户端创建的描述接受 `get_information`。
    pub(crate) allow_info: bool,
    /// Bitmask of `wp_color_manager_v1.feature` values the compositor advertised.
    /// compositor 广播的 `wp_color_manager_v1.feature` 位掩码。
    pub(crate) colour_features: u32,
    pub(crate) colour_features_known: bool,
    shm: Option<wl_shm::WlShm>,
    base: Option<xdg_wm_base::XdgWmBase>,
    configured: bool,
    closed: bool,
    /// Latest pointer position in surface-local coordinates.
    /// 指针在表面本地坐标中的最新位置。
    pointer: Option<ui_core::geom::Point>,
    /// Pointer enter/leave tracking.
    /// 指针进入/离开跟踪。
    pointer_over: bool,
    /// Serial from the latest pointer enter; `set_shape` is ignored without it.
    /// 最近一次指针进入的 serial；没有它 `set_shape` 会被忽略。
    pointer_enter_serial: Option<u32>,
    /// Last shape handed to the compositor, so a still pointer sends nothing.
    /// 最近一次交给 compositor 的形状，指针不动时不重复发送。
    cursor_shape: Option<ui_core::CursorShape>,
    /// Input events collected since the last drain; the loop dispatches them.
    /// 上次取空以来收集的输入事件；由循环派发。
    events: Vec<ui_core::Event>,
    /// False while a frame callback is outstanding: drawing another frame would
    /// be discarded by the compositor.
    /// 有未完成的帧回调时为 false：此时再画一帧会被 compositor 丢弃。
    frame_ready: bool,
    /// Frame callbacks delivered since the app last asked: the rate the compositor offers.
    /// 自上次读数以来送达的帧回调数：compositor 给出的速率。
    frame_callbacks: u32,
    /// Set when something changed and a new frame is wanted.
    /// 有变化、希望再画一帧时置位。
    redraw_requested: bool,
    /// A change the app cannot see as an `Event` — focus, IME focus, output scale. A loop
    /// that skips frames on unchanged input must still rebuild for these.
    /// 应用看不到对应 `Event` 的变化——焦点、输入法焦点、输出缩放。按输入未变而跳帧的循环
    /// 仍须为它们重建。
    silent_change: bool,
    /// The output's mode refresh rate in millihertz, as the compositor declared it.
    /// 输出模式的刷新率（毫赫兹），由 compositor 声明。
    refresh_mhz: u32,
    /// Keyboard focus came back: the compositor reset its text-input session, so the
    /// client must re-send `enable` and the whole state even though nothing changed.
    /// 键盘焦点回来了：compositor 已重置输入法会话，客户端必须重发 `enable` 与整套状态。
    ime_reenter: bool,
    /// The compositor's own text-input `enter` arrived: only then may `enable` be sent.
    /// compositor 自己的 text-input `enter` 已到达：此后才允许发送 `enable`。
    ime_entered: bool,
    /// Logical (surface-local) size, in points. Buffers are `logical * scale`.
    /// 逻辑（表面本地）尺寸，以 point 计。缓冲区为 `logical * scale`。
    width: u32,
    height: u32,
    /// Fractional scale from the compositor, stored as quarters (150 => 1.5).
    /// compositor 给出的分数缩放，按四分之一存（150 表示 1.5）。
    scale_quarters: u32,
    /// Keyboard and pointer state.
    /// 键盘与指针状态。
    input: InputState,
    /// The seat's clipboard: the data device, the offer, and the pipes in flight.
    /// 座位的剪贴板：数据设备、offer，以及进行中的管道。
    pub(crate) clipboard: crate::clipboard::Clipboard,
    /// Format/modifier pairs the compositor advertised for dma-buf import.
    /// compositor 为 dma-buf 导入通告的 format/modifier 组合。
    dmabuf_formats: DmaBufFormats,
    /// dma-buf buffers the compositor still holds; each is released on `wl_buffer.release`.
    /// compositor 仍持有的 dma-buf 缓冲；各自在 `wl_buffer.release` 时释放。
    dmabuf_inflight: Vec<wl_buffer::WlBuffer>,
    /// Count of `wl_buffer.release` events seen for dma-buf buffers.
    /// dma-buf 缓冲收到的 `wl_buffer.release` 事件计数。
    dmabuf_released: u32,
    /// Count of `zwp_linux_buffer_params_v1.failed` events.
    /// `zwp_linux_buffer_params_v1.failed` 事件计数。
    dmabuf_rejected: u32,
    /// Composition the input method sent since the last `done`.
    /// 输入法自上次 `done` 以来送来的组合内容。
    ime: ImePending,
}

/// One batch of input-method state, applied together on `done`.
/// 一批输入法状态，在 `done` 时一起生效。
#[derive(Default)]
struct ImePending {
    /// Preedit text with its cursor byte offset; `None` means none arrived this batch.
    /// 预编辑文本及其插入符字节偏移；`None` 表示本批没有送来。
    preedit: Option<(String, usize)>,
    commit: Option<String>,
    delete: Option<(usize, usize)>,
}

impl WindowState {
    fn new(width: u32, height: u32) -> Self {
        Self {
            shm: None,
            base: None,
            configured: false,
            closed: false,
            pointer: None,
            events: Vec::new(),
            pointer_over: false,
            pointer_enter_serial: None,
            cursor_shape: None,
            frame_ready: true,
            frame_callbacks: 0,
            redraw_requested: true,
            silent_change: true,
            refresh_mhz: 0,
            ime_reenter: false,
            ime_entered: false,
            width,
            height,
            scale_quarters: 100,
            input: InputState::new(),
            clipboard: crate::clipboard::Clipboard::new(),
            colour_failed: None,
            preferred_luminances: None,
            preferred_tf: None,
            preferred_primaries: None,
            preferred_chromaticities: None,
            allow_info: false,
            colour_features: 0,
            colour_features_known: false,
            dmabuf_formats: DmaBufFormats::default(),
            dmabuf_inflight: Vec::new(),
            dmabuf_released: 0,
            dmabuf_rejected: 0,
            ime: ImePending::default(),
        }
    }
}

macro_rules! noop_dispatch {
    ($iface:ty, $udata:ty) => {
        impl Dispatch<$iface, $udata> for WindowState {
            fn event(
                _: &mut Self,
                _: &$iface,
                _: <$iface as Proxy>::Event,
                _: &$udata,
                _: &Connection,
                _: &QueueHandle<Self>,
            ) {
            }
        }
    };
}

noop_dispatch!(wl_compositor::WlCompositor, ());
noop_dispatch!(wl_surface::WlSurface, ());
noop_dispatch!(wl_shm_pool::WlShmPool, ());
noop_dispatch!(wl_shm::WlShm, ());
noop_dispatch!(wl_seat::WlSeat, ());
noop_dispatch!(shape_device::WpCursorShapeDeviceV1, ());
noop_dispatch!(crate::conn::wp_cursor_shape_manager_v1::WpCursorShapeManagerV1, ());
noop_dispatch!(
    wayland_protocols::wp::text_input::zv3::client::zwp_text_input_manager_v3::ZwpTextInputManagerV3,
    ()
);
noop_dispatch!(wp_viewporter::WpViewporter, ());
noop_dispatch!(wp_viewport::WpViewport, ());
noop_dispatch!(wp_fractional_scale_manager_v1::WpFractionalScaleManagerV1, ());

impl Dispatch<ZwpTextInputV3, ()> for WindowState {
    fn event(
        state: &mut Self,
        _: &ZwpTextInputV3,
        event: TextInputEvent,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        // Collected, never applied here: `done` is the only commit point.
        // 只收集，不在此生效：`done` 是唯一的提交点。
        match event {
            // The session is the compositor's to grant: `enable` is only legal between these
            // two, and a focus change ends the old session without changing its enabled flag.
            // 会话由 compositor 授予：`enable` 只在两者之间合法，而焦点变化会结束旧会话
            // 却不会改动它的启用标志。
            TextInputEvent::Enter { .. } => {
                state.ime_entered = true;
                state.ime_reenter = true;
                state.redraw_requested = true;
                state.silent_change = true;
            }
            TextInputEvent::Leave { .. } => {
                state.ime_entered = false;
                state.redraw_requested = true;
                state.silent_change = true;
            }
            TextInputEvent::PreeditString {
                text,
                cursor_begin,
                cursor_end,
            } => {
                let text = text.unwrap_or_default();
                // The caret sits at the *end* of the highlighted range: fcitx5 sends
                // `begin=0, end=len` for every pinyin preedit, and clients draw the caret
                // after the composition, not before it.
                // 插入符落在高亮区的**末端**：fcitx5 对每个拼音预编辑都发 `begin=0, end=len`，
                // 客户端把插入符画在组合串之后，而不是之前。
                let cursor = if cursor_begin < 0 || cursor_end < 0 {
                    text.len()
                } else {
                    (cursor_end as usize).min(text.len())
                };
                state.ime.preedit = Some((text, cursor));
            }
            TextInputEvent::CommitString { text } => {
                state.ime.commit = text;
            }
            TextInputEvent::DeleteSurroundingText {
                before_length,
                after_length,
            } => {
                state.ime.delete = Some((before_length as usize, after_length as usize));
            }
            TextInputEvent::Done { .. } => state.apply_ime_batch(),
            _ => {}
        }
    }
}

impl WindowState {
    /// Turn one `done` batch into engine events, in the order the engine expects them.
    /// 把一批 `done` 转成引擎事件，顺序与引擎的预期一致。
    fn apply_ime_batch(&mut self) {
        if let Some((before, after)) = self.ime.delete.take() {
            self.events.push(ui_core::Event::DeleteSurrounding { before, after });
        }
        // `done` resets the pending values, so a batch without a preedit means the input
        // method has none: the old one must go, or the last composed character sticks.
        // `done` 后待发值复位：本批没有预编辑就表示输入法没有预编辑，旧的必须清掉，
        // 否则最后一个组合字符会一直留在屏幕上。
        let preedit = self.ime.preedit.take().and_then(|(text, cursor)| {
            (!text.is_empty()).then(|| ui_core::Preedit::new(text, cursor))
        });
        self.events.push(ui_core::Event::Preedit(preedit));
        if let Some(text) = self.ime.commit.take()
            && !text.is_empty() {
                self.events.push(ui_core::Event::Text(text));
            }
        self.redraw_requested = true;
    }
}

impl Dispatch<wl_output::WlOutput, ()> for WindowState {
    fn event(
        state: &mut Self,
        _: &wl_output::WlOutput,
        event: wl_output::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        if let wl_output::Event::Mode { refresh, .. } = event {
            // The protocol reports millihertz, and zero when the compositor does not know.
            // 协议以毫赫兹上报，compositor 不知道时为 0。
            state.refresh_mhz = refresh.max(0) as u32;
        }
    }
}

impl Dispatch<wl_buffer::WlBuffer, ()> for WindowState {
    fn event(
        state: &mut Self,
        buffer: &wl_buffer::WlBuffer,
        event: wl_buffer::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        if let wl_buffer::Event::Release = event {
            // The compositor stopped sampling; dropping the buffer now is safe.
            // compositor 已停止采样，此时丢弃缓冲是安全的。
            let before = state.dmabuf_inflight.len();
            state.dmabuf_inflight.retain(|held| held != buffer);
            state.dmabuf_released += (before - state.dmabuf_inflight.len()) as u32;
        }
    }
}

impl Dispatch<WpLinuxDrmSyncobjSurfaceV1, ()> for WindowState {
    fn event(
        _: &mut Self,
        _: &WpLinuxDrmSyncobjSurfaceV1,
        _: wayland_protocols::wp::linux_drm_syncobj::v1::client::wp_linux_drm_syncobj_surface_v1::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        // The release point tells us the compositor is done reading; we never reuse a
        // buffer before its `wl_buffer.release`, so there is nothing to act on.
        // release 点告诉我们 compositor 已读完；我们在 `wl_buffer.release` 之前从不复用
        // 缓冲，因此这里无需动作。
    }
}

impl Dispatch<WpLinuxDrmSyncobjTimelineV1, ()> for WindowState {
    fn event(
        _: &mut Self,
        _: &WpLinuxDrmSyncobjTimelineV1,
        _: wayland_protocols::wp::linux_drm_syncobj::v1::client::wp_linux_drm_syncobj_timeline_v1::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        // The timeline has no events.
        // timeline 没有事件。
    }
}

impl Dispatch<WpLinuxDrmSyncobjManagerV1, ()> for WindowState {
    fn event(
        _: &mut Self,
        _: &WpLinuxDrmSyncobjManagerV1,
        _: wayland_protocols::wp::linux_drm_syncobj::v1::client::wp_linux_drm_syncobj_manager_v1::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        // The manager has no events.
        // manager 没有事件。
    }
}

impl Dispatch<ZwpLinuxDmabufV1, ()> for WindowState {
    fn event(
        state: &mut Self,
        _: &ZwpLinuxDmabufV1,
        event: DmaBufEvent,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        match event {
            DmaBufEvent::Format { format } => state.dmabuf_formats.record_format(format),
            DmaBufEvent::Modifier {
                format,
                modifier_hi,
                modifier_lo,
            } => state
                .dmabuf_formats
                .record_modifier(format, dmabuf::modifier_from_parts(modifier_hi, modifier_lo)),
            _ => {}
        }
    }
}

impl Dispatch<ZwpLinuxBufferParamsV1, ()> for WindowState {
    fn event(
        state: &mut Self,
        _: &ZwpLinuxBufferParamsV1,
        event: ParamsEvent,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        // create_immed reports a rejected import asynchronously, never as Err.
        // create_immed 以异步方式报告导入被拒绝，不会返回 Err。
        if let ParamsEvent::Failed = event {
            state.dmabuf_rejected += 1;
        }
    }
}

impl Dispatch<wl_keyboard::WlKeyboard, ()> for WindowState {
    fn event(
        state: &mut Self,
        _: &wl_keyboard::WlKeyboard,
        event: wl_keyboard::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        match event {
            wl_keyboard::Event::Keymap { format, fd, size } => {
                // Only XKB_V1 text keymaps are handled; anything else is ignored.
                // 只处理 XKB_V1 文本键位表；其它格式忽略。
                if matches!(
                    format,
                    wayland_client::WEnum::Value(wl_keyboard::KeymapFormat::XkbV1)
                ) {
                    // Hand the fd to xkbcommon: the string path cannot work here,
                    // because keeping the trailing NUL panics CString and dropping
                    // it makes the parser reject the text.
                    // 把 fd 交给 xkbcommon：字符串路径在此不可行——
                    // 保留结尾 NUL 会让 CString panic，去掉 NUL 又会被解析器拒绝。
                    let _ = unsafe { state.input.set_keymap_fd(fd, size as usize) };
                }
                state.redraw_requested = true;
            }
            wl_keyboard::Event::Enter { serial, .. } => {
                // Focus returned, so the session the compositor dropped must be rebuilt; the
                // text-input `enter` says the same thing and gates when it may be sent.
                // 焦点回来了，compositor 丢掉的会话必须重建；text-input 的 `enter`
                // 说的是同一件事，并决定何时才允许发送。
                // `set_selection` is only honoured with a serial from our own input.
                // 只有带着我们自己输入事件的 serial，`set_selection` 才会被接受。
                state.clipboard.note_serial(serial);
                state.ime_reenter = true;
                state.redraw_requested = true;
                state.silent_change = true;
            }
            wl_keyboard::Event::Leave { .. } => {
                state.redraw_requested = true;
                state.silent_change = true;
            }
            wl_keyboard::Event::Key { key, serial, state: key_state, .. } => {
                state.clipboard.note_serial(serial);
                let pressed = matches!(key_state, wayland_client::WEnum::Value(wl_keyboard::KeyState::Pressed));
                // A command modifier turns the character into a command, never text:
                // Ctrl+A must not insert an `a`.
                // 命令修饰键让字符成为命令而非文本：Ctrl+A 不得插入 `a`。
                let command = state.input.is_held(0xffe3)
                    || state.input.is_held(0xffe9)
                    || state.input.is_held(0xffeb);
                if pressed {
                    // The key names itself; only the unmodified path also types text, which
                    // is what composes a dead key with the letter after it.
                    // 按键以自身命名；只有无修饰的路径还会打出文本，死键正是靠它和后一个字母组合。
                    if let Some(c) = state.input.key(key, true) {
                        if command {
                            state
                                .events
                                .push(ui_core::Event::KeyPressed { key: ui_core::Key::Char(c) });
                        } else {
                            let typed = state.input.text(key).unwrap_or(c);
                            state.input.push_text(typed);
                            state.events.push(ui_core::Event::Text(typed.to_string()));
                        }
                    }
                } else {
                    state.input.key(key, false);
                }
                // Named keys travel as themselves; text arrives as `Text` above.
                // 具名按键原样传递；文本通过上面的 `Text` 到达。
                if let Some(named) = named_key(key) {
                    state.events.push(if pressed {
                        ui_core::Event::KeyPressed { key: named }
                    } else {
                        ui_core::Event::KeyReleased { key: named }
                    });
                }
                state.redraw_requested = true;
            }
            wl_keyboard::Event::Modifiers {
                serial,
                mods_depressed,
                mods_latched,
                mods_locked,
                group,
            } => {
                state.clipboard.note_serial(serial);
                state
                    .input
                    .update_modifiers(mods_depressed, mods_latched, mods_locked, group);
                // Shift_L / Control_L / Alt_L / Super_L keysyms.
                // Shift_L / Control_L / Alt_L / Super_L 的 keysym。
                state.events.push(ui_core::Event::Modifiers(ui_core::Modifiers {
                    shift: state.input.is_held(0xffe1),
                    ctrl: state.input.is_held(0xffe3),
                    alt: state.input.is_held(0xffe9),
                    logo: state.input.is_held(0xffeb),
                }));
            }
            _ => {}
        }
    }
}

impl Dispatch<wp_fractional_scale_v1::WpFractionalScaleV1, ()> for WindowState {
    fn event(
        state: &mut Self,
        _: &wp_fractional_scale_v1::WpFractionalScaleV1,
        event: wp_fractional_scale_v1::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        if let wp_fractional_scale_v1::Event::PreferredScale { scale } = event {
            // The compositor's value is in 120ths of 1.0 by protocol, but the
            // integer encoding used here is quarters so 150 means 1.5.
            // 协议给的是 1.0 的 120 分之一，这里按四分之一存，150 表示 1.5。
            // Protocol scale is in 120ths of 1.0; `scale_quarters` is in 100ths.
            // 协议缩放是 1.0 的 120 分之一；`scale_quarters` 是 100 分之一。
            let quarters = ((scale as f64) * 100.0 / 120.0).round() as u32;
            #[cfg(debug_assertions)]
            if std::env::var_os("UI_WAYLAND_DEBUG").is_some() {
                trace(format_args!("preferred_scale {scale} -> {:.2}x", quarters as f32 / 100.0));
            }
            if quarters != state.scale_quarters {
                state.scale_quarters = quarters.max(100);
                // A scale change needs a full repaint and a buffer resize.
                // 缩放变化需要全量重绘并重建缓冲。
                state.redraw_requested = true;
                state.silent_change = true;
            }
        }
    }
}


impl Dispatch<xdg_wm_base::XdgWmBase, ()> for WindowState {
    fn event(
        _: &mut Self,
        base: &xdg_wm_base::XdgWmBase,
        event: xdg_wm_base::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        if let xdg_wm_base::Event::Ping { serial } = event {
            base.pong(serial);
        }
    }
}

impl Dispatch<xdg_surface::XdgSurface, ()> for WindowState {
    fn event(
        state: &mut Self,
        surface: &xdg_surface::XdgSurface,
        event: xdg_surface::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        if let xdg_surface::Event::Configure { serial } = event {
            surface.ack_configure(serial);
            state.configured = true;
        }
    }
}

impl Dispatch<xdg_toplevel::XdgToplevel, ()> for WindowState {
    fn event(
        state: &mut Self,
        _: &xdg_toplevel::XdgToplevel,
        event: xdg_toplevel::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        match event {
            xdg_toplevel::Event::Configure { width, height, .. } => {
                if width > 0 && height > 0 {
                    state.width = width as u32;
                    state.height = height as u32;
                }
                // A state change (maximised, tiled) is not an `Event` either.
                // 状态变化（最大化、平铺）同样不是一条 `Event`。
                state.silent_change = true;
            }
            xdg_toplevel::Event::Close => {
                ui_platform::exit_probe::stage("toplevel-close");
                state.closed = true
            }
            _ => {}
        }
    }
}

impl Dispatch<zwlr_layer_shell_v1::ZwlrLayerShellV1, ()> for WindowState {
    fn event(
        _: &mut Self,
        _: &zwlr_layer_shell_v1::ZwlrLayerShellV1,
        _: zwlr_layer_shell_v1::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
    }
}

impl Dispatch<zwlr_layer_surface_v1::ZwlrLayerSurfaceV1, ()> for WindowState {
    fn event(
        state: &mut Self,
        surface: &zwlr_layer_surface_v1::ZwlrLayerSurfaceV1,
        event: zwlr_layer_surface_v1::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        match event {
            // A zero axis means "no constraint"; the anchors already decided it.
            // 某个轴为零表示「不约束」；锚点已经决定了。
            zwlr_layer_surface_v1::Event::Configure {
                serial,
                width,
                height,
            } => {
                surface.ack_configure(serial);
                if width > 0 {
                    state.width = width;
                }
                if height > 0 {
                    state.height = height;
                }
                state.configured = true;
            }
            zwlr_layer_surface_v1::Event::Closed => state.closed = true,
            _ => {}
        }
    }
}

impl Dispatch<wl_callback::WlCallback, ()> for WindowState {
    fn event(
        state: &mut Self,
        _: &wl_callback::WlCallback,
        event: wl_callback::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        if let wl_callback::Event::Done { .. } = event {
            // The compositor is ready for another frame.
            // compositor 已准备好接收下一帧。
            state.frame_ready = true;
            state.frame_callbacks += 1;
        }
    }
}

impl Dispatch<wl_pointer::WlPointer, ()> for WindowState {
    fn event(
        state: &mut Self,
        _: &wl_pointer::WlPointer,
        event: wl_pointer::Event,
        _: &(),
        _: &Connection,
        _: &QueueHandle<Self>,
    ) {
        match event {
            wl_pointer::Event::Enter { serial, surface_x, surface_y, .. } => {
                // set_shape is ignored unless this matches the latest enter serial.
                // 除非与最新的 enter serial 一致，否则 set_shape 会被忽略。
                state.pointer_enter_serial = Some(serial);
                // The compositor drops our shape when the pointer leaves, so the cache must
                // not suppress the re-assert on the way back in.
                // 指针离开时 compositor 会丢掉我们的形状，因此缓存不得阻止重新进入时的重申。
                state.cursor_shape = None;
                state.pointer_over = true;
                let p = ui_core::geom::Point::new(surface_x as f32, surface_y as f32);
                state.pointer = Some(p);
                state.input.set_pointer(Some(p));
                state.events.push(ui_core::Event::PointerMoved { pos: p });
                state.redraw_requested = true;
            }
            wl_pointer::Event::Leave { .. } => {
                state.pointer_over = false;
                state.pointer_enter_serial = None;
                state.cursor_shape = None;
                state.pointer = None;
                state.input.set_pointer(None);
                state.events.push(ui_core::Event::PointerLeft);
                state.redraw_requested = true;
            }
            wl_pointer::Event::Motion { surface_x, surface_y, .. } => {
                let p = ui_core::geom::Point::new(surface_x as f32, surface_y as f32);
                state.pointer = Some(p);
                state.input.set_pointer(Some(p));
                state.events.push(ui_core::Event::PointerMoved { pos: p });
                state.redraw_requested = true;
            }
            wl_pointer::Event::Axis { axis, value, .. } => {
                // Both wheels map to their own axis; a plain mouse only sends vertical.
                // 两个轴各自映射；普通鼠标只发垂直轴。
                let delta = match axis {
                    wayland_client::WEnum::Value(wl_pointer::Axis::VerticalScroll) => {
                        Some(ui_core::geom::Point::new(0.0, value as f32))
                    }
                    wayland_client::WEnum::Value(wl_pointer::Axis::HorizontalScroll) => {
                        Some(ui_core::geom::Point::new(value as f32, 0.0))
                    }
                    _ => None,
                };
                if let (Some(delta), Some(pos)) = (delta, state.pointer) {
                    // Wayland reports positive values as scrolling down/right, and our
                    // `delta` means the same, so the sign passes through unchanged.
                    // Wayland 正值表示向下/向右滚动，我们的 `delta` 同义，因此符号不变。
                    state.events.push(ui_core::Event::Scroll { pos, delta });
                    state.redraw_requested = true;
                }
            }
            wl_pointer::Event::Button { button, state: bs, serial, .. } => {
                // A click is a fresh serial, and `set_selection` needs one from our input.
                // 一次点击就是新鲜的 serial，而 `set_selection` 需要来自我们输入的 serial。
                state.clipboard.note_serial(serial);
                // Linux input-event-codes: BTN_LEFT is 0x110; other buttons map by order.
                // Linux input-event-codes：BTN_LEFT 是 0x110；其余按键按顺序对应。
                let which = match button {
                    0x110 => ui_core::PointerButton::Primary,
                    0x111 => ui_core::PointerButton::Secondary,
                    _ => ui_core::PointerButton::Middle,
                };
                let pos = state
                    .pointer
                    .unwrap_or_else(|| ui_core::geom::Point::new(0.0, 0.0));
                let ev = if bs == wayland_client::WEnum::Value(wl_pointer::ButtonState::Pressed) {
                    ui_core::Event::PointerPressed {
                        pos,
                        button: which,
                    }
                } else {
                    ui_core::Event::PointerReleased {
                        pos,
                        button: which,
                    }
                };
                state.events.push(ev);
                state.redraw_requested = true;
            }
            _ => {}
        }
    }
}

/// Map an evdev keycode to the keys the framework names; others stay text-only.
/// 把 evdev 键码映射到框架命名的按键；其余按键只作为文本存在。
fn named_key(evdev: u32) -> Option<ui_core::Key> {
    // Linux input-event-codes.h, the raw codes Wayland delivers (no +8 shift).
    // Linux input-event-codes.h，Wayland 送的是原始码（不加 8）。
    Some(match evdev {
        1 => ui_core::Key::Escape,
        14 => ui_core::Key::Backspace,
        15 => ui_core::Key::Tab,
        28 => ui_core::Key::Enter,
        57 => ui_core::Key::Space,
        102 => ui_core::Key::Home,
        103 => ui_core::Key::Up,
        105 => ui_core::Key::Left,
        106 => ui_core::Key::Right,
        107 => ui_core::Key::End,
        108 => ui_core::Key::Down,
        111 => ui_core::Key::Delete,
        _ => return None,
    })
}

/// A real XDG toplevel; `wl_shm` by default, dma-buf when asked to present one.
/// 真实 XDG 顶层窗口；默认 `wl_shm`，被要求时可呈现 dma-buf。
pub struct WaylandWindow {
    /// Kept alive: dropping the connection closes the window.
    /// 保活：连接一旦丢弃窗口就会关闭。
    _conn: Connection,
    queue: EventQueue<WindowState>,
    state: WindowState,
    qh: QueueHandle<WindowState>,
    surface: wl_surface::WlSurface,
    /// Kept alive so the compositor keeps the toplevel mapped; `None` for a layer surface.
    /// 保活，使 compositor 持续映射该顶层窗口；浮层表面为 `None`。
    _xdg: Option<xdg_surface::XdgSurface>,
    _toplevel: Option<xdg_toplevel::XdgToplevel>,
    /// The layer-shell role, when this surface is an overlay instead of a window.
    /// 本表面是浮层而非窗口时，它的 layer-shell 角色。
    _layer: Option<zwlr_layer_surface_v1::ZwlrLayerSurfaceV1>,
    /// dma-buf factory, when the compositor exposes one. Kept at version <= 3.
    /// compositor 提供时才有 dma-buf 工厂；版本保持在 <= 3。
    dmabuf: Option<ZwpLinuxDmabufV1>,
    /// `wl_buffer`s reused per dma-buf identity; creating one per frame makes the compositor
    /// build and tear down an import object every frame for no reason.
    /// 按 dma-buf 身份复用的 `wl_buffer`；每帧新建会让 compositor 每帧无谓地建立并拆除导入对象。
    dmabuf_cache: HashMap<(u64, u64, u32, u32, u32, u32, u32, u64), DmaBufBuffer>,
    /// Explicit-synchronization objects, present only when the compositor advertises them.
    /// 显式同步对象，仅当 compositor 通告该协议时存在。
    syncobj_manager: Option<WpLinuxDrmSyncobjManagerV1>,
    syncobj_surface: Option<WpLinuxDrmSyncobjSurfaceV1>,
    syncobj_timeline: Option<WpLinuxDrmSyncobjTimelineV1>,
    /// The compositor signals this timeline once it is done reading a frame.
    /// compositor 读完一帧后会在该 timeline 上 signal。
    syncobj_release_timeline: Option<WpLinuxDrmSyncobjTimelineV1>,
    /// Point we ask the compositor to signal on the release timeline; grows every frame.
    /// 每帧递增，请 compositor 在 release timeline 上 signal 的点。
    /// Colour management, when the compositor exposes it.
    /// compositor 提供时才有色彩管理。
    color_manager: Option<wayland_protocols::wp::color_management::v1::client::wp_color_manager_v1::WpColorManagerV1>,
    /// First output; its description carries the real luminances.
    /// 第一个输出；它的描述携带真实亮度。
    output: Option<wayland_client::protocol::wl_output::WlOutput>,
    /// Kept alive while declared: dropping it reverts the surface to sRGB.
    /// 声明期间保活：丢弃它会让 surface 退回 sRGB。
    /// The output's own image description, kept for [`declare_output_description`].
    /// 输出自己的 image description，供 [`declare_output_description`] 使用。
    output_desc: Option<wayland_protocols::wp::color_management::v1::client::wp_image_description_v1::WpImageDescriptionV1>,
    hdr: Option<(
        wayland_protocols::wp::color_management::v1::client::wp_color_management_surface_v1::WpColorManagementSurfaceV1,
        wayland_protocols::wp::color_management::v1::client::wp_image_description_v1::WpImageDescriptionV1,
    )>,
    /// Logical surface size set through the viewport, if fractional scaling is on.
    /// 若启用分数缩放，经 viewport 设置的逻辑表面尺寸。
    viewport: Option<wp_viewport::WpViewport>,
    /// Set when the logical size changed and must be pushed to the viewport.
    /// 逻辑尺寸变化、需要推给 viewport 时置位。
    viewport_dirty: bool,
    /// Logical size last pushed to the viewport.
    /// 最近推给 viewport 的逻辑尺寸。
    viewport_size: (u32, u32),
    /// Double buffering: each slot owns its own pool, so a buffer still held by
    /// the compositor can never be overwritten.
    /// 双缓冲：每个槽位拥有自己的池，compositor 仍持有的缓冲绝不会被覆盖。
    back: Option<ShmBuffer>,
    front: Option<(wl_buffer::WlBuffer, ShmBuffer)>,
    pixels: Pixels,
    config: WindowConfig,
    /// Buffers handed to the compositor, so we can mark them released.
    /// 已交给 compositor 的缓冲，用于标记已释放。
    _inflight: Vec<wl_buffer::WlBuffer>,
    /// Pointer device, kept alive so motion events keep arriving.
    /// 指针设备，保活以持续收到移动事件。
    _pointer: Option<wl_pointer::WlPointer>,
    /// Named-shape device for that pointer, when the compositor supports it.
    /// 该指针的命名形状设备，compositor 支持时才有。
    cursor_device: Option<shape_device::WpCursorShapeDeviceV1>,
    /// Keyboard device, kept alive so key events keep arriving.
    /// 键盘设备，保活以持续收到按键事件。
    _keyboard: Option<wl_keyboard::WlKeyboard>,
    /// Text-input object; absent when the compositor has no input-method protocol.
    /// 文本输入对象；compositor 没有输入法协议时缺失。
    text_input: Option<ZwpTextInputV3>,
    /// IME state the engine asked for on the last frame, and what was last sent.
    /// 引擎上一帧要求的输入法状态，以及上次真正发出的状态。
    ime: Option<ui_platform::present::ImeState>,
    ime_sent: Option<ui_platform::present::ImeState>,
    /// Set when buffers were just reallocated and the back slot must be replaced.
    /// 缓冲刚重新分配、后槽位必须替换时置位。
    pool_fresh: bool,
}

impl Drop for WaylandWindow {
    /// Tear down in protocol order instead of leaving it to the disconnect.
    /// 按协议顺序拆除，而不是留给断开连接去处理。
    ///
    /// An input method left enabled keeps the compositor's IM session alive until it
    /// notices the disconnect; destroying the surface first would strand the buffers.
    /// 输入法留着启用状态时，compositor 的输入法会话要等到发现断开才结束；先销毁表面则会让缓冲悬空。
    fn drop(&mut self) {
        ui_platform::exit_probe::stage("window: ime");
        if let Some(ti) = self.text_input.as_ref() {
            ti.disable();
            ti.commit();
        }
        // Drop the surface's buffer before the proxies: a compositor that still holds a
        // dma-buf at close time may sync on it, and this is the client's only lever there.
        // 在销毁代理之前先放开表面的缓冲：关闭时仍被持有的 dma-buf 可能让 compositor 同步等待，
        // 而这正是客户端唯一能动的地方。
        let keep = std::env::var_os("EXIT_KEEP_BUFFERS").is_some();
        if !std::env::var_os("EXIT_NO_DETACH").is_some() {
            self.surface.attach(None, 0, 0);
            self.surface.commit();
            let _ = self._conn.flush();
        }
        ui_platform::exit_probe::stage("window: buffers");
        if !keep {
            if let Some((buffer, _)) = self.front.take() {
                buffer.destroy();
            }
            for (_, cached) in self.dmabuf_cache.drain() {
                cached.destroy();
            }
            self.state.dmabuf_inflight.clear();
        }
        ui_platform::exit_probe::stage("window: proxies");
        if let Some(t) = self._toplevel.take() {
            t.destroy();
        }
        if let Some(x) = self._xdg.take() {
            x.destroy();
        }
        if let Some(v) = self.viewport.take() {
            v.destroy();
        }
        if let Some(l) = self._layer.take() {
            l.destroy();
        }
        if let Some(ti) = self.text_input.take() {
            ti.destroy();
        }
        ui_platform::exit_probe::stage("window: surface");
        self.surface.clone().destroy();
        let _ = self._conn.flush();
        ui_platform::exit_probe::stage("window: dropped");
    }
}

impl WaylandWindow {
    /// Create and map a normal window, waiting until the compositor configures it.
    /// 创建并映射一个普通窗口，等待 compositor 配置完成。
    pub fn new(config: WindowConfig) -> Result<Self, WindowError> {
        Self::create(config, None)
    }

    /// Create and map a layer surface: no window manager, placed by the compositor.
    /// 创建并映射一个浮层表面：不经窗口管理器，由 compositor 摆放。
    pub fn new_layer(config: WindowConfig, layer: LayerConfig) -> Result<Self, WindowError> {
        Self::create(config, Some(layer))
    }

    fn create(config: WindowConfig, layer: Option<LayerConfig>) -> Result<Self, WindowError> {
        let (conn, mut queue, caps) = crate::conn::connect()?;
        let qh: QueueHandle<WindowState> = queue.handle();
        let crate::conn::Capabilities {
            compositor,
            shm,
            wm_base,
            layer_shell,
            seat,
            data_device_manager,
            cursor_shape,
            viewporter,
            fractional,
            dmabuf,
            syncobj,
            color_manager,
            text_input: text_input_manager,
            output,
        } = caps;

        let mut state = WindowState::new(config.width, config.height);
        state.base = wm_base.clone();

        let surface = compositor.create_surface(&qh, ());
        // The explicit-sync surface is created only once a timeline is attached: creating it
        // first makes every dma-buf commit require an acquire point, which we would not have.
        // 显式同步表面只在 timeline 接上之后才创建：先创建会让每次 dma-buf commit 都要求
        // acquire 点，而我们那时还没有。
        let syncobj_surface = None;
        // Fractional scaling needs a viewport: the buffer is `logical * scale`, and
        // the viewport shrinks it back to the logical size.
        // 分数缩放需要 viewport：缓冲区为 `logical * scale`，viewport 再把它缩回逻辑尺寸。
        let viewport = match (&viewporter, &fractional) {
            (Some(vp), Some(fs)) => {
                let viewport = vp.get_viewport(&surface, &qh, ());
                let _scale = fs.get_fractional_scale(&surface, &qh, ());
                // Buffer scale stays 1 under fractional scaling.
                // 分数缩放下缓冲区缩放保持 1。
                surface.set_buffer_scale(1);
                Some(viewport)
            }
            _ => {
                // Integer fallback: ask the compositor for an integer buffer scale.
                // 整数回退：向 compositor 请求整数缓冲区缩放。
                surface.set_buffer_scale(1);
                None
            }
        };
        let (xdg, toplevel, layer_surface) = match layer {
            None => {
                let wm = wm_base
                    .clone()
                    .ok_or(WindowError::MissingGlobal("xdg_wm_base"))?;
                let xdg = wm.get_xdg_surface(&surface, &qh, ());
                let toplevel = xdg.get_toplevel(&qh, ());
                toplevel.set_title(config.title.clone());
                toplevel.set_app_id(config.app_id.clone());
                (Some(xdg), Some(toplevel), None)
            }
            Some(cfg) => {
                let shell = layer_shell
                    .clone()
                    .ok_or(WindowError::MissingGlobal("zwlr_layer_shell_v1"))?;
                let surface_role = shell.get_layer_surface(
                    &surface,
                    output.as_ref(),
                    match cfg.layer {
                        Layer::Background => zwlr_layer_shell_v1::Layer::Background,
                        Layer::Bottom => zwlr_layer_shell_v1::Layer::Bottom,
                        Layer::Top => zwlr_layer_shell_v1::Layer::Top,
                        Layer::Overlay => zwlr_layer_shell_v1::Layer::Overlay,
                    },
                    cfg.namespace.clone(),
                    &qh,
                    (),
                );
                // Zero means "whatever the anchors leave"; the configure carries the answer.
                // 零表示「锚点剩下多少算多少」；答案在 configure 里。
                let (w, h) = cfg.size.unwrap_or((0, 0));
                surface_role.set_size(w, h);
                let mut anchor = zwlr_layer_surface_v1::Anchor::empty();
                anchor.set(zwlr_layer_surface_v1::Anchor::Top, cfg.anchor.top);
                anchor.set(zwlr_layer_surface_v1::Anchor::Bottom, cfg.anchor.bottom);
                anchor.set(zwlr_layer_surface_v1::Anchor::Left, cfg.anchor.left);
                anchor.set(zwlr_layer_surface_v1::Anchor::Right, cfg.anchor.right);
                surface_role.set_anchor(anchor);
                surface_role.set_exclusive_zone(cfg.exclusive_zone);
                surface_role.set_keyboard_interactivity(if cfg.keyboard {
                    zwlr_layer_surface_v1::KeyboardInteractivity::Exclusive
                } else {
                    zwlr_layer_surface_v1::KeyboardInteractivity::None
                });
                (None, None, Some(surface_role))
            }
        };
        surface.commit();

        // Wait for the first configure so the size is known before allocating.
        // 等待首次 configure，先拿到尺寸再分配缓冲。
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(5);
        while !state.configured {
            if std::time::Instant::now() > deadline {
                return Err(WindowError::Protocol("configure timeout".into()));
            }
            queue
                .blocking_dispatch(&mut state)
                .map_err(|e| WindowError::Protocol(e.to_string()))?;
        }

        // Grab a pointer for hover feedback.
        // 取出指针以提供悬停反馈。
        let mut pointer: Option<wl_pointer::WlPointer> = None;
        let mut keyboard: Option<wl_keyboard::WlKeyboard> = None;
        let mut text_input: Option<ZwpTextInputV3> = None;
        if let Some(seat) = seat {
            pointer = Some(seat.get_pointer(&qh, ()));
            keyboard = Some(seat.get_keyboard(&qh, ()));
            // Text input is per seat, like the keyboard it replaces.
            // 文本输入与它替代的键盘一样，是按 seat 的。
            text_input = text_input_manager.map(|m| m.get_text_input(&seat, &qh, ()));
            // The clipboard is per seat too: one data device carries its selection.
            // 剪贴板同样按 seat：一个数据设备承载它的选区。
            if let Some(manager) = data_device_manager {
                let device = manager.get_data_device(&seat, &qh, ());
                state.clipboard.attach(manager, device);
            }
        }
        // The shape device is bound to a specific pointer, so it follows that pointer.
        // 形状设备绑定到具体指针对象，因此跟随该指针。
        let cursor_device = match (cursor_shape, pointer.as_ref()) {
            (Some(manager), Some(p)) => Some(manager.get_pointer(p, &qh, ())),
            _ => None,
        };

        let (w, h) = (state.width, state.height);
        let pixels = Pixels::new(w, h);
        let back = ShmBuffer::new(&shm, &qh, w, h).ok_or(WindowError::Buffer)?;

        // A roundtrip delivers the keyboard's initial keymap before returning, so
        // callers can type on the very first frame.
        // 一次往返会先取回键盘的初始键位表，调用方第一帧就能输入。
        queue
            .roundtrip(&mut state)
            .map_err(|e| WindowError::Protocol(e.to_string()))?;

        let mut win = Self {
            color_manager,
            output,
            output_desc: None,
            hdr: None,
            _conn: conn,
            queue,
            state,
            qh,
            surface,
            _xdg: xdg,
            _toplevel: toplevel,
            _layer: layer_surface,
            dmabuf,
            dmabuf_cache: HashMap::new(),
            syncobj_manager: syncobj,
            syncobj_surface,
            syncobj_timeline: None,
            syncobj_release_timeline: None,
            viewport,
            viewport_dirty: true,
            viewport_size: (0, 0),
            back: Some(back),
            front: None,
            pixels,
            config,
            _inflight: Vec::new(),
            _pointer: pointer,
            _keyboard: keyboard,
            text_input,
            ime: None,
            ime_sent: None,
            cursor_device,
            pool_fresh: false,
        };
        win.state.shm = Some(shm);
        win.resize_with_callback();
        Ok(win)
    }

    pub fn config(&self) -> &WindowConfig {
        &self.config
    }

    /// Drain input events collected since the last call, in arrival order.
    /// 按到达顺序取走上一次调用以来收集的输入事件。
    ///
    /// Reads the socket first: intake must not depend on the pacing wait, or a loop that
    /// never blocks (uncapped frames) sees no input at all.
    /// 先读 socket：事件摄入不能取决于配速等待，否则从不阻塞的循环（取消帧率上限）完全收不到输入。
    pub fn take_events(&mut self) -> Vec<ui_core::Event> {
        let _ = self.drain_events();
        std::mem::take(&mut self.state.events)
    }

    /// Pointer position, when the pointer is over the surface.
    /// 指针位置（指针在表面内时）。
    pub fn pointer(&self) -> Option<ui_core::geom::Point> {
        // Leaving the surface must clear it, or hover sticks forever after the pointer goes.
        // 离开表面必须清空，否则指针走后悬停会一直粘住。
        if self.state.pointer_over {
            self.state.pointer
        } else {
            None
        }
    }

    pub fn should_close(&self) -> bool {
        self.state.closed
    }

    /// Close the window the way the compositor's Close event does, for scripted exit tests.
    /// 按 compositor 的 Close 事件那样关闭窗口，供脚本化的退出测试使用。
    pub fn request_close(&mut self) {
        ui_platform::exit_probe::stage("requested-close");
        self.state.closed = true;
    }

    /// Typed characters since the last call.
    /// 上次调用以来输入的字符。
    pub fn take_typed(&mut self) -> Vec<char> {
        self.state.input.take_typed()
    }

    /// Whether the compositor's keymap has been installed.
    /// compositor 的键位表是否已安装。
    pub fn has_keymap(&self) -> bool {
        self.state.input.has_keymap()
    }

    /// The output's refresh rate, when the compositor declared one.
    /// compositor 声明过时，输出的刷新率。
    ///
    /// This is the pacing ground truth: measuring "commit until the callback" instead gives
    /// about half a period, because the callback lands on the next boundary, not a period later.
    /// 这是配速的基准：改量「commit 到回调」只会得到约半个周期，因为回调落在下一个边界上，
    /// 而不是整整一个周期之后。
    pub fn refresh_hz(&self) -> Option<f32> {
        (self.state.refresh_mhz > 0).then(|| self.state.refresh_mhz as f32 / 1000.0)
    }

    /// Whether focus, IME focus, output scale or window state changed since the last call.
    /// 自上次调用以来焦点、输入法焦点、输出缩放或窗口状态是否变化。
    ///
    /// These carry no `ui_core::Event`, so a loop that skips rebuilds on unchanged input
    /// would otherwise show a stale focus ring until unrelated input arrived.
    /// 它们不带 `ui_core::Event`；按输入未变而跳过重建的循环，否则要等到无关输入到来
    /// 才会更新焦点环。
    pub fn take_silent_change(&mut self) -> bool {
        std::mem::take(&mut self.state.silent_change)
    }

    /// Whether something asked for a repaint.
    /// 是否有东西请求了重绘。
    pub fn redraw_requested(&self) -> bool {
        self.state.redraw_requested
    }

    /// Current fractional scale (for example 1.5).
    /// 当前分数缩放（例如 1.5）。
    pub fn scale(&self) -> f32 {
        self.state.scale_quarters as f32 / 100.0
    }

    /// Logical surface size in points; buffers are larger by `scale()`.
    /// 逻辑表面尺寸（point）；缓冲区比它大 `scale()` 倍。
    pub fn logical_size(&self) -> (u32, u32) {
        (self.state.width, self.state.height)
    }

    /// Whether another frame may be drawn right now.
    /// 当前是否可以再画一帧。
    pub fn can_draw(&self) -> bool {
        self.state.frame_ready
    }

    /// Frame callbacks since the last call: the rate the compositor is actually offering.
    /// 自上次调用以来送达的帧回调数：compositor 实际给出的速率。
    ///
    /// When this is below the output's refresh, the loop is not the limiter.
    /// 它低于输出刷新率时，限制不在循环这一侧。
    pub fn take_frame_callbacks(&mut self) -> u32 {
        std::mem::take(&mut self.state.frame_callbacks)
    }

    /// Whether the compositor exposes `zwp_linux_dmabuf_v1`.
    /// compositor 是否提供 `zwp_linux_dmabuf_v1`。
    pub fn has_dmabuf(&self) -> bool {
        self.dmabuf.is_some()
    }

    /// Bound `zwp_linux_dmabuf_v1` version, if the global exists.
    /// 若全局存在，`zwp_linux_dmabuf_v1` 的绑定版本。
    /// Declare the surface with the output's **own** description.
    /// 用输出**自己的**描述声明该 surface。
    ///
    /// A constructed description claims a 10000-nit peak, so the compositor tone-maps it
    /// down to the panel and darkens everything; reusing the output's description leaves
    /// it nothing to map.
    /// 构造的描述声明 10000 nit 峰值，compositor 会把它压缩到面板能力并压暗全部内容；
    /// 复用输出的描述则没有需要映射的东西。
    pub fn declare_output_description(&mut self) -> bool {
        let Some(desc) = self.output_desc.clone() else {
            return false;
        };
        let Some(manager) = self.color_manager.clone() else {
            return false;
        };
        let qh = self.qh.clone();
        let cm = manager.get_surface(&self.surface, &qh, ());
        cm.set_image_description(
            &desc,
            wayland_protocols::wp::color_management::v1::client::wp_color_manager_v1::RenderIntent::Perceptual,
        );
        let _ = self.queue.roundtrip(&mut self.state);
        self.hdr = Some((cm, desc));
        true
    }

    /// Declare the surface as PQ / BT.2020, converting the content to match.
    /// 把 surface 声明为 PQ / BT.2020，并把内容转换到该基色。
    ///
    /// The output's preferred description reports tf=st2084_pq, primaries=bt2020; declaring
    /// sRGB primaries made the compositor read our values in the wider gamut.
    /// 输出端的首选描述是 tf=st2084_pq、primaries=bt2020；声明 sRGB 基色会让
    /// compositor 用更宽的色域解释我们的数值。
    pub fn declare_pq(&mut self, min_lum: u32, reference_lum: u32) -> bool {
        use wayland_protocols::wp::color_management::v1::client::wp_color_manager_v1::{
            Primaries, TransferFunction,
        };
        let Some(manager) = self.color_manager.clone() else {
            return false;
        };
        let qh = self.qh.clone();
        // Features arrive on the first round-trip after binding; without them the
        // creator requests below are protocol errors.
        // feature 在绑定后的第一轮往返到达；没有它们，下面的创建请求都是协议错误。
        let _ = self.queue.roundtrip(&mut self.state);
        let features = self.state.colour_features;
        if features & (1 << 1) == 0 {
            return false;
        }
        let creator = manager.create_parametric_creator(&qh, ());
        creator.set_tf_named(TransferFunction::St2084Pq);
        creator.set_primaries_named(Primaries::Bt2020);
        if features & (1 << 4) != 0 {
            // min_lum is scaled by 10000 on the wire; max and reference are not.
            // min_lum 在协议上放大 10000 倍；max 与 reference 不缩放。
            creator.set_luminances(min_lum * 10_000, min_lum + 10_000, reference_lum);
        }
        let desc = creator.create(&qh, ());
        // The description is only usable after `done`; attach before that is ignored.
        // 描述只有在 `done` 之后可用；之前挂上会被忽略。
        let _ = self.queue.roundtrip(&mut self.state);
        if self.state.colour_failed.is_some() {
            return false;
        }
        // Ask for information on a description *we* created; the preferred one is
        // rejected with `no_information` here, so only this path is enabled.
        // 对我们自己创建的描述索取信息；本机上首选描述会被 `no_information` 拒绝，
        // 因此只开这条路径。
        self.state.preferred_luminances = None;
        self.state.allow_info = true;
        let _ = self.queue.roundtrip(&mut self.state);
        let _ = self.queue.roundtrip(&mut self.state);
        trace(format_args!(
            "own description info: {:?} failed={:?}",
            self.state.preferred_luminances, self.state.colour_failed
        ));

        self.state.allow_info = false;
        let cm = manager.get_surface(&self.surface, &qh, ());
        cm.set_image_description(
            &desc,
            wayland_protocols::wp::color_management::v1::client::wp_color_manager_v1::RenderIntent::Perceptual,
        );
        let _ = self.queue.roundtrip(&mut self.state);
        self.hdr = Some((cm, desc));
        true
    }

    /// Read luminances from the **output** description, the path the old project used.
    /// 从**输出**描述读取亮度，即旧项目使用的那条路径。
    pub fn output_luminances(&mut self) -> Option<(u32, u32, u32)> {
        let manager = self.color_manager.clone()?;
        let output = self.output.clone()?;
        let qh = self.qh.clone();
        let cm_out = manager.get_output(&output, &qh, ());
        let desc = cm_out.get_image_description(&qh, ());
        self.state.preferred_luminances = None;
        self.state.allow_info = true;
        let _ = self.queue.roundtrip(&mut self.state);
        let _ = self.queue.roundtrip(&mut self.state);
        self.state.allow_info = false;
        let out = self.state.preferred_luminances;
        trace(format_args!(
            "output prefers tf={:?} primaries={:?}",
            self.state.preferred_tf, self.state.preferred_primaries
        ));
        // Keep the description: setting it verbatim on the surface is what makes a
        // capture-paste round trip exact, since the compositor then has nothing to map.
        // 保留描述：把它原样设给 surface 才能让「捕获后贴回」精确，
        // 因为此时 compositor 没有任何东西需要映射。
        self.output_desc = Some(desc);
        cm_out.destroy();
        out
    }

    /// Reference white in nits: explicit override, then the output, then the protocol default.
    /// 参考白（nit）：显式覆盖，其次输出，最后协议默认值。
    pub fn reference_nits(&mut self) -> (u32, &'static str) {
        if let Ok(v) = std::env::var("CRABSNAP_REFERENCE_NITS")
            && let Ok(n) = v.parse::<u32>() {
                return (n, "env");
            }
        match self.output_luminances() {
            Some((_, _, reference)) if reference > 0 => (reference, "output"),
            _ => (80, "default"),
        }
    }

    /// Ask the compositor what this surface should look like, and read its luminances.
    /// 询问 compositor 该 surface 应是什么样，并读出它的亮度。
    ///
    /// The returned reference white is the anchor every description must agree on.
    /// 返回的参考白是所有描述必须对齐的锚点。
    pub fn preferred_luminances(&mut self) -> Option<(u32, u32, u32)> {
        let manager = self.color_manager.clone()?;
        let qh = self.qh.clone();
        let feedback = manager.get_surface_feedback(&self.surface, &qh, ());
        let desc = feedback.get_preferred(&qh, ());
        trace(format_args!(
            "colour versions: manager={} feedback={} description={}",
            wayland_client::Proxy::version(&manager),
            wayland_client::Proxy::version(&feedback),
            wayland_client::Proxy::version(&desc)
        ));
        self.state.preferred_luminances = None;
        // First trip delivers ready; details arrive on the next trip.
        // 第一次往返送出 ready；细节要下一次往返才到。
        let _ = self.queue.roundtrip(&mut self.state);
        let _ = self.queue.roundtrip(&mut self.state);
        let out = self.state.preferred_luminances;
        if out.is_none() {
            trace(format_args!("preferred unavailable, failed={:?}", self.state.colour_failed));
        }
        desc.destroy();
        feedback.destroy();
        out
    }

    /// Matrix converting our sRGB content into the output's own gamut, row-major.
    /// 把我们的 sRGB 内容转到输出自身色域的矩阵，行主序。
    pub fn output_gamut_matrix(&self) -> [[f32; 3]; 3] {
        let target = self
            .state
            .preferred_chromaticities
            .unwrap_or(ui_core::colour::Chromaticities::BT2020);
        // Measured: with Bradford the HDR and SDR paths match to 1/255 in one channel,
        // so this compositor does not adapt white points itself. Kept switchable as a
        // control variable for other compositors.
        // 实测：开启 Bradford 后 HDR 与 SDR 只差 1/255（单通道），说明本机 compositor
        // 自己不做白点适配。仍保留开关，供其他 compositor 作为控制变量。
        let mode = if std::env::var("CRABSNAP_NO_WHITE_ADAPT").is_ok() {
            ui_core::colour::WhiteAdaptation::None
        } else {
            ui_core::colour::WhiteAdaptation::Bradford
        };
        ui_core::colour::gamut_matrix_adapted(
            ui_core::colour::Chromaticities::SRGB,
            target,
            mode,
        )
    }

    /// Whether colour management was available at all.
    /// 色彩管理是否可用。
    pub fn has_color_management(&self) -> bool {
        self.color_manager.is_some()
    }

    pub fn dmabuf_version(&self) -> Option<u32> {
        self.dmabuf.as_ref().map(|d| d.version())
    }

    /// Format/modifier pairs the compositor advertised for dma-buf import.
    /// compositor 为 dma-buf 导入通告的 format/modifier 组合。
    pub fn dmabuf_formats(&self) -> &DmaBufFormats {
        &self.state.dmabuf_formats
    }

    /// dma-buf buffers the compositor has released so far.
    /// compositor 迄今已释放的 dma-buf 缓冲数。
    pub fn dmabuf_releases(&self) -> u32 {
        self.state.dmabuf_released
    }

    /// dma-buf imports the compositor has rejected so far.
    /// compositor 迄今拒绝的 dma-buf 导入数。
    pub fn dmabuf_rejections(&self) -> u32 {
        self.state.dmabuf_rejected
    }

    /// dma-buf buffers still held by the compositor.
    /// compositor 仍持有的 dma-buf 缓冲数。
    pub fn dmabuf_inflight(&self) -> usize {
        self.state.dmabuf_inflight.len()
    }

    /// Mark that the UI changed and wants a redraw.
    /// 标记 UI 变化、希望重绘。
    pub fn request_redraw(&mut self) {
        self.state.redraw_requested = true;
    }

    /// Block until the compositor reports the frame callback done.
    /// 阻塞直到 compositor 报告帧回调完成。
    pub fn wait_for_frame(&mut self) {
        let deadline = std::time::Instant::now() + std::time::Duration::from_millis(500);
        while !self.state.frame_ready {
            // A closing toplevel gets no more callbacks: waiting for one would hold the
            // close for the whole deadline, which is exactly what a slow exit looked like.
            // 正在关闭的顶层不再有帧回调：等它会把关闭拖满整个截止时间，这正是"退出慢"的样子。
            if self.state.closed {
                return;
            }
            let now = std::time::Instant::now();
            if now >= deadline {
                // A compositor that never answers must not deadlock the app.
                // 从不回应的 compositor 不能把应用卡死。
                self.state.frame_ready = true;
                break;
            }
            // Poll, never `blocking_dispatch`: that one sits in `read` until *some* event
            // arrives, so an omitted frame callback would hold the app past every deadline.
            // 用 poll 而不是 `blocking_dispatch`：后者会一直读等到有事件为止，
            // 一旦帧回调没来，任何截止时间都轮不到检查。
            self.poll_once(deadline - now);
            // A paste read can finish while a frame is in flight.
            // 帧在飞的时候，一次粘贴的读取也可能完成。
            self.service_clipboard();
        }
    }

    /// Pump pending events without blocking.
    /// 非阻塞地处理待处理事件。
    pub fn pump(&mut self) {
        let _ = self.drain_events();
    }

    /// Pump pending events, surfacing protocol errors instead of discarding them.
    /// 处理待处理事件，并暴露协议错误而不是丢弃它们。
    pub fn pump_checked(&mut self) -> Result<(), WindowError> {
        self.drain_events()
    }

    /// Read what the socket already holds, then dispatch it; never block.
    /// 读取 socket 中已有的事件再分发；绝不阻塞。
    fn drain_events(&mut self) -> Result<(), WindowError> {
        let protocol = |e: String| WindowError::Protocol(e);
        self.queue
            .dispatch_pending(&mut self.state)
            .map_err(|e| protocol(e.to_string()))?;
        // `dispatch_pending` never reads the socket; only `blocking_dispatch` does.
        // `dispatch_pending` 从不读 socket；只有 `blocking_dispatch` 会读。
        if let Some(guard) = self.queue.prepare_read() {
            match guard.read() {
                Ok(_) => {}
                Err(wayland_client::backend::WaylandError::Io(e))
                    if e.kind() == std::io::ErrorKind::WouldBlock => {}
                Err(e) => return Err(protocol(e.to_string())),
            }
        }
        self.queue
            .dispatch_pending(&mut self.state)
            .map_err(|e| protocol(e.to_string()))?;
        self.queue.flush().map_err(|e| protocol(e.to_string()))
    }

    /// Apply the shape the frame resolved. Returns whether anything was sent.
    /// 应用本帧解析出的形状。返回是否真的发出了请求。
    ///
    /// Flushed immediately: a still pointer produces no further events to carry the
    /// request, so waiting for the next dispatch would leave the shape one step late.
    /// 立即 flush：指针静止时没有后续事件捎带请求，等下次派发会让形状慢一步。
    pub fn set_cursor(&mut self, shape: CursorShape) -> bool {
        let Some(device) = self.cursor_device.as_ref() else {
            return false;
        };
        let Some(serial) = self.state.pointer_enter_serial else {
            return false;
        };
        if self.state.cursor_shape == Some(shape) {
            return false;
        }
        device.set_shape(serial, crate::cursor_shape::protocol_shape(shape));
        self.state.cursor_shape = Some(shape);
        let _ = self._conn.flush();
        true
    }

    /// Remember the IME state the engine resolved; it is sent with the next frame's commit.
    /// 记下引擎解析出的输入法状态；随下一帧的提交一起发出。
    pub fn set_ime(&mut self, state: ui_platform::present::ImeState) {
        self.ime = Some(state);
    }

    /// Whether the compositor still needs this frame's IME state committed.
    /// compositor 是否还需要本帧输入法状态的那次提交。
    ///
    /// A focus re-entry counts even when nothing changed: the compositor forgot the session.
    /// 焦点重新进入也算，即使状态没变：compositor 已经把会话忘掉了。
    ///
    /// Outside a session nothing is owed: there is no surface to send it for.
    /// 会话之外没有待发的东西：没有表面可供发送。
    pub fn ime_pending(&self) -> bool {
        self.state.ime_entered
            && (self.state.ime_reenter || self.ime.as_ref() != self.ime_sent.as_ref())
    }

    /// Send the IME state, if it changed, in the same batch as the surface commit.
    /// 状态有变时发出，且与 surface commit 同一批。
    ///
    /// Enabling always resends surrounding, content type and cursor rectangle: `enable`
    /// resets the compositor's copy, so a diff alone would leave it with stale values.
    /// 启用时总是重发 surrounding、内容类型与光标矩形：`enable` 会重置 compositor 的副本，
    /// 只发增量会让它留着旧值。
    fn apply_ime(&mut self) {
        // Outside a session nothing may be sent: `enable` before the compositor's `enter` is
        // a protocol violation, and a stale one hands it the keyboard with no owner.
        // 会话之外什么都不发：在 compositor 的 `enter` 之前 `enable` 违反协议，
        // 而过期的那一次会让它在没有归属表面时拿走键盘。
        if !self.state.ime_entered {
            return;
        }
        let Some(state) = self.ime.clone() else {
            return;
        };
        // A fresh focus ends the compositor's session but leaves its own "enabled" flag set,
        // and it reactivates the input method only on a real transition — so the old session
        // is closed first, or the re-enable would be a no-op and CJK would stay dead.
        // 新的焦点会结束 compositor 的会话，却留着它自己的“已启用”标志，而它只在真正的
        // 状态跳变时重新激活输入法——所以先结束旧会话，否则重发 `enable` 是空操作、CJK 不工作。
        if std::mem::take(&mut self.state.ime_reenter) {
            if self.ime_sent.as_ref().is_some_and(|sent| sent.enabled)
                && let Some(ti) = self.text_input.as_ref() {
                    ti.disable();
                    ti.commit();
                }
            self.ime_sent = None;
        }
        if self.ime_sent.as_ref() == Some(&state) {
            return;
        }
        let Some(ti) = self.text_input.as_ref() else {
            return;
        };
        let was_enabled = self.ime_sent.as_ref().is_some_and(|s| s.enabled);
        if state.enabled {
            // Rule 1: never enable without a caret rectangle from this very frame.
            // 规则一：没有本帧算出的插入符矩形就绝不启用。
            let Some(rect) = state.cursor else {
                return;
            };
            if !was_enabled {
                // `enable` starts a fresh session that resets everything, so it goes first
                // and the state below follows in a second commit.
                // `enable` 开启一个会重置一切的新会话，因此先发它，下面的状态在第二次提交里补上。
                ti.enable();
                ti.commit();
            }
            // Surrounding text and content type only when they changed (or on enable):
            // resending the surrounding text on every preedit character makes the input
            // method re-sync its composition on each keystroke.
            // surrounding 与内容类型只在变化时（或启用时）发送：
            // 每个预编辑字符都重发 surrounding 会让输入法每敲一下都重新同步组合。
            let changed = self.ime_sent.as_ref().map(|p| p.surrounding.as_ref()) != Some(state.surrounding.as_ref());
            if (!was_enabled || changed)
                && let Some((text, caret, anchor)) = &state.surrounding {
                    ti.set_surrounding_text(text.clone(), *caret as i32, *anchor as i32);
                }
            if !was_enabled {
                ti.set_content_type(
                    zwp_text_input_v3::ContentHint::None,
                    zwp_text_input_v3::ContentPurpose::Normal,
                );
            }
            ti.set_cursor_rectangle(
                rect.origin.x.round() as i32,
                rect.origin.y.round() as i32,
                rect.size.w.max(1.0).round() as i32,
                rect.size.h.max(1.0).round() as i32,
            );
        } else {
            ti.disable();
        }
        // A disable needs its commit too; without one the compositor keeps the old state.
        // 禁用同样需要提交；漏发会让 compositor 保留旧状态。
        ti.commit();
        self.ime_sent = Some(state);
    }

    /// Offer `text` as the seat's selection. Returns whether the compositor took it.
    /// 把 `text` 作为座位选区提供出去。返回 compositor 是否接受。
    pub fn write_clipboard(&mut self, text: &str) -> bool {
        self.state.clipboard.copy(text, &self._conn, &self.qh)
    }

    /// Ask the seat's selection for its text; it arrives as `Event::Paste`.
    /// 向座位选区索要文本；结果以 `Event::Paste` 到达。
    pub fn request_paste(&mut self) -> bool {
        self.state.clipboard.request_paste(&self._conn)
    }

    /// Move clipboard pipes forward, queueing a finished paste as an event.
    /// 推进剪贴板管道，把读完的粘贴排成事件。
    fn service_clipboard(&mut self) {
        if let Some(text) = self.state.clipboard.service() {
            self.state.events.push(ui_core::Event::Paste(text));
            self.state.redraw_requested = true;
        }
    }

    /// Block until at least one event arrives.
    /// 阻塞直到至少一个事件到达。
    ///
    /// A pending clipboard pipe must be polled alongside the socket, or a paste would
    /// wait for unrelated input before its bytes are read.
    /// 未完成的剪贴板管道必须与 socket 一起 poll，否则粘贴要等到无关输入才读到字节。
    pub fn wait(&mut self) {
        let _ = self.wait_until(None);
    }

    /// Block until an event arrives or `timeout` passes; true when events are waiting.
    /// 阻塞到有事件到达或 `timeout` 到期；有事件在等时返回真。
    ///
    /// Bounded even with no deadline given: an app-owned deadline can only be noticed
    /// between frames, and an unbounded read would swallow it until unrelated input.
    /// 即使没给截止时间也设上限：应用自己的截止时间只能在帧与帧之间被发现，
    /// 无界的读会把它一直吞到下一次无关输入。
    pub fn wait_until(&mut self, timeout: Option<std::time::Duration>) -> bool {
        let cap = std::time::Duration::from_millis(250);
        let mut timeout = timeout.unwrap_or(cap).min(std::time::Duration::from_secs(1));
        if let Some(t) = self.state.clipboard.timeout() {
            timeout = timeout.min(t);
        }
        self.poll_once(timeout);
        self.service_clipboard();
        let _ = self.drain_events();
        !self.state.events.is_empty()
    }

    /// Sleep at most `timeout`, waking for either the socket or a clipboard pipe.
    /// 最多睡 `timeout`，socket 或剪贴板管道任一就绪即醒。
    fn poll_once(&mut self, timeout: std::time::Duration) {
        let Some(guard) = self.queue.prepare_read() else {
            return;
        };
        let conn_fd = guard.connection_fd();
        let pipes = self.state.clipboard.fds();
        let mut fds: Vec<rustix::event::PollFd<'_>> = Vec::with_capacity(1 + pipes.len());
        fds.push(rustix::event::PollFd::from_borrowed_fd(
            conn_fd,
            rustix::event::PollFlags::IN,
        ));
        for (fd, write) in &pipes {
            let want = if *write {
                rustix::event::PollFlags::OUT
            } else {
                rustix::event::PollFlags::IN
            };
            fds.push(rustix::event::PollFd::from_borrowed_fd(*fd, want));
        }
        let deadline = rustix::event::Timespec {
            tv_sec: timeout.as_secs() as i64,
            tv_nsec: timeout.subsec_nanos() as i64,
        };
        let ready = rustix::event::poll(&mut fds, Some(&deadline)).unwrap_or(0);
        let conn_ready = ready > 0 && fds[0].revents() != rustix::event::PollFlags::empty();
        drop(fds);
        // Dropping the guard cancels the read; the socket keeps its bytes for `drain_events`.
        // 丢弃 guard 即取消读取；socket 里的字节留给 `drain_events`。
        drop(guard);
        if conn_ready {
            let _ = self.drain_events();
        }
    }

    /// Allocate fresh buffers when the compositor changed the size.
    /// compositor 改变尺寸时重新分配缓冲。
    fn resize_with_callback(&mut self) {
        // Buffers are logical size * scale; the UI itself lays out in logical units.
        // 缓冲区为逻辑尺寸 × 缩放；UI 本身按逻辑单位布局。
        let (lw, lh) = (self.state.width, self.state.height);
        let scale = self.scale();
        let (w, h) = device_size((lw, lh), scale);
        if w == self.pixels.width && h == self.pixels.height {
            return;
        }
        self.pixels = Pixels::new(w, h);
        // Old buffers belong to the previous size; drop them and make two fresh ones.
        // 旧缓冲属于旧尺寸；丢弃并新建两块。
        self.front = None;
        self.back = self
            .state
            .shm
            .as_ref()
            .and_then(|shm| ShmBuffer::new(shm, &self.qh, w, h));
        self.pool_fresh = true;
    }

    /// Map a scale-times-larger buffer back onto the logical surface size.
    /// 把放大 `scale` 倍的缓冲区映射回逻辑表面尺寸。
    fn push_viewport(&mut self) {
        if let Some(viewport) = &self.viewport {
            let target = (self.state.width, self.state.height);
            if self.viewport_dirty || self.viewport_size != target {
                viewport.set_destination(target.0 as i32, target.1 as i32);
                self.viewport_size = target;
                self.viewport_dirty = false;
            }
        }
    }

    /// Drop the cached buffers: a fresh dma-buf allocation can reuse a released inode.
    /// 丢弃缓存的缓冲：新分配的 dma-buf 可能复用已释放的 inode。
    pub fn forget_dmabuf_cache(&mut self) {
        for (_, cached) in self.dmabuf_cache.drain() {
            cached.destroy();
        }
    }

    /// Hand over the acquire and release timeline fds; both are required by the protocol.
    /// 交出 acquire 与 release 两个 timeline fd；协议要求两者成对。
    pub fn attach_sync_timelines(
        &mut self,
        acquire_fd: std::os::fd::OwnedFd,
        release_fd: std::os::fd::OwnedFd,
    ) -> bool {
        let Some(mgr) = self.syncobj_manager.as_ref() else {
            return false;
        };
        let acquire = mgr.import_timeline(acquire_fd.as_fd(), &self.qh, ());
        let release = mgr.import_timeline(release_fd.as_fd(), &self.qh, ());
        let surface = mgr.get_surface(&self.surface, &self.qh, ());
        self.syncobj_timeline = Some(acquire);
        self.syncobj_release_timeline = Some(release);
        self.syncobj_surface = Some(surface);
        true
    }

    /// Present an existing dma-buf image for the next frame instead of the shm pixels.
    /// 下一帧改为呈现已有的 dma-buf 图像，而不是 shm 像素。
    pub fn present_dmabuf(
        &mut self,
        image: &DmaBufImage,
        damage: &Damage,
        acquire_point: Option<u64>,
        release_point: u64,
    ) -> Result<(), WindowError> {
        let Some(dmabuf) = self.dmabuf.as_ref() else {
            return Err(WindowError::DmaBuf(DmaBufError::Unavailable));
        };
        // Reuse one `wl_buffer` per dma-buf: the compositor imports the buffer object once
        // instead of rebuilding it every frame.
        // 每个 dma-buf 复用一个 `wl_buffer`：compositor 只导入一次缓冲对象，而不是每帧重建。
        let (dev, ino) = dmabuf::image_identity(image)
            .ok_or(WindowError::DmaBuf(DmaBufError::Fd))?;
        let key = (
            dev,
            ino,
            image.width,
            image.height,
            image.stride,
            image.offset,
            image.format,
            image.modifier,
        );
        let buffer = match self.dmabuf_cache.get(&key) {
            Some(cached) => cached.buffer().clone(),
            None => {
                let created =
                    dmabuf::create_dmabuf_buffer(dmabuf, &self.state.dmabuf_formats, image, &self.qh)
                        .map_err(WindowError::DmaBuf)?;
                let handle = created.buffer().clone();
                self.dmabuf_cache.insert(key, created);
                handle
            }
        };
        self.push_viewport();
        // Logical rects scale into buffer pixels; a partial frame must still report some
        // damage or the compositor keeps the old pixels there.
        // 逻辑矩形按缩放换算成缓冲像素；部分帧仍必须上报，否则合成器会保留旧像素。
        let s = self.scale();
        let full = ui_core::geom::Rect::new(
            0.0,
            0.0,
            image.width as f32 / s,
            image.height as f32 / s,
        );
        let mut reported = false;
        for r in damage.rects(full) {
            let x = (r.origin.x * s).floor() as i32;
            let y = (r.origin.y * s).floor() as i32;
            let w = (r.size.w * s).ceil() as i32;
            let h = (r.size.h * s).ceil() as i32;
            if w <= 0 || h <= 0 {
                continue;
            }
            self.surface.damage_buffer(x, y, w, h);
            reported = true;
        }
        if !reported {
            self.surface
                .damage_buffer(0, 0, image.width as i32, image.height as i32);
        }
        self.surface.attach(Some(&buffer), 0, 0);
        // The acquire point must be in the same commit as the buffer it guards.
        // acquire 点必须与被它守护的缓冲在同一次 commit 里。
        if let (Some(surface), Some(acquire_tl), Some(release_tl), Some(point)) = (
            self.syncobj_surface.as_ref(),
            self.syncobj_timeline.as_ref(),
            self.syncobj_release_timeline.as_ref(),
            acquire_point,
        ) {
            surface.set_acquire_point(acquire_tl, (point >> 32) as u32, point as u32);
            let rp = release_point;
            surface.set_release_point(release_tl, (rp >> 32) as u32, rp as u32);
        }
        self.surface.frame(&self.qh, ());
        self.state.frame_ready = false;
        self.state.redraw_requested = false;
        // Same batch as the surface commit: v1 places the candidate window at the
        // rectangle in force when text-input commits (ime-text-design §6).
        // 与 surface commit 同一批：v1 用 text-input 提交时生效的矩形摆放候选窗（§6）。
        self.apply_ime();
        self.surface.commit();
        // Holding the buffer here is what keeps it alive until `release` arrives.
        // 在这里持有缓冲，才能让它活到 `release` 事件到来。
        self.state.dmabuf_inflight.push(buffer);
        let _ = self.queue.flush();
        Ok(())
    }

    /// Present the current `pixels` into the window.
    /// 把当前 `pixels` 呈现到窗口。
    pub fn present_now(&mut self, damage: &Damage) -> Result<(), WindowError> {
        self.resize_with_callback();
        self.push_viewport();

        let Some(back) = self.back.as_mut() else {
            return Err(WindowError::Buffer);
        };
        back.copy_from(self.pixels.as_bytes());

        // A wl_buffer is a view over its pool; each slot has its own pool so a
        // still-attached buffer is never written again.
        // wl_buffer 是其池上的视图；每个槽位各有自己的池，
        // 因此仍被持有的缓冲不会被再次写入。
        let shm_buffer = back.pool.create_buffer(
            0,
            back.width as i32,
            back.height as i32,
            back.stride as i32,
            ShmBuffer::format(),
            &self.qh,
            (),
        );
        back.set_busy(true);
        self.surface
            .damage_buffer(0, 0, back.width as i32, back.height as i32);
        let _ = damage;
        self.surface.attach(Some(&shm_buffer), 0, 0);
        // One callback per commit: no second frame is drawn until this fires.
        // 每次提交一个回调：在它触发前不会再画第二帧。
        self.surface.frame(&self.qh, ());
        self.state.frame_ready = false;
        self.state.redraw_requested = false;
        // Same batch as the surface commit; see `apply_ime`.
        // 与 surface commit 同一批；见 `apply_ime`。
        self.apply_ime();
        self.surface.commit();

        // Rotate the slots: the released previous-front becomes the new back.
        // 轮换槽位：被释放的原前缓冲成为新的后缓冲。
        let old_front = self.front.take();
        let old_back = self.back.take().expect("back buffer");
        self.front = Some((shm_buffer, old_back));
        if let Some((buf, old_buf)) = old_front {
            buf.destroy();
            if old_buf.width == self.pixels.width && old_buf.height == self.pixels.height {
                self.back = Some(old_buf);
            } else {
                // Wrong size after a configure; a fresh one is allocated next frame.
                // configure 后尺寸不符；下一帧重新分配。
                self.back = None;
            }
        } else {
            self.back = None;
        }
        if self.back.is_none() {
            self.back = self
                .state
                .shm
                .as_ref()
                .and_then(|shm| ShmBuffer::new(shm, &self.qh, self.pixels.width, self.pixels.height));
        }
        let _ = self.queue.flush();
        Ok(())
    }
}

impl PresentTarget for WaylandWindow {
    fn kind(&self) -> SurfaceKind {
        SurfaceKind::Window
    }

    fn size(&self) -> (u32, u32) {
        (self.pixels.width, self.pixels.height)
    }

    fn pixels_mut(&mut self) -> &mut Pixels {
        &mut self.pixels
    }

    fn present(&mut self, damage: &Damage) -> Result<(), String> {
        self.present_now(damage).map_err(|e| e.to_string())
    }

    fn set_cursor(&mut self, shape: CursorShape) {
        Self::set_cursor(self, shape);
    }

    fn set_ime(&mut self, state: ui_platform::present::ImeState) {
        Self::set_ime(self, state);
    }
}

// Keep rarely used imports meaningful for future input work.
// 为后续输入工作保留少用的导入。
#[allow(dead_code)]
fn _keep(_: &dyn AsFd, _: &mut std::fs::File) {}

/// The window as the engine's driver sees it; an app never derives these rules itself.
/// 引擎驱动眼中的窗口；应用不再自己推导这些规则。
impl ui_platform::driver::FrameHost for WaylandWindow {
    fn size(&self) -> (u32, u32) {
        device_size(self.logical_size(), self.scale())
    }
    fn scale(&self) -> f32 {
        WaylandWindow::scale(self)
    }
    fn pointer(&self) -> Option<ui_core::geom::Point> {
        WaylandWindow::pointer(self)
    }
    fn can_draw(&self) -> bool {
        WaylandWindow::can_draw(self)
    }
    fn wait_until(&mut self, timeout: Option<std::time::Duration>) -> bool {
        WaylandWindow::wait_until(self, timeout)
    }
    fn wait_for_frame(&mut self) {
        WaylandWindow::wait_for_frame(self)
    }
    fn should_close(&self) -> bool {
        WaylandWindow::should_close(self)
    }
    fn take_events(&mut self) -> Vec<ui_core::Event> {
        WaylandWindow::take_events(self)
    }
    fn take_silent_change(&mut self) -> bool {
        WaylandWindow::take_silent_change(self)
    }
}

#[cfg(test)]
mod tests {
    use super::device_size;

    #[test]
    fn device_size_rounds_fractional_scale_instead_of_truncating() {
        // 1.5 x 461 is 691.5; truncating to 691 would shift every row by half a pixel.
        // 1.5 倍的 461 是 691.5；截断成 691 会让每一行偏半像素。
        assert_eq!(device_size((461, 200), 1.5), (692, 300));
    }

    #[test]
    fn device_size_never_returns_a_zero_sized_target() {
        // A zero-sized target fails allocation, so an empty window still asks for one pixel.
        // 零尺寸目标会分配失败，因此空窗口仍然请求一个像素。
        assert_eq!(device_size((0, 0), 1.0), (1, 1));
    }
}
