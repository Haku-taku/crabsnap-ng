//! Input state: keyboard keysyms and pointer position.
//! 输入状态：键盘 keysym 与指针位置。

use std::collections::HashSet;

use ui_core::geom::Point;
use xkbcommon::xkb;

/// A key event translated from the compositor's evdev codes.
/// 由 compositor 的 evdev 码翻译得到的按键事件。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct KeyEvent {
    /// Unicode text this key produces, when it produces any.
    /// 该键产生的字符（若产生字符）。
    pub text: Option<char>,
    /// Whether a modifier (Ctrl/Alt/Super) was held.
    /// 是否按住了修饰键（Ctrl/Alt/Super）。
    pub modified: bool,
}

/// The character a keysym names, by the standard keysym-to-Unicode rule.
/// keysym 所命名的字符，按标准的 keysym 到 Unicode 规则。
///
/// Latin-1 keysyms are their code point; Unicode keysyms carry it offset by `0x0100_0000`.
/// Latin-1 的 keysym 就是码位；Unicode 的 keysym 以 `0x0100_0000` 为偏移携带码位。
fn keysym_char(sym: u32) -> Option<char> {
    let code = match sym {
        0x20..=0x7e | 0xa0..=0xff => sym,
        0x0100_0100..=0x0110_ffff => sym - 0x0100_0000,
        _ => return None,
    };
    char::from_u32(code)
}

/// Everything the UI needs to know about input.
/// UI 需要知道的全部输入状态。
pub struct InputState {
    /// Keys currently held, by keysym.
    /// 当前按住的键（按 keysym）。
    held: HashSet<u32>,
    /// Characters typed since the last frame consumed them.
    /// 上次消费以来输入的字符。
    typed: Vec<char>,
    /// Pointer position, when over the surface.
    /// 指针位置（在表面内时）。
    pointer: Option<Point>,
    /// xkb state: translates evdev codes to keysyms using the compositor's keymap.
    /// xkb 状态：用 compositor 的键位表把 evdev 码翻译成 keysym。
    xkb_state: Option<xkb::State>,
    xkb_context: xkb::Context,
}

impl std::fmt::Debug for InputState {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("InputState")
            .field("held", &self.held.len())
            .field("typed", &self.typed)
            .field("pointer", &self.pointer)
            .finish()
    }
}

impl Default for InputState {
    fn default() -> Self {
        Self::new()
    }
}

impl InputState {
    pub fn new() -> Self {
        Self {
            held: HashSet::new(),
            typed: Vec::new(),
            pointer: None,
            xkb_state: None,
            // The context must outlive every keymap built from it.
            // context 的生命周期必须长于由它构建的所有键位表。
            xkb_context: xkb::Context::new(xkb::CONTEXT_NO_FLAGS),
        }
    }

    /// Install the compositor's keymap from the descriptor it handed over.
    /// 从 compositor 交来的描述符安装键位表。
    ///
    /// This is the only path that works for a Wayland keymap: it ends with a NUL,
    /// which `new_from_string` cannot accept but the fd path handles.
    /// 这是 Wayland 键位表唯一可行的路径：它以 NUL 结尾，
    /// `new_from_string` 不接受，fd 路径才行。
    ///
    /// # Safety
    /// `fd` must be the keymap descriptor from a `wl_keyboard.keymap` event.
    /// `fd` 必须是 `wl_keyboard.keymap` 事件交来的键位表描述符。
    pub unsafe fn set_keymap_fd(
        &mut self,
        fd: std::os::fd::OwnedFd,
        size: usize,
    ) -> bool {
        // The caller's contract is this function's, so the unsafe block repeats it.
        // 调用方的契约就是本函数的契约，因此 unsafe 块把同一份契约再声明一次。
        unsafe {
            match xkb::Keymap::new_from_fd(
                &self.xkb_context,
                fd,
                size,
                xkb::KEYMAP_FORMAT_TEXT_V1,
                xkb::KEYMAP_COMPILE_NO_FLAGS,
            ) {
                Ok(Some(keymap)) => {
                    self.xkb_state = Some(xkb::State::new(&keymap));
                    true
                }
                _ => false,
            }
        }
    }

    /// Install a keymap from text that has no trailing NUL.
    /// 从没有结尾 NUL 的文本安装键位表。
    ///
    /// Kept for tests; real Wayland keymaps go through `set_keymap_fd`.
    /// 供测试使用；真实的 Wayland 键位表走 `set_keymap_fd`。
    pub fn set_keymap(&mut self, text: &str) {
        let keymap = xkb::Keymap::new_from_string(
            &self.xkb_context,
            text.trim_end_matches('\0').to_string(),
            xkb::KEYMAP_FORMAT_TEXT_V1,
            xkb::KEYMAP_COMPILE_NO_FLAGS,
        );
        self.xkb_state = keymap.map(|km| xkb::State::new(&km));
    }

    pub fn has_keymap(&self) -> bool {
        self.xkb_state.is_some()
    }

    pub fn set_pointer(&mut self, p: Option<Point>) {
        self.pointer = p;
    }

    pub fn pointer(&self) -> Option<Point> {
        self.pointer
    }

    /// Update a pressed key and return the character naming it, if any.
    /// 更新一个按键，返回命名它的字符（若有）。
    ///
    /// Named by keysym, not by the text the key would type: with Ctrl held xkb's utf8 is a
    /// control character, so a chord would otherwise arrive as no key at all.
    /// 按 keysym 命名，而不是按键会打出的文本：按住 Ctrl 时 xkb 的 utf8 是控制字符，
    /// 组合键因此会变成"没有按键"。
    pub fn key(&mut self, evdev_code: u32, pressed: bool) -> Option<char> {
        let state = self.xkb_state.as_mut()?;
        let keycode = xkb::Keycode::new(evdev_code + 8); // XKB keycodes are evdev + 8.
        let raw = state.key_get_one_sym(keycode).raw();
        if pressed {
            self.held.insert(raw);
        } else {
            self.held.remove(&raw);
        }
        if !pressed {
            return None;
        }
        keysym_char(raw)
    }

    /// The text this key types right now, composed with any dead key before it.
    /// 该键此刻打出的文本，已与之前的死键组合。
    ///
    /// Differs from [`Self::key`] where the layout composes: a dead key followed by `e`
    /// names `e` but types `é`.
    /// 与 [`Self::key`] 在布局会组合的地方不同：死键后接 `e` 命名 `e`，却打出 `é`。
    pub fn text(&mut self, evdev_code: u32) -> Option<char> {
        let state = self.xkb_state.as_mut()?;
        let utf8 = state.key_get_utf8(xkb::Keycode::new(evdev_code + 8));
        utf8.chars().next().filter(|c| !c.is_control())
    }

    /// Apply a modifier change from the compositor.
    /// 应用 compositor 的修饰键变化。
    pub fn update_modifiers(
        &mut self,
        depressed: u32,
        latched: u32,
        locked: u32,
        group: u32,
    ) {
        if let Some(state) = self.xkb_state.as_mut() {
            state.update_mask(depressed, latched, locked, 0, 0, group);
        }
    }

    /// Record a typed character for the next frame.
    /// 记录一个输入字符，供下一帧消费。
    pub fn push_text(&mut self, c: char) {
        if !c.is_control() {
            self.typed.push(c);
        }
    }

    /// Take all typed characters since the last call.
    /// 取走上次调用以来输入的全部字符。
    pub fn take_typed(&mut self) -> Vec<char> {
        std::mem::take(&mut self.typed)
    }

    /// Whether the named keysym is currently held.
    /// 指定的 keysym 当前是否按住。
    pub fn is_held(&self, keysym: u32) -> bool {
        self.held.contains(&keysym)
    }

    /// Held keysym count, for diagnostics.
    /// 按住的 keysym 数量，供诊断。
    pub fn held_count(&self) -> usize {
        self.held.len()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn typed_text_is_consumed_once() {
        let mut s = InputState::new();
        s.push_text('a');
        s.push_text('b');
        assert_eq!(s.take_typed(), vec!['a', 'b']);
        assert!(s.take_typed().is_empty(), "second take must be empty");
    }

    #[test]
    fn control_characters_are_not_recorded_as_text() {
        let mut s = InputState::new();
        s.push_text('\n');
        s.push_text('\t');
        s.push_text('x');
        assert_eq!(s.take_typed(), vec!['x']);
    }

    #[test]
    fn pointer_round_trips() {
        let mut s = InputState::new();
        assert_eq!(s.pointer(), None);
        s.set_pointer(Some(Point::new(3.0, 4.0)));
        assert_eq!(s.pointer(), Some(Point::new(3.0, 4.0)));
        s.set_pointer(None);
        assert_eq!(s.pointer(), None);
    }

    #[test]
    fn a_control_chord_still_names_its_letter() {
        // Ctrl turns xkb's utf8 into a control character; the key must still say which one.
        // Ctrl 会让 xkb 的 utf8 变成控制字符；按键仍须说清是哪一个。
        let mut s = InputState::new();
        let keymap = xkb::Keymap::new_from_names(&s.xkb_context, "", "", "us", "", None, 0)
            .expect("the us layout is installed");
        s.xkb_state = Some(xkb::State::new(&keymap));
        s.key(29, true); // KEY_LEFTCTRL
        s.update_modifiers(1 << 2, 0, 0, 0);
        assert_eq!(s.key(46, true), Some('c'), "Ctrl+C must name the letter c");
    }

    #[test]
    fn key_without_keymap_is_ignored() {
        let mut s = InputState::new();
        assert!(!s.has_keymap());
        assert_eq!(s.key(30, true), None);
        assert_eq!(s.held_count(), 0);
    }
}
