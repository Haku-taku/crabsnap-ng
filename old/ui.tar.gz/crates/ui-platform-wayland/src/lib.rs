//! Wayland XDG window target: `wl_shm` reference path plus an optional dma-buf path.
//! Wayland XDG 窗口目标：`wl_shm` 参考路径，外加可选的 dma-buf 路径。

pub mod colour;
pub(crate) mod clipboard;
pub(crate) mod conn;
pub(crate) mod cursor_shape;
pub mod dmabuf;
#[cfg(feature = "gpu")]
pub mod gpu_window;
#[cfg(feature = "global-hotkeys")]
pub mod portal_hotkeys;
pub mod session;
pub mod input;
pub mod shm;
pub mod window;
pub mod theme;

pub use dmabuf::{DmaBufBuffer, DmaBufError, DmaBufFormats, DmaBufImage, FormatSupport};
#[cfg(feature = "gpu")]
pub use gpu_window::{GpuWindow, GpuWindowConfig, GpuWindowError, PresentOutcome};
pub use session::{Session, SessionOptions, Tick};
pub use ui_paint_gpu::partial_frames;
pub use input::{InputState, KeyEvent};
#[cfg(feature = "global-hotkeys")]
pub use portal_hotkeys::PortalHotkeys;
pub use shm::ShmBuffer;
pub use theme::PortalThemeWatcher;
pub use window::{Anchor, Layer, LayerConfig, WaylandWindow, WindowConfig, WindowError};
