//! dma-buf backed `wl_buffer` creation through `zwp_linux_dmabuf_v1`.
//! 通过 `zwp_linux_dmabuf_v1` 创建 dma-buf 支撑的 `wl_buffer`。

use std::collections::BTreeSet;
use std::os::fd::{AsFd, OwnedFd};

use wayland_client::protocol::wl_buffer::WlBuffer;
use wayland_client::{Dispatch, Proxy, QueueHandle};
use wayland_protocols::wp::linux_dmabuf::zv1::client::zwp_linux_buffer_params_v1::{
    self, ZwpLinuxBufferParamsV1,
};
use wayland_protocols::wp::linux_dmabuf::zv1::client::zwp_linux_dmabuf_v1::ZwpLinuxDmabufV1;

/// `DRM_FORMAT_ARGB8888`, matching the shm path's little-endian BGRA bytes.
/// `DRM_FORMAT_ARGB8888`，与 shm 路径的小端 BGRA 字节一致。
pub const FORMAT_ARGB8888: u32 = 0x3432_5241;

/// `DRM_FORMAT_MOD_LINEAR`: stride-major rows, the fallback layout.
/// `DRM_FORMAT_MOD_LINEAR`：按行主序，回退布局。
pub const MODIFIER_LINEAR: u64 = 0;

/// `DRM_FORMAT_MOD_INVALID`: let the compositor derive the layout from the dma-buf.
/// `DRM_FORMAT_MOD_INVALID`：布局由 compositor 从 dma-buf 推导。
pub const MODIFIER_INVALID: u64 = 0x00ff_ffff_ffff_ffff;

/// One single-plane dma-buf image ready to become a `wl_buffer`.
/// 一张可直接变成 `wl_buffer` 的单平面 dma-buf 图像。
#[derive(Debug)]
pub struct DmaBufImage {
    pub fd: OwnedFd,
    pub width: u32,
    pub height: u32,
    pub stride: u32,
    pub offset: u32,
    /// DRM fourcc, e.g. [`FORMAT_ARGB8888`].
    /// DRM fourcc，例如 [`FORMAT_ARGB8888`]。
    pub format: u32,
    /// Real layout modifier from the allocator; never assume [`MODIFIER_LINEAR`].
    /// 分配器给出的真实布局 modifier；绝不假设是 [`MODIFIER_LINEAR`]。
    pub modifier: u64,
}

/// How the compositor's advertisement covers a format/modifier pair.
/// compositor 通告对某个 format/modifier 组合的覆盖情况。
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum FormatSupport {
    /// The exact pair was advertised and may be sent verbatim.
    /// 该组合被明确通告，可原样发送。
    Explicit,
    /// Only implicit layout is offered: send [`MODIFIER_INVALID`].
    /// 只提供隐式布局：发送 [`MODIFIER_INVALID`]。
    ImplicitOnly,
    /// The compositor will reject this pair.
    /// compositor 会拒绝该组合。
    Unsupported,
}

/// Format/modifier pairs advertised by `zwp_linux_dmabuf_v1`.
/// `zwp_linux_dmabuf_v1` 通告的 format/modifier 组合。
#[derive(Clone, Debug, Default)]
pub struct DmaBufFormats {
    pairs: BTreeSet<(u32, u64)>,
    formats: BTreeSet<u32>,
}

impl DmaBufFormats {
    /// Record a legacy `format` event (v1/v2 carry no modifier).
    /// 记录旧的 `format` 事件（v1/v2 不含 modifier）。
    pub fn record_format(&mut self, format: u32) {
        self.formats.insert(format);
    }

    /// Record a `modifier` event (v3+ only).
    /// 记录 `modifier` 事件（仅 v3+）。
    pub fn record_modifier(&mut self, format: u32, modifier: u64) {
        self.formats.insert(format);
        self.pairs.insert((format, modifier));
    }

    pub fn is_empty(&self) -> bool {
        self.formats.is_empty()
    }

    /// Number of distinct advertised format codes.
    /// 通告的 format 代码数量。
    pub fn format_count(&self) -> usize {
        self.formats.len()
    }

    /// Number of distinct advertised format/modifier pairs.
    /// 通告的 format/modifier 组合数量。
    pub fn pair_count(&self) -> usize {
        self.pairs.len()
    }

    /// Whether `format` appeared in any advertisement.
    /// `format` 是否出现在任何通告中。
    pub fn has_format(&self, format: u32) -> bool {
        self.formats.contains(&format) || self.pairs.iter().any(|(f, _)| *f == format)
    }

    /// Classify a pair against the advertisement.
    /// 按通告给某个组合分类。
    pub fn support(&self, format: u32, modifier: u64) -> FormatSupport {
        if self.pairs.contains(&(format, modifier)) {
            return FormatSupport::Explicit;
        }
        if !self.has_format(format) {
            return FormatSupport::Unsupported;
        }
        // Implicit layout is valid when INVALID was advertised or only codes were.
        // 通告了 INVALID 或只通告 format 代码时，隐式布局有效。
        if modifier == MODIFIER_INVALID || self.pairs.contains(&(format, MODIFIER_INVALID)) {
            return FormatSupport::ImplicitOnly;
        }
        let explicit_only = self
            .pairs
            .iter()
            .any(|(f, m)| *f == format && *m != MODIFIER_INVALID);
        if explicit_only {
            FormatSupport::Unsupported
        } else {
            FormatSupport::ImplicitOnly
        }
    }

    /// Modifier to put on the wire, or `None` when the pair cannot work.
    /// 实际发送的 modifier；无法工作时为 `None`。
    pub fn effective_modifier(&self, format: u32, modifier: u64) -> Option<u64> {
        match self.support(format, modifier) {
            FormatSupport::Explicit => Some(modifier),
            FormatSupport::ImplicitOnly => Some(MODIFIER_INVALID),
            FormatSupport::Unsupported => None,
        }
    }
}

/// Why a dma-buf `wl_buffer` could not be created.
/// dma-buf `wl_buffer` 创建失败的原因。
#[derive(Debug)]
pub enum DmaBufError {
    /// The compositor does not expose `zwp_linux_dmabuf_v1`.
    /// compositor 未提供 `zwp_linux_dmabuf_v1`。
    Unavailable,
    /// `create_immed` needs version 2; the bound global is older.
    /// `create_immed` 需要 v2，但绑定的全局更旧。
    TooOld(u32),
    /// The format/modifier pair was never advertised.
    /// 该 format/modifier 组合从未被通告。
    NotAdvertised { format: u32, modifier: u64 },
    /// Zero width, height, stride or format.
    /// 宽、高、stride 或 format 为零。
    InvalidImage,
    /// Duplicating the dma-buf fd failed.
    /// 复制 dma-buf fd 失败。
    Fd,
}

impl std::fmt::Display for DmaBufError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            DmaBufError::Unavailable => write!(f, "zwp_linux_dmabuf_v1 is not available"),
            DmaBufError::TooOld(v) => write!(f, "zwp_linux_dmabuf_v1 v{v} lacks create_immed"),
            DmaBufError::NotAdvertised { format, modifier } => write!(
                f,
                "compositor never advertised format {format:#x} modifier {modifier:#x}"
            ),
            DmaBufError::InvalidImage => write!(f, "invalid dma-buf image geometry"),
            DmaBufError::Fd => write!(f, "could not duplicate the dma-buf fd"),
        }
    }
}

impl std::error::Error for DmaBufError {}

/// A `wl_buffer` plus the dma-buf fd that must outlive it.
/// 一个 `wl_buffer`，以及必须比它活得更久的 dma-buf fd。
#[derive(Debug)]
pub struct DmaBufBuffer {
    buffer: WlBuffer,
    /// The compositor may sample the dma-buf until it sends `release`.
    /// 在 compositor 发出 `release` 前它都可能采样该 dma-buf。
    _keepalive: OwnedFd,
    /// Params stays alive so a late `failed` event still reaches dispatch.
    /// 保留 params，使迟到的 `failed` 事件仍能到达 dispatch。
    _params: ZwpLinuxBufferParamsV1,
}

impl DmaBufBuffer {
    pub fn buffer(&self) -> &WlBuffer {
        &self.buffer
    }

    /// Destroy the `wl_buffer` now; the compositor releases the dma-buf with it.
    /// 立即销毁 `wl_buffer`；compositor 随之一并释放 dma-buf。
    pub fn destroy(&self) {
        self.buffer.destroy();
    }
}

/// Combine the protocol's split modifier back into one 64-bit token.
/// 把协议中拆开的 modifier 合回一个 64 位值。
pub fn modifier_from_parts(hi: u32, lo: u32) -> u64 {
    ((hi as u64) << 32) | lo as u64
}

/// Split a 64-bit modifier into the protocol's `(modifier_hi, modifier_lo)`.
/// 把 64 位 modifier 拆成协议的 `(modifier_hi, modifier_lo)`。
pub fn modifier_parts(modifier: u64) -> (u32, u32) {
    ((modifier >> 32) as u32, modifier as u32)
}

/// The `(device, inode)` a dma-buf descriptor points at: a dup shares both, so the pair
/// identifies "the same buffer" across frames and lets its `wl_buffer` be reused.
/// 描述符指向的 `(device, inode)`：dup 出的 fd 共享两者，因此这对值可跨帧识别「同一个
/// 缓冲」，让其 `wl_buffer` 被复用。
pub fn image_identity(image: &DmaBufImage) -> Option<(u64, u64)> {
    use std::os::fd::AsRawFd;
    use std::os::unix::fs::MetadataExt;
    let meta = std::fs::metadata(format!("/proc/self/fd/{}", image.fd.as_raw_fd())).ok()?;
    Some((meta.dev(), meta.ino()))
}

/// Import `image` and create a `wl_buffer` through `create_immed`.
/// 导入 `image` 并通过 `create_immed` 创建 `wl_buffer`。
pub fn create_dmabuf_buffer<D>(
    dmabuf: &ZwpLinuxDmabufV1,
    formats: &DmaBufFormats,
    image: &DmaBufImage,
    qh: &QueueHandle<D>,
) -> Result<DmaBufBuffer, DmaBufError>
where
    D: Dispatch<ZwpLinuxBufferParamsV1, ()> + Dispatch<WlBuffer, ()> + 'static,
{
    let version = dmabuf.version();
    if version < 2 {
        return Err(DmaBufError::TooOld(version));
    }
    if image.width == 0 || image.height == 0 || image.stride == 0 || image.format == 0 {
        return Err(DmaBufError::InvalidImage);
    }
    let Some(modifier) = formats.effective_modifier(image.format, image.modifier) else {
        return Err(DmaBufError::NotAdvertised {
            format: image.format,
            modifier: image.modifier,
        });
    };
    let keepalive = image.fd.try_clone().map_err(|_| DmaBufError::Fd)?;
    let (hi, lo) = modifier_parts(modifier);

    let params = dmabuf.create_params(qh, ());
    params.add(image.fd.as_fd(), 0, image.offset, image.stride, hi, lo);
    // create_immed is synchronous; a rejected import arrives as `failed` later.
    // create_immed 是同步的；导入被拒绝会稍后以 `failed` 事件到达。
    let buffer = params.create_immed(
        image.width as i32,
        image.height as i32,
        image.format,
        zwp_linux_buffer_params_v1::Flags::empty(),
        qh,
        (),
    );
    Ok(DmaBufBuffer {
        buffer,
        _keepalive: keepalive,
        _params: params,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn modifier_parts_round_trip_preserves_nvidia_tiled_value() {
        let tiled = 0x0300_0000_00e0_8012u64;
        let (hi, lo) = modifier_parts(tiled);
        assert_eq!(hi, 0x0300_0000);
        assert_eq!(lo, 0x00e0_8012);
        assert_eq!(modifier_from_parts(hi, lo), tiled);
    }

    #[test]
    fn modifier_event_records_explicit_pair() {
        let tiled = 0x0300_0000_00e0_8012u64;
        let mut formats = DmaBufFormats::default();
        formats.record_modifier(FORMAT_ARGB8888, tiled);
        assert_eq!(formats.support(FORMAT_ARGB8888, tiled), FormatSupport::Explicit);
    }

    #[test]
    fn unlisted_modifier_is_unsupported_once_explicit_modifiers_are_advertised() {
        let mut formats = DmaBufFormats::default();
        formats.record_modifier(FORMAT_ARGB8888, MODIFIER_LINEAR);
        assert_eq!(
            formats.support(FORMAT_ARGB8888, 0x0300_0000_00e0_8012),
            FormatSupport::Unsupported
        );
    }

    #[test]
    fn format_only_advertisement_accepts_any_modifier_implicitly() {
        let mut formats = DmaBufFormats::default();
        formats.record_format(FORMAT_ARGB8888);
        assert_eq!(
            formats.support(FORMAT_ARGB8888, 0x0300_0000_00e0_8012),
            FormatSupport::ImplicitOnly
        );
    }

    #[test]
    fn unadvertised_format_is_unsupported() {
        let mut formats = DmaBufFormats::default();
        formats.record_modifier(FORMAT_ARGB8888, MODIFIER_LINEAR);
        assert_eq!(
            formats.support(0x3432_4241, MODIFIER_LINEAR),
            FormatSupport::Unsupported
        );
    }

    #[test]
    fn implicit_fallback_sends_modifier_invalid() {
        let mut formats = DmaBufFormats::default();
        formats.record_modifier(FORMAT_ARGB8888, MODIFIER_INVALID);
        assert_eq!(
            formats.effective_modifier(FORMAT_ARGB8888, 0x0300_0000_00e0_8012),
            Some(MODIFIER_INVALID)
        );
    }
}
