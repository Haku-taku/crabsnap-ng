//! Shared-memory buffer pool for `wl_shm` presentation.
//! `wl_shm` 呈现用的共享内存缓冲池。

use std::os::unix::io::AsFd;

use memmap2::MmapMut;
use wayland_client::protocol::wl_shm::{Format, WlShm};
use wayland_client::protocol::wl_shm_pool::WlShmPool;
use wayland_client::{Connection, QueueHandle};

/// One mapped buffer plus the pool that owns it.
/// 一个已映射的缓冲，以及拥有它的池。
pub struct ShmBuffer {
    pub pool: WlShmPool,
    pub map: MmapMut,
    pub width: u32,
    pub height: u32,
    pub stride: u32,
    /// Set by the compositor's `release` event.
    /// 由 compositor 的 `release` 事件置位。
    busy: std::cell::Cell<bool>,
}

impl std::fmt::Debug for ShmBuffer {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("ShmBuffer")
            .field("width", &self.width)
            .field("height", &self.height)
            .finish()
    }
}

impl ShmBuffer {
    /// Allocate a zeroed buffer of `width * height * 4` bytes.
    /// 分配 `width * height * 4` 字节的零初始化缓冲。
    pub fn new(
        shm: &WlShm,
        qh: &QueueHandle<impl wayland_client::Dispatch<WlShmPool, ()> + 'static>,
        width: u32,
        height: u32,
    ) -> Option<Self> {
        let stride = width.checked_mul(4)?;
        let size = (stride as usize).checked_mul(height as usize)?;
        if size == 0 {
            return None;
        }
        let file = tempfile_in_memory(size)?;
        let pool = shm.create_pool(file.as_fd(), size as i32, qh, ());
        let map = unsafe { MmapMut::map_mut(&file).ok()? };
        Some(Self {
            pool,
            map,
            width,
            height,
            stride,
            busy: std::cell::Cell::new(false),
        })
    }

    pub fn set_busy(&self, busy: bool) {
        self.busy.set(busy);
    }

    pub fn is_busy(&self) -> bool {
        self.busy.get()
    }

    /// Bytes for `wl_buffer` to interpret, as ARGB8888 (little-endian BGRA).
    /// 交给 `wl_buffer` 解释的字节，按 ARGB8888（小端 BGRA）。
    pub fn bytes(&self) -> &[u8] {
        &self.map
    }

    /// Copy premultiplied BGRA rows from `src` into the mapping.
    /// 把预乘 BGRA 行从 `src` 拷进映射。
    pub fn copy_from(&mut self, src: &[u8]) {
        let n = self.map.len().min(src.len());
        self.map[..n].copy_from_slice(&src[..n]);
    }

    pub fn format() -> Format {
        // wl_shm ARGB8888 is little-endian BGRA in memory, matching `ui_paint`.
        // wl_shm 的 ARGB8888 在内存里是小端 BGRA，与 `ui_paint` 一致。
        Format::Argb8888
    }
}

/// An anonymous in-memory file suitable for `wl_shm`.
/// 适合 `wl_shm` 的匿名内存文件。
fn tempfile_in_memory(size: usize) -> Option<std::fs::File> {
    use std::io::{Seek, SeekFrom, Write};
    let mut f = tempfile::tempfile().ok()?;
    f.set_len(size as u64).ok()?;
    f.seek(SeekFrom::Start(0)).ok()?;
    // Touch the last byte so the file is fully backed before mapping.
    // 触碰最后一字节，确保映射前文件已被完整分配。
    f.write_all(&[0u8]).ok()?;
    f.seek(SeekFrom::Start(0)).ok()?;
    Some(f)
}

/// Keep the connection type reachable for callers that build queues.
/// 让构建队列的调用方能拿到连接类型。
pub type ShmConnection = Connection;
