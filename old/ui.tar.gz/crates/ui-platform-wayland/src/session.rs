//! One engine-owned session: window, presenter, driver and teardown order.
//! 一个由引擎持有的会话：窗口、呈现器、驱动与拆除顺序。

use std::time::Duration;

use ui_core::geom::Point;
use ui_platform::driver::{Driver, Turn};
use ui_platform::present::{PresentStats, SceneTarget};
use ui_platform::text_pass::TextPass;
use ui_platform::view::{App, AppLoop, FrameOutcome};

use crate::gpu_window::{GpuWindow, GpuWindowConfig};
use crate::window::{WaylandWindow, WindowConfig};

/// What the host asks for when it hands the engine a loop.
/// 宿主把循环交给引擎时提出的要求。
pub struct SessionOptions {
    pub title: String,
    pub app_id: String,
    pub width: u32,
    pub height: u32,
    /// Draw on every turn instead of one frame per compositor callback (a stress knob).
    /// 每轮都画，而不是每个 compositor 回调一帧（压测旋钮）。
    pub uncapped: bool,
    /// Present through the CPU rasterizer even when a GPU is available.
    /// 即使有 GPU 也用 CPU 光栅器呈现。
    pub cpu_presenter: bool,
}

/// The GPU presenter as the engine's scene target.
/// 引擎眼中的 GPU 呈现器。
struct GpuTarget<'a> {
    win: &'a mut WaylandWindow,
    gpu: &'a mut GpuWindow,
}

impl SceneTarget for GpuTarget<'_> {
    fn size(&self) -> (u32, u32) {
        let (w, h) = self.win.logical_size();
        let s = self.win.scale().max(f32::EPSILON);
        ((w as f32 * s).round() as u32, (h as f32 * s).round() as u32)
    }

    fn present_scene(
        &mut self,
        scene: &ui_core::draw::DrawList,
        text: &TextPass,
        damage: &ui_core::Damage,
    ) -> Result<PresentStats, String> {
        self.gpu
            .sync_atlas(text)
            .map_err(|e| format!("atlas upload failed: {e}"))?;
        let (w, h) = self.win.logical_size();
        let out = self
            .gpu
            .present(self.win, (w, h), scene, damage)
            .map_err(|e| format!("present failed: {e}"))?;
        Ok(PresentStats {
            draw_calls: out.draw_calls,
            band: out.band,
        })
    }

    fn set_cursor(&mut self, shape: ui_core::CursorShape) {
        self.win.set_cursor(shape);
    }

    fn set_ime(&mut self, state: ui_platform::present::ImeState) {
        self.win.set_ime(state);
    }

    fn commit_pending(&self) -> bool {
        self.win.ime_pending()
    }
}

/// One turn's result: whether it drew, and what the target did.
/// 一轮的结果：有没有画，以及目标交给了屏幕什么。
pub struct Tick {
    pub drew: bool,
    pub outcome: Option<FrameOutcome>,
    pub presented: Option<PresentStats>,
    /// The pointer the frame was built with, for the host's own diagnostics.
    /// 构建该帧所用的指针，供宿主自己诊断。
    pub pointer: Option<Point>,
}

/// Window, presenter and driver, owned together so an app never orders them itself.
/// 窗口、呈现器与驱动由同一处持有，应用因此不必自己安排它们。
///
/// Dropped in declaration order, which is the order teardown needs: GPU objects while the
/// surface still exists, then the loop, then the window.
/// 按字段声明顺序析构，这正是拆除需要的顺序：表面还在时先放 GPU 对象，再放循环，最后放窗口。
pub struct Session<A: App> {
    gpu: Option<GpuWindow>,
    driver: Driver,
    lp: AppLoop<A>,
    win: WaylandWindow,
    /// Scripted pointer for the next frame; see `set_pointer`.
    /// 下一帧的脚本指针；见 `set_pointer`。
    pointer: Option<Point>,
}

impl<A: App> Session<A> {
    /// Open the window and pick a presenter; the loop is the caller's, the lifecycle is not.
    /// 打开窗口并选择呈现器；循环归调用方，生命周期归这里。
    pub fn open(lp: AppLoop<A>, opts: SessionOptions) -> Result<Self, String> {
        let mut win = WaylandWindow::new(WindowConfig {
            title: opts.title,
            app_id: opts.app_id,
            width: opts.width,
            height: opts.height,
        })
        .map_err(|e| format!("cannot open a Wayland window: {e}"))?;
        let gpu = if opts.cpu_presenter {
            None
        } else {
            match GpuWindow::open(&mut win, GpuWindowConfig::default()) {
                Ok(gpu) => Some(gpu),
                Err(e) => {
                    return Err(format!(
                        "GPU presenter unavailable: {e}\nset the CPU presenter to run without it"
                    ));
                }
            }
        };
        Ok(Self {
            gpu,
            driver: Driver::new().uncapped(opts.uncapped),
            lp,
            win,
            pointer: None,
        })
    }

    /// The GPU renderer's name and node, when one is in use.
    /// 使用 GPU 时其渲染器名称与节点。
    /// The pointer to build the next frame with, overriding the seat's — scripted input
    /// needs it, or the frame snaps back to wherever the real cursor is.
    /// 下一帧构建所用的指针，覆盖座位的——脚本输入需要它，
    /// 否则这一帧会弹回真实光标所在处。
    pub fn set_pointer(&mut self, pointer: Option<Point>) {
        self.pointer = pointer;
    }

    pub fn presenter_name(&self) -> Option<String> {
        self.gpu
            .as_ref()
            .map(|g| format!("{} ({})", g.renderer_name(), g.node()))
    }

    pub fn lp(&self) -> &AppLoop<A> {
        &self.lp
    }

    pub fn lp_mut(&mut self) -> &mut AppLoop<A> {
        &mut self.lp
    }

    pub fn window(&self) -> &WaylandWindow {
        &self.win
    }

    pub fn window_mut(&mut self) -> &mut WaylandWindow {
        &mut self.win
    }

    pub fn gpu_mut(&mut self) -> Option<&mut GpuWindow> {
        self.gpu.as_mut()
    }

    /// All three at once, for host code that needs the engine and the window together
    /// (clipboard round-trips, synthetic input). Finish with them before calling `tick`.
    /// 一次性取出三者，供同时需要引擎与窗口的宿主代码（剪贴板往返、合成输入）使用；
    /// 用完再调 `tick`。
    pub fn split(
        &mut self,
    ) -> (
        &mut AppLoop<A>,
        &mut WaylandWindow,
        Option<&mut GpuWindow>,
    ) {
        (&mut self.lp, &mut self.win, self.gpu.as_mut())
    }

    pub fn finished(&self) -> bool {
        self.win.should_close()
    }

    /// How long the last turn waited for a frame callback; a long one means a stalled output.
    /// 上一轮等帧回调的时长；很长说明输出停住了。
    pub fn last_wait(&self) -> Duration {
        self.driver.last_wait()
    }

    /// Frame waits so far and their total, for the host's exit line.
    /// 至今等待帧回调的次数与总时长，供宿主写在退出那一行。
    pub fn wait_stats(&self) -> (Duration, u32) {
        self.driver.wait_stats()
    }

    /// Events the last turn took from the window and dispatched to the app.
    /// 上一轮从窗口取到并派发给应用的事件。
    pub fn events(&self) -> &[ui_core::Event] {
        self.driver.events()
    }

    /// Intake, decide, draw and pace — everything a frame needs.
    /// 摄入、判定、绘制与配速——一帧需要的一切。
    pub fn tick(&mut self) -> Result<Tick, String> {
        let pointer = match self.driver.step(&mut self.lp, &mut self.win) {
            Turn::Draw { pointer } => pointer,
            Turn::Idle | Turn::Waiting => {
                return Ok(Tick {
                    drew: false,
                    outcome: None,
                    presented: None,
                    pointer: None,
                });
            }
        };
        // A scripted pointer wins over the seat's, which the driver just read.
        // 脚本指针压过驱动刚读到的座位指针。
        let pointer = self.pointer.take().or(pointer);
        let framed = match self.gpu.as_mut() {
            Some(gpu) => {
                let mut target = GpuTarget {
                    win: &mut self.win,
                    gpu,
                };
                self.lp.frame_scene(&mut target, pointer)
            }
            None => {
                let outcome = self.lp.frame(&mut self.win, pointer);
                Ok(ui_platform::view::SceneFrameOutcome {
                    outcome,
                    presented: None,
                })
            }
        }?;
        self.driver.pace(&mut self.win);
        Ok(Tick {
            drew: true,
            outcome: Some(framed.outcome),
            presented: framed.presented,
            pointer,
        })
    }
}
