//! Zero-copy presenter: EGL context, double-buffered dma-buf targets, `present_dmabuf`.
//! 零拷贝呈现器：EGL 上下文、双缓冲 dma-buf 目标、`present_dmabuf`。
//!
//! The Wayland surface and the input loop stay with the caller; this owns only the GPU side.
//! 窗口表面与输入循环留在调用方；这里只负责 GPU 一侧。

use std::io::Write;
use std::path::Path;

use ui_core::colour::BufferFormat;
use ui_core::damage::Damage;
use ui_core::draw::DrawList;
use ui_paint_gpu::{AtlasUpload, EglContext, GpuError, GpuRenderer, GpuTarget, SyncTimeline};
use ui_platform::TextPass;

use crate::dmabuf::DmaBufImage;
use crate::window::{device_size, WaylandWindow, WindowError};

/// How many dma-buf targets to cycle: the compositor holds one while we draw the other.
/// dma-buf 目标的数量：合成器持有一个时我们画另一个。
const TARGETS: usize = 2;
static PREV_FRAME: std::sync::Mutex<Option<Vec<u8>>> = std::sync::Mutex::new(None);

/// How long a frame waits for the compositor's release point before drawing anyway.
/// 一帧等 compositor 的 release 点最多等多久，超时就直接画。
const RELEASE_TIMEOUT: std::time::Duration = std::time::Duration::from_millis(50);

/// What [`GpuWindow::open`] needs to know.
/// [`GpuWindow::open`] 需要知道的配置。
#[derive(Clone, Debug)]
pub struct GpuWindowConfig {
    /// DRM render node; `None` asks the driver which GPU drives a connected output.
    /// DRM render 节点；`None` 时问驱动哪块 GPU 在驱动已连接输出。
    pub render_node: Option<String>,
    /// Format of the presented buffers.
    /// 呈现缓冲的格式。
    pub format: BufferFormat,
}

impl Default for GpuWindowConfig {
    fn default() -> Self {
        Self {
            render_node: None,
            format: BufferFormat::Bgra8Srgb,
        }
    }
}

/// Why a [`GpuWindow`] could not open or present a frame.
/// [`GpuWindow`] 为何无法打开或呈现一帧。
#[derive(Debug)]
pub enum GpuWindowError {
    /// The compositor never advertised `zwp_linux_dmabuf_v1`: there is no zero-copy path.
    /// compositor 没有通告 `zwp_linux_dmabuf_v1`：没有零拷贝路径可用。
    NoDmaBuf,
    /// The render node path is not a valid C string.
    /// render 节点路径不是合法的 C 字符串。
    InvalidNode(String),
    /// Nothing has been presented yet, so there is no frame to read back.
    /// 还没有呈现过任何帧，没有内容可读回。
    NotPresented,
    /// EGL, the target pool, or a GL call failed.
    /// EGL、目标池或某个 GL 调用失败。
    Gpu(GpuError),
    /// The Wayland side refused the buffer or the commit.
    /// Wayland 一侧拒绝了缓冲或提交。
    Window(WindowError),
    /// Writing a read-back image failed.
    /// 写出读回图像失败。
    Io(std::io::Error),
}

impl std::fmt::Display for GpuWindowError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::NoDmaBuf => write!(
                f,
                "compositor has no zwp_linux_dmabuf_v1; zero-copy presentation is unavailable"
            ),
            Self::InvalidNode(path) => write!(f, "render node {path:?} is not a valid path"),
            Self::NotPresented => write!(f, "no frame has been presented yet"),
            Self::Gpu(e) => write!(f, "GPU: {e}"),
            Self::Window(e) => write!(f, "{e}"),
            Self::Io(e) => write!(f, "write failed: {e}"),
        }
    }
}

impl std::error::Error for GpuWindowError {}

impl From<GpuError> for GpuWindowError {
    fn from(e: GpuError) -> Self {
        Self::Gpu(e)
    }
}

impl From<WindowError> for GpuWindowError {
    fn from(e: WindowError) -> Self {
        Self::Window(e)
    }
}

impl From<std::io::Error> for GpuWindowError {
    fn from(e: std::io::Error) -> Self {
        Self::Io(e)
    }
}

/// What one [`GpuWindow::present`] call did, so the caller can log it.
/// 一次 [`GpuWindow::present`] 做了什么，供调用方记录。
#[derive(Clone, Copy, Debug)]
pub struct PresentOutcome {
    /// The new device size when the target pool was rebuilt for this frame.
    /// 本帧重建目标池时的新设备尺寸。
    pub resized: Option<(u32, u32)>,
    /// Device pixels per logical unit used for this frame.
    /// 本帧使用的每逻辑单位设备像素数。
    pub scale: f32,
    /// GPU draw calls issued for this frame: the cost driver overhead tracks.
    /// 本帧发出的 GPU 绘制调用数：驱动侧开销跟着它走。
    pub draw_calls: u32,
    /// Device-space redraw band, `None` when the whole surface was redrawn.
    /// 设备空间的重绘带；整面重画时为 `None`。
    pub band: Option<[i32; 4]>,
}

/// A GPU presenter bound to one GPU and one window.
/// 绑定一块 GPU 与一个窗口的 GPU 呈现器。
pub struct GpuWindow {
    ctx: EglContext,
    renderer: GpuRenderer,
    /// The DRM timelines carrying this window's acquire/release points.
    /// 携带本窗口 acquire/release 点的 DRM timeline。
    sync_timeline: Option<SyncTimeline>,
    /// The compositor signals this timeline once it has stopped reading a buffer.
    /// compositor 读完一个缓冲后会在本时间线上 signal。
    sync_release_timeline: Option<SyncTimeline>,
    /// Last acquire point handed to the compositor; points must strictly increase.
    /// 交给 compositor 的最后一个 acquire 点；点必须严格递增。
    acquire_point: u64,
    /// Release point each target was last presented with, so reuse can wait for it.
    /// 每个目标上次呈现时用的 release 点，复用时据此等待。
    release_points: [u64; TARGETS],
    /// Last release point handed out; points must strictly increase.
    /// 发出的最后一个 release 点；点必须严格递增。
    release_point: u64,
    targets: Vec<GpuTarget>,
    /// Device size of the current pool; `(0, 0)` before the first present.
    /// 当前目标池的设备尺寸；首次呈现前是 `(0, 0)`。
    size: (u32, u32),
    format: BufferFormat,
    /// Index of the target to render into next.
    /// 下一个要渲染的目标下标。
    next: usize,
    /// Index of the target handed to the compositor last.
    /// 最近交给 compositor 的目标下标。
    last: usize,
    /// Bands drawn since the oldest target in the pool was last written, newest last.
    /// 池中最旧的目标上次写入之后画过的重绘带，最新的在末尾。
    recent_bands: Vec<[i32; 4]>,
    atlas_version: u64,
    color_atlas_version: u64,
    node: String,
}

impl GpuWindow {
    /// Create the EGL context and renderer for `win`, or say why it is impossible.
    /// 为 `win` 创建 EGL 上下文与渲染器，或说明为何做不到。
    pub fn open(win: &mut WaylandWindow, config: GpuWindowConfig) -> Result<Self, GpuWindowError> {
        if !win.has_dmabuf() {
            return Err(GpuWindowError::NoDmaBuf);
        }
        let node = config
            .render_node
            .or_else(ui_paint_gpu::output_render_node)
            .unwrap_or_else(|| "/dev/dri/renderD128".to_string());
        let cnode = std::ffi::CString::new(node.clone())
            .map_err(|_| GpuWindowError::InvalidNode(node.clone()))?;
        let ctx = EglContext::new(cnode.as_c_str())?;
        let renderer = GpuRenderer::new(ctx.gl(), ctx.is_gles())?;
        // Explicit synchronization: a DRM timeline whose fd the compositor imports, so each
        // frame carries an acquire point instead of relying on implicit fences.
        // 显式同步：一个 DRM timeline，compositor 导入它的 fd，每帧因此携带 acquire 点，
        // 不再依赖隐式 fence。
        let (sync_timeline, sync_release_timeline) =
            match (SyncTimeline::new(ctx.drm_fd()), SyncTimeline::new(ctx.drm_fd())) {
                (Ok(acquire), Ok(release)) => match (acquire.dup_fd(), release.dup_fd()) {
                    (Ok(afd), Ok(rfd)) => {
                        if win.attach_sync_timelines(afd, rfd) {
                            eprintln!("explicit sync: acquire/release timelines attached");
                            (Some(acquire), Some(release))
                        } else {
                            eprintln!(
                                "explicit sync unavailable: no wp_linux_drm_syncobj_manager_v1"
                            );
                            (None, None)
                        }
                    }
                    _ => (None, None),
                },
                (Err(e), _) | (_, Err(e)) => {
                    eprintln!("explicit sync unavailable: {e}");
                    (None, None)
                }
            };
        Ok(Self {
            ctx,
            renderer,
            sync_timeline,
            sync_release_timeline,
            acquire_point: 0,
            release_points: [0; TARGETS],
            release_point: 0,
            targets: Vec::new(),
            size: (0, 0),
            format: config.format,
            next: 0,
            last: 0,
            recent_bands: Vec::new(),
            atlas_version: u64::MAX,
            color_atlas_version: 0,
            node,
        })
    }

    /// The GPU's own renderer string, for reporting which device is in use.
    /// GPU 自报的渲染器字符串，用于报告用的是哪块设备。
    pub fn renderer_name(&self) -> String {
        self.ctx.renderer()
    }

    /// The render node this presenter opened.
    /// 本呈现器打开的 render 节点。
    pub fn node(&self) -> &str {
        &self.node
    }

    /// Wait until the GPU has executed every command submitted so far.
    /// 等到 GPU 执行完已提交的全部命令。
    ///
    /// A queue still full at exit drains while the compositor waits behind it, which is
    /// what a frozen screen after closing looks like.
    /// 退出时仍未排空的队列，会在 compositor 排在它后面时继续消耗，屏幕因此冻住。
    pub fn finish(&self) {
        self.renderer.finish(self.ctx.gl());
    }

    /// Format of the presented buffers.
    /// 呈现缓冲的格式。
    pub fn format(&self) -> BufferFormat {
        self.format
    }

    /// DRM fourcc of the presented buffers.
    /// 呈现缓冲的 DRM fourcc。
    pub fn fourcc(&self) -> u32 {
        self.format.drm_fourcc()
    }

    /// The renderer, for pipeline choices such as HDR or internal precision.
    /// 渲染器，用于 HDR、内部精度之类的管线选择。
    pub fn renderer_mut(&mut self) -> &mut GpuRenderer {
        &mut self.renderer
    }

    /// Upload the glyph atlases if the text pass changed them; returns whether it did.
    /// 文本 pass 让图集变化时上传；返回是否真的上传了。
    pub fn sync_atlas(&mut self, pass: &TextPass) -> Result<bool, GpuWindowError> {
        let mut uploaded = false;
        if pass.version() != self.atlas_version {
            self.atlas_version = pass.version();
            let (width, height) = pass.dimensions();
            self.renderer.set_atlas(
                self.ctx.gl(),
                AtlasUpload {
                    width,
                    height,
                    data: pass.atlas().to_vec(),
                },
            )?;
            uploaded = true;
        }
        // The colour page is tracked separately: a new text glyph must not re-upload it.
        // 颜色页单独跟踪：新增文字字形不应重传它。
        if pass.color_version() != self.color_atlas_version {
            self.color_atlas_version = pass.color_version();
            if !pass.color_atlas().is_empty() {
                let (width, height) = pass.color_dimensions();
                self.renderer.set_color_atlas(
                    self.ctx.gl(),
                    AtlasUpload {
                        width,
                        height,
                        data: pass.color_atlas().to_vec(),
                    },
                )?;
                uploaded = true;
            }
        }
        Ok(uploaded)
    }

    /// Render `list` at `logical` size into the back target and hand it to the compositor.
    /// 把 `list` 按 `logical` 尺寸渲染进后置目标并交给 compositor。
    pub fn present(
        &mut self,
        win: &mut WaylandWindow,
        logical: (u32, u32),
        list: &DrawList,
        damage: &Damage,
    ) -> Result<PresentOutcome, GpuWindowError> {
        let scale = win.scale();
        let device = device_size(logical, scale);
        let resized = if device == self.size {
            None
        } else {
            self.rebuild(device)?;
            // The old targets' dma-bufs are gone; their cached buffers must not survive to
            // be matched by a reused inode.
            // 旧目标的 dma-buf 已释放；缓存的缓冲不能留到被复用的 inode 匹配上。
            win.forget_dmabuf_cache();
            Some(device)
        };

        self.renderer.set_scale(scale);
        // A rebuilt pool holds no previous frame, so the whole surface has to be redrawn.
        // 重建过的目标池里没有上一帧，因此必须整面重画。
        let damage = if resized.is_some() {
            &Damage::Full
        } else {
            damage
        };
        // The compositor may still be scanning out this target's previous frame; writing
        // now would let it sample a half-drawn one. Its release point says when it is done.
        // compositor 可能仍在扫描本目标上一帧的内容；此刻写入会让它采样到画了一半的帧。
        // 它的 release 点说明它何时读完。
        if let Some(timeline) = self.sync_release_timeline.as_ref() {
            let point = self.release_points[self.next];
            if point != 0 && !timeline.wait(point, RELEASE_TIMEOUT) {
                eprintln!("present: release point {point} timed out; drawing anyway");
            }
        }
        let target = &self.targets[self.next];
        // A target only holds the bands drawn on the frames it was handed, so it also needs
        // everything drawn since its last turn. Without that the compositor shows an old
        // frame for one buffer's worth of time — the residue and flicker this pool caused.
        // 目标只带它被交付的那些帧上画过的重绘带，因此上次轮到它之后画的内容也得一并搬过去；
        // 少了这一半，compositor 会有一个缓冲周期显示旧内容——就是这套轮转造成的残留与闪烁。
        let stats = self.renderer.render_frame_into(
            self.ctx.gl(),
            target,
            list,
            damage,
            &self.recent_bands,
        )?;
        let full = [0, 0, self.size.0 as i32, self.size.1 as i32];
        self.recent_bands.push(stats.band.unwrap_or(full));
        while self.recent_bands.len() >= TARGETS {
            self.recent_bands.remove(0);
        }
        // Explicit sync exports a fence the compositor waits on; without it, block here so
        // the compositor never samples writes that have not landed yet.
        // 显式同步导出一个 compositor 会等待的 fence；没有它就在这里阻塞，
        // 使 compositor 绝不采样到尚未落地的写入。
        let acquire_point = match self.sync_timeline.as_ref() {
            Some(timeline) => {
                let fence = self.ctx.export_fence()?;
                self.acquire_point += 1;
                let point = self.acquire_point;
                timeline.import_fence_at(&fence.fd, point)?;
                Some(point)
            }
            None => {
                // Without explicit sync the compositor cannot tell when these writes land, so
                // wait here. Measured: this blocks (200–300µs) but burns no CPU.
                // 没有显式同步时 compositor 无从得知写入何时落地，因此在这里等待。
                // 实测：它只是阻塞（200~300µs），并不消耗 CPU。
                self.renderer.finish(self.ctx.gl());
                None
            }
        };

        let desc = target.desc();
        let image = DmaBufImage {
            fd: target.dup_fd()?,
            width: desc.width,
            height: desc.height,
            stride: desc.stride,
            offset: desc.offset,
            format: self.fourcc(),
            modifier: desc.modifier,
        };
        // The release point rides this commit: the compositor signals it once done reading.
        // release 点随这次提交一起发出：compositor 读完就会 signal 它。
        self.release_point += 1;
        let release_point = self.release_point;
        self.release_points[self.next] = release_point;
        // Report what this frame actually redrew. Everything outside the band is already the
        // same in the handed-over buffer, so the compositor may keep its copy there.
        // 上报本帧真正重画的区域。带外内容在交出的缓冲里已经一致，合成器可以保留自己的副本。
        let reported = match stats.band {
            Some([x, y, w, h]) => {
                let s = scale.max(f32::EPSILON);
                Damage::Rects(vec![ui_core::geom::Rect::new(
                    x as f32 / s,
                    y as f32 / s,
                    w as f32 / s,
                    h as f32 / s,
                )])
            }
            None => Damage::Full,
        };
        // Probe: a handed-over buffer promises the whole surface, so it must match the frame.
        // 探针：交出的缓冲承诺了整面内容，因此必须与持久帧一致。
        if std::env::var_os("CRABSNAP_TARGET_CHECK").is_some() {
            if let Some((n, bbox)) = self.renderer.diff_frame(self.ctx.gl(), target) {
                eprintln!(
                    "[target-check] differing={n} bbox={bbox:?} band={:?} reported={reported:?}",
                    stats.band
                );
            }
            // A change outside the band would never reach the compositor: it is not reported.
            // 带外的变化永远到不了 compositor：它没有被上报。
            if let Some((w, h, px)) = self.renderer.frame_pixels(self.ctx.gl()) {
                let mut prev = PREV_FRAME.lock().unwrap();
                if let Some(p) = prev.as_ref().filter(|p| p.len() == px.len()) {
                    let band = stats.band.unwrap_or([0, 0, w as i32, h as i32]);
                    let (mut c, mut x0, mut y0, mut x1, mut y1) =
                        (0u32, u32::MAX, u32::MAX, 0u32, 0u32);
                    for (i, (a, b)) in px
                        .as_chunks::<4>()
                        .0
                        .iter()
                        .zip(p.as_chunks::<4>().0)
                        .enumerate()
                    {
                        if a != b {
                            let (x, y) = (i as u32 % w, i as u32 / w);
                            let outside = (x as i32) < band[0]
                                || (y as i32) < band[1]
                                || (x as i32) >= band[0] + band[2]
                                || (y as i32) >= band[1] + band[3];
                            if outside {
                                c += 1;
                                x0 = x0.min(x);
                                y0 = y0.min(y);
                                x1 = x1.max(x);
                                y1 = y1.max(y);
                            }
                        }
                    }
                    if c > 0 {
                        eprintln!(
                            "[frame-outside] {c} px at [{x0},{y0},{x1},{y1}] band={:?}",
                            stats.band
                        );
                    }
                }
                *prev = Some(px);
            }
        }
        win.present_dmabuf(&image, &reported, acquire_point, release_point)?;

        self.last = self.next;
        self.next = (self.next + 1) % self.targets.len();
        Ok(PresentOutcome {
            resized,
            scale,
            draw_calls: stats.draw_calls,
            band: stats.band,
        })
    }

    /// Write the last presented frame and its layer 0 as PPM files.
    /// 把最近呈现的帧与它的第 0 层写成 PPM 文件。
    pub fn dump_ppm(
        &self,
        frame: &Path,
        layer: &Path,
    ) -> Result<Option<(u32, u32)>, GpuWindowError> {
        if self.targets.is_empty() {
            return Err(GpuWindowError::NotPresented);
        }
        let pixels = self.renderer.read_pixels(self.ctx.gl(), &self.targets[self.last])?;
        write_ppm(frame, self.size.0, self.size.1, &pixels, |p| [p[0], p[1], p[2]])?;
        // Alpha as grey, so transparency is visible instead of guessed.
        // alpha 当灰度用，透明区域因此可见而不是靠猜。
        // Layer 0 is absent when the frame painted no group; that is not an error.
        // 帧里没有组时第 0 层不存在；这不是错误。
        match self.renderer.read_layer(self.ctx.gl(), 0) {
            Some((w, h, buf)) => {
                write_ppm(layer, w, h, &buf, |p| [p[3], p[3], p[3]])?;
                Ok(Some((w, h)))
            }
            None => Ok(None),
        }
    }

    /// Allocate a fresh pool of `device`-sized targets; the old one is released only on success.
    /// 按 `device` 尺寸重建目标池；只在成功后才释放旧的。
    fn rebuild(&mut self, device: (u32, u32)) -> Result<(), GpuWindowError> {
        let fourcc = self.fourcc();
        let mut fresh = Vec::with_capacity(TARGETS);
        for _ in 0..TARGETS {
            match GpuTarget::new_with_fourcc(&self.ctx, device.0, device.1, fourcc) {
                Ok(t) => fresh.push(t),
                Err(e) => {
                    for t in &fresh {
                        t.release(&self.ctx);
                    }
                    return Err(GpuWindowError::Gpu(e));
                }
            }
        }
        self.release_targets();
        self.targets = fresh;
        self.size = device;
        self.next = 0;
        self.last = 0;
        // Fresh dma-bufs carry no earlier point; the old points name buffers that are gone.
        // 新的 dma-buf 没有更早的点；旧点指的是已经消失的缓冲。
        self.release_points = [0; TARGETS];
        // Fresh targets hold nothing, and the full frame they get next covers them.
        // 新目标里什么都没有，而它们下一帧拿到的整帧会覆盖全部内容。
        self.recent_bands.clear();
        Ok(())
    }

    fn release_targets(&mut self) {
        for t in &self.targets {
            t.release(&self.ctx);
        }
        self.targets.clear();
    }
}

impl Drop for GpuWindow {
    /// Release GL objects while the EGL context is still alive: fields drop after this body.
    /// 在 EGL 上下文仍存活时释放 GL 对象：字段在本函数体之后才析构。
    fn drop(&mut self) {
        ui_platform::exit_probe::stage("gpu: targets");
        self.release_targets();
        ui_platform::exit_probe::stage("gpu: renderer");
        self.renderer.release(self.ctx.gl());
        // EGL teardown is the driver's: `eglTerminate` waits for its worker threads.
        // EGL 拆除归驱动：`eglTerminate` 要等它自己的工作线程。
        ui_platform::exit_probe::stage("gpu: egl");
    }
}

/// Write top-down RGBA8 pixels as binary PPM, taking three channels per pixel.
/// 把自顶向下的 RGBA8 像素写成二进制 PPM，每像素取三个通道。
fn write_ppm(
    path: &Path,
    width: u32,
    height: u32,
    rgba: &[u8],
    pick: impl Fn(&[u8]) -> [u8; 3],
) -> std::io::Result<()> {
    let mut file = std::fs::File::create(path)?;
    write!(file, "P6\n{width} {height}\n255\n")?;
    for p in rgba.as_chunks::<4>().0 {
        file.write_all(&pick(p))?;
    }
    Ok(())
}

