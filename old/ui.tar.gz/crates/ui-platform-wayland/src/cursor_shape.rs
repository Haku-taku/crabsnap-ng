//! Mapping the framework's neutral shape names onto `wp_cursor_shape_v1`.
//! 把框架的中立形状名映射到 `wp_cursor_shape_v1`。

use ui_core::CursorShape;
use wayland_protocols::wp::cursor_shape::v1::client::wp_cursor_shape_device_v1::Shape;

/// The protocol value for a shape. Total, so a new variant cannot silently mean `Default`.
/// 形状对应的协议值。函数是全映射，因此新增变体不会静默退化为 `Default`。
pub(crate) fn protocol_shape(shape: CursorShape) -> Shape {
    match shape {
        CursorShape::Arrow => Shape::Default,
        CursorShape::Text => Shape::Text,
        CursorShape::Crosshair => Shape::Crosshair,
        CursorShape::PointingHand => Shape::Pointer,
        CursorShape::Grab => Shape::Grab,
        CursorShape::Grabbing => Shape::Grabbing,
        CursorShape::Move => Shape::Move,
        CursorShape::NotAllowed => Shape::NotAllowed,
        CursorShape::Copy => Shape::Copy,
        CursorShape::Alias => Shape::Alias,
        CursorShape::NoDrop => Shape::NoDrop,
        CursorShape::ResizeHorizontal => Shape::EwResize,
        CursorShape::ResizeVertical => Shape::NsResize,
        CursorShape::ResizeDiagonalDownRight => Shape::NwseResize,
        CursorShape::ResizeDiagonalUpRight => Shape::NeswResize,
        CursorShape::ResizeColumn => Shape::ColResize,
        CursorShape::ResizeRow => Shape::RowResize,
        CursorShape::AllScroll => Shape::AllScroll,
        CursorShape::ZoomIn => Shape::ZoomIn,
        CursorShape::ZoomOut => Shape::ZoomOut,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Distinct protocol values, so a copy-paste slip cannot make two cursors identical.
    /// 协议值互不相同，因此复制粘贴漏改不会让两种光标看起来一样。
    fn every_shape() -> [CursorShape; 20] {
        [
            CursorShape::Arrow,
            CursorShape::Text,
            CursorShape::Crosshair,
            CursorShape::PointingHand,
            CursorShape::Grab,
            CursorShape::Grabbing,
            CursorShape::Move,
            CursorShape::NotAllowed,
            CursorShape::Copy,
            CursorShape::Alias,
            CursorShape::NoDrop,
            CursorShape::ResizeHorizontal,
            CursorShape::ResizeVertical,
            CursorShape::ResizeDiagonalDownRight,
            CursorShape::ResizeDiagonalUpRight,
            CursorShape::ResizeColumn,
            CursorShape::ResizeRow,
            CursorShape::AllScroll,
            CursorShape::ZoomIn,
            CursorShape::ZoomOut,
        ]
    }

    #[test]
    fn every_shape_maps_to_a_distinct_protocol_value() {
        let mapped: Vec<Shape> = every_shape().iter().map(|s| protocol_shape(*s)).collect();
        for (i, a) in mapped.iter().enumerate() {
            for b in &mapped[i + 1..] {
                assert_ne!(a, b, "two framework shapes map to the same protocol value");
            }
        }
    }

    #[test]
    fn diagonal_resizes_are_not_swapped() {
        // "down-right" runs along `\` (nwse); swapping these is invisible in a smoke test.
        // 「右下」沿 `\`（nwse）；互换这两种在冒烟测试里看不出来。
        assert_eq!(protocol_shape(CursorShape::ResizeDiagonalDownRight), Shape::NwseResize);
        assert_eq!(protocol_shape(CursorShape::ResizeDiagonalUpRight), Shape::NeswResize);
    }

    #[test]
    fn horizontal_resize_maps_to_the_axis_that_is_named() {
        // A transposed axis still "works" but resizes the wrong way.
        // 轴写反依然「能用」，只是缩放方向错了。
        assert_eq!(protocol_shape(CursorShape::ResizeHorizontal), Shape::EwResize);
        assert_eq!(protocol_shape(CursorShape::ResizeVertical), Shape::NsResize);
    }
}
