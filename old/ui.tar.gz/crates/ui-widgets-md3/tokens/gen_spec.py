#!/usr/bin/env python3
"""Turn a Material design-system token export into a usable Rust spec function.

Two subcommands:

    inspect  Print the control's states / objects / properties and the full
             state -> object -> property table as JSON.
    gen      Emit a lean Rust module: per-object structs plus one function whose
             boolean parameters are the non-default states. It starts from the
             default values and overlays each active state in priority order.

Token names look like `md.comp.<control>.<states...>.<object>.<property>`; the object may
itself contain dots (`track.outline`, `focus.indicator`) and may be absent entirely
(`md.comp.divider.color`, where the control is its own object). A state is any segment that
is not part of the matched object, so the vocabulary does not have to be declared up front —
unknown states are *reported* instead of silently dropping the token.

Deprecated tokens (`deprecationMessage` on the token) are skipped.
"""
from __future__ import annotations

import argparse
import json
import sys

# Object vocabularies per control; `""` means the control itself (no object segment).
# Objects are matched longest-first, so `track.outline` wins over `track`.
# 每个控件的对象词表；`""` 表示控件自身（没有对象段）。对象按最长优先匹配。
OBJECTS_BY_CONTROL = {
    "md.comp.switch": ["track.outline", "track", "handle", "icon", "state-layer", "focus.indicator"],
    "md.comp.slider": [
        "track.inner-corner", "track.outer-corner", "stop-indicator.container",
        "value-indicator.label.label-text", "label.label-text", "value-indicator.container",
        "track.shape", "handle.outline", "label.container", "stop-indicator",
        "state-layer", "container", "handle", "track", "icon", "label", "value-indicator", "stop",
    ],
    "md.comp.checkbox": [
        "focus.indicator.outline", "focus.indicator", "container.outline",
        "container", "outline", "icon", "state-layer",
    ],
    "md.comp.radio-button": ["icon", "state-layer", ""],
    # The button group's own tokens are the corner radius and the gap; the member's colours
    # come from `md.comp.button`, so no state-layer or icon vocabulary is needed here.
    # 按钮组自身的令牌只有圆角与间距；成员颜色来自 `md.comp.button`，这里不需要状态层或图标词表。
    "md.comp.button-group.connected": ["container", ""],
    "md.comp.button-group.standard": ["container", ""],
    # Segmented buttons keep the member's own parts: one shared outline, per-segment state.
    # 分段按钮保留成员自身各部件：整组共用一条描边，状态按段计。
    "md.comp.outlined-segmented-button": [
        "focus.indicator.outline", "focus.indicator", "label-text", "state-layer",
        "outline", "container", "icon",
    ],
    # Progress indicator: `circular`/`linear` are shape variants, not states, and the 4dp
    # thickness tokens are deprecated upstream — the numbers come only from the deprecations.
    # 进度指示器：`circular`/`linear` 是形状变体而非状态，且 4dp 粗细令牌上游已废弃——
    # 数值只能取自废弃项。
    "md.comp.progress-indicator": [
        "active-indicator", "track", "stop-indicator",
    ],
    # Navigation bar: `active` is a real state here (the export's base is `inactive`), so the
    # selected item reads a different colour, weight and state layer from its neighbours.
    # 导航栏：`active` 在这里是真状态（导出的基态是 `inactive`），选中项与邻项的颜色、
    # 字重与状态层都不同。
    "md.comp.navigation-bar": [
        "active-indicator", "focus.indicator.outline", "focus.indicator",
        "label-text", "state-layer", "container", "icon",
    ],
    # Navigation rail: the same destination as the bar, stacked in a fixed-width column; with
    # no label the indicator becomes a 56×56 circle instead of the 56×32 capsule.
    # 导航栏轨道：与导航栏同一套目标，纵向堆在定宽列里；无标签时指示片由 56×32 胶囊
    # 变成 56×56 正圆。
    "md.comp.navigation-rail": [
        "active-indicator", "label-text", "state-layer", "container", "icon",
    ],
    # Navigation drawer: `standard`/`modal` are variant states on the container's colour and
    # elevation; the deprecated `container.color`/`scrim.*` must not be revived.
    # 导航抽屉：`standard`/`modal` 是容器颜色与高度的变体状态；已废弃的
    # `container.color`/`scrim.*` 不得复活。
    "md.comp.navigation-drawer": [
        "active-indicator", "bottom.container", "focus.indicator.outline", "focus.indicator",
        "large-badge-label", "label-text", "headline", "state-layer", "container", "icon",
    ],
    # The date input's surface: a header band (headline over supporting text) and the
    # container. `header.headline` must beat a bare `headline` match, or `header` reads as
    # a state and the band loses its own object.
    # 日期输入的表面：头部带（标题盖在辅助文本上）与容器。`header.headline` 必须赢过单独的
    # `headline` 匹配，否则 `header` 会被读成状态、这条带就丢了自己的对象。
    "md.comp.date-input.modal": [
        "header.container", "header.headline", "header.supporting-text",
        "header", "container",
    ],
    # Toolbar geometry and its two member themes; the container's colour lives in the theme
    # table, not the geometry one (the docked `container.color` is deprecated).
    # 工具条的几何与两套成员主题；容器颜色在主题表里而不在几何表（docked 的
    # `container.color` 已废弃）。
    "md.comp.toolbar.docked": ["container"],
    "md.comp.toolbar.floating": ["container", "horizontal.container", "vertical.container"],
    "md.comp.toolbar.standard": [
        "button.container", "label-text", "state-layer", "container", "icon",
    ],
    "md.comp.toolbar.vibrant": [
        "button.container", "label-text", "state-layer", "container", "icon",
    ],
    # Snackbar: the body text is `supporting-text`; `label-text` exists only under `action`.
    # 提示条：正文叫 `supporting-text`；`label-text` 只挂在 `action` 下。
    "md.comp.snackbar": [
        "action.label-text", "action.state-layer", "supporting-text",
        "icon.state-layer", "container", "icon",
    ],
    "md.comp.divider": [""],
    "md.comp.badge": ["label-text", ""],
    "md.comp.secondary-navigation-tab": [
        "active-indicator", "focus.indicator.outline", "focus.indicator", "label-text",
        "state-layer", "container", "divider", "icon",
    ],
    "md.comp.elevated-card": [
        "container.surface-tint-layer", "focus.indicator.outline", "focus.indicator",
        "container", "state-layer", "outline", "icon",
    ],
    "md.comp.filled-card": [
        "container.surface-tint-layer", "focus.indicator.outline", "focus.indicator",
        "container", "state-layer", "outline", "icon",
    ],
    "md.comp.outlined-card": [
        "container.surface-tint-layer", "focus.indicator.outline", "focus.indicator",
        "container", "state-layer", "outline", "icon",
    ],
    "md.comp.assist-chip": [
        "focus.indicator.outline", "focus.indicator", "container.surface-tint-layer",
        "container", "label-text", "state-layer", "outline", "icon",
    ],
    "md.comp.suggestion-chip": [
        "focus.indicator.outline", "focus.indicator", "container.surface-tint-layer",
        "container", "label-text", "state-layer", "outline", "leading-icon",
    ],
    "md.comp.filter-chip": [
        "focus.indicator.outline", "focus.indicator", "container.surface-tint-layer",
        "container", "label-text", "state-layer", "outline", "icon",
        "leading-icon", "trailing-icon",
    ],
    "md.comp.input-chip": [
        "focus.indicator.outline", "focus.indicator", "container.surface-tint-layer",
        "container", "label-text", "state-layer", "outline",
        "leading-icon", "trailing-icon", "avatar",
    ],
    "md.comp.fab-menu": [
        "close-button.container", "close-button.icon", "close-button.state-layer", "close-button",
        "menu-item.container", "menu-item.icon", "menu-item.label-text", "menu-item.state-layer",
        "menu-item",
        "list-item.container", "list-item.icon", "list-item.label-text", "list-item.state-layer",
        "list-item",
    ],
    "md.comp.list": [
        "focus.indicator.outline", "focus.indicator",
        "leading-icon.icon", "trailing-icon.icon",
        "label-text", "overline", "supporting-text", "trailing-supporting-text",
        "leading-icon", "trailing-icon", "leading-avatar", "leading-avatar-label",
        "leading-image", "leading-video",
        "state-layer", "container", "divider", "drop-zone", "segmented", "gap",
    ],
    "md.comp.dialog": [
        "headline", "supporting-text", "label-text", "state-layer", "container", "icon",
    ],
    "md.comp.outlined-text-field": [
        "focus.indicator.outline", "focus.indicator",
        "input-text.placeholder", "input-text.prefix", "input-text.suffix",
        "label-text.populated",
        "supporting-text", "leading-icon", "trailing-icon",
        "input-text", "label-text", "caret", "outline", "container",
    ],
    "md.comp.filled-text-field": [
        "focus.indicator.outline", "focus.indicator",
        "input-text.placeholder", "input-text.prefix", "input-text.suffix",
        "label-text.populated",
        "supporting-text", "leading-icon", "trailing-icon", "active-indicator",
        "state-layer", "input-text", "label-text", "caret", "container",
    ],
}


def objects_for(prefixes: list[str]) -> list[str]:
    objs: set[str] = set()
    for prefix in prefixes:
        known = OBJECTS_BY_CONTROL.get(prefix)
        if known is None:
            # The empty object means "no object path at all"; borrowing it would swallow every
            # path segment as a state, so it only applies to controls that declare it.
            # 空对象意味着「完全没有对象路径」；借用它会把每个路径段都当成状态，
            # 因此只对显式声明它的控件生效。
            known = [o for group in OBJECTS_BY_CONTROL.values() for o in group if o]
        objs.update(known)
    return sorted(objs, key=lambda o: (-len(o.split(".")), -len(o)))


# The default state: every other state becomes a parameter or a variant enum value.
# 默认态：其余每个状态要么变成参数，要么变成枚举值。
DEFAULT_STATE = "unselected"


def load(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)["system"]


def values_of(token: dict, values: list[dict]) -> list[dict]:
    prefix = token["name"] + "/values/"
    return [v for v in values if v["name"].startswith(prefix)]


def default_value(vals: list[dict]) -> dict | None:
    if not vals:
        return None
    bare = [v for v in vals if not v.get("contextTags")]
    if bare:
        return bare[-1]
    return min(vals, key=lambda v: len(v.get("contextTags", [])))


def deprecated(token: dict) -> bool:
    return "deprecationMessage" in token


def argb(color: dict) -> int:
    def q(x: float) -> int:
        return max(0, min(255, round(x * 255)))

    return (
        (q(color.get("alpha", 1.0)) << 24)
        | (q(color.get("red", 0)) << 16)
        | (q(color.get("green", 0)) << 8)
        | q(color.get("blue", 0))
    )


class Resolver:
    def __init__(self, tokens: list[dict], values: list[dict]):
        self.by_name = {t["tokenName"]: t for t in tokens}
        self.values = values

    def resolve(self, value: dict, depth: int = 0) -> tuple[str, object]:
        if depth > 8:
            return ("ref", "?")
        if "tokenName" in value:
            name = value["tokenName"]
            if name.startswith(("md.sys.color.", "md.ref.palette.")):
                return ("colour", name)
            token = self.by_name.get(name)
            if token is not None:
                nxt = default_value(values_of(token, self.values))
                if nxt is not None:
                    return self.resolve(nxt, depth + 1)
            return ("ref", name)
        if "length" in value:
            # Some exported lengths carry only a unit and no number; there is nothing to emit.
            # 有些导出的长度只有单位没有数值，没有可生成的东西。
            if "value" not in value["length"]:
                return ("missing", None)
            return ("length", float(value["length"]["value"]))
        if "opacity" in value:
            return ("opacity", float(value["opacity"]))
        if "color" in value:
            return ("colour_hex", argb(value["color"]))
        if "shape" in value:
            family = value["shape"].get("family", "")
            return ("shape", family.replace("SHAPE_FAMILY_", "").lower())
        if "elevation" in value:
            return ("elevation", float(value["elevation"].get("value", 0)))
        for numeric in ("fontSize", "lineHeight", "fontTracking", "fontWeight"):
            if numeric in value:
                # The export writes these as bare numbers, not `{value: n}`.
                # 导出里这些是裸数字，不是 `{value: n}`。
                raw = value[numeric]
                if isinstance(raw, dict):
                    raw = raw.get("value", 0)
                return ("length", float(raw))
        if "fontNames" in value:
            names = value["fontNames"].get("values") or ["?"]
            return ("font", names[0])
        if "type" in value:
            # The scale name lives in the size token's name, not its value (a bare number).
            # A component may point at its own `size` token first, so follow the chain of
            # names until a `md.sys.typescale.<name>.size` shows up.
            # 字阶名在字号令牌的**名字**里，不在值里（值是裸数字）。组件可能先指向自己的
            # `size` 令牌，因此沿名字链走到 `md.sys.typescale.<name>.size` 为止。
            name = value["type"].get("fontSizeTokenName", "")
            for _ in range(4):
                parts = name.split(".")
                if len(parts) >= 5 and parts[:3] == ["md", "sys", "typescale"]:
                    return ("scale", parts[3])
                token = self.by_name.get(name)
                nxt = default_value(values_of(token, self.values)) if token else None
                if not nxt or "tokenName" not in nxt:
                    break
                name = nxt["tokenName"]
            return ("scale", "?")
        return ("ref", "?")


def split_token(name: str, prefix: str, objects: list[str]) -> tuple[tuple[str, ...], str, str] | None:
    """Split `<states...>.<object>.<property>`; the export also writes `<object>.<states...>`
    and `<object-head>.<states...>.<object-tail>` (e.g. `close-button.focused.container`)."""
    if not name.startswith(prefix + "."):
        return None
    body = name[len(prefix) + 1 :].split(".")
    if not body or not body[0]:
        return None
    prop = body[-1]
    head = body[:-1]
    # Several objects can match one path (`segmented.container` vs `segmented` + `container`);
    # the longest object wins, then the match that leaves the object closest to the property.
    # 一条路径可能有多个对象能匹配；对象越长越优先，同长时取离属性最近的那种匹配。
    best: tuple[tuple[int, int], list[str], str] | None = None
    for obj in objects:
        parts = obj.split(".") if obj else []
        if not parts:
            # The empty object is the last resort, not a candidate: `md.comp.button.icon-label-space`
            # is the control's own property, but `md.comp.button.container.color` is not.
            # 空对象是兜底而不是候选：`md.comp.button.icon-label-space` 是控件自身的属性，
            # 但 `md.comp.button.container.color` 不是。
            continue
        if len(head) < len(parts):
            continue
        states: list[str] | None = None
        kind = 0
        if head[-len(parts) :] == parts:
            # Object right before the property.
            # 对象紧挨属性。
            states, kind = head[: -len(parts)], 3
        elif head[: len(parts)] == parts:
            # Object right after the prefix.
            # 对象紧挨前缀。
            states, kind = head[len(parts) :], 1
        else:
            tail = parts[1:]
            if tail and head[0] == parts[0] and head[-len(tail) :] == tail:
                # States wedged between the object's head and tail: `close-button.focused.container`.
                # 状态夹在对象头尾之间：`close-button.focused.container`。
                states, kind = head[1 : -len(tail)], 2
            elif len(head) > len(parts):
                # Object segments in order but not contiguous, with states anywhere between
                # (`primary.close-button.hovered.container`). Matched greedily from the left.
                # 对象各段按顺序但不连续、状态散落在其间。从左往右贪心匹配。
                taken: list[int] = []
                at = 0
                for part in parts:
                    while at < len(head) and head[at] != part:
                        at += 1
                    if at == len(head):
                        break
                    taken.append(at)
                    at += 1
                if len(taken) == len(parts):
                    states = [s for i, s in enumerate(head) if i not in taken]
        if states is None:
            continue
        key = (len(parts), kind)
        if best is None or key > best[0]:
            best = (key, states, obj)
    if best is None:
        # Nothing matched: the whole head is states and the control itself is the object.
        # 什么都没匹配上：整个 head 都是状态，对象就是控件自身。
        return tuple(sorted(set(head))), "", prop
    return tuple(sorted(set(best[1]))), best[2], prop


def rust_float(x: float) -> str:
    s = f"{x:g}"
    return s if ("." in s or "e" in s or "E" in s) else s + ".0"


def to_camel(kebab: str) -> str:
    parts = kebab.split("-")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


COLOUR_PREFIX = "md.sys.color."


def pack_role(token: str) -> str:
    # `md.sys.color.primary-container` is the very token our pack calls `primaryContainer`.
    # `md.sys.color.primary-container` 就是包里那个 `primaryContainer`。
    if token.startswith(COLOUR_PREFIX):
        return to_camel(token[len(COLOUR_PREFIX) :])
    return token


def rust_type(kind: str) -> str:
    # The declared type can lie about the payload: `label-text.font` is declared FONT_SIZE but
    # resolves to a scale name. A string payload always wins.
    # 声明类型可能与载荷不符：`label-text.font` 声明为 FONT_SIZE，解析出的却是字阶名。
    if kind in ("colour", "colour_hex", "shape", "font", "scale", "ref"):
        return "&'static str"
    return "f32"


def value_literal(kind: str, payload: object) -> str:
    if kind == "colour":
        return f'"{pack_role(payload)}"'
    if kind == "shape":
        return f'"{payload}"'
    if kind == "colour_hex":
        return f'"#{payload:08x}"'
    if isinstance(payload, str):
        return f'"{payload}"'
    return rust_float(payload)


def all_states_of(entries: list[dict]) -> set[str]:
    return {s for e in entries for s in e["states"]}


def used_default(entries: list[dict]) -> str:
    used = all_states_of(entries)
    if DEFAULT_STATE in used:
        return DEFAULT_STATE
    if "inactive" in used:
        return "inactive"
    # A control whose base tokens carry no state at all: the empty set is the default.
    # 基态令牌完全不带状态的控件：空集就是默认态。
    if any(not e["states"] for e in entries):
        return ""
    return sorted(used)[0] if used else ""


def build(system: dict, prefixes: list[str]) -> dict:
    tokens = system["tokens"]
    values = system["values"]
    resolver = Resolver(tokens, values)
    entries: list[dict] = []
    skipped: list[str] = []
    skipped_empty: list[str] = []
    skipped_unsupported: list[str] = []
    unknown: set[str] = set()
    for prefix in prefixes:
        objects = objects_for([prefix])
        for token in tokens:
            parsed = split_token(token["tokenName"], prefix, objects)
            if parsed is None:
                continue
            if deprecated(token):
                skipped.append(token["tokenName"])
                continue
            value = default_value(values_of(token, values))
            if value is None:
                continue
            kind, payload = resolver.resolve(value)
            if kind == "missing":
                skipped_empty.append(token["tokenName"])
                continue
            states, obj, prop = parsed
            section = SECTION_SEGMENTS.get(prefix, frozenset())
            states = tuple(s for s in states if s not in section)
            if EXCLUDED_SUBTREES.get(prefix, frozenset()) & set(states):
                skipped_unsupported.append(token["tokenName"])
                continue
            if IGNORED_SEGMENTS & set(states):
                skipped_unsupported.append(token["tokenName"])
                continue
            for state in states:
                if state not in KNOWN_STATES:
                    unknown.add(state)
            entries.append(
                {
                    "states": states,
                    "object": obj,
                    "property": prop,
                    "kind": kind,
                    "vtype": token["tokenValueType"],
                    "value": payload,
                    "source": prefix,
                }
            )
    entries.sort(key=lambda e: (e["states"], e["object"], e["property"]))
    all_states = sorted({s for e in entries for s in e["states"]})
    default = used_default(entries)
    return {
        "prefix": prefixes[0],
        "prefixes": prefixes,
        "control": prefixes[0].split(".")[-1],
        "token_count": len(tokens),
        "skipped_deprecated": skipped,
        "skipped_empty": skipped_empty,
        "skipped_unsupported": skipped_unsupported,
        "unknown_states": sorted(unknown),
        "states": {
            "default": default,
            "all": all_states,
            "params": [s for s in all_states if s != default],
        },
        "entries": entries,
    }


def cmd_inspect(system: dict, prefixes: list[str]) -> int:
    model = build(system, prefixes)
    objects: dict[str, dict[str, str]] = {}
    for e in model["entries"]:
        objects.setdefault(e["object"], {})[e["property"]] = rust_type(e["kind"])
    out = {
        "control": model["control"],
        "prefix": model["prefix"],
        "prefixes": model["prefixes"],
        "token_count": model["token_count"],
        "default_state": model["states"]["default"],
        "params": model["states"]["params"],
        "unknown_states": model["unknown_states"],
        "skipped_deprecated": model["skipped_deprecated"],
        "skipped_empty": model["skipped_empty"],
        "objects": objects,
        "entries": [
            {
                "states": list(e["states"]),
                "object": e["object"],
                "property": e["property"],
                "type": rust_type(e["kind"]),
                "value": e["value"],
            }
            for e in model["entries"]
        ],
    }
    json.dump(out, sys.stdout, indent=2, ensure_ascii=False)
    sys.stdout.write("\n")
    return 0


# Overlay priority: earliest wins first, later states override earlier ones.
# 叠加优先级：靠前的先写入，靠后的状态覆盖靠前的。
PRIORITY = [
    # The primary axis and its siblings come first, so the interaction states can override.
    # 主轴及其同类状态在前，好让交互态覆盖它们。
    "selected", "checked", "active", "expanded", "current", "on", "indeterminate", "error",
    "xsmall", "small", "medium", "large", "xlarge",
    "with-icon", "with-label", "with-tick-marks", "with-overlap", "has-icon", "centered",
    "docked", "modal", "full-screen", "contained",
    # The export spells these two both ways (`hover` / `hovered`); both must keep their slot.
    # 导出对这两个状态有两种拼法（`hover` / `hovered`），两种都要占住自己的位置。
    "hover", "hovered", "focus", "focused", "pressed", "dragged", "disabled",
]
# Per-control overrides: a control whose axes collide with the shared order.
# 逐控件覆盖：轴与公共顺序冲突的控件。
PRIORITY_BY_CONTROL: dict[str, list[str]] = {}

# Mutually exclusive state axes per control: each becomes one enum parameter, not bools.
# A control may have several axes (a button has both a style and a size).
# 按控件定义的互斥状态轴：每组生成一个枚举参数而不是布尔；一个控件可以有多个轴。
VARIANT_GROUPS: dict[str, list[tuple[str, list[str]]]] = {
    "md.comp.slider": [("size", ["xsmall", "small", "medium", "large", "xlarge"])],
    "md.comp.app-bar": [("size", ["small", "medium", "large"])],
    # The FAB menu repeats the FAB's colour role: the close button takes it directly, the list
    # items take its `-container` form.
    # FAB 菜单沿用 FAB 的颜色角色：关闭按钮直接取该色，列表项取其 `-container` 形式。
    "md.comp.assist-chip": [("variant", ["flat", "elevated"])],
    "md.comp.suggestion-chip": [("variant", ["flat", "elevated"])],
    "md.comp.filter-chip": [("variant", ["flat", "elevated"])],
    "md.comp.input-chip": [("variant", ["flat", "elevated"])],
    "md.comp.fab-menu": [
        ("color", ["primary", "secondary", "tertiary"]),
        ("container", ["primary-container", "secondary-container", "tertiary-container"]),
    ],
    "md.comp.button": [
        ("style", ["elevated", "filled", "outlined", "text", "tonal"]),
        ("size", ["xsmall", "small", "medium", "large", "xlarge"]),
        # The export's button is a *toggle* button: `unselected` is a real appearance, not the
        # stateless base, so a plain button needs `Base` to keep the plain tokens.
        # 导出的按钮是**切换**按钮：`unselected` 是一种真实外观而非无状态基态，
        # 因此普通按钮必须选 `Base` 才能拿到普通令牌。
        ("toggle", ["unselected", "selected"]),
    ],
    # The connected group's only tokens are per-size corner and gap values, so size is an axis.
    # 连通按钮组的令牌只有按尺寸给的圆角与间距，因此尺寸是一条轴。
    "md.comp.button-group.connected": [
        ("size", ["xsmall", "small", "medium", "large", "xlarge"]),
    ],
    # A progress indicator is either a line or a ring, never both: two bools would admit
    # `circular && linear`, an axis cannot.
    # 进度指示器是线条或圆环、从不同时：两个布尔会允许 `circular && linear`，轴不会。
    "md.comp.progress-indicator": [
        ("shape", ["linear", "circular"]),
    ],
    "md.comp.list": [
        ("lines", ["one-line", "two-line", "three-line"]),
        # Selection is an axis, not the primary bool: the export spells the unselected item
        # out as a real appearance (`unselected`), so both sides need a name.
        # 选中是一条轴而不是主轴布尔：导出把未选中写成一种真实外观（`unselected`），
        # 两侧都需要名字。
        ("selection", ["unselected", "selected"]),
        ("layout", ["segmented"]),
        ("variant", ["expressive"]),
        ("video", ["small", "large"]),
    ],
    # The icon slot is a build-time choice: with an icon the headline centres and the icon
    # takes the secondary colour.
    # 图标槽是构建期选择：有图标时标题居中，图标取 secondary 色。
    "md.comp.dialog": [("icon_slot", ["with-icon"])],
}

# Path segments that name a section of the design tool's tree, not a control state.
# They carry shape *names* and spring constants, which are not paintable properties.
# 这些路径段是设计工具树里的分区名，不是控件状态：它们装的是形状名与弹簧常数，不是可绘制属性。
IGNORED_SEGMENTS = {"shape", "corner-size", "motion", "spring"}

# Section segments carry no meaning of their own; the token under them still applies.
# `md.comp.list.list-item.hover.label-text.color` is the label's hover colour, not a
# "list-item" state.
# 分区段本身没有含义，其下的令牌照常生效：`…list-item.hover.label-text.color` 是标签的
# 悬停色，而不是「list-item」状态。
SECTION_SEGMENTS: dict[str, frozenset[str]] = {
    "md.comp.list": frozenset({"list-item"}),
    # A dialog's actions are always text buttons; `action` names the section, not an appearance.
    # 对话框的操作恒为文字按钮；`action` 是分区名，不是一种外观。
    "md.comp.dialog": frozenset({"action"}),
}

# Whole interaction models this package does not implement yet; keeping their tokens would
# only add parameters no widget reads.
# 本包尚未实现的交互模型；保留它们的令牌只会多出没人读取的参数。
EXCLUDED_SUBTREES: dict[str, frozenset[str]] = {
    "md.comp.list": frozenset({"reveal", "reorder", "expand"}),
    # The floating toolbar's FAB group is its own control, not a state of the bar.
    # 浮动工具条的 FAB 组是独立控件，不是工具条的一种状态。
    "md.comp.toolbar.floating": frozenset({"fab"}),
}

# Every state the export is known to use; an unlisted one is reported, not dropped.
# 导出里已知会用到的全部状态；未列出的会被报告，而不是丢弃。
KNOWN_STATES = set(PRIORITY) | {
    DEFAULT_STATE, "inactive", "enabled", "no-label", "standard",
    "icon", "with-single-line", "with-two-lines",
} | {
    s for groups in VARIANT_GROUPS.values() for _, states in groups for s in states
}

def variant_case(state: str) -> str:
    if state.startswith("x") and len(state) > 1:
        # `xsmall` reads as `XSmall`, not `Xsmall`.
        # `xsmall` 写作 `XSmall` 而非 `Xsmall`。
        return "X" + state[1:].capitalize()
    # An axis name can carry an underscore (`icon_slot`), not just a hyphen.
    # 轴名可以带下划线（`icon_slot`），不只是连字符。
    words = [w for w in state.replace("_", "-").split("-") if w]
    return "".join(w.capitalize() for w in words)


PARAM_RENAMES = {"hover": "hovered", "focus": "focused", "dragged": "dragging"}


def param_name(state: str) -> str:
    return PARAM_RENAMES.get(state, state).replace("-", "_")


def priority_for(prefix: str) -> list[str]:
    return PRIORITY_BY_CONTROL.get(prefix, PRIORITY)


def prio(state: str, order: list[str]) -> int:
    if state in order:
        return order.index(state)
    # An unlisted state behaves like an axis: it must be applied before the interaction
    # states so hover/focus/pressed/disabled still override it.
    # 未列出的状态按轴处理：必须先于交互态写入，好让 hover/focus/pressed/disabled 覆盖它。
    return order.index("hover") - 1


def state_plan(entries: list[dict], prefix: str = "") -> dict:
    used = all_states_of(entries)
    groups = []
    for param, states in VARIANT_GROUPS.get(prefix, []):
        present = [s for s in states if s in used]
        if present:
            groups.append((param, present))
    variant_of = {state: param for param, states in groups for state in states}
    default = used_default(entries)
    single = {e["states"][0] for e in entries if len(e["states"]) == 1}
    primary = next(
        (
            s
            for s in ("selected", "checked", "active")
            if s != default and s in single and s not in variant_of
        ),
        None,
    )
    order = priority_for(prefix)
    flags = sorted(
        used - {default, *variant_of} - ({primary} if primary else set()),
        key=lambda s: (prio(s, order), s),
    )
    # `hover` and `hovered` are the same switch under two spellings; one parameter serves both.
    # `hover` 与 `hovered` 是同一个开关的两种写法，共用一个参数。
    seen: set[str] = set()
    unique: list[str] = []
    for state in flags:
        param = param_name(state)
        if param not in seen:
            seen.add(param)
            unique.append(state)
    flags = unique
    return {
        "default": default,
        "primary": primary,
        "flags": flags,
        "groups": groups,
        "variant_of": variant_of,
        "order": order,
    }


def condition(states: tuple[str, ...], plan: dict) -> str:
    parts = []
    for state in states:
        if state in plan["variant_of"]:
            # `matches!` is const-friendly; `==` needs a non-const `PartialEq`.
            # `matches!` 可用于 const fn；`==` 需要非 const 的 `PartialEq`。
            param = plan["variant_of"][state]
            parts.append(
                f"matches!({param}, {plan['types'][param]}::{variant_case(state)})"
            )
        elif state == plan["default"]:
            # The default only needs guarding when it is the opposite of a primary axis.
            # 默认态只有在与主轴相反时才需要取反。
            if plan["primary"]:
                parts.append(f"!{param_name(plan['primary'])}")
        else:
            parts.append(param_name(state))
    return " && ".join(parts)


def key_order(key: tuple[str, ...], plan: dict) -> tuple[int, int]:
    if not key:
        return (-1, 0)
    order = plan["order"]
    scores = [prio(plan["primary"], order) if s == plan["default"] else prio(s, order) for s in key]
    return (max(scores), len(key))


def cmd_gen(system: dict, prefixes: list[str], out: str, name: str | None = None) -> int:
    model = build(system, prefixes)
    entries = model["entries"]
    plan = state_plan(entries, prefixes[0])
    # The last path segment is usually the control's name, but a prefixed subtree can share it
    # with a sibling (`button-group.connected.medium` reads as `medium`); `--name` fixes that.
    # 路径最后一段通常就是控件名，但带前缀的子树可能与兄弟重名
    #（`button-group.connected` 读起来是 `connected`）；用 `--name` 纠正。
    control = name or model["control"]
    camel = "".join(p.capitalize() for p in control.split("-"))
    # One enum per mutually exclusive axis, named after the control and the axis.
    # 每个互斥轴一个枚举，按控件与轴命名。
    plan["types"] = {param: camel + variant_case(param) for param, _ in plan["groups"]}

    objects: dict[str, dict[str, str]] = {}
    for e in entries:
        objects.setdefault(e["object"], {})[e["property"]] = rust_type(e["kind"])

    def struct_name(obj: str) -> str:
        if not obj:
            return camel + "Root"
        return camel + "".join(p.capitalize() for p in obj.replace(".", "-").split("-"))

    KEYWORDS = {"type", "impl", "match", "self", "crate", "const", "fn", "mod", "enum"}

    def field(name: str) -> str:
        if not name:
            return "root"
        clean = name.replace("-", "_").replace(".", "_")
        return f"{clean}_" if clean in KEYWORDS else clean

    def default_for(obj: str, prop: str) -> str:
        if objects[obj][prop] == "&'static str":
            return '""'
        if prop == "opacity" and obj != "state-layer":
            return "1.0"
        return "0.0"

    def assignments(key: tuple[str, ...], indent: str) -> list[str]:
        rows = [e for e in entries if e["states"] == key]
        return [
            f"{indent}out.{field(e['object'])}.{field(e['property'])} = "
            f"{value_literal(e['kind'], e['value'])};"
            for e in sorted(rows, key=lambda e: (e["object"], e["property"]))
        ]

    keys = sorted({e["states"] for e in entries}, key=lambda k: (key_order(k, plan), k))
    # A primary axis that became a variant value needs no boolean of its own.
    primary_flag = [plan["primary"]] if plan["primary"] and plan["primary"] not in plan["variant_of"] else []
    params = primary_flag + plan["flags"]

    L: list[str] = [
        "// Generated by tokens/gen_spec.py from the design-system export. Do not edit by hand.",
        "// 由 tokens/gen_spec.py 从设计系统导出生成，请勿手改。",
        "",
    ]
    if model["skipped_deprecated"]:
        L.append(f"// Skipped {len(model['skipped_deprecated'])} deprecated tokens (see the export).")
        L.append(f"// 已跳过 {len(model['skipped_deprecated'])} 个废弃令牌（见导出文件）。")
        L.append("")
    if model["unknown_states"]:
        L.append(f"// States outside the known vocabulary: {', '.join(model['unknown_states'])}")
        L.append(f"// 已知词表之外的状态：{', '.join(model['unknown_states'])}")
        L.append("")
    L.append("/// One resolved value set for a control state.")
    L.append("/// 某控件状态下解析出的一套值。")
    L.append("#[derive(Clone, Copy, Debug, PartialEq)]")
    L.append(f"pub struct {camel}Spec {{")
    for obj in sorted(objects):
        L.append(f"    pub {field(obj)}: {struct_name(obj)},")
    L.append("}")
    L.append("")
    for obj in sorted(objects):
        L.append(f"/// `{obj or 'the control itself'}` values.")
        L.append(f"/// `{obj or '控件自身'}` 的值。")
        L.append("#[derive(Clone, Copy, Debug, PartialEq)]")
        L.append(f"pub struct {struct_name(obj)} {{")
        for prop in sorted(objects[obj]):
            L.append(f"    pub {field(prop)}: {objects[obj][prop]},")
        L.append("}")
        L.append("")

    for param, states in plan["groups"]:
        variant_type = plan["types"][param]
        L.append("/// A mutually exclusive variant axis, not a boolean.")
        L.append("/// 互斥变体轴，不是布尔。")
        L.append("#[derive(Clone, Copy, Debug, PartialEq, Eq)]")
        L.append(f"pub enum {variant_type} {{")
        L.append("    /// No variant token applied.")
        L.append("    /// 不叠加任何变体令牌。")
        L.append("    Base,")
        for state in states:
            L.append(f"    {variant_case(state)},")
        L.append("}")
        L.append("")
        L.append(f"impl Default for {variant_type} {{")
        L.append("    fn default() -> Self {")
        L.append("        Self::Base")
        L.append("    }")
        L.append("}")
        L.append("")
    bits = [f"{param_name(p)}: bool" for p in params]
    for param, _ in plan["groups"]:
        bits.append(f"{param}: {plan['types'][param]}")
    signature = ", ".join(bits)
    doc_flags = ", ".join(f"`{param_name(p)}`" for p in params) or "none"
    for param, _ in plan["groups"]:
        doc_flags += f", `{param}`"
    L.append("/// Resolve the control's values for one state combination.")
    L.append("/// 为一组状态解析控件取值。")
    base = f"`{plan['default']}` is the base." if plan["default"] else "No state is the base."
    base_zh = f"`{plan['default']}` 是基态。" if plan["default"] else "无状态是基态。"
    L.append(f"/// Flags by priority: {doc_flags}; {base}")
    L.append(f"/// 按优先级的开关：{doc_flags}；{base_zh}")
    L.append(f"pub const fn {control.replace('-', '_')}_spec({signature}) -> {camel}Spec {{")
    L.append(f"    let mut out = {camel}Spec {{")
    for obj in sorted(objects):
        L.append(f"        {field(obj)}: {struct_name(obj)} {{")
        for prop in sorted(objects[obj]):
            L.append(f"            {field(prop)}: {default_for(obj, prop)},")
        L.append("        },")
    L.append("    };")
    for key in keys:
        rows = assignments(key, "        ")
        if not rows:
            continue
        if not key:
            L.extend(assignments(key, "    "))
        else:
            L.append(f"    if {condition(key, plan)} {{")
            L.extend(rows)
            L.append("    }")
    L.append("    out")
    L.append("}")
    L.append("")


    text = "\n".join(L)
    if out == "-":
        sys.stdout.write(text)
    else:
        with open(out, "w", encoding="utf-8") as f:
            f.write(text)
    return 0


def main() -> int:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("inspect", "gen"):
        p = sub.add_parser(name)
        p.add_argument("json")
        p.add_argument("--prefix", action="append", default=None)
        if name == "gen":
            p.add_argument("--out", default="-")
            p.add_argument("--name", default=None)
    args = ap.parse_args()
    system = load(args.json)
    prefixes = args.prefix or [system["tokenSets"][0]["tokenSetName"]]
    if args.cmd == "inspect":
        return cmd_inspect(system, prefixes)
    return cmd_gen(system, prefixes, args.out, args.name)


if __name__ == "__main__":
    raise SystemExit(main())
