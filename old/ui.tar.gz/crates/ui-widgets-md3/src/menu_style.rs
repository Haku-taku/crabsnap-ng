//! The MD3 look for the engine's context menu, resolved from the `md.comp.menus` tokens.
//! 引擎上下文菜单的 MD3 外观，取值来自 `md.comp.menus` 令牌。
//!
//! The engine owns collection, placement and hit testing; this only says how it paints.
//! 收集、摆放与命中仍归引擎；这里只说明它怎么画。

use ui_style::Style;

use crate::spec::menus_spec;
use crate::toggle::spec_ink;

/// `rounded_corners` on the MD3 shape scale, which the export names but does not number.
/// MD3 形状刻度上的 `rounded_corners`；导出只给名字不给数值。
const RADIUS: f32 = 4.0;
/// MD3 gives the menu no width cap; a very long label simply makes a wide menu.
/// MD3 不给菜单设宽度上限；很长的标签就直接撑出很宽的菜单。
const MAX_WIDTH: f32 = 560.0;

/// The menu's standard variant, as the engine's style.
/// 菜单的标准变体，交作引擎的样式。
pub fn menu_style(pack: &Style) -> ui_widgets::MenuStyle {
    // A menu container reads its tokens with no item state on.
    // 菜单容器读取令牌时不带任何条目状态。
    let s = menus_spec(false, false, false, false, false, false, false, false, false, false, false, true, false, false, false, false, false);
    // The row's own spec carries the label ink and the hover layer.
    // 行自己的 spec 携带标签墨色与悬停层。
    let row = menus_spec(false, false, false, false, false, false, false, false, false, true, false, true, false, true, false, false, false);
    ui_widgets::MenuStyle {
        surface: spec_ink(pack, s.container.color, 1.0),
        ink: spec_ink(pack, row.menu_item_label_text.color, 1.0),
        muted: spec_ink(
            pack,
            row.menu_item_label_text.color,
            crate::DISABLED_CONTENT_OPACITY,
        ),
        hover: spec_ink(pack, row.menu_item_state_layer.color, row.menu_item_state_layer.opacity),
        // MD3 bounds the menu with its shadow, not a hairline.
        // MD3 用阴影而非细线界定菜单。
        border: None,
        font_size: row.menu_item_label_text.size,
        // MD3 puts the shortcut in the trailing supporting text slot; Compose's font token is
        // `label-small`, while the export carries the label's own 14sp — the type scale wins.
        // MD3 把快捷键放在尾随支持文本位；Compose 的字级令牌是 `label-small`，
        // 导出给的却是标签的 14sp——以字级表为准。
        shortcut_ink: spec_ink(pack, row.trailing_supporting_text.color, 1.0),
        shortcut_size: crate::typescale::LABEL_SMALL.size,
        shortcut_weight: crate::typescale::LABEL_SMALL.weight,
        shortcut_gap: row.menu_item.between_space,
        trailing_space: row.menu_item.trailing_space,
        row_height: row.menu_item.height,
        pad_x: row.menu_item.leading_space,
        pad_y: row.menu_item.top_space,
        radius: RADIUS,
        min_width: 112.0,
        max_width: MAX_WIDTH,
        shadow: s.container.elevation * 2.0,
    }
}
