//! MD3 progress indicator: the linear bar (a track with a `value`-long active bar, or the
//! indeterminate pair sweeping across it) and the circular ring that sweeps on its own clock.
//! MD3 进度指示器：线性条（轨道上叠一段 `value` 长的活动条，或不确定态下扫过的两段），
//! 以及按自身时钟扫动的环形。
//!
//! Both indeterminate timings are Flutter's painters; the linear one comes from Android's
//! `progress_indeterminate_material.xml`, the circular one from a `SawTooth` pair of cycles.
//! 两种不确定态时序都取自 Flutter 的 painter：线性来自 Android 的
//! `progress_indeterminate_material.xml`，环形来自一对 `SawTooth` 周期。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Point, Rect};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::{Decl, Easing, Id, NodeKind};
use ui_style::Style;
use ui_widgets::{Cx, Widget, WidgetState};

use crate::spec::{progress_indicator_spec, ProgressIndicatorShape};
use crate::toggle::{role, spec_ink};
use crate::Md3Options;

/// One full sweep of the indeterminate pair (`_kIndeterminateLinearDuration`).
/// 不确定态一对条扫完一轮的时长（`_kIndeterminateLinearDuration`）。
pub const SWEEP_SECONDS: f32 = 1.8;

/// The circular sweep's path cycle: the arc grows and shrinks once per 1333 ms.
/// 环形扫动的路径周期：弧每 1333ms 长大又收回一次。
pub const PATH_SECONDS: f32 = 1.333;
/// The circular sweep's own rotation: one turn per 2222 ms.
/// 环形扫动自身的旋转：每 2222ms 转一圈。
pub const ROTATION_SECONDS: f32 = 2.222;
/// `_epsilon`: a zero sweep draws nothing, so the arc keeps a hair of it.
/// `_epsilon`：零扫角什么都画不出，因此弧始终留一根头发丝。
const MIN_SWEEP: f32 = 0.001 / std::f32::consts::TAU;
/// `Curves.fastOutSlowIn`: the head and the tail each ease over half the path cycle.
/// `Curves.fastOutSlowIn`：首尾各自在路径周期的一半内缓动。
const FAST_OUT_SLOW_IN: Easing = Easing::Cubic(0.4, 0.0, 0.2, 1.0);

/// Twelve o'clock, in turns from three o'clock: where both ring arcs begin.
/// 十二点，以三点起算的圈数：圆环两段弧都由此开始。
const START_TURN: f32 = -0.25;

/// A progress indicator, linear or circular. The value is the app's; it reports nothing.
/// 进度指示器，线性或环形。数值归应用，它不上报任何东西。
pub struct Md3ProgressIndicator {
    id: Id,
    /// The bar's width; the ring reads `size` instead.
    /// 条的宽度；圆环改读 `size`。
    width: f32,
    /// The ring's diameter; `None` paints the bar.
    /// 圆环的直径；为 `None` 时画条。
    size: Option<f32>,
    /// `0.0..=1.0`; the caller clamps, this paints whatever it is handed.
    /// `0.0..=1.0`；调用方夹取，本控件按收到的值绘制。
    value: f32,
    /// The bar's height and the ring's stroke: the spec's 4 dp.
    /// 条的高度与圆环的描边：规格的 4dp。
    thickness: f32,
    track: Color,
    active: Color,
    /// The sweep's clock in engine seconds; `None` paints the determinate form.
    /// 扫动的时钟（引擎秒）；为 `None` 时画确定态。
    age: Option<f32>,
    /// `track_active_indicator_space`: the space the track leaves around a moving bar.
    /// `track_active_indicator_space`：轨道给移动中的条让出的空隙。
    gap: f32,
}

impl Md3ProgressIndicator {
    /// Build a linear bar of `width`. The width comes from the caller because the control
    /// cannot read its own laid-out box yet (gap #3), exactly as `Md3Slider` and `Md3TabBar`
    /// take theirs.
    /// 构建一个宽 `width` 的线性条。宽度由调用方给，因为控件尚且读不到自己布局后的盒子
    /// （缺口 #3），与 `Md3Slider`、`Md3TabBar` 取宽度的方式一致。
    pub fn new_with(
        _options: Md3Options,
        id: Id,
        width: f32,
        value: f32,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let _ = cx;
        Self::build(id, width, None, value.clamp(0.0, 1.0), None, pack)
    }

    /// The same bar without a value: it sweeps on its own clock until the app has one.
    /// 同一个条，但没有数值：在应用拿到数值之前按自己的时钟扫动。
    pub fn indeterminate_with(
        _options: Md3Options,
        id: Id,
        width: f32,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        Self::build(id, width, None, 0.0, Some(age_of(id, cx)), pack)
    }

    /// A `size` ring without a value: the arc grows, travels and shrinks on its own clock.
    /// 一个 `size` 大小的圆环，没有数值：弧按自己的时钟长大、行进、收回。
    pub fn ring_indeterminate_with(
        _options: Md3Options,
        id: Id,
        size: f32,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        Self::build(id, size, Some(size), 0.0, Some(age_of(id, cx)), pack)
    }

    /// A `size` ring showing `value`: the track, then an arc from twelve o'clock.
    /// 一个 `size` 大小、显示 `value` 的圆环：轨道，再加一段从十二点起的弧。
    pub fn ring_with(
        _options: Md3Options,
        id: Id,
        size: f32,
        value: f32,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let _ = cx;
        Self::build(id, size, Some(size), value.clamp(0.0, 1.0), None, pack)
    }

    fn build(id: Id, width: f32, size: Option<f32>, value: f32, age: Option<f32>, pack: &Style) -> Self {
        let shape = if size.is_some() {
            ProgressIndicatorShape::Circular
        } else {
            ProgressIndicatorShape::Linear
        };
        let spec = progress_indicator_spec(false, false, false, shape);
        // Both the active bar and the track are the export's 4dp thickness; the deprecated
        // `thickness` token is the only source of that number, so it is read from the shape.
        // 活动条与轨道都是导出的 4dp 粗细；`thickness` 令牌是唯一来源，因此按形状读取。
        Self {
            id,
            width,
            size,
            value,
            thickness: if size.is_some() {
                spec.active_indicator.thickness
            } else {
                spec.root.height
            },
            track: role(pack, spec.track.color),
            active: spec_ink(pack, spec.active_indicator.color, 1.0),
            age,
            gap: spec.root.track_active_indicator_space,
        }
    }

    /// The bar's own height, so a caller can reserve room for it.
    /// 进度条自身高度，供调用方预留空间。
    pub fn height(&self) -> f32 {
        self.thickness
    }

    /// `track_active_indicator_space` as a share of a turn, measured on the stroke's centre
    /// line: Flutter's `startGap = (strokeWidth + trackGap) / arcRadius`.
    /// 把 `track_active_indicator_space` 折算成圈的比例，按描边中心线量：
    /// Flutter 的 `startGap = (strokeWidth + trackGap) / arcRadius`。
    fn track_gap_turns(&self, radius: f32) -> f32 {
        let centre = (radius - self.thickness * 0.5).max(f32::EPSILON);
        (self.thickness + self.gap) / centre / std::f32::consts::TAU
    }

    /// The ring: one stroked arc on a `size` circle, round-capped as Compose draws it.
    /// 圆环：`size` 圆上的一段描边弧，按 Compose 的画法取圆头。
    fn ring(&self, size: f32) -> Decl {
        let radius = size * 0.5;
        let mut shapes = Vec::with_capacity(2);
        let arc = |trim: (f32, f32), round_caps: bool, colour: Color| Shape::Sector {
            centre: Point::new(radius, radius),
            radius,
            thickness: self.thickness,
            trim,
            round_caps,
            colour,
        };
        // No track while sweeping: M3 gives the circular indicator one only when it has a
        // value (`circularTrackColor => indeterminate ? null : secondaryContainer`).
        // 扫动时不画轨道：M3 只在有数值时给圆环轨道
        // （`circularTrackColor => indeterminate ? null : secondaryContainer`）。
        if let Some(age) = self.age {
            let (start, end) = ring_arc(age);
            shapes.push(arc((start, end), true, self.active));
        } else if self.value > 0.0 {
            // The track stops either side of the value arc by `track_active_indicator_space`;
            // the arc itself is butt-capped, the track round-capped, as Flutter paints them.
            // 轨道在数值弧两端各让出 `track_active_indicator_space`；数值弧取平头、
            // 轨道取圆头，与 Flutter 的画法一致。
            let gap = self.track_gap_turns(radius);
            let end = START_TURN + 1.0 - gap;
            let start = START_TURN + self.value + gap;
            if end > start {
                shapes.push(arc((start, end), true, self.track));
            }
            shapes.push(arc((START_TURN, START_TURN + self.value), false, self.active));
        } else {
            shapes.push(arc((0.0, 1.0), true, self.track));
        }
        Decl::container(self.id, NodeKind::Box)
            .size(SizeClass::fixed(size, size))
            .shapes(shapes)
    }
}

/// The sweep's clock: reading the age every frame is what keeps the loop asking for frames.
/// 扫动时钟：每帧读取年龄，循环才会持续索要帧。
fn age_of(id: Id, cx: &mut Cx<'_, '_>) -> f32 {
    cx.at(id).age(id.with("sweep"))
}

/// The four endpoints of the two sweeping bars at `phase`, as fractions of the width.
/// `phase` 处两段扫动条的四个端点，按宽度的比例给出。
pub fn sweep_bars(phase: f32) -> [(f32, f32); 2] {
    // The curves are Flutter's, in fractions of the 1800 ms loop.
    // 曲线取自 Flutter，按 1800ms 一轮折算成比例。
    let line1_head = interval(phase, 0.0, 750.0 / 1800.0, Easing::Cubic(0.2, 0.0, 0.8, 1.0));
    let line1_tail = interval(phase, 333.0 / 1800.0, 1083.0 / 1800.0, Easing::Cubic(0.4, 0.0, 1.0, 1.0));
    let line2_head = interval(phase, 1000.0 / 1800.0, 1567.0 / 1800.0, Easing::Cubic(0.0, 0.0, 0.65, 1.0));
    let line2_tail = interval(phase, 1267.0 / 1800.0, 1.0, Easing::Cubic(0.10, 0.0, 0.45, 1.0));
    [
        (line1_tail, line1_head),
        (line2_tail, line2_head),
    ]
}

/// The ring's arc at `age` seconds, as `(start, end)` in turns from three o'clock, clockwise.
/// `age` 秒时圆环的弧，`(起点, 终点)`，以三点起、顺时针的圈计。
pub fn ring_arc(age: f32) -> (f32, f32) {
    // The head eases over the first half of the path cycle and the tail over the second, so
    // the arc grows to 270° and then shrinks back to nothing.
    // 首在路径周期的前半段缓动、尾在后半段，弧因此长到 270° 再收回空。
    let path = (age / PATH_SECONDS).fract();
    let head = FAST_OUT_SLOW_IN.apply((path * 2.0).min(1.0));
    let tail = FAST_OUT_SLOW_IN.apply(((path - 0.5) * 2.0).max(0.0));
    let rotation = (age / ROTATION_SECONDS).fract();
    // Flutter's `arcStart`: twelve o'clock, then the tail, the rotation and the offset.
    // Flutter 的 `arcStart`：十二点起，再加尾、旋转与偏移。
    let start = -0.25 + tail * 0.75 + rotation + path * 0.25;
    let sweep = (head * 0.75 - tail * 0.75).max(MIN_SWEEP);
    (start, start + sweep)
}

/// `CurveTween(Interval(begin, end, curve))`: flat before, eased within, flat after.
/// `CurveTween(Interval(begin, end, curve))`：之前持平、区间内缓动、之后持平。
fn interval(t: f32, begin: f32, end: f32, easing: Easing) -> f32 {
    if t <= begin {
        0.0
    } else if t >= end {
        1.0
    } else {
        easing.apply((t - begin) / (end - begin))
    }
}

impl Widget for Md3ProgressIndicator {
    fn change(&self, _state: &WidgetState, _bounds: ui_core::geom::Rect) -> Option<ui_core::Change> {
        // A progress bar is read-only: it reflects the app's value and produces no semantic
        // change of its own.
        // 进度条只读：它反映应用的数值，本身不产生任何语义变化。
        None
    }

    fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
        if let Some(size) = self.size {
            return self.ring(size);
        }
        let radius = self.thickness * 0.5;
        // A zero-length segment paints nothing, so neither a fresh bar nor a sweep at its
        // ends shows a rounded nub (the slider's zero-length rule, reused).
        // 零长度的一段不画，新进度条与扫到端点的条因此都不会露出圆的凸起（沿用 slider 的
        // 零长度规则）。
        let bar = |from: f32, to: f32, fill: Color| Shape::Rect {
            rect: Rect::new(from * self.width, 0.0, (to - from) * self.width, self.thickness),
            corners: Corners::all(radius),
            fill,
            gradient: None,
            border: None,
        };
        let mut shapes = Vec::with_capacity(5);
        match self.age.map(|age| (age / SWEEP_SECONDS).fract()) {
            None => {
                shapes.push(Shape::Box {
                    corners: Corners::all(radius),
                    fill: self.track,
                    gradient: None,
                    border: None,
                    shadow: None,
                    image: None,
                });
                if self.value > 0.0 {
                    shapes.push(bar(0.0, self.value, self.active));
                }
            }
            Some(phase) => {
                // The track shows only where the two bars are not, each edge held back by
                // the 4dp space; the ramp keeps that space from popping into existence.
                // 轨道只画在两段条之外，每条边都让出 4dp 空隙；空隙由斜坡渐入，不会突然出现。
                let gap = self.gap / self.width.max(1.0);
                let space = |v: f32| gap * v.clamp(0.0, 0.01) / 0.01;
                let mut segment = |from: f32, to: f32, fill: Color| {
                    let (from, to) = (from.clamp(0.0, 1.0), to.clamp(0.0, 1.0));
                    if to - from > 0.0 {
                        shapes.push(bar(from, to, fill));
                    }
                };
                let [(tail1, head1), (tail2, head2)] = sweep_bars(phase);
                if head1 < 1.0 - gap {
                    segment(if head1 > 0.0 { head1 + space(head1) } else { 0.0 }, 1.0, self.track);
                }
                segment(tail1, head1, self.active);
                if tail1 > gap {
                    let from = if head2 > 0.0 { head2 + space(head2) } else { 0.0 };
                    let to = if tail1 < 1.0 { tail1 - space(1.0 - tail1) } else { 1.0 };
                    segment(from, to, self.track);
                }
                segment(tail2, head2, self.active);
                if tail2 > gap {
                    let to = if tail2 < 1.0 { tail2 - space(1.0 - tail2) } else { 1.0 };
                    segment(0.0, to, self.track);
                }
            }
        }
        Decl::container(self.id, NodeKind::Box)
            .size(SizeClass {
                width: AxisSize::fixed(self.width),
                height: AxisSize::fixed(self.thickness),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .shapes(shapes)
    }
}

#[cfg(test)]
mod tests {
    use super::sweep_bars;

    #[test]
    fn the_sweeping_bars_stay_ordered_and_inside_the_track() {
        // An endpoint outside 0..=1 paints outside the bar, and a tail past its head paints
        // a segment the wrong way; both would only show up as a visual glitch.
        // 端点越出 0..=1 会画到条外，尾越过首则会反向画一段；两者都只表现为视觉故障。
        for k in 0..=360 {
            let phase = k as f32 / 360.0;
            for (tail, head) in sweep_bars(phase) {
                assert!((0.0..=1.0).contains(&tail), "phase {phase}: tail {tail}");
                assert!((0.0..=1.0).contains(&head), "phase {phase}: head {head}");
                assert!(tail <= head, "phase {phase}: tail {tail} past head {head}");
            }
        }
    }

    #[test]
    fn the_sweep_is_empty_at_the_seam_and_full_in_between() {
        // The loop restarts on itself, so both ends of the phase must be blank; if the seam
        // carried a bar, every cycle would flash one.
        // 循环首尾相接，相位两端因此必须都是空的；接缝处留着条，每一轮都会闪一下。
        let blank = |phase: f32| {
            sweep_bars(phase)
                .iter()
                .all(|(tail, head)| head - tail < 1e-6)
        };
        assert!(blank(0.0));
        assert!(blank(1.0));
        let widest = (0..=100)
            .map(|k| {
                let [(t1, h1), (t2, h2)] = sweep_bars(k as f32 / 100.0);
                (h1 - t1).max(h2 - t2)
            })
            .fold(0.0f32, f32::max);
        assert!(widest > 0.4, "the bars never grew: {widest}");
    }
}
