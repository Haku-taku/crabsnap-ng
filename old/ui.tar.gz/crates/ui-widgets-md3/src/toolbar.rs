//! MD3 toolbar: a 64dp bar of 48dp icon-button slots, docked (square, flush) or floating
//! (stadium, raised), with the standard and vibrant member themes.
//! MD3 工具条：64dp 的条，装着 48dp 图标按钮槽；停靠式（方角、贴边）或浮动式
//! （胶囊、抬升），成员主题分标准与鲜艳两种。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Insets, Rect};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::tree::ShadowSpec;
use ui_core::{AnimSpec, CursorShape, Decl, Easing, Id, InkRadius, NodeKind, PressInk, Sense};
use ui_style::Style;
use ui_widgets::build::param;
use ui_widgets::{Cx, IconSource, Widget, WidgetState};

use crate::layer::Background;
use crate::nav_bar::boxed;
use crate::spec::{
    toolbar_docked_spec, toolbar_floating_spec, toolbar_standard_spec, toolbar_vibrant_spec,
};
use crate::toggle::{between, role, spec_ink};
use crate::Md3Options;

/// The 48dp touch target; the same constant the app bar uses for its slots.
/// 48dp 触控区；与 app bar 的槽位同一个常量。
pub const TOOLBAR_SLOT: f32 = 48.0;
/// `md.comp.icon-button.container.height`: the 40dp disc inside the touch target.
/// `md.comp.icon-button.container.height`：触控区里的 40dp 圆盘。
pub const TOOLBAR_DISC: f32 = 40.0;
/// `md.comp.icon-button.icon.size`.
/// `md.comp.icon-button.icon.size`。
pub const TOOLBAR_ICON: f32 = 24.0;
/// `md.sys.state.focus-indicator.thickness`, which the icon button points at.
/// `md.sys.state.focus-indicator.thickness`，图标按钮指向它。
const FOCUS_THICKNESS: f32 = 3.0;

/// `kRadialReactionDuration`: the hover and focus layers.
/// `kRadialReactionDuration`：悬停与聚焦的状态层。
const REACTION: AnimSpec = AnimSpec::new(0.1, Easing::Linear);
/// The disc's selection dissolve; the export has no token, 200ms keeps it crisp.
/// 圆盘的选中溶解；导出没有令牌，200ms 保持利落。
const SELECT_DISC: AnimSpec = AnimSpec::new(0.2, Easing::Linear);

/// Where the toolbar sits: flush against its parent, or floating above it.
/// 工具条的位置：贴着父容器，或浮在它上方。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum ToolbarVariant {
    /// Full width, square, no shadow.
    /// 整宽、方角、无阴影。
    #[default]
    Docked,
    /// Hugs its members, stadium-shaped, raised by the export's elevation 6.
    /// 宽度贴合成员、胶囊形，按导出的 elevation 6 抬升。
    Floating,
}

/// Which member theme the toolbar paints: the export's two tables.
/// 工具条用哪套成员主题：导出的两张表。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum ToolbarTheme {
    /// `surface-container` bar with `secondary-container` selected discs.
    /// `surface-container` 的条，选中圆盘是 `secondary-container`。
    #[default]
    Standard,
    /// `primary-container` bar with `surface-container` selected discs.
    /// `primary-container` 的条，选中圆盘是 `surface-container`。
    Vibrant,
}

/// One member: the id the app knows it by, its 24dp mark, and whether it reads as toggled on.
/// 一个成员：应用认识它的 id、24dp 标记，以及是否表现为选中。
pub struct ToolbarAction<'a> {
    pub id: Id,
    /// The mark at the member's icon id, in the ink and `FILL` axis the state resolves to.
    /// 成员的图标 id 处的标记，按状态解析出的墨色与 `FILL` 轴。
    pub icon: IconSource,
    /// The export's `selected` state: the disc takes the theme's selected container colour.
    /// 导出的 `selected` 态：圆盘取主题的选中容器色。
    pub selected: bool,
    /// Kept for callers that key the member by something other than its id.
    /// 供用 id 之外的东西给成员做键的调用方。
    pub label: Option<&'a str>,
}

impl<'a> ToolbarAction<'a> {
    /// An untoggled member.
    /// 未选中的成员。
    pub fn new(id: Id, icon: IconSource) -> Self {
        Self { id, icon, selected: false, label: None }
    }

    /// The same member, reading as toggled on.
    /// 同一成员，表现为选中。
    pub fn selected(mut self) -> Self {
        self.selected = true;
        self
    }

    /// A label for the member; the export carries only its ink, so it is not painted yet.
    /// 成员的标签；导出只给了它的墨色，尚未绘制。
    pub fn label(mut self, label: &'a str) -> Self {
        self.label = Some(label);
        self
    }
}

/// Everything a toolbar needs besides the design system's own tokens.
/// 工具条除设计系统令牌之外所需的一切。
pub struct ToolbarParams<'a> {
    pub id: Id,
    pub variant: ToolbarVariant,
    pub theme: ToolbarTheme,
    pub actions: &'a [ToolbarAction<'a>],
    pub disabled: bool,
}

/// The token names one member resolves to in one state, whichever theme it belongs to.
/// 一个成员在某个状态下解析出的令牌名，不分主题。
struct Inks {
    ink: &'static str,
    disabled_ink: &'static str,
    disabled_opacity: f32,
    disc: &'static str,
    layer: &'static str,
    hover: f32,
    focus: f32,
    press: f32,
}

/// Resolve the member's token names for one state combination.
/// 为一个状态组合解析成员的令牌名。
fn inks(theme: ToolbarTheme, selected: bool, hovered: bool, focused: bool, pressed: bool) -> Inks {
    match theme {
        ToolbarTheme::Standard => {
            let s = toolbar_standard_spec(selected, hovered, focused, pressed, false);
            let d = toolbar_standard_spec(selected, false, false, false, true);
            Inks {
                ink: s.icon.color,
                disabled_ink: d.icon.color,
                disabled_opacity: d.icon.opacity,
                disc: s.button_container.color,
                layer: s.state_layer.color,
                hover: toolbar_standard_spec(selected, true, false, false, false).state_layer.opacity,
                focus: toolbar_standard_spec(selected, false, true, false, false).state_layer.opacity,
                press: toolbar_standard_spec(selected, false, false, true, false).state_layer.opacity,
            }
        }
        ToolbarTheme::Vibrant => {
            let s = toolbar_vibrant_spec(selected, hovered, focused, pressed, false);
            let d = toolbar_vibrant_spec(selected, false, false, false, true);
            Inks {
                ink: s.icon.color,
                disabled_ink: d.icon.color,
                disabled_opacity: d.icon.opacity,
                disc: s.button_container.color,
                layer: s.state_layer.color,
                hover: toolbar_vibrant_spec(selected, true, false, false, false).state_layer.opacity,
                focus: toolbar_vibrant_spec(selected, false, true, false, false).state_layer.opacity,
                press: toolbar_vibrant_spec(selected, false, false, true, false).state_layer.opacity,
            }
        }
    }
}

/// One member's resolved paint data.
/// 一个成员解析后的绘制数据。
struct Member {
    id: Id,
    icon: IconSource,
    ink: Color,
    /// The 40dp disc's fill, which is the theme's `button.container.color`.
    /// 40dp 圆盘的填充，即主题的 `button.container.color`。
    disc: Color,
    layer: Option<Color>,
    press: Option<PressInk>,
    ring: f32,
}

/// A toolbar; the app owns which members read as selected.
/// 工具条；哪些成员表现为选中归应用所有。
pub struct Md3Toolbar {
    id: Id,
    members: Vec<Member>,
    height: f32,
    inset: f32,
    gap: f32,
    container: Color,
    floating: bool,
    shadow: Option<ShadowSpec>,
    ring_colour: Color,
    disabled: bool,
}

impl Md3Toolbar {
    /// Same control with explicit parameters, so the semantic path and a direct caller
    /// produce identical `Decl`s.
    /// 带显式参数的同一控件，使语义路径与直接调用产出相同的 `Decl`。
    pub fn new_with(
        params: Md3Options,
        p: ToolbarParams<'_>,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let docked = toolbar_docked_spec();
        let floating = toolbar_floating_spec();
        let is_floating = p.variant == ToolbarVariant::Floating;
        let container = match p.theme {
            ToolbarTheme::Standard => toolbar_standard_spec(false, false, false, false, false).container.color,
            ToolbarTheme::Vibrant => toolbar_vibrant_spec(false, false, false, false, false).container.color,
        };
        let disabled = params.disabled || cx.state(p.id).disabled;
        // The 40dp disc every member paints into: layer, selection and ripple all use it.
        // 每个成员都画进其中的 40dp 圆盘：状态层、选中与涟漪都用它。
        let inset = (TOOLBAR_SLOT - TOOLBAR_DISC) * 0.5;
        let background = Background::new(
            Rect::new(inset, inset, TOOLBAR_DISC, TOOLBAR_DISC),
            Corners::all(TOOLBAR_DISC * 0.5),
        );
        let mut members = Vec::with_capacity(p.actions.len());
        for action in p.actions {
            let member_id = action.id;
            let mut node = cx.at(member_id);
            let state = node.state();
            let t = inks(p.theme, action.selected, state.hovered, state.focus_visible, state.pressed);
            // The disc and its ink dissolve between the two selection states instead of
            // snapping when the app flips `selected`.
            // 圆盘与它的墨色在两种选中状态之间溶解，而不是在应用翻转 `selected` 时硬切。
            let on = inks(p.theme, true, state.hovered, state.focus_visible, state.pressed);
            let off = inks(p.theme, false, state.hovered, state.focus_visible, state.pressed);
            let sel = node.animate(member_id.with(param::PROGRESS), f32::from(action.selected), SELECT_DISC);
            let ink = if disabled {
                between(
                    spec_ink(pack, off.disabled_ink, off.disabled_opacity),
                    spec_ink(pack, on.disabled_ink, on.disabled_opacity),
                    sel,
                )
            } else {
                between(spec_ink(pack, off.ink, 1.0), spec_ink(pack, on.ink, 1.0), sel)
            };
            let layer_ink = spec_ink(pack, t.layer, 1.0);
            let hover = node.animate(member_id.with(param::HOVER), f32::from(state.hovered), REACTION);
            let focus = node.animate(member_id.with(param::FOCUS), f32::from(state.focus_visible), REACTION);
            let alpha = (hover * t.hover).max(focus * t.focus);
            let layer = (alpha > 0.0 && !disabled)
                .then_some(Color { a: layer_ink.a * alpha, ..layer_ink });
            let press = (!disabled).then(|| {
                background.press(Color { a: layer_ink.a * t.press, ..layer_ink }, InkRadius::Cover)
            });
            let ring = if disabled {
                0.0
            } else {
                node.animate(member_id.with(param::THICKNESS), f32::from(state.focus_visible), REACTION)
            };
            members.push(Member {
                id: member_id,
                icon: action.icon,
                ink,
                disc: between(spec_ink(pack, off.disc, 1.0), spec_ink(pack, on.disc, 1.0), sel),
                layer,
                press,
                ring,
            });
        }
        let elevation = floating.container.elevation;
        Self {
            id: p.id,
            members,
            height: if is_floating { floating.horizontal_container.height } else { docked.container.height },
            inset: if is_floating { floating.container.leading_space } else { docked.container.leading_space },
            gap: if is_floating { floating.container.between_space } else { docked.container.min_spacing },
            container: role(pack, container),
            floating: is_floating,
            shadow: (is_floating && elevation > 0.0)
                .then(|| ShadowSpec::black(elevation * 2.0, 0.18, elevation * 0.5)),
            ring_colour: role(pack, "secondary"),
            disabled,
        }
    }

    /// The toolbar's own height, so a caller can reserve room for it.
    /// 工具条自身高度，供调用方预留空间。
    pub fn height(&self) -> f32 {
        self.height
    }

    /// One member: its disc, state layer, focus ring and centred mark.
    /// 一个成员：圆盘、状态层、焦点环与居中的标记。
    fn member_decl(&self, m: &Member) -> Decl {
        let d = (TOOLBAR_SLOT - TOOLBAR_DISC) * 0.5;
        let background = Background::new(
            Rect::new(d, d, TOOLBAR_DISC, TOOLBAR_DISC),
            Corners::all(TOOLBAR_DISC * 0.5),
        );
        let mut shapes = vec![background.fill(m.disc)];
        if let Some(layer) = m.layer {
            shapes.push(background.fill(layer));
        }
        // The icon button's focus indicator sits outside the disc; the slot is 48dp, so the
        // ring is drawn on the slot's own edge rather than inset into the disc.
        // 图标按钮的焦点指示在圆盘之外；槽是 48dp，所以环画在槽自己的边上而不是嵌进圆盘。
        if m.ring > 0.0 {
            let ring = Color { a: self.ring_colour.a * m.ring, ..self.ring_colour };
            shapes.push(boxed(Color::TRANSPARENT, Some((ring, FOCUS_THICKNESS))));
        }
        Decl::container(m.id, NodeKind::Column)
            .size(SizeClass::fixed(TOOLBAR_SLOT, TOOLBAR_SLOT))
            .padding(Insets {
                left: d,
                right: d,
                // The inset centres the mark's own em box in the slot.
                // 这段内衬把标记自身的 em 盒在槽里居中。
                top: (TOOLBAR_SLOT - ui_widgets::icon_extent(TOOLBAR_ICON)) * 0.5,
                bottom: 0.0,
            })
            .cross_align(0.0)
            .cross_pos(0.5)
            .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
            .cursor(if self.disabled { CursorShape::Arrow } else { CursorShape::PointingHand })
            .disabled(self.disabled)
            .press_ink(m.press)
            .shapes(shapes)
            .child(m.icon.resolve_with_size(m.id.with("icon"), m.ink, TOOLBAR_ICON))
    }
}

impl Widget for Md3Toolbar {
    fn handles_disabled(&self) -> bool {
        // The disabled ink is the export's own 38% colour, painted here.
        // 禁用墨色取自导出自己的 38%，在这里绘制。
        true
    }

    fn change(&self, state: &WidgetState, bounds: ui_core::geom::Rect) -> Option<ui_core::Change> {
        // The press point names the member; the keyboard has none (engine-audit F12).
        // 按下点指名成员；键盘没有按下点（engine-audit F12）。
        if self.disabled || !state.clicked {
            return None;
        }
        // Members are laid out left to right from the leading inset; the press point names
        // one by its slot.
        let local = state.local?;
        let x = local.x - self.inset;
        if x < 0.0 || local.y < 0.0 || local.y > bounds.size.h {
            return None;
        }
        let step = TOOLBAR_SLOT + self.gap;
        let k = (x / step).floor() as usize;
        if k >= self.members.len() || x - k as f32 * step > TOOLBAR_SLOT {
            return None;
        }
        Some(ui_core::Change::Selected(Some(self.members[k].id)))
    }

    fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
        let mut root = Decl::container(self.id, NodeKind::Row)
            .size(SizeClass {
                width: if self.floating { AxisSize::hug(0.0, 0.0) } else { AxisSize::fill(0.0, 0.0) },
                height: AxisSize::fixed(self.height),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets { left: self.inset, right: self.inset, top: 0.0, bottom: 0.0 })
            .gap(self.gap)
            .cross_align(0.0)
            .cross_pos(0.5)
            .shapes(vec![Shape::Box {
                // The docked bar is `corner.none`; the floating one is `corner.full`.
                // 停靠式是 `corner.none`；浮动式是 `corner.full`。
                corners: if self.floating {
                    Corners::all(self.height * 0.5)
                } else {
                    Corners::ZERO
                },
                fill: self.container,
                gradient: None,
                border: None,
                shadow: self.shadow,
                image: None,
            }]);
        for m in &self.members {
            root = root.child(self.member_decl(m));
        }
        root
    }
}
