//! MD3 controls, reproduced from `flutter/material/*.dart` defaults.
//! MD3 控件，按 `flutter/material/*.dart` 的默认值复刻。
//!
//! One file per control; the shared sizes, curves and glyph strokes live beside them.
//! 每个控件一个文件；共用的尺寸、曲线与笔画放在旁边。

pub mod pack;
/// Generated token lookups from the official design-system export (`tokens/*.json`).
/// 由官方设计系统导出（`tokens/*.json`）生成令牌查询。
pub mod spec;
pub use pack::{pack, pack_of};
pub use spec::{ButtonSize, ButtonStyle, ButtonToggle};
pub use ui_design::Appearance;

/// MD3 disabled content opacity: `on-surface` at 38% (label, icon, handle, active track).
/// MD3 禁用内容不透明度：`on-surface` 取 38%（标签、图标、手柄、活动轨道）。
pub const DISABLED_CONTENT_OPACITY: f32 = 0.38;
/// MD3 disabled container opacity: `on-surface` at 12% (inactive track, outline).
/// MD3 禁用容器不透明度：`on-surface` 取 12%（非活动轨道、描边）。
pub const DISABLED_CONTAINER_OPACITY: f32 = 0.12;


mod badge;
mod button;
mod button_group;
mod card;
mod checkbox;
mod chip;
mod date_input;
mod date_picker;
mod dialog;
mod divider;
mod fab_menu;
mod glyph;
mod layer;
mod list;
mod menu_style;
mod nav_bar;
mod nav_drawer;
mod nav_rail;
mod progress;
mod radio;
mod scaffold;
mod search_bar;
mod search_view;
mod segmented_button;
mod shortcut_field;
mod slider;
mod snackbar;
mod style;
mod tab_bar;
mod text_field;
mod time_picker;
mod toggle;
mod toolbar;
pub mod typescale;

mod app_bar;
mod carousel;

pub use app_bar::*;
pub use badge::*;
pub use button::*;
pub use button_group::*;
pub use card::*;
pub use carousel::*;
pub use checkbox::*;
pub use chip::*;
pub use date_input::*;
pub use date_picker::*;
pub use dialog::*;
pub use divider::*;
pub use fab_menu::*;
pub use list::*;
pub use menu_style::*;
pub use nav_bar::*;
pub use nav_drawer::*;
pub use nav_rail::*;
pub use progress::*;
pub use radio::*;
pub use scaffold::*;
pub use search_bar::*;
pub use search_view::*;
pub use segmented_button::*;
pub use shortcut_field::*;
pub use slider::*;
pub use snackbar::*;
pub use style::*;
pub use tab_bar::*;
pub use text_field::*;
pub use time_picker::*;
pub use toggle::*;
pub use toolbar::*;

#[cfg(test)]
mod tests;
