//! MD3 cards: one surface in three variants — elevated, filled, outlined.
//! MD3 卡片：同一种表面，三种变体——立面、填充、描边。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Insets};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::tree::ShadowSpec;
use ui_core::{AnimSpec, CursorShape, Decl, Easing, Id, InkRadius, NodeKind, PressInk, Sense};
use ui_style::Style;
use ui_widgets::build::param;
use ui_widgets::{Cx, Widget, WidgetState};

use crate::layer::press_ink;
use crate::spec::{elevated_card_spec, filled_card_spec, outlined_card_spec};
use crate::toggle::{role, spec_ink};
use crate::Md3Options;

/// `kRadialReactionDuration`: the state layer's fade, and the focus ring's.
/// `kRadialReactionDuration`：状态层与焦点环的淡入时长。
const REACTION: AnimSpec = AnimSpec::new(0.1, Easing::Linear);

/// MD3's card corner; the export says `rounded_corners` without a number.
/// MD3 卡片的圆角；导出只写 `rounded_corners`，没给数值。
pub const CARD_RADIUS: f32 = 12.0;
/// MD3's content inset for a card; the export carries no padding token.
/// MD3 卡片的内容内衬；导出没有内衬令牌。
pub const CARD_PAD: f32 = 16.0;

/// Which card this is; the export has one token table per variant.
/// 这是哪一种卡片；导出为每种变体各给一张令牌表。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CardVariant {
    Elevated,
    Filled,
    Outlined,
}

/// The values one variant resolves for one state, normalised across the three exports.
/// 某种变体在某个状态下解析出的取值，跨三份导出归一。
struct Parts {
    fill: &'static str,
    fill_op: f32,
    elevation: f32,
    outline: &'static str,
    outline_op: f32,
    outline_w: f32,
    layer: &'static str,
    layer_op: f32,
    ring: &'static str,
    ring_w: f32,
}

fn parts(variant: CardVariant, hovered: bool, focused: bool, pressed: bool, dragged: bool, disabled: bool) -> Parts {
    match variant {
        CardVariant::Elevated => {
            let v = elevated_card_spec(hovered, focused, pressed, dragged, disabled);
            Parts {
                fill: v.container.color,
                fill_op: v.container.opacity,
                elevation: v.container.elevation,
                // These two variants carry no `outline` object at all.
                // 这两种变体根本没有 `outline` 对象。
                outline: "",
                outline_op: 1.0,
                outline_w: 0.0,
                layer: v.state_layer.color,
                layer_op: v.state_layer.opacity,
                ring: v.focus_indicator.color,
                ring_w: v.focus_indicator.thickness,
            }
        }
        CardVariant::Filled => {
            let v = filled_card_spec(hovered, focused, pressed, dragged, disabled);
            Parts {
                fill: v.container.color,
                fill_op: v.container.opacity,
                elevation: v.container.elevation,
                // These two variants carry no `outline` object at all.
                // 这两种变体根本没有 `outline` 对象。
                outline: "",
                outline_op: 1.0,
                outline_w: 0.0,
                layer: v.state_layer.color,
                layer_op: v.state_layer.opacity,
                ring: v.focus_indicator.color,
                ring_w: v.focus_indicator.thickness,
            }
        }
        CardVariant::Outlined => {
            let v = outlined_card_spec(hovered, focused, pressed, dragged, disabled);
            Parts {
                fill: v.container.color,
                // Only this variant has no `container.opacity`: it disables the ring instead.
                // 只有这个变体没有 `container.opacity`：它把禁用放在描边上。
                fill_op: 1.0,
                elevation: v.container.elevation,
                outline: v.outline.color,
                outline_op: v.outline.opacity,
                outline_w: v.outline.width,
                layer: v.state_layer.color,
                layer_op: v.state_layer.opacity,
                ring: v.focus_indicator.color,
                ring_w: v.focus_indicator.thickness,
            }
        }
    }
}

/// A card: the surface the app fills with its own content.
/// 一张卡片：应用用自身内容填充的表面。
pub struct Md3Card {
    id: Id,
    variant: CardVariant,
    fill: Color,
    outline: Option<(Color, f32)>,
    shadow: Option<ShadowSpec>,
    layer: Option<Color>,
    /// The press ink the engine splats at the pointer.
    /// 引擎在指针处泼出的按压墨迹。
    press: Option<PressInk>,
    ring: Option<(Color, f32)>,
    pad: f32,
    clickable: bool,
    disabled: bool,
    content: Vec<Decl>,
}

impl Md3Card {
    /// Build one card. `content` is whatever the app puts inside; an empty list gives an
    /// empty surface.
    /// 构建一张卡片。`content` 是应用放进来的内容；空列表给出一个空表面。
    pub fn new_with(
        params: Md3Options,
        id: Id,
        variant: CardVariant,
        content: Vec<Decl>,
        clickable: bool,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let mut node = cx.at(id);
        let state = node.state();
        let disabled = params.disabled || state.disabled;
        let rest = parts(variant, state.hovered, state.focus_visible, state.pressed, false, disabled);
        let hover = parts(variant, true, false, false, false, disabled);
        let focus = parts(variant, false, true, false, false, disabled);
        let press = parts(variant, false, false, true, false, disabled);
        let hover_t = node.animate(id.with(param::HOVER), f32::from(state.hovered), REACTION);
        let focus_t = node.animate(id.with(param::FOCUS), f32::from(state.focus_visible), REACTION);
        let layer_ink = role(pack, hover.layer);
        // A static card has no interaction, so it paints no layer even when hovered.
        // 静态卡片没有交互，因此即使悬停也不画状态层。
        let interactive = clickable && !disabled;
        let strength = (hover_t * hover.layer_op).max(focus_t * focus.layer_op);
        let layer = (strength > 0.0 && interactive)
            .then_some(Color { a: layer_ink.a * strength, ..layer_ink });
        // A press is a splat from the pointer, not another rise of the flat layer.
        // 按下是自指针泼出的墨迹，而不是又把平坦状态层抬高一次。
        let ink = interactive.then(|| {
            press_ink(Color { a: layer_ink.a * press.layer_op, ..layer_ink }, InkRadius::Cover)
        });
        let ring_t = node.animate(id.with(param::THICKNESS), f32::from(state.focus_visible), REACTION);
        let ring_ink = spec_ink(pack, rest.ring, 1.0);
        let ring = (ring_t > 0.0 && clickable && !disabled)
            .then_some((Color { a: ring_ink.a * ring_t, ..ring_ink }, rest.ring_w));
        let outline = (rest.outline_w > 0.0 && !rest.outline.is_empty())
            .then(|| (spec_ink(pack, rest.outline, rest.outline_op), rest.outline_w));
        let shadow = (rest.elevation > 0.0)
            .then(|| ShadowSpec::black(rest.elevation * 2.0, 0.18, rest.elevation * 0.5));
        Self {
            id,
            variant,
            fill: spec_ink(pack, rest.fill, rest.fill_op),
            outline,
            shadow,
            layer,
            press: ink,
            ring,
            pad: CARD_PAD,
            clickable,
            disabled,
            content,
        }
    }

    /// The variant this card was built as.
    /// 这张卡片构建时选定的变体。
    pub fn variant(&self) -> CardVariant {
        self.variant
    }

    /// The corner radius, which the export names but does not size.
    /// 圆角半径：导出给了形状名，但没给尺寸。
    pub fn radius(&self) -> f32 {
        CARD_RADIUS
    }

    /// The content inset the card applies to whatever it holds.
    /// 卡片对其内容施加的内衬。
    pub fn pad(&self) -> f32 {
        self.pad
    }
}

impl Widget for Md3Card {
    fn handles_disabled(&self) -> bool {
        // The export carries the disabled container itself, so the adapter must not fade again.
        // 导出自带禁用容器，适配器不得再淡化一次。
        true
    }

    fn change(&self, state: &WidgetState, _bounds: ui_core::geom::Rect) -> Option<ui_core::Change> {
        (self.clickable && !self.disabled && state.activation())
            .then_some(ui_core::Change::Activated)
    }

    fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
        let mut shapes = Vec::with_capacity(3);
        let mut b = Shape::Box {
            corners: Corners::all(CARD_RADIUS),
            fill: self.fill,
            gradient: None,
            border: self.outline,
            shadow: self.shadow,
            image: None,
        };
        if let Shape::Box { shadow, .. } = &mut b {
            *shadow = self.shadow;
        }
        shapes.push(b);
        if let Some(layer) = self.layer {
            shapes.push(Shape::Box {
                corners: Corners::all(CARD_RADIUS),
                fill: layer,
                gradient: None,
                border: None,
                shadow: None,
                image: None,
            });
        }
        // The export insets the ring by `focus.indicator.outline.offset`; it is drawn on the
        // card's own edge instead, since the decl cannot know the final rect.
        // 导出要求焦点环外移 `focus.indicator.outline.offset`；改为画在卡片边缘，
        // 因为声明阶段拿不到最终矩形。
        if let Some((ink, width)) = self.ring {
            shapes.push(Shape::Box {
                corners: Corners::all(CARD_RADIUS),
                fill: Color::TRANSPARENT,
                gradient: None,
                border: Some((ink, width)),
                shadow: None,
                image: None,
            });
        }
        let mut card = Decl::container(self.id, NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::hug(0.0, 0.0),
                height: AxisSize::hug(0.0, 0.0),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets::all(self.pad))
            .shapes(shapes);
        if self.clickable {
            card = card
                .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
                .cursor(if self.disabled { CursorShape::Arrow } else { CursorShape::PointingHand })
                .disabled(self.disabled)
                .press_ink(self.press);
        }
        card.children(self.content.iter().cloned())
    }
}
