//! MD3 top app bar: a container holding a leading slot, a title and trailing actions.
//! MD3 顶部应用栏：一个容器，装前置槽位、标题与尾部动作。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Insets, Rect};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::tree::ShadowSpec;
use ui_core::{AnimSpec, Change, CursorShape, Decl, Easing, Id, InkRadius, NodeKind, Sense};
use ui_style::Style;
use ui_widgets::build::param;
use ui_widgets::text::Text;
use ui_widgets::{Cx, IconSource, Widget, WidgetState};

use crate::layer::Background;
use crate::spec::{app_bar_spec, AppBarSize};
use crate::toggle::spec_ink;
use crate::typescale;
use crate::Md3Options;

/// The small bar's height, which is also the band a medium or large bar keeps its slot in.
/// 小号栏的高度，也是中/大号栏容纳前置槽位的那条带。
pub const APP_BAR_TOP_BAND: f32 = 64.0;
/// MD3's icon-button touch target; the export's `leading-space` sits outside it.
/// MD3 图标按钮的触控尺寸；导出的 `leading-space` 在它之外。
pub const APP_BAR_SLOT: f32 = 48.0;
/// The mark inside a slot, from `md.comp.app-bar.icon.size`.
/// 槽位内的标记尺寸，取自 `md.comp.app-bar.icon.size`。
pub const APP_BAR_ICON: f32 = 24.0;
/// `NavigationToolbar.kMiddleSpacing`: the title follows the leading slot by this much.
/// `NavigationToolbar.kMiddleSpacing`：标题与前置槽位相距这么多。
pub const APP_BAR_TITLE_GAP: f32 = 16.0;
/// A title with nothing leading it starts this far from the bar's edge.
/// 前面没有东西的标题距栏边这么多。
pub const APP_BAR_TITLE_INSET: f32 = 16.0;

/// The scroll-under transition: MD3's emphasized decelerate.
/// 滚入其下的过渡：MD3 的强调减速曲线。
const COLLAPSE: AnimSpec = AnimSpec::new(0.3, Easing::Cubic(0.2, 0.0, 0.0, 1.0));
/// `kRadialReactionDuration`, shared by hover and focus.
/// `kRadialReactionDuration`，悬停与焦点共用。
const REACTION: AnimSpec = AnimSpec::new(0.1, Easing::Linear);

/// The six app bars the export tokenises; each fixes its height, title scale and padding.
/// 导出给出令牌的六种应用栏；每种都固定自己的高度、标题字级与内衬。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum AppBarVariant {
    Small,
    Medium,
    Large,
    /// Collapses to the small bar as its content scrolls under it.
    /// 内容滚到其下时收成小号栏。
    MediumFlexible,
    LargeFlexible,
    /// The 56dp pill with a search label instead of a title.
    /// 56dp 胶囊，用搜索标签代替标题。
    Search,
}

impl AppBarVariant {
    /// The generated spec's axes: `(large_flexible, medium_flexible, search, size)`.
    /// 生成规格的轴：`(large_flexible, medium_flexible, search, size)`。
    fn axes(self) -> (bool, bool, bool, AppBarSize) {
        match self {
            Self::Small => (false, false, false, AppBarSize::Small),
            Self::Medium => (false, false, false, AppBarSize::Medium),
            Self::Large => (false, false, false, AppBarSize::Large),
            Self::MediumFlexible => (false, true, false, AppBarSize::Medium),
            Self::LargeFlexible => (true, false, false, AppBarSize::Large),
            Self::Search => (false, false, true, AppBarSize::Small),
        }
    }

    /// Whether the bar shrinks from its expanded height to the small one.
    /// 栏是否从展开高度缩到小号高度。
    pub fn flexible(self) -> bool {
        matches!(self, Self::MediumFlexible | Self::LargeFlexible)
    }

    /// The height this variant takes when expanded, straight from the export; a caller that
    /// reserves space for the bar needs it before the bar exists.
    /// 该变体展开时的高度，直接取自导出；为栏预留空间的调用方在栏存在之前就需要它。
    pub fn expanded_height(self, with_subtitle: bool) -> f32 {
        let (large_flex, medium_flex, search, size) = self.axes();
        app_bar_spec(large_flex, medium_flex, false, search, false, false, with_subtitle, size)
            .container
            .height
    }

    /// The gap under the title when it is anchored to the bar's bottom edge.
    /// 标题锚在栏底时，其下方的间距。
    fn title_bottom(self) -> f32 {
        match self {
            Self::Medium | Self::MediumFlexible => 20.0,
            Self::Large | Self::LargeFlexible => 28.0,
            Self::Small | Self::Search => 0.0,
        }
    }

    /// Whether the title sits in the top band with the slots rather than in its own band.
    /// 标题是与槽位同处一条带，还是有自己的带。
    fn inline_title(self) -> bool {
        matches!(self, Self::Small | Self::Search)
    }
}

/// What leads the title.
/// 标题之前放什么。
pub enum AppBarLeading {
    None,
    /// A 24dp mark inside the 48dp icon-button slot, in `leading-icon` ink.
    /// 48dp 图标按钮槽位里的 24dp 标记，用 `leading-icon` 墨色绘制。
    Icon(IconSource),
    /// A 32dp avatar (`avatar.size`) centred in the slot; the app builds it.
    /// 居中于槽位的 32dp 头像（`avatar.size`）；由应用构建。
    Avatar(Decl),
}

/// One trailing action: the id the app knows it by and its mark.
/// 一个尾部动作：应用认识它的 id 与其标记。
pub struct AppBarAction {
    pub id: Id,
    /// The 24dp mark in `trailing-icon` ink, as a source the slot resolves.
    /// `trailing-icon` 墨色下的 24dp 标记，作为槽位解析的源。
    pub icon: IconSource,
}

/// Everything an app bar is built with. Variant, slots and width are fixed at build time.
/// 构建应用栏所需的一切。变体、槽位与宽度在构建期固定。
pub struct AppBarParams<'a> {
    pub id: Id,
    pub variant: AppBarVariant,
    pub title: &'a str,
    /// Only the flexible variants tokenise a subtitle; elsewhere it is dropped.
    /// 只有可收起的变体给出副标题令牌；其余变体会忽略它。
    pub subtitle: Option<&'a str>,
    pub leading: AppBarLeading,
    pub actions: &'a [AppBarAction],
    /// The width the bar will be laid out at; the title wraps inside it.
    /// 栏将被布局成的宽度；标题在其中换行。
    pub width: f32,
}

/// A top app bar; `scrolled` and `collapsed` are the two facts its app owns.
/// 一个顶部应用栏；`scrolled` 与 `collapsed` 是应用持有的两个事实。
pub struct Md3AppBar {
    id: Id,
    height: f32,
    /// The width the app said the bar will get; the title band and its wrap use it.
    /// 应用给出的栏宽；标题带与换行都用它。
    width: f32,
    corners: Corners,
    surface: Color,
    shadow: Option<ShadowSpec>,
    leading_space: f32,
    trailing_space: f32,
    inline_title: bool,
    /// The gap between the leading slot and an inline title; the band sets its own inset.
    /// 前置槽位与内联标题之间的间隙；带内的标题用自己的内衬。
    title_gap: f32,
    leading: Option<Decl>,
    actions: Vec<Decl>,
    title: Option<Decl>,
    subtitle: Option<Decl>,
    title_left: f32,
    title_bottom: f32,
    disabled: bool,
    /// The slot whose press landed this frame.
    /// 本帧按下所落的槽位。
    fired: Option<Id>,
}

impl Md3AppBar {
    /// Build one bar. `collapsed` only moves the flexible variants.
    /// 构建一个栏。`collapsed` 只影响可收起的变体。
    pub fn new_with(
        params: Md3Options,
        content: AppBarParams<'_>,
        scrolled: bool,
        collapsed: bool,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let AppBarParams { id, variant, title, subtitle, leading, actions, width } = content;
        let (large_flex, medium_flex, search, size) = variant.axes();
        let with_subtitle = subtitle.is_some() && variant.flexible();
        // The generated spec writes title and subtitle onto the same slot, so ask twice.
        // 生成的规格把标题与副标题写进同一个槽位，因此问两次。
        let base = app_bar_spec(large_flex, medium_flex, scrolled, search, false, false, with_subtitle, size);
        let title_spec = app_bar_spec(large_flex, medium_flex, scrolled, search, false, true, with_subtitle, size);
        let sub_spec = app_bar_spec(large_flex, medium_flex, scrolled, search, true, false, with_subtitle, size);

        let mut node = cx.at(id);
        let disabled = params.disabled || node.state().disabled;
        let collapse = if variant.flexible() {
            node.animate(id.with("collapse"), f32::from(collapsed), COLLAPSE)
        } else {
            0.0
        };

        // The base variant carries no height of its own; every real variant does.
        // 基变体没有自己的高度令牌；每个真实变体都有。
        let expanded = match base.container.height {
            0.0 => APP_BAR_TOP_BAND,
            height => height,
        };
        let height = lerp(expanded, APP_BAR_TOP_BAND, collapse);
        let fade = if disabled { crate::DISABLED_CONTENT_OPACITY } else { 1.0 };

        let scale = if !base.label_text.font.is_empty() {
            base.label_text.font
        } else {
            title_spec.root.font
        };
        let mut title_style = typescale::named(scale);
        if variant.flexible() {
            title_style.size = lerp(title_style.size, typescale::TITLE_LARGE.size, collapse);
        }
        let title_left = if variant.inline_title() {
            leading_inset(&leading, base.root.leading_space)
        } else {
            lerp(APP_BAR_TITLE_INSET, leading_inset(&leading, base.root.leading_space), collapse)
        };
        // Centring the collapsed title needs its own height, which only the small scale fixes.
        let collapsed_bottom = (APP_BAR_TOP_BAND - typescale::TITLE_LARGE.size * 1.4) * 0.5;
        let title_bottom = lerp(variant.title_bottom(), collapsed_bottom, collapse);

        let slots = width - title_left - APP_BAR_TITLE_INSET;
        let inline_slots = slots - actions.len() as f32 * APP_BAR_SLOT - base.root.trailing_space;
        let max_w = if variant.inline_title() { inline_slots } else { slots }.max(0.0);
        // An inline title is laid out by the row's flow, so the gap is what is left over
        // between the inset and the slot that already precedes it.
        // 内联标题由行的流摆放，因此间隙是内衬扣除已在其前的那段槽位后的余量。
        let title_gap = title_left
            - base.root.leading_space
            - if matches!(leading, AppBarLeading::None) { 0.0 } else { APP_BAR_SLOT };

        let title_decl = Text::new(id.with("title"), title, title_style.size, spec_ink(pack, title_spec.root.color, fade))
            .weight(title_style.weight)
            .max_width(max_w)
            .resolve();
        let subtitle_decl = subtitle.filter(|_| with_subtitle).map(|text| {
            let style = typescale::named(sub_spec.root.font);
            let ink = spec_ink(pack, sub_spec.root.color, fade * (1.0 - collapse));
            // The subtitle's line shrinks with the bar, so the title slides down instead of
            // jumping on the frame the line disappears.
            // 副标题那一行随栏一起收缩，标题因此平滑下移，而不是在它消失的那一帧瞬移。
            Decl::container(id.with("subtitle-row"), NodeKind::Column)
                .size(SizeClass {
                    width: AxisSize::fixed(max_w),
                    height: AxisSize::fixed(style.size * 1.4 * (1.0 - collapse)),
                    grow_x: Grow::No,
                    grow_y: Grow::No,
                })
                .cross_align(0.0)
                .child(
                    Text::new(id.with("subtitle"), text, style.size, ink)
                        .weight(style.weight)
                        .max_width(max_w)
                        .resolve(),
                )
        });

        let layer_ink = spec_ink(pack, "onSurface", 1.0);
        let leading_decl = match leading {
            AppBarLeading::None => None,
            AppBarLeading::Icon(build) => Some(icon_slot(
                id.with("leading"),
                build,
                spec_ink(pack, base.leading_icon.color, fade),
                layer_ink,
                disabled,
                cx,
            )),
            AppBarLeading::Avatar(avatar) => Some(avatar_slot(id.with("leading"), avatar)),
        };
        let action_decls: Vec<Decl> = actions
            .iter()
            .map(|a| {
                icon_slot(
                    a.id,
                    a.icon,
                    spec_ink(pack, base.trailing_icon.color, fade),
                    layer_ink,
                    disabled,
                    cx,
                )
            })
            .collect();
        let fired = actions
            .iter()
            .map(|a| a.id)
            .chain([id.with("leading")])
            .find(|slot| cx.state(*slot).activation());

        Self {
            id,
            height,
            width,
            corners: match base.container.shape {
                "circular" => Corners::all(height * 0.5),
                _ => Corners::ZERO,
            },
            surface: spec_ink(pack, base.container.color, 1.0),
            shadow: (base.container.elevation > 0.0).then(|| {
                ShadowSpec::black(
                    base.container.elevation * 2.0,
                    0.18,
                    base.container.elevation * 0.5,
                )
            }),
            leading_space: base.root.leading_space,
            trailing_space: base.root.trailing_space,
            inline_title: variant.inline_title(),
            title_gap,
            leading: leading_decl,
            actions: action_decls,
            title: Some(title_decl),
            subtitle: subtitle_decl,
            title_left,
            title_bottom,
            disabled,
            fired,
        }
    }

    /// The bar's own height this frame; a flexible one shrinks as it collapses.
    /// 本帧栏自身的高度；可收起的栏随收起而变矮。
    pub fn height(&self) -> f32 {
        self.height
    }

    /// The leading slot, the title when it is inline, then the actions at the far end.
    /// 前置槽位、内联时的标题，然后是坐在远端的动作。
    fn top_band(&self) -> Decl {
        let mut row = Decl::container(self.id.with("top"), NodeKind::Row)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fixed(self.height.min(APP_BAR_TOP_BAND)),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets {
                left: self.leading_space,
                top: 0.0,
                right: self.trailing_space,
                bottom: 0.0,
            })
            .cross_align(0.0)
            .cross_pos(0.5);
        if let Some(leading) = &self.leading {
            row = row.child(leading.clone());
        }
        if self.inline_title
            && let Some(title) = &self.title {
                row = row.child(
                    Decl::container(self.id.with("title-gap"), NodeKind::Column)
                        .padding(Insets {
                            left: self.title_gap,
                            top: 0.0,
                            right: 0.0,
                            bottom: 0.0,
                        })
                        .cross_align(0.0)
                        .child(title.clone()),
                );
            }
        row = row.child(spacer(self.id.with("gap")));
        for action in &self.actions {
            row = row.child(action.clone());
        }
        row
    }

    /// The title band: a full-height overlay, so a bottom anchor survives any bar height.
    /// 标题带：整高的悬浮层，因此底部锚定在任何栏高下都成立。
    ///
    /// `cross_pos` is the container's knob, so the row inside the overlay owns the anchor.
    /// `cross_pos` 是容器侧的旋钮，因此底部锚定由悬浮层里的那一行持有。
    fn title_band(&self) -> Option<Decl> {
        if self.inline_title {
            return None;
        }
        let mut column = Decl::container(self.id.with("title-col"), NodeKind::Column)
            .cross_align(0.0)
            .cross_pos(0.0)
            // The title is decoration: a press on it belongs to whatever is under the band.
            // 标题是装饰：点在标题上的按下属于栏内其下的东西。
            .sense(Sense::PASS_THROUGH);
        column = column.child(self.title.clone()?);
        if let Some(subtitle) = &self.subtitle {
            column = column.child(subtitle.clone());
        }
        let row = Decl::container(self.id.with("title-row"), NodeKind::Row)
            .size(SizeClass {
                width: AxisSize::fixed(self.width),
                height: AxisSize::fixed(self.height),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets {
                left: self.title_left,
                top: 0.0,
                right: APP_BAR_TITLE_INSET,
                bottom: self.title_bottom,
            })
            .cross_align(0.0)
            .cross_pos(1.0)
            .sense(Sense::PASS_THROUGH)
            .child(column);
        Some(
            Decl::container(self.id.with("title-band"), NodeKind::Overlay)
                .size(SizeClass {
                    width: AxisSize::fixed(self.width),
                    height: AxisSize::fixed(self.height),
                    grow_x: Grow::No,
                    grow_y: Grow::No,
                })
                // The band spans the whole bar, so it must let presses reach the slots.
                // 带覆盖整条栏，因此必须让按下透到槽位上。
                .sense(Sense::PASS_THROUGH)
                .child(row),
        )
    }
}

impl Widget for Md3AppBar {
    fn handles_disabled(&self) -> bool {
        // The 38% fade is resolved per ink, so the adapter must not fade the subtree again.
        // 38% 淡化是按墨色解析的，适配器不得再对子树淡化一次。
        true
    }

    fn change(&self, _state: &WidgetState, _bounds: Rect) -> Option<Change> {
        if self.disabled {
            return None;
        }
        self.fired.map(|slot| Change::Selected(Some(slot)))
    }

    fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
        let mut root = Decl::container(self.id, NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fixed(self.height),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .disabled(self.disabled)
            .shapes(vec![Shape::Box {
                corners: self.corners,
                fill: self.surface,
                gradient: None,
                border: None,
                shadow: self.shadow,
                image: None,
            }]);
        root = root.child(self.top_band());
        if let Some(band) = self.title_band() {
            root = root.child(band);
        }
        root
    }
}

/// Where the title starts: past the leading slot when there is one, else at its own inset.
/// 标题的起点：有前置槽位时在其之后，否则在自身的内衬处。
fn leading_inset(leading: &AppBarLeading, leading_space: f32) -> f32 {
    match leading {
        AppBarLeading::None => APP_BAR_TITLE_INSET,
        _ => leading_space + APP_BAR_SLOT + APP_BAR_TITLE_GAP,
    }
}

/// Scalar linear interpolation, exact at both ends.
/// 标量线性插值，两端取定值。
fn lerp(a: f32, b: f32, t: f32) -> f32 {
    if t <= 0.0 {
        a
    } else if t >= 1.0 {
        b
    } else {
        a + (b - a) * t
    }
}

/// A zero-basis grower: it takes the spare space so the actions reach the far end.
/// 零基准增长者：吃掉余量，使动作抵达远端。
fn spacer(id: Id) -> Decl {
    Decl::container(id, NodeKind::Column).size(SizeClass {
        width: AxisSize::hug(0.0, 0.0),
        height: AxisSize::hug(0.0, 0.0),
        grow_x: Grow::Yes,
        grow_y: Grow::No,
    })
}

/// The 40dp state-layer disc MD3 paints under an icon button; the slot keeps 4dp around it.
/// MD3 图标按钮的 40dp 状态层圆盘；槽位在它四周留 4dp。
fn state_layer(fill: Color) -> Shape {
    Shape::Rect {
        rect: Rect::new(4.0, 4.0, 40.0, 40.0),
        corners: Corners::all(20.0),
        fill,
        gradient: None,
        border: None,
    }
}

/// The shared shell of an icon-button slot: state layer, press ink, pointer and the mark.
/// 图标按钮槽位的共用外壳：状态层、按压墨迹、指针与标记。
fn icon_slot(
    id: Id,
    source: IconSource,
    ink: Color,
    layer_ink: Color,
    disabled: bool,
    cx: &mut Cx<'_, '_>,
) -> Decl {
    let mut node = cx.at(id);
    let state = node.state();
    let hover = node.animate(id.with(param::HOVER), f32::from(state.hovered), REACTION);
    let focus = node.animate(id.with(param::FOCUS), f32::from(state.focus_visible), REACTION);
    let alpha = (hover * 0.08).max(focus * 0.1);
    let mut shapes = Vec::with_capacity(1);
    if alpha > 0.0 && !disabled {
        shapes.push(state_layer(Color { a: layer_ink.a * alpha, ..layer_ink }));
    }
    // The ripple belongs to the 40dp disc, not the 48dp slot: the disc is the effective
    // background, as it is for the toolbar's icon buttons.
    // 涟漪属于 40dp 圆盘而不是 48dp 槽位：圆盘才是有效背景，与工具条的图标按钮一致。
    let background = Background::new(Rect::new(4.0, 4.0, 40.0, 40.0), Corners::all(20.0));
    let press = (!disabled)
        .then(|| background.press(Color { a: layer_ink.a * 0.1, ..layer_ink }, InkRadius::Cover));
    // A Stack centres the mark's em box; `Text`'s line box would hang it high.
    // 用 Stack 居中标记的 em 盒；`Text` 的行盒会把它吊高。
    Decl::container(id, NodeKind::Stack)
        .size(SizeClass::fixed(APP_BAR_SLOT, APP_BAR_SLOT))
        .stack_align(ui_core::layout::OverlayAlign::Center)
        .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
        .cursor(if disabled { CursorShape::Arrow } else { CursorShape::PointingHand })
        .disabled(disabled)
        .press_ink(press)
        // The slot's curve is a disc, stated rather than left to the shape it happens to
        // paint: a press near the corner must not fill the square around the state layer.
        // 槽位的曲线是圆，直接声明而不是依赖它恰好画出的形状：按在角落不得填满状态层外的方块。
        .corners(Corners::all(APP_BAR_SLOT * 0.5))
        .shapes(shapes)
        .child(source.resolve_with_size(id.with("icon"), ink, APP_BAR_ICON))
}

/// An avatar slot: the app's own 32dp mark, centred like an icon.
/// 头像槽位：应用自有的 32dp 标记，与图标一样居中。
fn avatar_slot(id: Id, avatar: Decl) -> Decl {
    Decl::container(id, NodeKind::Column)
        .size(SizeClass::fixed(APP_BAR_SLOT, APP_BAR_SLOT))
        .padding(Insets {
            left: 0.0,
            top: (APP_BAR_SLOT - 32.0) * 0.5,
            right: 0.0,
            bottom: 0.0,
        })
        .cross_align(0.0)
        .cross_pos(0.5)
        .child(avatar)
}
