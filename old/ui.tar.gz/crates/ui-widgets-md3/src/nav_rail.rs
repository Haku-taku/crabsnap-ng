//! MD3 navigation rail: the navigation bar's destinations stacked in a fixed 80dp column, with
//! a 56×32 capsule that becomes a 56×56 circle when no labels are shown. The Expressive variant
//! is a 96dp / 220dp pair whose width travels between the two as the destinations' pill opens.
//! MD3 导航轨道：把导航栏的目标纵向堆进 80dp 定宽列，指示片是 56×32 胶囊，
//! 不显示标签时变成 56×56 正圆。Expressive 变体是 96dp / 220dp 的一对，
//! 目标的胶囊张开时，轨道宽度在两端之间走过去。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Insets, Point, Rect};
use ui_core::layout::{AxisSize, Clip, Grow, Overflow, SizeClass};
use ui_core::{
    AnimSpec, CursorShape, Decl, Easing, Id, InkRadius, NodeKind, PieceCubic, PressInk, Sense,
    Weight,
};
use ui_style::Style;
use ui_widgets::build::param;
use ui_widgets::text::Text;
use ui_widgets::{Cx, IconSource, Widget, WidgetState};

use crate::layer::{press_ink_in, Background};
use crate::nav_bar::{boxed, faded, Md3NavItem};
use crate::spec::navigation_rail_spec;
use crate::toggle::{between, lerp, role, spec_ink};
use crate::Md3Options;

/// Flutter's `Curves.easeInOutCubicEmphasized`, the destination's indicator curve.
/// Flutter 的 `Curves.easeInOutCubicEmphasized`，目标指示片的曲线。
static EMPHASIZED: PieceCubic = PieceCubic {
    a1: (0.05, 0.0),
    b1: (0.133333, 0.06),
    mid: (0.166666, 0.4),
    a2: (0.208333, 0.82),
    b2: (0.25, 1.0),
};
/// `NavigationRail` destination animation: the indicator's 500ms scale-in.
/// `NavigationRail` 的目标动画：指示片 500ms 的展开。
const SELECT: AnimSpec = AnimSpec::new(0.5, Easing::Piece(&EMPHASIZED));
/// `kRadialReactionDuration`: the hover and focus layers.
/// `kRadialReactionDuration`：悬停与聚焦的状态层。
const REACTION: AnimSpec = AnimSpec::new(0.1, Easing::Linear);
/// `_verticalIconLabelSpacingM3`.
/// `_verticalIconLabelSpacingM3`。
const LABEL_GAP: f32 = 4.0;
/// `_verticalDestinationSpacingM3`: the room under a destination, label or not.
/// `_verticalDestinationSpacingM3`：目标下方的留白，有无标签都一样。
const BOTTOM_GAP: f32 = 12.0;
/// Baseline M3's "top margin of navigation rail content": 8dp around the destinations.
/// M3 基线规范「导航轨道内容的上边距」：目标组四周各 8dp。
const RAIL_MARGIN: f32 = 8.0;

// The Expressive rail is hand-written: the export splits it into four token sets (`collapsed`,
// `expanded`, `item.vertical`, `item.horizontal`) that `gen_spec.py` would flatten into one
// undifferentiated soup of states. Every value below names the token it comes from.
// Expressive 轨道是手写的：导出把它拆进 `collapsed`、`expanded`、`item.vertical`、
// `item.horizontal` 四个令牌集，`gen_spec.py` 只会把它们摊成一锅分不清的状态。下面每个值都标了出处。

/// `…collapsed.container.width` and `…expanded.container.width.minimum`.
/// `…collapsed.container.width` 与 `…expanded.container.width.minimum`。
const EXP_COLLAPSED: f32 = 96.0;
const EXP_EXPANDED: f32 = 220.0;
/// `collapsed.top-space` / `expanded.top-space`: 44dp at both ends.
/// `collapsed.top-space` / `expanded.top-space`：两端都是 44dp。
const EXP_TOP: f32 = 44.0;
/// `item.container.height`; `collapsed.item.vertical-space` separates destinations.
/// `item.container.height`；目标之间由 `collapsed.item.vertical-space` 分隔。
const EXP_ITEM_H: f32 = 64.0;
const EXP_ITEM_GAP: f32 = 4.0;
/// `item.vertical.active-indicator.height` and `item.horizontal.active-indicator.height`.
/// `item.vertical.active-indicator.height` 与 `item.horizontal.active-indicator.height`。
const EXP_PILL_H: (f32, f32) = (32.0, 56.0);
/// `item.vertical.active-indicator.width`: the collapsed pill, which spans the rail expanded.
/// `item.vertical.active-indicator.width`：收起的胶囊宽度，展开后它横跨整条轨道。
const EXP_PILL_W: f32 = 56.0;
/// `item.horizontal.full-width.leading-space`, also the pill's inner
/// `active-indicator.leading-space`: the same 16dp centres the icon while collapsed.
/// `item.horizontal.full-width.leading-space`，也是胶囊内衬的
/// `active-indicator.leading-space`：同为 16dp，收起时正好把图标居中。
const EXP_INSET: f32 = 16.0;
/// `item.horizontal.active-indicator.icon-label-space`.
/// `item.horizontal.active-indicator.icon-label-space`。
const EXP_GAP: f32 = 8.0;
/// The label's box when open: 220 − 2·16 (pill inset) − 2·16 (pill padding) − 24 − 8.
/// 展开时标签的盒子：220 − 2·16（胶囊内缩）− 2·16（胶囊内衬）− 24 − 8。
const EXP_LABEL_W: f32 = 124.0;
/// `md.sys.typescale.label-medium.line-height` and `label-large.line-height`.
/// `md.sys.typescale.label-medium.line-height` 与 `label-large.line-height`。
const EXP_LABEL_LH: (f32, f32) = (16.0, 20.0);
/// M3's paired curve for a transition that begins and ends on screen: Standard, 300 ms.
/// M3 给「在屏幕内起止」的过渡配的曲线：Standard，300 毫秒。
const EXPAND: AnimSpec = AnimSpec::new(0.3, Easing::Cubic(0.2, 0.0, 0.0, 1.0));

/// Which destinations carry their label, mirroring `NavigationRailLabelType`.
/// 哪些目标带标签，对应 `NavigationRailLabelType`。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum RailLabelType {
    /// No destination carries a label; the indicator becomes the 56×56 circle.
    /// 所有目标都不带标签；指示片变成 56×56 正圆。
    #[default]
    None,
    /// Only the selected destination carries its label.
    /// 只有选中的目标带标签。
    Selected,
    /// Every destination carries its label.
    /// 每个目标都带标签。
    All,
}

/// Which rail family to build: the baseline column, or the Expressive pair whose width travels
/// between collapsed and expanded.
/// 构建哪种轨道家族：基线列，或宽度往返于收起与展开之间的 Expressive 一对。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum RailVariant {
    #[default]
    Classic,
    /// `expanded` is the target the width and the pill open toward, given by the app.
    /// `expanded` 是宽度与胶囊张开所前往的目标，由应用给出。
    Expressive { expanded: bool },
}

/// Everything a navigation rail needs besides the design system's own tokens.
/// 除设计系统令牌之外，导航轨道所需的一切。
pub struct RailParams<'a> {
    pub id: Id,
    /// The same destinations the bar takes; a rail is their vertical host.
    /// 与导航栏同一套目标；轨道只是它们的纵向宿主。
    pub items: &'a [Md3NavItem<'a>],
    /// The selected destination's index; the app owns it.
    /// 选中目标的序号；归应用所有。
    pub selected: usize,
    /// Which family to build; Expressive ignores it, its labels are always inside the pill.
    /// 构建哪种家族；Expressive 忽略它——它的标签始终在胶囊里。
    pub label_type: RailLabelType,
    pub variant: RailVariant,
    pub disabled: bool,
}

/// One destination's resolved paint data.
/// 一个目标解析后的绘制数据。
struct Item {
    id: Id,
    label: String,
    icon: IconSource,
    /// Whether this label type can show a label at all; `None` builds no label node.
    /// 这种标签类型是否会显示标签；`None` 根本不建标签节点。
    labelled: bool,
    /// The label's animated presence, `0..=1`: it fades and gives its room back together.
    /// 标签的动画呈现度 `0..=1`：淡出与让出位置同时进行。
    reveal: f32,
    /// The destination's own box height, which also gives the hit-test bands.
    /// 目标自身盒子的高度，同时给出命中条带。
    height: f32,
    icon_ink: Color,
    label_ink: Color,
    label_weight: Weight,
    layer: Option<Color>,
    press: Option<PressInk>,
    ring: f32,
    indicator: f32,
}

/// A navigation rail; the app owns which destination is selected.
/// 导航轨道；选中项归应用所有。
pub struct Md3NavRail {
    id: Id,
    items: Vec<Item>,
    selected: usize,
    variant: RailVariant,
    /// 0 collapsed, 1 expanded; the Expressive geometry reads it, `Classic` keeps it at 0.
    /// 0 收起、1 展开；Expressive 的几何读它，`Classic` 恒为 0。
    expand: f32,
    width: f32,
    indicator_w: f32,
    indicator_h: f32,
    indicator_ink: Color,
    icon_size: f32,
    label_size: f32,
    label_h: f32,
    container: Color,
    disabled: bool,
}

impl Md3NavRail {
    /// Same control with explicit parameters, so the semantic path and a direct caller
    /// produce identical `Decl`s.
    /// 带显式参数的同一控件，使语义路径与直接调用产出相同的 `Decl`。
    pub fn new_with(
        params: Md3Options,
        p: RailParams<'_>,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let (expressive, expanded) = match p.variant {
            RailVariant::Classic => (false, false),
            RailVariant::Expressive { expanded } => (true, expanded),
        };
        // Expressive labels live inside the pill, so it always keeps the 56×32 capsule.
        // Expressive 的标签在胶囊里，胶囊因此恒为 56×32。
        let no_label = !expressive && p.label_type == RailLabelType::None;
        let base = navigation_rail_spec(false, no_label, false, false, false);
        let disabled = params.disabled || cx.state(p.id).disabled;
        let fade = if disabled { crate::DISABLED_CONTENT_OPACITY } else { 1.0 };
        // One tween drives the pill and the label; the root declares the width and lets the
        // engine interpolate it, so both read the same clock and land on the same frame.
        // 一条补间驱动胶囊与标签；根节点只声明宽度、交给引擎插值，两者因此同步落定。
        let expand = if expressive {
            cx.at(p.id).animate(p.id.with("expand"), f32::from(expanded), EXPAND)
        } else {
            0.0
        };
        let medium = crate::typescale::LABEL_MEDIUM;
        let large = crate::typescale::LABEL_LARGE;
        let layer_ink = role(pack, navigation_rail_spec(false, no_label, true, false, false).state_layer.color);
        let hover_a = navigation_rail_spec(false, no_label, true, false, false).state_layer.opacity;
        let focus_a = navigation_rail_spec(false, no_label, false, true, false).state_layer.opacity;
        let press_a = navigation_rail_spec(false, no_label, false, false, true).state_layer.opacity;
        let mut items = Vec::with_capacity(p.items.len());
        for (k, item) in p.items.iter().enumerate() {
            let item_id = item.id;
            let mut node = cx.at(item_id);
            let state = node.state();
            let on = navigation_rail_spec(true, no_label, state.hovered, state.focus_visible, state.pressed);
            let off = navigation_rail_spec(false, no_label, state.hovered, state.focus_visible, state.pressed);
            let sel = node.animate(item_id.with(param::PROGRESS), f32::from(k == p.selected), SELECT);
            let hover = node.animate(item_id.with(param::HOVER), f32::from(state.hovered), REACTION);
            let focus = node.animate(item_id.with(param::FOCUS), f32::from(state.focus_visible), REACTION);
            let alpha = (hover * hover_a).max(focus * focus_a);
            let layer = (alpha > 0.0 && !disabled)
                .then_some(Color { a: layer_ink.a * alpha, ..layer_ink });
            let press = (!disabled).then(|| {
                // The ripple covers the capsule, not the whole destination: the indicator
                // is the effective background (Flutter `_IndicatorInkWell`).
                // 墨迹盖住胶囊，而不是整个目标：指示片才是有效背景
                // （Flutter `_IndicatorInkWell`）。
                press_ink_in(
                    Color { a: layer_ink.a * press_a, ..layer_ink },
                    InkRadius::Cover,
                    item_id.with("indicator"),
                )
            });
            // The rail has no focus-indicator tokens; the keyboard ring borrows the capsule's
            // own ink rather than inventing a colour.
            // 轨道没有焦点指示令牌；键盘环借用胶囊自身的墨色，而不是另造一个颜色。
            let ring = if disabled {
                0.0
            } else {
                node.animate(item_id.with(param::THICKNESS), f32::from(state.focus_visible), REACTION)
            };
            // The label does not switch on: it fades in while its own room grows, so the
            // destinations below glide instead of jumping by a whole label's height.
            // 标签不是开关：它一边淡入，一边长出自己占的位置，下面的目标因此滑动，
            // 而不是整段标签高度地跳变。
            let labelled = expressive || p.label_type != RailLabelType::None;
            let reveal = if expressive {
                // The label only starts fading once the pill has room for it.
                // 胶囊给得出位置以后，标签才开始淡入。
                ((expand - 0.2) / 0.6).clamp(0.0, 1.0)
            } else {
                match p.label_type {
                    RailLabelType::None => 0.0,
                    RailLabelType::All => 1.0,
                    RailLabelType::Selected => sel,
                }
            };
            items.push(Item {
                id: item_id,
                label: item.label.to_string(),
                icon: item.icon,
                labelled,
                reveal,
                height: if expressive {
                    EXP_ITEM_H
                } else {
                    destination_height(
                        base.active_indicator.height,
                        base.label_text.line_height,
                        reveal,
                    )
                },
                icon_ink: faded(
                    between(
                        spec_ink(pack, off.icon.color, 1.0),
                        spec_ink(pack, on.icon.color, 1.0),
                        sel,
                    ),
                    fade,
                ),
                label_ink: faded(
                    if expressive {
                        // The horizontal family exports no label colour; inside the pill the
                        // label must read `on-secondary-container`, the vertical token's
                        // `secondary` is for a label on the rail's own surface.
                        // 横向家族没有导出标签色；胶囊里必须读 `on-secondary-container`，
                        // 纵向令牌的 `secondary` 是轨道表面上标签的颜色。
                        between(
                            role(pack, "secondary"),
                            role(pack, "onSecondaryContainer"),
                            expand,
                        )
                    } else {
                        between(
                            spec_ink(pack, off.label_text.color, 1.0),
                            spec_ink(pack, on.label_text.color, 1.0),
                            sel,
                        )
                    },
                    fade * reveal,
                ),
                label_weight: if expressive {
                    large.weight
                } else {
                    Weight(if k == p.selected {
                        on.label_text.weight as u16
                    } else {
                        off.label_text.weight as u16
                    })
                },
                layer,
                press,
                ring,
                indicator: if disabled { 0.0 } else { sel },
            });
        }
        Self {
            id: p.id,
            items,
            selected: p.selected,
            variant: p.variant,
            expand,
            // The declared width is always the target; the engine walks the layout to it.
            // 声明的宽度恒为目标；布局由引擎走过去。
            width: if expressive {
                if expanded { EXP_EXPANDED } else { EXP_COLLAPSED }
            } else {
                base.container.width
            },
            indicator_w: base.active_indicator.width,
            indicator_h: base.active_indicator.height,
            indicator_ink: spec_ink(pack, base.active_indicator.color, 1.0),
            icon_size: base.icon.size,
            label_size: if expressive {
                lerp(medium.size, large.size, expand)
            } else {
                base.label_text.size
            },
            label_h: if expressive {
                lerp(EXP_LABEL_LH.0, EXP_LABEL_LH.1, expand)
            } else {
                base.label_text.line_height
            },
            container: role(pack, base.container.color),
            disabled,
        }
    }

    /// The rail's own width, so a caller can reserve a column for it.
    /// 轨道自身宽度，供调用方预留一列。
    pub fn width(&self) -> f32 {
        self.width
    }

    /// The rail's own height: its destinations stacked inside the content margin. Only the
    /// width travels, so the height is the same at both ends of the Expressive pair.
    /// 轨道自身高度：内容边距内各目标堆叠之和。只有宽度会走，Expressive 两端的高度因此相同。
    pub fn height(&self) -> f32 {
        if matches!(self.variant, RailVariant::Expressive { .. }) {
            let n = self.items.len() as f32;
            return EXP_TOP + n * EXP_ITEM_H + (n - 1.0).max(0.0) * EXP_ITEM_GAP;
        }
        RAIL_MARGIN * 2.0 + self.items.iter().map(|i| i.height).sum::<f32>()
    }

    /// Which destination a point in the rail's own space belongs to.
    /// 轨道内某个点属于哪个目标。
    pub fn item_at(&self, local: Point, height: f32) -> Option<usize> {
        if local.y < 0.0 || local.y > height {
            return None;
        }
        if matches!(self.variant, RailVariant::Expressive { .. }) {
            let y = local.y - EXP_TOP;
            if y < 0.0 {
                return None;
            }
            let stride = EXP_ITEM_H + EXP_ITEM_GAP;
            let k = (y / stride) as usize;
            // The gap between two destinations belongs to neither.
            // 两个目标之间的间隙不属于任何一方。
            return (k < self.items.len() && y - k as f32 * stride < EXP_ITEM_H).then_some(k);
        }
        // The margin is part of the rail's box but not of any destination's band.
        // 边距属于轨道的盒子，却不属于任何目标的条带。
        let y = local.y - RAIL_MARGIN;
        if y < 0.0 {
            return None;
        }
        let mut top = 0.0;
        for (k, item) in self.items.iter().enumerate() {
            if y < top + item.height {
                return Some(k);
            }
            top += item.height;
        }
        None
    }

    /// One destination, in the shape its family stacks: the baseline column or the pill.
    /// 一个目标，按它家族的摆法：基线列，或胶囊。
    fn item_decl(&self, item: &Item) -> Decl {
        match self.variant {
            RailVariant::Classic => self.classic_item_decl(item),
            RailVariant::Expressive { .. } => self.expressive_item_decl(item),
        }
    }

    /// One destination: its state layer and ring, its indicator and centred content.
    /// 一个目标：状态层与焦点环、指示片与居中的内容。
    fn classic_item_decl(&self, item: &Item) -> Decl {
        // A labelled variant stacks the capsule and the label from the top; a bare rail
        // splits the bottom room around the capsule, as Flutter's `none` label type does.
        // 带标签的变体从顶部依次排胶囊与标签；无标签的轨道把底部留白分到胶囊上下，
        // 与 Flutter 的 `none` 标签类型一致。
        let top = if item.labelled {
            0.0
        } else {
            (item.height - self.indicator_h) * 0.5
        };
        let mut content = Decl::container(item.id.with("content"), NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fixed(item.height),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets { left: 0.0, right: 0.0, top, bottom: 0.0 })
            .gap(LABEL_GAP * item.reveal)
            .cross_align(0.0)
            .cross_pos(0.5);
        content = content.child(self.indicator_decl(item));
        if item.labelled {
            // The label's box gives its room back as the label fades, and clips, so a
            // half-open label shows only as much of itself as it has room for.
            // 标签的盒子随淡出一起让出位置，并裁剪；只展开一半时，只露出放得下的部分。
            let label = Text::new(item.id.with("label"), item.label.clone(), self.label_size, item.label_ink)
                .weight(item.label_weight)
                .resolve();
            let slot = Decl::container(item.id.with("label-slot"), NodeKind::Column)
                .size(SizeClass {
                    width: AxisSize::hug(0.0, 0.0),
                    height: AxisSize::fixed(self.label_h * item.reveal),
                    grow_x: Grow::No,
                    grow_y: Grow::No,
                })
                .clip(Clip { x: Overflow::Visible, y: Overflow::Hidden })
                .cross_align(0.0)
                .cross_pos(0.5)
                .child(label);
            content = content.child(slot);
        }
        Decl::container(item.id, NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fixed(self.width),
                height: AxisSize::fixed(item.height),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
            .cursor(if self.disabled { CursorShape::Arrow } else { CursorShape::PointingHand })
            .disabled(self.disabled)
            .press_ink(item.press)
            .child(content)
    }

    /// The capsule (or circle) behind the icon, scaling in on x from the destination's centre.
    /// 图标下的胶囊（或正圆），从目标中心沿 x 轴展开。
    fn indicator_decl(&self, item: &Item) -> Decl {
        // Hover, focus and selection all paint inside the icon's capsule, not across the
        // whole destination: the capsule is the destination's effective background.
        // 悬停、聚焦与选中都画在图标胶囊内，而不是横跨整个目标：胶囊才是目标的有效背景。
        let background = Background::stadium(self.indicator_w, self.indicator_h);
        let w = self.indicator_w * item.indicator;
        let mut shapes = Vec::with_capacity(3);
        if w > 0.0 {
            shapes.push(Shape::Rect {
                rect: Rect::new((self.indicator_w - w) * 0.5, 0.0, w, self.indicator_h),
                corners: Corners::all(w.min(self.indicator_h) * 0.5),
                // The capsule fades in with its width, so selection is a dissolve rather than
                // a hairline of full-strength colour appearing at once.
                // 胶囊随宽度一起淡入，选中因此是溶解，而不是突然冒出一条满色细线。
                fill: Color { a: self.indicator_ink.a * item.indicator, ..self.indicator_ink },
                gradient: None,
                border: None,
            });
        }
        if let Some(layer) = item.layer {
            shapes.push(background.fill(layer));
        }
        if item.ring > 0.0 {
            let ring = Color { a: self.indicator_ink.a * item.ring, ..self.indicator_ink };
            // MD3's focus indicator is 3dp (the bar's token says so); the rail exports none.
            // MD3 的焦点指示是 3dp（导航栏的令牌如此）；轨道导出里没有。
            shapes.push(background.ring(ring, 3.0));
        }
        Decl::container(item.id.with("indicator"), NodeKind::Column)
            .size(SizeClass::fixed(self.indicator_w, self.indicator_h))
            // The slot exists even when the capsule has not opened, so the ripple has a
            // capsule to be cut to and an unselected destination still shows one.
            // 即使胶囊尚未展开，槽位也存在，涟漪因此有胶囊可裁，未选中的目标也能看到水花。
            .corners(Corners::all(self.indicator_h * 0.5))
            .padding(Insets {
                left: 0.0,
                right: 0.0,
                top: ((self.indicator_h - ui_widgets::icon_extent(self.icon_size)) * 0.5).max(0.0),
                bottom: 0.0,
            })
            .cross_align(0.0)
            .cross_pos(0.5)
            .shapes(shapes)
            .child(self.icon_decl(item))
    }

    /// The icon with the `FILL` axis driving its selection state; a `Custom` source ignores it.
    /// 图标按 `FILL` 轴驱动选中态；`Custom` 源忽略它。
    fn icon_decl(&self, item: &Item) -> Decl {
        let filled = item.icon.fill(item.indicator);
        filled.resolve_with_size(item.id.with("icon"), item.icon_ink, self.icon_size)
    }

    /// An Expressive destination: one row whose pill spans the rail less its inset. The inset
    /// travels 20 → 16 so the pill's left edge lands on the token's full-width leading space.
    /// Expressive 目标：一行，胶囊横跨轨道减去内缩。内缩从 20 走到 16，
    /// 胶囊左缘因此落在令牌的全宽前空上。
    fn expressive_item_decl(&self, item: &Item) -> Decl {
        let inset = lerp((EXP_COLLAPSED - EXP_PILL_W) * 0.5, EXP_INSET, self.expand);
        Decl::container(item.id, NodeKind::Row)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fixed(item.height),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets { left: inset, right: inset, top: 0.0, bottom: 0.0 })
            .cross_align(0.0)
            .cross_pos(0.5)
            .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
            .cursor(if self.disabled { CursorShape::Arrow } else { CursorShape::PointingHand })
            .disabled(self.disabled)
            .press_ink(item.press)
            .child(self.expressive_pill_decl(item))
    }

    /// The pill: icon and label in one row, clipped to its own stadium. Collapsed it is exactly
    /// the icon plus its 16dp padding; expanding, the label leaves through the clip.
    /// 胶囊：图标与标签同一行，裁到自身胶囊形。收起时恰好是图标加两侧 16dp；
    /// 展开时标签从裁剪边缘露出来。
    fn expressive_pill_decl(&self, item: &Item) -> Decl {
        let h = lerp(EXP_PILL_H.0, EXP_PILL_H.1, self.expand);
        let corners = Corners::all(h * 0.5);
        let mut shapes = Vec::with_capacity(3);
        if item.indicator > 0.0 {
            shapes.push(pill_box(corners, faded(self.indicator_ink, item.indicator), None));
        }
        if let Some(layer) = item.layer {
            shapes.push(pill_box(corners, layer, None));
        }
        if item.ring > 0.0 {
            let ring = Color { a: self.indicator_ink.a * item.ring, ..self.indicator_ink };
            shapes.push(pill_box(corners, Color::TRANSPARENT, Some((ring, 3.0))));
        }
        // A fixed label box keeps the text from re-wrapping as the pill opens; the pill's own
        // clip hides whatever has not been revealed yet.
        // 固定宽度的标签盒使文字在胶囊张开时不重新换行；尚未露出的部分由胶囊自身裁掉。
        let label = Text::new(item.id.with("label"), item.label.clone(), self.label_size, item.label_ink)
            .weight(item.label_weight)
            .max_lines(1)
            .resolve();
        let slot = Decl::container(item.id.with("label-slot"), NodeKind::Row)
            .size(SizeClass {
                width: AxisSize::fixed(EXP_LABEL_W),
                height: AxisSize::fixed(self.label_h),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .cross_align(0.0)
            .cross_pos(0.5)
            .child(label);
        Decl::container(item.id.with("indicator"), NodeKind::Row)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fixed(h),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .corners(corners)
            .padding(Insets { left: EXP_INSET, right: EXP_INSET, top: 0.0, bottom: 0.0 })
            .gap(EXP_GAP)
            .cross_align(0.0)
            .cross_pos(0.5)
            .clip(Clip { x: Overflow::Hidden, y: Overflow::Hidden })
            .shapes(shapes)
            .child(self.icon_decl(item))
            .child(slot)
    }
}

/// A destination's height at a label presence of `reveal`: the capsule, the label's room in
/// proportion, and the bottom spacing.
/// 标签呈现度为 `reveal` 时目标的高度：胶囊、按比例给出的标签位置，以及底部间距。
fn destination_height(indicator_h: f32, label_h: f32, reveal: f32) -> f32 {
    indicator_h + (LABEL_GAP + label_h) * reveal + BOTTOM_GAP
}

/// A node-sized rounded box: the Expressive pill follows whatever rect layout gives it, so its
/// fill, state layer and ring need no width of their own.
/// 跟随布局矩形的圆角盒子：Expressive 胶囊跟着布局给它的矩形走，
/// 填充、状态层与焦点环因此不必自己算宽度。
fn pill_box(corners: Corners, fill: Color, border: Option<(Color, f32)>) -> Shape {
    Shape::Box { corners, fill, gradient: None, border, shadow: None, image: None }
}

impl Widget for Md3NavRail {
    fn handles_disabled(&self) -> bool {
        // The 38% content fade is painted here, so the adapter must not fade again.
        // 38% 的内容淡化在这里绘制，适配器不得再淡化一次。
        true
    }

    fn change(&self, state: &WidgetState, bounds: ui_core::geom::Rect) -> Option<ui_core::Change> {
        // The press point names the destination; the keyboard has none (engine-audit F12).
        // 按下点指名目的地；键盘没有按下点（engine-audit F12）。
        if self.disabled || !state.clicked {
            return None;
        }
        let k = self.item_at(state.local?, bounds.size.h)?;
        // Re-selecting the destination already selected is not a change.
        // 重复选中当前目标不算变化。
        (k != self.selected).then(|| ui_core::Change::Selected(Some(self.items[k].id)))
    }

    fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
        let expressive = matches!(self.variant, RailVariant::Expressive { .. });
        let mut root = Decl::container(self.id, NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fixed(self.width),
                height: AxisSize::fixed(self.height()),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets {
                left: 0.0,
                top: if expressive { EXP_TOP } else { RAIL_MARGIN },
                right: 0.0,
                bottom: if expressive { 0.0 } else { RAIL_MARGIN },
            })
            .gap(if expressive { EXP_ITEM_GAP } else { 0.0 })
            // The Expressive destinations fill the column so they track its interpolated
            // width; the baseline ones are already as wide as the rail.
            // Expressive 的目标填满整列，因此跟着插值后的宽度走；基线的目标本就与轨道同宽。
            .cross_align(if expressive { 1.0 } else { 0.0 })
            .cross_pos(0.5)
            .shapes(vec![boxed(self.container, None)]);
        if expressive {
            // The app keeps declaring the target; the engine walks the width there before
            // layout, so the destinations reflow on the way instead of jumping at the end.
            // 应用照旧声明目标；引擎在布局前把宽度走过去，目标因此一路重排而不是最后跳一下。
            root = root.transition_size(EXPAND);
        }
        for item in &self.items {
            root = root.child(self.item_decl(item));
        }
        root
    }
}
