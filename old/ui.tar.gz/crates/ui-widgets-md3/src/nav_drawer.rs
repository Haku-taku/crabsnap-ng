//! MD3 standard navigation drawer: a 360dp surface, 336×56 destination capsules inset 12dp,
//! and `title-small` headlines that group them.
//! MD3 标准导航抽屉：360dp 表面、内缩 12dp 的 336×56 目标胶囊，以及分组用的
//! `title-small` 标题。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Insets, Point, Rect};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::{
    AnimSpec, CursorShape, Decl, Easing, Id, InkRadius, NodeKind, PieceCubic, PressInk, Sense,
    Weight,
};
use ui_style::Style;
use ui_widgets::build::param;
use ui_widgets::text::Text;
use ui_widgets::{Cx, IconSource, Widget, WidgetState};

use crate::layer::Background;
use crate::nav_bar::faded;
use crate::spec::navigation_drawer_spec;
use crate::toggle::{between, role, spec_ink};
use crate::Md3Options;

/// Flutter's `Curves.easeInOutCubicEmphasized`, the destination's indicator curve.
/// Flutter 的 `Curves.easeInOutCubicEmphasized`，目标指示片的曲线。
static EMPHASIZED: PieceCubic = PieceCubic {
    a1: (0.05, 0.0),
    b1: (0.133333, 0.06),
    mid: (0.166666, 0.4),
    a2: (0.208333, 0.82),
    b2: (0.25, 1.0),
};
/// `NavigationDrawer` destination animation: the indicator's 500ms scale-in.
/// `NavigationDrawer` 的目标动画：指示片 500ms 的展开。
const SELECT: AnimSpec = AnimSpec::new(0.5, Easing::Piece(&EMPHASIZED));
/// `kRadialReactionDuration`: the hover and focus layers.
/// `kRadialReactionDuration`：悬停与聚焦的状态层。
const REACTION: AnimSpec = AnimSpec::new(0.1, Easing::Linear);
/// `tilePadding: EdgeInsets.symmetric(horizontal: 12)`, which leaves the 336dp capsule.
/// `tilePadding: EdgeInsets.symmetric(horizontal: 12)`，留下的正是 336dp 胶囊。
const TILE_INSET: f32 = 12.0;
/// The destination's own leading inset inside the capsule, from Flutter's destination row.
/// 目标在胶囊内的前置内缩，取自 Flutter 的目标行。
const TILE_LEADING: f32 = 16.0;
/// `SizedBox(width: 12)` between the mark and the label.
/// 标记与标签之间的 `SizedBox(width: 12)`。
const ICON_GAP: f32 = 12.0;
/// The export carries only the headline's type style; this row's vertical rhythm is ours.
/// 导出只给标题的字级；这一行的上下留白由本仓库决定。
const HEADLINE_PAD: (f32, f32) = (16.0, 8.0);

/// One drawer entry: a group headline or a destination.
/// 一个抽屉条目：分组标题或目标。
pub enum DrawerEntry<'a> {
    /// A `title-small` group label.
    /// `title-small` 分组标签。
    Headline(&'a str),
    /// A destination; the app owns the id it is selected by.
    /// 一个目标；选中时上报的 id 归应用所有。
    Item(DrawerItem<'a>),
}

/// One destination: its id, label and optional 24dp mark.
/// 一个目标：id、标签，以及可选的 24dp 标记。
pub struct DrawerItem<'a> {
    pub id: Id,
    pub label: &'a str,
    /// Built at the destination's icon id in the ink the current state resolves to.
    /// 按当前状态解析出的墨色在目标的图标 id 处构建。
    pub icon: Option<IconSource>,
}

impl<'a> DrawerItem<'a> {
    /// A destination with a mark and a label.
    /// 带标记与标签的目标。
    pub fn new(id: Id, label: &'a str, icon: IconSource) -> Self {
        Self { id, label, icon: Some(icon) }
    }

    /// A text-only destination.
    /// 纯文字目标。
    pub fn text(id: Id, label: &'a str) -> Self {
        Self { id, label, icon: None }
    }
}

/// Everything a standard drawer needs besides the design system's own tokens.
/// 标准抽屉除设计系统令牌之外所需的一切。
pub struct DrawerParams<'a> {
    pub id: Id,
    pub entries: &'a [DrawerEntry<'a>],
    /// The selected destination's id; the app owns it.
    /// 选中目标的 id；归应用所有。
    pub selected: Option<Id>,
    pub disabled: bool,
}

/// One destination's resolved paint data.
/// 一个目标解析后的绘制数据。
struct Row {
    id: Id,
    label: String,
    icon: Option<IconSource>,
    icon_ink: Color,
    label_ink: Color,
    label_weight: Weight,
    layer: Option<Color>,
    press: Option<PressInk>,
    ring: f32,
    indicator: f32,
}

/// One headline's resolved paint data.
/// 一个标题解析后的绘制数据。
struct Headline {
    id: Id,
    text: String,
    ink: Color,
}

/// A slot in visual order: the layout and the hit test walk the same list.
/// 视觉顺序上的一个槽位：布局与命中共用同一张表。
enum Slot {
    Headline(Headline),
    Row(Row),
}

/// A standard navigation drawer; the app owns which destination is selected.
/// 标准导航抽屉；选中项归应用所有。
pub struct Md3NavDrawer {
    id: Id,
    slots: Vec<Slot>,
    selected: Option<Id>,
    content_h: f32,        // total content height for scroll bounds
    width: f32,
    capsule_w: f32,
    capsule_h: f32,
    indicator_ink: Color,
    label_size: f32,
    headline_size: f32,
    headline_h: f32,
    headline_weight: Weight,
    container: Color,
    ring_colour: Color,
    ring_width: f32,
    disabled: bool,
}

impl Md3NavDrawer {
    /// Same control with explicit parameters, so the semantic path and a direct caller
    /// produce identical `Decl`s.
    /// 带显式参数的同一控件，使语义路径与直接调用产出相同的 `Decl`。
    pub fn new_with(
        params: Md3Options,
        p: DrawerParams<'_>,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let base = navigation_drawer_spec(false, false, true, false, false, false);
        let disabled = params.disabled || cx.state(p.id).disabled;
        let fade = if disabled { crate::DISABLED_CONTENT_OPACITY } else { 1.0 };
        let layer_ink = role(pack, navigation_drawer_spec(false, false, true, true, false, false).state_layer.color);
        let hover_a = navigation_drawer_spec(false, false, true, true, false, false).state_layer.opacity;
        let focus_a = navigation_drawer_spec(false, false, true, false, true, false).state_layer.opacity;
        let press_a = navigation_drawer_spec(false, false, true, false, false, true).state_layer.opacity;
        // The capsule slot every row shares: state layer, selection and ripple all use it.
        // 每一行共用的胶囊槽位：状态层、选中与涟漪都用它。
        let background = Background::stadium(base.active_indicator.width, base.active_indicator.height);
        let mut slots = Vec::new();
        for (k, entry) in p.entries.iter().enumerate() {
            match entry {
                DrawerEntry::Headline(text) => slots.push(Slot::Headline(Headline {
                    id: p.id.with(("headline", k)),
                    text: text.to_string(),
                    ink: spec_ink(pack, base.headline.color, 1.0),
                })),
                DrawerEntry::Item(item) => {
                    let item_id = item.id;
                    let mut node = cx.at(item_id);
                    let state = node.state();
                    let on = navigation_drawer_spec(true, false, true, state.hovered, state.focus_visible, state.pressed);
                    let off = navigation_drawer_spec(false, false, true, state.hovered, state.focus_visible, state.pressed);
                    let sel = node.animate(
                        item_id.with(param::PROGRESS),
                        f32::from(p.selected == Some(item_id)),
                        SELECT,
                    );
                    let hover = node.animate(item_id.with(param::HOVER), f32::from(state.hovered), REACTION);
                    let focus = node.animate(item_id.with(param::FOCUS), f32::from(state.focus_visible), REACTION);
                    let alpha = (hover * hover_a).max(focus * focus_a);
                    let layer = (alpha > 0.0 && !disabled)
                        .then_some(Color { a: layer_ink.a * alpha, ..layer_ink });
                    // The ripple belongs to the capsule, not the whole row, and it is cut to
                    // the capsule's fixed slot: an unselected row still has one.
                    // 涟漪属于胶囊而不是整行，并被裁到胶囊的固定槽位：未选中的行同样有槽位。
                    let press = (!disabled).then(|| {
                        background.press(
                            Color { a: layer_ink.a * press_a, ..layer_ink },
                            InkRadius::Cover,
                        )
                    });
                    let ring = if disabled {
                        0.0
                    } else {
                        node.animate(item_id.with(param::THICKNESS), f32::from(state.focus_visible), REACTION)
                    };
                    slots.push(Slot::Row(Row {
                        id: item_id,
                        label: item.label.to_string(),
                        icon: item.icon,
                        icon_ink: faded(
                            between(
                                spec_ink(pack, off.icon.color, 1.0),
                                spec_ink(pack, on.icon.color, 1.0),
                                sel,
                            ),
                            fade,
                        ),
                        label_ink: faded(
                            between(
                                spec_ink(pack, off.label_text.color, 1.0),
                                spec_ink(pack, on.label_text.color, 1.0),
                                sel,
                            ),
                            fade,
                        ),
                        label_weight: Weight(if p.selected == Some(item_id) {
                            on.label_text.weight as u16
                        } else {
                            off.label_text.weight as u16
                        }),
                        layer,
                        press,
                        ring,
                        indicator: if disabled { 0.0 } else { sel },
                    }));
                }
            }
        }
        let capsule_h = base.active_indicator.height;
        let headline_row_h = base.headline.line_height + HEADLINE_PAD.0 + HEADLINE_PAD.1;
        let content_h = slots.iter().map(|slot| match slot {
            Slot::Headline(_) => headline_row_h,
            Slot::Row(_) => capsule_h,
        }).sum();
        Self {
            id: p.id,
            slots,
            selected: p.selected,
            content_h,
            width: base.container.width,
            capsule_w: base.active_indicator.width,
            capsule_h,
            indicator_ink: spec_ink(pack, base.active_indicator.color, 1.0),
            label_size: base.label_text.size,
            headline_size: base.headline.size,
            headline_h: base.headline.line_height,
            headline_weight: Weight(base.headline.weight as u16),
            container: role(pack, base.container.color),
            ring_colour: spec_ink(pack, base.focus_indicator.color, 1.0),
            ring_width: base.focus_indicator.thickness,
            disabled,
        }
    }

    /// Total content height, for the app's scroll-boundary clamp.
    /// 内容总高，供应用做滚动边界夹取。
    pub fn content_h(&self) -> f32 {
        self.content_h
    }

    /// The drawer's own width, so a caller can reserve a column for it.
    /// 抽屉自身宽度，供调用方预留一列。
    pub fn width(&self) -> f32 {
        self.width
    }

    /// Which destination a point in the drawer's own space names, walking the visual order.
    ///
    /// `local_y` must already be shifted by the scroll offset: the widget does not apply its own scroll transform.
    /// `height` is the laid-out visible column; the scroller clips below it, so nothing below must hit.
    ///
    /// 按视觉顺序指认哪个目标：
    /// - `local_y` 必须已经减去滚动偏移；控件不会再做自身的滚动变换。
    /// - `height` 是布局后的可见列高；滚动容器裁掉它之下的内容，故其下不命中。
    ///
    /// 如果传入未减的坐标，命中会整体向上偏移。
    pub fn row_at(&self, local: Point, width: f32, height: f32) -> Option<Id> {
        // Above the column the scroller may expose content scrolled in; below it, the next
        // slot is the one already clipped away. Both must miss.
        // 视口上方可能是滚进来的内容；视口下方是已被裁掉的下一格。两者都不命中。
        if width <= 0.0 || local.y < 0.0 || local.y >= height {
            return None;
        }
        let mut top = TILE_INSET;
        for slot in &self.slots {
            let h = match slot {
                Slot::Headline(_) => self.headline_row_h(),
                Slot::Row(_) => self.capsule_h,
            };
            if local.y >= top && local.y < top + h {
                return match slot {
                    Slot::Row(row) => Some(row.id),
                    Slot::Headline(_) => None,
                };
            }
            top += h;
        }
        None
    }

    /// A headline's whole row: its line plus the vertical rhythm above and below.
    /// 标题整行：文字行加上下的留白。
    fn headline_row_h(&self) -> f32 {
        self.headline_h + HEADLINE_PAD.0 + HEADLINE_PAD.1
    }

    /// One destination: its capsule, state layer, ring, mark and label.
    /// 一个目标：胶囊、状态层、焦点环、标记与标签。
    fn row_decl(&self, row: &Row) -> Decl {
        let w = self.capsule_w * row.indicator;
        let mut shapes = Vec::with_capacity(3);
        // Always first, so `Shape(0)` names the capsule whatever else is showing, and the
        // capsule fades in with its width instead of appearing at full strength.
        // 永远在第一位，使 `Shape(0)` 无论还画了什么都是胶囊；胶囊随宽度一起淡入，
        // 而不是直接以满色出现。
        shapes.push(Shape::Rect {
            rect: Rect::new((self.capsule_w - w) * 0.5, 0.0, w, self.capsule_h),
            corners: Corners::all(w.min(self.capsule_h) * 0.5),
            fill: Color { a: self.indicator_ink.a * row.indicator, ..self.indicator_ink },
            gradient: None,
            border: None,
        });
        // The hover and focus layers follow the capsule, not the row's rectangle: a square
        // wash around a stadium reads as a different control.
        // 悬停与聚焦层跟随胶囊而不是行的矩形：胶囊周围的方形底色看起来像另一个控件。
        let background = Background::stadium(self.capsule_w, self.capsule_h);
        if let Some(layer) = row.layer {
            shapes.push(background.fill(layer));
        }
        if row.ring > 0.0 {
            let ring = Color { a: self.ring_colour.a * row.ring, ..self.ring_colour };
            shapes.push(background.ring(ring, self.ring_width));
        }
        let mut node = Decl::container(row.id, NodeKind::Row)
            .size(SizeClass::fixed(self.capsule_w, self.capsule_h))
            .padding(Insets {
                left: TILE_LEADING,
                right: TILE_LEADING,
                top: 0.0,
                bottom: 0.0,
            })
            .gap(ICON_GAP)
            .cross_align(0.0)
            .cross_pos(0.5)
            .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
            .cursor(if self.disabled { CursorShape::Arrow } else { CursorShape::PointingHand })
            .disabled(self.disabled)
            .press_ink(row.press)
            .shapes(shapes);
        if let Some(source) = row.icon {
            node = node.child(source.resolve(row.id.with("icon"), row.icon_ink));
        }
        node.child(
            Text::new(row.id.with("label"), row.label.clone(), self.label_size, row.label_ink)
                .weight(row.label_weight)
                .resolve(),
        )
    }

    /// A group headline: full width, inset so it lines up with the capsules' labels.
    /// 分组标题：整宽，内缩到与胶囊里的标签对齐。
    fn headline_decl(&self, h: &Headline) -> Decl {
        Decl::container(h.id, NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fixed(self.headline_row_h()),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets {
                left: TILE_INSET + TILE_LEADING,
                right: 0.0,
                top: HEADLINE_PAD.0,
                bottom: HEADLINE_PAD.1,
            })
            .cross_align(0.0)
            .cross_pos(0.0)
            .child(
                Text::new(h.id.with("text"), h.text.clone(), self.headline_size, h.ink)
                    .weight(self.headline_weight)
                    .resolve(),
            )
    }
}

impl Widget for Md3NavDrawer {
    fn handles_disabled(&self) -> bool {
        // The 38% content fade is painted here, so the adapter must not fade again.
        // 38% 的内容淡化在这里绘制，适配器不得再淡化一次。
        true
    }

    fn change(&self, state: &WidgetState, bounds: ui_core::geom::Rect) -> Option<ui_core::Change> {
        // The press point names the destination; the keyboard has none (engine-audit F12).
        // 按下点指名目的地；键盘没有按下点（engine-audit F12）。
        if self.disabled || !state.clicked {
            return None;
        }
        let id = self.row_at(state.local?, bounds.size.w, bounds.size.h)?;
        // Re-selecting the destination already selected is not a change.
        // 重复选中当前目标不算变化。
        (self.selected != Some(id)).then(|| ui_core::Change::Selected(Some(id)))
    }

    fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
        let mut root = Decl::container(self.id, NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fixed(self.width),
                height: AxisSize::fill(0.0, 0.0),
                grow_x: Grow::No,
                grow_y: Grow::Yes,
            })
            .padding(Insets { left: 0.0, right: 0.0, top: TILE_INSET, bottom: 0.0 })
            .cross_align(0.0)
            .cross_pos(0.5)
            .shapes(vec![Shape::Box {
                // `corner.large.end`: the drawer rounds its trailing edge by 16dp.
                // `corner.large.end`：抽屉把尾侧边缘做成 16dp 圆角。
                corners: Corners { tl: 0.0, tr: 16.0, br: 16.0, bl: 0.0, ..Corners::ZERO },
                fill: self.container,
                gradient: None,
                border: None,
                shadow: None,
                image: None,
            }]);
        for slot in &self.slots {
            root = match slot {
                Slot::Headline(h) => root.child(self.headline_decl(h)),
                Slot::Row(row) => root.child(self.row_decl(row)),
            };
        }
        root
    }
}
