//! MD3 navigation bar: equal destinations on an 80dp surface, a 64×32 capsule behind the
//! selected icon, and labels the app can always show, never show, or show only when selected.
//! MD3 导航栏：80dp 表面上的等宽目标，选中图标下压一颗 64×32 胶囊，标签由应用决定
//! 常显、常隐或仅选中时显示。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Insets, Point, Rect};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::{
    AnimSpec, CursorShape, Decl, Easing, Id, InkRadius, NodeKind, PieceCubic, PressInk, Sense,
    Weight,
};
use ui_style::Style;
use ui_widgets::build::param;
use ui_widgets::text::Text;
use ui_widgets::{Cx, IconSource, Widget, WidgetState};

use crate::layer::{press_ink_in, Background};
use crate::spec::navigation_bar_spec;
use crate::toggle::{between, role, spec_ink};
use crate::Md3Options;

/// Flutter's `Curves.easeInOutCubicEmphasized`: two cubics sharing (0.1667, 0.4).
/// Flutter 的 `Curves.easeInOutCubicEmphasized`：两段三次曲线在 (0.1667, 0.4) 相接。
static EMPHASIZED: PieceCubic = PieceCubic {
    a1: (0.05, 0.0),
    b1: (0.133333, 0.06),
    mid: (0.166666, 0.4),
    a2: (0.208333, 0.82),
    b2: (0.25, 1.0),
};
/// `NavigationBar.animationDuration`: the indicator's 500ms scale-in.
/// `NavigationBar.animationDuration`：指示片 500ms 的展开。
const SELECT: AnimSpec = AnimSpec::new(0.5, Easing::Piece(&EMPHASIZED));
/// `kRadialReactionDuration`: the hover and focus layers.
/// `kRadialReactionDuration`：悬停与聚焦的状态层。
const REACTION: AnimSpec = AnimSpec::new(0.1, Easing::Linear);
/// `labelPadding: EdgeInsets.only(top: 4)`; the export carries no icon-label gap.
/// `labelPadding: EdgeInsets.only(top: 4)`；导出没有图标与标签的间距。
const LABEL_GAP: f32 = 4.0;

/// Whether the bar shows the labels of its destinations.
/// 导航栏是否显示各目标的标签。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum NavLabelBehavior {
    /// Every destination carries its label.
    /// 每个目标都带标签。
    #[default]
    AlwaysShow,
    /// No destination carries a label; only the icons remain.
    /// 所有目标都不带标签，只留图标。
    AlwaysHide,
    /// Only the selected destination carries a label.
    /// 只有选中的目标带标签。
    OnlyShowSelected,
}

/// One destination: the id the app knows it by, its label and its 24dp mark.
/// 一个目标：应用认识它的 id、标签，以及一个 24dp 标记。
pub struct Md3NavItem<'a> {
    /// Owned by the app, so a reported `Change::Selected` names something it can map back.
    /// 归应用所有，使上报的 `Change::Selected` 指向它认得出的东西。
    pub id: Id,
    pub label: &'a str,
    /// The icon slot: a source the bar resolves at the destination's icon id, in the ink and
    /// `FILL` axis the current state resolves to. A `Custom` source keeps the slot open to
    /// anything the app can paint.
    /// 图标槽位：一个源，由栏在目标图标 id 处、按当前状态解析出的墨色与 `FILL` 轴解析。
    /// `Custom` 源让槽位对应用能画的任何东西开放。
    pub icon: IconSource,
}

impl<'a> Md3NavItem<'a> {
    /// A destination with an icon and a label.
    /// 带图标与标签的目标。
    pub fn new(id: Id, label: &'a str, icon: IconSource) -> Self {
        Self { id, label, icon }
    }
}

/// Everything a navigation bar needs besides the design system's own tokens.
/// 除设计系统令牌之外，导航栏所需的一切。
pub struct NavBarParams<'a> {
    pub id: Id,
    pub items: &'a [Md3NavItem<'a>],
    /// The selected destination's index; the app owns it, as with tabs.
    /// 选中目标的序号；与页签一样归应用所有。
    pub selected: usize,
    pub label_behavior: NavLabelBehavior,
    pub disabled: bool,
}

/// One destination's resolved paint data.
/// 一个目标解析后的绘制数据。
struct Item {
    id: Id,
    label: String,
    icon: IconSource,
    /// Whether the label's slot exists in the layout, whatever the label's alpha is.
    /// 布局里是否留出标签的位置，与标签当前的透明度无关。
    show_label: bool,
    /// Whether the label fades with the selection instead of always being drawn.
    /// 标签是否随选中淡入淡出，而不是恒常绘制。
    fade_label: bool,
    /// The selection progress, `0..=1`, which slides the content between the labelled and
    /// the bare position.
    /// 选中进度 `0..=1`，让内容在带标签与不带标签两种位置之间滑动。
    progress: f32,
    icon_ink: Color,
    label_ink: Color,
    label_weight: Weight,
    /// The state layer over the whole destination, already carrying its animated alpha.
    /// 覆盖整个目标的状态层，已带上动画后的透明度。
    layer: Option<Color>,
    /// The press ink the engine splats at the pointer.
    /// 引擎在指针处泼出的按压墨迹。
    press: Option<PressInk>,
    /// The keyboard focus ring's alpha; 0 when it is not showing.
    /// 键盘焦点环的透明度；不显示时为 0。
    ring: f32,
    /// The indicator's scale on x, `0..=1`.
    /// 指示片在 x 轴上的展开度，`0..=1`。
    indicator: f32,
}

/// A navigation bar; the app owns which destination is selected.
/// 导航栏；选中项归应用所有。
pub struct Md3NavBar {
    id: Id,
    items: Vec<Item>,
    selected: usize,
    height: f32,
    indicator_w: f32,
    indicator_h: f32,
    indicator_ink: Color,
    icon_size: f32,
    label_size: f32,
    label_h: f32,
    container: Color,
    ring_colour: Color,
    ring_width: f32,
    disabled: bool,
}

impl Md3NavBar {
    /// Same control with explicit parameters, so the semantic path and a direct caller
    /// produce identical `Decl`s.
    /// 带显式参数的同一控件，使语义路径与直接调用产出相同的 `Decl`。
    pub fn new_with(
        params: Md3Options,
        p: NavBarParams<'_>,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let base = navigation_bar_spec(false, false, false, false);
        let disabled = params.disabled || cx.state(p.id).disabled;
        // The export defines no disabled inks; MD3's rule for disabled content is 38%.
        // 导出没有禁用配色；MD3 对禁用内容的规定是 38%。
        let fade = if disabled { crate::DISABLED_CONTENT_OPACITY } else { 1.0 };
        // The state layer's ink only exists under hover/focus/pressed in the export.
        // 状态层的颜色在导出里只挂在悬停/聚焦/按下上。
        let layer_ink = role(pack, navigation_bar_spec(false, true, false, false).state_layer.color);
        let hover_a = navigation_bar_spec(false, true, false, false).state_layer.opacity;
        let focus_a = navigation_bar_spec(false, false, true, false).state_layer.opacity;
        let press_a = navigation_bar_spec(false, false, false, true).state_layer.opacity;
        let mut items = Vec::with_capacity(p.items.len());
        for (k, item) in p.items.iter().enumerate() {
            let item_id = item.id;
            let mut node = cx.at(item_id);
            let state = node.state();
            // The inks follow the destination's own state, as Flutter's destination theme does.
            // 墨色跟随目标自身的状态，与 Flutter 的目标主题一致。
            let on = navigation_bar_spec(true, state.hovered, state.focus_visible, state.pressed);
            let off = navigation_bar_spec(false, state.hovered, state.focus_visible, state.pressed);
            let sel = node.animate(item_id.with(param::PROGRESS), f32::from(k == p.selected), SELECT);
            let hover = node.animate(item_id.with(param::HOVER), f32::from(state.hovered), REACTION);
            let focus = node.animate(item_id.with(param::FOCUS), f32::from(state.focus_visible), REACTION);
            let alpha = (hover * hover_a).max(focus * focus_a);
            let layer = (alpha > 0.0 && !disabled)
                .then_some(Color { a: layer_ink.a * alpha, ..layer_ink });
            let press = (!disabled).then(|| {
                // The ripple covers the icon's capsule, not the whole destination: the
                // indicator is the effective background (Flutter `_IndicatorInkWell`).
                // 墨迹盖住图标的胶囊，而不是整个目标：指示片才是有效背景
                // （Flutter `_IndicatorInkWell`）。
                press_ink_in(
                    Color { a: layer_ink.a * press_a, ..layer_ink },
                    InkRadius::Cover,
                    item_id.with("indicator"),
                )
            });
            let ring = if disabled {
                0.0
            } else {
                node.animate(item_id.with(param::THICKNESS), f32::from(state.focus_visible), REACTION)
            };
            // The slot and the fade are separate: only the selected-only bar reserves the
            // label's room on every destination, so a selection change moves the content
            // instead of resizing it.
            // 槽位与淡入是两回事：只有「仅选中」栏会给每个目标都留出标签的位置，
            // 选中变化因此移动内容，而不是改变尺寸。
            let (show_label, fade_label) = match p.label_behavior {
                NavLabelBehavior::AlwaysShow => (true, false),
                NavLabelBehavior::AlwaysHide => (false, false),
                NavLabelBehavior::OnlyShowSelected => (true, true),
            };
            let label_fade = if fade_label { sel } else { 1.0 };
            items.push(Item {
                id: item_id,
                label: item.label.to_string(),
                icon: item.icon,
                show_label,
                fade_label,
                progress: sel,
                icon_ink: faded(
                    between(
                        spec_ink(pack, off.icon.color, 1.0),
                        spec_ink(pack, on.icon.color, 1.0),
                        sel,
                    ),
                    fade,
                ),
                label_ink: faded(
                    between(
                        spec_ink(pack, off.label_text.color, 1.0),
                        spec_ink(pack, on.label_text.color, 1.0),
                        sel,
                    ),
                    fade * label_fade,
                ),
                label_weight: Weight(if k == p.selected {
                    on.label_text.weight as u16
                } else {
                    off.label_text.weight as u16
                }),
                layer,
                press,
                ring,
                indicator: if disabled { 0.0 } else { sel },
            });
        }
        Self {
            id: p.id,
            items,
            selected: p.selected,
            height: base.container.height,
            indicator_w: base.active_indicator.width,
            indicator_h: base.active_indicator.height,
            indicator_ink: spec_ink(pack, base.active_indicator.color, 1.0),
            icon_size: base.icon.size,
            label_size: base.label_text.size,
            label_h: base.label_text.line_height,
            container: role(pack, base.container.color),
            ring_colour: spec_ink(pack, base.focus_indicator.color, 1.0),
            ring_width: base.focus_indicator.thickness,
            disabled,
        }
    }

    /// The bar's own height, so a caller can reserve room for it.
    /// 导航栏自身高度，供调用方预留空间。
    pub fn height(&self) -> f32 {
        self.height
    }

    /// Which destination a point in the bar's own space belongs to.
    /// 栏内某个点属于哪个目标。
    pub fn item_at(&self, local: Point, width: f32) -> Option<usize> {
        if self.items.is_empty() || local.y < 0.0 || local.y > self.height || width <= 0.0 {
            return None;
        }
        let share = width / self.items.len() as f32;
        Some(((local.x / share).floor().max(0.0) as usize).min(self.items.len() - 1))
    }

    /// The content block's height: the indicator, and the label when it shows.
    /// 内容块的高度：指示片，以及显示时的标签。
    fn content_h(&self, show_label: bool) -> f32 {
        if show_label {
            self.indicator_h + LABEL_GAP + self.label_h
        } else {
            self.indicator_h
        }
    }

    /// One destination: its state layer and focus ring, its indicator and centred content.
    /// 一个目标：状态层与焦点环、指示片与居中的内容。
    fn item_decl(&self, item: &Item) -> Decl {
        let content_h = self.content_h(item.show_label);
        // A selected-only destination holds the labelled position and the bare one at once and
        // moves between them with the selection: the icons glide, nothing resizes.
        // 「仅选中」的目标同时持有带标签与不带标签两个位置，随选中在两者间移动：
        // 图标平滑滑动，没有任何尺寸变化。
        let labelled = ((self.height - content_h) * 0.5).max(0.0);
        let bare = ((self.height - self.indicator_h) * 0.5).max(0.0);
        let top = if item.fade_label { bare + (labelled - bare) * item.progress } else { labelled };
        let mut content = Decl::container(item.id.with("content"), NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fixed(content_h),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .gap(if item.show_label { LABEL_GAP } else { 0.0 })
            // Children hug their own width and are centred in the space they leave.
            // 子节点按自身宽度并居中于它们让出的空间。
            .cross_align(0.0)
            .cross_pos(0.5);
        content = content.child(self.indicator_decl(item));
        if item.show_label {
            let label = Text::new(item.id.with("label"), item.label.clone(), self.label_size, item.label_ink)
                .weight(item.label_weight)
                .resolve();
            content = content.child(label);
        }
        Decl::container(item.id, NodeKind::Column)
            .size(SizeClass {
                // Equal shares: a zero basis splits the bar evenly whatever the labels are.
                // 等分：零基准把栏平均切开，与标签长短无关。
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fixed(self.height),
                grow_x: Grow::Split(1),
                grow_y: Grow::No,
            })
            .padding(Insets {
                left: 0.0,
                right: 0.0,
                top,
                bottom: 0.0,
            })
            .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
            .cursor(if self.disabled { CursorShape::Arrow } else { CursorShape::PointingHand })
            .disabled(self.disabled)
            .press_ink(item.press)
            .child(content)
    }

    /// The capsule behind the icon: Flutter scales it in on x from the destination's centre.
    /// 图标下压的胶囊：Flutter 让它从目标中心沿 x 轴展开。
    /// The icon with the `FILL` axis driving its selection state; a `Custom` source ignores it.
    /// 图标按 `FILL` 轴驱动选中态；`Custom` 源忽略它。
    fn icon_decl(&self, item: &Item) -> Decl {
        let filled = item.icon.fill(item.indicator);
        filled.resolve_with_size(item.id.with("icon"), item.icon_ink, self.icon_size)
    }

    fn indicator_decl(&self, item: &Item) -> Decl {
        // Hover, focus and selection all paint inside the icon's capsule, not across the
        // whole destination: the capsule is the destination's effective background.
        // 悬停、聚焦与选中都画在图标胶囊内，而不是横跨整个目标：胶囊才是目标的有效背景。
        let background = Background::stadium(self.indicator_w, self.indicator_h);
        let w = self.indicator_w * item.indicator;
        let mut shapes = Vec::with_capacity(3);
        if w > 0.0 {
            shapes.push(Shape::Rect {
                rect: Rect::new((self.indicator_w - w) * 0.5, 0.0, w, self.indicator_h),
                corners: Corners::all(w.min(self.indicator_h) * 0.5),
                // The capsule fades in with its width, so selection is a dissolve rather than
                // a hairline of full-strength colour appearing at once.
                // 胶囊随宽度一起淡入，选中因此是溶解，而不是突然冒出一条满色细线。
                fill: Color { a: self.indicator_ink.a * item.indicator, ..self.indicator_ink },
                gradient: None,
                border: None,
            });
        }
        if let Some(layer) = item.layer {
            shapes.push(background.fill(layer));
        }
        if item.ring > 0.0 {
            let ring = Color { a: self.ring_colour.a * item.ring, ..self.ring_colour };
            shapes.push(background.ring(ring, self.ring_width));
        }
        Decl::container(item.id.with("indicator"), NodeKind::Column)
            .size(SizeClass::fixed(self.indicator_w, self.indicator_h))
            // The slot exists even when the capsule has not opened, so the ripple has a
            // capsule to be cut to and an unselected destination still shows one.
            // 即使胶囊尚未展开，槽位也存在，涟漪因此有胶囊可裁，未选中的目标也能看到水花。
            .corners(Corners::all(self.indicator_h * 0.5))
            .padding(Insets {
                left: 0.0,
                right: 0.0,
                top: ((self.indicator_h - ui_widgets::icon_extent(self.icon_size)) * 0.5).max(0.0),
                bottom: 0.0,
            })
            .cross_align(0.0)
            .cross_pos(0.5)
            .shapes(shapes)
            .child(self.icon_decl(item))
    }
}

impl Widget for Md3NavBar {
    fn handles_disabled(&self) -> bool {
        // The 38% content fade is painted here, so the adapter must not fade again.
        // 38% 的内容淡化在这里绘制，适配器不得再淡化一次。
        true
    }

    fn change(&self, state: &WidgetState, bounds: ui_core::geom::Rect) -> Option<ui_core::Change> {
        // The press point names the destination; the keyboard has none (engine-audit F12).
        // 按下点指名目的地；键盘没有按下点（engine-audit F12）。
        if self.disabled || !state.clicked {
            return None;
        }
        // Destinations are equal shares of the bar, so the press point names one directly.
        // 目标等分栏宽，因此按下点无需查表就能指出是哪一个。
        let k = self.item_at(state.local?, bounds.size.w)?;
        // Re-selecting the destination already selected is not a change.
        // 重复选中当前目标不算变化。
        (k != self.selected).then(|| ui_core::Change::Selected(Some(self.items[k].id)))
    }

    fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
        let mut root = Decl::container(self.id, NodeKind::Row)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fixed(self.height),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .shapes(vec![boxed(self.container, None)]);
        for item in &self.items {
            root = root.child(self.item_decl(item));
        }
        root
    }
}

/// Multiply a colour's alpha, so a disabled bar fades its inks once.
/// 乘上颜色的 alpha，使禁用的栏只淡化一次。
pub(crate) fn faded(c: Color, k: f32) -> Color {
    Color { a: c.a * k, ..c }
}

/// A node-sized box: it follows whatever rect the layout hands the node.
/// 节点大小的盒子：跟随布局给节点的矩形。
pub(crate) fn boxed(fill: Color, border: Option<(Color, f32)>) -> Shape {
    Shape::Box {
        corners: Corners::ZERO,
        fill,
        gradient: None,
        border,
        shadow: None,
        image: None,
    }
}
