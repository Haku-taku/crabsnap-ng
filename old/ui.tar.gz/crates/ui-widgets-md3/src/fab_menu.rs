//! MD3 FAB menu: a column of pill items above the circular close button that replaced the FAB.
//! MD3 FAB 菜单：取代 FAB 的圆形关闭按钮上方，一列胶囊菜单项。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Insets, Rect};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::tree::ShadowSpec;
use ui_core::{AnimSpec, CursorShape, Decl, Easing, Id, InkRadius, NodeKind, NodeData, PressInk, Sense};
use ui_style::Style;
use ui_widgets::build::param;
use ui_widgets::text::Text;
use ui_widgets::{Cx, IconSource, Widget, WidgetState};

use crate::layer::press_ink;
use crate::spec::{fab_menu_spec, FabMenuColor, FabMenuContainer, FabMenuSpec};
use crate::toggle::{role, spec_ink};
use crate::typescale::{self, TypeStyle};
use crate::Md3Options;

/// MD3's `emphasizedDecelerate` in spirit: the items arrive fast and settle.
/// 大意是 MD3 的 `emphasizedDecelerate`：菜单项快速到位后收住。
const OPEN: AnimSpec = AnimSpec::new(0.15, Easing::EaseOut);
/// `kRadialReactionDuration`: the state layer's fade.
/// `kRadialReactionDuration`：状态层的淡入时长。
const REACTION: AnimSpec = AnimSpec::new(0.1, Easing::Linear);

/// The FAB's colour role, which decides both the close button's fill and the items' container.
/// FAB 的颜色角色，同时决定关闭按钮的填充与菜单项的容器色。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FabMenuColour {
    Primary,
    Secondary,
    Tertiary,
}

impl FabMenuColour {
    fn close(self) -> FabMenuColor {
        match self {
            Self::Primary => FabMenuColor::Primary,
            Self::Secondary => FabMenuColor::Secondary,
            Self::Tertiary => FabMenuColor::Tertiary,
        }
    }

    /// The items take the `-container` form of the same role.
    /// 菜单项取同一角色的 `-container` 形式。
    fn items(self) -> FabMenuContainer {
        match self {
            Self::Primary => FabMenuContainer::PrimaryContainer,
            Self::Secondary => FabMenuContainer::SecondaryContainer,
            Self::Tertiary => FabMenuContainer::TertiaryContainer,
        }
    }

    /// Resolve this tone for one interaction state.
    /// 为一个交互状态解析该色调。
    fn spec(self, hovered: bool, focused: bool, pressed: bool) -> FabMenuSpec {
        fab_menu_spec(hovered, focused, pressed, self.close(), self.items())
    }
}

/// One menu entry: the id the app knows it by, its label, and its mark.
/// 一个菜单项：应用认识它的 id、标签与标记。
pub struct Md3FabMenuItem<'a> {
    pub id: Id,
    pub label: &'a str,
    /// The mark at `id`, in the item's own ink and `FILL` axis.
    /// `id` 处的标记，按菜单项自身墨色与 `FILL` 轴。
    pub icon: IconSource,
}

/// One resolved menu entry.
/// 一个解析后的菜单项。
struct Item {
    id: Id,
    label: String,
    icon: (IconSource, Color),
    container: Color,
    layer: Option<Color>,
    /// The press ink the engine splats at the pointer.
    /// 引擎在指针处泼出的按压墨迹。
    press: Option<PressInk>,
    shadow: Option<ShadowSpec>,
    label_ink: Color,
}

/// The metrics every item shares, resolved once from the export.
/// 所有菜单项共用的度量，从导出解析一次。
struct Metrics {
    item_h: f32,
    item_gap: f32,
    close_gap: f32,
    close_w: f32,
    close_h: f32,
    close_icon: f32,
    icon: f32,
    icon_label: f32,
    leading: f32,
    trailing: f32,
    label: TypeStyle,
}

impl Metrics {
    fn of(spec: &FabMenuSpec) -> Self {
        Self {
            item_h: spec.menu_item_container.height,
            item_gap: spec.menu_item.between_space,
            close_gap: spec.close_button.between_space,
            close_w: spec.close_button_container.width,
            close_h: spec.close_button_container.height,
            close_icon: spec.close_button_icon.size,
            icon: spec.menu_item_icon.size,
            icon_label: spec.menu_item.icon_label_space,
            leading: spec.menu_item.leading_space,
            trailing: spec.menu_item.trailing_space,
            label: typescale::named(spec.menu_item.label_text),
        }
    }
}

/// The close button's resolved paint data.
/// 关闭按钮解析后的绘制数据。
struct Close {
    container: Color,
    icon_ink: Color,
    layer: Option<Color>,
    /// The press ink the engine splats at the pointer.
    /// 引擎在指针处泼出的按压墨迹。
    press: Option<PressInk>,
    shadow: Option<ShadowSpec>,
}

/// A FAB menu; the tone and `open` belong to the app.
/// FAB 菜单；色调与 `open` 归应用所有。
pub struct Md3FabMenu {
    id: Id,
    items: Vec<Item>,
    close: Close,
    metrics: Metrics,
    close_icon: IconSource,
    /// How far the items have arrived, 0..=1.
    /// 菜单项到位的程度，0..=1。
    open: f32,
    open_target: bool,
    disabled: bool,
}

/// The two interaction strengths the export gives one shape, as animated alphas. A press is
/// a splat from the pointer, so it is not one of them.
/// 导出给同一个形状的两档交互强度，作为动画后的 alpha。按下自指针泼出，不在此列。
fn layer_of(
    pack: &Style,
    hover: f32,
    focus: f32,
    hover_opacity: f32,
    focus_opacity: f32,
    ink: &'static str,
    disabled: bool,
) -> Option<Color> {
    let strength = (hover * hover_opacity).max(focus * focus_opacity);
    let ink = role(pack, ink);
    (strength > 0.0 && !disabled).then_some(Color { a: ink.a * strength, ..ink })
}

/// The press ink for a shape whose pressed layer is `ink` at `opacity`.
/// 某形状的按压墨迹，其按下状态层为 `ink`、透明度 `opacity`。
fn ink_of(pack: &Style, ink: &'static str, opacity: f32, disabled: bool) -> Option<PressInk> {
    if disabled {
        return None;
    }
    let ink = role(pack, ink);
    Some(press_ink(Color { a: ink.a * opacity, ..ink }, InkRadius::Cover))
}

impl Md3FabMenu {
    /// Build one menu. The close button is the anchor: it is drawn even while closed.
    /// 构建一个菜单。关闭按钮是锚点：即使收起也照画。
    #[allow(clippy::too_many_arguments)]
    pub fn new_with(
        params: Md3Options,
        id: Id,
        items: &[Md3FabMenuItem<'_>],
        tone: FabMenuColour,
        open: bool,
        close_icon: IconSource,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let disabled = params.disabled || cx.state(id).disabled;
        let rest = tone.spec(false, false, false);
        let metrics = Metrics::of(&rest);
        let fade = if disabled { crate::DISABLED_CONTENT_OPACITY } else { 1.0 };
        // The layer's ink is the same under hover/focus/press; only its strength differs.
        // 状态层的墨色在悬停/聚焦/按下三者相同，只有强度不同。
        let hover_spec = tone.spec(true, false, false);
        let focus_spec = tone.spec(false, true, false);
        let press_spec = tone.spec(false, false, true);
        let mut resolved = Vec::with_capacity(items.len());
        for item in items {
            let mut node = cx.at(item.id);
            let state = node.state();
            let hover = node.animate(item.id.with(param::HOVER), f32::from(state.hovered), REACTION);
            let focus = node.animate(item.id.with(param::FOCUS), f32::from(state.focus_visible), REACTION);
            let on = tone.spec(state.hovered, state.focus_visible, state.pressed);
            let layer = layer_of(
                pack, hover, focus,
                hover_spec.list_item_state_layer.opacity,
                focus_spec.list_item_state_layer.opacity,
                hover_spec.list_item_state_layer.color,
                disabled,
            );
            let ink = ink_of(
                pack,
                press_spec.list_item_state_layer.color,
                press_spec.list_item_state_layer.opacity,
                disabled,
            );
            resolved.push(Item {
                id: item.id,
                label: item.label.to_string(),
                icon: (item.icon, faded(spec_ink(pack, on.list_item_icon.color, 1.0), fade)),
                container: container_of(pack, on.list_item_container.color, disabled),
                layer,
                press: ink,
                shadow: shadow_of(on.list_item_container.elevation),
                label_ink: faded(spec_ink(pack, on.list_item_label_text.color, 1.0), fade),
            });
        }
        let close_id = id.with("close");
        let mut node = cx.at(close_id);
        let state = node.state();
        let hover = node.animate(close_id.with(param::HOVER), f32::from(state.hovered), REACTION);
        let focus = node.animate(close_id.with(param::FOCUS), f32::from(state.focus_visible), REACTION);
        let on = tone.spec(state.hovered, state.focus_visible, state.pressed);
        let layer = layer_of(
            pack, hover, focus,
            hover_spec.close_button_state_layer.opacity,
            focus_spec.close_button_state_layer.opacity,
            hover_spec.close_button_state_layer.color,
            disabled,
        );
        let ink = ink_of(
            pack,
            press_spec.close_button_state_layer.color,
            press_spec.close_button_state_layer.opacity,
            disabled,
        );
        let close = Close {
            container: container_of(pack, on.close_button_container.color, disabled),
            icon_ink: faded(spec_ink(pack, on.close_button_icon.color, 1.0), fade),
            layer,
            press: ink,
            shadow: shadow_of(on.close_button_container.elevation),
        };
        let mut root = cx.at(id);
        let open_t = root.animate(id.with(param::PROGRESS), f32::from(open), OPEN);
        Self { id, items: resolved, close, metrics, close_icon, open: open_t, open_target: open, disabled }
    }

    /// The mark's size from the export, so the caller builds the glyph at the right size.
    /// 标记尺寸取自导出，调用方据此构建字形。
    pub fn icon_size(&self) -> f32 {
        self.metrics.icon
    }

    /// The anchor's own diameter: the FAB slot this menu replaced.
    /// 锚点自身的直径：本菜单取代的 FAB 位置。
    pub fn anchor_size(&self) -> f32 {
        self.metrics.close_w
    }

    /// The control's own height: every item, the gaps, and the close button.
    /// 控件自身高度：全部菜单项、间隙与关闭按钮。
    pub fn height(&self) -> f32 {
        let n = self.items.len() as f32;
        if n == 0.0 {
            return self.metrics.close_h;
        }
        n * self.metrics.item_h + (n - 1.0) * self.metrics.item_gap + self.metrics.close_gap
            + self.metrics.close_h
    }

    /// Where each row starts, top to bottom: items first, the close button last.
    /// 每一行的起始 y，自上而下：先是菜单项，最后是关闭按钮。
    fn rows(&self) -> Vec<f32> {
        let m = &self.metrics;
        let mut ys = Vec::with_capacity(self.items.len() + 1);
        let mut y = 0.0;
        for _ in &self.items {
            ys.push(y);
            y += m.item_h + m.item_gap;
        }
        // The last item is followed by `close_gap`, not another `item_gap`.
        // 最后一项后面跟的是 `close_gap`，不是又一个 `item_gap`。
        y = y - m.item_gap + m.close_gap;
        ys.push(y);
        ys
    }

    /// How far item `k` has slid toward the anchor: the rows keep their slots so the anchor
    /// never moves, and the items themselves travel into it as the menu collapses.
    /// 菜单项 `k` 滑向锚点的距离：行槽位不变所以锚点不动，收起的位移由菜单项自己走。
    fn slide(&self, k: usize) -> f32 {
        let m = &self.metrics;
        let below = (self.items.len() - 1 - k) as f32 * (m.item_h + m.item_gap);
        (1.0 - self.open) * (m.close_gap + below + m.item_h)
    }

    /// One item's node: its container, its state layer, then the mark and the label.
    /// 一个菜单项的节点：容器、状态层，然后是标记与标签。
    fn item_decl(&self, item: &Item) -> Decl {
        let m = &self.metrics;
        let mut shapes = Vec::with_capacity(2);
        let mut b = self.boxed(item.container, m.item_h);
        if let Shape::Box { shadow, .. } = &mut b {
            *shadow = item.shadow;
        }
        shapes.push(b);
        if let Some(layer) = item.layer {
            shapes.push(self.boxed(layer, m.item_h));
        }
        Decl::container(item.id, NodeKind::Row)
            .size(SizeClass {
                width: AxisSize::hug(0.0, 0.0),
                height: AxisSize::fixed(m.item_h),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets { left: m.leading, right: m.trailing, top: 0.0, bottom: 0.0 })
            .gap(m.icon_label)
            .cross_align(0.0)
            .cross_pos(0.5)
            .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
            .cursor(if self.disabled { CursorShape::Arrow } else { CursorShape::PointingHand })
            .disabled(self.disabled)
            .press_ink(item.press)
            .shapes(shapes)
            .child(item.icon.0.resolve_with_size(item.id.with("icon"), item.icon.1, m.icon))
            .child(
                Text::new(item.id.with("label"), item.label.clone(), m.label.size, item.label_ink)
                    .weight(m.label.weight)
                    .resolve(),
            )
    }

    /// The close button: a circle with the mark centred in it.
    /// 关闭按钮：一个圆，标记居中。
    fn close_decl(&self) -> Decl {
        let m = &self.metrics;
        let mut shapes = Vec::with_capacity(2);
        let mut b = self.boxed(self.close.container, m.close_h);
        if let Shape::Box { shadow, .. } = &mut b {
            *shadow = self.close.shadow;
        }
        shapes.push(b);
        if let Some(layer) = self.close.layer {
            shapes.push(self.boxed(layer, m.close_h));
        }
        let side = ((m.close_w - m.close_icon) * 0.5).max(0.0);
        Decl::container(self.id.with("close"), NodeKind::Row)
            .size(SizeClass::fixed(m.close_w, m.close_h))
            // Equal side padding puts the mark on the circle's centre line; the vertical
            // centring is the cross axis's job.
            // 两侧等量内衬把标记放到圆的中心线上；纵向居中由交叉轴负责。
            .padding(Insets { left: side, right: side, top: 0.0, bottom: 0.0 })
            .cross_align(0.0)
            .cross_pos(0.5)
            .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
            .cursor(if self.disabled { CursorShape::Arrow } else { CursorShape::PointingHand })
            .disabled(self.disabled)
            .press_ink(self.close.press)
            .shapes(shapes)
            .child(self.close_icon.resolve_with_size(
                self.id.with("close").with("icon"),
                self.close.icon_ink,
                m.close_icon,
            ))
    }

    /// A zero-basis grower that holds the anchor on the bottom edge while the items are away.
    /// 零基准增长者：菜单项不在时把锚点留在底边。
    fn grower(&self) -> Decl {
        Decl::container(self.id.with("fill"), NodeKind::Column).size(SizeClass {
            width: AxisSize::hug(0.0, 0.0),
            height: AxisSize::hug(0.0, 0.0),
            grow_x: Grow::No,
            grow_y: Grow::Yes,
        })
    }

    /// An invisible node that reserves one gap; `k` keeps its id unique among siblings.
    /// 一个只占间隙的不可见节点；`k` 让它的 id 在同级中唯一。
    fn spacer(&self, k: usize, height: f32) -> Decl {
        Decl::container(self.id.with(("gap", k)), NodeKind::Column).size(SizeClass {
            width: AxisSize::fixed(0.0),
            height: AxisSize::fixed(height),
            grow_x: Grow::No,
            grow_y: Grow::No,
        })
    }

    /// A node-sized box rounded by half its height: MD3's `circular` shape.
    /// 节点大小的盒子，圆角取高度的一半：MD3 的 `circular` 形状。
    fn boxed(&self, fill: Color, height: f32) -> Shape {        Shape::Box {
            corners: Corners::all(height * 0.5),
            fill,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }
    }
}

impl Widget for Md3FabMenu {
    fn handles_disabled(&self) -> bool {
        // The 38% content fade is painted here, so the adapter must not fade again.
        // 38% 的内容淡化在这里绘制，适配器不得再淡化一次。
        true
    }

    fn change(&self, state: &WidgetState, bounds: Rect) -> Option<ui_core::Change> {
        if self.disabled || !state.activation() || bounds.size.w <= 0.0 {
            return None;
        }
        // The keyboard has no press point, so the anchor is the only target it can name.
        // 键盘没有按下点，因此它唯一能指名的目标是锚点。
        let Some(local) = state.local else {
            return Some(ui_core::Change::Activated);
        };
        let ys = self.rows();
        // A closed menu draws no items and they sit on the anchor's row, so they must not be
        // tested at all: otherwise the press that opens the menu names an invisible item.
        // 收起的菜单不画菜单项，而它们正好落在锚点那一行上；因此完全不测它们，
        // 否则「打开菜单」的那一按会指向一个看不见的项。
        if self.open_target {
            for (k, item) in self.items.iter().enumerate() {
                // Rows travel while the menu collapses, so the press point follows the slide.
                // 收起时行在移动，因此按下点要跟着滑动量走。
                let top = ys[k] + self.slide(k);
                if local.y >= top && local.y < top + self.metrics.item_h {
                    return Some(ui_core::Change::Selected(Some(item.id)));
                }
            }
        }
        let close_y = *ys.last()?;
        (local.y >= close_y && local.y < close_y + self.metrics.close_h)
            .then_some(ui_core::Change::Activated)
    }

    fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
        let mut column = Decl::container(self.id, NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::hug(0.0, 0.0),
                height: AxisSize::fixed(self.height()),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            // Items are wider than the close button; MD3 lines them up on the trailing edge.
            // 菜单项比关闭按钮宽；MD3 让它们的尾部对齐。
            .cross_align(0.0)
            .cross_pos(1.0)
            // Two different gaps, so spacing is explicit spacers rather than one column gap.
            // 有两种间隙，因此用显式占位节点而不是列的单一间隙。
            .gap(0.0)
            // Without this the anchor jumps to the top of the reserved box when the items go.
            // 没有它，菜单项一消失锚点就跳到预留区的顶端。
            .child(self.grower());
        // A closed menu draws nothing above the anchor; fading to zero would leave ghost hits.
        // 收起的菜单在锚点上方什么都不画；淡到零会留下幽灵命中区。
        if self.open > 0.001 {
            for (k, item) in self.items.iter().enumerate() {
                if k > 0 {
                    column = column.child(self.spacer(k, self.metrics.item_gap));
                }
                let slid = self.item_decl(item).offset(0.0, self.slide(k));
                column = column.child(faded_decl(slid, self.open));
            }
            column = column.child(self.spacer(self.items.len(), self.metrics.close_gap));
        }
        column.child(self.close_decl())
    }
}

/// Multiply every colour in a declaration by `k`, so a fading item carries its inks along.
/// 把声明里的每种颜色乘以 `k`，使淡出的菜单项连墨色一起淡。
fn faded_decl(mut decl: Decl, k: f32) -> Decl {
    decl.shapes = decl.shapes.into_iter().map(|s| fade_shape(s, k)).collect();
    if let NodeData::Text { ink, .. } = &mut decl.data {
        *ink = faded(*ink, k);
    }
    let children = std::mem::take(&mut decl.children);
    decl.children = children
        .into_iter()
        .map(|c| std::rc::Rc::new(faded_decl((*c).clone(), k)))
        .collect();
    decl
}

fn fade_shape(shape: Shape, k: f32) -> Shape {
    match shape {
        Shape::Box { corners, fill, gradient, border, shadow, image } => Shape::Box {
            corners,
            fill: faded(fill, k),
            gradient,
            border: border.map(|(c, w)| (faded(c, k), w)),
            shadow,
            image,
        },
        Shape::Rect { rect, corners, fill, gradient, border } => Shape::Rect {
            rect,
            corners,
            fill: faded(fill, k),
            gradient,
            border: border.map(|(c, w)| (faded(c, k), w)),
        },
        Shape::Shadow { rect, corners, colour, blur, dy, ring } => {
            Shape::Shadow { rect, corners, colour: faded(colour, k), blur, dy, ring }
        }
        Shape::Outline { corners, colour, gradient, width, gap } => Shape::Outline {
            corners,
            colour: faded(colour, k),
            gradient: gradient.map(|g| ui_core::draw::Gradient {
                from: faded(g.from, k),
                to: faded(g.to, k),
                ..g
            }),
            width,
            gap,
        },
        Shape::Sector {
            centre,
            radius,
            thickness,
            trim,
            round_caps,
            colour,
        } => Shape::Sector {
            centre,
            radius,
            thickness,
            trim,
            round_caps,
            colour: faded(colour, k),
        },
    }
}

/// Multiply a colour's alpha, so a disabled or fading control dims its inks once.
/// 乘上颜色的 alpha，使禁用或淡出的控件只淡化一次。
fn faded(c: Color, k: f32) -> Color {
    Color { a: c.a * k, ..c }
}

/// The export names no disabled inks; MD3's rule is `on-surface` at 12%.
/// 导出没有禁用配色；MD3 的规定是 `on-surface` 取 12%。
fn container_of(pack: &Style, token: &'static str, disabled: bool) -> Color {
    if disabled {
        Color { a: crate::DISABLED_CONTAINER_OPACITY, ..role(pack, "onSurface") }
    } else {
        spec_ink(pack, token, 1.0)
    }
}

/// MD3's elevation as the one analytic shadow the engine has.
/// 把 MD3 的立面写成引擎唯一支持的解析阴影。
fn shadow_of(elevation: f32) -> Option<ShadowSpec> {
    (elevation > 0.0).then(|| ShadowSpec::black(elevation * 2.0, 0.18, elevation * 0.5))
}
