//! MD3 snackbar: an inverse-surface bar with body-medium text and an optional label-large
//! action, fading in and out with the engine's goal-driven animation.
//! MD3 提示条：`inverse-surface` 的条，body-medium 正文与可选的 label-large 动作，
//! 靠引擎的目标驱动动画淡入淡出。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Insets};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::tree::ShadowSpec;
use ui_core::{AnimSpec, CursorShape, Decl, Easing, Id, InkRadius, NodeKind, Sense};
use ui_style::Style;
use ui_widgets::build::param;
use ui_widgets::text::Text;
use ui_widgets::{Cx, Widget, WidgetState};

use crate::layer::press_ink;
use crate::spec::snackbar_spec;
use crate::toggle::spec_ink;
use crate::Md3Options;

/// MD3's `corner.extra-small`, which the export names `rounded_corners` without a number.
/// MD3 的 `corner.extra-small`；导出只写 `rounded_corners`，没给数值。
const CORNER: f32 = 4.0;
/// Flutter's `padding`: 24 fixed, 16 floating.
/// Flutter 的 `padding`：固定式 24，浮动式 16。
const SIDE_FIXED: f32 = 24.0;
const SIDE_FLOATING: f32 = 16.0;
/// The action's touch target; it overhangs the bar's 14dp padding, which is visible-safe.
/// 动作的触控区；它溢出条的 14dp 内衬，而溢出是可见的。
const ACTION_H: f32 = 48.0;
/// material-web's enter: 150ms on `cubic-bezier(0, 0, 0.2, 1)`.
/// material-web 的入场：150ms、`cubic-bezier(0, 0, 0.2, 1)`。
const ENTER: AnimSpec = AnimSpec::new(0.15, Easing::Cubic(0.0, 0.0, 0.2, 1.0));
/// `kRadialReactionDuration`: the action's hover and focus layers.
/// `kRadialReactionDuration`：动作的悬停与聚焦状态层。
const REACTION: AnimSpec = AnimSpec::new(0.1, Easing::Linear);

/// Everything a snackbar needs besides the design system's own tokens.
/// 提示条除设计系统令牌之外所需的一切。
pub struct SnackbarParams<'a> {
    pub id: Id,
    pub message: &'a str,
    /// The action's label; a snackbar with an action must not auto-dismiss (the app owns that).
    /// 动作的标签；带动作的提示条不应自动消失（由应用负责）。
    pub action: Option<&'a str>,
    /// Two lines of body text instead of one, which is the export's 68dp branch.
    /// 正文两行而非一行，即导出的 68dp 分支。
    pub two_lines: bool,
    /// Floating snackbars inset their text by 16dp instead of 24.
    /// 浮动式提示条的正文内缩是 16dp 而不是 24。
    pub floating: bool,
    /// The export carries no width token; the app gives one.
    /// 导出没有宽度令牌；宽度由应用给。
    pub width: f32,
    /// Whether it is showing; the control fades between the two states.
    /// 是否显示；控件在两种状态之间淡变。
    pub visible: bool,
    /// Float over the page bottom instead of taking a slot in the flow; the app lays it
    /// out as the last child of a full-size container. `None` centres the bar; `Some(24)`
    /// also insets it from the bottom edge.
    /// 浮在页面底部而非占流内位置；应用把它作为全尺寸容器的最后一个子节点摆放。
    /// `None` 让条水平居中；`Some(24)` 再距底部 24dp。
    pub overlay: Option<f32>,
}

/// A snackbar; the app owns when it shows and whether it auto-dismisses.
/// 提示条；何时显示、是否自动消失归应用所有。
pub struct Md3Snackbar {
    id: Id,
    message: String,
    action: Option<String>,
    height: f32,
    side: f32,
    width: f32,
    /// The fade, `0..=1`; nothing is painted at 0.
    /// 淡变，`0..=1`；为 0 时不画任何东西。
    alpha: f32,
    container: Color,
    text_ink: Color,
    action_ink: Color,
    layer_ink: Color,
    hover_a: f32,
    focus_a: f32,
    press_a: f32,
    shadow: Option<ShadowSpec>,
    text_size: f32,
    text_weight: ui_core::Weight,
    action_size: f32,
    action_weight: ui_core::Weight,
    two_lines: bool,
    /// The action's own hover/focus, read from its node.
    /// 动作自身的悬停/聚焦，从其节点读取。
    action_hover: f32,
    action_focus: f32,
    action_ring: f32,
    /// The bottom inset when floating over the page; `None` keeps the bar in the flow.
    /// 浮在页面底部时的下内缩；`None` 表示条在流内。
    overlay: Option<f32>,
}

impl Md3Snackbar {
    /// Same control with explicit parameters, so the semantic path and a direct caller
    /// produce identical `Decl`s.
    /// 带显式参数的同一控件，使语义路径与直接调用产出相同的 `Decl`。
    pub fn new_with(
        _params: Md3Options,
        p: SnackbarParams<'_>,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let has_action = p.action.is_some();
        let base = snackbar_spec(false, !p.two_lines, p.two_lines, false, false, false);
        let hover = snackbar_spec(false, !p.two_lines, p.two_lines, true, false, false);
        let focus = snackbar_spec(false, !p.two_lines, p.two_lines, false, true, false);
        let press = snackbar_spec(false, !p.two_lines, p.two_lines, false, false, true);
        let fade = cx.at(p.id).animate(p.id.with(param::PROGRESS), f32::from(p.visible), ENTER);
        let action_id = p.id.with("action");
        let (action_hover, action_focus, action_ring) = if has_action {
            let mut node = cx.at(action_id);
            let state = node.state();
            (
                node.animate(action_id.with(param::HOVER), f32::from(state.hovered), REACTION),
                node.animate(action_id.with(param::FOCUS), f32::from(state.focus_visible), REACTION),
                node.animate(action_id.with(param::THICKNESS), f32::from(state.focus_visible), REACTION),
            )
        } else {
            (0.0, 0.0, 0.0)
        };
        let elevation = base.container.elevation;
        Self {
            id: p.id,
            message: p.message.to_string(),
            action: p.action.map(str::to_string),
            height: base.container.height,
            side: if p.floating { SIDE_FLOATING } else { SIDE_FIXED },
            width: p.width,
            alpha: fade,
            container: spec_ink(pack, base.container.color, 1.0),
            text_ink: spec_ink(pack, base.supporting_text.color, 1.0),
            action_ink: spec_ink(pack, base.action_label_text.color, 1.0),
            layer_ink: spec_ink(pack, hover.action_state_layer.color, 1.0),
            hover_a: hover.action_state_layer.opacity,
            focus_a: focus.action_state_layer.opacity,
            press_a: press.action_state_layer.opacity,
            shadow: (elevation > 0.0)
                .then(|| ShadowSpec::black(elevation * 2.0, 0.18, elevation * 0.5)),
            text_size: base.supporting_text.size,
            text_weight: ui_core::Weight(base.supporting_text.weight as u16),
            action_size: base.action_label_text.size,
            action_weight: ui_core::Weight(base.action_label_text.weight as u16),
            two_lines: p.two_lines,
            action_hover,
            action_focus,
            action_ring,
            overlay: p.overlay,
        }
    }

    /// The bar's own height, so a caller can reserve room for it.
    /// 提示条自身高度，供调用方预留空间。
    pub fn height(&self) -> f32 {
        self.height
    }

    /// Fade a colour by the bar's own progress.
    /// 按提示条自身的进度淡化颜色。
    fn faded(&self, c: Color) -> Color {
        Color { a: c.a * self.alpha, ..c }
    }
}

impl Widget for Md3Snackbar {
    fn change(&self, state: &WidgetState, _bounds: ui_core::geom::Rect) -> Option<ui_core::Change> {
        // Only the action carries a click sense, so a click inside the bar is the action's —
        // the message area stays inert and cannot swallow a press meant for the page.
        // 只有动作带点击语义，因此条内的点击就是动作的——正文区保持惰性，
        // 不会吞掉本该给页面的按下。
        (state.activation() && self.alpha > 0.0 && self.action.is_some())
            .then_some(ui_core::Change::Activated)
    }

    fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
        // A fully faded bar paints nothing, so the app can keep it mounted across the exit.
        // 完全淡出的条什么都不画，应用因此可以在退场期间让它留在树里。
        let mut empty = Decl::container(self.id, NodeKind::Row).size(SizeClass::fixed(self.width, self.height));
        if let Some(bottom) = self.overlay {
            // Out of flow, pinned to the page bottom and horizontally centred by the auto sides.
            // 移出流，钉在页面底部，左右 auto 让它水平居中。
            empty = empty.fixed().inset(Insets { bottom, ..Insets::AUTO });
        }
        if self.alpha <= 0.0 {
            return empty;
        }
        let mut root = Decl::container(self.id, NodeKind::Row)
            .size(SizeClass::fixed(self.width, self.height))
            .padding(Insets {
                left: self.side,
                right: self.side,
                top: 0.0,
                bottom: 0.0,
            })
            .gap(12.0)
            // The message and the action both centre on the bar's full height; padding the
            // content box vertically would squeeze the 48dp action out of a 20dp box.
            // 消息与动作都在条的全高上居中；给内容盒加纵向内衬会把 48dp 的动作
            // 从 20dp 的盒子里挤出去。
            .cross_align(0.0)
            .cross_pos(0.5)
            .shapes(vec![Shape::Box {
                corners: Corners::all(CORNER),
                fill: self.faded(self.container),
                gradient: None,
                border: None,
                shadow: self.shadow,
                image: None,
            }]);
        if let Some(bottom) = self.overlay {
            root = root.fixed().inset(Insets { bottom, ..Insets::AUTO });
        }
        let mut message = Text::new(
            self.id.with("message"),
            self.message.clone(),
            self.text_size,
            self.faded(self.text_ink),
        )
        .weight(self.text_weight);
        if !self.two_lines {
            message = message.nowrap();
        }
        let mut message_decl = message.resolve();
        // The message takes the room the action leaves, and no more.
        // 正文占据动作让出的空间，不多占。
        message_decl.size_class.width = AxisSize::hug(0.0, 0.0);
        message_decl.size_class.grow_x = Grow::Yes;
        root = root.child(message_decl);
        if let Some(label) = &self.action {
            let action_id = self.id.with("action");
            let layer = self.action_hover * self.hover_a;
            let focus = self.action_focus * self.focus_a;
            let alpha = layer.max(focus);
            let mut shapes = Vec::with_capacity(2);
            if alpha > 0.0 {
                shapes.push(Shape::Box {
                    corners: Corners::all(ACTION_H * 0.5),
                    fill: Color { a: self.layer_ink.a * alpha * self.alpha, ..self.layer_ink },
                    gradient: None,
                    border: None,
                    shadow: None,
                    image: None,
                });
            }
            if self.action_ring > 0.0 {
                // The snackbar exports no focus ring; the action borrows its own ink.
                // 提示条没有焦点环令牌；动作借用自身的墨色。
                let ring = Color { a: self.action_ink.a * self.action_ring * self.alpha, ..self.action_ink };
                shapes.push(Shape::Box {
                    corners: Corners::all(ACTION_H * 0.5),
                    fill: Color::TRANSPARENT,
                    gradient: None,
                    border: Some((ring, 3.0)),
                    shadow: None,
                    image: None,
                });
            }
            let text = Text::new(action_id.with("label"), label.clone(), self.action_size, self.faded(self.action_ink))
                .weight(self.action_weight)
                .nowrap()
                .resolve();
            let action = Decl::container(action_id, NodeKind::Row)
                .size(SizeClass {
                    width: AxisSize::hug(0.0, 0.0),
                    height: AxisSize::fixed(ACTION_H),
                    grow_x: Grow::No,
                    grow_y: Grow::No,
                })
                .padding(Insets { left: 12.0, right: 12.0, top: 0.0, bottom: 0.0 })
                .cross_align(0.0)
                .cross_pos(0.5)
                .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
                .cursor(CursorShape::PointingHand)
                .press_ink(Some(press_ink(
                    Color { a: self.layer_ink.a * self.press_a * self.alpha, ..self.layer_ink },
                    InkRadius::Cover,
                )))
                .shapes(shapes)
                .child(text);
            root = root.child(action);
        }
        root
    }
}
