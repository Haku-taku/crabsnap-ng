//! MD3 outlined segmented button: a pill of equal segments that filter a choice.
//! MD3 轮廓分段按钮：一排等宽分段合成一颗胶囊，用来筛选选择。
//!
//! The app owns the selection set; the control only reports which segment was clicked, so
//! it serves single- and multi-select with no mode flag.
//! 选中集合归应用所有；控件只上报点了哪一段，因此不需要模式参数就同时支持单选与多选。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Insets, Point, Rect};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::{AnimSpec, Change, CursorShape, Decl, Easing, Id, InkRadius, NodeKind, Sense, Weight};
use ui_style::Style;
use ui_widgets::build::param;
use ui_widgets::text::Text;
use ui_widgets::{Cx, GroupPosition, IconSource, Widget, WidgetState};

use crate::layer::press_ink;
use crate::spec::outlined_segmented_button_spec;
use crate::toggle::{role, spec_ink};
use crate::Md3Options;

/// `kRadialReactionDuration`: the state layer's fade, and the focus ring's.
/// `kRadialReactionDuration`：状态层与焦点环的淡入时长。
const REACTION: AnimSpec = AnimSpec::new(0.1, Easing::Linear);
/// Inset of one segment's content from its edges, when the neighbour is not there to share it.
/// 分段内容与自身边缘的间距，取邻居不在场分担时的值。
const SEGMENT_PAD: f32 = 16.0;

/// One segment: the id the app knows it by, its label, and an optional 18dp leading mark.
/// 一个分段：应用认识它的 id、标签，以及可选的 18dp 前置标记。
pub struct Md3SegmentItem<'a> {
    pub id: Id,
    pub label: &'a str,
    /// `Some(src)` draws the mark in the segment's own ink before the label.
    /// `Some(src)` 按分段自身的墨色在标签前绘制标记。
    pub icon: Option<IconSource>,
}

impl<'a> Md3SegmentItem<'a> {
    /// A text-only segment.
    /// 纯文字分段。
    pub fn text(id: Id, label: &'a str) -> Self {
        Self { id, label, icon: None }
    }

    /// A segment with a leading mark.
    /// 带前置标记的分段。
    pub fn with_icon(id: Id, label: &'a str, icon: IconSource) -> Self {
        Self { id, label, icon: Some(icon) }
    }
}

/// Everything the caller states about one segmented button.
/// 调用方对一个分段按钮声明的全部信息。
pub struct SegmentedParams<'a> {
    pub id: Id,
    pub items: Vec<Md3SegmentItem<'a>>,
    /// Selected segments, in any order. Single-select is the app replacing it; multi is toggling.
    /// 已选分段，次序任意。单选是应用替换它，多选是翻转。
    pub selected: Vec<Id>,
    pub disabled: bool,
}

/// One segment's resolved paint data.
/// 一个分段解析后的绘制数据。
struct Segment {
    id: Id,
    label: String,
    label_ink: Color,
    icon: Option<(IconSource, Color)>,
    corners: Corners,
    /// The selected fill; `None` when the segment's clear state shows the group's surface.
    /// 选中时的填充；分段透明态露出分组表面时为 `None`。
    fill: Option<Color>,
    /// Draw the seam on this segment's left edge; the first segment has none.
    /// 在该分段的左边缘画接缝；首段没有。
    seam: bool,
    layer: Option<Color>,
    press: Option<ui_core::PressInk>,
    ring: Option<(Color, f32)>,
    label_size: f32,
    label_weight: Weight,
}

/// An MD3 outlined segmented button.
/// 一个 MD3 轮廓分段按钮。
pub struct Md3SegmentedButton {
    id: Id,
    height: f32,
    segments: Vec<Segment>,
    /// The group's outline: one ring around every segment, plus the seams between them.
    /// 整组的描边：所有分段外围一圈，以及分段之间的接缝。
    outline: Option<(Color, f32)>,
    /// The clicked segment, resolved at build time so `change` carries no state.
    /// 被点击的分段，构建时就解析好，使 `change` 不再带状态。
    clicked: Option<Id>,
    disabled: bool,
}

impl Md3SegmentedButton {
    pub fn new_with(
        options: Md3Options,
        params: SegmentedParams<'_>,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let SegmentedParams { id, items, selected, disabled } = params;
        let with_icon = items.iter().any(|s| s.icon.is_some());
        let rest = outlined_segmented_button_spec(false, false, false, false, false, false);
        let disabled = options.disabled || disabled || cx.state(id).disabled;
        let height = rest.container.height;
        let ring_colour = spec_ink(pack, rest.focus_indicator.color, 1.0);
        let ring_width = rest.focus_indicator.thickness;
        // One ring for the whole group and one seam between neighbours: each segment drawing
        // its own ring would put two lines in every seam.
        // 整组只有一圈描边、相邻分段之间一条接缝：每段各画整圈会让每条接缝出现两条线。
        let outline = (rest.outline.width > 0.0).then(|| {
            (spec_ink(pack, rest.outline.color, rest.outline.opacity), rest.outline.width)
        });
        let len = items.len();
        let mut segments = Vec::with_capacity(len);
        let mut clicked = None;
        for (k, item) in items.iter().enumerate() {
            let on = selected.contains(&item.id);
            let mut node = cx.at(item.id);
            let state = node.state();
            if state.activation() && !disabled {
                clicked = Some(item.id);
            }
            let spec = outlined_segmented_button_spec(
                on,
                with_icon,
                state.hovered,
                state.focus_visible,
                state.pressed,
                disabled,
            );
            // The layer's ink follows the segment's own selection: `onSurface` clear,
            // `onSecondaryContainer` when filled. Read it off the hovered set.
            // 状态层的墨色跟随分段自身的选中态：未选是 `onSurface`，已选是 `onSecondaryContainer`。
            // 按悬停态读取它。
            let layer_ink = role(
                pack,
                outlined_segmented_button_spec(on, with_icon, true, false, false, disabled)
                    .state_layer
                    .color,
            );
            let fill = on.then(|| spec_ink(pack, spec.container.color, 1.0));
            // Press is a splat at the pointer, so only hover and focus stay in the flat layer.
            // 按下是在指针处泼墨，因此平坦层里只留悬停与聚焦。
            let hover_layer =
                outlined_segmented_button_spec(on, with_icon, true, false, false, disabled)
                    .state_layer
                    .opacity;
            let focus_layer =
                outlined_segmented_button_spec(on, with_icon, false, true, false, disabled)
                    .state_layer
                    .opacity;
            let press_layer =
                outlined_segmented_button_spec(on, with_icon, false, false, true, disabled)
                    .state_layer
                    .opacity;
            let hover = node.animate(item.id.with(param::HOVER), f32::from(state.hovered), REACTION);
            let focus =
                node.animate(item.id.with(param::FOCUS), f32::from(state.focus_visible), REACTION);
            let alpha = (hover * hover_layer).max(focus * focus_layer);
            let layer =
                (alpha > 0.0 && !disabled).then_some(Color { a: layer_ink.a * alpha, ..layer_ink });
            // Declared every frame, not only while held: the engine owns the splat and fades
            // it out after release, so withdrawing the declaration would cut the ripple short.
            // 每帧都声明，而不是只在按住时：引擎持有墨迹并在松手后淡出，
            // 收回声明会把涟漪截断。
            let press = (!disabled).then(|| {
                press_ink(Color { a: layer_ink.a * press_layer, ..layer_ink }, InkRadius::Cover)
            });
            let ring = (!disabled && state.focus_visible).then(|| {
                let t = node.animate(item.id.with(param::THICKNESS), 1.0, REACTION);
                (Color { a: ring_colour.a * t, ..ring_colour }, ring_width)
            });
            let corners = GroupPosition::new(k, len).corners(height * 0.5, 0.0);
            segments.push(Segment {
                id: item.id,
                label: item.label.to_string(),
                label_ink: spec_ink(pack, spec.label_text.color, spec.label_text.opacity),
                icon: item.icon.map(|f| (f, spec_ink(pack, spec.icon.color, spec.icon.opacity))),
                corners,
                fill,
                seam: k > 0,
                layer,
                press,
                ring,
                label_size: spec.label_text.size,
                label_weight: Weight(spec.label_text.weight as u16),
            });
        }
        Self {
            id,
            height,
            segments,
            outline,
            clicked,
            disabled,
        }
    }

    /// The bar's height, so a caller can align what sits beside it.
    /// 条的高度，供调用方对齐旁边的东西。
    pub fn height(&self) -> f32 {
        self.height
    }

    /// Which segment a point in the bar's space belongs to; segments are equal shares.
    /// 条内某点属于哪个分段；分段严格等宽。
    pub fn segment_at(&self, local: Point, width: f32) -> Option<usize> {
        let n = self.segments.len();
        if n == 0 || width <= 0.0 || local.y < 0.0 || local.y > self.height {
            return None;
        }
        let share = width / n as f32;
        Some(((local.x / share).floor().max(0.0) as usize).min(n - 1))
    }
}

impl Widget for Md3SegmentedButton {
    fn handles_disabled(&self) -> bool {
        // The export carries 38% content and 12% outline fades, already painted per segment.
        // 导出自带内容 38%、描边 12% 的淡化，已按分段逐一绘制。
        true
    }

    fn change(&self, _state: &WidgetState, _bounds: ui_core::geom::Rect) -> Option<Change> {
        self.clicked.map(|id| Change::Selected(Some(id)))
    }

    fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
        let corners = Corners::all(self.height * 0.5);
        let mut row = Decl::container(self.id, NodeKind::Row)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fixed(self.height),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .corners(corners)
            // The ring is positioned against this row, so it can cover the whole bar.
            // 描边相对这一行定位，因此能盖住整条。
            .relative()
            .disabled(self.disabled);
        for segment in &self.segments {
            row = row.child(self.segment_decl(segment));
        }
        if let Some((ink, width)) = self.outline {
            // One ring for the whole group, painted after the segments: a selected fill would
            // otherwise cover the border, which is what makes the selection read as outlined.
            // 整组一圈描边，绘制在分段之后：否则选中的填充会盖住边框，而正是它让选中态读作有边框。
            row = row.child(
                Decl::container(self.id.with("outline"), NodeKind::Box)
                    .size(SizeClass::hug(0.0, 0.0))
                    .inset(Insets::ZERO)
                    .absolute()
                    // Paint-only: it covers every segment, so it must not take their presses.
                    // 只负责绘制：它盖住全部分段，不能抢走它们的按下。
                    .sense(Sense::PASS_THROUGH)
                    .shapes(vec![Shape::Box {
                        corners,
                        fill: Color::TRANSPARENT,
                        gradient: None,
                        border: Some((ink, width)),
                        shadow: None,
                        image: None,
                    }]),
            );
        }
        row
    }
}

impl Md3SegmentedButton {
    /// One segment: full ring or fill, its state layer, and the centred icon-and-label block.
    /// 一个分段：整圈描边或填充、状态层，以及居中的图标与标签块。
    fn segment_decl(&self, segment: &Segment) -> Decl {
        let mut shapes = Vec::with_capacity(4);
        // The clear segment's surface is transparent over the group's pill; a fill means selected.
        // 未选中分段的表面透明地覆在分组胶囊上；有填充即为选中。
        if let Some(fill) = segment.fill {
            shapes.push(Shape::Box {
                corners: segment.corners,
                fill,
                gradient: None,
                // The group's ring and the seams already frame this segment; a third outline
                // would double every edge and need the selection state to draw itself.
                // 整组描边与接缝已经把这段框住；再加一圈会让每条边画两遍，还得读选中态。
                border: None,
                shadow: None,
                image: None,
            });
        }
        if let Some(layer) = segment.layer {
            shapes.push(Shape::Box {
                corners: segment.corners,
                fill: layer,
                gradient: None,
                border: None,
                shadow: None,
                image: None,
            });
        }
        // One seam on this segment's left edge, not a ring: the group's own outline already
        // covers the perimeter, and two rings would draw every seam twice.
        // 只在本段左边缘画一条接缝，不画整圈：整组的外框已经覆盖周边，
        // 两圈描边会让每条接缝画两遍。
        if segment.seam
            && let Some((ink, width)) = self.outline {
                shapes.push(Shape::Rect {
                    rect: Rect::new(0.0, 0.0, width, self.height),
                    corners: Corners::ZERO,
                    fill: ink,
                    gradient: None,
                    border: None,
                });
            }
        if let Some((ink, width)) = segment.ring {
            shapes.push(Shape::Box {
                corners: segment.corners,
                fill: Color::TRANSPARENT,
                gradient: None,
                border: Some((ink, width)),
                shadow: None,
                image: None,
            });
        }
        let label =
            Text::new(segment.id.with("label"), segment.label.clone(), segment.label_size, segment.label_ink)
                .weight(segment.label_weight)
                .resolve();
        let mut content = Decl::container(segment.id.with("content"), NodeKind::Row)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fixed(self.height),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets {
                left: SEGMENT_PAD,
                right: SEGMENT_PAD,
                top: 0.0,
                bottom: 0.0,
            })
            .gap(8.0)
            .cross_align(0.0)
            .cross_pos(0.5);
        if let Some((source, ink)) = segment.icon {
            content = content.child(source.resolve(segment.id.with("icon"), ink));
        }
        content = content.child(label);
        Decl::container(segment.id, NodeKind::Column)
            .size(SizeClass {
                // Equal shares: a zero-basis grower splits the bar whatever the labels are.
                // 等分：零基准的增长者平均切开整条，与标签长短无关。
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fixed(self.height),
                grow_x: Grow::Split(1),
                grow_y: Grow::No,
            })
            .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
            .cursor(if self.disabled { CursorShape::Arrow } else { CursorShape::PointingHand })
            .disabled(self.disabled)
            .press_ink(segment.press)
            // The segment's own curve, so the ripple is cut to the end segments' rounding.
            // 分段自身的曲线，涟漪因此被裁到两端分段的圆角。
            .corners(segment.corners)
            .shapes(shapes)
            .child(content)
    }
}
