//! MD3 switch, rebuilt from Flutter's `material/switch.dart`: one raw controller drives the
//! size sequence and the colour clock, while a curved view drives the thumb's position.
//! MD3 开关，按 Flutter `material/switch.dart` 重建：原始控制器驱动尺寸序列与颜色时钟，
//! 曲线视图驱动滑块位置。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Rect};
use ui_core::{AnimSpec, CursorShape, Decl, Easing, Id, NodeKind, Sense, SizeClass, Travel};
use ui_style::Style;
use ui_widgets::build::{param, IMMEDIATE};
use ui_widgets::{Widget, WidgetState};

use crate::spec::{switch_spec, SwitchSpec};
use crate::Md3Options;

/// Token snapshots the geometry derives from: rest, selected, pressed, with icon.
/// 几何常量由此派生的令牌快照：静止、选中、按压、带图标。
const REST: SwitchSpec = switch_spec(false, false, false, false, false, false);
const ON: SwitchSpec = switch_spec(true, false, false, false, false, false);
const PRESSED: SwitchSpec = switch_spec(false, false, false, false, true, false);
const WITH_ICON: SwitchSpec = switch_spec(false, true, false, false, false, false);

/// The track box; the spec's `52x32` already includes the 2dp outline.
/// 轨道盒；规范里的 `52x32` 已含 2dp 描边。
pub const TRACK: (f32, f32) = (REST.track.width, REST.track.height);
/// `EdgeInsets.symmetric(horizontal: 4)`; the vertical padding centres the 32dp track in
/// the 48dp control.
/// `EdgeInsets.symmetric(horizontal: 4)`；纵向内衬把 32dp 轨道居中在 48dp 控件里。
pub const PAD: (f32, f32) = (4.0, 8.0);
/// `switchWidth + padding.horizontal` by `switchHeight` (`switchMinSize.height + 8`).
/// `switchWidth + padding.horizontal` × `switchHeight`（`switchMinSize.height + 8`）。
pub const WIDGET: (f32, f32) = (TRACK.0 + 2.0 * PAD.0, 48.0);

/// Handle diameters: inactive 16, active 24, pressed 28, with-icon 24 in **both** states.
/// 滑块直径：关闭 16、开启 24、按压 28，带图标时**两态**都是 24。
pub const THUMB_INACTIVE: f32 = REST.handle.width;
pub const THUMB_ACTIVE: f32 = ON.handle.width;
pub const THUMB_PRESSED: f32 = PRESSED.handle.width;
pub const THUMB_WITH_ICON: f32 = WITH_ICON.handle.width;
/// `transitionalThumbSize`, hand-coded in Flutter as `Size(34, 22)`.
/// `transitionalThumbSize`，Flutter 里手写为 `Size(34, 22)`。
pub const THUMB_TRANSITIONAL: (f32, f32) = (34.0, 22.0);
/// `trackOutlineWidth`; the outline is painted in every state, only its colour moves.
/// `trackOutlineWidth`；描边在两态都画，只有颜色在动。
pub const OUTLINE_WIDTH: f32 = REST.track_outline.width;
/// The radial reaction's full radius: `state-layer.size / 2`.
/// 涟漪满半径：`state-layer.size / 2`。
pub const SPLASH_RADIUS: f32 = REST.state_layer.size * 0.5;
/// Gap between the track and the focus ring, from `focus.indicator.offset`.
/// 轨道与焦点环之间的间隙，取自 `focus.indicator.offset`。
pub const FOCUS_RING_GAP: f32 = REST.focus_indicator.offset;
/// The token asks for 3dp, but the 60dp box leaves 4dp per side and the ring must not
/// enlarge the control, so its width is what the box has left.
/// 令牌要求 3dp，但 60dp 的盒子每侧只剩 4dp，且环不得撑大控件，故宽度取盒子剩下的量。
pub const FOCUS_RING_WIDTH: f32 = (WIDGET.0 - TRACK.0) * 0.5 - FOCUS_RING_GAP;
/// `icon.size`.
/// `icon.size`。
pub const ICON_SIZE: f32 = REST.icon.size;
/// Bar thickness of the hand-drawn glyph; the engine has no rotation, so a diagonal is a
/// staircase of small squares.
/// 手绘字形的条厚；引擎没有旋转变换，故斜线用一串小方块排成阶梯。
pub const ICON_BAR: f32 = 2.2;

/// `toggleDuration` (M3).
/// `toggleDuration`（M3）。
pub const TOGGLE_MS: f32 = 300.0;
/// `kRadialReactionDuration`.
/// `kRadialReactionDuration`。
pub const REACTION_MS: f32 = 100.0;

/// `Curves.easeOutBack`.
/// `Curves.easeOutBack`。
const POSITION_CURVE: Easing = Easing::Cubic(0.175, 0.885, 0.32, 1.275);

/// `_colorAnimation = CurvedAnimation(positionController, Curves.easeOut)`, which is the
/// CSS cubic `(0, 0, 0.58, 1)`; the engine's `EaseOut` is a different (Penner) curve.
/// `_colorAnimation = CurvedAnimation(positionController, Curves.easeOut)`，即 CSS 三次曲线
/// `(0, 0, 0.58, 1)`；引擎的 `EaseOut` 是另一条（Penner）曲线。
const COLOUR_CURVE: Easing = Easing::Cubic(0.0, 0.0, 0.58, 1.0);
/// The two size-sequence curves: `Cubic(0.31, 0, 0.56, 1)` and `Cubic(0.20, 0, 0, 1)`.
/// 两条尺寸序列曲线：`Cubic(0.31, 0, 0.56, 1)` 与 `Cubic(0.20, 0, 0, 1)`。
const SEQ_IN: Easing = Easing::Cubic(0.31, 0.0, 0.56, 1.0);
const SEQ_OUT: Easing = Easing::Cubic(0.20, 0.0, 0.0, 1.0);
/// `Curves.fastOutSlowIn`.
/// `Curves.fastOutSlowIn`。
const FAST_OUT_SLOW_IN: Easing = Easing::Cubic(0.4, 0.0, 0.2, 1.0);

/// The raw controller: linear in time, 300ms.
/// 原始控制器：随时间线性，300ms。
pub const PROGRESS: AnimSpec = AnimSpec::new(TOGGLE_MS / 1000.0, Easing::Linear).span(1.0);
/// The curved view of the same controller. The down leg uses the same `easeOutBack` **as a
/// leg-progress curve**: Flutter's `easeOutBack.flipped` applies to a falling controller.
/// 同一控制器的曲线视图。下行腿按**段进度**取同一条 `easeOutBack`：Flutter 的
/// `easeOutBack.flipped` 作用在下降的控制器上。
pub const POSITION: AnimSpec = AnimSpec::new(TOGGLE_MS / 1000.0, POSITION_CURVE)
    .down(TOGGLE_MS / 1000.0, POSITION_CURVE)
    .span(1.0);
/// The colour clock is the raw controller on `Curves.easeOut`.
/// 颜色时钟是原始控制器上的 `Curves.easeOut`。
pub const COLOUR_SPEC: AnimSpec =
    AnimSpec::new(TOGGLE_MS / 1000.0, COLOUR_CURVE).span(1.0);
/// `reaction` runs 100ms on `fastOutSlowIn`.
/// `reaction` 时长 100ms，曲线 `fastOutSlowIn`。
pub const REACTION: AnimSpec = AnimSpec::new(REACTION_MS / 1000.0, FAST_OUT_SLOW_IN).span(1.0);
/// Hover and focus overlays fade in 50ms on `fastOutSlowIn`.
/// 悬停与聚焦覆盖层在 50ms 内按 `fastOutSlowIn` 淡入淡出。
pub const REACTION_FADE: AnimSpec = AnimSpec::new(0.05, FAST_OUT_SLOW_IN).span(1.0);

/// `trackInnerLength = trackWidth - trackHeight`; the thumb centre travels 16 -> 36.
/// `trackInnerLength = trackWidth - trackHeight`；滑块中心从 16 走到 36。
pub fn track_inner_length() -> f32 {
    TRACK.0 - TRACK.1
}

/// Thumb centre x for a curved position; the reference puts it on the track's end caps.
/// 曲线位置对应的滑块中心 x；参考把中心放在轨道端帽上。
pub fn thumb_center_x(visual: f32) -> f32 {
    TRACK.1 * 0.5 + visual * track_inner_length()
}

/// Left edge of the thumb box; deliberately unclamped, as in the reference.
/// 滑块盒左边缘；与参考一致，刻意不钳制。
pub fn thumb_left(centre: f32, width: f32) -> f32 {
    centre - width * 0.5
}

/// One point on the size trajectory: the two endpoint sizes and the transitional pill.
/// 尺寸轨迹上的一点：两个端点尺寸与过渡胶囊。
///
/// `forward` follows the reference's 11/72/17 sequence, `false` its mirrored 17/72/11;
/// `progress` is the **raw** controller value, never the curved position.
/// `forward` 走参考的 11/72/17 序列，`false` 走镜像的 17/72/11；`progress` 是**原始**控制器值。
pub fn size_at(forward: bool, progress: f32, off: f32, on: f32) -> (f32, f32) {
    let p = progress.clamp(0.0, 1.0);
    let (pw, ph) = THUMB_TRANSITIONAL;
    let mix = |a: f32, b: f32, t: f32| a + (b - a) * t;
    if forward {
        if p < 0.11 {
            let t = SEQ_IN.apply(p / 0.11);
            (mix(off, pw, t), mix(off, ph, t))
        } else if p < 0.83 {
            let t = SEQ_OUT.apply((p - 0.11) / 0.72);
            (mix(pw, on, t), mix(ph, on, t))
        } else {
            (on, on)
        }
    } else if p < 0.17 {
        (off, off)
    } else if p < 0.89 {
        let t = SEQ_OUT.mirrored().apply((p - 0.17) / 0.72);
        (mix(off, pw, t), mix(off, ph, t))
    } else {
        let t = SEQ_IN.mirrored().apply((p - 0.89) / 0.11);
        (mix(pw, on, t), mix(ph, on, t))
    }
}

/// One role resolved against the live pack; a miss is a bug, shown as magenta.
/// 角色用品活的包解析；缺失是缺陷，用品红显形。
pub(crate) fn role(pack: &Style, name: &'static str) -> Color {
    let c = pack.ink(name);
    debug_assert!(c.is_some(), "neither the pack nor its palette knows {name}");
    c.unwrap_or(Color::from_rgba8(255, 0, 255, 255))
}

/// One token slot resolved against the live pack; an empty name means "paint nothing".
/// 令牌位用品活的包解析；名字为空即「不画色」。
pub(crate) fn spec_ink(pack: &Style, token: &'static str, opacity: f32) -> Color {
    if token.is_empty() {
        return Color::TRANSPARENT;
    }
    let c = role(pack, token);
    Color { a: c.a * opacity, ..c }
}

/// Source-over compositing in stored sRGB, matching `Color.alphaBlend`.
/// 在存储的 sRGB 空间做 source-over 合成，对应 `Color.alphaBlend`。
fn over(src: Color, dst: Color) -> Color {
    let a = src.a.clamp(0.0, 1.0);
    Color {
        r: src.r * a + dst.r * (1.0 - a),
        g: src.g * a + dst.g * (1.0 - a),
        b: src.b * a + dst.b * (1.0 - a),
        a: a + dst.a * (1.0 - a),
    }
}

/// Snap at the ends so a settled switch reports the exact state colour, not a lerp one ULP
/// off; only an in-flight transition interpolates.
/// 在两端直接取定值，使静止的开关报告精确的状态色，而非差一个 ULP 的插值；只有过渡中才插值。
pub(crate) fn between(a: Color, b: Color, t: f32) -> Color {
    if t <= 0.0 {
        a
    } else if t >= 1.0 {
        b
    } else {
        a.lerp(b, t)
    }
}

/// Scalar linear interpolation.
/// 标量线性插值。
pub(crate) fn lerp(a: f32, b: f32, t: f32) -> f32 {
    a + (b - a) * t
}

/// Read or write one latched endpoint; `None` means the reference stopped writing it.
/// 读取或写入一个锁存端点；`None` 表示参考停止写该字段。
fn latch(ctx: &mut ui_widgets::NodeCx<'_>, key: Id, target: Option<f32>, rest: f32) -> f32 {
    match target {
        Some(t) => ctx.animate(key, t, IMMEDIATE),
        None => ctx.status(key).map(|s| s.value).unwrap_or(rest),
    }
}

/// The two glyphs an MD3 switch thumb can carry. Kept as plain shapes, not a font: the
/// engine draws no icon fonts, and a check/cross is a few bars.
/// 开关滑块可带的两种字形。用简单形状而非字体：引擎不画图标字体，勾/叉本就是几笔。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ThumbGlyph {
    /// Drawn when the switch is on.
    /// 开关打开时绘制。
    Check,
    /// Drawn when the switch is off.
    /// 开关关闭时绘制。
    Cross,
}

/// `_SwitchConfigM3.iconColor` at rest: selected reads `onPrimaryContainer` in Flutter and
/// `primary` in the export; unselected reads `surfaceContainerHighest`; disabled fades 38%.
/// `_SwitchConfigM3.iconColor` 的静止值：选中在 Flutter 取 `onPrimaryContainer`、导出取
/// `primary`；未选中取 `surfaceContainerHighest`；禁用淡到 38%。
pub fn icon_color(pack: &Style, on: bool, disabled: bool) -> Color {
    let s = switch_spec(on, true, false, false, false, disabled);
    spec_ink(pack, s.icon.color, s.icon.opacity)
}

/// The bars that draw `glyph`, in the glyph's own 16x16 space.
/// 绘制 `glyph` 的各条，坐标在字形自身的 16×16 空间。
fn glyph_bars(glyph: ThumbGlyph) -> Vec<(f32, f32, f32, f32)> {
    let s = ICON_SIZE;
    let (a, b, c, d) = match glyph {
        ThumbGlyph::Check => (
            (s * 0.20, s * 0.52),
            (s * 0.42, s * 0.72),
            (s * 0.42, s * 0.72),
            (s * 0.80, s * 0.28),
        ),
        ThumbGlyph::Cross => (
            (s * 0.26, s * 0.26),
            (s * 0.74, s * 0.74),
            (s * 0.74, s * 0.26),
            (s * 0.26, s * 0.74),
        ),
    };
    let mut bars = crate::glyph::bars_along(a, b, ICON_BAR);
    bars.extend(crate::glyph::bars_along(c, d, ICON_BAR));
    bars
}

/// One MD3 switch; every animation is advanced in `new_with`, so `decl` stays pure.
/// 一个 MD3 开关；所有动画都在 `new_with` 里推进，因此 `decl` 是纯函数。
pub struct Md3Toggle {
    id: Id,
    /// Curved position 0..=1, used for drawing and for the release decision.
    /// 曲线位置 0..=1，用于绘制与松手判定。
    position: f32,
    /// Drawn thumb size.
    /// 绘制的滑块尺寸。
    thumb: (f32, f32),
    thumb_color: Color,
    track_color: Color,
    outline: Color,
    outline_width: f32,
    /// Radial reaction: centre offset in the track, radius, colour.
    /// 涟漪：圆心相对轨道的偏移、半径、颜色。
    reaction: Option<(f32, f32, Color)>,
    /// The glyph on the thumb, if any, and its colour at this position.
    /// 滑块上的字形（若有）及其当前位置的颜色。
    glyph: Option<(ThumbGlyph, Color)>,
    /// Keyboard-focus fade 0..=1; the ring is drawn only while this is above zero.
    /// 键盘焦点的淡入 0..=1；仅在大于零时绘制焦点环。
    focus_fade: f32,
    focus_ring_colour: Color,
    semantic_on: bool,
    disabled: bool,
}

impl Md3Toggle {
    /// The unprefixed form: constants only, as a direct caller expects.
    /// 无参数版本：只用常量，直接调用方会这样用。
    pub fn new(
        id: Id,
        on: bool,
        _label: &str,
        ctx: &mut ui_widgets::NodeCx<'_>,
        pack: &Style,
    ) -> Self {
        Self::new_with(Md3Options::default(), id, on, ctx, pack)
    }

    /// Same control with explicit parameters, so the semantic path and a direct caller
    /// produce identical `Decl`s. 带显式参数的同一控件，使语义路径与直接调用产出相同的 Decl。
    pub fn new_with(
        params: Md3Options,
        id: Id,
        on: bool,
        ctx: &mut ui_widgets::NodeCx<'_>,
        pack: &Style,
    ) -> Self {
        let state = ctx.state();
        let disabled = state.disabled || params.disabled;
        let inner = track_inner_length();
        let pkey = id.with(param::PROGRESS);
        let vkey = id.with(param::POSITION);

        // A drag writes the finger's own position; a release frame reads it back without
        // retargeting, so the app's value change can arrive on the next frame.
        // 拖拽写入手指自己的位置；松手帧只读回，不重定向，让应用的值变化在下一帧到达。
        let (raw, eased) = if state.dragging {
            let before = ctx.value(pkey);
            let target = match state.drag_step {
                Some(d) => (before + d.x / inner).clamp(0.0, 1.0),
                None => before,
            };
            (
                ctx.animate(pkey, target, IMMEDIATE),
                ctx.animate(vkey, target, IMMEDIATE),
            )
        } else if state.dropped {
            (ctx.value(pkey), ctx.value(vkey))
        } else {
            let target = if on { 1.0 } else { 0.0 };
            (
                ctx.animate(pkey, target, PROGRESS),
                ctx.animate(vkey, target, POSITION),
            )
        };
        let progress_status = ctx.status(pkey).unwrap_or_default();

        // `reaction` runs 100ms on `fastOutSlowIn`, started by press or drag.
        // `reaction` 时长 100ms，曲线 `fastOutSlowIn`，由按压或拖拽启动。
        let rkey = id.with(param::PRESS);
        let reaction = ctx.animate(rkey, f32::from(state.pressed || state.dragging), REACTION);
        let reaction_status = ctx.status(rkey).unwrap_or_default();
        let reaction_active = !(reaction_status.settled && reaction_status.value <= 0.0);
        let reaction_completed = reaction_status.settled && reaction_status.value >= 1.0;

        // The endpoints are re-derived only where the reference does: a completed press, or the
        // raw controller resting at an end. Mid-flight they stay latched.
        // 端点只在参考会重算的地方重算：按压已完成，或原始控制器停在某一端。飞行中保持锁存。
        let inactive_size = if params.has_icon { THUMB_WITH_ICON } else { THUMB_INACTIVE };
        let active_size = THUMB_ACTIVE;
        let (off_target, on_target) = if reaction_completed {
            (
                Some(lerp(inactive_size, THUMB_PRESSED, reaction)),
                Some(lerp(active_size, THUMB_PRESSED, reaction)),
            )
        } else if raw <= 0.0 {
            (
                Some(lerp(inactive_size, THUMB_PRESSED, reaction)),
                Some(active_size),
            )
        } else if raw >= 1.0 {
            (
                Some(inactive_size),
                Some(lerp(active_size, THUMB_PRESSED, reaction)),
            )
        } else {
            (None, None)
        };
        let off_end = latch(ctx, id.with(param::SIZE_OFF), off_target, inactive_size);
        let on_end = latch(ctx, id.with(param::SIZE_ON), on_target, active_size);

        // The sequence follows the instance's travel, not the semantic target: on the
        // release frame the app has not flipped yet, so the target still points the old way.
        // 序列跟随实例的行进方向，而不是语义目标：松手帧应用还没翻转，目标仍指向旧方向。
        let forward = progress_status.travel == Travel::Forward;
        let (tw, th) = if reaction_completed {
            (THUMB_PRESSED, THUMB_PRESSED)
        } else {
            size_at(forward, raw, off_end, on_end)
        };

        // The four thumb branches come from the reference: pressed -> both ends pressed; a
        // forward leg keeps the off end pressed; a reverse leg the on end; rest follows hover.
        // 滑块的四个分支来自参考：按压时两端都是「按压色」；正向腿保持关闭端按压；
        // 反向腿保持开启端按压；静止时两端按悬停/聚焦取值。
        let lit = state.hovered || state.focus_visible;
        let traveling = !progress_status.settled;
        let off_pressed = reaction_active || (traveling && progress_status.travel == Travel::Forward);
        let on_pressed = reaction_active || (traveling && progress_status.travel == Travel::Reverse);
        let off = switch_spec(false, params.has_icon, lit, lit, off_pressed, disabled);
        let active = switch_spec(true, params.has_icon, lit, lit, on_pressed, disabled);
        let t = COLOUR_CURVE.apply(raw);
        let surface = role(pack, "surface");
        // `Color.alphaBlend(lerpedThumbColor, surfaceColor)`: a translucent handle is blended
        // over the surface so the track cannot show through it.
        // `Color.alphaBlend(lerpedThumbColor, surfaceColor)`：半透明滑块先与表面合成，
        // 轨道因此不会透过它。
        let thumb_color = over(
            between(
                spec_ink(pack, off.handle.color, off.handle.opacity),
                spec_ink(pack, active.handle.color, active.handle.opacity),
                t,
            ),
            surface,
        );
        let track_color = between(
            spec_ink(pack, off.track.color, off.track.opacity),
            spec_ink(pack, active.track.color, active.track.opacity),
            t,
        );
        // The export gives the outline no opacity of its own; Flutter's disabled ring is
        // `onSurface` at the track's 12%, so the track's opacity is the right one.
        // 导出里描边没有自己的透明度；Flutter 的禁用环是 `onSurface` 取轨道的 12%，
        // 故沿用轨道的透明度。
        let outline = between(
            spec_ink(pack, off.track_outline.color, off.track.opacity),
            spec_ink(pack, active.track_outline.color, active.track.opacity),
            t,
        );

        // Hover and focus fade 50ms. `isFocused` in `paintRadialReaction` is the keyboard
        // focus highlight, so both the ring and the splash key on `focus_visible`.
        // 悬停与焦点 50ms 淡变。`paintRadialReaction` 的 `isFocused` 是键盘焦点高亮，
        // 故焦点环与涟漪都用 `focus_visible`。
        let hover_fade = ctx.animate(
            id.with(param::HOVER),
            f32::from(state.hovered),
            REACTION_FADE,
        );
        let focus_fade = ctx.animate(
            id.with(param::FOCUS),
            f32::from(state.focus_visible),
            REACTION_FADE,
        );
        let layer = |selected: bool, hovered: bool, focused: bool, pressed: bool| {
            let s = switch_spec(selected, params.has_icon, hovered, focused, pressed, disabled);
            spec_ink(pack, s.state_layer.color, s.state_layer.opacity)
        };
        let base = between(
            layer(false, false, false, true),
            layer(true, false, false, true),
            eased,
        );
        let reaction_colour = base
            .lerp(layer(on, true, false, false), hover_fade)
            .lerp(layer(on, false, true, false), focus_fade);
        let radius = if state.hovered || state.focus_visible {
            SPLASH_RADIUS
        } else {
            reaction * SPLASH_RADIUS
        };
        // A running fade still counts as showing: its first frame is 0 but the circle exists.
        // 正在进行的淡变也算在显示：首帧值为 0，但圆已经存在。
        let showing =
            reaction_active || state.hovered || state.focus_visible || hover_fade > 0.0 || focus_fade > 0.0;

        // `radialReactionOrigin.dx = thumbLeft + thumbSize.height / 2`: the splash sits on the
        // thumb's left cap centre, not its centroid.
        // `radialReactionOrigin.dx = thumbLeft + thumbSize.height / 2`：涟漪落在滑块左端帽的
        // 圆心，不是几何中心。
        let centre = thumb_center_x(eased);
        let origin_x = thumb_left(centre, tw) + th * 0.5;
        let reaction_shape =
            (showing && radius > 0.0 && !disabled).then_some((origin_x, radius, reaction_colour));

        // `thumbIcon = currentValue < 0.5 ? inactiveIcon : activeIcon`; its colour lerps across
        // the whole travel.
        // `thumbIcon = currentValue < 0.5 ? inactiveIcon : activeIcon`；颜色整程插值。
        let glyph = params.has_icon.then(|| {
            let colour = between(
                icon_color(pack, false, disabled),
                icon_color(pack, true, disabled),
                eased,
            );
            let glyph = if eased < 0.5 {
                ThumbGlyph::Cross
            } else {
                ThumbGlyph::Check
            };
            (glyph, colour)
        });

        Self {
            id,
            position: eased,
            thumb: (tw, th),
            thumb_color,
            track_color,
            outline,
            outline_width: params.outline_width,
            reaction: reaction_shape,
            glyph,
            focus_fade,
            focus_ring_colour: spec_ink(pack, REST.focus_indicator.color, 1.0),
            semantic_on: on,
            disabled,
        }
    }
}

impl Widget for Md3Toggle {
    fn handles_disabled(&self) -> bool {
        // The token table paints disabled (12%/38%) itself; the adapter must not fade again.
        // 令牌表已自行按 12%/38% 画禁用；适配器不得再淡化一次。
        true
    }

    fn change(
        &self,
        state: &WidgetState,
        _bounds: ui_core::geom::Rect,
    ) -> Option<ui_core::Change> {
        if self.disabled {
            return None;
        }
        if state.activation() {
            return Some(ui_core::Change::Toggled {
                on: Some(!self.semantic_on),
            });
        }
        // `position.value >= 0.5 != widget.value`: the release decides by where the thumb
        // ended up, not by the pointer's last pixel.
        // `position.value >= 0.5 != widget.value`：松手按滑块落点判定，而不是指针最后一个像素。
        if state.dropped {
            let want = self.position >= 0.5;
            return (want != self.semantic_on).then_some(ui_core::Change::Toggled { on: Some(want) });
        }
        None
    }

    fn decl(&self, _cx: &ui_widgets::Cx<'_, '_>) -> Decl {
        let mut shapes = Vec::with_capacity(8);
        // Keyboard focus is an overlay ring with a transparent gap; it never participates in
        // layout or hit testing.
        // 键盘焦点是一圈带透明间隙的覆盖环；它从不参与布局或命中。
        if self.focus_fade > 0.0 {
            let outset = FOCUS_RING_GAP + FOCUS_RING_WIDTH;
            let w = TRACK.0 + outset * 2.0;
            let h = TRACK.1 + outset * 2.0;
            shapes.push(Shape::Rect {
                rect: Rect::new(PAD.0 - outset, PAD.1 - outset, w, h),
                corners: Corners::all(h * 0.5),
                fill: Color::TRANSPARENT,
                gradient: None,
                border: Some((
                    Color {
                        a: self.focus_fade,
                        ..self.focus_ring_colour
                    },
                    FOCUS_RING_WIDTH,
                )),
            });
        }
        // The outline is an inward border: the spec's 52x32 is the track's overall size,
        // outline included, so the border eats into the fill rather than adding around it.
        // 描边是向内边框：规范的 52×32 是轨道含描边的整体尺寸，故边框吃进填充而非向外增加。
        shapes.push(Shape::Rect {
            rect: Rect::new(PAD.0, PAD.1, TRACK.0, TRACK.1),
            corners: Corners::all(TRACK.1 * 0.5),
            fill: self.track_color,
            gradient: None,
            border: (self.outline_width > 0.0).then_some((self.outline, self.outline_width)),
        });
        if let Some((origin_x, r, colour)) = self.reaction {
            shapes.push(Shape::Rect {
                rect: Rect::new(
                    PAD.0 + origin_x - r,
                    PAD.1 + TRACK.1 * 0.5 - r,
                    r * 2.0,
                    r * 2.0,
                ),
                corners: Corners::all(r),
                fill: colour,
                gradient: None,
                border: None,
            });
        }
        let (tw, th) = self.thumb;
        let x = PAD.0 + thumb_left(thumb_center_x(self.position), tw);
        let y = PAD.1 + (TRACK.1 - th) * 0.5;
        shapes.push(Shape::Rect {
            rect: Rect::new(x, y, tw, th),
            corners: Corners::all(tw.min(th) * 0.5),
            fill: self.thumb_color,
            gradient: None,
            border: None,
        });
        if let Some((glyph, colour)) = self.glyph {
            let gx = x + (tw - ICON_SIZE) * 0.5;
            let gy = y + (th - ICON_SIZE) * 0.5;
            for (bx, by, bw, bh) in glyph_bars(glyph) {
                shapes.push(Shape::Rect {
                    rect: Rect::new(gx + bx, gy + by, bw, bh),
                    corners: Corners::all(bw.min(bh) * 0.5),
                    fill: colour,
                    gradient: None,
                    border: None,
                });
            }
        }
        Decl::container(self.id, NodeKind::Box)
            .size(SizeClass::fixed(WIDGET.0, WIDGET.1))
            // The switch takes hover, click, drag and focus; its shapes take nothing.
            // 开关接受悬停、点击、拖拽与焦点；它的形状不接受任何交互。
            .sense(Sense::HOVER | Sense::CLICK | Sense::DRAG | Sense::FOCUSABLE)
            .cursor(if self.disabled {
                CursorShape::Arrow
            } else {
                CursorShape::PointingHand
            })
            .disabled(self.disabled)
            .shapes(shapes)
    }
}
