//! MD3 connected button group: a row of buttons sharing one pill and each other's edges.
//! MD3 连通按钮组：一排按钮共用一颗胶囊与彼此的边缘。
//!
//! The group is the parent that knows, and it tells: it computes each member's
//! [`GroupPosition`] and hands the resolved corners down to the button it builds. A button
//! standing alone never sees a position, so neither the engine nor a plain button changes.
//! 分组是知情的一方，由它来说：它算出每个成员的 [`GroupPosition`]，把解析好的圆角交给自己构建的按钮。
//! 单独构建的按钮永远看不到位置，因此引擎与普通按钮都不必改动。

use ui_core::geom::{Color, Corners};
use ui_core::layout::SizeClass;
use ui_core::{Decl, Id, NodeKind, Sense};
use ui_style::Style;
use ui_widgets::{Cx, GroupPosition, Widget};

use crate::button::{ButtonParams, Md3Button};
use crate::spec::{
    button_group_connected_spec, ButtonGroupConnectedSize, ButtonSize,
};
use crate::toggle::role;
use crate::Md3Options;

/// One connected group: its members, in order, left to right (or top to bottom).
/// 一个连通分组：成员按顺序，自左向右（或自上而下）。
pub struct ButtonGroupParams {
    pub id: Id,
    /// The members, described but not built: the group builds them so the sizes match.
    /// 成员只给描述、不由调用方构建：分组自己构建它们，尺寸才能一致。
    pub members: Vec<ButtonParams>,
    pub size: ButtonGroupConnectedSize,
    /// Stack the members instead of lining them up.
    /// 改为纵向堆叠成员。
    pub vertical: bool,
}

impl ButtonGroupParams {
    pub fn new(id: Id, members: Vec<ButtonParams>) -> Self {
        Self {
            id,
            members,
            size: ButtonGroupConnectedSize::Medium,
            vertical: false,
        }
    }

    pub fn size(mut self, size: ButtonGroupConnectedSize) -> Self {
        self.size = size;
        self
    }

    pub fn vertical(mut self) -> Self {
        self.vertical = true;
        self
    }
}

/// The group's own surface, which shows through the gap between members.
/// 分组自身的表面色，会从成员之间的缝里露出来。
fn group_surface(pack: &Style) -> Color {
    role(pack, "surfaceContainerLow")
}

/// The button size the group's height corresponds to: one scale for both.
/// 分组高度对应的按钮档位：两边共用一套刻度。
fn button_size(size: ButtonGroupConnectedSize) -> ButtonSize {
    match size {
        ButtonGroupConnectedSize::XSmall => ButtonSize::XSmall,
        ButtonGroupConnectedSize::Small => ButtonSize::Small,
        ButtonGroupConnectedSize::Large => ButtonSize::Large,
        ButtonGroupConnectedSize::XLarge => ButtonSize::XLarge,
        _ => ButtonSize::Medium,
    }
}

/// One MD3 connected button group.
/// 一个 MD3 连通按钮组。
pub struct Md3ButtonGroup {
    id: Id,
    members: Vec<Md3Button>,
    height: f32,
    gap: f32,
    surface: Color,
    vertical: bool,
    disabled: bool,
}

impl Md3ButtonGroup {
    pub fn new_with(
        options: Md3Options,
        params: ButtonGroupParams,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let ButtonGroupParams {
            id,
            members,
            size,
            vertical,
        } = params;
        let state = cx.state(id);
        let len = members.len();
        // The export's `selected` flag means the group is showing a choice: that is a
        // member's own toggle, which the app has already stated on its parameters.
        // 导出的 `selected` 指分组正在显示选择：即某成员自身的开关，应用已在参数里说过。
        let selected = members
            .iter()
            .any(|m| m.toggle == crate::ButtonToggle::Selected);
        // A press anywhere in the group is a press on the group: the shared edges round over.
        // 组内任何处的按下都算在组上：共用的边缘因此变圆。
        let pressed = state.pressed;
        let spec = button_group_connected_spec(selected, pressed, size);
        let corners_of = |i: usize| -> Corners {
            GroupPosition::new(i, len).corners(spec.container.height * 0.5, spec.root.corner_size.min(spec.container.height * 0.5))
        };
        let resolved: Vec<Md3Button> = members
            .iter()
            .enumerate()
            .map(|(i, m)| {
                Md3Button::new_with(
                    options,
                    ButtonParams {
                        size: button_size(size),
                        corners: Some(corners_of(i)),
                        ..m.clone()
                    },
                    cx,
                    pack,
                )
            })
            .collect();
        Self {
            id,
            members: resolved,
            height: spec.container.height,
            gap: spec.root.between_space,
            surface: group_surface(pack),
            vertical,
            disabled: options.disabled || state.disabled,
        }
    }

    /// The group's own height, so a caller can align what sits beside it.
    /// 分组自身的高度，供调用方对齐旁边的东西。
    pub fn height(&self) -> f32 {
        self.height
    }
}

impl Widget for Md3ButtonGroup {
    fn handles_disabled(&self) -> bool {
        // The members fade themselves, exactly as a standalone disabled button does.
        // 成员自己淡化，与独立的禁用按钮完全一致。
        true
    }

    fn decl(&self, cx: &Cx<'_, '_>) -> Decl {
        let kind = if self.vertical {
            NodeKind::Column
        } else {
            NodeKind::Row
        };
        // Both axes hug: the members carry their own sizes, and the group is exactly their sum.
        // 两轴都收紧：尺寸由成员自带，分组正好是它们的总和。
        let mut row = Decl::container(self.id, kind)
            .size(SizeClass::hug(0.0, 0.0))
            .gap(self.gap)
            // The gap reads as the group's own surface: one pill divided, not pills apart.
            // 缝读作分组自身的表面：一颗被分开的胶囊，而不是几颗分开的胶囊。
            .background(self.surface, ui_core::geom::Corners::all(self.height * 0.5))
            // A group is a surface, never a target: every press belongs to a member.
            // 分组是表面而非目标：每次按下都归某个成员。
            .sense(Sense::PASS_THROUGH)
            .disabled(self.disabled);
        for member in &self.members {
            row = row.child(member.decl(cx));
        }
        row
    }
}
