//! MD3 search bar: a pill that edits one query and offers its own actions.
//! MD3 搜索栏：编辑一条查询、并提供自身动作的胶囊。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Insets};
use ui_core::layout::{AxisSize, Clip, Grow, Overflow, SizeClass};
use ui_core::{AnimSpec, Change, CursorShape, Decl, Easing, Id, NodeKind, Sense, Weight};
use ui_style::Style;
use ui_widgets::text::Text;
use ui_widgets::{Cx, IconSource, Widget, WidgetState};

use crate::spec::{search_bar_spec, SearchBarSpec};
use crate::text_field::{caret_scroll, typed_input};
use crate::toggle::{role, spec_ink};
use crate::Md3Options;

/// Height of the bar, from the export.
/// 栏高，取自导出。
pub const SEARCH_BAR_HEIGHT: f32 = 56.0;
/// Side of an action's touch target, matching the bar's own height budget.
/// 动作触控区的边长，与栏的高度预算一致。
pub(crate) const ACTION_BOX: f32 = 48.0;

const HOVER: AnimSpec = AnimSpec::new(0.167, Easing::Cubic(0.4, 0.0, 0.2, 1.0));

/// One trailing action: the node it reports as, and how it draws itself.
/// 一个尾部动作：它上报所用的节点，以及它怎么画自己。
#[derive(Clone, Copy)]
pub struct SearchAction {
    pub id: Id,
    pub icon: IconSource,
}

/// Everything a search bar is built with; the app owns the query.
/// 构建搜索栏所需的一切；查询归应用所有。
pub struct SearchBarParams<'a> {
    pub id: Id,
    pub text: &'a str,
    /// Shown while the query is empty.
    /// 查询为空时显示。
    pub hint: &'a str,
    /// Full width of the pill.
    /// 胶囊的完整宽度。
    pub width: f32,
    /// The contained variant, which hugs its contents at either end.
    /// 容纳式变体：两端紧贴内容。
    pub contained: bool,
    pub disabled: bool,
    pub leading: Option<IconSource>,
    pub actions: Vec<SearchAction>,
}

impl<'a> SearchBarParams<'a> {
    /// A docked bar of `width` with no hint, icon or actions.
    /// 一个宽 `width` 的停靠栏，无提示、图标或动作。
    pub fn new(id: Id, width: f32) -> Self {
        Self {
            id,
            text: "",
            hint: "",
            width,
            contained: false,
            disabled: false,
            leading: None,
            actions: Vec::new(),
        }
    }

    pub fn text(mut self, text: &'a str) -> Self {
        self.text = text;
        self
    }

    pub fn hint(mut self, hint: &'a str) -> Self {
        self.hint = hint;
        self
    }

    pub fn contained(mut self, contained: bool) -> Self {
        self.contained = contained;
        self
    }

    pub fn disabled(mut self, disabled: bool) -> Self {
        self.disabled = disabled;
        self
    }

    pub fn leading(mut self, icon: IconSource) -> Self {
        self.leading = Some(icon);
        self
    }

    pub fn action(mut self, id: Id, icon: IconSource) -> Self {
        self.actions.push(SearchAction { id, icon });
        self
    }
}

/// What a search bar reports besides the edits the engine sends as `Change::Text`.
/// 搜索栏除引擎以 `Change::Text` 送达的编辑之外上报的东西。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SearchBarChange {
    /// One of the trailing actions was clicked.
    /// 某个尾部动作被点击。
    Action(Id),
}

/// One bar, resolved against the pack.
/// 一个按包解析好的搜索栏。
pub struct Md3SearchBar {
    id: Id,
    width: f32,
    text: String,
    hint: String,
    disabled: bool,
    pad_l: f32,
    pad_r: f32,
    leading: Option<(IconSource, Color)>,
    actions: Vec<(SearchAction, Color)>,
    fill: Color,
    layer: Option<Color>,
    ring: Option<(Color, f32)>,
    input_ink: Color,
    hint_ink: Color,
    caret_ink: Color,
    input_size: f32,
    input_weight: Weight,
    caret: Option<usize>,
    painted: Option<ui_core::SelectionPrim>,
    preedit: Option<ui_core::Preedit>,
    fired: Option<Id>,
}

impl Md3SearchBar {
    /// Build one bar. The caret and the selection come from the engine.
    /// 构建一个搜索栏。插入符与选区来自引擎。
    pub fn new_with(
        params: Md3Options,
        content: SearchBarParams<'_>,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let SearchBarParams {
            id,
            text,
            hint,
            width,
            contained,
            disabled: off,
            leading,
            actions,
        } = content;
        let caret = cx.core().caret_for(id);
        let preedit = cx.core().preedit_for(id);
        let painted = cx
            .core()
            .selection_for(id)
            .filter(|selection| !selection.is_collapsed())
            .map(|selection| ui_core::SelectionPrim {
                range: selection.range(),
                fill: pack
                    .ink(ui_widgets::text::roles::SELECTION)
                    .unwrap_or(Color::TRANSPARENT),
                painter: pack.selection,
            });
        let mut node = cx.at(id);
        let state = node.state();
        let disabled = params.disabled || off || state.disabled;
        let focused = state.focused && !disabled;
        let has_actions = !actions.is_empty();
        let rest = parts(contained, has_actions, state.hovered, state.pressed);
        let hover = parts(contained, has_actions, true, false);
        let hover_t = node.animate(id.with("hover"), f32::from(state.hovered), HOVER);

        let layer = (!hover.state_layer.color.is_empty())
            .then(|| {
                let ink = role(pack, hover.state_layer.color);
                let strength = hover_t * hover.state_layer.opacity;
                Color { a: ink.a * strength, ..ink }
            })
            .filter(|c| c.a > 0.0 && !disabled);
        let ring = focused.then(|| {
            (
                spec_ink(pack, rest.focus_indicator.color, 1.0),
                rest.focus_indicator.thickness,
            )
        });
        let icon_ink = spec_ink(pack, rest.leading_icon.color, 1.0);
        let action_ink = spec_ink(pack, rest.trailing_icon.color, 1.0);
        let mut fired = None;
        for action in &actions {
            if cx.state(action.id).activation() {
                fired = Some(action.id);
            }
        }
        Self {
            id,
            width,
            text: text.to_string(),
            hint: hint.to_string(),
            disabled,
            pad_l: rest.root.leading_space,
            pad_r: rest.root.trailing_space,
            leading: leading.map(|f| (f, icon_ink)),
            actions: actions.into_iter().map(|a| (a, action_ink)).collect(),
            fill: spec_ink(pack, rest.container.color, 1.0),
            layer,
            ring,
            input_ink: spec_ink(pack, rest.input_text.color, 1.0),
            hint_ink: spec_ink(pack, rest.leading_icon.color, 0.7),
            caret_ink: spec_ink(pack, rest.focus_indicator.color, 1.0),
            input_size: rest.input_text.size,
            input_weight: Weight(rest.input_text.weight as u16),
            caret,
            painted,
            preedit,
            fired,
        }
    }

    /// The pill: fill, state layer and, while focused, a ring on the bar's own edge.
    /// 胶囊：填充、状态层，以及聚焦时画在栏自身边缘上的焦点环。
    fn shapes(&self) -> Vec<Shape> {
        let corners = Corners::all(SEARCH_BAR_HEIGHT * 0.5);
        let mut shapes = vec![Shape::Box {
            corners,
            fill: self.fill,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }];
        if let Some(layer) = self.layer {
            shapes.push(Shape::Box {
                corners,
                fill: layer,
                gradient: None,
                border: None,
                shadow: None,
                image: None,
            });
        }
        // The export offsets the ring outward; a declaration cannot know the final rect, so
        // it is drawn on the bar's own edge instead, as the list and carousel items do.
        // 导出让焦点环外移；声明期拿不到最终矩形，于是画在栏自身边缘，与列表/轮播条目一致。
        if let Some((ink, width)) = self.ring {
            shapes.push(Shape::Box {
                corners,
                fill: Color::TRANSPARENT,
                gradient: None,
                border: Some((ink, width)),
                shadow: None,
                image: None,
            });
        }
        shapes
    }
}

/// One 24dp icon in a 48dp touch box, centred in the header of height `height`.
/// 48dp 触控盒里的 24dp 图标，居中于高 `height` 的头部。
pub(crate) fn icon_box(id: Id, source: IconSource, ink: Color, height: f32) -> Decl {
    Decl::container(id, NodeKind::Column)
        .size(SizeClass::fixed(ACTION_BOX, height))
        .padding(Insets {
            left: 0.0,
            right: 0.0,
            top: (height - ui_widgets::icon_extent(24.0)) * 0.5,
            bottom: 0.0,
        })
        .cross_align(0.0)
        .cross_pos(0.5)
        .child(source.resolve(id.with("icon"), ink))
}

/// The editable query: shown text, caret, selection, composing run and the hint behind them.
/// 可编辑的查询：显示的文本、插入符、选区、组合段，以及它们背后的提示。
pub(crate) struct QueryField<'a> {
    pub id: Id,
    pub text: &'a str,
    pub caret: Option<usize>,
    pub preedit: Option<&'a ui_core::Preedit>,
    pub painted: Option<ui_core::SelectionPrim>,
    pub size: f32,
    pub weight: Weight,
    pub ink: Color,
    pub hint: &'a str,
    pub hint_ink: Color,
    pub caret_ink: Color,
    pub width: f32,
}

/// One query line, clipped to `width` and scrolled just far enough to keep the caret in view.
/// 一行查询，裁到 `width`，并且只滚到插入符刚好可见为止。
pub(crate) fn query_field(cx: &Cx<'_, '_>, f: QueryField<'_>) -> Decl {
    let (shown, composing, caret_at) = typed_input(f.text, f.caret, f.preedit);
    let mut input = Text::new(f.id.with("input"), shown.clone(), f.size, f.ink)
        .weight(f.weight)
        .nowrap()
        .max_width(f.width)
        .painting(f.painted)
        .composing(composing);
    if let Some(offset) = caret_at.filter(|_| !shown.is_empty()) {
        input = input.caret(offset, f.caret_ink);
    }
    let scroll = caret_scroll(cx, f.id.with("input"), f.width);
    let input = input.resolve().offset(-scroll, 0.0);

    // The box hugs its line; the caller's row centres it with `cross_pos`, so the typeface's
    // line height decides the position, not a widget constant.
    // 盒子紧贴行高，由调用方的行用 `cross_pos` 居中它：落位由字面行高决定，而非控件常量。
    let mut content = Decl::container(f.id.with("content"), NodeKind::Stack)
        .size(SizeClass {
            width: AxisSize::fixed(f.width),
            height: AxisSize::hug(0.0, 0.0),
            grow_x: Grow::No,
            grow_y: Grow::No,
        })
        // A nowrap query runs past the field; cutting it here is what keeps the overflow
        // out of sight, and the renderer then skips the glyphs entirely.
        // 单行查询会跑出字段之外；在这里裁剪才能挡住溢出，渲染器随后会整块跳过这些字形。
        .clip(Clip { x: Overflow::Hidden, y: Overflow::Visible })
        .child(input);
    if f.text.is_empty() && f.preedit.is_none() && !f.hint.is_empty() {
        content = content.child(
            Text::new(f.id.with("hint"), f.hint.to_string(), f.size, f.hint_ink)
                .weight(f.weight)
                .max_width(f.width)
                .resolve(),
        );
    }
    content
}

impl Widget for Md3SearchBar {
    fn decl(&self, cx: &Cx<'_, '_>) -> Decl {
        let lead_w = if self.leading.is_some() { ACTION_BOX } else { 0.0 };
        let actions_w = self.actions.len() as f32 * ACTION_BOX;
        let input_w = (self.width - self.pad_l - self.pad_r - lead_w - actions_w).max(0.0);
        let content = query_field(
            cx,
            QueryField {
                id: self.id,
                text: &self.text,
                caret: self.caret,
                preedit: self.preedit.as_ref(),
                painted: self.painted.clone(),
                size: self.input_size,
                weight: self.input_weight,
                ink: self.input_ink,
                hint: &self.hint,
                hint_ink: self.hint_ink,
                caret_ink: self.caret_ink,
                width: input_w,
            },
        );

        let mut bar = Decl::container(self.id, NodeKind::Row)
            .size(SizeClass::fixed(self.width, SEARCH_BAR_HEIGHT))
            .padding(Insets {
                left: self.pad_l,
                top: 0.0,
                right: self.pad_r,
                bottom: 0.0,
            })
            .cross_align(0.0)
            // A row's cross axis is vertical: this centres the query line in the bar.
            // 行的交叉轴是垂直方向：这一行把查询行居中于栏内。
            .cross_pos(0.5)
            .shapes(self.shapes())
            .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
            .cursor(if self.disabled {
                CursorShape::Arrow
            } else {
                CursorShape::Text
            })
            .disabled(self.disabled)
            .text_input(self.text.clone());
        if let Some((source, ink)) = self.leading {
            bar = bar.child(icon_box(self.id.with("leading"), source, ink, SEARCH_BAR_HEIGHT));
        }
        bar = bar.child(content);
        for (action, ink) in &self.actions {
            bar = bar.child(
                icon_box(action.id, action.icon, *ink, SEARCH_BAR_HEIGHT).sense(Sense::CLICK),
            );
        }
        bar
    }

    fn change(&self, _state: &WidgetState, _bounds: ui_core::geom::Rect) -> Option<Change> {
        Some(Change::Data(Box::new(SearchBarChange::Action(self.fired?))))
    }
}

/// Resolve the export for one state; the contained variant also decides the end insets.
/// 解析某个状态下的导出值；容纳式变体同时决定两端的内部留白。
fn parts(contained: bool, has_actions: bool, hovered: bool, pressed: bool) -> SearchBarSpec {
    search_bar_spec(contained, false, false, has_actions, hovered, pressed)
}
