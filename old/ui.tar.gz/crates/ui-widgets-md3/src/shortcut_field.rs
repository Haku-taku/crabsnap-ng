//! MD3 shortcut field: an outlined box that captures the next chord and shows it.
//! MD3 快捷键字段：一个描边盒子，捕获下一个组合键并把它显示出来。

use ui_core::geom::{Color, Corners, Insets};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::{CursorShape, Decl, Id, KeyChord, Modifiers, NodeKind};
use ui_style::Style;
use ui_widgets::{modifiers_label, shortcut_label, Cx, Text, Widget};

use crate::toggle::role;

/// The box's height, matching the text field it usually sits beside.
/// 盒子的高度，与它通常并排的文本字段一致。
pub const SHORTCUT_FIELD_HEIGHT: f32 = 56.0;
/// `rounded_corners` on the MD3 shape scale.
/// MD3 形状刻度上的 `rounded_corners`。
const RADIUS: f32 = 4.0;
const PAD: f32 = 16.0;
const LABEL_SIZE: f32 = 16.0;

/// Everything a shortcut field is built with; the app owns the bound chord.
/// 构建快捷键字段所需的一切；已绑定的组合键归应用所有。
pub struct ShortcutFieldParams<'a> {
    pub id: Id,
    /// The chord currently bound; `None` shows the placeholder.
    /// 当前绑定的组合键；`None` 时显示占位文本。
    pub chord: Option<KeyChord>,
    pub placeholder: &'a str,
    pub width: f32,
    pub disabled: bool,
}

/// One MD3 shortcut field; focus it and the next chord pressed is captured.
/// 一个 MD3 快捷键字段；聚焦后按下的下一个组合键即被捕获。
pub struct Md3ShortcutField {
    id: Id,
    chord: Option<KeyChord>,
    placeholder: String,
    width: f32,
    disabled: bool,
    outline: Color,
    accent: Color,
    ink: Color,
    hint: Color,
}

impl Md3ShortcutField {
    pub fn new(params: ShortcutFieldParams<'_>, pack: &Style) -> Self {
        Self {
            id: params.id,
            chord: params.chord,
            placeholder: params.placeholder.to_string(),
            width: params.width,
            disabled: params.disabled,
            outline: role(pack, "outline"),
            accent: role(pack, "primary"),
            ink: role(pack, "on_surface"),
            hint: role(pack, "on_surface_variant"),
        }
    }

    /// What the box reads right now: the bound chord, or the modifiers being held.
    /// 盒子此刻显示的内容：已绑定的组合键，或正按住的修饰键。
    fn shown(&self, focused: bool, held: Modifiers, cx: &Cx<'_, '_>) -> (String, bool) {
        if focused && !held.is_empty() {
            // Live preview: the chord under construction, before any key lands.
            // 实时预览：尚未落键、正在拼的组合。
            let mut out = modifiers_label(held, cx);
            out.push('…');
            return (out, false);
        }
        match &self.chord {
            Some(chord) => (shortcut_label(chord, cx), false),
            None => (self.placeholder.clone(), true),
        }
    }
}

impl Widget for Md3ShortcutField {
    fn decl(&self, cx: &Cx<'_, '_>) -> Decl {
        let state = cx.state(self.id);
        let focused = state.focused;
        let (shown, is_hint) = self.shown(focused, state.modifiers, cx);
        let edge = if focused { self.accent } else { self.outline };
        let width = if focused { 2.0 } else { 1.0 };
        let text = Text::new(
            self.id.with("value"),
            shown,
            LABEL_SIZE,
            if is_hint { self.hint } else { self.ink },
        );
        Decl::container(self.id, NodeKind::Box)
            .size(SizeClass {
                width: AxisSize::fixed(self.width),
                height: AxisSize::fixed(SHORTCUT_FIELD_HEIGHT),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets {
                left: PAD,
                top: 0.0,
                right: PAD,
                bottom: 0.0,
            })
            .background(Color::TRANSPARENT, Corners::all(RADIUS))
            .border(edge, width)
            // Capture, not navigation: the editor must see the chord it is about to bind.
            // 是捕获而非导航：编辑器必须看到它即将绑定的那个组合。
            .sense(ui_core::Sense::CLICK | ui_core::Sense::FOCUSABLE | ui_core::Sense::CAPTURE_KEYS)
            .cursor(CursorShape::Text)
            .disabled(self.disabled)
            .child(text.resolve())
    }
}
