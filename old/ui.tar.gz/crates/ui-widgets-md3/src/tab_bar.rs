//! MD3 secondary navigation tabs: equal-width tabs over a 1dp divider, a 2dp primary
//! underline under the selected one, and the label ink crossfading between the two roles.
//! MD3 次级导航页签：等宽页签铺在 1dp 分隔线上，选中项下压一条 2dp 主色下划线，
//! 标签色在两种角色之间交叉淡变。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Insets, Point};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::{AnimSpec, CursorShape, Decl, Easing, Id, InkRadius, NodeKind, PressInk, Sense, Weight};
use ui_style::Style;
use ui_widgets::build::param;
use ui_widgets::text::Text;
use ui_widgets::{Cx, IconSource, Widget, WidgetState};

use crate::layer::press_ink;
use crate::spec::secondary_navigation_tab_spec;
use crate::toggle::{between, role, spec_ink};
use crate::Md3Options;

/// `_kTabHeight`: the text-only tab's box; the bar adds the indicator band below it.
/// `_kTabHeight`：纯文字页签的盒子；栏在它下方再加上下划线的工带。
pub const TAB_HEIGHT: f32 = 46.0;
/// `_kTextAndIconTabHeight`: a tab carrying a 24dp mark grows to this.
/// `_kTextAndIconTabHeight`：带 24dp 图标的页签长到这个高度。
pub const TAB_ICON_HEIGHT: f32 = 72.0;
/// `kTabLabelPadding`: the label's horizontal breathing room.
/// `kTabLabelPadding`：标签左右的内缩。
pub const TAB_LABEL_PAD: f32 = 16.0;
/// `_TabsPrimaryDefaultsM3.iconMargin`, which `Tab.build` uses for M3 either way.
/// `_TabsPrimaryDefaultsM3.iconMargin`，M3 下 `Tab.build` 无论主次都用它。
pub const TAB_ICON_MARGIN: f32 = 2.0;
/// `_TabsSecondaryDefaultsM3.dividerHeight`; the export deprecated its own divider tokens.
/// `_TabsSecondaryDefaultsM3.dividerHeight`；导出已废弃自己的分隔线令牌。
pub const TAB_DIVIDER: f32 = 1.0;

/// `kTabScrollDuration`: the controller's travel, which drives the ink crossfade.
/// `kTabScrollDuration`：控制器的行程，它驱动标签色的交叉淡变。
const INK: AnimSpec = AnimSpec::new(0.3, Easing::Linear);
/// The web demo's indicator travel: 250ms on `EASING.EMPHASIZED`, not Flutter's 300ms.
/// 网页 demo 的下划线行程：250ms、`EASING.EMPHASIZED`，而不是 Flutter 的 300ms。
const INDICATOR: AnimSpec = AnimSpec::new(0.25, Easing::Cubic(0.3, 0.0, 0.0, 1.0));
/// `kRadialReactionDuration`.
/// `kRadialReactionDuration`。
const REACTION: AnimSpec = AnimSpec::new(0.1, Easing::Linear);

/// One tab: the id the app knows it by, its label, and, for the icon variant, a 24dp mark
/// built in the tab's own ink.
/// 一个页签：应用认识它的 id、标签；带图标的变体还要一个按页签自身墨色绘制的 24dp 标记。
pub struct Md3TabItem<'a> {
    /// Owned by the app, so a reported `Change::Selected` names something it can map back.
    /// 归应用所有，使上报的 `Change::Selected` 指向它认得出的东西。
    pub id: Id,
    pub label: &'a str,
    /// `None` is the text-only tab; `Some(f)` builds the mark at `id` in the given ink.
    /// `None` 表示纯文字页签；`Some(src)` 按给定墨色在 `id` 处解析标记。
    pub icon: Option<IconSource>,
}

impl<'a> Md3TabItem<'a> {
    /// A text-only tab.
    /// 纯文字页签。
    pub fn text(id: Id, label: &'a str) -> Self {
        Self { id, label, icon: None }
    }

    /// A tab with a 24dp mark above its label.
    /// 标签上方带 24dp 标记的页签。
    pub fn with_icon(id: Id, label: &'a str, icon: IconSource) -> Self {
        Self { id, label, icon: Some(icon) }
    }
}

/// One tab's resolved paint data.
/// 一个页签解析后的绘制数据。
struct Tab {
    id: Id,
    label: String,
    label_ink: Color,
    icon: Option<(IconSource, Color)>,
    /// The state layer over the whole tab, already carrying its animated alpha.
    /// 覆盖整个页签的状态层，已带上动画后的透明度。
    layer: Option<Color>,
    /// The press ink the engine splats at the pointer.
    /// 引擎在指针处泼出的按压墨迹。
    press: Option<PressInk>,
    /// The keyboard focus ring's alpha; 0 when it is not showing.
    /// 键盘焦点环的透明度；不显示时为 0。
    ring: f32,
}

/// A secondary navigation tab bar; the app owns which tab is selected.
/// 次级导航页签栏；选中项归应用所有。
pub struct Md3TabBar {
    id: Id,
    tabs: Vec<Tab>,
    /// The tab's own box height, before the indicator band.
    /// 页签自身盒子的高度，不含下划线的工带。
    content_h: f32,
    selected: usize,
    /// The bar's laid-out width, which the engine cannot hand to `decl`; the underline's
    /// travel is one share of it, so without it there is no slide.
    /// 栏的布局宽度，引擎无法在 `decl` 阶段提供；下划线的行程是它的一个份额，没有它就滑不起来。
    width: f32,
    /// How far the underline has travelled, in tabs.
    /// 下划线已经走过的距离，以页签为单位。
    slide: f32,
    label_size: f32,
    label_weight: Weight,
    icon_size: f32,
    indicator: Color,
    ring_colour: Color,
    ring_width: f32,
    divider: Color,
    disabled: bool,
}

impl Md3TabBar {
    /// Same control with explicit parameters, so the semantic path and a direct caller
    /// produce identical `Decl`s.
    /// 带显式参数的同一控件，使语义路径与直接调用产出相同的 `Decl`。
    pub fn new_with(
        params: Md3Options,
        id: Id,
        items: &[Md3TabItem<'_>],
        selected: usize,
        width: f32,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let with_icon = items.iter().any(|t| t.icon.is_some());
        let base = secondary_navigation_tab_spec(false, with_icon, false, false, false);
        let active = secondary_navigation_tab_spec(true, with_icon, false, false, false);
        // The state layer's ink only exists under hover/focus/pressed in the export, so ask
        // for the hovered set to read it; it is `onSurface` in all three.
        // 状态层的颜色在导出里只挂在悬停/聚焦/按下上，因此按悬停读它；三处都是 `onSurface`。
        let layer_ink = role(
            pack,
            secondary_navigation_tab_spec(false, with_icon, true, false, false).state_layer.color,
        );
        let disabled = params.disabled || cx.state(id).disabled;
        // The export defines no disabled inks; MD3's rule for disabled content is 38%.
        // 导出没有禁用配色；MD3 对禁用内容的规定是 38%。
        let ink_fade = if disabled { crate::DISABLED_CONTENT_OPACITY } else { 1.0 };
        let mut tabs = Vec::with_capacity(items.len());
        for (k, item) in items.iter().enumerate() {
            let tab_id = item.id;
            let mut node = cx.at(tab_id);
            let state = node.state();
            // The ink is keyed on the tab's own interaction state, as Flutter's `_TabStyle`.
            // 墨色跟随页签自身的交互状态，与 Flutter 的 `_TabStyle` 一致。
            let on = secondary_navigation_tab_spec(true, with_icon, state.hovered, state.focus_visible, state.pressed);
            let off = secondary_navigation_tab_spec(false, with_icon, state.hovered, state.focus_visible, state.pressed);
            let select = node.animate(tab_id.with(param::PROGRESS), f32::from(k == selected), INK);
            let label_ink = faded(
                between(
                    spec_ink(pack, off.label_text.color, 1.0),
                    spec_ink(pack, on.label_text.color, 1.0),
                    select,
                ),
                ink_fade,
            );
            let icon_ink = faded(
                between(
                    spec_ink(pack, off.icon.color, 1.0),
                    spec_ink(pack, on.icon.color, 1.0),
                    select,
                ),
                ink_fade,
            );
            // Flutter's overlay priority: pressed 10%, hovered 8%, focused 10%. The press is
            // a splat from the pointer, so only hover and focus stay in the flat layer.
            // Flutter 的状态层优先级：按下 10%、悬停 8%、聚焦 10%。按下自指针泼出，
            // 因此平坦层里只剩悬停与聚焦。
            let hover = node.animate(tab_id.with(param::HOVER), f32::from(state.hovered), REACTION);
            let focus = node.animate(tab_id.with(param::FOCUS), f32::from(state.focus_visible), REACTION);
            let alpha = (hover * 0.08).max(focus * 0.1);
            let layer = (alpha > 0.0 && !disabled)
                .then_some(Color { a: layer_ink.a * alpha, ..layer_ink });
            let press = (!disabled).then(|| {
                press_ink(Color { a: layer_ink.a * 0.1, ..layer_ink }, InkRadius::Cover)
            });
            let ring = if disabled {
                0.0
            } else {
                node.animate(tab_id.with(param::THICKNESS), f32::from(state.focus_visible), REACTION)
            };
            tabs.push(Tab {
                id: tab_id,
                label: item.label.to_string(),
                label_ink,
                icon: item.icon.map(|f| (f, icon_ink)),
                layer,
                press,
                ring,
            });
        }
        let slide = cx
            .at(id)
            .animate(id.with(param::PROGRESS), selected as f32, INDICATOR);
        Self {
            id,
            tabs,
            content_h: if with_icon { TAB_ICON_HEIGHT } else { TAB_HEIGHT },
            selected,
            width,
            slide,
            label_size: base.label_text.size,
            label_weight: Weight(base.label_text.weight as u16),
            icon_size: if with_icon { active.icon.size } else { 0.0 },
            indicator: spec_ink(pack, active.active_indicator.color, 1.0),
            ring_colour: spec_ink(pack, base.focus_indicator.color, 1.0),
            ring_width: base.focus_indicator.thickness,
            divider: role(pack, "outlineVariant"),
            disabled,
        }
    }

    /// The tab strip's height: the tab box plus the band its underline occupies.
    /// 页签带的高度：页签盒子加上下划线占的工带。
    pub fn strip_height(&self) -> f32 {
        self.content_h + self.indicator_height()
    }

    /// The whole control's height, divider included.
    /// 整个控件的高度，含分隔线。
    pub fn height(&self) -> f32 {
        self.strip_height() + TAB_DIVIDER
    }

    /// Which tab a point in the bar's own space belongs to; the divider belongs to none.
    /// 栏内某个点属于哪个页签；落在分隔线上则不属于任何页签。
    pub fn tab_at(&self, local: Point, width: f32) -> Option<usize> {
        if self.tabs.is_empty() || local.y < 0.0 || local.y > self.strip_height() || width <= 0.0 {
            return None;
        }
        let share = width / self.tabs.len() as f32;
        Some(((local.x / share).floor().max(0.0) as usize).min(self.tabs.len() - 1))
    }

    /// One tab node: its state layer and focus ring, its centred content, its underline.
    /// 一个页签节点：状态层与焦点环、居中的内容、下划线。
    fn tab_decl(&self, tab: &Tab) -> Decl {
        let mut shapes = Vec::with_capacity(2);
        if let Some(layer) = tab.layer {
            shapes.push(boxed(layer, None));
        }
        // The export insets the ring by `outline.offset` (negative), which needs a width the
        // decl does not have; it is drawn on the tab's own edge instead.
        // 导出要求焦点环内缩 `outline.offset`（负值），而声明阶段拿不到宽度；改为画在页签边缘。
        if tab.ring > 0.0 {
            let ring = Color { a: self.ring_colour.a * tab.ring, ..self.ring_colour };
            shapes.push(boxed(Color::TRANSPARENT, Some((ring, self.ring_width))));
        }
        let label = Text::new(tab.id.with("label"), tab.label.clone(), self.label_size, tab.label_ink)
            .weight(self.label_weight)
            .resolve();
        // `Center(widthFactor: 1)` over a fixed-height box: the content block is centred.
        // `Center(widthFactor: 1)` 套在定高盒里：内容块居中。
        let inner = match tab.icon {
            Some(_) => self.icon_size + TAB_ICON_MARGIN + label.size_class.height.hint,
            None => label.size_class.height.hint,
        };
        let mut content = Decl::container(tab.id.with("content"), NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fixed(self.content_h),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets {
                left: TAB_LABEL_PAD,
                right: TAB_LABEL_PAD,
                top: ((self.content_h - inner) * 0.5).max(0.0),
                bottom: 0.0,
            })
            .gap(TAB_ICON_MARGIN)
            // Children hug their own width and are centred in the space they leave.
            // 子节点按自身宽度并居中于它们让出的空间。
            .cross_align(0.0)
            .cross_pos(0.5);
        if let Some((source, ink)) = tab.icon {
            content = content.child(source.resolve(tab.id.with("icon"), ink));
        }
        content = content.child(label);
        Decl::container(tab.id, NodeKind::Column)
            .size(SizeClass {
                // Equal shares: a zero basis splits the bar evenly whatever the labels are.
                // 等分：零基准把栏平均切开，与标签长短无关。
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fixed(self.strip_height()),
                grow_x: Grow::Split(1),
                grow_y: Grow::No,
            })
            .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
            .cursor(if self.disabled { CursorShape::Arrow } else { CursorShape::PointingHand })
            .disabled(self.disabled)
            .press_ink(tab.press)
            .shapes(shapes)
            .child(content)
    }

    /// The one underline the whole bar shares: it slides to the selected tab instead of each
    /// tab fading its own in and out.
    /// 整条栏共用的一条下划线：它滑到选中项，而不是每个页签各自淡入淡出。
    fn indicator_decl(&self) -> Option<Decl> {
        if self.tabs.is_empty() || self.width <= 0.0 {
            return None;
        }
        let share = self.width / self.tabs.len() as f32;
        // Disabled bars mark no selection at all.
        // 禁用的栏不标出任何选择。
        let alpha = if self.disabled { 0.0 } else { self.indicator.a };
        Some(
            Decl::container(self.id.with("indicator"), NodeKind::Overlay)
                .size(SizeClass::fixed(share, self.indicator_height()))
                .offset(self.slide * share, self.content_h)
                .shapes(vec![boxed(Color { a: alpha, ..self.indicator }, None)]),
        )
    }

    /// `active-indicator.height`, which is also the band the strip reserves for it.
    /// `active-indicator.height`，也是页签带为它预留的工带高度。
    fn indicator_height(&self) -> f32 {
        secondary_navigation_tab_spec(true, false, false, false, false).active_indicator.height
    }
}

impl Widget for Md3TabBar {
    fn handles_disabled(&self) -> bool {
        // The 38% content fade is painted here, so the adapter must not fade again.
        // 38% 的内容淡化在这里绘制，适配器不得再淡化一次。
        true
    }

    fn change(&self, state: &WidgetState, bounds: ui_core::geom::Rect) -> Option<ui_core::Change> {
        // The press point names the tab; the keyboard has none (engine-audit F12).
        // 按下点指名页签；键盘没有按下点（engine-audit F12）。
        if self.disabled || !state.clicked {
            return None;
        }
        // Tabs are equal shares of the bar, so the press point names one without a lookup.
        // 页签等分栏宽，因此按下点无需查表就能指出是哪一个。
        let k = self.tab_at(state.local?, bounds.size.w)?;
        // Re-selecting the tab that is already selected is not a change; Flutter still calls
        // `onTap`, but the semantic door here reports only movement.
        // 重复选中当前页签不算变化；Flutter 仍会调 `onTap`，但这里的语义门只上报移动。
        (k != self.selected).then(|| ui_core::Change::Selected(Some(self.tabs[k].id)))
    }

    fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
        let fill = || AxisSize::fill(0.0, 0.0);
        let mut row = Decl::container(self.id.with("tabs"), NodeKind::Row).size(SizeClass {
            width: fill(),
            height: AxisSize::fixed(self.strip_height()),
            grow_x: Grow::No,
            grow_y: Grow::No,
        });
        for tab in &self.tabs {
            row = row.child(self.tab_decl(tab));
        }
        let divider = Decl::container(self.id.with("divider"), NodeKind::Column)
            .size(SizeClass {
                width: fill(),
                height: AxisSize::fixed(TAB_DIVIDER),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .shapes(vec![boxed(self.divider, None)]);
        let mut root = Decl::container(self.id, NodeKind::Column)
            .size(SizeClass {
                width: fill(),
                height: AxisSize::fixed(self.height()),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .child(row)
            .child(divider);
        if let Some(indicator) = self.indicator_decl() {
            root = root.child(indicator);
        }
        root
    }
}

/// Multiply a colour's alpha, so a disabled bar fades its inks once.
/// 乘上颜色的 alpha，使禁用的栏只淡化一次。
fn faded(c: Color, k: f32) -> Color {
    Color { a: c.a * k, ..c }
}

/// A node-sized box: it follows whatever rect the layout hands the node.
/// 节点大小的盒子：跟随布局给节点的矩形。
fn boxed(fill: Color, border: Option<(Color, f32)>) -> Shape {
    Shape::Box {
        corners: Corners::ZERO,
        fill,
        gradient: None,
        border,
        shadow: None,
        image: None,
    }
}
