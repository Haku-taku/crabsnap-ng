//! MD3 date picker (docked): header, month/year buttons, weekday row and a 6×7 day grid.
//! MD3 日期选择器（停靠式）：标题、年月按钮、星期行与 6×7 的日期网格。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Insets, Rect};
use ui_core::layout::{AxisSize, Grow, OverlayAlign, SizeClass};
use ui_core::tree::ShadowSpec;
use ui_core::{AnimSpec, Change, CursorShape, Decl, Easing, Id, InkRadius, NodeKind, Sense, Weight};
use ui_style::Style;
use ui_widgets::build::param;
use ui_widgets::text::Text;
use ui_widgets::{Cx, Icon, Widget, WidgetState};

use crate::layer::{press_ink, Background};
use crate::spec::{date_picker_spec, DatePickerSpec};
use crate::toggle::spec_ink;
use crate::typescale::{self, TypeStyle};

/// `container.width`: the docked surface's box width.
/// `container.width`：停靠表面的盒子宽度。
pub const DATE_PICKER_WIDTH: f32 = 360.0;
/// `container.height`: the docked surface's box height.
/// `container.height`：停靠表面的盒子高度。
pub const DATE_PICKER_HEIGHT: f32 = 456.0;
/// `header.height`.
/// `header.height`。
pub const DATE_PICKER_HEADER: f32 = 64.0;
/// `menu-button.container.height`: the month, year and arrow buttons.
/// `menu-button.container.height`：月份、年份与箭头按钮的高度。
pub const DATE_PICKER_BUTTON: f32 = 40.0;
/// `date.container.width`: one day cell.
/// `date.container.width`：一个日期格。
pub const DATE_PICKER_CELL: f32 = 48.0;
/// `date.state-layer.width`: the disc inside a day cell.
/// `date.state-layer.width`：日期格内的圆盘。
pub const DATE_PICKER_DISC: f32 = 40.0;
/// The surface's corner: MD3's extra-large shape.
/// 表面的圆角：MD3 的 extra-large 形状。
pub const DATE_PICKER_RADIUS: f32 = 28.0;
/// Side inset of the grid and of the weekday row.
/// 网格与星期行的侧向内衬。
pub const DATE_PICKER_SIDE: f32 = 12.0;
/// The grid is six weeks tall in every month, so no month resizes the surface.
/// 网格恒为六周高，因此没有哪个月会改变表面尺寸。
pub const DATE_PICKER_WEEKS: usize = 6;
/// `date.disabled` has no token in the export; 38% is MD3's disabled label strength. The
/// export dims outside-month days to the same 38%, so this build keeps their role instead.
/// 导出没有 `date.disabled` 令牌；38% 是 MD3 禁用标签的强度。导出把邻月日期也压到
/// 同一个 38%，因此本实现改用角色区分邻月。
pub const DATE_PICKER_DISABLED_OPACITY: f32 = 0.38;

/// `kRadialReactionDuration`.
/// `kRadialReactionDuration`。
const REACTION: AnimSpec = AnimSpec::new(0.1, Easing::Linear);

/// The id of the cell standing for `date` inside the picker `picker`: the derivation lives
/// here, so a caller that only has the two ids can address the cell without guessing.
/// 选择器 `picker` 中代表 `date` 的格子 id：派生规则放在这里，只有两个 id 的调用方
/// 不必猜就能寻址该格子。
pub fn day_cell_id(picker: Id, date: Date) -> Id {
    Id::of((&picker, "day", date.year, date.month, date.day))
}

/// The id of the month cell for `month` (1–12) in the picker `picker`.
/// 选择器 `picker` 中代表 `month`（1–12）的月份格 id。
pub fn month_cell_id(picker: Id, month: u8) -> Id {
    Id::of((&picker, "month-cell", month))
}

/// The id of the year cell for `year` in the picker `picker`.
/// 选择器 `picker` 中代表 `year` 的年份格 id。
pub fn year_cell_id(picker: Id, year: i32) -> Id {
    Id::of((&picker, "year-cell", year))
}

/// A civil date: no time, no zone, no clock. Months and days are 1-based.
/// 一个民用日期：无时间、无时区、无时钟。月与日都从 1 开始。
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord)]
pub struct Date {
    pub year: i32,
    /// 1–12.
    pub month: u8,
    /// 1–31, bounded by the month.
    /// 1–31，受所在月约束。
    pub day: u8,
}

impl Date {
    /// A date, or `None` when that month or day cannot exist.
    /// 一个日期；该月或该日不存在时返回 `None`。
    pub fn new(year: i32, month: u8, day: u8) -> Option<Self> {
        ((1..=12).contains(&month) && day >= 1 && day <= Self::days_in_month(year, month))
            .then_some(Self { year, month, day })
    }

    /// The Gregorian length of a month, leap years included.
    /// 格里高利历下一个月的天数，含闰年。
    pub fn days_in_month(year: i32, month: u8) -> u8 {
        match month {
            1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
            4 | 6 | 9 | 11 => 30,
            2 if year % 4 == 0 && (year % 100 != 0 || year % 400 == 0) => 29,
            2 => 28,
            _ => 0,
        }
    }

    /// Days since 1970-01-01, by Howard Hinnant's `days_from_civil`.
    /// 距 1970-01-01 的天数，用 Howard Hinnant 的 `days_from_civil`。
    fn days_since_epoch(self) -> i64 {
        let y = if self.month <= 2 { self.year - 1 } else { self.year } as i64;
        let era = if y >= 0 { y } else { y - 399 } / 400;
        let yoe = y - era * 400;
        let mp = (self.month as i64 + 9) % 12;
        let doy = (153 * mp + 2) / 5 + self.day as i64 - 1;
        let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
        era * 146_097 + doe - 719_468
    }

    /// The weekday this date falls on.
    /// 这一天是星期几。
    pub fn weekday(self) -> Weekday {
        // 1970-01-01 was a Thursday, which is index 3 counted from Monday.
        // 1970-01-01 是星期四；从星期一起算是 3。
        Weekday::ALL[(((self.days_since_epoch() + 3) % 7 + 7) % 7) as usize]
    }

    /// The same month, on its first day.
    /// 同一个月，取第一天。
    pub fn first_of_month(self) -> Date {
        Date { day: 1, ..self }
    }

    /// The month `delta` months away, the day clamped into whatever the target month allows.
    /// 相隔 `delta` 个月的那个月，日数被夹进目标月允许的范围。
    pub fn add_months(self, delta: i32) -> Date {
        let zero = self.year * 12 + self.month as i32 - 1 + delta;
        let year = zero.div_euclid(12);
        let month = zero.rem_euclid(12) as u8 + 1;
        let day = self.day.min(Self::days_in_month(year, month));
        Date { year, month, day }
    }
}

/// A day of the week; the calendar's columns start at whichever one the app picks.
/// 星期中的一天；日历的列从应用选定的那天开始。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Weekday {
    Mon,
    Tue,
    Wed,
    Thu,
    Fri,
    Sat,
    Sun,
}

impl Weekday {
    /// Monday first, which is also the index order.
    /// 从星期一起，也正是下标顺序。
    pub const ALL: [Weekday; 7] = [
        Weekday::Mon,
        Weekday::Tue,
        Weekday::Wed,
        Weekday::Thu,
        Weekday::Fri,
        Weekday::Sat,
        Weekday::Sun,
    ];

    /// The 0-based index of `self` counted from Monday.
    /// 从星期一起算 `self` 的 0 基下标。
    pub fn index(self) -> u8 {
        Weekday::ALL.iter().position(|w| *w == self).unwrap_or(0) as u8
    }

    /// This weekday's 0-based column when the week starts at `start`.
    /// 一周从 `start` 开始时，这一天所在的 0 基列号。
    pub fn column(self, start: Weekday) -> u8 {
        (self.index() + 7 - start.index()) % 7
    }
}

/// What the body of the picker shows.
/// 选择器主体当前显示什么。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DatePickerView {
    /// The 6×7 day grid.
    /// 6×7 的日期网格。
    Days,
    /// Twelve month names.
    /// 十二个月份名。
    Months,
    /// Twelve years.
    /// 十二个年份。
    Years,
}

/// The words a calendar cannot invent: month names, weekday initials and the title.
/// 日历无法自造的词：月份名、星期缩写与标题。
///
/// The app owns them so they can come from Fluent; the widget only draws what it is given.
/// 归应用所有，以便来自 Fluent；控件只画交给它的那些字。
#[derive(Clone, Debug)]
pub struct CalendarLabels {
    /// January first.
    /// 从一月开始。
    pub months: [std::sync::Arc<str>; 12],
    /// Monday first, matching [`Weekday::ALL`].
    /// 从星期一开始，与 [`Weekday::ALL`] 一致。
    pub weekdays: [std::sync::Arc<str>; 7],
    pub header: std::sync::Arc<str>,
}

impl CalendarLabels {
    /// Read every label from the catalog in force.
    /// 从当前生效的 catalog 读取全部标签。
    pub fn from_cx(cx: &Cx<'_, '_>) -> Self {
        Self {
            months: [
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_MONTH_JANUARY),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_MONTH_FEBRUARY),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_MONTH_MARCH),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_MONTH_APRIL),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_MONTH_MAY),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_MONTH_JUNE),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_MONTH_JULY),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_MONTH_AUGUST),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_MONTH_SEPTEMBER),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_MONTH_OCTOBER),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_MONTH_NOVEMBER),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_MONTH_DECEMBER),
            ],
            weekdays: [
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_WEEKDAY_MON),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_WEEKDAY_TUE),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_WEEKDAY_WED),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_WEEKDAY_THU),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_WEEKDAY_FRI),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_WEEKDAY_SAT),
                cx.t(ui_i18n::Msg::MD3_DATE_PICKER_WEEKDAY_SUN),
            ],
            header: cx.t(ui_i18n::Msg::MD3_DATE_PICKER_HEADER),
        }
    }

    /// The name of a 1-based month.
    /// 从 1 开始的月份名。
    pub fn month(&self, month: u8) -> &str {
        &self.months[(month.clamp(1, 12) - 1) as usize]
    }
}

/// The catalog's name for a 1-based month, for readouts beside a picker.
/// catalog 给出的、从 1 开始的月份名，供选择器旁的读数使用。
pub fn month_label(cx: &Cx<'_, '_>, month: u8) -> std::sync::Arc<str> {
    cx.t(month_msg(month))
}

fn month_msg(month: u8) -> ui_i18n::Msg {
    use ui_i18n::Msg;
    match month.clamp(1, 12) {
        1 => Msg::MD3_DATE_PICKER_MONTH_JANUARY,
        2 => Msg::MD3_DATE_PICKER_MONTH_FEBRUARY,
        3 => Msg::MD3_DATE_PICKER_MONTH_MARCH,
        4 => Msg::MD3_DATE_PICKER_MONTH_APRIL,
        5 => Msg::MD3_DATE_PICKER_MONTH_MAY,
        6 => Msg::MD3_DATE_PICKER_MONTH_JUNE,
        7 => Msg::MD3_DATE_PICKER_MONTH_JULY,
        8 => Msg::MD3_DATE_PICKER_MONTH_AUGUST,
        9 => Msg::MD3_DATE_PICKER_MONTH_SEPTEMBER,
        10 => Msg::MD3_DATE_PICKER_MONTH_OCTOBER,
        11 => Msg::MD3_DATE_PICKER_MONTH_NOVEMBER,
        _ => Msg::MD3_DATE_PICKER_MONTH_DECEMBER,
    }
}

/// Everything the picker is built with; all of it is the app's, none of it is the widget's.
/// 构建选择器所需的一切；全部归应用，控件自己不持有状态。
pub struct DatePickerParams {
    pub id: Id,
    /// The chosen date, drawn filled.
    /// 选中的日期，画成实心。
    pub value: Option<Date>,
    /// The month on screen.
    /// 屏幕上的那个月。
    pub shown: Date,
    /// The day drawn with an outline.
    /// 画成描边的那一天。
    pub today: Date,
    pub view: DatePickerView,
    /// Labels to draw; `None` reads them from the catalog in force.
    /// 要绘制的标签；`None` 表示从当前生效的 catalog 读取。
    pub labels: Option<CalendarLabels>,
    /// Earliest selectable day; cells before it are inert.
    /// 可选的最早一天；更早的格子是惰性的。
    pub min: Option<Date>,
    pub max: Option<Date>,
    /// The column the week starts on.
    /// 一周从哪一列开始。
    pub week_start: Weekday,
}

impl DatePickerParams {
    /// A picker showing `today`'s month with nothing chosen.
    /// 显示 `today` 所在月、未选中任何日期的选择器。
    pub fn new(id: Id, today: Date) -> Self {
        Self {
            id,
            value: None,
            shown: today.first_of_month(),
            today,
            view: DatePickerView::Days,
            labels: None,
            min: None,
            max: None,
            week_start: Weekday::Mon,
        }
    }
}

/// What the picker asks its app to remember.
/// 选择器请应用记住的东西。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DatePickerChange {
    /// A day was chosen.
    /// 选中了一天。
    Picked(Date),
    /// The month on screen moved, and the body may switch view in the same step.
    /// 屏幕上的月份移动了，主体可在同一步切换视图。
    Shown { date: Date, view: DatePickerView },
    /// The body switched view without moving the month.
    /// 主体切换了视图，月份没动。
    View(DatePickerView),
}

/// One action the user took this frame, found at build time from the cells' own state.
/// 本帧用户做的一个动作，在构建期从各格子的状态里找出。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum Action {
    Day(Date),
    Prev,
    Next,
    MonthButton,
    YearButton,
    Month(u8),
    Year(i32),
}

/// One state combination to look up: the generated table takes these as flags.
/// 一种要查的状态组合：生成的表以开关形式接收它们。
#[derive(Clone, Copy, Default)]
struct Flags {
    selected: bool,
    date: bool,
    header: bool,
    list_item: bool,
    menu: bool,
    menu_button: bool,
    outside_month: bool,
    today: bool,
    weekdays: bool,
    hovered: bool,
    focused: bool,
    pressed: bool,
    disabled: bool,
}

impl Flags {
    /// The table's own answer for this combination.
    /// 表对这套组合的答案。
    fn get(self) -> DatePickerSpec {
        date_picker_spec(
            self.selected,
            self.date,
            self.header,
            self.list_item,
            self.menu,
            self.menu_button,
            self.outside_month,
            self.today,
            self.weekdays,
            self.hovered,
            self.focused,
            self.pressed,
            self.disabled,
        )
    }
}

/// The inks this frame resolves to, so assembling the decl repeats no token lookups.
/// 本帧解析出的墨色，组装声明时不必再查令牌。
#[derive(Clone, Copy)]
struct Palette {
    surface: Color,
    on_surface: Color,
    on_surface_variant: Color,
    primary: Color,
    on_primary: Color,
    /// The strength an unselectable day's label keeps.
    /// 不可选日期标签保留的强度。
    disabled_opacity: f32,
    /// `date.hover.state-layer.opacity`.
    /// `date.hover.state-layer.opacity`。
    hover_opacity: f32,
    /// `date.pressed.state-layer.opacity`.
    /// `date.pressed.state-layer.opacity`。
    press_opacity: f32,
    elevation: f32,
    cell: f32,
    disc: f32,
    button: f32,
    day_label: TypeStyle,
    menu_label: TypeStyle,
    weekday_label: TypeStyle,
}

/// One day cell, resolved.
/// 一个解析完的日期格。
struct DayCell {
    id: Id,
    text: String,
    selected: bool,
    today: bool,
    enabled: bool,
    ink: Color,
    layer: Option<Color>,
    ring: Option<Color>,
}

/// One cell of the month or year grid, resolved.
/// 月/年网格里的一格，已解析。
struct ChoiceCell {
    id: Id,
    text: String,
    chosen: bool,
    width: f32,
    layer: Option<Color>,
    ring: Option<Color>,
}

/// One of the 40dp buttons, resolved.
/// 某个 40dp 按钮，已解析。
struct Button {
    id: Id,
    text: Option<String>,
    icon: Option<&'static str>,
    /// Already dimmed when the view stands the button down.
    /// 视图让按钮停用时，这里已经是压暗后的墨色。
    ink: Color,
    enabled: bool,
    layer: Option<Color>,
    ring: Option<Color>,
}

/// A docked MD3 date picker; the app owns the chosen date, the shown month and the view.
/// 停靠式 MD3 日期选择器；选中日期、显示月份与视图都归应用所有。
pub struct Md3DatePicker {
    id: Id,
    shown: Date,
    view: DatePickerView,
    labels: CalendarLabels,
    week_start: Weekday,
    fired: Option<Action>,
    disabled: bool,
    palette: Palette,
    line: LineHeights,
    weekdays: Vec<(Id, String)>,
    days: Vec<DayCell>,
    months: Vec<ChoiceCell>,
    years: Vec<ChoiceCell>,
    month_button: Button,
    year_button: Button,
    prev: Button,
    next: Button,
}

/// The measured height of one line at each size the picker uses, for vertical centring.
/// 选择器用到的每种字号下，一行文字实测的高度，用于垂直居中。
#[derive(Clone, Copy)]
struct LineHeights {
    day: f32,
    menu: f32,
    weekday: f32,
    header: f32,
}

impl Md3DatePicker {
    /// Resolve this frame's control: palette, every cell's paint, and the one action taken.
    /// 解析本帧的控件：调色板、每个格子的绘制，以及发生的那一个动作。
    pub fn from_pack(pack: &Style, cx: &mut Cx<'_, '_>, params: DatePickerParams) -> Self {
        let base = Flags::default().get();
        let day = Flags { date: true, ..Flags::default() }.get();
        let selected = Flags { selected: true, date: true, ..Flags::default() }.get();
        let hover = Flags { date: true, hovered: true, ..Flags::default() }.get();
        let press = Flags { date: true, pressed: true, ..Flags::default() }.get();
        let button = Flags { menu_button: true, ..Flags::default() }.get();
        let weekdays = Flags { weekdays: true, ..Flags::default() }.get();
        let palette = Palette {
            surface: spec_ink(pack, base.container.color, 1.0),
            on_surface: spec_ink(pack, day.label_text.color, 1.0),
            on_surface_variant: spec_ink(pack, hover.state_layer.color, 1.0),
            primary: spec_ink(pack, selected.container.color, 1.0),
            on_primary: spec_ink(pack, selected.label_text.color, 1.0),
            disabled_opacity: DATE_PICKER_DISABLED_OPACITY,
            hover_opacity: hover.state_layer.opacity,
            press_opacity: press.state_layer.opacity,
            elevation: base.container.elevation,
            cell: day.container.width.max(DATE_PICKER_CELL),
            disc: day.state_layer.width.max(DATE_PICKER_DISC),
            button: button.container.height.max(DATE_PICKER_BUTTON),
            day_label: TypeStyle {
                size: day.label_text.size,
                weight: Weight(day.label_text.weight as u16),
            },
            menu_label: TypeStyle {
                size: button.label_text.size,
                weight: Weight(button.label_text.weight as u16),
            },
            weekday_label: TypeStyle {
                size: weekdays.label_text.size,
                weight: Weight(weekdays.label_text.weight as u16),
            },
        };
        let line = LineHeights {
            day: measure_line(palette.day_label.size),
            menu: measure_line(palette.menu_label.size),
            weekday: measure_line(palette.weekday_label.size),
            header: measure_line(typescale::LABEL_MEDIUM.size),
        };
        let id = params.id;
        let labels = params
            .labels
            .clone()
            .unwrap_or_else(|| CalendarLabels::from_cx(cx));
        let mut me = Self {
            id,
            shown: params.shown.first_of_month(),
            view: params.view,
            labels,
            week_start: params.week_start,
            fired: None,
            disabled: cx.state(id).disabled,
            palette,
            line,
            weekdays: Vec::with_capacity(7),
            days: Vec::with_capacity(DATE_PICKER_WEEKS * 7),
            months: Vec::with_capacity(12),
            years: Vec::with_capacity(12),
            month_button: Button::placeholder(id.with("month")),
            year_button: Button::placeholder(id.with("year")),
            prev: Button::placeholder(id.with("prev")),
            next: Button::placeholder(id.with("next")),
        };
        me.resolve(cx, &params);
        me
    }

    /// The ids a caller (or a test) can address.
    /// 调用方（或测试）可以寻址的那些 id。
    pub fn day_id(&self, date: Date) -> Id {
        day_cell_id(self.id, date)
    }

    pub fn prev_id(&self) -> Id {
        self.prev.id
    }

    pub fn next_id(&self) -> Id {
        self.next.id
    }

    pub fn month_button_id(&self) -> Id {
        self.month_button.id
    }

    pub fn year_button_id(&self) -> Id {
        self.year_button.id
    }

    pub fn month_cell_id(&self, month: u8) -> Id {
        month_cell_id(self.id, month)
    }

    pub fn year_cell_id(&self, year: i32) -> Id {
        year_cell_id(self.id, year)
    }

    /// The month on screen, as the widget resolved it.
    /// 控件解析出的、屏幕上的那个月。
    pub fn shown(&self) -> Date {
        self.shown
    }

    /// Whether a day may be chosen at all.
    /// 某一天是否可选。
    fn selectable(date: Date, min: Option<Date>, max: Option<Date>) -> bool {
        min.is_none_or(|m| date >= m) && max.is_none_or(|m| date <= m)
    }

    /// The 42 cells of the grid: the shown month, the tail of the previous month and the head
    /// of the next, so the surface keeps one height.
    /// 网格的 42 格：本月、上月的尾巴与下月的开头，表面因此只有一种高度。
    pub(crate) fn grid(&self) -> Vec<(Date, bool)> {
        let first = self.shown.first_of_month();
        let lead = first.weekday().column(self.week_start) as u32;
        let days = Date::days_in_month(first.year, first.month) as u32;
        let prev = first.add_months(-1);
        let prev_days = Date::days_in_month(prev.year, prev.month) as u32;
        let next = first.add_months(1);
        let total = (DATE_PICKER_WEEKS * 7) as u32;
        let mut out = Vec::with_capacity(total as usize);
        for i in 0..lead {
            let day = (prev_days - lead + i + 1) as u8;
            out.push((Date { year: prev.year, month: prev.month, day }, false));
        }
        for day in 1..=days {
            out.push((Date { year: first.year, month: first.month, day: day as u8 }, true));
        }
        let mut day = 1;
        while (out.len() as u32) < total {
            out.push((Date { year: next.year, month: next.month, day }, false));
            day += 1;
        }
        out
    }

    /// The twelve years the year view offers: one fixed block, so picking one does not move it.
    /// 年份视图给出的十二年：固定的一块，选中某年不会让它移动。
    fn year_block(&self) -> i32 {
        self.shown.year.div_euclid(12) * 12
    }

    /// How far the arrows move in this view: one month, or one block of twelve years.
    /// 本视图下箭头走多远：一个月，或十二年的整块。
    fn step(&self) -> i32 {
        match self.view {
            DatePickerView::Days => 1,
            // The arrows stand down while the month grid is shown, so this is never used.
            // 月份网格显示时箭头已停用，这条分支不会走到。
            DatePickerView::Months => 0,
            DatePickerView::Years => 12 * 12,
        }
    }

    /// The state layer's ink, or nothing when no pointer is on the cell; the shape it fills
    /// is the cell's own effective background.
    /// 某个格子的状态层墨色；指针不在上面时什么都没有，所填形状是该格自己的有效背景。
    fn layer(&self, cx: &mut Cx<'_, '_>, id: Id, ink: Color) -> Option<Color> {
        let p = self.palette;
        let state = cx.state(id);
        if self.disabled || !(state.hovered || state.pressed || state.focus_visible) {
            return None;
        }
        let mut node = cx.at(id);
        let hover = node.animate(id.with(param::HOVER), if state.hovered { 1.0 } else { 0.0 }, REACTION);
        let press = node.animate(id.with(param::PRESS), if state.pressed { 1.0 } else { 0.0 }, REACTION);
        let fade = if state.pressed {
            p.press_opacity
        } else {
            (hover * p.hover_opacity).max(press * p.press_opacity)
        };
        (fade > 0.0).then_some(Color { a: ink.a * fade, ..ink })
    }

    /// Every resolved piece of the frame, and the one action taken.
    /// 本帧解析出的每一块，以及发生的那一个动作。
    fn resolve(&mut self, cx: &mut Cx<'_, '_>, params: &DatePickerParams) {
        let p = self.palette;
        let id = self.id;
        let (min, max) = (params.min, params.max);
        let value = params.value;

        for (date, inside) in self.grid() {
            let cell_id = self.day_id(date);
            let selected = value == Some(date);
            let today = date == params.today;
            let enabled = Self::selectable(date, min, max) && !self.disabled;
            let layer_ink = if selected {
                p.on_primary
            } else if today {
                p.primary
            } else {
                p.on_surface_variant
            };
            // Two independent channels: the role says which month a day belongs to, the
            // alpha says whether it can be picked — so no category borrows another's look.
            // 两条独立的通道：角色说明日期属于哪个月，透明度说明能否选——
            // 于是没有哪一类借用另一类的外观。
            let role = if inside { p.on_surface } else { p.on_surface_variant };
            let ink = if selected {
                p.on_primary
            } else if !enabled {
                Color { a: role.a * p.disabled_opacity, ..role }
            } else if today {
                p.primary
            } else {
                role
            };
            let layer = if enabled { self.layer(cx, cell_id, layer_ink) } else { None };
            let state = cx.state(cell_id);
            if state.activation() && enabled {
                self.fired = Some(Action::Day(date));
            }
            self.days.push(DayCell {
                id: cell_id,
                text: date.day.to_string(),
                selected,
                today,
                enabled,
                ink,
                layer,
                ring: state.focus_visible.then_some(p.on_surface),
            });
        }

        for i in 0..7u8 {
            let weekday = Weekday::ALL[((self.week_start.index() + i) % 7) as usize];
            let text = self.labels.weekdays[weekday.index() as usize].to_string();
            self.weekdays.push((Id::of((&id, "weekday", i)), text));
        }

        let wide = (DATE_PICKER_WIDTH - 2.0 * DATE_PICKER_SIDE) / 3.0;
        for month in 1..=12u8 {
            let cell_id = self.month_cell_id(month);
            let chosen = value.is_some_and(|v| v.year == self.shown.year && v.month == month);
            let layer_ink = if chosen { p.on_primary } else { p.on_surface_variant };
            let layer = self.layer(cx, cell_id, layer_ink);
            let state = cx.state(cell_id);
            if state.activation() && !self.disabled {
                self.fired = Some(Action::Month(month));
            }
            self.months.push(ChoiceCell {
                id: cell_id,
                text: self.labels.month(month).to_string(),
                chosen,
                width: wide,
                layer,
                ring: state.focus_visible.then_some(p.on_surface),
            });
        }

        let first_year = self.year_block();
        for year in first_year..first_year + 12 {
            let cell_id = self.year_cell_id(year);
            let chosen = value.is_some_and(|v| v.year == year);
            let layer_ink = if chosen { p.on_primary } else { p.on_surface_variant };
            let layer = self.layer(cx, cell_id, layer_ink);
            let state = cx.state(cell_id);
            if state.activation() && !self.disabled {
                self.fired = Some(Action::Year(year));
            }
            self.years.push(ChoiceCell {
                id: cell_id,
                text: year.to_string(),
                chosen,
                width: wide,
                layer,
                ring: state.focus_visible.then_some(p.on_surface),
            });
        }

        let month_text = self.labels.month(self.shown.month).to_string();
        let year_text = self.shown.year.to_string();
        // A month grid spans a whole year, so there is no month to page to and the arrows
        // stand down until the day grid is back; the year grid pages by its own block.
        // 月份网格覆盖整年，没有可翻的月份，因此箭头在回到日期网格前停用；年份网格按整块翻。
        let arrows = self.view != DatePickerView::Months;
        self.month_button = self.button(cx, id.with("month"), Some(month_text), None, Action::MonthButton, true);
        self.year_button = self.button(cx, id.with("year"), Some(year_text), None, Action::YearButton, true);
        self.prev = self.button(cx, id.with("prev"), None, Some("chevron_left"), Action::Prev, arrows);
        self.next = self.button(cx, id.with("next"), None, Some("chevron_right"), Action::Next, arrows);
    }

    /// Resolve one 40dp button: its state layer, its focus ring and the action it fires.
    /// 解析一个 40dp 按钮：状态层、焦点环，以及它会触发的动作。
    fn button(
        &mut self,
        cx: &mut Cx<'_, '_>,
        id: Id,
        text: Option<String>,
        icon: Option<&'static str>,
        action: Action,
        enabled: bool,
    ) -> Button {
        let enabled = enabled && !self.disabled;
        let ink = if enabled {
            self.palette.on_surface_variant
        } else {
            // `menu-button.disabled`: onSurface at 38%.
            // `menu-button.disabled`：onSurface 的 38%。
            let base = self.palette.on_surface;
            Color { a: base.a * DATE_PICKER_DISABLED_OPACITY, ..base }
        };
        let layer = if enabled { self.layer(cx, id, ink) } else { None };
        let state = cx.state(id);
        if state.activation() && enabled {
            self.fired = Some(action);
        }
        Button {
            id,
            text,
            icon,
            ink,
            enabled,
            layer,
            ring: (enabled && state.focus_visible).then_some(self.palette.on_surface),
        }
    }

    /// A ring drawn on the node's own edge.
    /// 画在节点自己边缘上的环。
    fn ring(corners: Corners, ink: Color) -> Shape {
        Shape::Box {
            corners,
            fill: Color::TRANSPARENT,
            gradient: None,
            border: Some((ink, 2.0)),
            shadow: None,
            image: None,
        }
    }

    /// Vertical padding that centres one line of `line` in a box of `height`.
    /// 在 `height` 高的盒子里垂直居中 `line` 高的一行文字所需的上内衬。
    fn centre(height: f32, line: f32) -> Insets {
        Insets { left: 0.0, top: ((height - line) * 0.5).max(0.0), right: 0.0, bottom: 0.0 }
    }

    /// One day cell.
    /// 一个日期格。
    fn day_decl(&self, cell: &DayCell) -> Decl {
        let p = &self.palette;
        let side = p.cell;
        // The effective background is the 40dp disc inside the 48dp touch cell: selection,
        // state layer and ripple all use it, never the square or the touch box around it.
        // 有效背景是 48dp 触控格里那个 40dp 圆盘：选中、状态层与涟漪都用它，
        // 而不是外面的方块或触控盒。
        let inset = (side - p.disc) * 0.5;
        let background =
            Background::new(Rect::new(inset, inset, p.disc, p.disc), Corners::all(p.disc * 0.5));
        let mut shapes = Vec::with_capacity(4);
        if cell.selected {
            shapes.push(background.fill(p.primary));
        }
        if let Some(ink) = cell.layer {
            shapes.push(background.fill(ink));
        }
        // Today keeps its outline only while it can be picked, so the ring never advertises
        // a day the range rules out.
        // 今天只在可选时保留描边，以免圆环示意一个被范围排除的日期。
        if cell.today && !cell.selected && cell.enabled {
            shapes.push(background.ring(p.primary, 1.0));
        }
        if let Some(ink) = cell.ring {
            shapes.push(Self::ring(Corners::all(side * 0.5 - 2.0), ink));
        }
        let label = Text::new(cell.id.with("label"), cell.text.clone(), p.day_label.size, cell.ink)
            .weight(p.day_label.weight)
            .resolve();
        Decl::container(cell.id, NodeKind::Column)
            .size(SizeClass::fixed(side, side))
            .padding(Self::centre(side, self.line.day))
            .cross_align(0.0)
            .cross_pos(0.5)
            .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
            // A day paints nothing at rest, and a focus stop is usually inferred from ink:
            // without this the arrows walk past every unselected day.
            // 日期格静息时不画任何东西，而焦点停靠点通常由墨迹推断：
            // 不写这一行，方向键会越过所有未选中的日期。
            .focus_stop(true)
            .cursor(if cell.enabled { CursorShape::PointingHand } else { CursorShape::Arrow })
            .disabled(!cell.enabled)
            .press_ink(cell.enabled.then(|| {
                let ink = if cell.selected {
                    p.on_primary
                } else if cell.today {
                    p.primary
                } else {
                    p.on_surface_variant
                };
                background.press(Color { a: ink.a * p.press_opacity, ..ink }, InkRadius::Cover)
            }))
            // The touch target stays the 48dp cell, larger than the disc it ink-splats into.
            // 触控目标仍是 48dp 的格子，比它泼墨的圆盘大。
            .corners(Corners::all(side * 0.5))
            .shapes(shapes)
            .child(label)
    }

    /// One cell of the month or year grid.
    /// 月/年网格里的一格。
    fn choice_decl(&self, cell: &ChoiceCell) -> Decl {
        let p = &self.palette;
        let (w, h) = (cell.width, p.cell);
        let corners = Corners::all(h * 0.5);
        // The item *is* the background: its selection and state layer fill the stadium the
        // ripple is clipped to, not a disc floating in its middle.
        // 整格就是背景：选中与状态层填满涟漪被裁到的胶囊，而不是中间浮一个圆盘。
        let background = Background::stadium(w, h);
        let mut shapes = Vec::with_capacity(3);
        if cell.chosen {
            shapes.push(background.fill(p.primary));
        }
        if let Some(ink) = cell.layer {
            shapes.push(background.fill(ink));
        }
        if let Some(ink) = cell.ring {
            shapes.push(Self::ring(Corners::all(h * 0.5 - 2.0), ink));
        }
        let ink = if cell.chosen { p.on_primary } else { p.on_surface };
        let label = Text::new(cell.id.with("label"), cell.text.clone(), p.weekday_label.size, ink)
            .weight(p.weekday_label.weight)
            .resolve();
        Decl::container(cell.id, NodeKind::Column)
            .size(SizeClass::fixed(w, h))
            .padding(Self::centre(h, self.line.weekday))
            .cross_align(0.0)
            .cross_pos(0.5)
            .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
            .focus_stop(true)
            .cursor(CursorShape::PointingHand)
            .disabled(self.disabled)
            .press_ink(Some(background.press(
                Color { a: p.on_surface_variant.a * p.press_opacity, ..p.on_surface_variant },
                InkRadius::Cover,
            )))
            .corners(corners)
            .shapes(shapes)
            .child(label)
    }

    /// One 40dp button: a label with a caret, or a mark alone.
    /// 一个 40dp 按钮：带下拉箭头的标签，或单独一个标记。
    fn button_decl(&self, button: &Button, icon_only: bool) -> Decl {
        let p = &self.palette;
        let h = p.button;
        let corners = Corners::all(h * 0.5);
        let ink = button.ink;
        let mut shapes = Vec::with_capacity(2);
        // The button is its own background: a TextButton-style pill (a circle when icon-only),
        // so the state layer covers the whole button instead of a disc at its left edge.
        // 按钮本身就是背景：文本按钮式的胶囊（纯图标时是圆），因此状态层盖住整个按钮，
        // 而不是停在左缘的圆盘。
        if let Some(layer) = button.layer {
            shapes.push(Shape::Box {
                corners,
                fill: layer,
                gradient: None,
                border: None,
                shadow: None,
                image: None,
            });
        }
        if let Some(ring) = button.ring {
            shapes.push(Self::ring(Corners::all(h * 0.5 - 2.0), ring));
        }
        // An icon-only button stacks its mark, so the glyph's em box centres on both axes;
        // a row would leave it at the main-axis start.
        // 纯图标按钮用 Stack 放标记，字形 em 盒在两轴上都居中；用行会让它停在主轴起点。
        let mut decl = if icon_only {
            Decl::container(button.id, NodeKind::Stack)
                .size(fixed(AxisSize::fixed(h), AxisSize::fixed(h)))
                .stack_align(OverlayAlign::Center)
        } else {
            Decl::container(button.id, NodeKind::Row)
                .size(fixed(AxisSize::hug(0.0, 0.0), AxisSize::fixed(h)))
                .padding(Insets {
                    left: 12.0,
                    top: ((h - self.line.menu) * 0.5).max(0.0),
                    right: 8.0,
                    bottom: 0.0,
                })
                .cross_align(0.0)
                .cross_pos(0.0)
                .gap(2.0)
        }
        .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
        .cursor(if button.enabled { CursorShape::PointingHand } else { CursorShape::Arrow })
        .disabled(!button.enabled)
        .press_ink(button.enabled.then(|| {
            press_ink(Color { a: p.on_surface_variant.a * p.press_opacity, ..p.on_surface_variant }, InkRadius::Cover)
        }))
        .corners(corners)
        .shapes(shapes);
        if let Some(name) = button.icon {
            decl = decl.child(Icon::new(button.id.with("icon"), name, 24.0, ink).resolve());
        }
        if let Some(text) = &button.text {
            decl = decl
                .child(
                    Text::new(button.id.with("label"), text.clone(), p.menu_label.size, ink)
                        .weight(p.menu_label.weight)
                        .resolve(),
                )
                .child(Icon::new(button.id.with("caret"), "arrow_drop_down", 18.0, ink).resolve());
        }
        decl
    }

    /// The header band: the calendar's title.
    /// 标题带：日历的标题。
    fn header_decl(&self) -> Decl {
        let p = &self.palette;
        let label = Text::new(
            self.id.with("header/label"),
            self.labels.header.to_string(),
            typescale::LABEL_MEDIUM.size,
            p.on_surface_variant,
        )
        .weight(typescale::LABEL_MEDIUM.weight)
        .resolve();
        Decl::container(self.id.with("header"), NodeKind::Row)
            .size(fixed(AxisSize::fill(0.0, 0.0), AxisSize::fixed(DATE_PICKER_HEADER)))
            .padding(Insets { left: 16.0, top: ((DATE_PICKER_HEADER - self.line.header) * 0.5).max(0.0), right: 16.0, bottom: 0.0 })
            .child(label)
    }

    /// The month and year buttons with the arrows at the far end.
    /// 月份、年份按钮，箭头在远端。
    fn month_row_decl(&self) -> Decl {
        let spacer = Decl::container(self.id.with("month-row/spacer"), NodeKind::Column).size(SizeClass {
            width: AxisSize::hug(0.0, 0.0),
            height: AxisSize::hug(0.0, 0.0),
            grow_x: Grow::Yes,
            grow_y: Grow::No,
        });
        Decl::container(self.id.with("month-row"), NodeKind::Row)
            .size(fixed(AxisSize::fill(0.0, 0.0), AxisSize::fixed(self.palette.button)))
            .padding(Insets { left: DATE_PICKER_SIDE, top: 0.0, right: DATE_PICKER_SIDE, bottom: 0.0 })
            .cross_align(0.0)
            .gap(4.0)
            .child(self.button_decl(&self.month_button, false))
            .child(self.button_decl(&self.year_button, false))
            .child(spacer)
            .child(self.button_decl(&self.prev, true))
            .child(self.button_decl(&self.next, true))
    }

    /// The seven weekday initials.
    /// 七个星期缩写。
    fn weekdays_decl(&self) -> Decl {
        let p = &self.palette;
        let cells: Vec<Decl> = self
            .weekdays
            .iter()
            .map(|(id, text)| {
                let label = Text::new(id.with("label"), text.clone(), p.weekday_label.size, p.on_surface)
                    .weight(p.weekday_label.weight)
                    .resolve();
                Decl::container(*id, NodeKind::Column)
                    .size(SizeClass::fixed(p.cell, p.cell))
                    .padding(Self::centre(p.cell, self.line.weekday))
                    .cross_align(0.0)
                    .cross_pos(0.5)
                    .child(label)
            })
            .collect();
        Decl::container(self.id.with("weekdays"), NodeKind::Row)
            .size(fixed(AxisSize::fill(0.0, 0.0), AxisSize::fixed(p.cell)))
            .children(cells)
    }

    /// Six rows of seven day cells.
    /// 六行、每行七个日期格。
    fn grid_decl(&self) -> Decl {
        let p = &self.palette;
        let rows: Vec<Decl> = self
            .days
            .chunks(7)
            .enumerate()
            .map(|(r, week)| {
                Decl::container(Id::of((&self.id, "week", r)), NodeKind::Row)
                    .size(fixed(AxisSize::fill(0.0, 0.0), AxisSize::fixed(p.cell)))
                    .children(week.iter().map(|cell| self.day_decl(cell)).collect::<Vec<_>>())
            })
            .collect();
        Decl::container(self.id.with("grid"), NodeKind::Column)
            .size(fixed(
                AxisSize::fill(0.0, 0.0),
                AxisSize::fixed(p.cell * DATE_PICKER_WEEKS as f32),
            ))
            .children(rows)
    }

    /// Three columns of four month or year cells.
    /// 三列四行的月份或年份格。
    fn choices_decl(&self, cells: &[ChoiceCell], tag: &str) -> Decl {
        let rows: Vec<Decl> = cells
            .chunks(3)
            .enumerate()
            .map(|(r, line)| {
                Decl::container(Id::of((&self.id, tag, r)), NodeKind::Row)
                    .size(fixed(
                        AxisSize::fill(0.0, 0.0),
                        AxisSize::fixed(self.palette.cell),
                    ))
                    .children(line.iter().map(|c| self.choice_decl(c)).collect::<Vec<_>>())
            })
            .collect();
        Decl::container(self.id.with(tag), NodeKind::Column)
            .size(fixed(AxisSize::fill(0.0, 0.0), AxisSize::hug(0.0, 0.0)))
            .children(rows)
    }

    /// The area under the month row: whichever grid the view asks for.
    /// 月份行下方的区域：当前视图要求的那个网格。
    fn body_decl(&self) -> Decl {
        let body = Decl::container(self.id.with("body"), NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::hug(0.0, 0.0),
                grow_x: Grow::No,
                grow_y: Grow::Yes,
            })
            .padding(Insets { left: DATE_PICKER_SIDE, top: 8.0, right: DATE_PICKER_SIDE, bottom: 8.0 });
        match self.view {
            DatePickerView::Days => body.child(self.weekdays_decl()).child(self.grid_decl()),
            DatePickerView::Months => body.child(self.choices_decl(&self.months, "month-grid")),
            DatePickerView::Years => body.child(self.choices_decl(&self.years, "year-grid")),
        }
    }
}

impl Button {
    fn placeholder(id: Id) -> Self {
        Self {
            id,
            text: None,
            icon: None,
            ink: Color::TRANSPARENT,
            enabled: true,
            layer: None,
            ring: None,
        }
    }
}

/// A box with no growth in either axis.
/// 两个轴都不增长的盒子。
fn fixed(width: AxisSize, height: AxisSize) -> SizeClass {
    SizeClass { width, height, grow_x: Grow::No, grow_y: Grow::No }
}

/// The height one line occupies at `size`, as the text engine measures it.
/// 给定字号下一行文字占据的高度，按文本引擎的测量。
fn measure_line(size: f32) -> f32 {
    Text::new(Id::str("date-picker/probe"), "0".to_string(), size, Color::WHITE)
        .resolve()
        .size_class
        .height
        .hint
}

impl Widget for Md3DatePicker {
    fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
        let p = &self.palette;
        Decl::container(self.id, NodeKind::Column)
            .size(SizeClass::fixed(DATE_PICKER_WIDTH, DATE_PICKER_HEIGHT))
            .cross_align(1.0)
            .shapes(vec![Shape::Box {
                corners: Corners::all(DATE_PICKER_RADIUS),
                fill: p.surface,
                gradient: None,
                border: None,
                shadow: Some(ShadowSpec::elevation(p.elevation.clamp(0.0, 8.0) as u8)),
                image: None,
            }])
            .child(self.header_decl())
            .child(self.month_row_decl())
            .child(self.body_decl())
    }

    fn change(&self, _state: &WidgetState, _bounds: Rect) -> Option<Change> {
        let action = self.fired?;
        Some(Change::Data(Box::new(match action {
            Action::Day(date) => DatePickerChange::Picked(date),
            Action::Prev => DatePickerChange::Shown {
                date: self.shown.add_months(-self.step()),
                view: self.view,
            },
            Action::Next => DatePickerChange::Shown {
                date: self.shown.add_months(self.step()),
                view: self.view,
            },
            // The two menu buttons toggle: a second tap on the open list returns to the days.
            // 两个菜单按钮都是开关：再点一次已打开的列表就回到日期网格。
            Action::MonthButton => DatePickerChange::View(if self.view == DatePickerView::Months {
                DatePickerView::Days
            } else {
                DatePickerView::Months
            }),
            Action::YearButton => DatePickerChange::View(if self.view == DatePickerView::Years {
                DatePickerView::Days
            } else {
                DatePickerView::Years
            }),
            Action::Month(month) => DatePickerChange::Shown {
                date: Date { month, ..self.shown },
                view: DatePickerView::Days,
            },
            Action::Year(year) => DatePickerChange::Shown {
                date: Date { year, ..self.shown },
                view: DatePickerView::Months,
            },
        })))
    }

    fn handles_disabled(&self) -> bool {
        true
    }
}
