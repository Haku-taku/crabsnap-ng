//! The MD3 outlined segmented button: one pill of equal segments, selection the app owns.
//! MD3 轮廓分段按钮：等宽分段合成一颗胶囊，选中归应用所有。

use super::*;

use ui_core::cx::Routing;
use ui_core::geom::{Corners, Point};
use ui_core::NodeData;

const BAR: Id = Id::str("bar");

fn segment(k: usize) -> Md3SegmentItem<'static> {
    Md3SegmentItem::text(BAR.with(("s", k)), "S")
}

fn build(
    store: &mut AnimStore,
    routing: Routing,
    count: usize,
    selected: Vec<Id>,
    disabled: bool,
) -> Decl {
    let mut core = ui_core::cx::Cx::new(store, 0, 600, 200, 0.0, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let items = (0..count).map(segment).collect();
    let control = Md3SegmentedButton::new_with(
        Md3Options { disabled, ..Default::default() },
        SegmentedParams { id: BAR, items, selected, disabled },
        &mut cx,
        &crate::pack::pack(),
    );
    cx.with_cx(|cx| control.decl(cx))
}

fn corners_of(decl: &Decl) -> Corners {
    match &decl.data {
        NodeData::Container(p) => p.corners.expect("the segment states its curve"),
        _ => panic!("the segment is a container"),
    }
}

/// The segment's own fill and its outline border, from the boxes it paints.
/// 分段自身盒子的填充与描边，取自它画的这些 box。
fn paints(decl: &Decl) -> (Option<Color>, Option<(Color, f32)>) {
    let mut fill = None;
    let mut border = None;
    for shape in &decl.shapes {
        if let ui_core::draw::Shape::Box { fill: f, border: b, .. } = shape {
            if *f != Color::TRANSPARENT {
                fill = Some(*f);
            }
            if let Some(b) = b {
                border = Some(*b);
            }
        }
    }
    (fill, border)
}

#[test]
fn only_the_segments_ends_are_round_and_the_seams_are_square() {
    // The pill is the bar's, not a segment's: rounding follows the place in the group,
    // and neighbours share a square edge — the segmented button's whole geometry claim.
    // 胶囊是整条的、不是分段的：圆角取决于在组中的位置，相邻者共用方边——分段按钮全部的几何主张。
    let mut store = AnimStore::new();
    let decl = build(&mut store, Routing::default(), 3, Vec::new(), false);
    let outer = crate::spec::outlined_segmented_button_spec(
        false, false, false, false, false, false,
    )
    .container
    .height
        * 0.5;
    let first = corners_of(&decl.children[0]);
    let middle = corners_of(&decl.children[1]);
    let last = corners_of(&decl.children[2]);
    assert_eq!((first.tl, first.bl), (outer, outer), "the first end rounds its left");
    assert_eq!((first.tr, first.br), (0.0, 0.0), "the seam side is square");
    assert!(
        (middle.tl, middle.tr, middle.bl, middle.br) == (0.0, 0.0, 0.0, 0.0),
        "a middle segment is square on all sides, got {middle:?}"
    );
    assert_eq!((last.tr, last.br), (outer, outer), "the last end rounds its right");
    assert_eq!((last.tl, last.bl), (0.0, 0.0));
}

#[test]
fn one_ring_rings_the_group_and_one_seam_separates_neighbours() {
    // A ring per segment would draw every seam twice and would have to read the selection;
    // the group owns one perimeter, painted after the fills, and each later segment adds a seam.
    // 每段一圈会让每条接缝画两遍，还得读选中态；外框归整组且画在填充之上，除首段外每段各加一条接缝。
    let mut store = AnimStore::new();
    let selected = BAR.with(("s", 1usize));
    let decl = build(&mut store, Routing::default(), 3, vec![selected], false);
    let ring = decl
        .children
        .iter()
        .find(|c| c.id == BAR.with("outline"))
        .expect("the group draws one ring around every segment");
    assert!(
        ring.shapes
            .iter()
            .any(|s| matches!(s, ui_core::draw::Shape::Box { border: Some(_), .. })),
        "the group ring is one border box"
    );
    assert_eq!(
        ring.placement.position,
        ui_core::layout::Position::Absolute,
        "the ring is positioned, so it paints above the segment fills"
    );
    assert_eq!(
        decl.children.last().map(|c| c.id),
        Some(BAR.with("outline")),
        "declared last, so the ring paints last"
    );
    let (fill_on, border_on) = paints(&decl.children[1]);
    let (fill_off, border_off) = paints(&decl.children[0]);
    assert!(fill_on.is_some(), "the selected segment paints its container fill");
    assert!(border_on.is_none(), "the selected segment draws no ring of its own");
    assert!(fill_off.is_none(), "an unselected segment paints no fill");
    assert!(border_off.is_none(), "an unselected segment draws no ring");
    let seams = |d: &Decl| {
        d.shapes
            .iter()
            .filter(|s| matches!(s, ui_core::draw::Shape::Rect { .. }))
            .count()
    };
    assert_eq!(seams(&decl.children[0]), 0, "the first segment has no seam");
    assert_eq!(seams(&decl.children[1]), 1, "each later segment draws one");
    assert_eq!(seams(&decl.children[2]), 1);
    let tree = laid_out(decl);
    assert_eq!(
        region_rect(&tree, BAR.with("outline")),
        region_rect(&tree, BAR),
        "the ring covers the whole bar, not a share of it"
    );
}

#[test]
fn segments_are_equal_shares_of_the_bars_width_whatever_their_labels() {
    // `Grow::Split(1)` with a zero basis is the bar's hit contract too: the point names
    // the segment by place, matching what a caller of `change` needs.
    // 零基准的 `Grow::Split(1)` 同时是命中契约：按下点按位置指认分段，正是 `change` 调用方所需。
    let mut store = AnimStore::new();
    let control = {
        let mut core = ui_core::cx::Cx::new(&mut store, 0, 600, 200, 0.0, 0.0, 1.0, None);
        core.route(Routing::default());
        let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
        Md3SegmentedButton::new_with(
            Md3Options::default(),
            SegmentedParams {
                id: BAR,
                items: (0..4).map(segment).collect(),
                selected: Vec::new(),
                disabled: false,
            },
            &mut cx,
            &crate::pack::pack(),
        )
    };
    assert_eq!(control.segment_at(Point::new(0.0, 10.0), 400.0), Some(0));
    assert_eq!(control.segment_at(Point::new(99.0, 10.0), 400.0), Some(0));
    assert_eq!(control.segment_at(Point::new(101.0, 10.0), 400.0), Some(1));
    assert_eq!(control.segment_at(Point::new(399.0, 10.0), 400.0), Some(3));
    assert_eq!(control.segment_at(Point::new(450.0, 10.0), 400.0), Some(3), "clamped inside");
    assert_eq!(control.segment_at(Point::new(10.0, 1000.0), 400.0), None, "below the bar");
}
