//! The MD3 checkbox: box geometry, fill/outline resolution, and the check that draws itself in.
//! MD3 复选框：方框几何、填充与描边的取值，以及自行画入的勾。

use super::*;

use crate::spec::checkbox_spec;
use crate::toggle::spec_ink;
use crate::checkbox::{CHECK_STROKE, EDGE, EDGE_RADIUS, TOUCH};
use ui_core::cx::Routing;
use ui_core::geom::Rect;
use ui_core::draw::Shape;

const ID: Id = Id::str("c");

fn build(
    store: &mut AnimStore,
    routing: Routing,
    now: f64,
    checked: bool,
    error: bool,
    params: Md3Options,
) -> (Box<dyn Widget>, Decl, ui_widgets::WidgetState) {
    let mut core = ui_core::cx::Cx::new(store, 0, 400, 200, now, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let control = Md3Kit::with_scope(ui_style::StyleScope::default(), params).checkbox(
        ID, checked, error, &mut cx,
    );
    let state = cx.state(ID);
    let decl = cx.with_cx(|cx| control.decl(cx));
    (control, decl, state)
}

fn role(pack: &ui_style::Style, name: &'static str) -> Color {
    pack.ink(name).unwrap_or_else(|| panic!("the pack has no {name}"))
}

/// The box: the only rect rounded by `EDGE_RADIUS`. The disc is a circle and the focus ring
/// is rounded by more, so this identifies it through the whole squeeze.
/// 方框：唯一以 `EDGE_RADIUS` 为圆角的矩形。圆盘是正圆、焦点环圆角更大，故在整段收缩中都能认出它。
fn box_rect(decl: &Decl) -> &Shape {
    decl.shapes
        .iter()
        .find(|s| match s {
            Shape::Rect { corners, .. } => (corners.tl - EDGE_RADIUS).abs() < 0.01,
            _ => false,
        })
        .expect("the checkbox always paints its box")
}

fn box_side(decl: &Decl) -> f32 {
    match box_rect(decl) {
        Shape::Rect { rect, .. } => rect.size.w,
        _ => unreachable!(),
    }
}

fn box_colour(decl: &Decl) -> Color {
    match box_rect(decl) {
        Shape::Rect { fill, .. } => *fill,
        _ => unreachable!(),
    }
}

fn box_border(decl: &Decl) -> Option<(Color, f32)> {
    match box_rect(decl) {
        Shape::Rect { border, .. } => *border,
        _ => unreachable!(),
    }
}

/// The check's bars: nothing else in this control is a `CHECK_STROKE` square.
/// 勾的方块：本控件里没有别的形状是 `CHECK_STROKE` 见方。
fn check_bars(decl: &Decl) -> Vec<(Color, f32, f32)> {
    decl.shapes
        .iter()
        .filter_map(|s| match s {
            Shape::Rect { rect, fill, .. } if rect.size.w <= CHECK_STROKE + 0.01 => {
                Some((*fill, rect.origin.x, rect.origin.y))
            }
            _ => None,
        })
        .collect()
}

#[test]
fn an_unchecked_box_is_the_exported_edge_with_the_exported_outline() {
    // An unchecked box is nothing but its two tokens; a wrong width or role turns a hairline
    // into a slab, which no layout test would notice.
    // 未选中的方框只有两个令牌；宽度或角色取错会把细线变成板砖，而布局测试看不出来。
    let spec = checkbox_spec(false, false, false, false, false, false);
    let pack = crate::pack::pack();
    let mut store = AnimStore::new();
    let (_, decl, _) = build(&mut store, Routing::default(), 0.0, false, false, Md3Options::default());
    assert_eq!(box_side(&decl), spec.container.size);
    assert_eq!(box_colour(&decl), Color::TRANSPARENT, "an unchecked box has no fill");
    let (colour, width) = box_border(&decl).expect("an unchecked box is an outline");
    assert_eq!(width, spec.outline.width);
    assert_eq!(colour, role(&pack, spec.outline.color));
    assert!(check_bars(&decl).is_empty(), "no check before the box is checked");
}

#[test]
fn a_checked_box_fills_with_primary_and_drops_its_outline() {
    // The fill replaces the ring rather than joining it: keeping both paints a 2dp dark band
    // around a primary square, which reads as a disabled box.
    // 填充取代描边而不是叠加：两者都留会在主色方块外描一圈深色带，看起来像禁用框。
    let spec = checkbox_spec(true, false, false, false, false, false);
    let pack = crate::pack::pack();
    let mut store = AnimStore::new();
    let (_, decl, _) = build(&mut store, Routing::default(), 0.0, true, false, Md3Options::default());
    assert_eq!(box_colour(&decl), role(&pack, spec.container.color));
    assert!(
        box_border(&decl).is_none_or(|(_, width)| width == 0.0),
        "a checked box keeps no outline"
    );
    let bars = check_bars(&decl);
    assert!(!bars.is_empty(), "a checked box draws the check");
    assert_eq!(bars[0].0, role(&pack, spec.icon.color), "the check takes the exported ink");
}

#[test]
fn the_check_is_drawn_in_only_after_the_box_has_filled() {
    // The reference splits the clock: fill by a quarter, box at its smallest at the halfway
    // point, and only then the check. Drawing it earlier leaves a tick floating on a
    // half-filled box.
    // 参考把时钟分段：前四分之一填满，中点半框最小，之后才画勾。提前画会得到浮在半填方框上的勾。
    let mut store = AnimStore::new();
    let params = Md3Options::default();
    build(&mut store, Routing::default(), 0.0, false, false, params);
    build(&mut store, Routing::default(), 0.0, true, false, params);
    // Linear 200ms: 0.05s is a quarter of the way, 0.11s just past the middle, 0.19s near the end.
    // 线性 200ms：0.05 秒走四分之一，0.11 秒刚过中点，0.19 秒接近终点。
    let (_, early, _) = build(&mut store, Routing::default(), 0.05, true, false, params);
    let (_, mid, _) = build(&mut store, Routing::default(), 0.11, true, false, params);
    let (_, late, _) = build(&mut store, Routing::default(), 0.19, true, false, params);
    assert!(check_bars(&early).is_empty(), "a quarter in, the box is still filling");
    assert!(!check_bars(&mid).is_empty(), "past the middle the check starts");
    assert!(
        check_bars(&late).len() > check_bars(&mid).len(),
        "the check grows along its own length ({:?} vs {:?})",
        check_bars(&late).len(),
        check_bars(&mid).len()
    );
}

#[test]
fn a_disabled_unchecked_box_dims_its_outline_to_the_container_opacity() {
    // The export gives the outline no opacity of its own; the disabled ring is `onSurface` at
    // the container's 38%. Using the role's full alpha paints an enabled-looking box.
    // 导出里描边没有自己的透明度；禁用环是容器的 38% `onSurface`。按角色全不透明画会看着像可用。
    let spec = checkbox_spec(false, false, false, false, false, true);
    let pack = crate::pack::pack();
    let params = Md3Options { disabled: true, ..Md3Options::default() };
    let mut store = AnimStore::new();
    let (_, decl, _) = build(&mut store, Routing::default(), 0.0, false, false, params);
    let (colour, _) = box_border(&decl).expect("a disabled unchecked box keeps its outline");
    assert_eq!(colour, spec_ink(&pack, spec.outline.color, spec.container.opacity));
    assert!((colour.a - 0.38).abs() < 1e-4, "38%, not {}", colour.a);
}

#[test]
fn a_hovered_box_paints_the_exported_state_layer_disc_under_the_box() {
    // The disc is 40dp — the tap target's inner circle, not the 18dp box. Drawing it at the
    // box's size hides it behind the box entirely, so hover looks like nothing happening.
    // 圆盘是 40dp——触控区内的圆，而不是 18dp 方框。按方框大小画会被方框完全盖住，悬停就像没反应。
    let spec = checkbox_spec(false, false, true, false, false, false);
    let pack = crate::pack::pack();
    let routing = Routing { hovered: Some(ID), hovered_path: vec![ID], ..Routing::default() };
    let mut store = AnimStore::new();
    let (_, decl, _) = build(&mut store, routing, 0.0, false, false, Md3Options::default());
    let index = decl
        .shapes
        .iter()
        .position(|s| match s {
            Shape::Rect { rect, .. } => (rect.size.w - spec.state_layer.size).abs() < 0.01,
            _ => false,
        })
        .expect("hover paints a state layer");
    let box_index = decl
        .shapes
        .iter()
        .position(|s| match s {
            Shape::Rect { corners, .. } => (corners.tl - EDGE_RADIUS).abs() < 0.01,
            _ => false,
        })
        .unwrap();
    assert!(index < box_index, "the disc is painted under the box");
    assert_eq!(
        decl.shapes[index],
        // The disc is centred in the 48dp target.
        // 圆盘在 48dp 触控区里居中。
        Shape::Rect {
            rect: Rect::new(
                (TOUCH - spec.state_layer.size) * 0.5,
                (TOUCH - spec.state_layer.size) * 0.5,
                spec.state_layer.size,
                spec.state_layer.size,
            ),
            corners: ui_core::geom::Corners::all(spec.state_layer.size * 0.5),
            fill: spec_ink(&pack, spec.state_layer.color, spec.state_layer.opacity),
            gradient: None,
            border: None,
        }
    );
}

#[test]
fn an_error_checkbox_takes_the_error_role_for_both_fill_and_check() {
    // Error is a role swap, not a tint: resolving `primary` for a checked error box paints the
    // ordinary colour and the error state silently disappears.
    // 错误是换角色而非调色：勾选+错误仍解析 `primary` 会画成普通色，错误态静默消失。
    let spec = checkbox_spec(true, true, false, false, false, false);
    let pack = crate::pack::pack();
    let mut store = AnimStore::new();
    let (_, decl, _) = build(&mut store, Routing::default(), 0.0, true, true, Md3Options::default());
    assert_eq!(box_colour(&decl), role(&pack, spec.container.color));
    assert_ne!(role(&pack, spec.container.color), role(&pack, "primary"), "error is not primary");
    assert_eq!(check_bars(&decl)[0].0, role(&pack, spec.icon.color));
}

#[test]
fn a_click_reports_the_opposite_value_and_a_disabled_box_ignores_it() {
    // The click handler is the only place the semantic value can flip; inverting it the wrong
    // way leaves a checkbox that looks right and never changes.
    // 点击处理是语义值唯一能翻转的地方；取反写错会得到看起来正常却永远不变的复选框。
    let clicked = Routing { clicked_path: vec![ID], ..Routing::default() };
    let mut store = AnimStore::new();
    let (control, _, state) = build(&mut store, clicked.clone(), 0.0, false, false, Md3Options::default());
    let change = control.change(&state, Rect::ZERO);
    assert!(matches!(change, Some(ui_core::Change::Toggled { on: Some(true) })), "{change:?}");

    let disabled = Md3Options { disabled: true, ..Md3Options::default() };
    let mut store = AnimStore::new();
    let (control, _, state) = build(&mut store, clicked, 0.0, false, false, disabled);
    assert!(control.change(&state, Rect::ZERO).is_none(), "a disabled box ignores clicks");
}

#[test]
fn enter_toggles_like_a_click_rather_than_reporting_a_bare_activation() {
    // The keyboard and the pointer reach the same change; a box that answers only clicks
    // hands the app an `Activated` it cannot read as a new value.
    // 键盘与指针到达同一个变化；只应答点击的复选框交给应用一个读不成新值的 `Activated`。
    let keyboard = Routing { activated_path: vec![ID], focused: Some(ID), ..Routing::default() };
    let mut store = AnimStore::new();
    let (control, _, state) = build(&mut store, keyboard, 0.0, false, false, Md3Options::default());
    let change = control.change(&state, Rect::ZERO);
    assert!(matches!(change, Some(ui_core::Change::Toggled { on: Some(true) })), "{change:?}");
}

#[test]
fn the_box_sits_centred_in_the_tap_target() {
    // The 18dp box is centred in the 48dp target; anchoring it at the corner shifts the whole
    // control by 15dp, which reads as a misaligned row.
    // 18dp 方框在 48dp 触控区里居中；按角对齐会让整个控件偏 15dp，看起来像整行没对齐。
    let mut store = AnimStore::new();
    let (_, decl, _) = build(&mut store, Routing::default(), 0.0, false, false, Md3Options::default());
    let Shape::Rect { rect, .. } = box_rect(&decl) else { unreachable!() };
    assert_eq!(rect.origin.x, (TOUCH - EDGE) * 0.5);
    assert_eq!(rect.origin.y, (TOUCH - EDGE) * 0.5);
}

#[test]
fn retargeting_to_unchecked_takes_the_check_and_the_fill_away() {
    // The reverse leg is its own path in the store; a widget that only follows the forward
    // direction keeps a checked-looking box after the app clears it.
    // 反向腿在存储里是另一条路径；只跟正向走的控件在应用清空后仍会画出选中外观。
    let mut store = AnimStore::new();
    let p = Md3Options::default();
    build(&mut store, Routing::default(), 0.0, true, false, p);
    build(&mut store, Routing::default(), 0.0, false, false, p);
    let (_, decl, _) = build(&mut store, Routing::default(), 0.3, false, false, p);
    assert!(check_bars(&decl).is_empty(), "retargeting to unchecked must drop the check");
    assert_eq!(box_colour(&decl), Color::TRANSPARENT);
}

#[test]
fn a_settled_dash_spans_the_middle_sixty_percent_of_the_box() {
    // Flutter's `_drawDash` runs from `0.2·EDGE` to `0.8·EDGE` on the centre line. Growing
    // only one end leaves a short bar parked right of centre, which is what a wrong lerp
    // argument produces — it looks like a misplaced glyph rather than a half-drawn one.
    // Flutter 的 `_drawDash` 在中心线上从 `0.2·EDGE` 画到 `0.8·EDGE`。只有一端生长会留下一条
    // 偏右的短杠——正是把插值参数写反的结果，看起来像字形错位而不是没画完。
    let mut store = AnimStore::new();
    let (_, decl, _) = build(&mut store, Routing::default(), 0.0, false, false, Md3Options::default());
    let origin = (TOUCH - EDGE) * 0.5;
    let mut mixed = AnimStore::new();
    let mut core = ui_core::cx::Cx::new(&mut mixed, 0, 400, 200, 0.3, 0.0, 1.0, None);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let control = Md3Kit::with_scope(ui_style::StyleScope::default(), Md3Options::default())
        .checkbox_tri(ID, CheckState::Mixed, false, &mut cx);
    let dash = cx.with_cx(|cx| control.decl(cx));
    let bars = glyph_bars(&dash);
    assert_eq!(bars.len(), 1, "the dash is one stroke, got {}", bars.len());
    let bar = bars[0];
    assert!((bar.origin.x - (origin + EDGE * 0.2)).abs() < 0.01, "dash starts at {}", bar.origin.x);
    assert!((bar.size.w - EDGE * 0.6).abs() < 0.01, "dash is {} long", bar.size.w);
    assert!((bar.origin.y - dash_line()).abs() < 0.01, "on the centre line");
    assert!(glyph_bars(&decl).is_empty(), "an unchecked box draws no glyph");
}

#[test]
fn the_focus_ring_is_drawn_on_the_touch_target_with_a_quarter_round_corner() {
    // Compose passes `RoundedCornerShape(25)` on the 48dp interactive bounds. Hugging the
    // 18dp box instead makes the ring a third of the size the reference shows.
    // Compose 在 48dp 触控区上传 `RoundedCornerShape(25)`。贴着 18dp 方框会让环只有参考的三分之一大。
    let routing = Routing {
        focused: Some(ID),
        focus_visible: true,
        ..Routing::default()
    };
    let mut store = AnimStore::new();
    let (_, decl, _) = build(&mut store, routing, 0.3, false, false, Md3Options::default());
    let (rect, corners, width) = decl
        .shapes
        .iter()
        .find_map(|s| match s {
            // The ring is the only transparent shape that carries a border.
            // 环是唯一透明且带边框的形状。
            Shape::Rect { rect, corners, fill, border: Some((_, w)), .. }
                if *fill == Color::TRANSPARENT =>
            {
                Some((*rect, *corners, *w))
            }
            _ => None,
        })
        .expect("keyboard focus draws the ring");
    let spec = checkbox_spec(false, false, false, false, false, false);
    assert_eq!(width, spec.focus_indicator.thickness, "3dp ring");
    assert!(
        (rect.origin.x - spec.focus_indicator_outline.offset).abs() < 0.01,
        "inset by the 2dp outline offset, got {}",
        rect.origin.x
    );
    assert!((rect.size.w - (TOUCH - 4.0)).abs() < 0.01, "44dp square, got {}", rect.size.w);
    assert!((corners.tl - (TOUCH * 0.25 - 2.0)).abs() < 0.01, "25% corner, got {}", corners.tl);
}

#[test]
fn the_check_waits_for_the_second_half_of_a_mixed_boxes_transition() {
    // Flutter shrinks the outgoing glyph over the first half of the 200ms and grows the
    // incoming one over the second; growing both at once would show a dash and a check.
    // Flutter 在前半程收缩离开的字形、后半程长出到达的字形；同时长出会显示横杠与勾。
    let mut store = AnimStore::new();
    let mut at = |now: f64, value: CheckState| {
        let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 200, now, 0.0, 1.0, None);
        let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
        let control = Md3Kit::with_scope(ui_style::StyleScope::default(), Md3Options::default())
            .checkbox_tri(ID, value, false, &mut cx);
        cx.with_cx(|cx| control.decl(cx))
    };
    let mixed = at(0.0, CheckState::Mixed);
    assert!(!glyph_bars(&mixed).is_empty(), "a mixed box draws the dash");
    // The dash is one horizontal run of squares; the check bends off that line immediately.
    at(0.05, CheckState::On);
    let mid = at(0.12, CheckState::On);
    let bars = glyph_bars(&mid);
    assert!(!bars.is_empty(), "the dash is still there at 70ms");
    assert!(
        bars.iter().all(|r| (r.origin.y - dash_line()).abs() < 0.01),
        "the check must not have started at 70ms"
    );
    let late = at(0.22, CheckState::On);
    assert!(
        glyph_bars(&late).iter().any(|r| (r.origin.y - dash_line()).abs() > 0.01),
        "by 170ms the check is drawn"
    );
}

/// The dash's squares all sit on the box's centre line.
/// 横杠的方块都落在方框的中心线上。
fn dash_line() -> f32 {
    (TOUCH - EDGE) * 0.5 + EDGE * 0.5 - CHECK_STROKE * 0.5
}

/// The strokes the check and the dash are built from: everything one stroke thick. The dash
/// is a single long rect, the check a run of squares; every other shape is larger.
/// 勾与横杠所用的笔画：所有一 stroke 厚的东西。横杠是一条长矩形，勾是一串方块；
/// 其余形状都更大。
fn glyph_bars(decl: &Decl) -> Vec<Rect> {
    decl.shapes
        .iter()
        .filter_map(|s| match s {
            Shape::Rect { rect, .. } if (rect.size.h - CHECK_STROKE).abs() < 0.01 => Some(*rect),
            _ => None,
        })
        .collect()
}
