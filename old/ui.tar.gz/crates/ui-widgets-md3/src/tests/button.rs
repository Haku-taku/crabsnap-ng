//! The MD3 button: five styles, five sizes, one pill with a centred icon and label.
//! MD3 按钮：五种样式、五档尺寸，一颗居中放着图标与标签的胶囊。

use super::*;

use crate::spec::{button_spec, ButtonSize, ButtonStyle, ButtonToggle};
use crate::toggle::{role, spec_ink};
use crate::typescale;
use ui_core::cx::Routing;
use ui_core::draw::Shape;
use ui_core::geom::Rect;
use ui_core::NodeData;

const BTN: Id = Id::str("btn");

const SIZES: [ButtonSize; 5] = [
    ButtonSize::XSmall,
    ButtonSize::Small,
    ButtonSize::Medium,
    ButtonSize::Large,
    ButtonSize::XLarge,
];

/// A 24dp mark in the button's ink: the icon variant's stand-in for a real glyph.
/// 24dp、按按钮墨色绘制的标记：图标变体用来代替真实字形。
fn dot(id: Id, ink: Color) -> Decl {
    Decl::container(id, NodeKind::Box)
        .size(SizeClass::fixed(24.0, 24.0))
        .shapes(vec![Shape::Box {
            corners: ui_core::Corners::ZERO,
            fill: ink,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }])
}

fn build(
    store: &mut AnimStore,
    routing: Routing,
    now: f64,
    style: ButtonStyle,
    size: ButtonSize,
    toggle: ButtonToggle,
    icon: bool,
    params: Md3Options,
) -> (Md3Button, Decl) {
    let mut core = ui_core::cx::Cx::new(store, 0, 400, 200, now, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let mark = icon.then_some(ui_widgets::IconSource::Custom(dot));
    let spec = ButtonParams::new(BTN, "Label").style(style).size(size).toggle(toggle);
    let spec = match mark {
        Some(m) => spec.icon(m),
        None => spec,
    };
    let control = Md3Button::new_with(params, spec, &mut cx, &crate::pack::pack());
    let decl = cx.with_cx(|cx| control.decl(cx));
    (control, decl)
}

fn plain(style: ButtonStyle, size: ButtonSize) -> (Md3Button, Decl) {
    let mut store = AnimStore::new();
    build(&mut store, Routing::default(), 0.0, style, size, ButtonToggle::Base, false, Md3Options::default())
}

/// Lay the button out in a row, so it keeps the width its own content asks for.
/// 把按钮放进一行里布局，使它保持自身内容要求的宽度。
fn laid(decl: Decl) -> Tree {
    let root = Decl::container(Id::str("root"), NodeKind::Row).child(decl);
    lay_out(&root, (400.0, 200.0))
}

fn find(decl: &Decl, id: Id) -> Option<&Decl> {
    if decl.id == id {
        return Some(decl);
    }
    decl.children.iter().find_map(|c| find(c, id))
}

/// The container box: the first shape, when it carries a fill or a border.
/// 容器盒：首个形状，若它带填充或边框。
fn container_box(decl: &Decl) -> Option<(Color, Option<(Color, f32)>, Option<ui_core::tree::ShadowSpec>, f32)> {
    match decl.shapes.first() {
        Some(Shape::Box { corners, fill, border, shadow, .. }) if fill.a > 0.0 || border.is_some() => {
            Some((*fill, *border, *shadow, corners.tl))
        }
        _ => None,
    }
}

/// Every box's fill in paint order: container, then the state layer, then the focus ring.
/// 按绘制顺序给出每个盒子的填充：容器、状态层、焦点环。
fn fills(decl: &Decl) -> Vec<Color> {
    decl.shapes
        .iter()
        .filter_map(|s| match s {
            Shape::Box { fill, .. } => Some(*fill),
            _ => None,
        })
        .collect()
}

/// Every box's border in paint order; only the ring (and an outlined container) has one.
/// 按绘制顺序给出每个盒子的边框；只有环（与轮廓容器）有。
fn borders(decl: &Decl) -> Vec<(Color, f32)> {
    decl.shapes
        .iter()
        .filter_map(|s| match s {
            Shape::Box { border: Some(b), .. } => Some(*b),
            _ => None,
        })
        .collect()
}

fn ring(decl: &Decl) -> Option<(Color, f32)> {
    borders(decl).last().copied()
}

fn label(decl: &Decl) -> (&ui_core::text::TextRun, Color) {
    match &find(decl, BTN.with("label")).expect("every button carries a label").data {
        NodeData::Text { block, ink, .. } => (&block.runs[0], *ink),
        _ => panic!("the label is a text node"),
    }
}

#[test]
fn each_size_takes_its_height_and_side_padding_from_the_export() {
    // The five sizes are the whole point of the size axis: a fixed 40dp button would look
    // right in one sample and wrong in the other four.
    // 五档尺寸正是尺寸轴的意义：写死 40dp 会让一个样本正确、其余四个错误。
    for size in SIZES {
        let (control, decl) = plain(ButtonStyle::Filled, size);
        let spec = button_spec(false, false, false, false, ButtonStyle::Filled, size, ButtonToggle::Base);
        assert_eq!(control.height(), spec.container.height, "{size:?} height");
        let tree = laid(decl);
        let (_, _, w, h) = region_rect(&tree, BTN);
        assert_eq!(h, spec.container.height, "{size:?} laid out");
        // Height and padding decide the width, so a wrong pad shows up as a wrong width.
        // 高度与内衬决定宽度，因此内衬写错会表现为宽度不对。
        let (_, _, label_w, _) = region_rect(&tree, BTN.with("label"));
        let want = spec.root.leading_space + label_w + spec.root.trailing_space;
        assert!((w - want).abs() < 0.01, "{size:?} is {w} wide, want {want}");
    }
}

#[test]
fn each_size_takes_the_label_type_style_the_export_names() {
    // The export names a typescale per size (`label-large` … `headline-large`) but not its
    // numbers; using one size for all five flattens the hierarchy the sizes exist to create.
    // 导出为每档尺寸命名一个字级（`label-large` … `headline-large`）但不给数值；
    // 五档共用一个字号会抹平尺寸档本该建立的层级。
    let want = [
        (ButtonSize::XSmall, typescale::LABEL_LARGE),
        (ButtonSize::Small, typescale::LABEL_LARGE),
        (ButtonSize::Medium, typescale::TITLE_MEDIUM),
        (ButtonSize::Large, typescale::HEADLINE_SMALL),
        (ButtonSize::XLarge, typescale::HEADLINE_LARGE),
    ];
    for (size, style) in want {
        let (_, decl) = plain(ButtonStyle::Filled, size);
        let (run, _) = label(&decl);
        assert_eq!(run.style.size, style.size, "{size:?} size");
        assert_eq!(run.style.weight, style.weight, "{size:?} weight");
    }
}

#[test]
fn the_pill_radius_is_half_the_height() {
    // MD3's default button shape is `StadiumBorder`; a fixed radius rounds the small sizes
    // into pills and leaves the large ones square-ish.
    // MD3 按钮的默认形状是 `StadiumBorder`；写死半径会把小尺寸变成胶囊、大尺寸留成方角。
    for size in SIZES {
        let (control, decl) = plain(ButtonStyle::Filled, size);
        let (_, _, _, radius) = container_box(&decl).expect("a filled button paints a container");
        assert!((radius - control.height() * 0.5).abs() < 0.01, "{size:?} radius {radius}");
    }
}

#[test]
fn only_the_styles_that_have_a_container_paint_one() {
    // Text and outlined buttons are transparent by definition; painting the inherited
    // `primary` container colour puts a solid pill behind every text button.
    // 文字与轮廓按钮按定义是透明的；画上继承来的 `primary` 容器色会给每个文字按钮垫一块实心胶囊。
    for style in [ButtonStyle::Filled, ButtonStyle::Tonal, ButtonStyle::Elevated, ButtonStyle::Base] {
        let (_, decl) = plain(style, ButtonSize::Small);
        assert!(container_box(&decl).is_some_and(|(fill, ..)| fill.a > 0.0), "{style:?} paints a container");
    }
    for style in [ButtonStyle::Text, ButtonStyle::Outlined] {
        let (_, decl) = plain(style, ButtonSize::Small);
        assert!(
            container_box(&decl).is_none_or(|(fill, ..)| fill.a == 0.0),
            "{style:?} paints no container"
        );
    }
    // A selected outlined button *does* gain one: its selected colour is a real fill.
    // 选中的轮廓按钮**会**得到容器：它的选中色是真填充。
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Routing::default(), 0.0, ButtonStyle::Outlined, ButtonSize::Small, ButtonToggle::Selected, false, Md3Options::default());
    let pack = crate::pack::pack();
    let spec = button_spec(false, false, false, false, ButtonStyle::Outlined, ButtonSize::Small, ButtonToggle::Selected);
    let (fill, ..) = container_box(&decl).expect("a selected outlined button is filled");
    assert_eq!(fill, spec_ink(&pack, spec.container.color, spec.container.opacity));
}

#[test]
fn a_plain_filled_button_is_primary_not_the_unselected_toggle() {
    // The export describes a *toggle* button; its `unselected` fill (`surface-container`) is a
    // real appearance. Reusing it for a plain button paints every filled button grey.
    // 导出描述的是**切换**按钮；其 `unselected` 填充（`surface-container`）是一种真实外观。
    // 普通按钮若沿用它，所有填充按钮都会变成灰底。
    let pack = crate::pack::pack();
    let (_, plain_decl) = plain(ButtonStyle::Filled, ButtonSize::Small);
    let (fill, ..) = container_box(&plain_decl).expect("a filled button paints a container");
    assert_eq!(fill, role(&pack, "primary"));
    let mut store = AnimStore::new();
    let (_, toggle) = build(
        &mut store,
        Routing::default(),
        0.0,
        ButtonStyle::Filled,
        ButtonSize::Small,
        ButtonToggle::Unselected,
        false,
        Md3Options::default(),
    );
    let (toggle_fill, ..) = container_box(&toggle).expect("an unselected toggle still paints");
    assert_eq!(toggle_fill, role(&pack, "surfaceContainer"));
}

#[test]
fn an_outlined_button_draws_its_ring_even_without_a_container() {
    // The outline is the whole affordance; dropping it with the container leaves a floating
    // label that looks like a text button.
    // 描边是轮廓按钮的全部可感知形态；跟着容器一起丢掉，它就变成一颗看似文字按钮的悬空标签。
    let (_, decl) = plain(ButtonStyle::Outlined, ButtonSize::Small);
    let pack = crate::pack::pack();
    let spec = button_spec(false, false, false, false, ButtonStyle::Outlined, ButtonSize::Small, ButtonToggle::Base);
    let (ink, width) = ring(&decl).expect("an outlined button draws its ring");
    assert_eq!(ink, spec_ink(&pack, spec.outline.color, 1.0));
    assert_eq!(width, spec.outline.width);
    // A filled button has no ring at all.
    // 填充按钮完全没有环。
    let (_, filled) = plain(ButtonStyle::Filled, ButtonSize::Small);
    assert_eq!(ring(&filled), None);
}

/// The press ink the button declares, if any.
/// 按钮声明的按压墨迹（若有）。
fn splat(decl: &Decl) -> Option<ui_core::PressInk> {
    match &decl.data {
        NodeData::Container(p) => p.press_ink,
        _ => None,
    }
}

#[test]
fn every_style_states_the_pill_its_ink_is_clipped_to() {
    // A text button paints no container at rest, so the ink's outline cannot be read off the
    // frame: without a stated one, a held ripple squares off as soon as hover fades.
    // 文字按钮静息时不画容器，墨迹的轮廓无从从这一帧读出：不显式声明，
    // 悬停一淡出，按住的涟漪就会变方。
    for style in [ButtonStyle::Text, ButtonStyle::Outlined, ButtonStyle::Filled] {
        let (control, decl) = plain(style, ButtonSize::Small);
        let stated = match &decl.data {
            NodeData::Container(p) => p.corners.expect("every button states its curve"),
            _ => panic!("the button is a container"),
        };
        let want = control.height() * 0.5;
        assert!((stated.tl - want).abs() < 0.01, "{style:?} states {stated:?}");
        assert_eq!(stated, ui_core::Corners::all(want), "{style:?} is a pill on all four corners");
    }
}

#[test]
fn a_hovered_button_paints_the_eight_percent_state_layer() {
    // The layer's ink and strength come from the export; hard-coding `onSurface` at 8% is
    // wrong for tonal (whose layer is `on-secondary-container`) and for selected styles.
    // 状态层的墨色与强度来自导出；写死 `onSurface` 的 8% 对 tonal（其层色是
    // `on-secondary-container`）与选中态都是错的。
    let routing = Routing {
        hovered: Some(BTN),
        hovered_path: vec![BTN],
        ..Routing::default()
    };
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, routing, 0.0, ButtonStyle::Tonal, ButtonSize::Small, ButtonToggle::Base, false, Md3Options::default());
    let pack = crate::pack::pack();
    let spec = button_spec(true, false, false, false, ButtonStyle::Tonal, ButtonSize::Small, ButtonToggle::Base);
    let ink = role(&pack, spec.state_layer.color);
    let want = Color { a: ink.a * spec.state_layer.opacity, ..ink };
    assert_eq!(fills(&decl).last(), Some(&want), "the layer is painted over the container");
    assert_eq!(fills(&decl).len(), 2, "container then layer, nothing else");
    // Pressed is 10%, not the hovered 8%, but it is ink now: the flat layer is hover's alone.
    // 按下是 10% 而非悬停的 8%，但按下已是墨迹：平坦层只随悬停。
    let pressed = Routing { pressed: Some(BTN), ..Routing::default() };
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, pressed, 0.0, ButtonStyle::Tonal, ButtonSize::Small, ButtonToggle::Base, false, Md3Options::default());
    let spec = button_spec(false, false, true, false, ButtonStyle::Tonal, ButtonSize::Small, ButtonToggle::Base);
    let ink = role(&pack, spec.state_layer.color);
    let want = Color { a: ink.a * spec.state_layer.opacity, ..ink };
    assert_eq!(fills(&decl).len(), 1, "a press adds no flat layer");
    let ink = splat(&decl).expect("a press asks the engine for ink");
    assert_eq!(ink.colour, want);
    assert_eq!(ink.radius, ui_core::InkRadius::Cover, "the ink covers the pill");
}

#[test]
fn the_focus_state_layer_keys_on_keyboard_focus_not_pointer_focus() {
    // A click focuses the button too, and MD3's focus layer is 10% — the same as the press
    // layer, so painting it for pointer focus leaves the button looking pressed after release.
    // 点击同样会给按钮焦点，而 MD3 的聚焦层是 10%，与按下层相同；指针焦点也画它，
    // 松手后按钮就仍然像是按着的。
    let pointer = Routing {
        focused: Some(BTN),
        focus_visible: false,
        ..Routing::default()
    };
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, pointer, 0.0, ButtonStyle::Tonal, ButtonSize::Small, ButtonToggle::Base, false, Md3Options::default());
    assert_eq!(fills(&decl).len(), 1, "pointer focus paints no state layer");

    let keyboard = Routing {
        focused: Some(BTN),
        focus_visible: true,
        ..Routing::default()
    };
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, keyboard, 0.0, ButtonStyle::Tonal, ButtonSize::Small, ButtonToggle::Base, false, Md3Options::default());
    let pack = crate::pack::pack();
    let spec = button_spec(false, true, false, false, ButtonStyle::Tonal, ButtonSize::Small, ButtonToggle::Base);
    let ink = role(&pack, spec.state_layer.color);
    let want = Color { a: ink.a * spec.state_layer.opacity, ..ink };
    // Fills go container, layer, ring; the ring's own fill is transparent.
    // 填充顺序是容器、状态层、焦点环；焦点环自身的填充是透明的。
    assert_eq!(fills(&decl).get(1), Some(&want), "keyboard focus paints the ten percent layer");
}

#[test]
fn a_disabled_button_fades_its_content_and_keeps_a_ten_percent_container() {
    // MD3 disables by fading content to 38% over an `on-surface` container at 10%; dropping
    // the container makes a disabled filled button read as an enabled text button.
    // MD3 的禁用是把内容淡到 38%、容器换成 10% 的 `on-surface`；丢掉容器会让禁用的填充按钮
    // 看起来像启用的文字按钮。
    let params = Md3Options { disabled: true, ..Md3Options::default() };
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Routing::default(), 0.0, ButtonStyle::Filled, ButtonSize::Small, ButtonToggle::Base, true, params);
    let pack = crate::pack::pack();
    let spec = button_spec(false, false, false, true, ButtonStyle::Filled, ButtonSize::Small, ButtonToggle::Base);
    let (fill, ..) = container_box(&decl).expect("a disabled filled button keeps a container");
    assert_eq!(fill, spec_ink(&pack, spec.container.color, spec.container.opacity));
    assert!((fill.a - 0.1).abs() < 1e-4, "the container is at 10%, got {}", fill.a);
    let (_, ink) = label(&decl);
    assert!((ink.a - 0.38).abs() < 1e-4, "the label is at 38%, got {}", ink.a);
    assert_eq!(fills(&decl), vec![fill], "no state layer over the container");
    assert_eq!(ring(&decl), None, "and no focus ring");
}

#[test]
fn a_click_reports_activation_and_a_disabled_click_reports_nothing() {
    // A button's semantic is activation, not a value; reporting on a disabled control would
    // let the app act on a press the UI said it would ignore.
    // 按钮的语义是「被激活」而不是某个值；禁用的控件若也上报，应用就会对界面声称忽略的按下做出反应。
    let (control, _) = plain(ButtonStyle::Filled, ButtonSize::Small);
    let bounds = Rect::new(0.0, 0.0, 100.0, control.height());
    let click = ui_widgets::WidgetState { clicked: true, ..Default::default() };
    assert!(matches!(control.change(&click, bounds), Some(ui_core::Change::Activated)));
    let hover = ui_widgets::WidgetState { local: Some(ui_core::geom::Point::new(1.0, 1.0)), ..Default::default() };
    assert!(control.change(&hover, bounds).is_none(), "hover alone is not activation");
    let params = Md3Options { disabled: true, ..Md3Options::default() };
    let mut store = AnimStore::new();
    let (disabled, _) = build(&mut store, Routing::default(), 0.0, ButtonStyle::Filled, ButtonSize::Small, ButtonToggle::Base, false, params);
    assert!(disabled.change(&click, bounds).is_none());
}

#[test]
fn the_icon_comes_after_the_leading_pad_and_the_label_after_the_gap() {
    // The export's `leading-space` / `icon-label-space` / `trailing-space` are the only
    // horizontal metrics; centring the pair or padding it symmetrically moves both.
    // 导出的 `leading-space` / `icon-label-space` / `trailing-space` 是仅有的横向度量；
    // 把两者整体居中或对称内衬都会让它们移位。
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Routing::default(), 0.0, ButtonStyle::Filled, ButtonSize::Medium, ButtonToggle::Base, true, Md3Options::default());
    let spec = button_spec(false, false, false, false, ButtonStyle::Filled, ButtonSize::Medium, ButtonToggle::Base);
    let tree = laid(decl);
    let (x, y, w, h) = region_rect(&tree, BTN);
    let (ix, iy, iw, ih) = region_rect(&tree, BTN.with("icon"));
    let (lx, ly, lw, lh) = region_rect(&tree, BTN.with("label"));
    assert!((ix - x - spec.root.leading_space).abs() < 0.01, "icon at {ix}, button at {x}");
    assert!((iw - spec.icon.size).abs() < 0.01, "the mark is {} wide", iw);
    assert!((lx - (ix + iw) - spec.root.icon_label_space).abs() < 0.01, "label at {lx}");
    // Both are centred on the button's own midline.
    // 两者都以按钮自身的中线居中。
    let mid = y + h * 0.5;
    assert!((iy + ih * 0.5 - mid).abs() < 0.01, "icon centre {} vs {mid}", iy + ih * 0.5);
    assert!((ly + lh * 0.5 - mid).abs() < 0.01, "label centre {} vs {mid}", ly + lh * 0.5);
    // The label's right edge is the trailing pad away from the button's right edge.
    // 标签右边缘距按钮右边缘正好一个尾部内衬。
    assert!((x + w - (lx + lw) - spec.root.trailing_space).abs() < 0.01);
}
