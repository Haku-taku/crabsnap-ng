//! Shared fixtures for the pack's tests, plus one module per subject.
//! 本包测试的共享装置，以及按主题划分的模块。

use crate::*;

use ui_core::geom::Color;
use ui_core::{
    AnimStore, BuiltinLayout, Constraints, Decl, Id, LayoutEngine, MonospaceMeasure, NodeKind,
    SizeClass, Tree,
};
use ui_widgets::{decl_only, ScaffoldSpec, StyleKit, Widget};

/// A kit's scaffold as a bare declaration: a scaffold arranges, it never reports.
/// 某套件的骨架解析成裸声明：骨架只负责排列，从不上报。
fn scaffold_decl(
    kit: &dyn StyleKit,
    spec: &ScaffoldSpec<'_>,
    cx: &mut ui_widgets::Cx<'_, '_>,
) -> Decl {
    let widget = kit.scaffold(spec, cx);
    decl_only(widget.as_ref(), cx)
}

mod app_bar;
mod badge;
mod button;
mod button_group;
mod card;
mod carousel;
mod checkbox;
mod common_plane;
mod date_input;
mod date_picker;
mod dialog;
mod chip;
mod divider;
mod fab_menu;
mod list;
mod nav_bar;
mod nav_drawer;
mod nav_rail;
mod progress;
mod radio;
mod scaffold;
mod scope;
mod search_bar;
mod search_view;
mod segmented_button;
mod slider;
mod snackbar;
mod tab_bar;
mod text_field;
mod time_picker;
mod toggle;
mod toolbar;
mod theme;
mod spec;
mod token_parity;

/// The fill of a node's background box (transparent when it paints none).
/// 节点背景盒的填充色（没有背景时为透明）。
fn box_fill(decl: &Decl) -> Color {
    decl.shapes
        .iter()
        .find_map(|s| match s {
            ui_core::draw::Shape::Box { fill, .. } => Some(*fill),
            _ => None,
        })
        .unwrap_or(Color::TRANSPARENT)
}

/// The rect a shape paints, for tests that measure what the switch draws.
/// 形状绘制的矩形，供测量开关绘制结果的测试使用。
fn shape_rect(shape: &ui_core::draw::Shape) -> ui_core::geom::Rect {
    match shape {
        ui_core::draw::Shape::Rect { rect, .. } => *rect,
        ui_core::draw::Shape::Shadow { rect, .. } => *rect,
        ui_core::draw::Shape::Box { .. } => panic!("the switch has no box shape"),
        ui_core::draw::Shape::Outline { .. } => panic!("the switch has no outline shape"),
        ui_core::draw::Shape::Sector { .. } => panic!("the switch has no arc shape"),
    }
}

/// The switch paints track, then the optional radial reaction, then the thumb, then the
/// thumb's icon bars. The thumb is therefore the largest-area shape after the track — not
/// simply the last one, which is now an icon bar.
/// 开关依次绘制轨道、可选的涟漪、滑块，然后是滑块上的图标条。滑块因此是轨道之后**面积最大**
/// 的形状，而不是最后一个——最后一个现在是图标条。
fn thumb_shape(decl: &Decl) -> &ui_core::draw::Shape {
    // Paint order is: [outline ring], track, [splash], thumb, [icon bars]. Find the first icon
    // bar (narrow) and take the shape before it; if no bars, take the last non-track, non-ring
    // shape — which is the thumb.
    // 绘制顺序：[描边环]、轨道、[涟漪]、滑块、[图标条]。找到第一个窄图标条并取其前一个；
    // 若无图标条，则取最后一个非轨道、非描边环的形状——那就是滑块。
    let width = |s: &ui_core::draw::Shape| match s {
        ui_core::draw::Shape::Rect { rect, .. } => rect.size.w,
        _ => f32::INFINITY,
    };
    let bar = crate::toggle::ICON_BAR + 0.01;
    let track_w = crate::toggle::TRACK.0;
    let ring_w = track_w + crate::toggle::OUTLINE_WIDTH * 2.0;
    let is_trivial = |w: f32| (w - track_w).abs() < 0.01 || (w - ring_w).abs() < 0.01;
    // The handle is the last shape that is neither a track/ring nor an icon bar.
    // 滑块是最后一个既非轨道/描边环、也非图标条的形状。
    decl.shapes
        .iter()
        .rfind(|s| {
            let w = width(s);
            w > bar && !is_trivial(w)
        })
        .expect("the switch always paints a handle")
}

/// The track *fill*: the 52×32 box. An outlined switch paints a 2pt wider ring before it, so
/// the fill is not always the first shape, but it is always the first 52×32 rect.
/// 轨道**填充**：52×32 的盒子。描边的开关会在它之前画一个宽 2pt 的环，故填充不总是首个形状，
/// 但总是首个 52×32 的矩形。
/// The fill colour of a rect shape (transparent for non-rects).
/// 矩形形状的填充色（非矩形为透明）。
fn shape_fill(shape: &ui_core::draw::Shape) -> Color {
    match shape {
        ui_core::draw::Shape::Rect { fill, .. } => *fill,
        _ => Color::TRANSPARENT,
    }
}

/// The focus ring: the outermost rect, wider than the track's 2dp outline ring, present only
/// under keyboard focus. Returns `None` when nothing outside the outline ring is painted.
/// 焦点环：最外层的矩形，比轨道 2dp 描边环更宽，仅在键盘焦点下存在。若描边环之外无形状则返回
/// `None`。
fn focus_ring_shape(decl: &Decl) -> Option<&ui_core::draw::Shape> {
    // The track outline is inward now, so the ring sits (gap + width) outside the 52x32 box.
    // It is a stroke (border present, transparent fill); match on width only, since the box is
    // not square and the ring inherits a capsule-ish height.
    // 轨道描边现在向内，故环位于 52×32 盒子之外 (gap + width) 处。它是描边（有边框、填充透明）；
    // 仅按宽度匹配，因为盒子非正方形，环高度随之为非正方形。
    let outer = crate::toggle::TRACK.0
        + (crate::toggle::FOCUS_RING_GAP + crate::toggle::FOCUS_RING_WIDTH) * 2.0;
    decl.shapes.iter().find(|s| match s {
        ui_core::draw::Shape::Rect { rect, border: Some(_), .. } => (rect.size.w - outer).abs() < 0.01,
        _ => false,
    })
}

fn track_shape(decl: &Decl) -> &ui_core::draw::Shape {
    decl.shapes
        .iter()
        .find(|s| match s {
            ui_core::draw::Shape::Rect { rect, .. } => {
                (rect.size.w - crate::toggle::TRACK.0).abs() < 0.01
                    && (rect.size.h - crate::toggle::TRACK.1).abs() < 0.01
            }
            _ => false,
        })
        .expect("the track fill is the 52x32 rect")
}

/// The shapes that are neither the track nor the thumb nor the reaction: the icon bars.
/// They are the small squares after the thumb. Counted by "a square no wider than ICON_BAR".
/// 既非轨道、滑块，也非涟漪的形状：图标条。即滑块之后不超过 ICON_BAR 宽的小方块。
fn glyph_bar_count(decl: &Decl) -> usize {
    decl.shapes
        .iter()
        .filter(|s| match s {
            ui_core::draw::Shape::Rect { rect, .. } => {
                rect.size.w <= crate::toggle::ICON_BAR + 0.01
                    && rect.size.h <= crate::toggle::ICON_BAR + 0.01
            }
            _ => false,
        })
        .count()
}

/// Index of the radial reaction, if the switch is painting one. The reaction is the only
/// non-track shape whose size is a square larger than the thumb.
/// 涟漪的索引（若在画）。涟漪是轨道之外唯一尺寸大于滑块的正方形。
fn reaction_index(decl: &Decl) -> Option<usize> {
    // The builder pushes, in order: track, [reaction], thumb, [glyph bars]. The reaction is a
    // perfect square wider than the thumb's diameter — an off state with an icon has a 24 px
    // thumb, so a fixed 16.5 threshold would call the thumb the reaction.
    // 构造顺序为：轨道、[涟漪]、滑块、[字形条]。涟漪是边长大于滑块直径的正方形——
    // 带图标的关闭态滑块有 24px，固定的 16.5 阈值会把滑块误认成涟漪。
    // The builder pushes the reaction immediately after the track. Detect it there: it is a
    // perfect circle whose diameter exceeds the 28pt pressed thumb, so an ordinary thumb or a
    // 2.2pt icon bar can never be mistaken for it.
    // 构造把涟漪紧接在轨道之后。在那里检测：它是直径超过 28pt 按压滑块的完美圆，
    // 故普通滑块或 2.2pt 图标条都不会被误认。
    decl.shapes.iter().enumerate().skip(1).find_map(|(i, s)| match s {
        ui_core::draw::Shape::Rect { rect, .. }
            if (rect.size.w - rect.size.h).abs() < 0.01 && rect.size.w > 28.0 =>
        {
            Some(i)
        }
        _ => None,
    })
}

/// Rest sizes, as if nothing was ever pressed.
/// 静息尺寸，仿佛从未被按过。
/// A content widget that knows nothing but its own fixed square.
/// 只知道自己是个固定方块的内容控件。
struct Square {
    id: Id,
    side: f32,
}

impl Widget for Square {
    fn decl(&self, _cx: &ui_widgets::Cx<'_, '_>) -> Decl {
        Decl::container(self.id, NodeKind::Box)
            .size(SizeClass::fixed(self.side, self.side))
    }
}

fn lay_out(decl: &Decl, size: (f32, f32)) -> Tree {
    let mut tree = Tree::new();
    tree.apply(decl);
    let root = tree.root().expect("root node");
    let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
    engine.solve(
        &mut tree,
        root,
        Constraints::loose(ui_core::Size::new(size.0, size.1)),
    );
    tree
}

/// Lay `decl` out as the only child of a 200x100 column: a root node is forced to the
/// constraint, so a size class is only honoured one level down.
/// 把 `decl` 作为 200x100 列的唯一子节点布局：根节点会被强制成约束尺寸，
/// 尺寸类只有在下一层才被遵守。
fn laid_out(decl: Decl) -> Tree {
    let root = Decl::container(Id::str("root"), NodeKind::Column).child(decl);
    lay_out(&root, (200.0, 100.0))
}

fn region_rect(tree: &Tree, id: Id) -> (f32, f32, f32, f32) {
    let nid = tree.find_by_id(id).unwrap_or_else(|| panic!("missing {id:?}"));
    let r = tree.get(nid).expect("node").visual_rect();
    (r.origin.x, r.origin.y, r.size.w, r.size.h)
}

/// Build one toggle with a fresh store, so the first call lands at the target value.
/// 用全新存储构建一个开关，使首次调用就落在目标值上。
fn toggle_decl(
    style: &dyn ui_widgets::StyleKit,
    env: &std::sync::Arc<ui_style::Env>,
    hot: bool,
) -> Decl {
    let id = Id::str("t");
    let mut store = AnimStore::new();
    // Scope is only visible in what the builder draws, so the hot state has to come
    // from real routing rather than being assumed.
    // 作用域只体现在构建器画出的东西上，因此热状态必须来自真实路由而不是假定。
    let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 200, 0.0, 0.0, 1.0, None);
    core.route(ui_core::cx::Routing {
        hovered: if hot { Some(id) } else { None },
        hovered_path: if hot { vec![id] } else { Vec::new() },
        ..ui_core::cx::Routing::default()
    });
    let mut cx = ui_widgets::Cx::new(&mut core, env.clone());
    let spec = ui_style::ToggleSpec::new(id, false, "");
    let control = style.toggle(&spec, &mut cx);
    cx.with_cx(|inner| control.decl(inner))
}

fn md3_scope(outline_width: f32) -> std::sync::Arc<ui_style::Env> {
    ui_style::Env::with(None, Md3Options { outline_width, ..Default::default() })
}

