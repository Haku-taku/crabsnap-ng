//! MD3 chips: assist, suggestion, filter and input over one 32dp pill.
//! MD3 芯片：辅助、建议、筛选与输入，共用一颗 32dp 胶囊。

use super::*;

use crate::spec::{
    assist_chip_spec, filter_chip_spec, AssistChipVariant, FilterChipVariant,
};
use crate::toggle::{role, spec_ink};
use ui_core::cx::Routing;
use ui_core::draw::Shape;
use ui_core::geom::Rect;
use ui_core::NodeData;
use ui_widgets::WidgetState;

const CHIP: Id = Id::str("chip");

fn dot(id: Id, ink: Color) -> Decl {
    Decl::container(id, NodeKind::Box)
        .size(SizeClass::fixed(18.0, 18.0))
        .shapes(vec![Shape::Box {
            corners: ui_core::Corners::ZERO,
            fill: ink,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }])
}

fn build(
    store: &mut AnimStore,
    routing: Routing,
    kind: ChipKind,
    variant: ChipVariant,
    selected: bool,
    lead: bool,
    params: Md3Options,
) -> (Md3Chip, Decl) {
    let mut core = ui_core::cx::Cx::new(store, 0, 400, 200, 0.0, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let spec = ChipParams::new(CHIP, "Label", kind).variant(variant).selected(selected);
    let spec = if lead { spec.lead(ui_widgets::IconSource::Custom(dot)) } else { spec };
    let chip = Md3Chip::new_with(params, spec, &mut cx, &crate::pack::pack());
    let decl = cx.with_cx(|cx| chip.decl(cx));
    (chip, decl)
}

fn plain(kind: ChipKind, variant: ChipVariant) -> (Md3Chip, Decl) {
    let mut store = AnimStore::new();
    build(&mut store, Routing::default(), kind, variant, false, false, Md3Options::default())
}

fn find(decl: &Decl, id: Id) -> Option<&Decl> {
    if decl.id == id {
        return Some(decl);
    }
    decl.children.iter().find_map(|c| find(c, id))
}

/// The pill's fill and border, in paint order.
/// 胶囊的填充与描边，按绘制顺序。
fn pills(decl: &Decl) -> Vec<(Color, Option<(Color, f32)>, Option<ui_core::tree::ShadowSpec>)> {
    decl.shapes
        .iter()
        .filter_map(|s| match s {
            Shape::Box { fill, border, shadow, .. } => Some((*fill, *border, *shadow)),
            _ => None,
        })
        .collect()
}

#[test]
fn every_kind_takes_the_exported_height() {
    // All four exports say 32dp; a kind-specific height would misalign a row of mixed chips.
    // 四份导出都写 32dp；某一种用别的值会让混排的一行对不齐。
    for kind in [ChipKind::Assist, ChipKind::Suggestion, ChipKind::Filter, ChipKind::Input] {
        let (chip, _) = plain(kind, ChipVariant::Flat);
        assert_eq!(chip.height(), 32.0, "{kind:?}");
    }
}

#[test]
fn a_flat_chip_is_outlined_and_an_elevated_chip_is_filled() {
    // The flat/elevated axis is the whole difference between the two exports: flat paints a
    // 1dp `outline-variant` ring and no fill, elevated paints a fill and a shadow.
    // 扁平与立面这两份导出的全部差别：扁平画 1dp 的 `outline-variant` 描边且不填充，
    // 立面填充并带阴影。
    let pack = crate::pack::pack();
    let (_, flat) = plain(ChipKind::Assist, ChipVariant::Flat);
    let spec = assist_chip_spec(false, false, false, false, false, false, AssistChipVariant::Flat);
    let (fill, border, shadow) = pills(&flat)[0];
    assert_eq!(fill.a, 0.0, "a flat chip has no fill");
    let (ink, width) = border.expect("a flat chip is outlined");
    assert_eq!(ink, spec_ink(&pack, spec.outline.color, spec.outline.opacity));
    assert_eq!(width, spec.outline.width);
    assert_eq!(shadow, None);
    let (_, elevated) = plain(ChipKind::Assist, ChipVariant::Elevated);
    let spec = assist_chip_spec(false, false, false, false, false, false, AssistChipVariant::Elevated);
    let (fill, border, shadow) = pills(&elevated)[0];
    assert_eq!(fill, spec_ink(&pack, spec.container.color, spec.container.opacity));
    assert_eq!(border, None, "an elevated chip has no outline");
    assert!(shadow.is_some_and(|s| s.blur > 0.0), "and it lifts off the page");
}

#[test]
fn a_selected_filter_chip_takes_the_secondary_container() {
    // Selection is the filter chip's whole point: the container replaces the outline, so a
    // chip that keeps its ring reads as unselected no matter what the app stores.
    // 选中是筛选芯片的全部意义：容器取代描边，因此保留描边的芯片无论应用存了什么都会读作未选中。
    let pack = crate::pack::pack();
    for (selected, want) in [(true, "secondaryContainer"), (false, "outlineVariant")] {
        let mut store = AnimStore::new();
        let (_, decl) = build(
            &mut store,
            Routing::default(),
            ChipKind::Filter,
            ChipVariant::Flat,
            selected,
            false,
            Md3Options::default(),
        );
        let (fill, border, _) = pills(&decl)[0];
        if selected {
            assert_eq!(fill, role(&pack, want));
            assert_eq!(border, None, "a selected chip has no ring");
        } else {
            assert_eq!(border.expect("an unselected chip is outlined").0, role(&pack, want));
            assert_eq!(fill.a, 0.0);
        }
    }
}

/// The press ink the pill declares, if any.
/// 胶囊声明的按压墨迹（若有）。
fn splat(decl: &Decl) -> Option<ui_core::PressInk> {
    match &decl.data {
        NodeData::Container(p) => p.press_ink,
        _ => None,
    }
}

#[test]
fn a_press_splats_the_press_opacity_instead_of_raising_the_layer() {
    // The layer's strength differs per state (8% hover, 10% press). Only hover raises the flat
    // layer now; a press is ink the engine splats where the pointer landed.
    // 状态层强度按状态不同（悬停 8%、按下 10%）。现在只有悬停抬高平坦层；
    // 按下是引擎在指针落点泼出的墨迹。
    let pack = crate::pack::pack();

    let routing = Routing { hovered: Some(CHIP), hovered_path: vec![CHIP], ..Routing::default() };
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, routing, ChipKind::Assist, ChipVariant::Flat, false, false, Md3Options::default());
    let spec = assist_chip_spec(false, true, false, false, false, false, AssistChipVariant::Flat);
    let ink = role(&pack, spec.state_layer.color);
    let want = Color { a: ink.a * spec.state_layer.opacity, ..ink };
    assert_eq!(pills(&decl).last().map(|p| p.0), Some(want), "hover still raises the layer");

    let mut store = AnimStore::new();
    let (_, decl) = build(
        &mut store,
        Routing { pressed: Some(CHIP), ..Routing::default() },
        ChipKind::Assist,
        ChipVariant::Flat,
        false,
        false,
        Md3Options::default(),
    );
    let spec = assist_chip_spec(false, false, false, true, false, false, AssistChipVariant::Flat);
    let ink = role(&pack, spec.state_layer.color);
    let want = Color { a: ink.a * spec.state_layer.opacity, ..ink };
    let ink = splat(&decl).expect("a press asks the engine for ink");
    assert_eq!(ink.colour, want);
    assert_eq!(ink.radius, ui_core::InkRadius::Cover, "ink covers the pill");
    assert_eq!(pills(&decl).len(), 1, "a press paints no flat layer over the outline");
}

#[test]
fn a_filter_chip_reports_the_opposite_state_and_an_assist_chip_reports_activation() {
    // A filter chip is a toggle, an assist chip is a verb; reporting both as `Activated`
    // leaves the app without the value it needs to store.
    // 筛选芯片是开关，辅助芯片是一个动作；两者都报 `Activated` 会让应用拿不到要保存的值。
    let bounds = Rect::new(0.0, 0.0, 120.0, 32.0);
    let click = WidgetState { clicked: true, ..Default::default() };
    let (_, _) = plain(ChipKind::Assist, ChipVariant::Flat);
    let (assist, _) = plain(ChipKind::Assist, ChipVariant::Flat);
    assert!(matches!(assist.change(&click, bounds), Some(ui_core::Change::Activated)));
    let mut store = AnimStore::new();
    let (on, _) = build(&mut store, Routing::default(), ChipKind::Filter, ChipVariant::Flat, true, false, Md3Options::default());
    assert!(matches!(on.change(&click, bounds), Some(ui_core::Change::Toggled { on: Some(false) })));
    let mut store = AnimStore::new();
    let (off, _) = build(&mut store, Routing::default(), ChipKind::Filter, ChipVariant::Flat, false, false, Md3Options::default());
    assert!(matches!(off.change(&click, bounds), Some(ui_core::Change::Toggled { on: Some(true) })));
}

#[test]
fn a_disabled_chip_takes_the_exported_opacities() {
    // The export gives 38% for the label and 12% for a flat chip's ring; inventing one
    // number for both makes the label unreadable or the ring invisible.
    // 导出给标签 38%、扁平芯片描边 12%；两者共用一个数会让标签读不出或描边看不见。
    let params = Md3Options { disabled: true, ..Md3Options::default() };
    let mut store = AnimStore::new();
    let (chip, decl) = build(
        &mut store,
        Routing::default(),
        ChipKind::Assist,
        ChipVariant::Flat,
        false,
        false,
        params,
    );
    let spec = assist_chip_spec(false, false, false, false, false, true, AssistChipVariant::Flat);
    let (_, border, _) = pills(&decl)[0];
    let (ink, _) = border.expect("a disabled flat chip keeps its ring");
    assert!((ink.a - spec.outline.opacity).abs() < 1e-4, "the ring is at 12%, got {}", ink.a);
    let label = match &find(&decl, CHIP.with("label")).expect("label").data {
        NodeData::Text { ink, .. } => *ink,
        _ => panic!("the label is a text node"),
    };
    assert!((label.a - spec.label_text.opacity).abs() < 1e-4, "the label is at 38%, got {}", label.a);
    let click = WidgetState { clicked: true, ..Default::default() };
    assert!(chip.change(&click, Rect::new(0.0, 0.0, 120.0, 32.0)).is_none());
}

#[test]
fn the_leading_mark_sits_after_the_eight_dp_pad() {
    // A chip with a mark shrinks that side's pad from 16 to 8; keeping 16 leaves the pill
    // looking unbalanced and the label off-centre.
    // 带标记的一侧内衬从 16 缩到 8；保持 16 会让胶囊失衡、标签偏心。
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Routing::default(), ChipKind::Assist, ChipVariant::Flat, false, true, Md3Options::default());
    let root = Decl::container(Id::str("root"), NodeKind::Row).child(decl);
    let tree = lay_out(&root, (400.0, 200.0));
    let (x, _, _, _) = region_rect(&tree, CHIP);
    let (ix, _, iw, _) = region_rect(&tree, CHIP.with("lead"));
    let (lx, _, _, _) = region_rect(&tree, CHIP.with("label"));
    assert!((ix - x - CHIP_PAD_ICON).abs() < 0.01, "mark at {ix}, chip at {x}");
    assert!((iw - 18.0).abs() < 0.01, "the mark is {} wide", iw);
    assert!((lx - (ix + iw) - CHIP_GAP).abs() < 0.01, "label at {lx}");
}

#[test]
fn an_unselected_input_chip_is_outlined_like_a_filter_one() {
    // Input chips have no elevated variant, so an unselected one must still get its ring;
    // reusing the filter table's `selected` fill would paint every input chip solid.
    // 输入芯片没有立面变体，未选中时仍必须拿到描边；沿用筛选表里的 `selected` 填充
    // 会把每颗输入芯片都涂成实心。
    let pack = crate::pack::pack();
    let (_, decl) = plain(ChipKind::Input, ChipVariant::Flat);
    let spec = filter_chip_spec(false, false, false, false, false, false, false, false, false, FilterChipVariant::Flat);
    let (fill, border, _) = pills(&decl)[0];
    assert_eq!(fill.a, 0.0, "an unselected input chip has no fill");
    let (ink, width) = border.expect("an unselected input chip is outlined");
    assert_eq!(ink, spec_ink(&pack, spec.outline.color, spec.outline.opacity));
    assert_eq!(width, spec.outline.width);
}
