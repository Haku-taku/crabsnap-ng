//! Scope resolution: the nearest declaration wins, and a foreign style is skipped.
//! 作用域解析：最近的声明生效，其他风格的声明被跳过。

use super::*;

#[test]
fn a_scope_changes_the_control_and_its_parent_does_not() {
    let style = Md3Kit::new();
    let outer = md3_scope(2.0);
    let inner = ui_style::Env::with(
        Some(outer.clone()),
        Md3Options { outline_width: 5.0, ..Default::default() },
    );
    let parent_before = toggle_decl(&style, &outer, true);
    let child = toggle_decl(&style, &inner, true);
    let parent_after = toggle_decl(&style, &outer, true);
    assert_eq!(parent_before, parent_after, "the parent must not change");
    assert_ne!(parent_before, child, "the inner scope must change the control");
}

#[test]
fn the_nearest_scope_wins() {
    let style = Md3Kit::new();
    let outer = md3_scope(2.0);
    let middle = ui_style::Env::with(
        Some(outer.clone()),
        Md3Options { outline_width: 2.0, ..Default::default() },
    );
    let inner = ui_style::Env::with(
        Some(middle.clone()),
        Md3Options { outline_width: 5.0, ..Default::default() },
    );
    assert_eq!(inner.find::<Md3Options>(), Some(&Md3Options { outline_width: 5.0, ..Default::default() }));
    let expected = toggle_decl(&style, &md3_scope(5.0), true);
    assert_eq!(toggle_decl(&style, &inner, true), expected);
    assert_ne!(toggle_decl(&style, &middle, true), expected);
}

#[test]
fn an_instance_default_applies_when_no_scope_exists() {
    let shoot = Md3Kit::with_scope(
        ui_style::StyleScope::default(),
        Md3Options { outline_width: 5.0, ..Default::default() },
    );
    let root = ui_style::Env::root();
    // The constant default is `true`, so this instance must not match it.
    // 常量默认是 `true`，因此该实例不应当与它一致。
    assert_ne!(toggle_decl(&shoot, &root, true), toggle_decl(&Md3Kit::new(), &root, true));
    let explicit = md3_scope(5.0);
    assert_eq!(toggle_decl(&shoot, &root, true), toggle_decl(&shoot, &explicit, true));
}

#[test]
fn a_scope_for_another_style_is_skipped() {
    let style = Md3Kit::new();
    let fluent = ui_style::Env::with(
        None,
        ui_widgets_fluent::FluentOptions::default(),
    );
    let root = ui_style::Env::root();
    assert_eq!(
        toggle_decl(&style, &fluent, true),
        toggle_decl(&style, &root, true),
        "a foreign scope must read as no scope at all"
    );
}

#[test]
fn a_direct_widget_and_the_semantic_path_agree() {
    let id = Id::str("t");
    // A non-default outline width, so an ignored scope shows up in the Decl.
    // 用非默认的描边宽度，使被忽略的作用域在 Decl 上可见。
    let params = Md3Options { outline_width: 5.0, ..Default::default() };
    let env = md3_scope(params.outline_width);


    let mut semantic_store = AnimStore::new();
    let mut semantic_core =
        ui_core::cx::Cx::new(&mut semantic_store, 0, 400, 200, 0.0, 0.0, 1.0, None);
    let mut semantic_fx = ui_widgets::Cx::new(&mut semantic_core, env.clone());
    let semantic_c =
        Md3Kit::new().toggle(&ui_style::ToggleSpec::new(id, true, ""), &mut semantic_fx);
    let semantic = semantic_fx.with_cx(|cx| semantic_c.decl(cx));

    let mut direct_store = AnimStore::new();
    let mut direct_core =
        ui_core::cx::Cx::new(&mut direct_store, 0, 400, 200, 0.0, 0.0, 1.0, None);
    let mut direct_fx = ui_widgets::Cx::new(&mut direct_core, env.clone());
    let direct_c = {
        let mut node = direct_fx.at(id);
        Md3Toggle::new_with(params, id, true, &mut node, &crate::pack::pack())
    };
    let direct = direct_fx.with_cx(|cx| direct_c.decl(cx));

    assert_eq!(direct, semantic, "direct and semantic construction must agree");
}

