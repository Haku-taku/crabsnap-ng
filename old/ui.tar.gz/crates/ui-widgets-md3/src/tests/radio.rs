//! The MD3 radio button: the ring's colour is the mark, and the dot grows out of the centre.
//! MD3 单选框：环色即标记色，内点从中心长出。

use super::*;

use crate::radio::{DOT_RADIUS, RING, STROKE, TOUCH};
use crate::spec::radio_button_spec;
use crate::toggle::spec_ink;
use ui_core::cx::Routing;
use ui_core::draw::Shape;
use ui_core::geom::Rect;

const ID: Id = Id::str("r");

fn build(
    store: &mut AnimStore,
    routing: Routing,
    now: f64,
    selected: bool,
    params: Md3Options,
) -> (Box<dyn Widget>, Decl, ui_widgets::WidgetState) {
    let mut core = ui_core::cx::Cx::new(store, 0, 400, 200, now, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let control = Md3Kit::with_scope(ui_style::StyleScope::default(), params).radio(
        ID, selected, &mut cx,
    );
    let state = cx.state(ID);
    let decl = cx.with_cx(|cx| control.decl(cx));
    (control, decl, state)
}

fn role(pack: &ui_style::Style, name: &'static str) -> Color {
    pack.ink(name).unwrap_or_else(|| panic!("the pack has no {name}"))
}

/// The ring: the only bordered shape in this control.
/// 圆环：本控件里唯一带描边的形状。
fn ring(decl: &Decl) -> (Color, f32, Rect) {
    decl.shapes
        .iter()
        .find_map(|s| match s {
            Shape::Rect { rect, border: Some((c, w)), .. } => Some((*c, *w, *rect)),
            _ => None,
        })
        .expect("the radio always paints its ring")
}

/// The inner dot: a filled circle smaller than the ring.
/// 内点：比圆环小的实心圆。
fn dot(decl: &Decl) -> Option<(Color, f32)> {
    decl.shapes.iter().find_map(|s| match s {
        Shape::Rect { rect, fill, border: None, .. }
            if (rect.size.w - rect.size.h).abs() < 0.01
                && rect.size.w < RING - STROKE * 2.0 + 0.01 =>
        {
            Some((*fill, rect.size.w * 0.5))
        }
        _ => None,
    })
}

#[test]
fn an_unselected_ring_is_the_exported_diameter_in_on_surface_variant() {
    // The ring is nothing but `icon.size` and `icon.color`: a wrong role turns the resting
    // state into a selected-looking or invisible mark, and layout would never notice.
    // 圆环只有 `icon.size` 与 `icon.color`：角色取错会把静止态画成「已选中」或看不见，
    // 而布局永远看不出来。
    let spec = radio_button_spec(false, false, false, false, false);
    let pack = crate::pack::pack();
    let mut store = AnimStore::new();
    let (_, decl, _) = build(&mut store, Routing::default(), 0.0, false, Md3Options::default());
    let (colour, width, rect) = ring(&decl);
    assert_eq!(colour, role(&pack, spec.icon.color));
    assert_eq!(width, STROKE);
    assert_eq!((rect.size.w, rect.size.h), (spec.icon.size, spec.icon.size));
    assert_eq!(rect.origin.x, (TOUCH - RING) * 0.5, "the ring is centred in the target");
    assert!(dot(&decl).is_none(), "an unselected radio has no dot");
}

#[test]
fn a_selected_ring_and_its_dot_take_the_primary_role() {
    // The dot is the same colour as the ring in the export; painting it in another role
    // leaves a two-tone mark no token ever asked for.
    // 导出里内点与环同色；画成别的角色会得到任何令牌都没要求的双色标记。
    let spec = radio_button_spec(true, false, false, false, false);
    let pack = crate::pack::pack();
    let mut store = AnimStore::new();
    let (_, decl, _) = build(&mut store, Routing::default(), 0.0, true, Md3Options::default());
    let (colour, _, _) = ring(&decl);
    assert_eq!(colour, role(&pack, spec.icon.color));
    let (dot_colour, radius) = dot(&decl).expect("a selected radio paints its dot");
    assert_eq!(dot_colour, colour);
    assert!((radius - DOT_RADIUS).abs() < 1e-4, "the dot is {radius}, not {DOT_RADIUS}");
}

#[test]
fn the_dot_grows_out_of_the_centre_with_the_selection() {
    // `drawCircle(center, innerRadius * position)`: a dot at full size the moment the click
    // lands pops instead of growing.
    // `drawCircle(center, innerRadius * position)`：点击一落地就满尺寸的内点是「弹」出来的，
    // 而不是长出来的。
    let mut store = AnimStore::new();
    let params = Md3Options::default();
    build(&mut store, Routing::default(), 0.0, false, params);
    build(&mut store, Routing::default(), 0.0, true, params);
    // Linear 200ms: 0.1s is exactly halfway.
    // 线性 200ms：0.1 秒正好过半。
    let (_, mid, _) = build(&mut store, Routing::default(), 0.1, true, params);
    let (_, radius) = dot(&mid).expect("the dot exists as soon as the selection starts");
    assert!((radius - DOT_RADIUS * 0.5).abs() < 1e-3, "halfway dot is {radius}");
    let (colour, _, _) = ring(&mid);
    assert_ne!(colour, role(&crate::pack::pack(), "onSurfaceVariant"), "the ring left its rest colour");
    assert_ne!(colour, role(&crate::pack::pack(), "primary"), "the ring has not arrived yet");
}

#[test]
fn a_disabled_ring_is_on_surface_at_thirty_eight_percent() {
    // The disabled role is `onSurface` at 38%, carried in the icon's own opacity slot; using
    // the colour alone paints a fully enabled-looking ring.
    // 禁用角色是 38% 的 `onSurface`，走图标自己的透明度槽；只取颜色会画出「完全可用」的环。
    let spec = radio_button_spec(false, false, false, false, true);
    let pack = crate::pack::pack();
    let params = Md3Options { disabled: true, ..Md3Options::default() };
    let mut store = AnimStore::new();
    let (_, decl, _) = build(&mut store, Routing::default(), 0.0, false, params);
    let (colour, _, _) = ring(&decl);
    assert_eq!(colour, spec_ink(&pack, spec.icon.color, spec.icon.opacity));
    assert!((colour.a - 0.38).abs() < 1e-4, "38%, not {}", colour.a);
}

#[test]
fn a_hovered_radio_paints_the_exported_state_layer_disc() {
    // The disc is 40dp and sits under the 20dp ring; drawing it at the ring's size hides it
    // completely, so hover looks like nothing happening.
    // 圆盘是 40dp，压在 20dp 圆环之下；按环的尺寸画会被完全遮住，悬停就像没反应。
    let spec = radio_button_spec(false, true, false, false, false);
    let pack = crate::pack::pack();
    let routing = Routing { hovered: Some(ID), hovered_path: vec![ID], ..Routing::default() };
    let mut store = AnimStore::new();
    let (_, decl, _) = build(&mut store, routing, 0.0, false, Md3Options::default());
    let index = decl
        .shapes
        .iter()
        .position(|s| match s {
            Shape::Rect { rect, border: None, .. } => (rect.size.w - spec.state_layer.size).abs() < 0.01,
            _ => false,
        })
        .expect("hover paints a state layer");
    assert_eq!(index, 0, "the disc is painted under the ring");
    assert_eq!(
        decl.shapes[index],
        Shape::Rect {
            rect: Rect::new(
                (TOUCH - spec.state_layer.size) * 0.5,
                (TOUCH - spec.state_layer.size) * 0.5,
                spec.state_layer.size,
                spec.state_layer.size,
            ),
            corners: ui_core::geom::Corners::all(spec.state_layer.size * 0.5),
            fill: spec_ink(&pack, spec.state_layer.color, spec.state_layer.opacity),
            gradient: None,
            border: None,
        }
    );
}

#[test]
fn a_click_selects_an_unselected_radio_and_a_selected_one_reports_nothing() {
    // The group owns the selection, so a click only ever says "this one"; reporting on an
    // already-selected radio would let a click clear the group.
    // 选中项归整组所有，点击只可能说「这一个」；已选中的单选框若上报，点击就会把整组清空。
    let clicked = Routing { clicked_path: vec![ID], ..Routing::default() };
    let mut store = AnimStore::new();
    let (control, _, state) = build(&mut store, clicked.clone(), 0.0, false, Md3Options::default());
    let change = control.change(&state, Rect::ZERO);
    assert!(
        matches!(&change, Some(ui_core::Change::Selected(Some(id))) if *id == ID),
        "{change:?}"
    );

    let mut store = AnimStore::new();
    let (control, _, state) = build(&mut store, clicked, 0.0, true, Md3Options::default());
    assert!(control.change(&state, Rect::ZERO).is_none(), "already selected: nothing changes");
}
