//! The generated state function overlays states by priority; colours are pack roles.
//! 生成的状态函数按优先级叠加状态；颜色字段就是包内角色名（即 md.sys.color.* 规范令牌）。

use crate::spec::switch_spec;

#[test]
fn the_default_state_is_unselected_at_rest() {
    // No flags set: the base geometry plus the `unselected` branch.
    // 不带任何开关：基线几何加 `unselected` 分支。
    let s = switch_spec(false, false, false, false, false, false);
    assert_eq!((s.track.width, s.track.height), (52.0, 32.0));
    assert_eq!(s.track.color, "surfaceContainerHighest");
    assert_eq!(s.handle.width, 16.0);
    assert_eq!(s.state_layer.opacity, 0.0);
}

#[test]
fn selected_replaces_the_unselected_branch() {
    let s = switch_spec(true, false, false, false, false, false);
    assert_eq!(s.track.color, "primary");
    assert_eq!(s.handle.color, "onPrimary");
    assert_eq!(s.handle.width, 24.0);
}

#[test]
fn a_pressed_handle_overrides_the_selected_size() {
    // Pressed is a later state than `selected`, so 28dp wins over the 24dp handle.
    // 按压晚于 selected 生效，28dp 压过选中的 24dp 手柄。
    let s = switch_spec(true, false, false, false, true, false);
    assert_eq!((s.handle.width, s.handle.height), (28.0, 28.0));
    assert_eq!(s.state_layer.opacity, 0.1);
}

#[test]
fn hover_uses_the_state_layer_for_the_current_selection() {
    let off = switch_spec(false, false, true, false, false, false);
    let on = switch_spec(true, false, true, false, false, false);
    assert_eq!(off.state_layer.color, "onSurface");
    assert_eq!(on.state_layer.color, "primary");
    assert_eq!(off.state_layer.opacity, 0.08);
}

#[test]
fn disabled_is_applied_last_and_keeps_the_track_visible() {
    // Disabled wins over hover, yet the track colour still comes from the disabled branch.
    // 禁用压过悬停，轨道色仍来自禁用分支。
    let s = switch_spec(true, false, true, false, true, true);
    assert_eq!(s.track.color, "onSurface");
    assert_eq!(s.track.opacity, 0.12);
    assert_eq!(s.handle.color, "surface");
    assert_eq!(s.handle.opacity, 1.0);
}
