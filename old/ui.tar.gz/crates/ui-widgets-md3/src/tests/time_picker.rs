//! MD3 time input: the 12-hour arithmetic, and the one action a frame reports.
//! MD3 时间输入：12 小时制算术，以及一帧上报的那一个动作。

use super::*;

use crate::time_picker::{
    Md3TimeInput, Period, TimePickerChange, TimePickerParams, TIME_INPUT_FIELD, TIME_INPUT_PERIOD,
};
use ui_core::cx::Routing;
use ui_core::Change;
use ui_widgets::WidgetState;

const P: Id = Id::str("time");

fn build(routing: Routing, params: TimePickerParams<'_>) -> (Md3TimeInput, Decl) {
    let mut store = AnimStore::new();
    let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 400, 0.0, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let picker = Md3TimeInput::from_pack(&crate::pack::pack(), &mut cx, params);
    let decl = cx.with_cx(|cx| picker.decl(cx));
    (picker, decl)
}

fn plain(params: TimePickerParams<'_>) -> (Md3TimeInput, Decl) {
    build(Routing::default(), params)
}

/// The change a click on `hit` produces, through the path the engine would route.
/// 点击 `hit` 产生的变化，路径与引擎的路由一致。
fn clicked(params: TimePickerParams<'_>, hit: Id) -> Option<Change> {
    let routing = Routing {
        clicked_path: vec![P, hit],
        ..Routing::default()
    };
    let (picker, _) = build(routing, params);
    picker.change(&WidgetState::default(), ui_core::geom::Rect::ZERO)
}

fn fact(change: Option<Change>) -> Option<TimePickerChange> {
    change?.data::<TimePickerChange>().ok()
}

#[test]
fn twelve_am_is_midnight_and_twelve_pm_is_noon() {
    // The two hours every hand-rolled converter gets wrong: noon and midnight are both 12
    // on the clock face but eleven apart in the day.
    // 每个手写换算都会错的两小时：午夜与正午在表盘上都是 12，却相隔十一小时。
    assert_eq!(Period::Am.hour24(12), 0);
    assert_eq!(Period::Pm.hour24(12), 12);
    assert_eq!(Period::Am.hour24(1), 1);
    assert_eq!(Period::Pm.hour24(1), 13);
    assert_eq!(Period::Am.hour24(11), 11);
    assert_eq!(Period::Pm.hour24(11), 23);
}

#[test]
fn every_hour_of_the_day_round_trips_through_the_period_and_the_clock() {
    // A one-way test would pass with `from_hour24` off by twelve; the round trip cannot.
    // 单向测试在 `from_hour24` 差十二时仍会通过；往返不会。
    for hour in 0..24 {
        let (period, clock) = Period::from_hour24(hour);
        assert!((1..=12).contains(&clock), "{hour} -> {clock}");
        assert_eq!(period.hour24(clock), hour, "{hour} -> {clock} {period:?}");
    }
}

#[test]
fn a_third_digit_is_dropped_and_the_fitted_hour_is_reported() {
    // The engine edits whatever buffer the control declares, so fitting it is the only way
    // the field can hold two digits; the trimmed value must still reach the app.
    // 引擎编辑控件声明的缓冲，因此裁好它是输入格只留两位的唯一办法；裁出的值仍须送达应用。
    let params = TimePickerParams {
        hour: "123",
        ..TimePickerParams::new(P, "", "45", Period::Am)
    };
    let (picker, _) = plain(params);
    assert_eq!(picker.hour_text(), "12");
    assert_eq!(picker.minute_text(), "45");
    assert_eq!(
        fact(picker.change(&WidgetState::default(), ui_core::geom::Rect::ZERO)),
        Some(TimePickerChange::Hour("12".to_string()))
    );
}

#[test]
fn a_buffer_with_no_valid_hour_is_still_reported_as_the_text_to_keep() {
    // Typing into the front of "09" gives "009", which fits to "00" — no 12-hour clock has
    // hour 0, so a numeric payload would report nothing and the app's buffer would stay "009".
    // 在 "09" 前面输入得到 "009"，裁成 "00"——12 小时制没有 0 点，数字载荷会什么都不报，
    // 应用的缓冲就永远停在 "009"。
    let params = TimePickerParams {
        hour: "009",
        ..TimePickerParams::new(P, "", "30", Period::Am)
    };
    let (picker, _) = plain(params);
    assert_eq!(picker.hour_text(), "00");
    assert_eq!(
        fact(picker.change(&WidgetState::default(), ui_core::geom::Rect::ZERO)),
        Some(TimePickerChange::Hour("00".to_string()))
    );
}

#[test]
fn clicking_am_reports_the_am_tile_even_when_pm_was_selected() {
    // A period control reports which tile was hit, not the opposite of the old value: the
    // app decides what re-selecting the current period means.
    // 周期控件上报被点中的块，而不是旧值的反面：重复点当前周期意味着什么由应用决定。
    let params = TimePickerParams::new(P, "09", "30", Period::Pm);
    let change = clicked(params, P.with("am"));
    assert_eq!(
        fact(change),
        Some(TimePickerChange::Period(Period::Am))
    );
}

fn find_decl(decl: &Decl, id: Id) -> Option<&Decl> {
    if decl.id == id {
        return Some(decl);
    }
    decl.children.iter().find_map(|child| find_decl(child, id))
}

#[test]
fn a_focused_field_fills_with_primary_container_and_takes_the_primary_edge() {
    // Focus is the only state that moves both the fill and the border; reading them from
    // the wrong token leaves one half of the pair unchanged and is invisible in a screenshot.
    // 焦点是唯一同时改变填充与描边的状态；取错令牌只会改一半，截图里看不出来。
    let pack = crate::pack::pack();
    let hour = P.with("hour");
    let mut store = AnimStore::new();
    let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 400, 0.0, 0.0, 1.0, None);
    core.route(Routing {
        focused: Some(hour),
        focus_visible: true,
        ..Routing::default()
    });
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let picker =
        Md3TimeInput::from_pack(&pack, &mut cx, TimePickerParams::new(P, "09", "30", Period::Am));
    let decl = cx.with_cx(|cx| picker.decl(cx));
    let fill = |decl: &Decl| match decl.shapes.first() {
        Some(ui_core::draw::Shape::Box { fill, .. }) => *fill,
        _ => panic!("a filled box"),
    };
    let edge = |decl: &Decl| {
        decl.shapes.iter().find_map(|shape| match shape {
            ui_core::draw::Shape::Box { border: Some((ink, width)), .. } => Some((*ink, *width)),
            _ => None,
        })
    };
    let focused = find_decl(&decl, hour).expect("the hour field");
    let resting = find_decl(&decl, P.with("minute")).expect("the minute field");
    assert_eq!(fill(focused), pack.ink("primaryContainer").expect("a role"));
    assert_eq!(fill(resting), pack.ink("surfaceContainerHighest").expect("a role"));
    assert_eq!(
        edge(focused),
        Some((pack.ink("primary").expect("a role"), 2.0))
    );
    assert_eq!(edge(resting), None, "an unfocused field paints no edge");
}

#[test]
fn the_exported_sizes_reach_the_layout() {
    // The export's 96×72 fields, 52×72 selector and 24dp padding are the surface's whole
    // anatomy; a squeezed or stretched child means the table and the layout disagree.
    // 导出的 96×72 输入格、52×72 选择器与 24dp 内衬就是表面的全部解剖；子节点被压扁或
    // 拉伸都说明表与布局对不上。
    let (_, decl) = plain(TimePickerParams::new(P, "09", "30", Period::Am));
    let tree = lay_out(&decl, (328.0, 182.0));
    assert_eq!(
        region_rect(&tree, P.with("hour")),
        (24.0, 60.0, TIME_INPUT_FIELD.0, TIME_INPUT_FIELD.1)
    );
    assert_eq!(
        region_rect(&tree, P.with("minute")),
        (144.0, 60.0, TIME_INPUT_FIELD.0, TIME_INPUT_FIELD.1)
    );
    assert_eq!(
        region_rect(&tree, P.with("period")),
        (252.0, 60.0, TIME_INPUT_PERIOD.0, TIME_INPUT_PERIOD.1)
    );
    assert_eq!(
        region_rect(&tree, P.with("am")),
        (252.0, 60.0, TIME_INPUT_PERIOD.0, TIME_INPUT_PERIOD.1 * 0.5)
    );
    assert_eq!(
        region_rect(&tree, P.with("pm")),
        (252.0, 96.0, TIME_INPUT_PERIOD.0, TIME_INPUT_PERIOD.1 * 0.5)
    );
}
