//! The MD3 card: one surface in three variants, holding the app's own content.
//! MD3 卡片：同一种表面的三种变体，承载应用自身的内容。

use super::*;

use crate::spec::{elevated_card_spec, filled_card_spec, outlined_card_spec};
use crate::toggle::{role, spec_ink};
use ui_core::cx::Routing;
use ui_core::draw::Shape;
use ui_core::geom::Rect;
use ui_widgets::WidgetState;

const CARD: Id = Id::str("card");

fn content() -> Vec<Decl> {
    vec![Decl::container(Id::str("card/body"), NodeKind::Column)
        .size(SizeClass::fixed(120.0, 40.0))]
}

fn build(
    store: &mut AnimStore,
    routing: Routing,
    variant: CardVariant,
    clickable: bool,
    params: Md3Options,
) -> (Md3Card, Decl) {
    let mut core = ui_core::cx::Cx::new(store, 0, 400, 400, 0.0, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let card = Md3Card::new_with(params, CARD, variant, content(), clickable, &mut cx, &crate::pack::pack());
    let decl = cx.with_cx(|cx| card.decl(cx));
    (card, decl)
}

fn plain(variant: CardVariant) -> (Md3Card, Decl) {
    let mut store = AnimStore::new();
    build(&mut store, Routing::default(), variant, false, Md3Options::default())
}

/// Every box in paint order: the container, then the state layer, then the ring.
/// 按绘制顺序给出每个盒子：容器、状态层、焦点环。
fn boxes(decl: &Decl) -> Vec<(Color, Option<(Color, f32)>, Option<ui_core::tree::ShadowSpec>)> {
    decl.shapes
        .iter()
        .filter_map(|s| match s {
            Shape::Box { fill, border, shadow, .. } => Some((*fill, *border, *shadow)),
            _ => None,
        })
        .collect()
}

#[test]
fn each_variant_takes_its_exported_fill() {
    // The three exports differ only in the container they paint; using one fill for all
    // collapses the variants into one look.
    // 三份导出的差别只在容器；三种共用一个填充会把变体塌成一种外观。
    let pack = crate::pack::pack();
    let cases = [
        (CardVariant::Elevated, elevated_card_spec(false, false, false, false, false).container.color),
        (CardVariant::Filled, filled_card_spec(false, false, false, false, false).container.color),
        (CardVariant::Outlined, outlined_card_spec(false, false, false, false, false).container.color),
    ];
    for (variant, token) in cases {
        let (_, decl) = plain(variant);
        assert_eq!(boxes(&decl)[0].0, spec_ink(&pack, token, 1.0), "{variant:?}");
    }
    assert_eq!(role(&pack, "surfaceContainerLow"), spec_ink(&pack, cases[0].1, 1.0));
}

#[test]
fn only_the_outlined_variant_draws_a_ring() {
    // The ring is what distinguishes an outlined card from a filled one at elevation 0.
    // 描边正是轮廓卡片在 0 立面下与填充卡片的区别。
    let pack = crate::pack::pack();
    let spec = outlined_card_spec(false, false, false, false, false);
    let (_, outlined) = plain(CardVariant::Outlined);
    let (_, border, _) = boxes(&outlined)[0];
    let (ink, width) = border.expect("an outlined card draws a ring");
    assert_eq!(ink, spec_ink(&pack, spec.outline.color, spec.outline.opacity));
    assert_eq!(width, spec.outline.width);
    for variant in [CardVariant::Elevated, CardVariant::Filled] {
        let (_, decl) = plain(variant);
        assert_eq!(boxes(&decl)[0].1, None, "{variant:?} has no ring");
    }
}

#[test]
fn a_hovered_card_lifts_to_the_exported_elevation() {
    // Hover raises an elevated card from 1 to 3 and a filled one from 0 to 1; keeping the
    // resting elevation makes the hover look dead.
    // 悬停把立面卡片从 1 抬到 3、把填充卡片从 0 抬到 1；沿用静止立面会让悬停毫无反应。
    let cases = [
        (CardVariant::Elevated, 1.0, 3.0),
        (CardVariant::Filled, 0.0, 1.0),
    ];
    for (variant, rest, hover) in cases {
        let mut store = AnimStore::new();
        let (_, still) = build(&mut store, Routing::default(), variant, true, Md3Options::default());
        let rest_blur = boxes(&still)[0].2.map(|s| s.blur).unwrap_or(0.0);
        assert!((rest_blur - rest * 2.0).abs() < 0.01, "{variant:?} rests at {rest_blur}");
        let routing = Routing { hovered: Some(CARD), hovered_path: vec![CARD], ..Routing::default() };
        let mut store = AnimStore::new();
        let (_, lit) = build(&mut store, routing, variant, true, Md3Options::default());
        let hover_blur = boxes(&lit)[0].2.map(|s| s.blur).unwrap_or(0.0);
        assert!((hover_blur - hover * 2.0).abs() < 0.01, "{variant:?} hovers at {hover_blur}");
    }
}

#[test]
fn a_static_card_paints_no_state_layer() {
    // A card without an action cannot be hovered by the user; painting the layer anyway
    // makes a static card look clickable.
    // 没有动作的卡片用户悬停不到；照画状态层会让静态卡片看起来可点。
    let routing = Routing { hovered: Some(CARD), hovered_path: vec![CARD], ..Routing::default() };
    let mut store = AnimStore::new();
    let (_, still) = build(&mut store, routing.clone(), CardVariant::Filled, false, Md3Options::default());
    assert_eq!(boxes(&still).len(), 1, "only the container");
    let mut store = AnimStore::new();
    let (_, live) = build(&mut store, routing, CardVariant::Filled, true, Md3Options::default());
    let pack = crate::pack::pack();
    let spec = filled_card_spec(true, false, false, false, false);
    let ink = role(&pack, spec.state_layer.color);
    let want = Color { a: ink.a * spec.state_layer.opacity, ..ink };
    assert_eq!(boxes(&live).len(), 2, "container then layer");
    assert_eq!(boxes(&live)[1].0, want);
}

#[test]
fn a_clickable_card_reports_activation_and_a_static_one_does_not() {
    // The card is the only thing an app can hang an action on; a static card must stay silent.
    // 卡片是应用唯一能挂动作的地方；静态卡片必须保持沉默。
    let bounds = Rect::new(0.0, 0.0, 200.0, 120.0);
    let click = WidgetState { clicked: true, ..Default::default() };
    let mut store = AnimStore::new();
    let (live, _) = build(&mut store, Routing::default(), CardVariant::Filled, true, Md3Options::default());
    assert!(matches!(live.change(&click, bounds), Some(ui_core::Change::Activated)));
    let (still, _) = plain(CardVariant::Filled);
    assert!(still.change(&click, bounds).is_none());
    let params = Md3Options { disabled: true, ..Md3Options::default() };
    let mut store = AnimStore::new();
    let (disabled, _) = build(&mut store, Routing::default(), CardVariant::Filled, true, params);
    assert!(disabled.change(&click, bounds).is_none());
}

#[test]
fn the_content_sits_inside_the_pad() {
    // The card's own inset is what keeps text off the rounded edge; a zero pad puts the
    // content in the corners where the radius clips it.
    // 卡片自身的内衬让文字离开圆角边缘；内衬为零会把内容放到被圆角裁掉的角上。
    let (card, decl) = plain(CardVariant::Filled);
    let root = Decl::container(Id::str("root"), NodeKind::Row)
        .cross_align(0.0)
        .child(decl);
    let tree = lay_out(&root, (400.0, 400.0));
    let (x, y, w, h) = region_rect(&tree, CARD);
    let (bx, by, bw, bh) = region_rect(&tree, Id::str("card/body"));
    assert!((bx - x - card.pad()).abs() < 0.01, "content at {bx}, card at {x}");
    assert!((by - y - card.pad()).abs() < 0.01);
    assert!((w - bw - card.pad() * 2.0).abs() < 0.01, "card {w} wide, content {bw}");
    assert!((h - bh - card.pad() * 2.0).abs() < 0.01, "card h {h}, content h {bh}");
}
