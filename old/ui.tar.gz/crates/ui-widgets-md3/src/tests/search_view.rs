//! The MD3 search view: the bar's surface grown over the results it finds.
//! MD3 搜索视图：搜索栏的表面长开来盖住它找到的结果。

use super::*;

use crate::search_view::{Md3SearchView, SearchViewChange, SearchViewParams};
use ui_core::cx::Routing;
use ui_core::geom::{Rect, Size};
use ui_core::NodeData;
use ui_widgets::WidgetState;

const VIEW: Id = Id::str("view");
const COLLAPSED: Size = Size::new(320.0, 56.0);
const OPEN: Size = Size::new(320.0, 420.0);
const ACTION: Id = Id::str("close");

fn icon(id: Id, ink: Color) -> Decl {
    Decl::container(id, NodeKind::Box)
        .size(SizeClass::fixed(24.0, 24.0))
        .background(ink, ui_core::geom::Corners::ZERO)
}

fn build_at(
    store: &mut AnimStore,
    expanded: bool,
    now: f64,
    routing: Routing,
) -> (Md3SearchView, Decl) {
    let mut core = ui_core::cx::Cx::new(store, 0, 480, 600, now, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let params = SearchViewParams::new(VIEW, COLLAPSED, OPEN)
        .text("query")
        .hint("Search")
        .expanded(expanded)
        .leading(ui_widgets::IconSource::Custom(icon))
        .action(ACTION, ui_widgets::IconSource::Custom(icon))
        .results(vec![Decl::container(Id::str("hit"), NodeKind::Box)
            .size(SizeClass::fixed(200.0, 40.0))]);
    let view = Md3SearchView::new_with(Md3Options::default(), params, &mut cx, crate::pack::pack());
    let decl = cx.with_cx(|cx| view.decl(cx));
    (view, decl)
}

fn build(store: &mut AnimStore, expanded: bool, now: f64) -> (Md3SearchView, Decl) {
    build_at(store, expanded, now, Routing::default())
}

fn laid(decl: Decl) -> Tree {
    let root = Decl::container(Id::str("root"), NodeKind::Column).child(decl);
    lay_out(&root, (480.0, 600.0))
}

fn find(decl: &Decl, id: Id) -> Option<&Decl> {
    if decl.id == id {
        return Some(decl);
    }
    decl.children.iter().find_map(|c| find(c, id))
}

/// The radius the surface is drawn with.
/// 表面绘制所用的圆角。
fn radius(decl: &Decl) -> f32 {
    match find(decl, VIEW).expect("the view exists").shapes.first() {
        Some(ui_core::draw::Shape::Box { corners, .. }) => corners.tl,
        other => panic!("the surface is a box, got {other:?}"),
    }
}

/// A background box's fill alpha, by node id.
/// 某个节点的背景填充透明度。
fn alpha(decl: &Decl, id: Id) -> f32 {
    let node = find(decl, id).unwrap_or_else(|| panic!("missing {id:?}"));
    match node.shapes.first() {
        Some(ui_core::draw::Shape::Box { fill, .. }) => fill.a,
        other => panic!("{id:?} paints a box, got {other:?}"),
    }
}

/// The group opacity the results are composited at.
/// 结果整体合成时的不透明度。
fn results_alpha(decl: &Decl) -> f32 {
    match &find(decl, VIEW.with("results")).expect("the results exist").data {
        NodeData::Container(p) => p.opacity,
        other => panic!("the results are a container, got {other:?}"),
    }
}

#[test]
fn the_surface_opens_from_the_bar_over_the_results_on_one_clock() {
    // One control at two sizes: the declaration carries the target and the engine walks the
    // size there, while the radius, the divider and the results follow the same progress on
    // the same frame. At rest the bar is one line, so nothing is laid out beneath it.
    // 一控两端：声明带目标、引擎把尺寸走过去；圆角、分隔线与结果在同一帧上跟同一进度。
    // 静止时栏只有一行，下面没有任何东西参与布局。
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, false, 0.0);
    assert_eq!(radius(&decl), 28.0, "a pill while it is the bar");
    // Declaring the target is not enough: the node has to ask the engine to walk there.
    // 只声明目标不够：节点还得请引擎走过去。
    match &find(&decl, VIEW).expect("the view exists").data {
        NodeData::Container(p) => {
            assert_eq!(p.size_transition.expect("the size travels").duration, 0.3);
        }
        other => panic!("the view is a container, got {other:?}"),
    }
    assert!(find(&decl, VIEW.with("divider")).is_none(), "nothing under a resting bar");
    assert!(find(&decl, VIEW.with("results")).is_none(), "and no results");
    let tree = laid(decl);
    assert_eq!(region_rect(&tree, VIEW), (0.0, 0.0, COLLAPSED.w, COLLAPSED.h));
    assert_eq!(region_rect(&tree, VIEW.with("header")).3, 56.0);

    // Opening: the target is declared whole, and everything the engine does not move is
    // part-way there.
    // 展开：目标是整个声明的，引擎不负责的部分都停在半路。
    let (_, _) = build(&mut store, true, 0.0);
    let (_, mid) = build(&mut store, true, 0.08);
    assert!(radius(&mid) > 0.0 && radius(&mid) < 28.0, "the corners are rounding away, {}", radius(&mid));
    assert!(alpha(&mid, VIEW.with("divider")) > 0.0 && alpha(&mid, VIEW.with("divider")) < 1.0, "the divider is fading in");
    assert!(results_alpha(&mid) > 0.0 && results_alpha(&mid) < 1.0, "the results are fading in");
    let tree = laid(mid);
    assert_eq!(region_rect(&tree, VIEW), (0.0, 0.0, OPEN.w, OPEN.h), "the declaration is the target");
    let header = region_rect(&tree, VIEW.with("header")).3;
    assert!(header > 56.0 && header < 72.0, "the header is growing, {header}");

    let (_, open) = build(&mut store, true, 1.0);
    assert_eq!(radius(&open), 0.0, "an open view is square");
    assert_eq!(alpha(&open, VIEW.with("divider")), 1.0);
    assert_eq!(results_alpha(&open), 1.0);
    let tree = laid(open);
    assert_eq!(region_rect(&tree, VIEW), (0.0, 0.0, OPEN.w, OPEN.h));
    assert_eq!(region_rect(&tree, VIEW.with("header")).3, 72.0);
    assert!(region_rect(&tree, Id::str("hit")).3 > 0.0, "the results are laid out below the divider");
}

#[test]
fn the_resting_bar_asks_to_open_and_an_open_view_does_not() {
    // The bar is a button that asks the app to open the view; once open, a click in the
    // header is an ordinary edit and must not keep asking — that loop would never settle.
    // 静止的栏是请应用展开视图的按钮；展开之后头部里的点击只是普通编辑，
    // 不能继续请求——那样的循环永远停不下来。
    let mut store = AnimStore::new();
    let (shut, _) = build(&mut store, false, 0.0);
    let click = WidgetState { clicked: true, ..Default::default() };
    match shut.change(&click, Rect::ZERO).expect("the bar reports").data::<SearchViewChange>() {
        Ok(SearchViewChange::Activated) => {}
        Ok(other) => panic!("a resting click is not {other:?}"),
        Err(other) => panic!("not a search view change: {other:?}"),
    }
    let (open, _) = build(&mut store, true, 1.0);
    assert!(open.change(&click, Rect::ZERO).is_none(), "an open view stays open");

    // An action reports itself, open or shut.
    // 动作自报身份，开合都一样。
    let routing = Routing { clicked_path: vec![VIEW, ACTION], ..Routing::default() };
    let (shut, _) = build_at(&mut store, false, 1.0, routing);
    match shut.change(&click, Rect::ZERO).expect("the action reports").data::<SearchViewChange>() {
        Ok(SearchViewChange::Action(id)) => assert_eq!(id, ACTION),
        Ok(other) => panic!("an action click is not {other:?}"),
        Err(other) => panic!("not a search view change: {other:?}"),
    }
}
