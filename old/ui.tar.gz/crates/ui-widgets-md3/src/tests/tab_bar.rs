//! The MD3 secondary navigation tab bar: equal shares, the underline, the centred content and
//! the ink crossfade.
//! MD3 次级导航页签栏：等分、下划线、居中的内容，以及墨色的交叉淡变。

use super::*;

use crate::spec::secondary_navigation_tab_spec;
use crate::tab_bar::{Md3TabBar, TAB_DIVIDER, TAB_HEIGHT, TAB_ICON_HEIGHT, TAB_ICON_MARGIN};
use crate::toggle::{role, spec_ink};
use ui_core::cx::Routing;
use ui_core::draw::Shape;
use ui_core::geom::{Point, Rect};
use ui_core::NodeData;

const BAR: Id = Id::str("bar");
const WIDTH: f32 = 300.0;

/// A 24dp mark in the tab's ink: the icon variant's stand-in for a real glyph.
/// 24dp、按页签墨色绘制的标记：图标变体用来代替真实字形。
fn dot(id: Id, ink: Color) -> Decl {
    Decl::container(id, NodeKind::Box)
        .size(SizeClass::fixed(24.0, 24.0))
        .shapes(vec![Shape::Box {
            corners: ui_core::Corners::ZERO,
            fill: ink,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }])
}

fn items(with_icon: bool) -> Vec<Md3TabItem<'static>> {
    ["One", "Two", "Three"]
        .into_iter()
        .enumerate()
        .map(|(k, label)| {
            if with_icon {
                Md3TabItem::with_icon(tab_id(k), label, ui_widgets::IconSource::Custom(dot))
            } else {
                Md3TabItem::text(tab_id(k), label)
            }
        })
        .collect()
}

fn build(
    store: &mut AnimStore,
    routing: Routing,
    now: f64,
    with_icon: bool,
    selected: usize,
    params: Md3Options,
) -> (Md3TabBar, Decl) {
    let mut core = ui_core::cx::Cx::new(store, 0, 400, 200, now, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let list = items(with_icon);
    let control = Md3TabBar::new_with(params, BAR, &list, selected, WIDTH, &mut cx, &crate::pack::pack());
    let decl = cx.with_cx(|cx| control.decl(cx));
    (control, decl)
}

/// Lay the bar out as the only child of a `WIDTH`-wide column, so it is stretched to it.
/// 把栏作为 `WIDTH` 宽列的唯一子节点布局，使它被撑到该宽度。
fn laid(decl: Decl) -> Tree {
    let root = Decl::container(Id::str("root"), NodeKind::Column).child(decl);
    lay_out(&root, (WIDTH, 200.0))
}

fn find(decl: &Decl, id: Id) -> Option<&Decl> {
    if decl.id == id {
        return Some(decl);
    }
    decl.children.iter().find_map(|c| find(c, id))
}

fn tab_id(k: usize) -> Id {
    BAR.with(("tab", k))
}

fn label_ink(decl: &Decl, k: usize) -> Color {
    match &find(decl, tab_id(k).with("label")).expect("every tab carries a label").data {
        NodeData::Text { ink, .. } => *ink,
        _ => panic!("the label is a text node"),
    }
}

/// The bar's one underline: its height and fill, or nothing when the bar paints none.
/// 整条栏共用的下划线：高度与填充色；栏不画时为 `None`。
fn underline(decl: &Decl) -> Option<(f32, Color)> {
    let d = find(decl, BAR.with("indicator"))?;
    match d.shapes.first() {
        Some(Shape::Box { fill, .. }) => Some((d.size_class.height.max, *fill)),
        other => panic!("the underline is a box, got {other:?}"),
    }
}

/// The state layer, if the tab paints one; the focus ring is the only other box, and it
/// carries a border.
/// 状态层（若在画）；另一个盒子是焦点环，它带边框。
fn layer(decl: &Decl, k: usize) -> Option<Color> {
    find(decl, tab_id(k)).expect("the tab exists").shapes.iter().find_map(|s| match s {
        Shape::Box { fill, border: None, .. } => Some(*fill),
        _ => None,
    })
}

fn ring(decl: &Decl, k: usize) -> Option<(Color, f32)> {
    find(decl, tab_id(k)).expect("the tab exists").shapes.iter().find_map(|s| match s {
        Shape::Box { border: Some(b), .. } => Some(*b),
        _ => None,
    })
}

#[test]
fn the_exported_bar_height_is_the_tab_box_plus_the_indicator_band() {
    // Flutter's tab is `_kTabHeight` tall and the bar reserves the indicator's 2dp below it;
    // the export's 48dp container is exactly that sum, so either constant moving breaks it.
    // Flutter 的页签高 `_kTabHeight`，栏在其下方为下划线留 2dp；导出的 48dp 容器正是这个和，
    // 任一常量变动都会与令牌失配。
    let spec = secondary_navigation_tab_spec(false, false, false, false, false);
    assert_eq!(spec.container.height, TAB_HEIGHT + spec.active_indicator.height);
    let mut store = AnimStore::new();
    let (control, decl) = build(&mut store, Routing::default(), 0.0, false, 0, Md3Options::default());
    assert_eq!(control.strip_height(), spec.container.height);
    assert_eq!(control.height(), spec.container.height + TAB_DIVIDER);
    assert_eq!(decl.size_class.height.max, control.height());
}

#[test]
fn tabs_divide_the_bar_into_equal_shares() {
    // Flutter wraps every tab in `Expanded`. Hinting a width instead makes a short label's tab
    // narrow and lets the last one eat the remainder.
    // Flutter 给每个页签套 `Expanded`。若改为给出宽度 hint，短标签的页签会变窄，最后一个吃掉剩余。
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Routing::default(), 0.0, false, 0, Md3Options::default());
    let tree = laid(decl);
    let share = WIDTH / 3.0;
    for k in 0..3 {
        let (x, _, w, _) = region_rect(&tree, tab_id(k));
        assert!((w - share).abs() < 1e-4, "tab {k} is {w} wide");
        assert!((x - share * k as f32).abs() < 1e-4, "tab {k} starts at {x}");
    }
    // The underline is `TabBarIndicatorSize.tab`: the whole tab, not just the label.
    // 下划线按 `TabBarIndicatorSize.tab`：整个页签宽，而不是只有标签宽。
    let (ix, _, iw, _) = region_rect(&tree, BAR.with("indicator"));
    assert!((iw - share).abs() < 1e-4, "the underline spans the tab, got {iw}");
    assert!((ix - share * 0.0).abs() < 1e-4, "and sits under the selected tab, at {ix}");
}

#[test]
fn a_press_selects_the_tab_under_the_pointer() {
    // The bar maps the press point itself; the app never sees a coordinate, so a wrong share
    // selects the neighbour and the app switches to the wrong page.
    // 栏自己在自身空间映射按下点；app 看不到坐标，份额算错就会选中相邻页签，app 于是切到错误的页。
    let mut store = AnimStore::new();
    let (control, _) = build(&mut store, Routing::default(), 0.0, false, 2, Md3Options::default());
    let bounds = Rect::new(0.0, 0.0, WIDTH, control.height());
    let press = |x: f32, y: f32| ui_widgets::WidgetState {
        clicked: true,
        local: Some(Point::new(x, y)),
        ..Default::default()
    };
    // Every share's first pixel belongs to that share, not to the one before it.
    // 每一份的第一个像素属于它自己，而不是前一份。
    for (x, want) in [(20.0, 0), (120.0, 1), (199.0, 1)] {
        match control.change(&press(x, 20.0), bounds) {
            Some(ui_core::Change::Selected(Some(id))) => assert_eq!(id, tab_id(want), "x={x}"),
            other => panic!("x={x} expected Selected(tab {want}), got {other:?}"),
        }
    }
}

#[test]
fn a_bar_reports_nothing_for_the_selected_tab_or_the_divider() {
    // Re-selecting the current tab is not a change, and the divider band belongs to no tab;
    // reporting either would make the app re-render for nothing or select a neighbour.
    // 重选当前页签不算变化，分隔线工带也不属于任何页签；上报任一都会让 app 白刷新或选中相邻页签。
    let mut store = AnimStore::new();
    let (control, _) = build(&mut store, Routing::default(), 0.0, false, 1, Md3Options::default());
    let bounds = Rect::new(0.0, 0.0, WIDTH, control.height());
    let press = |x: f32, y: f32| ui_widgets::WidgetState {
        clicked: true,
        local: Some(Point::new(x, y)),
        ..Default::default()
    };
    assert!(control.change(&press(120.0, 20.0), bounds).is_none(), "the current tab");
    assert!(
        control.change(&press(260.0, control.strip_height() + 0.5), bounds).is_none(),
        "the divider"
    );
    // A pointer that is merely over the bar reports nothing: a click is required.
    let hover = ui_widgets::WidgetState {
        local: Some(Point::new(260.0, 20.0)),
        ..Default::default()
    };
    assert!(control.change(&hover, bounds).is_none(), "no click, no selection");
}

#[test]
fn the_underline_sits_under_the_selected_tab_and_slides_to_it() {
    // One underline serves the whole bar; keying it on the tab's own index instead would put
    // one under every tab, and a stale slide value would leave it under the old one.
    // 整条栏共用一条下划线；若按页签自身下标为键，每个页签都会有一条，
    // 而陈旧的滑移值会让它留在旧页签下。
    let pack = crate::pack::pack();
    let spec = secondary_navigation_tab_spec(true, false, false, false, false);
    let primary = spec_ink(&pack, spec.active_indicator.color, 1.0);
    let share = WIDTH / 3.0;
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Routing::default(), 0.0, false, 1, Md3Options::default());
    let (h, fill) = underline(&decl).expect("the bar paints one underline");
    assert!((h - spec.active_indicator.height).abs() < 1e-4, "the band is {h}");
    assert_eq!(fill, primary, "in the exported indicator colour");
    let tree = laid(decl);
    let (x, _, _, _) = region_rect(&tree, BAR.with("indicator"));
    assert!((x - share).abs() < 1e-4, "the underline starts at {x}, want {share}");
    // Selecting another tab moves it there over the 300ms travel, not in one frame.
    // 选中另一个页签会让它在 300ms 的行程里过去，而不是一帧跳过去。
    build(&mut store, Routing::default(), 0.0, false, 2, Md3Options::default());
    let (_, mid) = build(&mut store, Routing::default(), 0.15, false, 2, Md3Options::default());
    let tree = laid(mid);
    let (mx, _, _, _) = region_rect(&tree, BAR.with("indicator"));
    assert!(mx > share && mx < share * 2.0, "halfway the underline is at {mx}");
    let (_, decl) = build(&mut store, Routing::default(), 0.4, false, 2, Md3Options::default());
    let tree = laid(decl);
    let (x, _, _, _) = region_rect(&tree, BAR.with("indicator"));
    assert!((x - share * 2.0).abs() < 1e-4, "settled it starts at {x}");
    // The web demo animates it over 250ms; Flutter's 300ms would still be in flight at 260.
    // 网页 demo 用 250ms 走完；Flutter 的 300ms 在 260ms 时还在途中。
    let (_, nearly) = build(&mut store, Routing::default(), 0.26, false, 2, Md3Options::default());
    let tree = laid(nearly);
    let (x, _, _, _) = region_rect(&tree, BAR.with("indicator"));
    assert!((x - share * 2.0).abs() < 1e-4, "arrived by 260ms, at {x}");
}

#[test]
fn an_icon_tab_grows_to_the_text_and_icon_height_and_centres_its_content() {
    // `_kTextAndIconTabHeight` is 72; the mark sits `iconMargin` above the label and the block
    // is centred, so the space above the mark equals the space below the label.
    // `_kTextAndIconTabHeight` 是 72；标记在标签上方留 `iconMargin`，整块居中，
    // 因此标记上方的空间与标签下方的空间相等。
    let mut store = AnimStore::new();
    let (control, decl) = build(&mut store, Routing::default(), 0.0, true, 0, Md3Options::default());
    let spec = secondary_navigation_tab_spec(true, true, false, false, false);
    assert_eq!(control.strip_height(), TAB_ICON_HEIGHT + spec.active_indicator.height);
    let tree = laid(decl);
    let (_, tab_y, _, _) = region_rect(&tree, tab_id(0));
    let (_, icon_y, _, icon_h) = region_rect(&tree, tab_id(0).with("icon"));
    let (_, label_y, _, label_h) = region_rect(&tree, tab_id(0).with("label"));
    assert!((icon_h - spec.icon.size).abs() < 1e-4, "the mark is {} tall", icon_h);
    assert!(
        (label_y - (icon_y + icon_h) - TAB_ICON_MARGIN).abs() < 1e-4,
        "the mark and the label are {} apart",
        label_y - (icon_y + icon_h)
    );
    let above = icon_y - tab_y;
    let below = (tab_y + TAB_ICON_HEIGHT) - (label_y + label_h);
    assert!((above - below).abs() < 1e-3, "{above} above vs {below} below");
}

#[test]
fn the_divider_sits_below_the_strip_and_takes_the_outline_variant_ink() {
    // The underline occupies the strip's last 2dp; a divider drawn on the same band would be
    // covered by it, and one drawn in another ink breaks the row the bar closes.
    // 下划线占用页签带的最后 2dp；画在同一工带上的分隔线会被它盖住，换成别的墨色则破坏了栏收尾的那条线。
    let mut store = AnimStore::new();
    let (control, decl) = build(&mut store, Routing::default(), 0.0, false, 0, Md3Options::default());
    let pack = crate::pack::pack();
    let fill = match &find(&decl, BAR.with("divider")).expect("the bar paints a divider").shapes[0] {
        Shape::Box { fill, .. } => *fill,
        other => panic!("the divider is a box, got {other:?}"),
    };
    assert_eq!(fill, role(&pack, "outlineVariant"));
    let tree = laid(decl);
    let (_, y, _, h) = region_rect(&tree, BAR.with("divider"));
    assert!((y - control.strip_height()).abs() < 1e-4, "divider at {y}");
    assert!((h - TAB_DIVIDER).abs() < 1e-4, "divider is {h} tall");
}

#[test]
fn a_hovered_tab_paints_the_eight_percent_state_layer() {
    // Flutter's overlay priority for a hovered tab is `onSurface` at 8%. A shared key paints it
    // on every tab, and the pressed 10% is a different, wrong strength.
    // Flutter 给悬停页签的状态层是 8% 的 `onSurface`。共用动画键会让每个页签都画，
    // 而按下的 10% 是另一种、错误的强度。
    let pack = crate::pack::pack();
    let routing = Routing {
        hovered: Some(tab_id(1)),
        hovered_path: vec![BAR, tab_id(1)],
        ..Routing::default()
    };
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, routing, 0.0, false, 0, Md3Options::default());
    let ink = role(&pack, "onSurface");
    let want = Color { a: ink.a * 0.08, ..ink };
    assert_eq!(layer(&decl, 1), Some(want), "the hovered tab carries the layer");
    assert_eq!(layer(&decl, 0), None, "its neighbour does not");
    assert_eq!(layer(&decl, 2), None, "nor the one after");
}

#[test]
fn the_label_ink_crossfades_over_three_hundred_milliseconds() {
    // `kTabScrollDuration` drives the ink; a step change makes the label flick between two
    // colours instead of the reference's fade, and the wrong easing shows at the midpoint.
    // `kTabScrollDuration` 驱动墨色；突变会让标签在两个颜色之间闪，而不是参考的淡变；
    // 曲线写错则在中点显形。
    let pack = crate::pack::pack();
    let on = spec_ink(&pack, secondary_navigation_tab_spec(true, false, false, false, false).label_text.color, 1.0);
    let off = spec_ink(&pack, secondary_navigation_tab_spec(false, false, false, false, false).label_text.color, 1.0);
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Routing::default(), 0.0, false, 1, Md3Options::default());
    assert_eq!(label_ink(&decl, 1), on, "the selected tab takes the active ink");
    assert_eq!(label_ink(&decl, 0), off, "the others keep the inactive ink");
    // Halfway through the fade the *old* tab has come half way back to the inactive ink.
    // 淡变过半时，**旧**页签已回到非活动墨色的一半。
    // The retarget frame only latches `from`; the fade starts on the frame after it.
    // 重定向那一帧只锁存 `from`；淡变从它之后的一帧开始。
    build(&mut store, Routing::default(), 0.0, false, 0, Md3Options::default());
    let (_, mid) = build(&mut store, Routing::default(), 0.15, false, 0, Md3Options::default());
    assert_eq!(label_ink(&mid, 1), off.lerp(on, 0.5));
}

#[test]
fn a_disabled_bar_fades_its_inks_once_and_drops_the_underline() {
    // The export defines no disabled inks, so MD3's 38% content rule applies; the underline
    // must go, or the bar still advertises a selection it can no longer change.
    // 导出没有禁用配色，因此套用 MD3 的 38% 内容规则；下划线必须撤掉，
    // 否则栏仍在展示一个它已无法改变的选择。
    let mut store = AnimStore::new();
    let params = Md3Options { disabled: true, ..Md3Options::default() };
    let (_, decl) = build(&mut store, Routing::default(), 0.0, false, 0, params);
    assert!((label_ink(&decl, 0).a - 0.38).abs() < 1e-4, "label at 38%");
    let (_, fill) = underline(&decl).expect("the bar still declares its underline");
    assert_eq!(fill.a, 0.0, "a disabled bar paints no underline");
    assert_eq!(layer(&decl, 0), None, "and no state layer");
}

#[test]
fn the_focus_ring_keys_on_keyboard_focus_not_pointer_focus() {
    // A pointer press also focuses the tab; drawing the ring then puts a keyboard affordance on
    // every click, which the reference never does.
    // 指针按下同样会给页签焦点；此时画环会把键盘提示挂在每次点击上，参考从不这样。
    let focused = Routing {
        focused: Some(tab_id(0)),
        focus_visible: false,
        ..Routing::default()
    };
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, focused, 0.0, false, 0, Md3Options::default());
    assert_eq!(ring(&decl, 0), None, "pointer focus draws no ring");
    let keyboard = Routing {
        focused: Some(tab_id(0)),
        focus_visible: true,
        ..Routing::default()
    };
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, keyboard, 0.0, false, 0, Md3Options::default());
    let pack = crate::pack::pack();
    let spec = secondary_navigation_tab_spec(false, false, false, false, false);
    let (ink, width) = ring(&decl, 0).expect("keyboard focus draws the ring");
    assert_eq!(ink, spec_ink(&pack, spec.focus_indicator.color, 1.0));
    assert_eq!(width, spec.focus_indicator.thickness);
}

