//! The MD3 search bar: one query on one line, and the actions it owns.
//! MD3 搜索栏：一行查询，以及它自己的动作。

use super::*;

use crate::search_bar::{
    Md3SearchBar, SearchBarChange, SearchBarParams, SEARCH_BAR_HEIGHT,
};
use ui_core::cx::Routing;
use ui_core::geom::Corners;
use ui_core::NodeData;
use ui_widgets::WidgetState;

const BAR: Id = Id::str("bar");
const WIDTH: f32 = 320.0;
const MIC: Id = Id::str("mic");

fn icon(id: Id, ink: Color) -> Decl {
    Decl::container(id, NodeKind::Box)
        .size(SizeClass::fixed(24.0, 24.0))
        .background(ink, Corners::ZERO)
}

fn build(routing: Routing, text: &str) -> (Md3SearchBar, Decl) {
    let mut store = AnimStore::new();
    let mut core = ui_core::cx::Cx::new(&mut store, 0, 480, 400, 0.0, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let params = SearchBarParams::new(BAR, WIDTH)
        .text(text)
        .hint("Search")
        .leading(ui_widgets::IconSource::Custom(icon))
        .action(MIC, ui_widgets::IconSource::Custom(icon));
    let bar = Md3SearchBar::new_with(Md3Options::default(), params, &mut cx, &crate::pack::pack());
    let decl = cx.with_cx(|cx| bar.decl(cx));
    (bar, decl)
}

fn find(decl: &Decl, id: Id) -> &Decl {
    fn walk(decl: &Decl, id: Id) -> Option<&Decl> {
        if decl.id == id {
            return Some(decl);
        }
        decl.children.iter().find_map(|c| walk(c, id))
    }
    walk(decl, id).unwrap_or_else(|| panic!("no node {id:?}"))
}

#[test]
fn the_bar_is_the_height_the_export_gives_it() {
    // 56dp and a pill: the export's `container.height` and its circular shape.
    // 56dp 的胶囊：导出的 `container.height` 与 circular 形状。
    let (_, decl) = build(Routing::default(), "");
    let tree = laid_out(decl);
    let (_, _, w, h) = region_rect(&tree, BAR);
    assert_eq!((w, h), (WIDTH, SEARCH_BAR_HEIGHT), "bar box");
}

#[test]
fn a_query_too_long_for_the_bar_stays_on_one_line() {
    // A search query is edited, not read: it must never wrap into a second line.
    // 搜索查询是被编辑的，不是被阅读的：绝不能折成第二行。
    let (_, decl) = build(Routing::default(), "a query far longer than the bar can show");
    let input = find(&decl, BAR.with("input"));
    match &input.data {
        NodeData::Text { nowrap, .. } => assert!(*nowrap, "the query draws on one line"),
        other => panic!("the input is not text: {other:?}"),
    }
}

#[test]
fn an_action_reports_its_own_id_and_nothing_else() {
    // The engine routes a click through the whole path; only the action's own click fires.
    // 引擎把点击沿整条路径路由；只有动作自己的点击算数。
    let routing = Routing {
        clicked_path: vec![BAR, MIC],
        ..Routing::default()
    };
    let (bar, _) = build(routing, "x");
    match bar
        .change(&WidgetState::default(), ui_core::geom::Rect::ZERO)
        .expect("the action reports")
        .data::<SearchBarChange>()
    {
        Ok(SearchBarChange::Action(id)) => assert_eq!(id, MIC),
        Err(other) => panic!("not a search change: {other:?}"),
    }

    let (quiet, _) = build(Routing::default(), "x");
    assert!(quiet
        .change(&WidgetState::default(), ui_core::geom::Rect::ZERO)
        .is_none());
}
