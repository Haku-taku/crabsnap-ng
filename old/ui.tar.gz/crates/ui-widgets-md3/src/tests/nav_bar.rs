//! The MD3 navigation bar: equal destinations, the 64×32 capsule, the label behaviour and the
//! press that names a destination.
//! MD3 导航栏：等宽目标、64×32 胶囊、标签行为，以及指认目标的按下。

use super::*;

use crate::spec::navigation_bar_spec;
use crate::{
    Md3NavBar, Md3NavItem, NavBarParams, NavLabelBehavior,
};
use ui_core::cx::Routing;
use ui_core::draw::Shape;
use ui_core::geom::{Corners, Point, Rect};
use ui_core::{NodeData, Weight};

const BAR: Id = Id::str("nav");
const WIDTH: f32 = 300.0;

fn item_id(k: usize) -> Id {
    BAR.with(("item", k))
}

/// A 24dp mark in the destination's ink: the stand-in for a real glyph.
/// 24dp、按目标墨色绘制的标记：真实字形的替身。
fn dot(id: Id, ink: Color) -> Decl {
    Decl::container(id, NodeKind::Box)
        .size(SizeClass::fixed(24.0, 24.0))
        .shapes(vec![Shape::Box {
            corners: ui_core::Corners::ZERO,
            fill: ink,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }])
}

fn items() -> Vec<Md3NavItem<'static>> {
    ["Home", "Search", "Library"]
        .into_iter()
        .enumerate()
        .map(|(k, label)| Md3NavItem::new(item_id(k), label, ui_widgets::IconSource::Custom(dot)))
        .collect()
}

fn build(
    store: &mut AnimStore,
    selected: usize,
    label_behavior: NavLabelBehavior,
) -> (Md3NavBar, Decl) {
    build_at(store, selected, label_behavior, 0.0)
}

fn build_at(
    store: &mut AnimStore,
    selected: usize,
    label_behavior: NavLabelBehavior,
    now: f64,
) -> (Md3NavBar, Decl) {
    let mut core = ui_core::cx::Cx::new(store, 0, 400, 200, now, 0.0, 1.0, None);
    core.route(Routing::default());
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let list = items();
    let control = Md3NavBar::new_with(
        Md3Options::default(),
        NavBarParams { id: BAR, items: &list, selected, label_behavior, disabled: false },
        &mut cx,
        &crate::pack::pack(),
    );
    let decl = cx.with_cx(|cx| control.decl(cx));
    (control, decl)
}

fn laid(decl: Decl) -> Tree {
    let root = Decl::container(Id::str("root"), NodeKind::Column).child(decl);
    lay_out(&root, (WIDTH, 200.0))
}

fn find(decl: &Decl, id: Id) -> Option<&Decl> {
    if decl.id == id {
        return Some(decl);
    }
    decl.children.iter().find_map(|c| find(c, id))
}

fn label_weight(decl: &Decl, k: usize) -> Weight {
    match &find(decl, item_id(k).with("label")).expect("the destination carries a label").data {
        NodeData::Text { block, .. } => block.runs[0].style.weight,
        _ => panic!("the label is a text node"),
    }
}

#[test]
fn the_bar_is_the_exported_height_and_its_destinations_split_it_equally() {
    // The export's 80dp is the bar's whole height, and Flutter wraps each destination in
    // `Expanded`; a width hint instead lets a short label's destination go narrow.
    // 导出的 80dp 是整条栏的高度，且 Flutter 给每个目标套 `Expanded`；
    // 若改为给出宽度 hint，短标签的目标就会变窄。
    let spec = navigation_bar_spec(false, false, false, false);
    let mut store = AnimStore::new();
    let (control, decl) = build(&mut store, 0, NavLabelBehavior::AlwaysShow);
    assert_eq!(control.height(), spec.container.height);
    let tree = laid(decl);
    let (_, _, _, h) = region_rect(&tree, BAR);
    assert!((h - spec.container.height).abs() < 1e-4, "the bar is {h} tall");
    let share = WIDTH / 3.0;
    for k in 0..3 {
        let (x, _, w, _) = region_rect(&tree, item_id(k));
        assert!((w - share).abs() < 1e-4, "destination {k} is {w} wide");
        assert!((x - share * k as f32).abs() < 1e-4, "destination {k} starts at {x}");
    }
}

#[test]
fn the_capsule_is_the_exported_size_centred_on_the_selected_destination() {
    // The 64×32 `corner.full` capsule is the selected destination's whole mark; a wrong width
    // or a capsule hung off the destination's edge is visible at a glance.
    // 64×32 的 `corner.full` 胶囊是选中目标的全部标记；宽度错了或挂在目标边上，一眼就看得出来。
    let spec = navigation_bar_spec(false, false, false, false);
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, 1, NavLabelBehavior::AlwaysShow);
    let selected = find(&decl, item_id(1).with("indicator")).expect("the destination has one");
    match selected.shapes.first() {
        Some(Shape::Rect { rect, corners, .. }) => {
            assert_eq!((rect.size.w, rect.size.h), (spec.active_indicator.width, spec.active_indicator.height));
            assert_eq!((corners.tl, corners.tr), (16.0, 16.0), "a stadium, not a rounded box");
        }
        other => panic!("the capsule is an explicit rect, got {other:?}"),
    }
    let idle = find(&decl, item_id(0).with("indicator")).expect("the destination has one");
    assert!(idle.shapes.is_empty(), "an unselected destination paints no capsule");
    let tree = laid(decl);
    let (dx, _, dw, _) = region_rect(&tree, item_id(1));
    let (ix, _, iw, _) = region_rect(&tree, item_id(1).with("indicator"));
    assert!((iw - spec.active_indicator.width).abs() < 1e-4, "the capsule is {iw} wide");
    assert!((ix - (dx + (dw - iw) * 0.5)).abs() < 1e-3, "the capsule starts at {ix}, not centred");
}

#[test]
fn the_selected_label_is_bold_and_the_others_are_medium() {
    // The export gives the active label weight 700 and the inactive one 500; a bar that keeps
    // one weight loses the only typographic cue besides colour.
    // 导出给选中标签 700、未选中 500；只用一种字重的栏会丢掉颜色之外唯一的排版线索。
    let spec = navigation_bar_spec(false, false, false, false);
    let active = navigation_bar_spec(true, false, false, false);
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, 1, NavLabelBehavior::AlwaysShow);
    assert_eq!(label_weight(&decl, 1), Weight(active.label_text.weight as u16));
    assert_eq!(label_weight(&decl, 0), Weight(spec.label_text.weight as u16));
    assert_ne!(label_weight(&decl, 0), label_weight(&decl, 1));
}

#[test]
fn the_capsule_dissolves_with_its_width_instead_of_appearing_at_full_strength() {
    // Selection is a dissolve: a half-open capsule is also half transparent, otherwise the
    // first frame is a hairline of solid colour.
    // 选中是溶解：展开一半的胶囊也半透明，否则第一帧就是一条满色细线。
    let spec = navigation_bar_spec(false, false, false, false);
    let mut store = AnimStore::new();
    let (_, _) = build_at(&mut store, 0, NavLabelBehavior::AlwaysShow, 0.0);
    // The frame that commits the new target is still at the old value; the next one moves.
    // 提交新目标的那一帧还停在旧值；下一帧才开始移动。
    let (_, _) = build_at(&mut store, 1, NavLabelBehavior::AlwaysShow, 0.0);
    let (_, decl) = build_at(&mut store, 1, NavLabelBehavior::AlwaysShow, 0.25);
    let capsule = find(&decl, item_id(0).with("indicator")).expect("the destination has one");
    let Some(Shape::Rect { rect, fill, .. }) = capsule.shapes.first() else {
        panic!("the outgoing capsule is still drawn mid-transition");
    };
    assert!(
        rect.size.w > 0.0 && rect.size.w < spec.active_indicator.width,
        "width {} is mid-scale",
        rect.size.w
    );
    assert!(fill.a > 0.0 && fill.a < 1.0, "alpha {} is mid-dissolve", fill.a);
}

#[test]
fn a_press_names_the_destination_under_the_pointer_and_reselection_reports_nothing() {
    // The bar maps the press point itself, so a wrong share selects the neighbour; and
    // re-selecting the current destination must not make the app re-render.
    // 栏自己在自身空间映射按下点，份额算错就会选中邻居；重选当前目标也不该让 app 白刷新。
    let mut store = AnimStore::new();
    let (control, _) = build(&mut store, 0, NavLabelBehavior::AlwaysShow);
    let bounds = Rect::new(0.0, 0.0, WIDTH, control.height());
    let press = |x: f32, y: f32| ui_widgets::WidgetState {
        clicked: true,
        local: Some(Point::new(x, y)),
        ..Default::default()
    };
    for (x, want) in [(199.0, 1), (260.0, 2)] {
        match control.change(&press(x, 40.0), bounds) {
            Some(ui_core::Change::Selected(Some(id))) => assert_eq!(id, item_id(want), "x={x}"),
            other => panic!("x={x} expected Selected(destination {want}), got {other:?}"),
        }
    }
    assert!(control.change(&press(99.0, 40.0), bounds).is_none(), "the current destination");
    assert!(control.change(&press(120.0, 100.0), bounds).is_none(), "below the bar");
    let hover = ui_widgets::WidgetState { local: Some(Point::new(20.0, 40.0)), ..Default::default() };
    assert!(control.change(&hover, bounds).is_none(), "no click, no selection");
}

#[test]
fn a_destinations_ink_clips_to_its_own_indicator() {
    // The ripple covers the icon's capsule, not the whole destination: the export draws the
    // capsule behind the icon, and the ink declaring that capsule as its clip keeps the
    // splash inside the effective background (Flutter `_IndicatorInkWell`).
    // 墨迹盖住图标的胶囊，而不是整个目标：导出把胶囊画在图标后面，墨迹以它为裁剪目标，
    // 涟漪就留在有效背景内（Flutter `_IndicatorInkWell`）。
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, 1, NavLabelBehavior::AlwaysShow);
    for k in 0..3 {
        let dest = find(&decl, item_id(k)).expect("the destination exists");
        let ink = match &dest.data {
            NodeData::Container(p) => p.press_ink.expect("every destination declares press ink"),
            _ => panic!("the destination is a container"),
        };
        assert_eq!(
            ink.target,
            ui_core::InkTarget::Descendant(item_id(k).with("indicator")),
            "destination {k} clips its ink to its own capsule"
        );
    }
}

#[test]
fn an_unselected_destination_still_offers_a_capsule_to_cut_the_ripple_to() {
    // The slot exists before its capsule opens and declares the capsule curve, so a press on
    // an unselected destination still ripples inside a pill instead of having no background.
    // 槽位在胶囊展开之前就存在，并声明了胶囊曲线；未选中目标上的按压因此在胶囊内起涟漪，
    // 而不是没有背景可用。
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, 0, NavLabelBehavior::AlwaysShow);
    let slot = find(&decl, item_id(1).with("indicator")).expect("the slot exists");
    match &slot.data {
        NodeData::Container(p) => {
            assert_eq!(p.corners, Some(Corners::all(16.0)), "a stadium, not a square");
        }
        _ => panic!("the slot is a container"),
    }
    assert!(slot.shapes.is_empty(), "and it paints nothing while unselected");
}

#[test]
fn hiding_labels_changes_neither_the_bar_height_nor_the_other_destinations() {
    // `labelBehavior` is the app's parameter and the export has no token for it; whichever
    // mode is chosen, the bar stays 80dp and only the label's presence changes.
    // `labelBehavior` 是应用的参数，导出没有对应令牌；无论选哪种模式，栏都保持 80dp，
    // 变的只有标签的有无。
    let spec = navigation_bar_spec(false, false, false, false);
    let mut store = AnimStore::new();
    let (_, hidden) = build(&mut store, 0, NavLabelBehavior::AlwaysHide);
    for k in 0..3 {
        assert!(find(&hidden, item_id(k).with("label")).is_none(), "destination {k} has a label");
    }
    let tree = laid(hidden);
    let (_, _, _, h) = region_rect(&tree, BAR);
    assert!((h - spec.container.height).abs() < 1e-4, "with no labels the bar is {h} tall");

    let mut store = AnimStore::new();
    let (_, only) = build(&mut store, 1, NavLabelBehavior::OnlyShowSelected);
    // Every destination reserves the slot and only the ink follows the selection, so the
    // content slides between two positions instead of the bar re-laying itself out.
    // 每个目标都留出标签位置，只有墨色跟随选中，内容因此在两个位置间滑动，
    // 而不是让整条栏重新布局。
    for k in 0..3 {
        assert!(find(&only, item_id(k).with("label")).is_some(), "destination {k} has its slot");
    }
    assert!(label_alpha(&only, 1) > 0.99, "the selected label is fully inked");
    assert!(label_alpha(&only, 0) < 0.01, "an idle label is transparent");
    assert!(label_alpha(&only, 2) < 0.01, "an idle label is transparent");
    let tree = laid(only);
    let (_, _, _, h) = region_rect(&tree, BAR);
    assert!((h - spec.container.height).abs() < 1e-4, "one label keeps the bar at {h}");
}

#[test]
fn a_selected_only_bar_cross_fades_its_labels_and_slides_the_icons_without_resizing() {
    // Switching selection in a selected-only bar is a cross-fade, not a swap: the outgoing
    // label fades while its icon slides to the bare position, the incoming one fades in as its
    // icon rises, and every destination keeps its height so nothing else moves.
    // 「仅选中」栏切换选中是交叉淡出而非替换：旧标签淡出、图标滑向无标签位置，
    // 新标签淡入而图标升起；每个目标高度不变，因此别处都不移动。
    let mut store = AnimStore::new();
    let (_, start) = build_at(&mut store, 0, NavLabelBehavior::OnlyShowSelected, 0.0);
    let start_tree = laid(start);
    let out_icon = region_rect(&start_tree, item_id(0).with("icon")).1;
    let in_icon = region_rect(&start_tree, item_id(1).with("icon")).1;
    let item_h = region_rect(&start_tree, item_id(0)).3;
    // The frame that commits the new target is still at the old value; the next one moves.
    // 提交新目标的那一帧还停在旧值；下一帧才开始移动。
    let (_, _) = build_at(&mut store, 1, NavLabelBehavior::OnlyShowSelected, 0.0);
    let (_, mid) = build_at(&mut store, 1, NavLabelBehavior::OnlyShowSelected, 0.25);
    let (out, inn) = (label_alpha(&mid, 0), label_alpha(&mid, 1));
    let mid_tree = laid(mid);
    let (_, out_mid, _, _) = region_rect(&mid_tree, item_id(0).with("icon"));
    let (_, in_mid, _, _) = region_rect(&mid_tree, item_id(1).with("icon"));
    assert!(out_mid > out_icon, "the outgoing icon slides down: {out_mid} > {out_icon}");
    assert!(in_mid < in_icon, "the incoming icon rises: {in_mid} < {in_icon}");
    assert!(
        (region_rect(&mid_tree, item_id(1)).3 - item_h).abs() < 1e-4,
        "the destination keeps its height"
    );
    assert!(out > 0.0 && out < 1.0, "the outgoing label is at {out}");
    assert!(inn > 0.0 && inn < 1.0, "the incoming label is at {inn}");
}

/// The alpha a destination's label is drawn at.
/// 目标标签绘制时的透明度。
fn label_alpha(decl: &Decl, k: usize) -> f32 {
    match &find(decl, item_id(k).with("label")).expect("the destination carries a label").data {
        NodeData::Text { ink, .. } => ink.a,
        _ => panic!("the label is a text node"),
    }
}
