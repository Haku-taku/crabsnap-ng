//! The MD3 dialog: a modal surface with an icon, a title, a body and the app's actions.
//! MD3 对话框：带图标、标题、正文与应用动作的模态表面。

use super::*;

use crate::spec::dialog_spec;
use crate::toggle::{role, spec_ink};
use ui_core::cx::Routing;
use ui_core::geom::{Corners, Insets, Rect, Size};
use ui_core::{Change, ModalTarget, TextAlign};
use ui_widgets::WidgetState;

const D: Id = Id::str("dialog");
const WIDTH: f32 = 320.0;
const AREA: Size = Size::new(400.0, 300.0);
/// Where the tree would put the dialog if the engine did not place it on its target.
/// 若引擎不把它放到目标上，树会给它的位置。
const INSET: Insets = Insets { left: 40.0, right: 0.0, top: 30.0, bottom: 0.0 };
const LONG: &str = "A body long enough to need more than one line inside the surface, \
                    because a dialog wraps at its own insets and not at the window.";

fn action(label: &str) -> DialogAction {
    DialogAction { id: D.with(label), label: label.to_string() }
}

fn content() -> DialogContent {
    DialogContent {
        id: D,
        title: Some("Discard draft?".to_string()),
        body: Some(LONG.to_string()),
        content: Vec::new(),
        actions: vec![action("cancel"), action("discard")],
        icon: DialogIcon::None,
        build_icon: None,
        width: WIDTH,
        target: ModalTarget::Global,
        barrier: true,
    }
}

fn build(store: &mut AnimStore, routing: Routing, content: DialogContent) -> (Md3Dialog, Decl) {
    let mut core = ui_core::cx::Cx::new(store, 0, 400, 300, 0.0, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let dialog = Md3Dialog::new_with(
        Md3Options::default(),
        content,
        &mut cx,
        &crate::pack::pack(),
    );
    let decl = cx.with_cx(|cx| dialog.decl(cx));
    (dialog, decl)
}

fn plain(content: DialogContent) -> (Md3Dialog, Decl) {
    let mut store = AnimStore::new();
    build(&mut store, Routing::default(), content)
}

/// The dialog as a child of a padded window: the tree would inset it, the target does not.
/// 作为带内衬窗口子节点的对话框：树会给它内衬，目标不会。
fn laid_out(content: DialogContent) -> Tree {
    let (_, decl) = plain(content);
    let root = Decl::container(Id::str("window"), NodeKind::Column)
        .size(SizeClass::fixed(AREA.w, AREA.h))
        .padding(INSET)
        .child(decl);
    lay_out(&root, (AREA.w, AREA.h))
}

/// The text alignment a band's leaf declares.
/// 某条带的文字叶子所声明的对齐方式。
fn align_of(decl: &Decl, id: Id) -> TextAlign {
    let mut found = None;
    walk(decl, &mut |d| {
        if d.id == id
            && let ui_core::NodeData::Text { block, .. } = &d.data {
                found = Some(block.align);
            }
    });
    found.unwrap_or_else(|| panic!("no text node at {id:?}"))
}

fn walk(decl: &Decl, f: &mut impl FnMut(&Decl)) {
    f(decl);
    for child in &decl.children {
        walk(child, f);
    }
}

#[test]
fn the_scrim_covers_its_target_and_the_surface_centres_in_it() {
    // The scrim blocks what is behind the dialog; measured to its own content it leaves the
    // rest of the window clickable, and an off-centre surface reads as a panel, not a modal.
    // It must also cover the *target*, not the slot the tree gave it: a dialog declared
    // inside a padded column would otherwise dim that column's content box.
    // 遮罩挡住对话框身后的内容；按自身内容测量会留下可点击的窗口其余部分，
    // 而不居中的表面看起来像面板而不是模态。它还必须盖住**目标**而不是树给它的位置：
    // 声明在带内衬的列里的对话框，否则只会压暗那一列的内容盒。
    let tree = laid_out(content());
    let (x, y, w, h) = region_rect(&tree, D);
    assert_eq!((x, y, w, h), (0.0, 0.0, AREA.w, AREA.h), "the scrim fills the window");
    let (sx, sy, sw, _) = region_rect(&tree, D.with("surface"));
    assert_eq!(sw, WIDTH, "the surface keeps the width the app chose");
    assert!((sx - (AREA.w - WIDTH) * 0.5).abs() < 0.01, "surface x {sx}");
    let (_, _, _, sh) = region_rect(&tree, D.with("surface"));
    let want_y = (AREA.h - sh) * 0.5;
    assert!((sy - want_y).abs() < 0.01, "surface y {sy}, want {want_y} of h {sh}");
}

#[test]
fn the_text_wraps_at_the_surface_insets_not_at_the_window() {
    // A container passes its own available width down; a dialog that lets the window's width
    // through measures one long line and then clips it against the 28dp corners.
    // 容器会把自己的可用宽度传下去；让窗口宽度穿过的对话框会量出一整行，再被 28dp 圆角裁掉。
    let tree = laid_out(content());
    let (sx, _, _, _) = region_rect(&tree, D.with("surface"));
    let (bx, _, bw, _) = region_rect(&tree, D.with("body"));
    // The painter wraps at `wrap_width`, not at the node's rect, so that is the fact to pin.
    // 绘制端按 `wrap_width` 换行而不是按节点矩形，因此要钉住的是这个值。
    let wrap = tree
        .get(tree.find_by_id(D.with("body")).expect("body"))
        .expect("node")
        .wrap_width;
    assert!((wrap - (WIDTH - 2.0 * DIALOG_SIDE_PAD)).abs() < 0.01, "body wraps at {wrap}");
    assert!((bw - (WIDTH - 2.0 * DIALOG_SIDE_PAD)).abs() < 0.01, "body box is {bw}");
    assert!((bx - sx - DIALOG_SIDE_PAD).abs() < 0.01, "body starts at {bx}, surface at {sx}");
}

#[test]
fn the_scrim_dims_what_is_behind_it_rather_than_hiding_it() {
    // `showDialog`'s barrier is `Colors.black54`; an opaque one hides the content the dialog
    // is asking about, which is the context the user needs in order to answer.
    // `showDialog` 的屏障是 `Colors.black54`；不透明屏障会遮住对话框正在询问的内容，
    // 而那正是用户作答所需的上下文。
    let (_, decl) = plain(content());
    let alpha = box_fill(&decl).a;
    let want = SCRIM_OPACITY * role(&crate::pack::pack(), "scrim").a;
    assert!((alpha - want).abs() < 0.01, "scrim alpha {alpha}, want {want}");
    assert!(alpha < 0.9, "an opaque scrim hides the page behind it");
}

#[test]
fn an_action_click_names_the_action_it_landed_on() {
    // The actions are decls, not elements, so their own `change()` never runs: the dialog has
    // to name the one that was hit, or the app cannot tell "discard" from "cancel".
    // 动作是声明而不是元素，它们自己的 `change()` 从不执行：对话框必须指出被点中的那个，
    // 否则应用分不清「丢弃」与「取消」。
    let hit = D.with("discard");
    let routing = Routing { clicked_path: vec![D, D.with("surface"), D.with("actions-box"), hit], ..Routing::default() };
    let mut store = AnimStore::new();
    let (dialog, _) = build(&mut store, routing, content());
    assert!(matches!(
        dialog.change(&WidgetState::default(), Rect::ZERO),
        Some(Change::Selected(Some(id))) if id == hit
    ));
}

#[test]
fn a_click_on_the_scrim_cancels_and_a_click_inside_the_surface_does_not() {
    // A modal's barrier dismisses; a press on the surface's own padding must not, or the
    // dialog closes whenever the user misses a button by two pixels.
    // 模态屏障会被点击关闭；落在表面自身内衬上的按下则不能，否则用户偏两像素就会关掉对话框。
    let scrim = Routing { clicked_path: vec![D], ..Routing::default() };
    let mut store = AnimStore::new();
    let (dialog, _) = build(&mut store, scrim, content());
    assert!(matches!(
        dialog.change(&WidgetState::default(), Rect::ZERO),
        Some(Change::Cancelled)
    ));
    let inside = Routing {
        clicked_path: vec![D, D.with("surface"), D.with("body-box"), D.with("body")],
        ..Routing::default()
    };
    let mut store = AnimStore::new();
    let (dialog, _) = build(&mut store, inside, content());
    assert!(dialog.change(&WidgetState::default(), Rect::ZERO).is_none());
}

#[test]
fn the_actions_sit_at_the_far_end_of_their_band() {
    // OverflowBar aligns its children at the end; a start-aligned row puts the destructive
    // action on the left, where MD3 never places it.
    // OverflowBar 把子节点对齐到远端；起始对齐会把破坏性动作放到左边，MD3 从不这样摆。
    let tree = laid_out(content());
    let (sx, _, sw, _) = region_rect(&tree, D.with("surface"));
    let (ax, _, aw, _) = region_rect(&tree, D.with("discard"));
    let want = sx + sw - DIALOG_SIDE_PAD;
    assert!((ax + aw - want).abs() < 0.01, "actions end at {}, want {want}", ax + aw);
    let (cx, _, _, _) = region_rect(&tree, D.with("cancel"));
    assert!((ax - cx).abs() > ACTION_GAP - 0.01, "the two actions overlap: {cx} vs {ax}");
}

#[test]
fn an_icon_centres_every_line_and_its_absence_leaves_them_started() {
    // Flutter centres both lines when an icon is present; taking that from the *requested*
    // icon instead of the resolved one centres a dialog that draws no icon at all.
    // Flutter 在有图标时把标题与正文都居中；若按**请求的**图标而非解析出的图标决定，
    // 就会把一个根本没画图标的对话框居中。
    let icon = |id: Id, ink: Color| {
        Decl::container(id, NodeKind::Box).size(SizeClass::fixed(24.0, 24.0)).background(ink, Corners::ZERO)
    };
    let with = DialogContent {
        icon: DialogIcon::Slot,
        build_icon: Some(ui_widgets::IconSource::Custom(icon as fn(Id, Color) -> Decl)),
        ..content()
    };
    let (_, decl) = plain(with);
    assert_eq!(align_of(&decl, D.with("headline")), TextAlign::Center);
    assert_eq!(align_of(&decl, D.with("body")), TextAlign::Center);
    let (_, decl) = plain(content());
    assert_eq!(align_of(&decl, D.with("headline")), TextAlign::Start);
    assert_eq!(align_of(&decl, D.with("body")), TextAlign::Start);
    // Asked for an icon, handed no builder: there is no icon, so nothing centres.
    // 请求了图标却没给构建器：图标并不存在，因此什么也不居中。
    let orphan = DialogContent { icon: DialogIcon::Slot, build_icon: None, ..content() };
    let (_, decl) = plain(orphan);
    assert_eq!(align_of(&decl, D.with("headline")), TextAlign::Start);
}

#[test]
fn the_action_labels_take_the_exported_label_text_colour() {
    // The actions reuse the button, so the dialog's own `label-text` token is never read; if
    // the two exports drift apart the dialog silently follows the button.
    // 动作复用按钮，因此对话框自己的 `label-text` 令牌从未被读取；两份导出一旦分叉，
    // 对话框会悄悄跟着按钮走。
    let pack = crate::pack::pack();
    let want = spec_ink(&pack, dialog_spec(false, false, false, crate::spec::DialogIconSlot::Base).label_text.color, 1.0);
    let (_, decl) = plain(content());
    let mut ink = None;
    walk(&decl, &mut |d| {
        if d.id == D.with("discard").with("label")
            && let ui_core::NodeData::Text { ink: i, .. } = &d.data {
                ink = Some(*i);
            }
    });
    assert_eq!(ink, Some(want));
}

/// The first declaration under `id`, walking the tree the same way the engine does.
/// `id` 下的第一个声明，按引擎的方式遍历树。
fn find(decl: &Decl, id: Id) -> Option<&Decl> {
    if decl.id == id {
        return Some(decl);
    }
    decl.children.iter().find_map(|c| find(c, id))
}

/// The same dialog with a measurer, so the action band can size its labels before layout.
/// 接入测量器的同一个对话框，动作带因此能在布局前量出标签尺寸。
fn band_kind(labels: &[&str]) -> ui_core::NodeKind {
    let mut store = AnimStore::new();
    let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 300, 0.0, 0.0, 1.0, None);
    core.route(Routing::default());
    core.attach_measure(std::rc::Rc::new(std::cell::RefCell::new(
        ui_core::MonospaceMeasure::default(),
    )));
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let mut c = content();
    c.actions = labels.iter().map(|label| action(label)).collect();
    let dialog = Md3Dialog::new_with(Md3Options::default(), c, &mut cx, &crate::pack::pack());
    let decl = cx.with_cx(|cx| dialog.decl(cx));
    find(&decl, D.with("actions")).expect("the band holds the actions").kind
}

#[test]
fn actions_that_cannot_share_a_line_stack_at_the_far_end() {
    // OverflowBar: the band is 272dp wide, so three long labels stack instead of being
    // crushed past their text; short labels keep the row.
    // OverflowBar：带只有 272dp 宽，三个长标签因此竖排而不是被压到文字以内；
    // 短标签仍保持横排。
    assert_eq!(band_kind(&["Not now", "Save draft", "Publish"]), ui_core::NodeKind::Column);
    assert_eq!(band_kind(&["OK", "No"]), ui_core::NodeKind::Row);
}

#[test]
fn a_disabled_dialog_reports_nothing_even_when_an_action_is_clicked() {
    // A disabled dialog is inert; still reporting the action would let the app act on a
    // dialog the user was told was unavailable.
    // 禁用的对话框是惰性的；仍上报动作会让应用对被明示不可用的对话框采取行动。
    let hit = D.with("discard");
    let routing = Routing { clicked_path: vec![D, D.with("surface"), D.with("actions-box"), hit], ..Routing::default() };
    let mut store = AnimStore::new();
    let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 300, 0.0, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let params = Md3Options { disabled: true, ..Md3Options::default() };
    let dialog = Md3Dialog::new_with(params, content(), &mut cx, &crate::pack::pack());
    assert!(dialog.change(&WidgetState::default(), Rect::ZERO).is_none());
}

