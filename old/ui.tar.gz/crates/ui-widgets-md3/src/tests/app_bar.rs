//! The MD3 top app bar: exported heights, the title's inset, and the slot that reports a press.
//! MD3 顶部应用栏：导出的高度、标题的内衬，以及上报按下的槽位。

use super::*;

use crate::app_bar::{
    AppBarAction, AppBarLeading, AppBarParams, AppBarVariant, Md3AppBar, APP_BAR_SLOT,
    APP_BAR_TITLE_GAP, APP_BAR_TITLE_INSET,
};
use ui_core::cx::Routing;
use ui_core::draw::Shape;
use ui_core::Change;
use ui_widgets::WidgetState;

const BAR: Id = Id::str("bar");
const WIDTH: f32 = 480.0;

/// A 24dp mark in the ink the bar resolved, standing in for a real glyph.
/// 按栏解析出的墨色绘制的 24dp 标记，用来代替真实字形。
fn mark(id: Id, ink: Color) -> Decl {
    Decl::container(id, NodeKind::Box)
        .size(SizeClass::fixed(24.0, 24.0))
        .shapes(vec![Shape::Box {
            corners: ui_core::Corners::ZERO,
            fill: ink,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }])
}

fn build(
    store: &mut AnimStore,
    routing: Routing,
    variant: AppBarVariant,
    subtitle: Option<&'static str>,
    leading: bool,
    actions: usize,
    collapsed: bool,
) -> (Md3AppBar, Decl) {
    let mut core = ui_core::cx::Cx::new(store, 0, WIDTH as u32, 400, 0.0, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let list: Vec<AppBarAction> = (0..actions)
        .map(|k| AppBarAction { id: BAR.with(("action", k)), icon: ui_widgets::IconSource::Custom(mark) })
        .collect();
    let content = AppBarParams {
        id: BAR,
        variant,
        title: "Inbox",
        subtitle,
        leading: if leading {
            AppBarLeading::Icon(ui_widgets::IconSource::Custom(mark))
        } else {
            AppBarLeading::None
        },
        actions: &list,
        width: WIDTH,
    };
    let bar = Md3AppBar::new_with(
        Md3Options::default(),
        content,
        false,
        collapsed,
        &mut cx,
        &crate::pack::pack(),
    );
    let decl = cx.with_cx(|cx| bar.decl(cx));
    (bar, decl)
}

#[test]
fn every_variant_takes_the_height_the_export_gives_it() {
    // The five heights and the 56dp search pill come straight from the export; a clamp
    // anywhere in the control would show up here.
    // 五个高度与 56dp 的搜索胶囊直接来自导出；控件里任何夹取都会在这里露出来。
    for (variant, subtitle, want) in [
        (AppBarVariant::Small, None, 64.0),
        (AppBarVariant::Medium, None, 112.0),
        (AppBarVariant::Large, None, 152.0),
        (AppBarVariant::MediumFlexible, Some("12 new"), 136.0),
        (AppBarVariant::LargeFlexible, Some("12 new"), 152.0),
        (AppBarVariant::Search, None, 56.0),
    ] {
        let mut store = AnimStore::new();
        let (bar, _) = build(&mut store, Routing::default(), variant, subtitle, true, 1, false);
        assert_eq!(bar.height(), want, "{variant:?} with subtitle {subtitle:?}");
    }
}

#[test]
fn a_collapsed_flexible_bar_takes_the_small_height_and_a_rigid_one_ignores_the_flag() {
    // Collapsing is the flexible variants' whole point; the rigid ones must not move.
    // 收起是可收起变体的全部意义；固定变体不得移动。
    let mut store = AnimStore::new();
    let (shut, _) = build(
        &mut store,
        Routing::default(),
        AppBarVariant::MediumFlexible,
        Some("12 new"),
        true,
        0,
        true,
    );
    assert_eq!(shut.height(), 64.0);

    let mut store = AnimStore::new();
    let (open, _) = build(
        &mut store,
        Routing::default(),
        AppBarVariant::MediumFlexible,
        Some("12 new"),
        true,
        0,
        false,
    );
    assert_eq!(open.height(), 136.0);

    let mut store = AnimStore::new();
    let (large, _) = build(&mut store, Routing::default(), AppBarVariant::Large, None, true, 0, true);
    assert_eq!(large.height(), 152.0);
}

#[test]
fn the_title_starts_after_the_leading_slot_and_at_the_inset_without_one() {
    // MD3 puts the title one `kMiddleSpacing` past the 48dp slot, and at its own inset when
    // nothing leads it. A medium bar's title sits at that inset on its own band.
    // MD3 把标题放在 48dp 槽位之后 `kMiddleSpacing` 处；前面没东西时用自己的内衬。
    // 中号栏的标题在自己的带上，起点同样是那个内衬。
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Routing::default(), AppBarVariant::Small, None, true, 1, false);
    let tree = lay_out(&decl, (WIDTH, 200.0));
    let (x, _, _, _) = region_rect(&tree, BAR.with("title"));
    assert_eq!(x, 4.0 + APP_BAR_SLOT + APP_BAR_TITLE_GAP);

    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Routing::default(), AppBarVariant::Small, None, false, 1, false);
    let tree = lay_out(&decl, (WIDTH, 200.0));
    let (x, _, _, _) = region_rect(&tree, BAR.with("title"));
    assert_eq!(x, APP_BAR_TITLE_INSET);

    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Routing::default(), AppBarVariant::Medium, None, true, 1, false);
    let tree = lay_out(&decl, (WIDTH, 200.0));
    let (x, _, _, _) = region_rect(&tree, BAR.with("title"));
    assert_eq!(x, APP_BAR_TITLE_INSET);

    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Routing::default(), AppBarVariant::Large, None, true, 1, false);
    let tree = lay_out(&decl, (WIDTH, 200.0));
    let (x, _, _, _) = region_rect(&tree, BAR.with("title"));
    assert_eq!(x, APP_BAR_TITLE_INSET);

    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Routing::default(), AppBarVariant::Search, None, true, 1, false);
    let tree = lay_out(&decl, (WIDTH, 200.0));
    let (x, _, _, _) = region_rect(&tree, BAR.with("title"));
    let (lx, _, _, _) = region_rect(&tree, BAR.with("leading"));
    assert_eq!(
        x,
        lx + APP_BAR_SLOT + APP_BAR_TITLE_GAP,
        "the search label follows the leading slot by the same gap"
    );
}

#[test]
fn the_title_band_lets_presses_through_to_the_slots() {
    // The band covers the whole bar; an opaque one swallows every press on the actions,
    // which looks like "only the bars without a band are clickable".
    // 带覆盖整条栏；不透明的话会吞掉所有落在动作上的按下，
    // 看起来就像「只有没有带的栏能点」。
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Routing::default(), AppBarVariant::Medium, None, true, 1, false);
    let tree = lay_out(&decl, (WIDTH, 200.0));
    for id in [BAR.with("title-band"), BAR.with("title-row"), BAR.with("title-col")] {
        let node = tree.get(tree.find_by_id(id).unwrap_or_else(|| panic!("missing {id:?}")));
        assert!(
            node.expect("node").sense.contains(ui_core::Sense::PASS_THROUGH),
            "{id:?} must let the press through"
        );
    }
}

#[test]
fn a_pressed_action_hands_its_own_id_to_the_app() {
    // The slots are decls, so their own `change()` never runs; the bar must name the one
    // that was pressed or the app cannot tell "search" from "more".
    // 槽位是声明，自己的 `change()` 从不执行；栏必须指出被按下的是哪个，
    // 否则应用分不清「搜索」与「更多」。
    let hit = BAR.with(("action", 1usize));
    let routing = Routing {
        clicked_path: vec![BAR, BAR.with("top"), hit],
        ..Routing::default()
    };
    let mut store = AnimStore::new();
    let (bar, _) = build(&mut store, routing, AppBarVariant::Small, None, true, 2, false);
    let change = bar.change(&WidgetState::default(), ui_core::geom::Rect::ZERO);
    assert!(
        matches!(change, Some(Change::Selected(Some(id))) if id == hit),
        "the bar reported {change:?}"
    );

    let mut store = AnimStore::new();
    let (quiet, _) = build(&mut store, Routing::default(), AppBarVariant::Small, None, true, 2, false);
    assert!(quiet.change(&WidgetState::default(), ui_core::geom::Rect::ZERO).is_none());
}
