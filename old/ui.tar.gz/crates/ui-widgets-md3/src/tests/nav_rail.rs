//! The MD3 navigation rail: a fixed-width column, the capsule that becomes a circle without
//! labels, and the press that names a destination.
//! MD3 导航轨道：定宽列、无标签时由胶囊变正圆的指示片，以及指认目标的按下。

use super::*;

use crate::spec::navigation_rail_spec;
use crate::{Md3NavItem, Md3NavRail, RailLabelType, RailParams, RailVariant};
use ui_core::cx::Routing;
use ui_core::draw::Shape;
use ui_core::geom::{Point, Rect};
use ui_core::{NodeData, Weight};

const RAIL: Id = Id::str("rail");

fn item_id(k: usize) -> Id {
    RAIL.with(("item", k))
}

/// A 24dp mark in the destination's ink: the stand-in for a real glyph.
/// 24dp、按目标墨色绘制的标记：真实字形的替身。
fn dot(id: Id, ink: Color) -> Decl {
    Decl::container(id, NodeKind::Box)
        .size(SizeClass::fixed(24.0, 24.0))
        .shapes(vec![Shape::Box {
            corners: ui_core::Corners::ZERO,
            fill: ink,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }])
}

fn items() -> Vec<Md3NavItem<'static>> {
    ["Home", "Search", "Library"]
        .into_iter()
        .enumerate()
        .map(|(k, label)| Md3NavItem::new(item_id(k), label, ui_widgets::IconSource::Custom(dot)))
        .collect()
}

fn build(
    store: &mut AnimStore,
    selected: usize,
    label_type: RailLabelType,
) -> (Md3NavRail, Decl) {
    build_at(store, selected, label_type, 0.0)
}

fn build_at(
    store: &mut AnimStore,
    selected: usize,
    label_type: RailLabelType,
    now: f64,
) -> (Md3NavRail, Decl) {
    build_variant(store, selected, label_type, RailVariant::Classic, now)
}

fn build_variant(
    store: &mut AnimStore,
    selected: usize,
    label_type: RailLabelType,
    variant: RailVariant,
    now: f64,
) -> (Md3NavRail, Decl) {
    let mut core = ui_core::cx::Cx::new(store, 0, 400, 400, now, 0.0, 1.0, None);
    core.route(Routing::default());
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let list = items();
    let control = Md3NavRail::new_with(
        Md3Options::default(),
        RailParams { id: RAIL, items: &list, selected, label_type, variant, disabled: false },
        &mut cx,
        crate::pack::pack(),
    );
    let decl = cx.with_cx(|cx| control.decl(cx));
    (control, decl)
}

fn laid(decl: Decl) -> Tree {
    let root = Decl::container(Id::str("root"), NodeKind::Column).child(decl);
    lay_out(&root, (400.0, 600.0))
}

fn find(decl: &Decl, id: Id) -> Option<&Decl> {
    if decl.id == id {
        return Some(decl);
    }
    decl.children.iter().find_map(|c| find(c, id))
}

fn capsule(decl: &Decl, k: usize) -> (f32, f32, f32) {
    match find(decl, item_id(k).with("indicator")).expect("the destination has one").shapes.first() {
        Some(Shape::Rect { rect, corners, .. }) => (rect.size.w, rect.size.h, corners.tl),
        other => panic!("the capsule is an explicit rect, got {other:?}"),
    }
}

#[test]
fn the_rail_is_the_exported_width_and_stacks_its_labelled_destinations() {
    // The classic rail is a fixed 80dp column; its destinations stack top to bottom, each one
    // the capsule plus the 4dp gap, the label and the 12dp room Flutter reserves below it.
    // 经典轨道是 80dp 定宽列；目标自上而下堆叠，每个是胶囊 + 4dp 间距 + 标签 + Flutter
    // 在其下方预留的 12dp。
    let spec = navigation_rail_spec(false, false, false, false, false);
    let mut store = AnimStore::new();
    let (control, decl) = build(&mut store, 0, RailLabelType::All);
    assert_eq!(control.width(), spec.container.width);
    let per_item = spec.active_indicator.height + 4.0 + spec.label_text.line_height + 12.0;
    // Baseline M3 leaves 8dp of margin above and below the destinations, so the first
    // capsule cannot sit on the rail's edge.
    // M3 基线规范在目标组上下各留 8dp 边距，第一颗胶囊因此不会贴着轨道边缘。
    let margin = 8.0;
    assert_eq!(control.height(), per_item * 3.0 + margin * 2.0);
    let tree = laid(decl);
    let (_, _, w, _) = region_rect(&tree, RAIL);
    assert!((w - spec.container.width).abs() < 1e-4, "the rail is {w} wide");
    for k in 0..3 {
        let (x, y, iw, ih) = region_rect(&tree, item_id(k));
        assert!((x - 0.0).abs() < 1e-4, "destination {k} starts at {x}");
        assert!(
            (y - (margin + per_item * k as f32)).abs() < 1e-4,
            "destination {k} starts at {y}"
        );
        assert!((iw - spec.container.width).abs() < 1e-4, "destination {k} is {iw} wide");
        assert!((ih - per_item).abs() < 1e-4, "destination {k} is {ih} tall");
    }
}

#[test]
fn a_selection_change_grows_and_fades_the_label_instead_of_switching_it() {
    // `Selected` moves the label between destinations. If the label merely appeared, every
    // destination below would jump a whole label's height in one frame; its room, its ink and
    // their positions must all be part-way between the two ends.
    // `Selected` 让标签在目标之间移动。若标签只是出现，下面每个目标都会在一帧内整段跳走；
    // 标签占的位置、它的墨色与下方目标的位置，都必须停在两端之间的半路上。
    let spec = navigation_rail_spec(false, false, false, false, false);
    let line = spec.label_text.line_height;
    let labelled = spec.active_indicator.height + 4.0 + line + 12.0;
    let bare = spec.active_indicator.height + 12.0;
    let mut store = AnimStore::new();
    let (_, start) = build_at(&mut store, 0, RailLabelType::Selected, 0.0);
    let start_next = region_rect(&laid(start), item_id(1)).1;
    // The frame that commits the new target is still at the old value; the next one moves.
    // 提交新目标的那一帧还停在旧值；下一帧才开始移动。
    let (_, _) = build_at(&mut store, 1, RailLabelType::Selected, 0.0);
    let (_, mid) = build_at(&mut store, 1, RailLabelType::Selected, 0.25);
    let alphas = [label_alpha(&mid, 0), label_alpha(&mid, 1)];
    let mid_tree = laid(mid);
    let (_, _, _, h0) = region_rect(&mid_tree, item_id(0));
    assert!(h0 > bare && h0 < labelled, "the outgoing label's room is {h0}, mid-way");
    let (_, _, _, slot) = region_rect(&mid_tree, item_id(0).with("label-slot"));
    assert!(slot > 0.0 && slot < line, "the label's slot is {slot} of {line}");
    let mid_next = region_rect(&mid_tree, item_id(1)).1;
    assert!(mid_next < start_next, "the next destination moved up: {mid_next} < {start_next}");
    for (k, alpha) in alphas.into_iter().enumerate() {
        assert!(alpha > 0.0 && alpha < 1.0, "destination {k}'s label ink is at {alpha}");
    }
}

/// The alpha a destination's label is drawn at.
/// 目标标签绘制时的透明度。
fn label_alpha(decl: &Decl, k: usize) -> f32 {
    match &find(decl, item_id(k).with("label")).expect("the destination carries a label").data {
        NodeData::Text { ink, .. } => ink.a,
        _ => panic!("the label is a text node"),
    }
}

#[test]
fn without_labels_the_indicator_is_the_exported_circle() {
    // `no-label` is the only state that changes the indicator's shape: 56×56 with full
    // corners, centred in the column — a 56×32 capsule here would be the wrong variant.
    // `no-label` 是唯一改变指示片形状的状态：56×56、全圆角、在列中居中——
    // 此处画成 56×32 胶囊就是错的变体。
    let spec = navigation_rail_spec(false, true, false, false, false);
    assert_eq!((spec.active_indicator.width, spec.active_indicator.height), (56.0, 56.0));
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, 1, RailLabelType::None);
    let (w, h, radius) = capsule(&decl, 1);
    assert_eq!((w, h), (56.0, 56.0), "the capsule is a circle");
    assert_eq!(radius, 28.0, "and is fully round");
    assert!(find(&decl, item_id(0).with("label")).is_none(), "no destination shows a label");
    let tree = laid(decl);
    let (ix, _, _, _) = region_rect(&tree, item_id(1).with("indicator"));
    assert!((ix - 12.0).abs() < 1e-4, "the circle is centred, starts at {ix}");
}

#[test]
fn with_labels_the_indicator_is_the_exported_capsule_and_the_selected_label_is_bold() {
    // The labelled variant keeps the 56×32 capsule from the base state; the export's only
    // typographic cue is the 700 weight on the selected destination.
    // 带标签的变体保持基态的 56×32 胶囊；导出唯一的排版线索是选中目标的 700 字重。
    let spec = navigation_rail_spec(false, false, false, false, false);
    let active = navigation_rail_spec(true, false, false, false, false);
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, 1, RailLabelType::All);
    let (w, h, radius) = capsule(&decl, 1);
    assert_eq!((w, h), (spec.active_indicator.width, spec.active_indicator.height));
    assert_eq!(radius, 16.0, "a stadium, not a circle");
    let weight = |k: usize| match &find(&decl, item_id(k).with("label")).expect("labelled").data {
        NodeData::Text { block, .. } => block.runs[0].style.weight,
        _ => panic!("the label is a text node"),
    };
    assert_eq!(weight(1), Weight(active.label_text.weight as u16));
    assert_eq!(weight(0), Weight(spec.label_text.weight as u16));
}

#[test]
fn a_destinations_ink_clips_to_its_own_indicator() {
    // The ripple covers the capsule, not the whole destination: the ink naming its own
    // indicator as the clip keeps the splash inside the effective background.
    // 墨迹盖住胶囊，而不是整个目标：墨迹把自己名字的指示片作为裁剪目标，
    // 涟漪就留在有效背景内。
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, 1, RailLabelType::All);
    for k in 0..3 {
        let dest = find(&decl, item_id(k)).expect("the destination exists");
        let ink = match &dest.data {
            NodeData::Container(p) => p.press_ink.expect("every destination declares press ink"),
            _ => panic!("the destination is a container"),
        };
        assert_eq!(
            ink.target,
            ui_core::InkTarget::Descendant(item_id(k).with("indicator")),
            "destination {k} clips its ink to its own capsule"
        );
    }
}

#[test]
fn a_press_names_the_destination_under_the_pointer_and_reselection_reports_nothing() {
    // The rail maps the press by the stacked bands; an off-by-one band selects the neighbour,
    // and re-selecting the current destination must not make the app re-render.
    // 轨道按堆叠条带映射按下点；条带错一格就选中邻居，重选当前目标也不该让 app 白刷新。
    let spec = navigation_rail_spec(false, false, false, false, false);
    let mut store = AnimStore::new();
    // `Selected` gives the destinations unequal heights, which is where the bands can slip.
    // `Selected` 让各目标高度不等，条带正是在这里最容易错位。
    let (control, _) = build(&mut store, 0, RailLabelType::Selected);
    let labelled = spec.active_indicator.height + 4.0 + spec.label_text.line_height + 12.0;
    let bare = spec.active_indicator.height + 12.0;
    let margin = 8.0;
    assert_eq!(control.height(), labelled + bare * 2.0 + margin * 2.0);
    let bounds = Rect::new(0.0, 0.0, control.width(), control.height());
    let press = |y: f32| ui_widgets::WidgetState {
        clicked: true,
        local: Some(Point::new(40.0, y)),
        ..Default::default()
    };
    for (y, want) in [(labelled + 1.0, 1), (labelled + bare + 1.0, 2)] {
        match control.change(&press(margin + y), bounds) {
            Some(ui_core::Change::Selected(Some(id))) => assert_eq!(id, item_id(want), "y={y}"),
            other => panic!("y={y} expected Selected(destination {want}), got {other:?}"),
        }
    }
    // Points where equal division would disagree with the real bands: the labelled destination
    // is taller, so its last 4dp and the next one's are only reachable by the real heights.
    // 等分与真实条带会给出不同答案的点：带标签的目标更高，只有真实高度才划得对最后 4dp。
    assert!(
        control.change(&press(margin + labelled - 4.0), bounds).is_none(),
        "still the current one"
    );
    match control.change(&press(margin + labelled + bare - 4.0), bounds) {
        Some(ui_core::Change::Selected(Some(id))) => assert_eq!(id, item_id(1), "still destination 1"),
        other => panic!("expected Selected(destination 1), got {other:?}"),
    }
    assert!(
        control.change(&press(margin + labelled * 0.5), bounds).is_none(),
        "the current destination"
    );
    assert!(control.change(&press(margin - 4.0), bounds).is_none(), "the top margin is no band");
    assert!(control.change(&press(control.height() + 5.0), bounds).is_none(), "below the rail");
    let hover = ui_widgets::WidgetState { local: Some(Point::new(40.0, 10.0)), ..Default::default() };
    assert!(control.change(&hover, bounds).is_none(), "no click, no selection");
}

#[test]
fn the_expressive_rail_widens_between_its_two_ends_and_the_pill_opens_with_it() {
    // The Expressive pair is one control at two widths: collapsed the pill is exactly the icon
    // plus its 16dp padding, expanded it spans the rail, and the icon keeps that 16dp front
    // inset at both ends so it does not slide while the pill opens.
    // Expressive 是一控两端：收起时胶囊恰好是图标加两侧 16dp，展开时横跨轨道；
    // 图标的前空两端都是 16dp，胶囊张开时它不滑动。
    let mut store = AnimStore::new();
    let collapsed = RailVariant::Expressive { expanded: false };
    let expanded = RailVariant::Expressive { expanded: true };
    let (control, decl) = build_variant(&mut store, 0, RailLabelType::All, collapsed, 0.0);
    assert_eq!(control.width(), 96.0);
    assert_eq!(control.height(), 44.0 + 3.0 * 64.0 + 2.0 * 4.0, "44dp top space, 64dp items, 4dp apart");
    // Declaring the target is not enough: the node has to ask the engine to walk there.
    // 只声明目标不够：节点还得请引擎走过去。
    let travel = match &decl.data {
        NodeData::Container(p) => p.size_transition.expect("the width travels, it does not jump"),
        _ => panic!("the rail is a container"),
    };
    assert_eq!(travel.duration, 0.3, "M3 Standard");
    let tree = laid(decl);
    let (x, _, w, h) = region_rect(&tree, item_id(0).with("indicator"));
    assert_eq!((x, w, h), (20.0, 56.0, 32.0), "the pill is the icon's own capsule");
    let (icon_x, _, _, _) = region_rect(&tree, item_id(0).with("icon"));
    assert_eq!(icon_x, x + 16.0, "the icon sits 16dp inside the pill");

    // Flipping the target and letting the clock run leaves the declaration at the whole
    // target while the pill is only part-way: the engine owns the width interpolation.
    // 翻转目标再让时钟走一段：声明仍是整个目标，而胶囊只到半路——宽度插值归引擎。
    let (_, _) = build_variant(&mut store, 0, RailLabelType::All, expanded, 0.0);
    let (control, decl) = build_variant(&mut store, 0, RailLabelType::All, expanded, 0.08);
    assert_eq!(control.width(), 220.0, "the declaration is the target, not the current width");
    let alpha = label_alpha(&decl, 0);
    assert!(alpha > 0.0 && alpha < 1.0, "the label is on its way in, at {alpha}");
    let tree = laid(decl);
    let (_, _, _, h) = region_rect(&tree, item_id(0).with("indicator"));
    assert!(h > 32.0 && h < 56.0, "the pill is opening, {h} tall");

    let (control, decl) = build_variant(&mut store, 0, RailLabelType::All, expanded, 1.0);
    assert_eq!(control.width(), 220.0);
    let tree = laid(decl);
    let (x, _, w, h) = region_rect(&tree, item_id(0).with("indicator"));
    assert_eq!((x, w, h), (16.0, 188.0, 56.0), "the pill spans the rail less its 16dp inset");
    let (icon_x, _, _, _) = region_rect(&tree, item_id(0).with("icon"));
    assert_eq!(icon_x, x + 16.0, "and the icon still sits 16dp inside it");
}
