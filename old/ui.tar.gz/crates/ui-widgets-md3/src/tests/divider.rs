//! The MD3 divider: one hairline whose thickness and colour come from the export.
//! MD3 分隔线：一条细线，厚度与颜色取自导出令牌。

use super::*;

use crate::spec::divider_spec;
use crate::DividerAxis;
use ui_core::geom::Insets;

fn divider_decl(axis: DividerAxis, inset: Insets) -> Decl {
    let style = Md3Kit::new();
    ui_widgets::Cx::for_test_mut(|cx| {
        let control = style.divider(Id::str("d"), axis, inset, cx);
        cx.with_cx(|inner| control.decl(inner))
    })
}

#[test]
fn the_hairline_uses_the_exported_thickness_and_colour() {
    // The divider is nothing but its token: if the table and the painter drift apart, the line
    // silently changes weight or colour. 分隔线只有令牌：表与绘制一旦分叉，线的粗细或颜色就会静默改变。
    let spec = divider_spec();
    let decl = divider_decl(DividerAxis::Horizontal, Insets::ZERO);
    assert_eq!(
        box_fill(&decl),
        role(&crate::pack::pack(), spec.root.color),
        "the line takes the exported colour role"
    );
    let tree = laid_out(decl);
    let (_, _, w, h) = region_rect(&tree, Id::str("d"));
    assert_eq!(h, spec.root.thickness, "the line is as thick as the export says");
    assert_eq!(w, 200.0, "a horizontal divider spans the full width");
}

#[test]
fn an_inset_divider_keeps_the_hairline_inside_the_padding() {
    // Padding shrinks the child, not the background: painting the line on the padded box would
    // draw it full-bleed and the inset would silently do nothing.
    // padding 只内缩子节点、不动背景：把线画在加了内边距的盒子上会通栏，内缩便静默失效。
    let inset = Insets { left: 16.0, top: 0.0, right: 16.0, bottom: 0.0 };
    let decl = divider_decl(DividerAxis::Horizontal, inset);
    assert_eq!(
        box_fill(&decl),
        Color::TRANSPARENT,
        "the padded box itself must paint nothing"
    );
    assert_eq!(decl.children.len(), 1, "the line moves to a child that the padding insets");
    let tree = laid_out(decl);
    let (x, _, w, h) = region_rect(&tree, Id::str("d").with("line"));
    assert_eq!(x, 16.0, "the hairline starts after the leading inset");
    assert_eq!(w, 200.0 - 32.0, "and stops before the trailing one");
    assert_eq!(h, divider_spec().root.thickness);
}

#[test]
fn a_vertical_divider_is_thin_across_and_fills_down() {
    // The axis swap is one branch; getting it backwards paints a 1px-wide full-height line as a
    // full-width 1px bar. 换轴只是一个分支；写反了会把 1px 宽的通高线画成通宽的 1px 横条。
    let decl = divider_decl(DividerAxis::Vertical, Insets::ZERO);
    let tree = laid_out(decl);
    let (_, _, w, h) = region_rect(&tree, Id::str("d"));
    assert_eq!(w, divider_spec().root.thickness);
    assert_eq!(h, 100.0, "a vertical divider spans the full height");
}
