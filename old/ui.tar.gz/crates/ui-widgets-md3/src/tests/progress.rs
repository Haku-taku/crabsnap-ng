//! The MD3 linear progress indicator: a track, and an active bar `value` of the width long.
//! MD3 线性进度指示器：一条轨道，加一段长度为宽度 `value` 倍的活动条。

use super::*;

use ui_core::draw::Shape;
use ui_core::geom::{Corners, Rect};

const BAR: Id = Id::str("progress");

fn build(store: &mut AnimStore, width: f32, value: f32) -> Decl {
    let mut core = ui_core::cx::Cx::new(store, 0, 600, 200, 0.0, 0.0, 1.0, None);
    core.route(ui_core::cx::Routing::default());
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let control = Md3ProgressIndicator::new_with(
        Md3Options::default(),
        BAR,
        width,
        value,
        &mut cx,
        &crate::pack::pack(),
    );
    cx.with_cx(|cx| control.decl(cx))
}

fn track_of(decl: &Decl) -> (Corners, Color) {
    match decl.shapes.first() {
        Some(Shape::Box { corners, fill, .. }) => (*corners, *fill),
        other => panic!("the bar paints no track box first, got {other:?}"),
    }
}

fn active_of(decl: &Decl) -> Option<Rect> {
    decl.shapes.iter().find_map(|s| match s {
        Shape::Rect { rect, .. } => Some(*rect),
        _ => None,
    })
}

#[test]
fn the_track_is_the_exports_thickness_with_round_ends() {
    // The export's only surviving thickness source is `linear.height` (the `thickness` token
    // is deprecated), and a 4dp bar with 2dp ends is the linear indicator's whole silhouette.
    // 导出中唯一幸存的粗细来源是 `linear.height`（`thickness` 令牌已废弃），
    // 4dp 高、2dp 端圆正是线性指示器的全部轮廓。
    let mut store = AnimStore::new();
    let decl = build(&mut store, 200.0, 0.5);
    let spec = crate::spec::progress_indicator_spec(
        false,
        false,
        false,
        crate::spec::ProgressIndicatorShape::Linear,
    );
    let (corners, fill) = track_of(&decl);
    let half = spec.root.height * 0.5;
    assert_eq!(
        (corners.tl, corners.tr, corners.bl, corners.br),
        (half, half, half, half),
        "the track's ends are half its height"
    );
    assert_eq!(decl.size_class.height.hint, spec.root.height);
    assert_ne!(fill, Color::TRANSPARENT, "the track is painted, not left blank");
}

#[test]
fn the_active_bar_is_the_value_fraction_of_the_width_and_vanishes_at_zero() {
    // The value is the app's number, so the bar must be exactly that share of the width, and
    // a zero value must paint no nub — the slider's zero-length rule, reused.
    // 数值归应用，活动条必须恰是宽度的那一份；值为零时不得画出凸起——沿用滑块的零长度规则。
    let mut store = AnimStore::new();
    let quarter = active_of(&build(&mut store, 240.0, 0.25)).expect("a quarter bar paints");
    assert!((quarter.size.w - 60.0).abs() < 0.5, "got width {}", quarter.size.w);
    assert_eq!(
        (quarter.origin.x, quarter.origin.y),
        (0.0, 0.0),
        "it starts at the track's left"
    );
    let empty = build(&mut store, 240.0, 0.0);
    let painted = active_of(&empty).map_or(0.0, |r| r.size.w);
    assert_eq!(painted, 0.0, "zero value shows no visible bar");
}

#[test]
fn at_full_value_the_active_bar_ends_where_the_track_does() {
    // Completion is the claim the value=1 frame makes; an off-by-a-rounding bar leaves a
    // visible sliver of track at the end.
    // 完成态是 value=1 那一帧的主张；差一个舍入就会在末端留下一条可见的轨道缝。
    let mut store = AnimStore::new();
    let decl = build(&mut store, 320.0, 1.0);
    let full = active_of(&decl).expect("a full bar paints");
    let width = decl.size_class.width.hint;
    assert!((full.size.w - width).abs() < 0.5, "got width {}", full.size.w);
    assert!(
        (full.origin.x + full.size.w - width).abs() < 0.5,
        "the right edge coincides"
    );
}

const RING: Id = Id::str("progress/ring");

fn build_ring(store: &mut AnimStore, size: f32, value: f32) -> Decl {
    let mut core = ui_core::cx::Cx::new(store, 0, 600, 200, 0.0, 0.0, 1.0, None);
    core.route(ui_core::cx::Routing::default());
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let control = Md3ProgressIndicator::ring_with(
        Md3Options::default(),
        RING,
        size,
        value,
        &mut cx,
        &crate::pack::pack(),
    );
    cx.with_cx(|cx| control.decl(cx))
}

/// `(trim, round_caps, colour)` per sector, in paint order.
/// 每个扇区的 `(区间, 圆头, 颜色)`，按绘制顺序。
fn arcs_of(decl: &Decl) -> Vec<((f32, f32), bool, Color)> {
    decl.shapes
        .iter()
        .filter_map(|s| match s {
            Shape::Sector {
                trim,
                round_caps,
                colour,
                ..
            } => Some((*trim, *round_caps, *colour)),
            _ => None,
        })
        .collect()
}

#[test]
fn a_determinate_ring_runs_from_twelve_oclock_and_stops_the_track_either_side() {
    // The gap is the export's own `track_active_indicator_space`, so a ring whose track runs
    // into its arc has read the wrong token — and an arc that starts anywhere but twelve
    // o'clock reads the wrong angle convention.
    // 空隙就是导出令牌 `track_active_indicator_space`：轨道直抵弧身说明读错了令牌，
    // 弧不从十二点起说明角度约定读错了。
    let mut store = AnimStore::new();
    let arcs = arcs_of(&build_ring(&mut store, 40.0, 0.6));
    assert_eq!(arcs.len(), 2, "track then arc, got {arcs:?}");
    let (arc, butt, active_colour) = arcs[1];
    assert!((arc.0 - -0.25).abs() < 1e-6, "the arc starts at twelve, got {}", arc.0);
    assert!((arc.1 - arc.0 - 0.6).abs() < 1e-6, "the arc sweeps the value");
    assert!(!butt, "the value arc is butt-capped");
    let (track, round, track_colour) = arcs[0];
    // `(strokeWidth + trackGap) / centreline radius`, the reference's `startGap`.
    // `(strokeWidth + trackGap) / 中心线半径`，即参考实现的 `startGap`。
    let gap = ((4.0 + 4.0) / 18.0) / std::f32::consts::TAU;
    assert!((track.0 - (arc.1 + gap)).abs() < 1e-4, "the track starts past the arc");
    assert!((track.1 - (-0.25 + 1.0 - gap)).abs() < 1e-4, "and ends short of it");
    assert!(round, "the track is round-capped");
    assert_ne!(track_colour, active_colour, "track and arc are different roles");
}

#[test]
fn a_full_ring_is_one_arc_and_a_zero_ring_is_one_track() {
    // At both ends one of the two spans has no length: a sliver of track at 100% or an arc
    // at 0% is the rounding bug this pins.
    // 两端各有一段长度为零：100% 时留下轨道缝、0% 时画出弧，都是这条要钉住的舍入错误。
    let mut store = AnimStore::new();
    let full = arcs_of(&build_ring(&mut store, 40.0, 1.0));
    assert_eq!(full.len(), 1, "no track at full value, got {full:?}");
    assert!((full[0].0.1 - full[0].0.0 - 1.0).abs() < 1e-6);
    let zero = arcs_of(&build_ring(&mut store, 40.0, 0.0));
    assert_eq!(zero.len(), 1, "no arc at zero, got {zero:?}");
    assert!((zero[0].0.1 - zero[0].0.0 - 1.0).abs() < 1e-6);
    let half_track = arcs_of(&build_ring(&mut store, 40.0, 0.6))[0].2;
    assert_eq!(zero[0].2, half_track, "the zero ring is the track alone");
}
