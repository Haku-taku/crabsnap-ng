//! Differential check: the generated token table against Flutter's `_SwitchDefaultsM3`.
//! 交叉比对：生成的令牌表与 Flutter 的 `_SwitchDefaultsM3`。

use crate::spec::{slider_spec, switch_spec, SliderSize, SwitchSpec};

/// (role, alpha) as Flutter's M3 defaults would resolve it. A transparent slot is `("", 0.0)`.
/// 按 Flutter M3 默认值应解出的（角色, alpha）。透明槽记为 `("", 0.0)`。
type Ink = (&'static str, f32);

fn thumb(s: &SwitchSpec) -> Ink {
    (s.handle.color, s.handle.opacity)
}

fn track(s: &SwitchSpec) -> Ink {
    (s.track.color, s.track.opacity)
}

fn outline(s: &SwitchSpec) -> Ink {
    if s.track_outline.color.is_empty() {
        return ("", 0.0);
    }
    (s.track_outline.color, s.track.opacity)
}

fn layer(s: &SwitchSpec) -> Ink {
    if s.state_layer.opacity <= 0.0 {
        return ("", 0.0);
    }
    (s.state_layer.color, s.state_layer.opacity)
}

/// Flutter's `thumbColor.resolve`, transcribed from `material/switch.dart`.
/// Flutter 的 `thumbColor.resolve`，照 `material/switch.dart` 抄录。
fn flutter_thumb(selected: bool, disabled: bool, lit: bool) -> Ink {
    match (disabled, selected, lit) {
        (true, true, _) => ("surface", 1.0),
        (true, false, _) => ("onSurface", 0.38),
        (false, true, true) => ("primaryContainer", 1.0),
        (false, true, false) => ("onPrimary", 1.0),
        (false, false, true) => ("onSurfaceVariant", 1.0),
        (false, false, false) => ("outline", 1.0),
    }
}

/// Flutter's `trackColor.resolve` and `trackOutlineColor.resolve`.
/// Flutter 的 `trackColor.resolve` 与 `trackOutlineColor.resolve`。
fn flutter_track(selected: bool, disabled: bool) -> Ink {
    match (disabled, selected) {
        (true, true) => ("onSurface", 0.12),
        (true, false) => ("surfaceContainerHighest", 0.12),
        (false, true) => ("primary", 1.0),
        (false, false) => ("surfaceContainerHighest", 1.0),
    }
}

fn flutter_outline(selected: bool, disabled: bool) -> Ink {
    if selected {
        ("", 0.0)
    } else if disabled {
        ("onSurface", 0.12)
    } else {
        ("outline", 1.0)
    }
}

/// Flutter's `overlayColor.resolve`: null at rest, 8% on hover, 10% on focus or press.
/// Flutter 的 `overlayColor.resolve`：静止无层，悬停 8%，焦点或按压 10%。
fn flutter_layer(selected: bool, hover: bool, focus: bool, press: bool) -> Ink {
    let role = if selected { "primary" } else { "onSurface" };
    if press || focus {
        (role, 0.1)
    } else if hover {
        (role, 0.08)
    } else {
        ("", 0.0)
    }
}

#[test]
fn every_state_combination_matches_flutter_defaults() {
    for selected in [false, true] {
        for disabled in [false, true] {
            for (hover, focus, press) in [
                (false, false, false),
                (true, false, false),
                (false, true, false),
                (false, false, true),
            ] {
                let s = switch_spec(selected, false, hover, focus, press, disabled);
                let lit = hover || focus || press;
                let where_ = (selected, disabled, hover, focus, press);
                assert_eq!(thumb(&s), flutter_thumb(selected, disabled, lit), "thumb {where_:?}");
                assert_eq!(track(&s), flutter_track(selected, disabled), "track {where_:?}");
                assert_eq!(outline(&s), flutter_outline(selected, disabled), "outline {where_:?}");
                assert_eq!(
                    layer(&s),
                    flutter_layer(selected, hover, focus, press),
                    "layer {where_:?}"
                );
            }
        }
    }
}

#[test]
fn the_export_differs_from_flutter_in_two_named_places() {
    // Documented divergences: the export is authoritative, Flutter's `_SwitchConfigM3` is hand
    // coded. Selected icon `primary` vs Flutter's `onPrimaryContainer`; focus indicator
    // `secondary`/3dp vs Flutter, which paints no M3 switch ring at all.
    // 已记录的分歧：以导出为准。选中图标 `primary`（Flutter 手写为 `onPrimaryContainer`）；
    // 焦点指示器 `secondary`/3dp（Flutter 的 M3 开关根本不画环）。
    let on = switch_spec(true, false, false, false, false, false);
    assert_eq!((on.icon.color, on.icon.opacity), ("primary", 1.0));
    let rest = switch_spec(false, false, false, false, false, false);
    assert_eq!(
        (rest.focus_indicator.color, rest.focus_indicator.thickness, rest.focus_indicator.offset),
        ("secondary", 3.0, 2.0)
    );
}

#[test]
fn the_geometry_matches_the_m3_switch_config() {
    // `_SwitchConfigM3`: track 52x32, thumb 16/24, pressed 28, with icon 24, icon glyph 16.
    // `_SwitchConfigM3`：轨道 52x32，滑块 16/24，按压 28，带图标 24，字形 16。
    let off = switch_spec(false, false, false, false, false, false);
    let on = switch_spec(true, false, false, false, false, false);
    let pressed = switch_spec(false, false, false, false, true, false);
    let icon = switch_spec(false, true, false, false, false, false);
    assert_eq!((off.track.width, off.track.height), (52.0, 32.0));
    assert_eq!((off.handle.width, on.handle.width), (16.0, 24.0));
    assert_eq!((pressed.handle.width, pressed.handle.height), (28.0, 28.0));
    assert_eq!((icon.handle.width, icon.handle.height), (24.0, 24.0));
    assert_eq!((off.icon.size, on.icon.size), (16.0, 16.0));
    assert_eq!(off.state_layer.size, 40.0);
    assert_eq!(off.track_outline.width, 2.0);
}

/// The slider's track and handle against `_SliderDefaultsM3` (material/slider.dart).
/// 滑块的轨道与手柄对照 `_SliderDefaultsM3`（material/slider.dart）。
#[test]
fn the_slider_track_and_handle_match_flutter_defaults() {
    let cases = [
        // (active, disabled, track role, track alpha, handle role, handle alpha)
        (true, false, "primary", 1.0, "primary", 1.0),
        (false, false, "secondaryContainer", 1.0, "primary", 1.0),
        (true, true, "onSurface", 0.38, "onSurface", 0.38),
        (false, true, "onSurface", 0.12, "onSurface", 0.38),
    ];
    for (active, disabled, track_role, track_alpha, handle_role, handle_alpha) in cases {
        let s = slider_spec(active, false, false, false, disabled, SliderSize::Base);
        let where_ = (active, disabled);
        assert_eq!((s.track.color, s.track.opacity), (track_role, track_alpha), "track {where_:?}");
        assert_eq!(
            (s.handle.color, s.handle.opacity),
            (handle_role, handle_alpha),
            "handle {where_:?}"
        );
    }
}

/// Every size variant keeps the same handle width and only grows the track.
/// 每个尺寸档保持手柄宽度不变，只让轨道变高。
#[test]
fn the_slider_sizes_grow_the_track() {
    let sizes = [
        (SliderSize::Base, 16.0),
        (SliderSize::XSmall, 16.0),
        (SliderSize::Small, 24.0),
        (SliderSize::Medium, 40.0),
        (SliderSize::Large, 56.0),
        (SliderSize::XLarge, 96.0),
    ];
    for (size, height) in sizes {
        let s = slider_spec(true, false, false, false, false, size);
        assert_eq!(s.track.height, height, "{size:?}");
        assert_eq!(s.handle.width, 4.0, "{size:?}");
    }
}
