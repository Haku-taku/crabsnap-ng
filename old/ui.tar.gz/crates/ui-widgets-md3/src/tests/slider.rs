//! The MD3 slider: gapped track geometry, the stop dot, the handle's press narrowing and the
//! press-to-value mapping.
//! MD3 滑块：留缺口的轨道几何、停止点、按压收窄的手柄，以及按下映射成值。

use super::*;

use crate::spec::{slider_spec, SliderSize};
use crate::slider::{Md3Slider, SliderOpts, HANDLE_W, SLIDER_OVERLAY, SLIDER_TOUCH};
use crate::toggle::{role, spec_ink};
use ui_core::cx::Routing;
use ui_core::draw::Shape;
use ui_core::geom::{Point, Rect};

const ID: Id = Id::str("s");
const WIDTH: f32 = 240.0;

fn build(
    store: &mut AnimStore,
    routing: Routing,
    now: f64,
    value: f32,
    size: SliderSize,
    params: Md3Options,
) -> (Md3Slider, Decl, ui_widgets::WidgetState) {
    build_opts(store, routing, now, value, size, params, SliderOpts::default())
}

#[allow(clippy::too_many_arguments)]
fn build_opts(
    store: &mut AnimStore,
    routing: Routing,
    now: f64,
    value: f32,
    size: SliderSize,
    params: Md3Options,
    opts: SliderOpts,
) -> (Md3Slider, Decl, ui_widgets::WidgetState) {
    let mut core = ui_core::cx::Cx::new(store, 0, 400, 200, now, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let control = {
        let mut node = cx.at(ID);
        Md3Slider::with_opts(
            ID,
            value,
            WIDTH,
            size,
            params,
            opts,
            Some(&mut node),
            &crate::pack::pack(),
        )
    };
    let state = cx.state(ID);
    let decl = cx.with_cx(|cx| control.decl(cx));
    (control, decl, state)
}

/// The handle is painted last, so the slider's own order identifies it.
/// 手柄最后绘制，因此按滑块自己的绘制顺序即可认出。
fn handle(decl: &Decl) -> Rect {
    match decl.shapes.last().expect("the slider always paints its handle") {
        Shape::Rect { rect, .. } => *rect,
        _ => unreachable!(),
    }
}

/// The two track segments: as tall as the track and wider than the 4dp stop dot.
/// 两段轨道：与轨道等高，且比 4dp 停止点更宽。
fn segments(decl: &Decl, track_h: f32) -> Vec<(Rect, Color)> {
    decl.shapes
        .iter()
        .filter_map(|s| match s {
            Shape::Rect { rect, fill, .. }
                if (rect.size.h - track_h).abs() < 0.01 && rect.size.w > 4.01 =>
            {
                Some((*rect, *fill))
            }
            _ => None,
        })
        .collect()
}

/// The export splits the two track insets across the active and inactive states; they agree.
/// 导出把两个轨道内缩分在激活与非激活状态里；两者数值相同。
fn insets(size: SliderSize) -> (f32, f32) {
    let on = slider_spec(true, false, false, false, false, size);
    let off = slider_spec(false, false, false, false, false, size);
    assert_eq!(on.track_shape.leading, off.track_shape.trailing, "the two halves agree");
    (on.track_shape.leading, off.track_shape.trailing)
}

/// The stop dot: the only square smaller than the handle.
/// 停止点：唯一比手柄小的正方形。
fn stop_dot(decl: &Decl) -> Option<(Rect, Color)> {
    decl.shapes.iter().find_map(|s| match s {
        Shape::Rect { rect, fill, .. }
            if (rect.size.w - rect.size.h).abs() < 0.01 && rect.size.w <= 4.01 =>
        {
            Some((*rect, *fill))
        }
        _ => None,
    })
}

/// Every dot of the exported diameter, in paint order.
/// 每个导出直径的点，按绘制顺序。
fn stop_dots(decl: &Decl, size: f32) -> Vec<Rect> {
    decl.shapes
        .iter()
        .filter_map(|s| match s {
            Shape::Rect { rect, .. }
                if (rect.size.w - size).abs() < 0.01 && (rect.size.h - size).abs() < 0.01 =>
            {
                Some(*rect)
            }
            _ => None,
        })
        .collect()
}

#[test]
fn the_handle_rides_between_the_exported_track_insets() {
    // The export gives each size its own `track.shape` insets; ignoring them puts the handle
    // hard against the control's edge, where half of it falls outside the rounded track.
    // 导出为每个尺寸给出自己的 `track.shape` 内缩；忽略它会让手柄贴住控件边缘，一半落在轨道外。
    let spec = slider_spec(true, false, false, false, false, SliderSize::Medium);
    let mut store = AnimStore::new();
    let at = |store: &mut AnimStore, v: f32| {
        let (control, decl, _) = build(
            store,
            Routing::default(),
            0.0,
            v,
            SliderSize::Medium,
            Md3Options::default(),
        );
        (control, decl)
    };
    let (left, right) = insets(SliderSize::Medium);
    let travel = WIDTH - left - right;
    for v in [0.0, 0.25, 0.5, 1.0] {
        let (control, decl) = at(&mut store, v);
        let want = left + travel * v;
        assert!((control.handle_x() - want).abs() < 1e-4, "value {v} at {}", control.handle_x());
        let rect = handle(&decl);
        assert!((rect.origin.x + rect.size.w * 0.5 - want).abs() < 1e-4, "painted at {rect:?}");
    }
    // The `Medium` handle is 44 tall inside a 48dp target, so it is centred, not flush.
    let (_, decl) = at(&mut store, 0.0);
    let rect = handle(&decl);
    assert!((rect.origin.y - (SLIDER_TOUCH - spec.handle.height) * 0.5).abs() < 1e-4);
}

#[test]
fn a_pointer_position_maps_to_the_same_value_the_handle_shows() {
    // One mapping serves both the gesture and the paint; if they disagree the handle lands
    // beside the finger and the value jitters as the app feeds it back.
    // 手势与绘制共用同一个映射；两者不一致时手柄会停在手指旁边，值还会随反馈抖动。
    let mut store = AnimStore::new();
    for v in [0.0, 0.1, 0.5, 0.87, 1.0] {
        let (control, _, _) = build(
            &mut store,
            Routing::default(),
            0.0,
            v,
            SliderSize::XSmall,
            Md3Options::default(),
        );
        let back = control.value_at(control.handle_x());
        assert!((back - v).abs() < 1e-4, "value {v} round-trips to {back}");
    }
    // Outside the track the mapping clamps instead of extrapolating.
    // 轨道之外夹取，不外推。
    let (control, _, _) = build(
        &mut store,
        Routing::default(),
        0.0,
        0.5,
        SliderSize::XSmall,
        Md3Options::default(),
    );
    assert_eq!(control.value_at(-50.0), 0.0);
    assert_eq!(control.value_at(WIDTH + 50.0), 1.0);
}

#[test]
fn the_track_leaves_the_track_gap_clear_around_the_handle() {
    // `trackGap` splits the track around the handle's centre; drawing one continuous bar
    // hides the gap the design system uses to separate the active and inactive halves.
    // `trackGap` 在把手中心两侧切开轨道；画成一条连续的条就丢掉了设计系统用来分隔活动与非活动段的缺口。
    let mut store = AnimStore::new();
    let (control, decl, _) = build(
        &mut store,
        Routing::default(),
        0.0,
        0.5,
        SliderSize::XSmall,
        Md3Options::default(),
    );
    let spec = slider_spec(true, false, false, false, false, SliderSize::XSmall);
    let (inset_l, inset_r) = insets(SliderSize::XSmall);
    let centre = control.handle_x();
    let segs = segments(&decl, spec.track.height);
    assert_eq!(segs.len(), 2, "two segments: {segs:?}");
    let (left, left_fill) = segs[0];
    let (right, right_fill) = segs[1];
    assert!((left.origin.x - inset_l).abs() < 1e-4);
    assert!((left.origin.x + left.size.w - (centre - 6.0)).abs() < 1e-4, "left ends at {left:?}");
    assert!((right.origin.x - (centre + 6.0)).abs() < 1e-4, "right starts at {right:?}");
    assert!((right.origin.x + right.size.w - (WIDTH - inset_r)).abs() < 1e-4);
    let pack = crate::pack::pack();
    assert_eq!(left_fill, spec_ink(&pack, spec.track.color, spec.track.opacity), "the active ink");
    assert_ne!(left_fill, right_fill, "the inactive segment keeps its own ink");
}

#[test]
fn a_pressed_slider_reports_the_value_under_the_finger() {
    // The slider maps the press point itself, in its own space; the app never sees a
    // coordinate, and a wrong offset here puts the handle beside the finger.
    // 滑块自己在自身空间里映射按下点；app 看不到坐标，偏移算错会让手柄停在手指旁边。
    let mut store = AnimStore::new();
    let (control, _, _) = build(
        &mut store,
        Routing::default(),
        0.0,
        0.25,
        SliderSize::XSmall,
        Md3Options::default(),
    );
    let (inset_l, inset_r) = insets(SliderSize::XSmall);
    let travel = WIDTH - inset_l - inset_r;
    let mut state = ui_widgets::WidgetState::default();
    state.pressed = true;
    state.local = Some(Point::new(inset_l + travel * 0.75, 16.0));
    match control.change(&state, Rect::ZERO) {
        Some(ui_core::Change::Value(v)) => {
            assert!((v - 0.75).abs() < 1e-4, "three quarters along asks 0.75, got {v}")
        }
        other => panic!("expected Value(0.75), got {other:?}"),
    }
}

#[test]
fn a_slider_reports_nothing_unless_a_press_is_live_and_it_is_enabled() {
    // `pressed` is also true on a plain hover in some routes; reporting without a press
    // would let the app jump the value whenever the pointer passes over the slider.
    // 有些路由下悬停也会带上 `pressed`；没有按下就上报会让指针路过时值乱跳。
    let mut store = AnimStore::new();
    let (control, _, _) = build(
        &mut store,
        Routing::default(),
        0.0,
        0.25,
        SliderSize::XSmall,
        Md3Options::default(),
    );
    let mut state = ui_widgets::WidgetState::default();
    state.local = Some(Point::new(200.0, 16.0));
    assert!(control.change(&state, Rect::ZERO).is_none(), "no press, no value");

    let disabled = Md3Options { disabled: true, ..Md3Options::default() };
    let mut store = AnimStore::new();
    let (control, _, _) = build(&mut store, Routing::default(), 0.0, 0.25, SliderSize::XSmall, disabled);
    state.pressed = true;
    assert!(control.change(&state, Rect::ZERO).is_none(), "a disabled slider ignores presses");
}

#[test]
fn the_stop_dot_sits_inside_the_track_end_and_takes_the_active_ink() {
    // The dot marks the far end of the track; the export gives it two inks — the inactive
    // container while the fill has not reached it, the active one once it has.
    // 停止点标记轨道远端；导出给它两种颜色——填充未到达时用非活动容器色，到达后用活动色。
    let pack = crate::pack::pack();
    let spec = slider_spec(true, false, false, false, false, SliderSize::XSmall);
    let idle = spec_ink(
        &pack,
        slider_spec(false, false, false, false, false, SliderSize::XSmall)
            .stop_indicator_container
            .color,
        1.0,
    );
    let active = spec_ink(&pack, spec.stop_indicator_container.color, spec.stop_indicator_container.opacity);
    let right = WIDTH - insets(SliderSize::XSmall).1;
    let want_c = right - spec.stop_indicator.trailing_space - spec.stop_indicator.size * 0.5;

    let mut store = AnimStore::new();
    let (_, low, _) = build(&mut store, Routing::default(), 0.0, 0.2, SliderSize::XSmall, Md3Options::default());
    let (rect, colour) = stop_dot(&low).expect("a slider paints its stop dot");
    assert!((rect.size.w - spec.stop_indicator.size).abs() < 1e-4, "the exported diameter");
    assert!((rect.origin.x + rect.size.w * 0.5 - want_c).abs() < 1e-4, "dot at {rect:?}");
    assert_eq!(colour, idle, "the fill has not reached the dot");

    let (_, high, _) = build(&mut store, Routing::default(), 0.0, 1.0, SliderSize::XSmall, Md3Options::default());
    let (_, colour) = stop_dot(&high).expect("the dot stays painted at the end");
    assert_eq!(colour, active, "the fill has run over the dot");
}

#[test]
fn a_pressed_handle_narrows_and_the_gap_closes_with_it() {
    // `thumbSize` resolves to 2dp while pressed, and Flutter shrinks `trackGap` by the same
    // half-delta so the visible space stays put; narrowing alone leaves a 5dp hole.
    // 按压时 `thumbSize` 为 2dp，Flutter 同时把 `trackGap` 减去同样的半差，让可见空隙不变；
    // 只收窄手柄会留下 5dp 的空洞。
    let mut store = AnimStore::new();
    let pressed = Routing { pressed: Some(ID), pressed_path: vec![ID], ..Routing::default() };
    let params = Md3Options::default();
    let spec = slider_spec(true, false, false, true, false, SliderSize::XSmall);
    let (_, rest, _) = build(&mut store, Routing::default(), 0.0, 0.5, SliderSize::XSmall, params);
    assert_eq!(handle(&rest).size.w, HANDLE_W, "the resting handle is 4dp");
    build(&mut store, pressed.clone(), 0.0, 0.5, SliderSize::XSmall, params);
    let (_, mid, _) = build(&mut store, pressed.clone(), 0.05, 0.5, SliderSize::XSmall, params);
    let (control, held, _) = build(&mut store, pressed, 0.1, 0.5, SliderSize::XSmall, params);
    let pressed_w = spec.handle.width;
    assert!((pressed_w - 2.0).abs() < 1e-4, "the export narrows to 2dp");
    assert!((handle(&held).size.w - pressed_w).abs() < 1e-4, "settled at {pressed_w}");
    // Linear 100ms: halfway is a quarter of the way from 4 to 2.
    // 线性 100ms：过半时正好走完 4 到 2 的一半。
    assert!((handle(&mid).size.w - 3.0).abs() < 1e-3, "halfway is {}", handle(&mid).size.w);
    // The gap follows the width: 6 at rest, 5 when fully narrowed.
    // 缺口跟随宽度：静止 6，完全收窄后 5。
    let centre = control.handle_x();
    let segs = segments(&held, spec.track.height);
    assert!((segs[0].0.origin.x + segs[0].0.size.w - (centre - 5.0)).abs() < 1e-4, "gap closes");
}

#[test]
fn a_disabled_slider_takes_the_twelve_and_thirty_eight_percent_inks() {
    // Disabled: inactive track `onSurface@12%`, active track and handle `onSurface@38%`.
    // Using the enabled roles paints a slider that looks perfectly usable.
    // 禁用：非活动轨道 `onSurface@12%`，活动轨道与手柄 `onSurface@38%`。
    // 用启用态的角色会画出看起来完全可用的滑块。
    let pack = crate::pack::pack();
    let params = Md3Options { disabled: true, ..Md3Options::default() };
    let spec = slider_spec(true, false, false, false, true, SliderSize::XSmall);
    let mut store = AnimStore::new();
    let (_, decl, _) = build(&mut store, Routing::default(), 0.0, 0.5, SliderSize::XSmall, params);
    let segs = segments(&decl, spec.track.height);
    assert!((segs[0].1.a - 0.38).abs() < 1e-4, "active track at 38%, not {}", segs[0].1.a);
    assert!((segs[1].1.a - 0.12).abs() < 1e-4, "inactive track at 12%, not {}", segs[1].1.a);
    let handle_fill = match decl.shapes.last().unwrap() {
        Shape::Rect { fill, .. } => *fill,
        _ => unreachable!(),
    };
    assert_eq!(handle_fill, spec_ink(&pack, spec.handle.color, spec.handle.opacity));
    assert!((handle_fill.a - 0.38).abs() < 1e-4, "handle at 38%, not {}", handle_fill.a);
}

#[test]
fn a_size_variant_sets_its_own_track_height_and_insets() {
    // The five sizes are construction-time variants: each has its own track height, inset
    // and handle height, and a slider that ignores them looks like the smallest one forever.
    // 五个尺寸是构建期变体：各自有轨道高度、内缩与手柄高度，忽略它们的滑块永远是那一副小样子。
    for (size, want) in [
        (SliderSize::XSmall, (16.0, 8.0, 48.0)),
        (SliderSize::Small, (24.0, 8.0, 48.0)),
        (SliderSize::Medium, (40.0, 12.0, 48.0)),
        (SliderSize::Large, (56.0, 16.0, 68.0)),
        (SliderSize::XLarge, (96.0, 28.0, 108.0)),
    ] {
        let spec = slider_spec(true, false, false, false, false, size);
        let mut store = AnimStore::new();
        let (_, decl, _) = build(&mut store, Routing::default(), 0.0, 0.5, size, Md3Options::default());
        assert_eq!(spec.track.height, want.0, "{size:?}");
        assert_eq!(spec.track_shape.leading, want.1, "{size:?}");
        assert_eq!(decl.size_class.height.max, want.2, "{size:?}");
        let segs = segments(&decl, want.0);
        assert_eq!(segs.len(), 2, "{size:?}: {segs:?}");
        assert!((segs[0].0.origin.x - want.1).abs() < 1e-4, "{size:?} left inset");
        assert!((handle(&decl).size.h - spec.handle.height).abs() < 1e-4, "{size:?} handle height");
    }
}

#[test]
fn a_hovered_slider_paints_the_overlay_disc_under_the_handle() {
    // The disc is the 48dp `RoundSliderOverlayShape`, centred on the handle; drawing it at
    // the handle's own size hides it behind the handle, so hover looks like nothing happens.
    // 圆盘是 48dp 的 `RoundSliderOverlayShape`，以手柄为中心；按手柄大小画会被手柄盖住，
    // 悬停就像没反应。
    let pack = crate::pack::pack();
    let routing = Routing { hovered: Some(ID), hovered_path: vec![ID], ..Routing::default() };
    let mut store = AnimStore::new();
    let (control, decl, _) = build(&mut store, routing, 0.0, 0.5, SliderSize::XSmall, Md3Options::default());
    let index = decl
        .shapes
        .iter()
        .position(|s| match s {
            Shape::Rect { rect, .. } => (rect.size.w - SLIDER_OVERLAY).abs() < 0.01,
            _ => false,
        })
        .expect("hover paints an overlay disc");
    assert_eq!(index, decl.shapes.len() - 2, "the disc sits directly under the handle");
    let Shape::Rect { rect, corners, fill, .. } = decl.shapes[index] else { unreachable!() };
    let centre = control.handle_x();
    assert!((rect.origin.x + rect.size.w * 0.5 - centre).abs() < 1e-4, "disc at {rect:?}");
    assert!((rect.origin.y + rect.size.h * 0.5 - SLIDER_TOUCH * 0.5).abs() < 1e-4);
    assert_eq!(corners.tl, SLIDER_OVERLAY * 0.5);
    // Flutter's M3 `overlayColor` for hover: primary at 8%.
    // Flutter 的 M3 `overlayColor` 悬停值：8% 的 primary。
    assert_eq!(fill.a, role(&pack, "primary").a * 0.08);
}

/// The tick dots: the only 2dp squares the slider paints.
/// 刻度点：滑块唯一画的 2dp 方块。
fn ticks(decl: &Decl) -> Vec<Rect> {
    decl.shapes
        .iter()
        .filter_map(|s| match s {
            Shape::Rect { rect, .. } if (rect.size.w - 2.0).abs() < 0.01 => Some(*rect),
            _ => None,
        })
        .collect()
}

#[test]
fn a_stepped_slider_reports_the_nearest_stop() {
    // `step` is a mapping rule, not a paint detail: a press between two stops must report
    // the nearer one, or the handle settles beside the finger and the app never sees a stop.
    // `step` 是映射规则而非绘制细节：落在两个刻度之间的按下必须上报较近的那个，
    // 否则手柄停在手指旁边，应用永远看不到刻度值。
    let mut store = AnimStore::new();
    let opts = SliderOpts { step: Some(0.25), ..Default::default() };
    let (control, _, _) = build_opts(
        &mut store,
        Routing::default(),
        0.0,
        0.25,
        SliderSize::XSmall,
        Md3Options::default(),
        opts,
    );
    let (inset_l, inset_r) = insets(SliderSize::XSmall);
    let travel = WIDTH - inset_l - inset_r;
    let mut state = ui_widgets::WidgetState::default();
    state.pressed = true;
    state.local = Some(Point::new(inset_l + travel * 0.62, 16.0));
    match control.change(&state, Rect::ZERO) {
        Some(ui_core::Change::Value(v)) => {
            assert!((v - 0.5).abs() < 1e-4, "0.62 along snaps to 0.5, got {v}")
        }
        other => panic!("expected Value(0.5), got {other:?}"),
    }
    // A press that lands on the stop the slider already sits on reports nothing.
    // 落在滑块已停刻度上的按下不上报。
    state.local = Some(Point::new(inset_l + travel * 0.24, 16.0));
    assert!(control.change(&state, Rect::ZERO).is_none(), "0.24 is still the current stop");
}

#[test]
fn tick_dots_sit_on_the_interior_stops() {
    // The two end stops have no dot: the track's rounded cap would leave a half-dot hanging
    // outside the shape, and the handle covers that spot at either extreme anyway.
    // 两端刻度不画点：轨道圆端帽会让半个点露在形状之外，且两端的位置本就由手柄占着。
    let mut store = AnimStore::new();
    let opts = SliderOpts { step: Some(0.25), ticks: true, end: None };
    let (control, decl, _) = build_opts(
        &mut store,
        Routing::default(),
        0.0,
        0.0,
        SliderSize::XSmall,
        Md3Options::default(),
        opts,
    );
    let got = ticks(&decl);
    assert_eq!(got.len(), 3, "three interior stops: {got:?}");
    let (inset_l, _) = insets(SliderSize::XSmall);
    let travel = WIDTH - 2.0 * inset_l;
    for (k, rect) in got.iter().enumerate() {
        let want = inset_l + travel * (k as f32 + 1.0) * 0.25;
        assert!(
            (rect.origin.x + rect.size.w * 0.5 - want).abs() < 1e-4,
            "dot {k} at {rect:?}, want centre {want}"
        );
    }
    // The leading handle starts at the first stop, so no dot is hidden under it here.
    // 前手柄停在第一个刻度上，因此这里没有点被它挡住。
    assert!((control.handle_x() - inset_l).abs() < 1e-4);
}

#[test]
fn a_range_paints_only_the_span_between_its_handles_active() {
    // Flutter's `RangeSliderTrackShape`: "The middle track segment is the selected range and is
    // active, and the two outer track segments are inactive."
    // Flutter `RangeSliderTrackShape`：中间段是选中范围且为激活色，两侧段为非激活色。
    let mut store = AnimStore::new();
    let opts = SliderOpts { end: Some(0.7), ..Default::default() };
    let (_, decl, _) = build_opts(
        &mut store,
        Routing::default(),
        0.0,
        0.2,
        SliderSize::XSmall,
        Md3Options::default(),
        opts,
    );
    let on = slider_spec(true, false, false, false, false, SliderSize::XSmall);
    let off = slider_spec(false, false, false, false, false, SliderSize::XSmall);
    let active = spec_ink(&crate::pack::pack(), on.track.color, on.track.opacity);
    let inactive = spec_ink(&crate::pack::pack(), off.track.color, off.track.opacity);
    let fills: Vec<Color> = segments(&decl, on.track.height)
        .into_iter()
        .map(|(_, fill)| fill)
        .collect();
    assert_eq!(fills, vec![inactive, active, inactive], "left, middle, right");
}

#[test]
fn a_range_puts_a_stop_dot_at_each_track_end() {
    // Flutter's `GappedRangeSliderTrackShape` draws one indicator per end; a range that marks
    // only the far end leaves the start of the track unmarked.
    // Flutter `GappedRangeSliderTrackShape` 在两端各画一个指示点；只标远端的范围滑块
    // 会让轨道起点没有标记。
    let spec = slider_spec(true, false, false, false, false, SliderSize::XSmall);
    let mut store = AnimStore::new();
    let opts = SliderOpts { end: Some(0.7), ..Default::default() };
    let (_, decl, _) = build_opts(
        &mut store,
        Routing::default(),
        0.0,
        0.2,
        SliderSize::XSmall,
        Md3Options::default(),
        opts,
    );
    let (inset_l, inset_r) = insets(SliderSize::XSmall);
    let space = spec.stop_indicator.trailing_space + spec.stop_indicator.size * 0.5;
    let mut xs: Vec<f32> = stop_dots(&decl, spec.stop_indicator.size)
        .into_iter()
        .map(|r| r.origin.x + r.size.w * 0.5)
        .collect();
    xs.sort_by(|a, b| a.partial_cmp(b).expect("finite"));
    assert_eq!(xs.len(), 2, "one dot per end");
    assert!((xs[0] - (inset_l + space)).abs() < 1e-4, "left dot at {}", xs[0]);
    assert!((xs[1] - (WIDTH - inset_r - space)).abs() < 1e-4, "right dot at {}", xs[1]);
}

#[test]
fn a_discrete_slider_shows_tick_dots_instead_of_stop_dots() {
    // Flutter guards the stop indicator with `!isDiscrete`: a stepped slider marks its stops
    // with tick dots, and drawing both leaves a dot between the last tick and the end.
    // Flutter 用 `!isDiscrete` 挡住停止点：有刻度的滑块用刻度点标出各个停靠点，
    // 两者都画会在最后一个刻度与末端之间多出一个点。
    let mut store = AnimStore::new();
    let opts = SliderOpts { step: Some(0.25), ticks: true, ..Default::default() };
    let (_, decl, _) = build_opts(
        &mut store,
        Routing::default(),
        0.0,
        0.0,
        SliderSize::XSmall,
        Md3Options::default(),
        opts,
    );
    let spec = slider_spec(true, false, false, false, false, SliderSize::XSmall);
    assert!(stop_dots(&decl, spec.stop_indicator.size).is_empty(), "no stop dot");
    assert_eq!(ticks(&decl).len(), 3, "the three interior stops still show");
}

#[test]
fn a_range_slider_moves_only_the_nearer_handle() {
    // Two handles share one node, so the press has to pick one: the nearer. Moving both, or
    // the wrong one, makes the selected span jump under the finger.
    // 两个手柄共用一个节点，按下必须挑一个：较近的那个。同时移动或移错，
    // 会让选中段在手指下跳变。
    let mut store = AnimStore::new();
    let opts = SliderOpts { end: Some(0.7), ..Default::default() };
    let (control, _, _) = build_opts(
        &mut store,
        Routing::default(),
        0.0,
        0.2,
        SliderSize::XSmall,
        Md3Options::default(),
        opts,
    );
    let (inset_l, inset_r) = insets(SliderSize::XSmall);
    let travel = WIDTH - inset_l - inset_r;
    let mut state = ui_widgets::WidgetState::default();
    state.pressed = true;

    state.local = Some(Point::new(inset_l + travel * 0.9, 16.0));
    let moved = control.change(&state, Rect::ZERO).expect("a press past 0.7 moves the end");
    let r = moved.data::<crate::slider::Md3Range>().expect("a range reports both values");
    assert!((r.start - 0.2).abs() < 1e-4, "the leading handle stays at 0.2, got {}", r.start);
    assert!((r.end - 0.9).abs() < 1e-4, "the trailing handle follows to 0.9, got {}", r.end);

    state.local = Some(Point::new(inset_l + travel * 0.3, 16.0));
    let moved = control.change(&state, Rect::ZERO).expect("a press past 0.2 moves the start");
    let r = moved.data::<crate::slider::Md3Range>().expect("a range reports both values");
    assert!((r.start - 0.3).abs() < 1e-4, "the leading handle follows to 0.3, got {}", r.start);
    assert!((r.end - 0.7).abs() < 1e-4, "the trailing handle stays at 0.7, got {}", r.end);
}
