//! The MD3 FAB menu: pill items stacked above the circular close button that replaced the FAB.
//! MD3 FAB 菜单：胶囊菜单项堆在取代 FAB 的圆形关闭按钮上方。

use super::*;

use crate::spec::{fab_menu_spec, FabMenuColor, FabMenuContainer};
use crate::toggle::{role, spec_ink};
use crate::typescale;
use ui_core::cx::Routing;
use ui_core::draw::Shape;
use ui_core::geom::Rect;
use ui_core::NodeData;
use ui_widgets::WidgetState;

const MENU: Id = Id::str("fab-menu");
const ITEMS: [Id; 3] = [Id::str("item-a"), Id::str("item-b"), Id::str("item-c")];

/// A 24dp mark in the item's ink: the stand-in for a real glyph.
/// 24dp、按菜单项墨色绘制的标记：代替真实字形。
fn dot(id: Id, ink: Color) -> Decl {
    Decl::container(id, NodeKind::Box)
        .size(SizeClass::fixed(24.0, 24.0))
        .shapes(vec![Shape::Box {
            corners: ui_core::Corners::ZERO,
            fill: ink,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }])
}

fn close_id() -> Id {
    MENU.with("close")
}

fn entries() -> [Md3FabMenuItem<'static>; 3] {
    [
        Md3FabMenuItem { id: ITEMS[0], label: "One", icon: ui_widgets::IconSource::Custom(dot) },
        Md3FabMenuItem { id: ITEMS[1], label: "Two", icon: ui_widgets::IconSource::Custom(dot) },
        Md3FabMenuItem { id: ITEMS[2], label: "Three", icon: ui_widgets::IconSource::Custom(dot) },
    ]
}

fn build(
    store: &mut AnimStore,
    routing: Routing,
    now: f64,
    tone: FabMenuColour,
    open: bool,
    params: Md3Options,
) -> (Md3FabMenu, Decl) {
    let mut core = ui_core::cx::Cx::new(store, 0, 400, 400, now, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let menu = Md3FabMenu::new_with(
        params,
        MENU,
        &entries(),
        tone,
        open,
        ui_widgets::IconSource::Custom(dot),
        &mut cx,
        &crate::pack::pack(),
    );
    let decl = cx.with_cx(|cx| menu.decl(cx));
    (menu, decl)
}

fn plain(open: bool) -> (Md3FabMenu, Decl) {
    let mut store = AnimStore::new();
    build(&mut store, Routing::default(), 0.0, FabMenuColour::Primary, open, Md3Options::default())
}

fn find(decl: &Decl, id: Id) -> Option<&Decl> {
    if decl.id == id {
        return Some(decl);
    }
    decl.children.iter().find_map(|c| find(c, id))
}

/// The fills of a node's boxes in paint order: container, then the state layer.
/// 一个节点的盒子填充，按绘制顺序：容器、状态层。
fn fills(decl: &Decl) -> Vec<Color> {
    decl.shapes
        .iter()
        .filter_map(|s| match s {
            Shape::Box { fill, .. } => Some(*fill),
            _ => None,
        })
        .collect()
}

fn label(decl: &Decl, item: Id) -> (&ui_core::text::TextRun, Color) {
    match &find(decl, item.with("label")).expect("every item carries a label").data {
        NodeData::Text { block, ink, .. } => (&block.runs[0], *ink),
        _ => panic!("the label is a text node"),
    }
}

#[test]
fn each_row_takes_its_height_and_the_gaps_from_the_export() {
    // Three rows and two different gaps: 56dp items with 4dp between them, then 8dp before
    // the close button. One shared gap would move the anchor off the FAB's slot.
    // 三行与两种间隙：56dp 的项之间 4dp，关闭按钮前 8dp。用同一种间隙会把锚点挪离 FAB 的位置。
    let (menu, decl) = plain(true);
    let spec = fab_menu_spec(false, false, false, FabMenuColor::Primary, FabMenuContainer::PrimaryContainer);
    assert_eq!(menu.height(), 3.0 * 56.0 + 2.0 * 4.0 + 8.0 + 56.0);
    let tree = lay_out(&decl, (400.0, 400.0));
    let (_, y0, _, h0) = region_rect(&tree, ITEMS[0]);
    let (_, y1, _, _) = region_rect(&tree, ITEMS[1]);
    let (_, y2, _, _) = region_rect(&tree, ITEMS[2]);
    let (_, cy, _, ch) = region_rect(&tree, close_id());
    assert_eq!(h0, spec.menu_item_container.height);
    assert!((y1 - (y0 + h0) - spec.menu_item.between_space).abs() < 0.01, "item gap");
    assert!((y2 - (y1 + h0) - spec.menu_item.between_space).abs() < 0.01, "item gap");
    assert!((cy - (y2 + h0) - spec.close_button.between_space).abs() < 0.01, "close gap: close {cy}, last item bottom {}, want gap {}", y2 + h0, spec.close_button.between_space);
    assert_eq!(ch, spec.close_button_container.height);
}

#[test]
fn the_items_take_the_container_form_of_the_close_buttons_tone() {
    // The export splits the FAB's tone across two axes (`primary` for the close button,
    // `primary-container` for the items). Picking them independently would let a primary FAB
    // open a secondary menu.
    // 导出把 FAB 的色调拆成两个轴（关闭按钮 `primary`、菜单项 `primary-container`）。
    // 各自独立选取会让主色 FAB 开出次色菜单。
    let pack = crate::pack::pack();
    let cases = [
        (FabMenuColour::Primary, FabMenuColor::Primary, FabMenuContainer::PrimaryContainer),
        (FabMenuColour::Secondary, FabMenuColor::Secondary, FabMenuContainer::SecondaryContainer),
        (FabMenuColour::Tertiary, FabMenuColor::Tertiary, FabMenuContainer::TertiaryContainer),
    ];
    for (tone, close, items) in cases {
        let mut store = AnimStore::new();
        let (_, decl) = build(&mut store, Routing::default(), 0.0, tone, true, Md3Options::default());
        let spec = fab_menu_spec(false, false, false, close, items);
        let item = fills(find(&decl, ITEMS[0]).expect("the item is drawn"));
        assert_eq!(item[0], spec_ink(&pack, spec.list_item_container.color, 1.0), "{tone:?} item");
        let close = fills(find(&decl, close_id()).expect("the close button is drawn"));
        assert_eq!(close[0], spec_ink(&pack, spec.close_button_container.color, 1.0), "{tone:?} close");
    }
}

#[test]
fn the_item_label_takes_the_exported_type_scale() {
    // The export names `title-medium` for the item label; a hard-coded size would drift from
    // the rest of the type scale the moment the export changes.
    // 导出给菜单项标签指定 `title-medium`；写死字号会在导出一变就与整套字级脱节。
    let (_, decl) = plain(true);
    let (run, _) = label(&decl, ITEMS[0]);
    let want = typescale::named("title-medium");
    assert_eq!(run.style.size, want.size);
    assert_eq!(run.style.weight, want.weight);
}

#[test]
fn the_trailing_edges_of_the_items_and_the_anchor_line_up() {
    // Items are wider than the close button; MD3 lines them up on the trailing edge. Centring
    // them instead hangs the anchor off the FAB's slot by half an item's width.
    // 菜单项比关闭按钮宽；MD3 让尾部对齐。改成居中会让锚点偏出 FAB 的位置半个项宽。
    let (_, decl) = plain(true);
    let tree = lay_out(&decl, (400.0, 400.0));
    let (_, _, cw, _) = region_rect(&tree, close_id());
    let (cx, _, _, _) = region_rect(&tree, close_id());
    for item in ITEMS {
        let (x, _, w, _) = region_rect(&tree, item);
        assert!((x + w - (cx + cw)).abs() < 0.01, "{item:?} ends at {}, anchor at {}", x + w, cx + cw);
    }
}

#[test]
fn a_hovered_item_paints_the_eight_percent_state_layer() {
    // The layer's ink and strength come from the export's `list-item.hovered` branch; the
    // close button's own layer must not light up with it.
    // 状态层的墨色与强度来自导出的 `list-item.hovered` 分支；关闭按钮的层不得跟着亮。
    let routing = Routing { hovered: Some(ITEMS[1]), hovered_path: vec![ITEMS[1]], ..Routing::default() };
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, routing, 0.0, FabMenuColour::Primary, true, Md3Options::default());
    let pack = crate::pack::pack();
    let spec = fab_menu_spec(
        true, false, false, FabMenuColor::Primary, FabMenuContainer::PrimaryContainer,
    );
    let ink = role(&pack, spec.list_item_state_layer.color);
    let want = Color { a: ink.a * spec.list_item_state_layer.opacity, ..ink };
    let item = fills(find(&decl, ITEMS[1]).expect("the item is drawn"));
    assert_eq!(item.last(), Some(&want), "the layer is painted over the container");
    assert_eq!(item.len(), 2, "container then layer, nothing else");
    let close = fills(find(&decl, close_id()).expect("the close button is drawn"));
    assert_eq!(close.len(), 1, "an unhovered anchor paints no layer");
}

#[test]
fn a_closed_menu_draws_no_items_but_keeps_the_anchor() {
    // Collapsing by fading to zero would leave items that still answer clicks; the anchor is
    // the FAB's own slot and must stay.
    // 靠淡到零来收起会留下仍能响应点击的项；锚点是 FAB 自己的位置，必须留下。
    let (_, decl) = plain(false);
    for item in ITEMS {
        assert!(find(&decl, item).is_none(), "{item:?} is not drawn while closed");
    }
    assert!(find(&decl, close_id()).is_some(), "the anchor stays");
}

#[test]
fn a_press_names_the_item_or_the_anchor() {
    // A menu item is a choice, the anchor is an action: reporting both as one kind of change
    // would leave the app unable to tell "picked B" from "closed the menu".
    // 菜单项是一次选择，锚点是一个动作：两者报同一种变化，应用就分不清「选了 B」与「收起菜单」。
    let (menu, _) = plain(true);
    let bounds = Rect::new(0.0, 0.0, 200.0, menu.height());
    let press = |y: f32| WidgetState { clicked: true, local: Some(ui_core::geom::Point::new(10.0, y)), ..Default::default() };
    assert!(matches!(menu.change(&press(10.0), bounds), Some(ui_core::Change::Selected(Some(id))) if id == ITEMS[0]));
    assert!(matches!(menu.change(&press(70.0), bounds), Some(ui_core::Change::Selected(Some(id))) if id == ITEMS[1]));
    let close_y = menu.height() - 20.0;
    assert!(matches!(menu.change(&press(close_y), bounds), Some(ui_core::Change::Activated)));
}

#[test]
fn a_press_on_a_closed_menu_reports_no_choice() {
    // The items are not drawn while closed, so a press landing on their old rows must not
    // report a choice the app cannot see.
    // 收起时菜单项不画，因此落在它们旧行上的按下不得上报一个应用看不见的选择。
    let (menu, _) = plain(false);
    let bounds = Rect::new(0.0, 0.0, 200.0, menu.height());
    let press = WidgetState { clicked: true, local: Some(ui_core::geom::Point::new(10.0, 10.0)), ..Default::default() };
    assert!(menu.change(&press, bounds).is_none());
}

#[test]
fn a_disabled_menu_fades_its_inks_and_keeps_a_twelve_percent_container() {
    // The export has no disabled inks; MD3's rule is 38% content over an `on-surface` container
    // at 12%. Dropping the container would make a disabled item look like a hovered one.
    // 导出没有禁用配色；MD3 的规定是内容 38%、容器为 12% 的 `on-surface`。
    // 丢掉容器会让禁用项看起来像悬停项。
    let params = Md3Options { disabled: true, ..Md3Options::default() };
    let mut store = AnimStore::new();
    let (menu, decl) = build(&mut store, Routing::default(), 0.0, FabMenuColour::Primary, true, params);
    let pack = crate::pack::pack();
    let item = find(&decl, ITEMS[0]).expect("the item is drawn");
    let fill = fills(item);
    assert_eq!(fill[0], Color { a: 0.12, ..role(&pack, "onSurface") });
    let (_, ink) = label(&decl, ITEMS[0]);
    assert!((ink.a - 0.38).abs() < 1e-4, "the label is at 38%, got {}", ink.a);
    let close = fills(find(&decl, close_id()).expect("the anchor is drawn"));
    assert_eq!(close[0], Color { a: 0.12, ..role(&pack, "onSurface") });
    let bounds = Rect::new(0.0, 0.0, 200.0, menu.height());
    let press = WidgetState { clicked: true, local: Some(ui_core::geom::Point::new(10.0, 10.0)), ..Default::default() };
    assert!(menu.change(&press, bounds).is_none(), "a disabled menu reports nothing");
}
