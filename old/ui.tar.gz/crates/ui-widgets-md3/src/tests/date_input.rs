//! The MD3 date input: the exported box, and the three ids the app tells its actions by.
//! MD3 日期输入：导出的盒子，以及应用据以区分动作的三个 id。

use super::*;

use crate::date_input::{
    date_input_field_id, DateInputAction, DateInputChange, DateInputParams, Md3DateInput,
};
use ui_core::cx::Routing;
use ui_core::layout::{AxisSize, Sizing};
use ui_core::Change;
use ui_widgets::WidgetState;

const D: Id = Id::str("date-input");

fn build(routing: Routing, params: DateInputParams<'_>) -> (Md3DateInput, Decl) {
    let mut store = AnimStore::new();
    let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 560, 0.0, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let input = Md3DateInput::from_pack(&crate::pack::pack(), &mut cx, params);
    let decl = cx.with_cx(|cx| input.decl(cx));
    (input, decl)
}

/// The change a click on `hit` produces, through the path the engine would route.
/// 点击 `hit` 产生的变化，路径与引擎的路由一致。
fn clicked(params: DateInputParams<'_>, hit: Id) -> Option<Change> {
    let routing = Routing {
        clicked_path: vec![D, hit],
        ..Routing::default()
    };
    let (input, _) = build(routing, params);
    input.change(&WidgetState::default(), ui_core::geom::Rect::ZERO)
}

fn find_decl(decl: &Decl, id: Id) -> Option<&Decl> {
    if decl.id == id {
        return Some(decl);
    }
    decl.children.iter().find_map(|c| find_decl(c, id))
}

#[test]
fn each_action_reports_the_node_it_owns() {
    // The app tells the three apart by id alone; if they shared one, Cancel would read as
    // Confirm and the dialog would commit a date the user refused.
    // 应用只凭 id 区分这三者；若共用同一个，取消会被读成确定，对话框就提交了用户拒绝的日期。
    for action in [
        DateInputAction::Calendar,
        DateInputAction::Cancel,
        DateInputAction::Confirm,
    ] {
        let change = clicked(DateInputParams::new(D), action.id(D)).expect("an action");
        assert_eq!(
            change.data::<DateInputChange>().ok(),
            Some(DateInputChange(action)),
            "{action:?}"
        );
    }
}

#[test]
fn a_host_without_a_calendar_gets_no_calendar_button() {
    // The toggle is the host's choice: a page with no calendar face must not draw a button
    // that reports an action it cannot honour.
    // 开关由宿主选择：没有日历面的页面不得画出一个上报它兑现不了的动作的按钮。
    let mut params = DateInputParams::new(D);
    params.calendar = false;
    assert!(clicked(params, DateInputAction::Calendar.id(D)).is_none());
}

#[test]
fn the_field_spans_the_surface_minus_its_side_insets() {
    // The export fixes the surface and the header band; the field takes what the side insets
    // leave. A hand-picked field width would drift from the box it sits in.
    // 导出固定了表面与标题带；字段取侧向内衬剩下的宽度。手挑的字段宽度会与它所在的盒子脱节。
    let (_, decl) = build(Routing::default(), DateInputParams::new(D));
    // The export's own numbers, spelled out: a constant compared with itself would pass
    // whatever the constant said.
    // 导出自己的数字，写死在这里：拿常量和自己比，常量改成什么都会通过。
    assert_eq!(decl.size_class.width, AxisSize::fixed(328.0));
    assert_eq!(decl.size_class.height, AxisSize::fixed(512.0));
    let header = find_decl(&decl, D.with("header")).expect("the header band");
    let band = header.size_class.height;
    assert_eq!(band.min, 120.0, "the export's floor");
    assert_eq!(band.sizing, Sizing::Fit, "and a wrapping headline may grow it");
    let field = find_decl(&decl, date_input_field_id(D).with("root")).expect("the field");
    assert_eq!(field.size_class.width, AxisSize::fixed(280.0), "328 less 24 either side");
}
