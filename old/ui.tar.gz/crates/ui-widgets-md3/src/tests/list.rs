//! MD3 list items: one to three lines, an optional leading slot and a state layer.
//! MD3 列表项：一到三行文字、可选的前置槽，以及状态层。

use super::*;

use crate::spec::{
    list_spec, ListLayout, ListLines, ListSelection, ListVariant, ListVideo,
};
use crate::toggle::{role, spec_ink};
use ui_core::cx::Routing;
use ui_core::draw::Shape;
use ui_core::geom::Rect;
use ui_core::NodeData;
use ui_widgets::WidgetState;

const ROW: Id = Id::str("row");

fn dot(id: Id, ink: Color, size: f32) -> Decl {
    Decl::container(id, NodeKind::Box)
        .size(SizeClass::fixed(size, size))
        .shapes(vec![Shape::Box {
            corners: ui_core::Corners::ZERO,
            fill: ink,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }])
}

fn build(
    store: &mut AnimStore,
    routing: Routing,
    item: ListItemParams,
    params: Md3Options,
) -> (Md3ListItem, Decl) {
    let mut core = ui_core::cx::Cx::new(store, 0, 400, 400, 0.0, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let widget = Md3ListItem::new_with(params, item, &mut cx, &crate::pack::pack());
    let decl = cx.with_cx(|cx| widget.decl(cx));
    (widget, decl)
}

fn plain(lines: ListLineCount) -> (Md3ListItem, Decl) {
    let mut store = AnimStore::new();
    let item = ListItemParams::new(ROW, "Label").lines(lines);
    build(&mut store, Routing::default(), item, Md3Options::default())
}

/// The item's boxes in paint order: the container, then the state layer, then the ring.
/// 条目按绘制顺序的盒子：容器、状态层、焦点环。
fn boxes(decl: &Decl) -> Vec<(Color, Option<(Color, f32)>)> {
    decl.shapes
        .iter()
        .filter_map(|s| match s {
            Shape::Box { fill, border, .. } => Some((*fill, *border)),
            _ => None,
        })
        .collect()
}

fn find(decl: &Decl, id: Id) -> Option<&Decl> {
    if decl.id == id {
        return Some(decl);
    }
    decl.children.iter().find_map(|c| find(c, id))
}

/// The node id an item derives for one of its named slots.
/// 条目为其某个命名槽派生的节点 id。
fn list_slot(id: Id, name: ListItemSlot) -> Id {
    ui_core::slot::slot_id(id, name.slot())
}

fn ink_of(decl: &Decl, id: Id) -> Color {
    match &find(decl, id).unwrap_or_else(|| panic!("missing {id:?}")).data {
        NodeData::Text { ink, .. } => *ink,
        _ => panic!("{id:?} is not text"),
    }
}

fn base_spec(selected: bool, lines: ListLines) -> crate::spec::ListSpec {
    list_spec(
        false,
        false,
        false,
        false,
        false,
        lines,
        if selected { ListSelection::Selected } else { ListSelection::Unselected },
        ListLayout::Base,
        ListVariant::Base,
        ListVideo::Base,
    )
}

#[test]
fn a_leading_icon_box_shares_the_label_rows_centre() {
    // A glyph fills its 1.4 em line box, a painted mark only its own size; both must land
    // on the label's centre or the mark hangs high — the shape of the bug this pins.
    // 字形填满 1.4em 行盒，绘制标记只有自身尺寸；两者都必须落在标签中心，否则标记吊高
    // ——这正是本条要钉住的缺陷形态。
    for (name, mark) in [
        (
            "glyph",
            (|id, ink, size| ui_widgets::Icon::new(id, "square", size, ink).resolve())
                as fn(Id, Color, f32) -> Decl,
        ),
        ("box", dot),
    ] {
        let mut store = AnimStore::new();
        let item = ListItemParams::new(ROW, "Label")
            .leading(ListLeading::Icon)
            .mark(mark);
        let (_, decl) = build(&mut store, Routing::default(), item, Md3Options::default());
        let tree = laid_out(decl);
        let mark_id = ui_core::slot::slot_id(ROW, ListItemSlot::Leading.slot()).with("mark");
        let (_, my, _, mh) = region_rect(&tree, mark_id);
        let (_, ly, _, lh) = region_rect(&tree, ROW.with("text").with("label"));
        assert_eq!(
            my + mh * 0.5,
            ly + lh * 0.5,
            "{name} mark's box centre must sit on the label's, got {my}+{mh}/2 vs {ly}+{lh}/2"
        );
    }
}

#[test]
fn each_line_count_takes_its_exported_height() {
    // 56 / 72 / 88 are three different heights; one height for all three squashes the
    // supporting text into a one-line row.
    // 56 / 72 / 88 是三个不同高度；三行共用一个高度会把副文本挤进单行。
    for (count, lines, want) in [
        (ListLineCount::One, ListLines::OneLine, 56.0),
        (ListLineCount::Two, ListLines::TwoLine, 72.0),
        (ListLineCount::Three, ListLines::ThreeLine, 88.0),
    ] {
        let (item, _) = plain(count);
        assert_eq!(item.height(), want, "{lines:?}");
        assert_eq!(base_spec(false, lines).container.height, want);
    }
}

#[test]
fn a_selected_item_takes_the_secondary_container() {
    // Selection is the whole reason a list item paints a fill: a plain one sits on `surface`.
    // 选中正是列表项要画填充的全部理由：普通项坐在 `surface` 上。
    let pack = crate::pack::pack();
    let (_, plain_decl) = plain(ListLineCount::One);
    assert_eq!(boxes(&plain_decl)[0].0, spec_ink(&pack, base_spec(false, ListLines::OneLine).container.color, 1.0));
    let mut store = AnimStore::new();
    let item = ListItemParams::new(ROW, "Label").selected(true);
    let (_, selected) = build(&mut store, Routing::default(), item, Md3Options::default());
    assert_eq!(boxes(&selected)[0].0, role(&pack, "secondaryContainer"));
}

/// The press ink the row declares, if any.
/// 行声明的按压墨迹（若有）。
fn splat(decl: &Decl) -> Option<ui_core::PressInk> {
    match &decl.data {
        NodeData::Container(p) => p.press_ink,
        _ => None,
    }
}

#[test]
fn a_press_splats_the_press_opacity_instead_of_raising_the_layer() {
    // Hover is 8% and press is 10%. Only hover raises the flat layer now; a press is ink the
    // engine splats where the pointer landed.
    // 悬停 8%、按下 10%。现在只有悬停抬高平坦层；按下是引擎在指针落点泼出的墨迹。
    let pack = crate::pack::pack();

    let mut store = AnimStore::new();
    let (_, decl) = build(
        &mut store,
        Routing { hovered: Some(ROW), hovered_path: vec![ROW], ..Routing::default() },
        ListItemParams::new(ROW, "Label"),
        Md3Options::default(),
    );
    let spec = list_spec(
        true,
        false,
        false,
        false,
        false,
        ListLines::OneLine,
        ListSelection::Unselected,
        ListLayout::Base,
        ListVariant::Base,
        ListVideo::Base,
    );
    let ink = role(&pack, spec.state_layer.color);
    let want = Color { a: ink.a * spec.state_layer.opacity, ..ink };
    assert_eq!(boxes(&decl).last().map(|b| b.0), Some(want), "hover still raises the layer");

    let mut store = AnimStore::new();
    let (_, decl) = build(
        &mut store,
        Routing { pressed: Some(ROW), ..Routing::default() },
        ListItemParams::new(ROW, "Label"),
        Md3Options::default(),
    );
    let spec = list_spec(
        false,
        false,
        true,
        false,
        false,
        ListLines::OneLine,
        ListSelection::Unselected,
        ListLayout::Base,
        ListVariant::Base,
        ListVideo::Base,
    );
    let ink = role(&pack, spec.state_layer.color);
    let want = Color { a: ink.a * spec.state_layer.opacity, ..ink };
    let ink = splat(&decl).expect("a press asks the engine for ink");
    assert_eq!(ink.colour, want);
    assert_eq!(ink.radius, ui_core::InkRadius::Cover, "ink covers the whole row");
    assert!(
        boxes(&decl).iter().all(|b| b.0 != want),
        "a press must not also raise the flat layer"
    );
}

#[test]
fn a_disabled_item_takes_the_exported_opacities() {
    // Disabled content is `on-surface` at 38%, and the item stops reporting clicks.
    // 禁用内容是 `on-surface` 取 38%，且条目不再上报点击。
    let params = Md3Options { disabled: true, ..Md3Options::default() };
    let mut store = AnimStore::new();
    let (item, decl) = build(
        &mut store,
        Routing::default(),
        ListItemParams::new(ROW, "Label").supporting("Supporting"),
        params,
    );
    let spec = list_spec(
        false,
        false,
        false,
        false,
        true,
        ListLines::OneLine,
        ListSelection::Unselected,
        ListLayout::Base,
        ListVariant::Base,
        ListVideo::Base,
    );
    let label = ink_of(&decl, ROW.with("text").with("label"));
    assert!((label.a - spec.label_text.opacity).abs() < 1e-4, "label at {}", label.a);
    let supporting = ink_of(&decl, ROW.with("text").with("supporting"));
    assert!((supporting.a - spec.supporting_text.opacity).abs() < 1e-4);
    assert_eq!(boxes(&decl).len(), 1, "a disabled item paints no state layer");
    let click = WidgetState { clicked: true, ..Default::default() };
    assert!(item.change(&click, Rect::new(0.0, 0.0, 300.0, 56.0)).is_none());
}

#[test]
fn a_clicked_item_reports_activation() {
    // The item is the row an app hangs an action on; it must not stay silent.
    // 条目是应用挂动作的那一行；它不能保持沉默。
    let (item, _) = plain(ListLineCount::One);
    let click = WidgetState { clicked: true, ..Default::default() };
    assert!(matches!(
        item.change(&click, Rect::new(0.0, 0.0, 300.0, 56.0)),
        Some(ui_core::Change::Activated)
    ));
}

#[test]
fn the_leading_slot_sits_after_the_sixteen_dp_pad_and_the_text_after_twelve() {
    // The export insets the row by 16dp and separates the slot from the text by 12dp;
    // collapsing either puts the text against the edge.
    // 导出把整行内缩 16dp、前置槽与文字之间留 12dp；任一处塌陷都会让文字贴边。
    let mut store = AnimStore::new();
    let item = ListItemParams::new(ROW, "Label")
        .leading(ListLeading::Icon)
        .mark(dot);
    let (_, decl) = build(&mut store, Routing::default(), item, Md3Options::default());
    let root = Decl::container(Id::str("root"), NodeKind::Row).child(decl);
    let tree = lay_out(&root, (400.0, 400.0));
    let (x, _, _, _) = region_rect(&tree, ROW);
    let (sx, _, sw, _) = region_rect(&tree, list_slot(ROW, ListItemSlot::Leading));
    let (tx, _, _, _) = region_rect(&tree, ROW.with("text"));
    let spec = base_spec(false, ListLines::OneLine);
    assert!((sx - x - spec.root.leading_space).abs() < 0.01, "slot at {sx}, row at {x}");
    assert!((sw - spec.leading_icon.size).abs() < 0.01, "slot is {} wide", sw);
    assert!((tx - (sx + sw) - spec.root.between_space).abs() < 0.01, "text at {tx}");
}

#[test]
fn a_filled_slot_takes_its_id_from_the_item_and_the_slot_name() {
    // The app names a slot, never an id: the node carrying the content is derived from
    // (item, name), so swapping the content inside cannot change the slot's identity.
    // 应用只给出槽名，从不给 id：承载内容的节点由 (条目, 名字) 派生，
    // 因此换掉里面的内容也改不了槽的身份。
    let art = dot(Id::str("custom-leading"), Color::WHITE, 20.0);
    let mut store = AnimStore::new();
    let item = ListItemParams::new(ROW, "Label").slot(ListItemSlot::Leading, art);
    let (_, decl) = build(&mut store, Routing::default(), item, Md3Options::default());
    let slot = find(&decl, list_slot(ROW, ListItemSlot::Leading))
        .expect("the slot node must carry the derived id");
    assert!(
        find(slot, Id::str("custom-leading")).is_some(),
        "the app's content keeps its own id inside the slot"
    );
}

#[test]
fn an_app_fill_outranks_the_built_in_mark() {
    // `mark` is the item's default content; a named fill replaces it instead of drawing on
    // top of it, or the app's icon sits over the built-in one.
    // `mark` 是条目的默认内容；命名填充替换它而不是叠在它上面，
    // 否则应用的图标会压在内建图标上。
    let mut store = AnimStore::new();
    let item = ListItemParams::new(ROW, "Label")
        .leading(ListLeading::Icon)
        .mark(dot)
        .slot(ListItemSlot::Leading, dot(Id::str("app-mark"), Color::WHITE, 24.0));
    let (_, decl) = build(&mut store, Routing::default(), item, Md3Options::default());
    let slot = find(&decl, list_slot(ROW, ListItemSlot::Leading)).expect("the slot node");
    assert!(find(slot, Id::str("app-mark")).is_some(), "the fill is what the slot shows");
    assert!(
        find(slot, list_slot(ROW, ListItemSlot::Leading).with("mark")).is_none(),
        "the built-in mark must not be drawn beside an app fill"
    );
}

#[test]
fn an_unfilled_leading_slot_leaves_no_gap_before_the_text() {
    // Slots are 0..n: an item with no leading content starts its text at the row inset,
    // not after a placeholder plus the slot gap.
    // 槽是 0..n：没有前置内容的条目，文字从行内衬处起排，
    // 而不是从一个占位符加上槽间隙之后。
    let (_, decl) = plain(ListLineCount::One);
    assert!(find(&decl, list_slot(ROW, ListItemSlot::Leading)).is_none());
    let root = Decl::container(Id::str("root"), NodeKind::Row).child(decl);
    let tree = lay_out(&root, (400.0, 400.0));
    let (x, _, _, _) = region_rect(&tree, ROW);
    let (tx, _, _, _) = region_rect(&tree, ROW.with("text"));
    let inset = base_spec(false, ListLines::OneLine).root.leading_space;
    assert!((tx - x - inset).abs() < 0.01, "text at {tx}, row at {x}, inset {inset}");
}

#[test]
fn slots_lay_out_around_the_text_column_when_filled_backwards() {
    // The app may fill the trailing slot first, but the item's layout is its own: leading
    // before the text column, trailing after it. Fill order must move neither.
    // 应用可以先填后置槽，但条目的布局归它自己：前置在文字列之前，后置在其后。
    // 填充顺序不得挪动任何一方。
    let mut store = AnimStore::new();
    let item = ListItemParams::new(ROW, "Label")
        .leading(ListLeading::Icon)
        .slot(ListItemSlot::Trailing, dot(Id::str("trail-fill"), Color::WHITE, 8.0))
        .slot(ListItemSlot::Leading, dot(Id::str("lead-fill"), Color::WHITE, 24.0));
    let (_, decl) = build(&mut store, Routing::default(), item, Md3Options::default());
    let root = Decl::container(Id::str("root"), NodeKind::Row).child(decl);
    let tree = lay_out(&root, (400.0, 400.0));
    let (lx, _, lw, _) = region_rect(&tree, list_slot(ROW, ListItemSlot::Leading));
    let (tx, _, _, _) = region_rect(&tree, ROW.with("text"));
    let (rx, _, _, _) = region_rect(&tree, list_slot(ROW, ListItemSlot::Trailing));
    assert!(lx + lw <= tx, "the leading slot must precede the text: {lx}+{lw} vs {tx}");
    assert!(tx <= rx, "the trailing slot must follow the text: {tx} vs {rx}");
}

#[test]
fn the_three_text_roles_take_their_exported_sizes() {
    // 16/24, 14/20 and 11/16 are three different roles; one size for all makes the overline
    // read as a second label.
    // 16/24、14/20、11/16 是三个不同角色；共用一个尺寸会让上标读成第二个标签。
    let mut store = AnimStore::new();
    let item = ListItemParams::new(ROW, "Label")
        .overline("Overline")
        .supporting("Supporting")
        .lines(ListLineCount::Three);
    let (_, decl) = build(&mut store, Routing::default(), item, Md3Options::default());
    let spec = base_spec(false, ListLines::ThreeLine);
    let text = ROW.with("text");
    for (id, size, colour) in [
        (text.with("overline"), spec.overline.size, spec.overline.color),
        (text.with("label"), spec.label_text.size, spec.label_text.color),
        (text.with("supporting"), spec.supporting_text.size, spec.supporting_text.color),
    ] {
        match &find(&decl, id).unwrap_or_else(|| panic!("missing {id:?}")).data {
            NodeData::Text { ink, block, .. } => {
                assert_eq!(block.runs[0].style.size, size, "{id:?}");
                assert_eq!(*ink, spec_ink(&crate::pack::pack(), colour, 1.0), "{id:?}");
            }
            _ => panic!("{id:?} is not text"),
        }
    }
}
