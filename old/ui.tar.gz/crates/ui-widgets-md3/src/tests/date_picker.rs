//! The MD3 date picker: the calendar's arithmetic, and the one action a frame reports.
//! MD3 日期选择器：日历的算术，以及一帧上报的那一个动作。

use super::*;

use crate::date_picker::{
    Date, DatePickerChange, DatePickerParams, DatePickerView, Md3DatePicker, Weekday,
    DATE_PICKER_WEEKS,
};
use ui_core::cx::Routing;
use ui_core::Change;
use ui_widgets::WidgetState;

const D: Id = Id::str("picker");

/// The day the fixtures call today; a Friday.
/// 夹具称作「今天」的那一天；星期五。
fn today() -> Date {
    Date::new(2026, 10, 30).expect("a real date")
}

fn build(routing: Routing, params: DatePickerParams) -> (Md3DatePicker, Decl) {
    let mut store = AnimStore::new();
    let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 480, 0.0, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let picker = Md3DatePicker::from_pack(&crate::pack::pack(), &mut cx, params);
    let decl = cx.with_cx(|cx| picker.decl(cx));
    (picker, decl)
}

fn plain(params: DatePickerParams) -> (Md3DatePicker, Decl) {
    build(Routing::default(), params)
}

/// The change a click on `hit` produces, through the path the engine would route.
/// 点击 `hit` 产生的变化，路径与引擎的路由一致。
fn clicked(params: DatePickerParams, hit: Id) -> Option<Change> {
    let routing = Routing {
        clicked_path: vec![D, hit],
        ..Routing::default()
    };
    let (picker, _) = build(routing, params);
    picker.change(&WidgetState::default(), ui_core::geom::Rect::ZERO)
}

/// The date a change names, if it names one.
/// 变化所指的日期，若它指了一个。
fn picked(change: Option<Change>) -> Option<Date> {
    match change?.data::<DatePickerChange>().ok()? {
        DatePickerChange::Picked(date) => Some(date),
        _ => None,
    }
}

fn shown(change: Option<Change>) -> Option<(Date, DatePickerView)> {
    match change?.data::<DatePickerChange>().ok()? {
        DatePickerChange::Shown { date, view } => Some((date, view)),
        _ => None,
    }
}

#[test]
fn debug_rows() {
    let (_, decl) = plain(DatePickerParams::new(D, today()));
    let tree = lay_out(&decl, (360.0, 456.0));
    for name in ["header", "month-row", "body", "weekdays", "grid"] {
        let id = D.with(name);
        if let Some(nid) = tree.find_by_id(id)
            && let Some(n) = tree.get(nid) {
                eprintln!("{name}: {:?}", n.rect);
            }
    }
    for r in 0..6usize {
        let id = Id::of((&D, "week", r));
        if let Some(nid) = tree.find_by_id(id)
            && let Some(n) = tree.get(nid) {
                eprintln!("week {r}: {:?}", n.rect);
            }
    }
}

#[test]
fn february_follows_the_gregorian_leap_rule() {
    // The four-year rule alone is wrong for century years, which is the one mistake every
    // hand-rolled calendar makes: 1900 and 2100 are not leap, 2000 is.
    // 只用四年一闰对整世纪年是错的，这是手写日历最常犯的一个错：1900 与 2100 不是闰年，
    // 2000 是。
    assert_eq!(Date::days_in_month(2024, 2), 29, "a leap year");
    assert_eq!(Date::days_in_month(2025, 2), 28, "a common year");
    assert_eq!(Date::days_in_month(2000, 2), 29, "a 400-year leap");
    assert_eq!(Date::days_in_month(1900, 2), 28, "a 100-year non-leap");
    assert_eq!(Date::days_in_month(2100, 2), 28, "another 100-year non-leap");
    assert!(Date::new(2023, 2, 29).is_none(), "no 29 February in 2023");
}

#[test]
fn a_date_lands_on_the_weekday_it_is_known_by() {
    // Four independent anchors, so an off-by-one in the epoch constant cannot pass.
    // 四个互相独立的锚点，使纪元常数差一无法蒙混过关。
    let cases = [
        (Date::new(1970, 1, 1).unwrap(), Weekday::Thu),
        (Date::new(2000, 1, 1).unwrap(), Weekday::Sat),
        (Date::new(2024, 2, 29).unwrap(), Weekday::Thu),
        (Date::new(2026, 10, 30).unwrap(), Weekday::Fri),
    ];
    for (date, want) in cases {
        assert_eq!(date.weekday(), want, "{date:?}");
    }
}

#[test]
fn the_grid_is_six_weeks_from_the_chosen_first_column() {
    // The surface keeps one height and the columns keep their weekday, so both facts have to
    // hold for a month that starts on any day and for either week start.
    // 表面只有一种高度、各列保持各自的星期，因此「月份从任意一天开始」与「一周从任一天起」
    // 两种情形下这两点都必须成立。
    for week_start in Weekday::ALL {
        for month in 1..=12u8 {
            for day in 1..=28u8 {
                let shown = Date::new(2026, month, day).unwrap();
                let mut params = DatePickerParams::new(D, today());
                params.shown = shown;
                params.week_start = week_start;
                let (picker, _) = plain(params);
                let grid = picker.grid();
                assert_eq!(grid.len(), DATE_PICKER_WEEKS * 7, "six weeks of seven");
                assert_eq!(
                    grid[0].0.weekday(),
                    week_start,
                    "the first cell is the week start, for {shown:?}"
                );
                let days = Date::days_in_month(shown.year, shown.month);
                let inside: Vec<u8> = grid.iter().filter(|(_, i)| *i).map(|(d, _)| d.day).collect();
                assert_eq!(inside, (1..=days).collect::<Vec<_>>(), "every day exactly once");
            }
        }
    }
}

#[test]
fn stepping_a_month_clamps_the_day_into_the_target() {
    // 31 January cannot become 31 February; the app must get a date that exists.
    // 1 月 31 日无法变成 2 月 31 日；应用必须拿到一个存在的日期。
    let jan31 = Date::new(2024, 1, 31).unwrap();
    assert_eq!(jan31.add_months(1), Date::new(2024, 2, 29).unwrap(), "a leap February");
    assert_eq!(
        Date::new(2023, 1, 31).unwrap().add_months(1),
        Date::new(2023, 2, 28).unwrap(),
        "a common February"
    );
    assert_eq!(
        Date::new(2026, 1, 15).unwrap().add_months(-1),
        Date::new(2025, 12, 15).unwrap(),
        "backwards over a year end"
    );
}

#[test]
fn a_clicked_day_reports_the_date_that_cell_stands_for() {
    // The cells are decls: their own `change()` never runs, so the picker has to name the day.
    // 格子是声明：它们自己的 `change()` 从不执行，因此由选择器指出是哪一天。
    let (picker, _) = plain(DatePickerParams::new(D, today()));
    let target = Date::new(2026, 10, 14).unwrap();
    let change = clicked(DatePickerParams::new(D, today()), picker.day_id(target));
    assert_eq!(picked(change), Some(target));
    assert!(
        clicked(DatePickerParams::new(D, today()), D.with("nowhere")).is_none(),
        "a click outside every cell reports nothing"
    );
}

#[test]
fn a_cell_outside_the_range_the_app_allows_reports_nothing() {
    // `min` is a promise: a cell before it must be inert, not merely dimmed.
    // `min` 是一个承诺：它之前的格子必须真的惰性，而不只是被调暗。
    let mut params = DatePickerParams::new(D, today());
    params.min = Some(Date::new(2026, 10, 10).unwrap());
    let (picker, _) = plain(DatePickerParams::new(D, today()));
    let early = Date::new(2026, 10, 3).unwrap();
    assert!(clicked(params, picker.day_id(early)).is_none(), "before the minimum");
}

#[test]
fn the_arrows_follow_the_view_and_choosing_a_month_returns_to_the_days() {
    // A step is a month on the day grid and a whole year block on the year grid; the month
    // grid spans every month of its year, so its arrows stand down. Picking a month must
    // land the app back on the days, or the choice has no visible effect.
    // 日期网格上一步是一个月，年份网格上是一整块；月份网格覆盖它那一年的所有月份，
    // 因此箭头停用。选中月份后必须回到日期网格，否则这次选择看不出效果。
    let base = DatePickerParams::new(D, today());
    let (picker, _) = plain(DatePickerParams::new(D, today()));
    let (date, view) = shown(clicked(base, picker.next_id())).expect("a step");
    assert_eq!(date, Date::new(2026, 11, 1).unwrap());
    assert_eq!(view, DatePickerView::Days, "the day grid stays");

    let mut months = DatePickerParams::new(D, today());
    months.view = DatePickerView::Months;
    assert!(
        clicked(months, picker.next_id()).is_none(),
        "the month grid has no step to take"
    );

    let mut years = DatePickerParams::new(D, today());
    years.view = DatePickerView::Years;
    let (date, view) = shown(clicked(years, picker.next_id())).expect("a block");
    assert_eq!(date, Date::new(2038, 10, 1).unwrap(), "twelve years, in the year grid");
    assert_eq!(view, DatePickerView::Years);

    let chosen = clicked(
        DatePickerParams::new(D, today()),
        picker.month_cell_id(3),
    );
    let (date, view) = shown(chosen).expect("a month");
    assert_eq!(date, Date::new(2026, 3, 1).unwrap());
    assert_eq!(view, DatePickerView::Days);
}

#[test]
fn a_menu_button_toggles_its_own_list() {
    // Each list has one opener and one closer: the button that raised it, so a second tap
    // takes the calendar back to the days. A year tap must not close the month list.
    // 每个列表只有一个开与关：就是举起它的那个按钮，再点一次即回到日期网格。
    // 点年份按钮不应关掉月份列表。
    let (picker, _) = plain(DatePickerParams::new(D, today()));
    let view_of = |view: DatePickerView, hit: Id| {
        let mut params = DatePickerParams::new(D, today());
        params.view = view;
        match clicked(params, hit)?.data::<DatePickerChange>().ok()? {
            DatePickerChange::View(view) => Some(view),
            _ => None,
        }
    };
    assert_eq!(
        view_of(DatePickerView::Days, picker.month_button_id()),
        Some(DatePickerView::Months),
        "the month button opens its list"
    );
    assert_eq!(
        view_of(DatePickerView::Months, picker.month_button_id()),
        Some(DatePickerView::Days),
        "and the same button closes it"
    );
    assert_eq!(
        view_of(DatePickerView::Years, picker.year_button_id()),
        Some(DatePickerView::Days),
        "the year button closes the year list"
    );
}

#[test]
fn the_surface_keeps_the_exported_size_in_every_view() {
    // A picker that resizes when the body changes makes the whole page jump; the export
    // fixes one box, so all three views must fill the same one.
    // 切换主体就改变尺寸的选择器会让整页跳动；导出固定了一个盒子，三种视图都必须填满它。
    for view in [DatePickerView::Days, DatePickerView::Months, DatePickerView::Years] {
        let mut params = DatePickerParams::new(D, today());
        params.view = view;
        let (_, decl) = plain(params);
        assert_eq!(decl.size_class.width, ui_core::layout::AxisSize::fixed(360.0), "{view:?}");
        assert_eq!(decl.size_class.height, ui_core::layout::AxisSize::fixed(456.0), "{view:?}");    }
}

fn find_decl(decl: &Decl, id: Id) -> Option<&Decl> {
    if decl.id == id {
        return Some(decl);
    }
    decl.children.iter().find_map(|c| find_decl(c, id))
}

#[test]
fn a_cell_that_paints_nothing_at_rest_is_still_a_keyboard_stop() {
    // The engine infers a Tab stop from ink, and an unselected day paints none: without the
    // flag, Tab and the arrows walk past every day on the calendar.
    // 引擎从墨迹推断 Tab 停靠点，而未选中的日期什么都不画：
    // 不挂这个标志，Tab 与方向键会越过日历上的每一个日期。
    let (_, days) = plain(DatePickerParams::new(D, today()));
    let day = find_decl(&days, crate::date_picker::day_cell_id(D, today())).expect("a day cell");
    assert!(
        day.data.params().is_some_and(|p| p.focus_stop),
        "a day cell is a stop of its own"
    );
    let mut params = DatePickerParams::new(D, today());
    params.view = DatePickerView::Months;
    let (_, months) = plain(params);
    let month = find_decl(&months, crate::date_picker::month_cell_id(D, 3)).expect("a month cell");
    assert!(
        month.data.params().is_some_and(|p| p.focus_stop),
        "a month cell is a stop of its own"
    );
}
