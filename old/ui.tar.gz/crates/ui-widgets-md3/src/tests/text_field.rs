//! MD3 text fields: the label's float rule and the band an outlined field reserves.
//! MD3 文本字段：标签的浮起规则，以及描边式预留的标签带。

use super::*;

use crate::text_field::{Md3TextField, TextFieldParams, TextFieldVariant, TEXT_FIELD_HEIGHT};
use ui_core::cx::Routing;
use ui_core::NodeData;

const FIELD: Id = Id::str("field");
const WIDTH: f32 = 200.0;

fn build(params: TextFieldParams<'_>) -> (Md3TextField, Decl) {
    let mut store = AnimStore::new();
    let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 400, 0.0, 0.0, 1.0, None);
    core.route(Routing::default());
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let widget =
        Md3TextField::new_with(Md3Options::default(), params, &mut cx, &crate::pack::pack());
    let decl = cx.with_cx(|cx| widget.decl(cx));
    (widget, decl)
}

fn find(decl: &Decl, id: Id) -> &Decl {
    fn walk(decl: &Decl, id: Id) -> Option<&Decl> {
        if decl.id == id {
            return Some(decl);
        }
        decl.children.iter().find_map(|c| walk(c, id))
    }
    walk(decl, id).unwrap_or_else(|| panic!("no node {id:?}"))
}

fn label_size(decl: &Decl) -> f32 {
    match &find(decl, FIELD.with("label-text")).data {
        NodeData::Text { block, .. } => block.runs[0].style.size,
        other => panic!("the label is not text: {other:?}"),
    }
}

fn label_top(decl: &Decl) -> f32 {
    find(decl, FIELD.with("label-layer")).box_model.padding.top
}

#[test]
fn the_label_floats_once_the_field_holds_text_even_without_focus() {
    // Flutter floats the label for focus *or* content; content alone must be enough.
    // Flutter 在聚焦或已有内容时都让标签浮起；只有内容也必须足够。
    let (_, empty) = build(TextFieldParams::new(FIELD, TextFieldVariant::Outlined, WIDTH).label("L"));
    let (_, typed) = build(
        TextFieldParams::new(FIELD, TextFieldVariant::Outlined, WIDTH)
            .label("L")
            .text("x"),
    );
    assert_eq!(label_size(&empty), 16.0, "an empty field keeps the label at body size");
    assert_eq!(label_size(&typed), 12.0, "content floats the label to the populated size");
    assert!(
        label_top(&typed) < label_top(&empty),
        "the floated label sits above the resting one: {} vs {}",
        label_top(&typed),
        label_top(&empty)
    );
}

/// The same build, with a measurer so the widget can size its label before layout.
/// 同一次构建，但接入了测量器，控件因此能在布局前量出标签尺寸。
fn build_measured(params: TextFieldParams<'_>) -> (Md3TextField, Decl) {
    let mut store = AnimStore::new();
    let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 400, 0.0, 0.0, 1.0, None);
    core.route(Routing::default());
    core.attach_measure(std::rc::Rc::new(std::cell::RefCell::new(
        ui_core::MonospaceMeasure::default(),
    )));
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let widget =
        Md3TextField::new_with(Md3Options::default(), params, &mut cx, &crate::pack::pack());
    let decl = cx.with_cx(|cx| widget.decl(cx));
    (widget, decl)
}

/// Everything the field declares as shapes, root included.
/// 该字段声明的全部形状，根节点起算。
fn shapes(decl: &Decl) -> Vec<&ui_core::draw::Shape> {
    fn walk<'a>(decl: &'a Decl, out: &mut Vec<&'a ui_core::draw::Shape>) {
        out.extend(decl.shapes.iter());
        for child in &decl.children {
            walk(child, out);
        }
    }
    let mut out = Vec::new();
    walk(decl, &mut out);
    out
}

/// The gap the outline cuts for a floated label reading `label`, and the label's size.
/// 浮起标签 `label` 在描边上切出的缺口，以及标签字号。
fn outline_gap(label: &str) -> (Option<(f32, f32)>, f32) {
    let (_, decl) = build_measured(
        TextFieldParams::new(FIELD, TextFieldVariant::Outlined, WIDTH)
            .label(label)
            .text("x"),
    );
    let size = label_size(&decl);
    let gap = shapes(&decl)
        .into_iter()
        .find_map(|s| match s {
            ui_core::draw::Shape::Outline { gap, .. } => Some(*gap),
            _ => None,
        })
        .expect("an outlined field draws its border as a cuttable outline");
    (gap, size)
}

#[test]
fn an_outlined_label_cuts_a_gap_that_tracks_its_own_text_width() {
    // The label carries no background, so the border itself must be interrupted around it:
    // a fixed gap either clips the text or draws a line through it.
    // 标签没有底色，因此描边必须绕着它中断：固定宽度要么裁掉文字，要么从字间穿过。
    let advance = ui_core::MonospaceMeasure::default().advance;
    let (short, size) = outline_gap("L");
    let (long, _) = outline_gap("LLL");
    let (from, to) = short.expect("a floated outlined label cuts a gap");
    let (_, long_to) = long.expect("a floated outlined label cuts a gap");
    assert_eq!(
        to - from,
        advance * size + 2.0 * crate::text_field::LABEL_PAD,
        "the gap is the text plus padding on both sides"
    );
    let wider = long_to - to - advance * size * 2.0;
    assert!(
        wider.abs() < 1e-3,
        "two more characters widen the gap by exactly their advance, off by {wider}"
    );
    assert_eq!(from, crate::TEXT_FIELD_PAD - crate::text_field::LABEL_PAD);
}

#[test]
fn a_filled_field_has_no_outline_to_cut() {
    // Its border is the indicator line; drawing an outline there would add a frame.
    // 它的描边就是指示线；在那里画一圈描边等于凭空加个边框。
    let (_, decl) = build_measured(
        TextFieldParams::new(FIELD, TextFieldVariant::Filled, WIDTH)
            .label("L")
            .text("x"),
    );
    let outlines = shapes(&decl)
        .into_iter()
        .filter(|s| matches!(s, ui_core::draw::Shape::Outline { .. }))
        .count();
    assert_eq!(outlines, 0);
}

#[test]
fn an_outlined_field_sits_below_its_label_band_while_a_filled_one_does_not() {
    // The band is what keeps the outlined label's upper half from being clipped by the mask.
    // 这条带让描边式标签的上半部分不被遮罩裁掉。
    for (variant, band) in [
        (TextFieldVariant::Filled, 0.0),
        (TextFieldVariant::Outlined, crate::TEXT_FIELD_BAND),
    ] {
        let (_, decl) = build(TextFieldParams::new(FIELD, variant, WIDTH));
        let tree = laid_out(decl);
        let (x, y, w, h) = region_rect(&tree, FIELD);
        assert_eq!(
            (x, y, w, h),
            (0.0, band, WIDTH, TEXT_FIELD_HEIGHT),
            "{variant:?} field box"
        );
    }
}

/// The laid-out rect of the node with `id`.
/// 该 `id` 节点在布局后的矩形。
fn rect_of(tree: &Tree, id: Id) -> ui_core::geom::Rect {
    tree.get(tree.find_by_id(id).unwrap_or_else(|| panic!("no node {id:?}")))
        .expect("node")
        .rect
}

fn centre_y(rect: ui_core::geom::Rect) -> f32 {
    rect.origin.y + rect.size.h * 0.5
}

#[test]
fn the_resting_label_and_the_input_share_the_fields_vertical_centre() {
    // The line's height comes from the typeface; the engine centres both boxes, so the label
    // and the input stay on one axis in both variants without a widget-side constant.
    // 行高来自字面；引擎居中两个盒子，因此两种变体下标签与输入同轴，无需控件常量。
    for variant in [TextFieldVariant::Filled, TextFieldVariant::Outlined] {
        // Empty and unfocused: the label rests on the input's line instead of floating.
        // 空且未聚焦：标签停在输入行上，而不是浮起。
        let (_, decl) = build(TextFieldParams::new(FIELD, variant, WIDTH).label("L"));
        let tree = laid_out(decl);
        let field = centre_y(rect_of(&tree, FIELD));
        let input = centre_y(rect_of(&tree, FIELD.with("input")));
        let label = centre_y(rect_of(&tree, FIELD.with("label-text")));
        assert!(
            (input - field).abs() < 0.01,
            "{variant:?}: the input line must centre on the field, got {input} vs {field}"
        );
        assert!(
            (label - input).abs() < 0.01,
            "{variant:?}: the resting label must share the input's axis, got {label} vs {input}"
        );
    }
}

#[test]
fn a_floated_label_and_the_input_are_centred_as_one_block() {
    // Filled floats the label above the line and centres the pair; centring the line alone
    // would leave the label hanging out of the top by half a label line.
    // 填充式把标签浮到行上方并居中这一对；只居中行会让标签从顶部探出半个标签行。
    let (_, decl) = build_measured(
        TextFieldParams::new(FIELD, TextFieldVariant::Filled, WIDTH)
            .label("L")
            .text("x"),
    );
    let tree = laid_out(decl);
    let field = rect_of(&tree, FIELD);
    let input = rect_of(&tree, FIELD.with("input"));
    let label = rect_of(&tree, FIELD.with("label-text"));
    let above = label.origin.y - field.origin.y;
    let below = (field.origin.y + field.size.h) - (input.origin.y + input.size.h);
    assert!(
        (above - below).abs() < 0.01,
        "the block must sit on the field's centre, got {above} above and {below} below"
    );
    assert!(
        label.origin.y + label.size.h <= input.origin.y + 0.01,
        "the floated label sits above the line, not over it"
    );
}

/// Lay out a filled field holding `text`, with the caret at `caret_x` in the input's space.
/// 布局一个装着 `text` 的填充式字段，插入符位于输入节点坐标系中的 `caret_x`。
fn routed(text: &str, caret_x: Option<f32>) -> Tree {
    let mut store = AnimStore::new();
    let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 400, 0.0, 0.0, 1.0, None);
    core.route(Routing {
        caret_in_text: caret_x.map(|x| (FIELD.with("input"), x)),
        ..Routing::default()
    });
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let widget = Md3TextField::new_with(
        Md3Options::default(),
        TextFieldParams::new(FIELD, TextFieldVariant::Filled, WIDTH).text(text),
        &mut cx,
        &crate::pack::pack(),
    );
    laid_out(cx.with_cx(|cx| widget.decl(cx)))
}

/// The width the input may occupy: the content box minus its side padding.
/// 输入节点可占的宽度：内容盒减去左右内衬。
fn content_w(tree: &Tree) -> f32 {
    let content = tree
        .get(tree.find_by_id(FIELD.with("content")).expect("content"))
        .expect("node");
    let pad = content.box_model.padding;
    content.rect.size.w - pad.left - pad.right
}

fn input_offset(tree: &Tree) -> f32 {
    let node = tree
        .get(tree.find_by_id(FIELD.with("input")).expect("input"))
        .expect("node");
    node.offset.x
}

#[test]
fn a_single_line_field_scrolls_exactly_far_enough_to_show_the_caret() {
    // A single-line editor never wraps; it slides the line under its mask, and only once the
    // caret has actually left the visible width.
    // 单行编辑器从不换行：它在遮罩下平移文本，且只在插入符真的离开可见宽度之后才平移。
    let text = "a buffer long enough that the field cannot show all of it at once";
    let tree = routed(text, None);
    let node = tree
        .get(tree.find_by_id(FIELD.with("input")).expect("input"))
        .expect("node");
    assert!(
        matches!(node.data, NodeData::Text { nowrap: true, .. }),
        "the input draws on one line"
    );
    let visible = content_w(&tree);

    let inside = routed(text, Some(visible * 0.5));
    assert_eq!(input_offset(&inside), 0.0, "a caret inside the width scrolls nothing");

    let past = routed(text, Some(visible + 40.0));
    let scrolled = -input_offset(&past);
    assert!(
        (40.0..=44.0).contains(&scrolled),
        "scrolled past the caret by the caret's own width and its slack, got {scrolled}"
    );
}
