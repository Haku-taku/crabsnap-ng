//! The MD3 connected button group: one pill, shared edges, presses still reaching members.
//! MD3 连通按钮组：一颗胶囊、共用边缘，按下仍然落到成员上。

use super::*;

use crate::spec::ButtonGroupConnectedSize;
use ui_core::cx::Routing;
use ui_core::geom::Corners;

const GROUP: Id = Id::str("group");

fn member(k: usize) -> ButtonParams {
    ButtonParams::new(GROUP.with(("m", k)), format!("M{k}"))
}

fn build(store: &mut AnimStore, routing: Routing, count: usize, size: ButtonGroupConnectedSize) -> Decl {
    let mut core = ui_core::cx::Cx::new(store, 0, 600, 200, 0.0, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let members = (0..count).map(member).collect();
    let control = Md3ButtonGroup::new_with(
        Md3Options::default(),
        ButtonGroupParams::new(GROUP, members).size(size),
        &mut cx,
        &crate::pack::pack(),
    );
    cx.with_cx(|cx| control.decl(cx))
}

/// The corners each member paints, in order.
/// 每个成员绘制的圆角，按顺序。
fn member_corners(decl: &Decl) -> Vec<Corners> {
    decl
        .children
        .iter()
        .map(|m| match m.shapes.first() {
            Some(ui_core::draw::Shape::Box { corners, .. }) => *corners,
            other => panic!("member paints no box, got {other:?}"),
        })
        .collect()
}

#[test]
fn only_the_groups_ends_are_round_and_the_inner_sides_take_corner_size() {
    // The contract of a connected group: neighbours share a square edge, so a member's
    // rounding must depend on its place — never on its own label.
    // 连通分组的契约：相邻者共用一条方边，因此成员的圆角必须取决于它的位置，绝不该取决于自己的标签。
    let mut store = AnimStore::new();
    let decl = build(&mut store, Routing::default(), 3, ButtonGroupConnectedSize::Medium);
    let corners = member_corners(&decl);
    let outer = 56.0 * 0.5;
    assert_eq!((corners[0].tl, corners[0].bl), (outer, outer));
    assert_eq!((corners[0].tr, corners[0].br), (8.0, 8.0), "a middle side is not round");
    assert!(
        corners[1].tl == 8.0 && corners[1].tr == 8.0,
        "the middle member is square on both sides, got {:?}",
        corners[1]
    );
    assert_eq!((corners[2].tr, corners[2].br), (outer, outer));
    assert_eq!((corners[2].tl, corners[2].bl), (8.0, 8.0));
}

#[test]
fn a_lone_member_is_a_plain_pill_not_a_group_with_one_inner_side() {
    // A group of one must look exactly like the button it wraps, or "group" would change
    // what a single button means.
    // 只有一个个成员的分组必须与它包裹的按钮一模一样，否则「分组」会改变单个按钮的含义。
    let mut store = AnimStore::new();
    let decl = build(&mut store, Routing::default(), 1, ButtonGroupConnectedSize::Medium);
    let only = &member_corners(&decl)[0];
    let outer = 56.0 * 0.5;
    assert_eq!((only.tl, only.tr, only.br, only.bl), (outer, outer, outer, outer));
}

#[test]
fn the_group_passes_its_presses_through_to_the_members() {
    // The group is a surface, not a target: if it ended the hit search no member could ever
    // be pressed, and a group whose buttons do nothing is worse than no group.
    // 分组是表面不是目标：若它终结命中查找，成员就永远按不到；按钮全无反应的分组比没有分组更糟。
    let mut store = AnimStore::new();
    let decl = build(&mut store, Routing::default(), 2, ButtonGroupConnectedSize::Medium);
    assert!(
        decl.sense.contains(ui_core::Sense::PASS_THROUGH),
        "the group must let the pointer through"
    );
    assert_eq!(decl.children.len(), 2);
}
