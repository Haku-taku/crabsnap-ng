//! The MD3 badge: a 6dp dot, or a 16dp pill whose label uses the exported type.
//! MD3 徽标：6dp 圆点，或 16dp 胶囊，标签用导出的字阶。

use super::*;

use crate::spec::badge_spec;
use ui_core::{NodeData, Weight};

fn badge_decl(label: Option<&str>) -> Decl {
    let style = Md3Kit::new();
    ui_widgets::Cx::for_test_mut(|cx| {
        let control = style.badge(Id::str("b"), label, cx);
        cx.with_cx(|inner| control.decl(inner))
    })
}

/// Lay a badge out in a row: the row's cross axis is height, so the pill keeps its own width
/// instead of being stretched by a column's default cross alignment.
/// 把徽标放进行里布局：行的交叉轴是高度，胶囊因此保持自身宽度，不被列的默认交叉对齐撑满。
fn badge_size(label: Option<&str>) -> (f32, f32) {
    let decl = badge_decl(label);
    let root = Decl::container(Id::str("root"), NodeKind::Row).child(decl);
    let tree = lay_out(&root, (200.0, 100.0));
    let (_, _, w, h) = region_rect(&tree, Id::str("b"));
    (w, h)
}

#[test]
fn the_dot_is_the_exported_small_size_in_the_error_role() {
    // A dot is only its two tokens: swapping the small and large size would paint a 16dp blob.
    // 圆点只有两个令牌：大小尺寸写反就会画成 16dp 的团。
    let spec = badge_spec(false);
    assert_eq!(badge_size(None), (spec.root.size, spec.root.size));
    let decl = badge_decl(None);
    assert_eq!(box_fill(&decl), role(&crate::pack::pack(), spec.root.color));
}

#[test]
fn the_pill_is_the_large_height_and_no_narrower_than_it() {
    // `minWidth: largeSize`: a one-character badge is a circle, not a sliver.
    // `minWidth: largeSize`：单字符徽标是个圆，不是细条。
    let spec = badge_spec(true);
    let (w, h) = badge_size(Some("3"));
    assert_eq!(h, spec.root.size);
    assert!(w >= spec.root.size, "a one-character pill is {w} wide, under {}", spec.root.size);
    let (wide, _) = badge_size(Some("12"));
    assert!(wide > w, "two digits must widen the pill ({wide} vs {w})");
}

#[test]
fn the_label_takes_the_exported_ink_and_type_size() {
    // The pill's own colour is `error`; the label on it is `onError`. Painting both the same
    // leaves an unreadable badge, which is exactly what a wrong token role looks like.
    // 胶囊底色是 `error`，其上的标签是 `onError`。两者画成同色就得到不可读的徽标——
    // 令牌角色写错正是这个样子。
    let spec = badge_spec(true);
    let decl = badge_decl(Some("9+"));
    let text = decl.children.first().expect("the pill carries its label");
    let NodeData::Text { ink, block, .. } = &text.data else {
        panic!("the label must be a text node");
    };
    assert_eq!(*ink, role(&crate::pack::pack(), spec.label_text.color));
    assert_eq!(block.runs[0].style.size, spec.label_text.size);
    assert_eq!(block.runs[0].style.weight, Weight(spec.label_text.weight as u16));
}
