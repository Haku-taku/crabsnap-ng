//! The MD3 switch: the reference's size trajectory, four-branch palette, release rule.
//! MD3 开关：参考的尺寸轨迹、四分支配色与松手判定。

use super::*;

use crate::toggle::{
    icon_color, size_at, thumb_center_x, thumb_left, track_inner_length, ICON_BAR, ICON_SIZE,
    PAD, THUMB_ACTIVE, THUMB_INACTIVE, THUMB_PRESSED, TRACK,
};
use ui_core::cx::Routing;
use ui_core::geom::Point;
use ui_core::{Change, Easing};

const ID: Id = Id::str("t");

/// Build one toggle in `store` at `now`, with the given routing and params.
/// 在 `store` 的 `now` 处按给定路由与参数构建一个开关。
fn build(
    store: &mut AnimStore,
    routing: Routing,
    now: f64,
    on: bool,
    params: Md3Options,
) -> (Box<dyn Widget>, Decl, ui_widgets::WidgetState) {
    let mut core = ui_core::cx::Cx::new(store, 0, 400, 200, now, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let spec = ui_style::ToggleSpec::new(ID, on, "");
    let control = Md3Kit::with_scope(ui_style::StyleScope::default(), params).toggle(&spec, &mut cx);
    let state = cx.state(ID);
    let decl = cx.with_cx(|cx| control.decl(cx));
    (control, decl, state)
}

fn near(a: Color, b: Color) -> bool {
    (a.r - b.r).abs() < 1e-4
        && (a.g - b.g).abs() < 1e-4
        && (a.b - b.b).abs() < 1e-4
        && (a.a - b.a).abs() < 1e-4
}

fn role(pack: &ui_style::Style, name: &'static str) -> Color {
    pack.ink(name).unwrap_or_else(|| panic!("the pack has no {name}"))
}

/// The colour the track's ring is painted with; transparent when the ring is not drawn.
/// 轨道环绘制用的颜色；未绘制时为透明。
fn ring_colour(decl: &Decl) -> Color {
    match track_shape(decl) {
        ui_core::draw::Shape::Rect { border, .. } => {
            border.as_ref().map(|(c, _)| *c).unwrap_or(Color::TRANSPARENT)
        }
        _ => unreachable!("the track is a rect"),
    }
}

#[test]
fn the_size_trajectory_uses_the_reference_keyframes_on_both_legs() {
    // Flutter's `TweenSequence` weights are 11/72/17 forward and 17/72/11 reverse, so the
    // pill sits at 11% going on and at 89% going off.
    // Flutter 的 `TweenSequence` 权重正向是 11/72/17、反向是 17/72/11，因此胶囊在开启方向
    // 的 11% 处、关闭方向的 89% 处。
    let (off, on) = (THUMB_INACTIVE, THUMB_ACTIVE);
    for (forward, p, want) in [
        (true, 0.0, (16.0, 16.0)),
        (true, 0.11, (34.0, 22.0)),
        (true, 0.83, (24.0, 24.0)),
        (true, 1.0, (24.0, 24.0)),
        (false, 0.0, (16.0, 16.0)),
        (false, 0.17, (16.0, 16.0)),
        (false, 0.89, (34.0, 22.0)),
        (false, 1.0, (24.0, 24.0)),
    ] {
        let got = size_at(forward, p, off, on);
        assert!(
            (got.0 - want.0).abs() < 0.01 && (got.1 - want.1).abs() < 0.01,
            "forward={forward} p={p}: {got:?} vs {want:?}"
        );
    }
    // The reverse leg is the forward leg time-reversed with the ends swapped.
    // 反向腿是正向腿的时间反转，并把两端互换。
    for p in [0.25, 0.5, 0.75] {
        let rev = size_at(false, p, off, on);
        let fwd = size_at(true, 1.0 - p, on, off);
        assert!(
            (rev.0 - fwd.0).abs() < 0.01 && (rev.1 - fwd.1).abs() < 0.01,
            "p={p}: reverse {rev:?} vs mirrored forward {fwd:?}"
        );
    }

    // Mid-segment values pin the 11/72/17 weights themselves; the junctions above are
    // continuous under a small weight shift, so they alone cannot see it.
    // 段中取值才能钉住 11/72/17 的权重；上面的交界处在小幅权重变化下仍连续，单靠它看不出来。
    let out = Easing::Cubic(0.20, 0.0, 0.0, 1.0);
    let into = Easing::Cubic(0.31, 0.0, 0.56, 1.0);
    let first = into.apply(0.05 / 0.11);
    let want = (off + (34.0 - off) * first, off + (22.0 - off) * first);
    let got = size_at(true, 0.05, off, on);
    assert!(
        (got.0 - want.0).abs() < 0.005 && (got.1 - want.1).abs() < 0.005,
        "forward first segment: {got:?} vs {want:?}"
    );
    let forward_mid = out.apply((0.5 - 0.11) / 0.72);
    let want = (34.0 + (on - 34.0) * forward_mid, 22.0 + (on - 22.0) * forward_mid);
    let got = size_at(true, 0.5, off, on);
    assert!(
        (got.0 - want.0).abs() < 0.005 && (got.1 - want.1).abs() < 0.005,
        "forward mid: {got:?} vs {want:?}"
    );
    let reverse_mid = 1.0 - out.apply(1.0 - (0.5 - 0.17) / 0.72);
    let want = (off + (34.0 - off) * reverse_mid, off + (22.0 - off) * reverse_mid);
    let got = size_at(false, 0.5, off, on);
    assert!(
        (got.0 - want.0).abs() < 0.005 && (got.1 - want.1).abs() < 0.005,
        "reverse mid: {got:?} vs {want:?}"
    );
}

#[test]
fn the_thumb_centre_travels_between_the_track_end_caps() {
    // `trackInnerLength = trackWidth - trackHeight`: the centre goes 16 -> 36, not 8 -> 44.
    // `trackInnerLength = trackWidth - trackHeight`：中心从 16 走到 36，而不是 8 到 44。
    assert_eq!(track_inner_length(), 20.0);
    assert_eq!(thumb_center_x(0.0), TRACK.1 * 0.5);
    assert_eq!(thumb_center_x(1.0), TRACK.1 * 0.5 + 20.0);
    assert_eq!(thumb_left(thumb_center_x(0.0), THUMB_INACTIVE), 8.0);
    assert_eq!(thumb_left(thumb_center_x(1.0), THUMB_ACTIVE), 24.0);
}

#[test]
fn the_rest_and_hovered_palette_comes_from_the_token_table() {
    let pack = crate::pack::pack();
    let mut store = AnimStore::new();
    let (_, off, _) = build(&mut store, Routing::default(), 0.0, false, Md3Options::default());
    assert!(near(
        shape_fill(track_shape(&off)),
        role(&pack, "surfaceContainerHighest")
    ));
    assert!(near(shape_fill(thumb_shape(&off)), role(&pack, "outline")));
    // The unselected ring is `outline`; the selected one is transparent at the same 2dp.
    // 未选中的环是 `outline`；选中态的环在同样 2dp 下是透明的。
    assert!(near(ring_colour(&off), role(&pack, "outline")));

    let mut store = AnimStore::new();
    let (_, on, _) = build(&mut store, Routing::default(), 0.0, true, Md3Options::default());
    assert!(near(shape_fill(track_shape(&on)), role(&pack, "primary")));
    assert!(near(shape_fill(thumb_shape(&on)), role(&pack, "onPrimary")));
    assert_eq!(ring_colour(&on).a, 0.0, "the selected track paints no ring");

    // Hovering changes the handle, not the track: `onSurfaceVariant` / `primaryContainer`.
    // 悬停改变滑块而不是轨道：`onSurfaceVariant` / `primaryContainer`。
    let hovered = |on: bool| {
        let mut store = AnimStore::new();
        let routing = Routing {
            hovered: Some(ID),
            hovered_path: vec![ID],
            ..Routing::default()
        };
        build(&mut store, routing, 0.0, on, Md3Options::default()).1
    };
    assert!(near(
        shape_fill(thumb_shape(&hovered(false))),
        role(&pack, "onSurfaceVariant")
    ));
    assert!(near(
        shape_fill(thumb_shape(&hovered(true))),
        role(&pack, "primaryContainer")
    ));
}

/// Routing with the pointer held down on the switch.
/// 指针按在开关上的路由。
fn pressed() -> Routing {
    Routing {
        pressed: Some(ID),
        pressed_path: vec![ID],
        ..Routing::default()
    }
}

/// Drive the real retarget path from `from_on` to `to_on` and read the tree at `now`.
/// 走真实重定向路径从 `from_on` 到 `to_on`，在 `now` 处读取树。
fn travel(from_on: bool, to_on: bool, now: f64) -> Decl {
    let mut store = AnimStore::new();
    let params = Md3Options::default();
    build(&mut store, Routing::default(), 0.0, from_on, params);
    build(&mut store, Routing::default(), 0.0, to_on, params);
    build(&mut store, Routing::default(), now, to_on, params).1
}

#[test]
fn the_thumb_colour_follows_the_four_reference_branches() {
    // Flutter picks the two endpoint colours by press/forward/reverse/settled:
    // pressed -> both ends pressed; forward -> off pressed; reverse -> on pressed; settled -> rest.
    // Flutter 按按压/正向/反向/落定挑选两端颜色：按压 → 两端按压；正向 → 关闭端按压；
    // 反向 → 开启端按压；落定 → 静息。
    let pack = crate::pack::pack();
    let curve = Easing::Cubic(0.0, 0.0, 0.58, 1.0);
    let t = curve.apply(0.5);
    let blend = |a: Color, b: Color| a.lerp(b, t);

    // Half-way through a forward leg: the off end stays pressed.
    let forward = travel(false, true, 0.15);
    assert!(near(
        shape_fill(thumb_shape(&forward)),
        blend(role(&pack, "onSurfaceVariant"), role(&pack, "onPrimary"))
    ));

    // Half-way through a reverse leg: the on end stays pressed.
    let reverse = travel(true, false, 0.15);
    assert!(near(
        shape_fill(thumb_shape(&reverse)),
        blend(role(&pack, "outline"), role(&pack, "primaryContainer"))
    ));

    // A live press: both ends are pressed.
    let pressed = |on: bool| {
        let mut store = AnimStore::new();
        let routing = Routing {
            pressed: Some(ID),
            pressed_path: vec![ID],
            ..Routing::default()
        };
        build(&mut store, routing, 0.0, on, Md3Options::default()).1
    };
    assert!(near(
        shape_fill(thumb_shape(&pressed(false))),
        role(&pack, "onSurfaceVariant")
    ));
    assert!(near(
        shape_fill(thumb_shape(&pressed(true))),
        role(&pack, "primaryContainer")
    ));

    // Settled: the plain state colours.
    let rest = |on: bool| {
        let mut store = AnimStore::new();
        build(&mut store, Routing::default(), 0.0, on, Md3Options::default()).1
    };
    assert!(near(shape_fill(thumb_shape(&rest(false))), role(&pack, "outline")));
    assert!(near(shape_fill(thumb_shape(&rest(true))), role(&pack, "onPrimary")));
}

#[test]
fn the_disabled_thumb_is_alpha_blended_over_the_surface() {
    // `Color.alphaBlend(thumbColor, surfaceColor)` turns the 38% handle opaque; the track
    // keeps its 12% alpha.
    // `Color.alphaBlend(thumbColor, surfaceColor)` 让 38% 的滑块变成不透明；轨道保留 12% alpha。
    let pack = crate::pack::pack();
    let surface = role(&pack, "surface");
    let on_surface = role(&pack, "onSurface");
    let params = Md3Options { disabled: true, ..Default::default() };

    let mut store = AnimStore::new();
    let (_, off, _) = build(&mut store, Routing::default(), 0.0, false, params);
    let thumb = shape_fill(thumb_shape(&off));
    assert!(near(thumb, surface.lerp(on_surface, 0.38)), "blended over surface: {thumb:?}");
    assert_eq!(thumb.a, 1.0, "the blend must be opaque");
    assert!((shape_fill(track_shape(&off)).a - 0.12).abs() < 1e-4, "track keeps 12%");

    let mut store = AnimStore::new();
    let (_, on, _) = build(&mut store, Routing::default(), 0.0, true, params);
    assert!(near(shape_fill(thumb_shape(&on)), surface), "the selected handle is surface");
}

#[test]
fn a_release_decides_by_the_dragged_position_against_the_current_value() {
    // `position.value >= 0.5 != widget.value`: a drag to 0.6 turns an off switch on, and a
    // drag to 0.4 leaves it off; starting on, the same positions mirror.
    // `position.value >= 0.5 != widget.value`：拖到 0.6 会把关闭的开关打开，拖到 0.4 保持关闭；
    // 从开启出发时同样的位置镜像。
    let params = Md3Options::default();
    for (start, dx, want) in [
        (false, 12.0, Some(true)),
        (false, 8.0, None),
        (true, -12.0, Some(false)),
        (true, -8.0, None),
    ] {
        let mut store = AnimStore::new();
        build(&mut store, Routing::default(), 0.0, start, params);
        build(
            &mut store,
            Routing {
                drag_owner: Some(ID),
                drag_step: Some(Point::new(dx, 0.0)),
                ..Routing::default()
            },
            0.0,
            start,
            params,
        );
        let (control, _, state) = build(
            &mut store,
            Routing {
                dropped_path: vec![ID],
                ..Routing::default()
            },
            0.0,
            start,
            params,
        );
        let got = match control.change(&state, ui_core::geom::Rect::ZERO) {
            Some(Change::Toggled { on }) => on,
            None => None,
            other => panic!("unexpected change {other:?}"),
        };
        assert_eq!(got, want, "start={start} dx={dx}");
    }
}

#[test]
fn the_thumb_stays_inside_the_track_through_both_legs() {
    // The pill is 34 wide on a 20-wide travel; the curve must keep it inside. A flipped
    // reverse curve makes the thumb overshoot the on end while still a pill.
    // 胶囊宽 34、行程只有 20，曲线必须把它留在轨道内。反向曲线若取翻转形式，滑块会在
    // 还是胶囊时越过开启端。
    for start in [false, true] {
        let mut store = AnimStore::new();
        build(&mut store, Routing::default(), 0.0, start, Md3Options::default());
        build(&mut store, Routing::default(), 0.0, !start, Md3Options::default());
        for frame in 0..=20 {
            let now = frame as f64 * 0.015;
            let (_, decl, _) = build(&mut store, Routing::default(), now, !start, Md3Options::default());
            let r = shape_rect(thumb_shape(&decl));
            let left = r.origin.x - PAD.0;
            let top = r.origin.y - PAD.1;
            let over = (-left)
                .max(left + r.size.w - TRACK.0)
                .max(-top)
                .max(top + r.size.h - TRACK.1);
            assert!(
                over < 0.01,
                "start={start} t={now:.3}: the thumb leaves the track by {over:.2}px"
            );
        }
    }
}

#[test]
fn a_release_shrinks_the_thumb_instead_of_snapping_back() {
    // The pressed handle is 28; letting go walks it back to 24 over the 100ms retract. Holding
    // it at 28 and dropping it in one frame reads as "no response, then a jump".
    // 按压滑块是 28；松手要在 100ms 的回缩里走回 24。停在 28 再一帧掉下来，
    // 看起来就是「先没反应、然后跳变」。
    let mut store = AnimStore::new();
    build(&mut store, Routing::default(), 0.0, true, Md3Options::default());
    let mut last = 24.0;
    let mut saw_between = false;
    for frame in 0..=30 {
        let now = frame as f64 * 0.016;
        let routing = if now <= 0.2 { pressed() } else { Routing::default() };
        let (_, decl, _) = build(&mut store, routing, now, true, Md3Options::default());
        let w = shape_rect(thumb_shape(&decl)).size.w;
        if now > 0.2 {
            assert!((w - last).abs() < 1.5, "t={now:.3}: {last:.2} -> {w:.2}");
            saw_between |= w > 24.0 && w < 28.0;
        }
        last = w;
    }
    assert!(saw_between, "the retract must pass through the intermediate sizes");
    assert!((last - 24.0).abs() < 0.01, "the thumb ends at rest size, got {last}");
}

#[test]
fn a_press_grows_the_resting_thumb_instead_of_snapping_to_pressed() {
    // Every rest size (16 plain-off, 24 plain-on or with-icon) must walk to 28 over the 100ms
    // reaction. Jumping on the first frame reads as "the press did not register, then snapped".
    // 每种静息尺寸（16 普通关、24 普通开或带图标）都要在 100ms 的按压动画里走到 28；
    // 首帧直接跳过去，看起来就是「按下没反应，然后跳变」。
    let plain = Md3Options {
        has_icon: false,
        ..Md3Options::default()
    };
    for (params, on, rest) in [
        (plain, false, THUMB_INACTIVE),
        (plain, true, THUMB_ACTIVE),
        (Md3Options::default(), false, THUMB_WITH_ICON),
    ] {
        let mut store = AnimStore::new();
        let (_, decl, _) = build(&mut store, Routing::default(), 0.0, on, params);
        assert_eq!(
            shape_rect(thumb_shape(&decl)).size.w,
            rest,
            "on={on} icon={}: the test's rest size is wrong",
            params.has_icon
        );
        let mut last = rest;
        let mut saw_between = false;
        // `fastOutSlowIn` peaks at ~2.3x the average rate, so one 16ms frame may move ~37% of
        // the travel; a snap would move all of it.
        // `fastOutSlowIn` 的峰值约为平均速率的 2.3 倍，故一帧最多走约 37% 的行程；跳变则走完全程。
        let bound = (THUMB_PRESSED - rest) * 0.45;
        for frame in 0..=20 {
            let now = frame as f64 * 0.016;
            let (_, decl, _) = build(&mut store, pressed(), now, on, params);
            let w = shape_rect(thumb_shape(&decl)).size.w;
            assert!(
                (w - last).abs() < bound,
                "on={on} icon={}: t={now:.3} went {last:.2} -> {w:.2} in one frame",
                params.has_icon
            );
            saw_between |= w > rest + 0.5 && w < THUMB_PRESSED - 0.5;
            last = w;
        }
        assert!(
            saw_between,
            "on={on} icon={}: the press must pass through intermediate sizes",
            params.has_icon
        );
        assert!(
            (last - THUMB_PRESSED).abs() < 0.01,
            "on={on} icon={}: the thumb ends at the pressed size, got {last}",
            params.has_icon
        );
    }
}

#[test]
fn a_press_mid_flight_leaves_the_far_end_untouched() {
    // `easeOutBack` overshoots past 1 while the controller is still at ~0.9; the far endpoint
    // must key on the raw controller, or a press mid-toggle inflates it.
    // `easeOutBack` 在控制器还只有约 0.9 时就越过 1；远端必须按原始控制器判断，
    // 否则过渡中按下会把远端也撑大。
    let mut store = AnimStore::new();
    build(&mut store, Routing::default(), 0.0, false, Md3Options::default());
    build(&mut store, Routing::default(), 0.0, true, Md3Options::default());
    let mut width = |routing: Routing, now: f64| {
        let (_, decl, _) = build(&mut store, routing, now, true, Md3Options::default());
        shape_rect(thumb_shape(&decl)).size.w
    };
    // 0.27s in, the raw controller is at 0.9: the last segment holds the far end at rest size.
    // 0.27s 时原始控制器在 0.9：最后一段保持远端为静息尺寸。
    assert!((width(Routing::default(), 0.27) - 24.0).abs() < 0.01);
    assert!(
        (width(pressed(), 0.27) - 24.0).abs() < 0.01,
        "a press must not resize the far end"
    );
    assert!((width(pressed(), 0.28) - 24.0).abs() < 0.01);
}

#[test]
fn a_drag_release_keeps_the_thumb_continuous_until_the_app_flips() {
    // The release frame still carries the old `on`, so the size table must follow the drag's
    // travel, not the semantic target; otherwise the thumb jumps a frame later.
    // 松手帧仍带着旧的 `on`，故尺寸表必须跟随拖拽的行进方向，而不是语义目标；否则下一帧会跳。
    let params = Md3Options::default();
    let mut store = AnimStore::new();
    build(&mut store, Routing::default(), 0.0, false, params);
    build(
        &mut store,
        Routing {
            drag_owner: Some(ID),
            drag_step: Some(Point::new(12.0, 0.0)),
            ..Routing::default()
        },
        0.0,
        false,
        params,
    );
    let (_, release, _) = build(
        &mut store,
        Routing {
            dropped_path: vec![ID],
            ..Routing::default()
        },
        0.0,
        false,
        params,
    );
    let at_release = shape_rect(thumb_shape(&release)).size.w;
    // The app flips on the next frame; the position is still 0.6 and the endpoints frozen.
    let (_, after, _) = build(&mut store, Routing::default(), 0.0, true, params);
    let next = shape_rect(thumb_shape(&after)).size.w;
    assert!(
        (at_release - next).abs() < 1.0,
        "the thumb jumped across the release: {at_release:.2} -> {next:.2}"
    );
}

#[test]
fn a_disabled_switch_reports_no_change_and_paints_no_reaction() {
    let mut store = AnimStore::new();
    let (control, decl, state) = build(
        &mut store,
        Routing {
            pressed: Some(ID),
            pressed_path: vec![ID],
            hovered: Some(ID),
            hovered_path: vec![ID],
            disabled: vec![ID],
            ..Routing::default()
        },
        0.0,
        false,
        Md3Options::default(),
    );
    assert!(state.disabled);
    assert!(control.change(&state, ui_core::geom::Rect::ZERO).is_none());
    assert!(reaction_index(&decl).is_none(), "a disabled switch paints no splash");
}

#[test]
fn only_keyboard_focus_paints_the_ring() {
    // `onShowFocusHighlight` is keyboard-only: pointer focus must leave no halo.
    // `onShowFocusHighlight` 只认键盘：指针焦点不得留下光晕。
    let ring = |focus_visible: bool| {
        let mut store = AnimStore::new();
        let routing = Routing {
            focused: Some(ID),
            focus_visible,
            ..Routing::default()
        };
        let (_, decl, _) = build(&mut store, routing, 0.0, false, Md3Options::default());
        focus_ring_shape(&decl).is_some()
    };
    assert!(ring(true), "keyboard focus paints the ring");
    assert!(!ring(false), "pointer focus paints no ring");
}

#[test]
fn the_icon_parameter_decides_the_glyph_and_the_larger_handle() {
    // With an icon both states use a 24 handle; without one the off handle is 16.
    // 带图标时两态都用 24 滑块；不带时关闭态是 16。
    let mut store = AnimStore::new();
    let (_, icon_off, _) = build(&mut store, Routing::default(), 0.0, false, Md3Options::default());
    assert_eq!(shape_rect(thumb_shape(&icon_off)).size.w, 24.0);
    assert!(glyph_bar_count(&icon_off) > 0);

    let mut store = AnimStore::new();
    let (_, plain_off, _) = build(
        &mut store,
        Routing::default(),
        0.0,
        false,
        Md3Options { has_icon: false, ..Default::default() },
    );
    assert_eq!(shape_rect(thumb_shape(&plain_off)).size.w, 16.0);
    assert_eq!(glyph_bar_count(&plain_off), 0);

    // The off glyph is a cross, the on glyph a check: compare them in the thumb's own space.
    // 关闭字形是叉、开启字形是勾：在滑块自身空间里比较。
    let mut store = AnimStore::new();
    let (_, icon_on, _) = build(&mut store, Routing::default(), 0.0, true, Md3Options::default());
    let bars = |decl: &Decl| {
        let thumb = shape_rect(thumb_shape(decl));
        let gx = thumb.origin.x + (thumb.size.w - ICON_SIZE) * 0.5;
        let gy = thumb.origin.y + (thumb.size.h - ICON_SIZE) * 0.5;
        decl.shapes
            .iter()
            .filter_map(|s| match s {
                ui_core::draw::Shape::Rect { rect, .. }
                    if rect.size.w <= ICON_BAR + 0.01 && rect.size.h <= ICON_BAR + 0.01 =>
                {
                    Some((
                        (rect.origin.x - gx) as i32,
                        (rect.origin.y - gy) as i32,
                    ))
                }
                _ => None,
            })
            .collect::<Vec<_>>()
    };
    assert_ne!(bars(&icon_off), bars(&icon_on), "cross and check must differ");
    // The glyph colour is the token's icon colour at each end.
    let pack = crate::pack::pack();
    let icon_fill = |decl: &Decl| {
        decl.shapes
            .iter()
            .find_map(|s| match s {
                ui_core::draw::Shape::Rect { rect, fill, .. }
                    if rect.size.w <= ICON_BAR + 0.01 && rect.size.h <= ICON_BAR + 0.01 =>
                {
                    Some(*fill)
                }
                _ => None,
            })
            .expect("a bar")
    };
    assert!(near(icon_fill(&icon_off), icon_color(&pack, false, false)));
    assert!(near(icon_fill(&icon_on), icon_color(&pack, true, false)));
}
