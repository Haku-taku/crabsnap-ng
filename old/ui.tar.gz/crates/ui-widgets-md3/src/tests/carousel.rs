//! The MD3 carousel: the sizes each layout asks for, where its pages end, and the slot that
//! reports a press.
//! MD3 轮播：各布局要求的尺寸、它的页止于何处，以及上报按下的槽位。

use super::*;

use crate::carousel::{
    carousel_centre_of, carousel_content, carousel_cycle, carousel_looped_start,
    carousel_max_scroll, carousel_page, carousel_slots, carousel_slots_looped, CarouselItem,
    CarouselKind, CarouselParams, Md3Carousel, CAROUSEL_GAP, CAROUSEL_PAD, CAROUSEL_SMALL,
};
use ui_core::cx::Routing;
use ui_core::draw::Shape;
use ui_core::geom::Color;
use ui_core::Change;
use ui_widgets::WidgetState;

const STRIP: Id = Id::str("strip");
const WIDTH: f32 = 360.0;
const HEIGHT: f32 = 200.0;
const LARGE: f32 = 280.0;

/// The three layouts that resize their items as the strip scrolls.
/// 三个会随条带滚动改变条目尺寸的布局。
const WEIGHTED: [(CarouselKind, usize); 3] = [
    (CarouselKind::MultiBrowse, 6),
    (CarouselKind::Hero, 4),
    (CarouselKind::HeroCentered, 4),
];

fn usable_of(kind: CarouselKind) -> f32 {
    if kind.vertical() {
        HEIGHT
    } else if kind.shrinking() {
        WIDTH - 2.0 * CAROUSEL_PAD
    } else {
        WIDTH
    }
}

fn slots(kind: CarouselKind, count: usize, scroll: f32) -> Vec<crate::carousel::CarouselSlot> {
    carousel_slots(kind, usable_of(kind), count, scroll, LARGE)
}

fn extents(kind: CarouselKind, count: usize, scroll: f32) -> Vec<f32> {
    slots(kind, count, scroll).into_iter().map(|slot| slot.extent).collect()
}

fn indices(kind: CarouselKind, count: usize, scroll: f32) -> Vec<usize> {
    slots(kind, count, scroll).into_iter().map(|slot| slot.index).collect()
}

/// A plain filled box standing in for a real image.
/// 一个纯色盒子，代替真实的图片。
fn swatch(id: Id) -> Decl {
    Decl::container(id, NodeKind::Box)
        .size(SizeClass::fixed(40.0, 40.0))
        .shapes(vec![Shape::Box {
            corners: ui_core::Corners::ZERO,
            fill: Color::TRANSPARENT,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }])
}

fn build(store: &mut AnimStore, routing: Routing, kind: CarouselKind, count: usize) -> (Md3Carousel, Decl) {
    let mut core = ui_core::cx::Cx::new(store, 0, WIDTH as u32, HEIGHT as u32, 0.0, 0.0, 1.0, None);
    core.route(routing);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let items: Vec<CarouselItem> = (0..count)
        .map(|k| CarouselItem::new(STRIP.with(("item", k)), vec![swatch(STRIP.with(("art", k)))]))
        .collect();
    let content = CarouselParams {
        id: STRIP,
        kind,
        items: &items,
        width: WIDTH,
        height: HEIGHT,
        large: LARGE,
        infinite: false,
    };
    let strip = Md3Carousel::new_with(Md3Options::default(), content, &mut cx, &crate::pack::pack());
    let decl = cx.with_cx(|cx| strip.decl(cx));
    (strip, decl)
}

#[test]
fn every_layout_gives_its_leading_item_the_width_its_weights_ask_for() {
    // The export sizes gaps and the small range but no item; the ratios below are what
    // turn the container width into extents, so a change in the model shows up here.
    // 导出给了间距与小号范围却没给条目尺寸；下面的比例才是把容器宽度变成条目宽度的东西，
    // 模型一改就会在这里露出来。
    let browsed = extents(CarouselKind::MultiBrowse, 6, 0.0);
    assert_eq!(browsed, vec![156.0, 104.0, 52.0], "large, medium, small");
    assert_eq!(extents(CarouselKind::Hero, 3, 0.0), vec![280.0, 40.0]);
    // A centred strip expands its hero to the maximum weight at rest and leaves one small
    // item's width in front of it, which is what puts the hero in the middle of the page.
    // 居中的条带静止时把大条目撑到最大权重，并在它之前留下一件小条目的宽度，
    // 大条目因此落在页面中央。
    let centred = slots(CarouselKind::HeroCentered, 3, 0.0);
    assert_eq!(centred.len(), 2, "the hero and the small item behind it");
    let small = centred[1].extent;
    assert!(
        (centred[0].offset - CAROUSEL_GAP - small).abs() < 0.01,
        "the space before the hero mirrors the small item: {centred:?}"
    );
    assert!((centred[0].extent - 5.0 * small).abs() < 0.01, "the hero takes five weights");
    // MD3's small items never leave their 40–56 range at a compact width.
    // MD3 的小号条目在紧凑宽度下不会跑出 40–56 的范围。
    for small in [browsed[2], small, extents(CarouselKind::Hero, 3, 0.0)[1]] {
        assert!(
            small >= CAROUSEL_SMALL.0 && small <= CAROUSEL_SMALL.1,
            "small item {small} is outside {:?}",
            CAROUSEL_SMALL
        );
    }
}

#[test]
fn a_page_is_as_wide_as_the_widest_item_not_the_leading_slot() {
    // The focal role travels one widest item per page. A centred pattern leads with a small
    // slot; calling that slot a page rushes the whole strip past in a sixth of the room.
    // 焦点角色每页走一个最宽条目。居中花样以前缘的小槽位领先；
    // 把那个槽位当作一页，整条条带只用六分之一的路程就走到头。
    for (kind, count) in WEIGHTED {
        let usable = usable_of(kind);
        let widest = extents(kind, count, 0.0)
            .into_iter()
            .fold(0.0_f32, f32::max);
        assert_eq!(carousel_page(kind, usable, count), widest, "{kind:?}");
    }
}

#[test]
fn a_page_of_scroll_hands_the_leading_item_to_the_next_one() {
    // One page is exactly one item: at every page boundary the widest slot is the item
    // the page number names, or the turnover would jump or stall.
    // 一页正好是一件：在每个页边界上最宽的槽位就是页号所指的那件，否则换位会跳或卡住。
    for (kind, count) in WEIGHTED {
        let page = carousel_page(kind, usable_of(kind), count);
        for i in 0..3 {
            let at = slots(kind, count, page * i as f32);
            let widest = at
                .iter()
                .max_by(|a, b| a.extent.total_cmp(&b.extent))
                .expect("a page shows at least one item");
            assert_eq!(widest.index, i, "{kind:?} page {i} leads with {:?}", widest.index);
        }
    }
    // Half a page: the leading item is half gone and the next has grown by the same amount.
    // 半页：前缘条目缩掉一半，下一件正好长回同样的量。
    let page = carousel_page(CarouselKind::MultiBrowse, usable_of(CarouselKind::MultiBrowse), 6);
    assert_eq!(page, 156.0);
    assert_eq!(indices(CarouselKind::MultiBrowse, 6, page), vec![1, 2, 3]);
    assert_eq!(extents(CarouselKind::MultiBrowse, 6, page), extents(CarouselKind::MultiBrowse, 6, 0.0));
    // Mid-transition the three slots add up to less than the viewport, so the item after
    // them slides in from a sliver instead of appearing at full width. The leading slot is
    // half gone and its whole 8dp pad comes out of that half, so its card is 74 not 78.
    // 过渡中三个槽位加起来不到视口，其后那一件因此从一条窄边滑入，而不是整宽出现。
    // 前缘槽位已收掉一半，整条 8dp 间距都从这一半里出，卡片因此是 74 而不是 78。
    assert_eq!(
        extents(CarouselKind::MultiBrowse, 6, page * 0.5),
        vec![74.0, 130.0, 78.0, 22.0]
    );
}

#[test]
fn the_pad_behind_the_leading_item_stays_whole_while_it_leaves() {
    // The leading card's pad is what separates it from the next item, so it may not shrink
    // with the card; the slot carries the pad and gives it up only once the card is gone.
    // 前缘卡片的间距是它与下一件之间的分界，不能随卡片一起缩；槽位带着间距，
    // 只在卡片消失之后才交出它。
    let kind = CarouselKind::MultiBrowse;
    let page = carousel_page(kind, usable_of(kind), 6);
    for at in [0.0, page * 0.5, page * 0.9] {
        let row = slots(kind, 6, at);
        assert_eq!(
            row[1].offset - (row[0].offset + row[0].extent),
            CAROUSEL_GAP,
            "the pad at scroll {at} is {}",
            row[1].offset - (row[0].offset + row[0].extent)
        );
    }
    // At the turn the card is gone and the successor already leads, so nothing moves.
    // 翻页那一刻卡片已消失、接替者已经领先，因此没有任何东西在动。
    let almost = slots(kind, 6, page - 0.001);
    assert!(
        almost[0].offset < 0.05,
        "the successor must already lead, got {}",
        almost[0].offset
    );
    assert_eq!(almost[0].index, slots(kind, 6, page)[0].index);
}

#[test]
fn the_last_page_ends_flush_with_the_trailing_edge() {
    // The goal the offsets have to serve: the furthest scroll puts the last item's trailing
    // edge exactly on the viewport's, so the strip never rests with a blank right side.
    // 偏移必须服务的目标：滚到最远时最后一件的尾缘正好落在视口后缘，
    // 条带因此从不停在右侧留白的位置。
    let cases = WEIGHTED.into_iter().chain([(CarouselKind::Uncontained, 5)]);
    for (kind, count) in cases {
        let usable = usable_of(kind);
        let at = slots(kind, count, carousel_max_scroll(kind, usable, count, LARGE));
        let last = at.iter().max_by(|a, b| a.offset.total_cmp(&b.offset)).expect("something");
        assert_eq!(last.index, count - 1, "{kind:?} ends on the last item");
        assert!(
            (last.offset + last.extent - usable).abs() < 0.01,
            "{kind:?} ends at {} of {usable}",
            last.offset + last.extent
        );
    }
}

#[test]
fn a_leading_anchored_strip_ends_on_its_widest_item() {
    // Flush alone would still leave the last item a sliver: the pattern has to turn around
    // so the item the strip ends on is as wide as the one it started on.
    // 只贴齐还不够——最后一件仍可能是一条窄边：花样必须掉头，
    // 条带收尾的那一件才和开头那件一样宽。
    for (kind, count) in [(CarouselKind::MultiBrowse, 6), (CarouselKind::Hero, 4)] {
        let usable = usable_of(kind);
        let first = slots(kind, count, 0.0)[0].extent;
        let at = slots(kind, count, carousel_max_scroll(kind, usable, count, LARGE));
        let last = at.iter().max_by(|a, b| a.offset.total_cmp(&b.offset)).expect("something");
        assert!(
            (last.extent - first).abs() < 0.01,
            "{kind:?} ends on {} but starts on {first}",
            last.extent
        );
        // And the page it ends on is still exactly full, so nothing is cut off.
        // 它收尾的那一页也仍然正好占满，没有任何东西被裁掉。
        let span = at.iter().map(|s| s.extent).sum::<f32>() + CAROUSEL_GAP * (at.len() - 1) as f32;
        assert!((span - usable).abs() < 0.01, "{kind:?} fills {span} of {usable}");
    }
}

#[test]
fn a_weighted_canvas_is_the_viewport_plus_the_furthest_scroll() {
    // The engine clamps against the canvas's extent, so the canvas has to end where the
    // last page does; otherwise the scroller would stop short or scroll past the end.
    // 引擎按画布范围钳位，因此画布必须止于最后一页；否则滚动容器会早停或滚过头。
    for (kind, count) in WEIGHTED {
        let usable = usable_of(kind);
        let content = carousel_content(kind, usable, count, LARGE);
        let max = carousel_max_scroll(kind, usable, count, LARGE);
        assert!((content - usable - max).abs() < 0.01, "{kind:?}: {content} vs {}", usable + max);
    }
}

#[test]
fn an_uncontained_item_keeps_its_width_while_the_strip_scrolls() {
    // That is the whole point of the layout: items do not resize, they slide.
    // 这正是该布局的全部意义：条目不变形，只平移。
    assert_eq!(extents(CarouselKind::Uncontained, 4, 0.0), vec![280.0; 4]);
    assert_eq!(extents(CarouselKind::Uncontained, 4, 500.0), vec![280.0; 4]);
    // The scroll has an end: the last item's trailing edge, plus the leading gutter.
    // 滚动有尽头：最后一件的尾缘，再加上前缘的边距。
    assert_eq!(
        carousel_max_scroll(CarouselKind::Uncontained, WIDTH, 4, LARGE),
        16.0 + 4.0 * 280.0 + 24.0 - 360.0
    );
}

#[test]
fn the_strip_starts_after_the_gutter_and_the_first_item_is_drawn_there() {
    // MD3's 16dp gutter is part of the layout, not decoration: the leading item starts at
    // 16 whether or not it is the widest one.
    // MD3 的 16dp 边距属于布局而非装饰：无论前缘条目是不是最宽的，它都从 16 开始。
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Routing::default(), CarouselKind::MultiBrowse, 4);
    let tree = lay_out(&decl, (WIDTH, HEIGHT));
    let (x, y, _, h) = region_rect(&tree, STRIP.with(("item", 0usize)));
    assert_eq!((x, y), (16.0, 8.0));
    assert_eq!(h, HEIGHT - 16.0);
}

#[test]
fn a_full_screen_item_fills_the_strip_in_both_axes() {
    // Full-screen is edge-to-edge: no gutter, and one item covers the whole viewport.
    // 全屏贴边：没有边距，一件条目覆盖整个视口。
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Routing::default(), CarouselKind::FullScreen, 3);
    let tree = lay_out(&decl, (WIDTH, HEIGHT));
    let (x, y, w, h) = region_rect(&tree, STRIP.with(("item", 0usize)));
    assert_eq!((x, y, w, h), (0.0, 0.0, WIDTH, HEIGHT));
}

#[test]
fn a_pressed_item_hands_its_own_id_to_the_app() {
    // Items are decls, so their own `change()` never runs; the strip must name the one
    // that was pressed or the app cannot tell one item from another.
    // 条目是声明，自己的 `change()` 从不执行；条带必须指出被按下的是哪一件，
    // 否则应用分不清条目。
    let hit = STRIP.with(("item", 2usize));
    let routing = Routing {
        clicked_path: vec![STRIP, STRIP.with("strip"), hit],
        ..Routing::default()
    };
    let mut store = AnimStore::new();
    let (carousel, _) = build(&mut store, routing, CarouselKind::MultiBrowse, 4);
    let change = carousel.change(&WidgetState::default(), ui_core::geom::Rect::ZERO);
    assert!(
        matches!(change, Some(Change::Selected(Some(id))) if id == hit),
        "the strip reported {change:?}"
    );

    let mut store = AnimStore::new();
    let (quiet, _) = build(&mut store, Routing::default(), CarouselKind::MultiBrowse, 4);
    assert!(quiet.change(&WidgetState::default(), ui_core::geom::Rect::ZERO).is_none());
}


#[test]
fn a_centred_strip_turns_so_its_hero_ends_the_strip() {
    // The same goal as the leading-anchored turn, reached by rotating the pattern: the item
    // the strip stops on is the hero, and it ends flush with the trailing edge.
    // 与锚前缘的掉头同一目标，只是靠花样转一圈实现：条带停在的那一件是英雄，
    // 并且贴着后缘收尾。
    let kind = CarouselKind::HeroCentered;
    let usable = usable_of(kind);
    let count = 4;
    let hero = slots(kind, count, 0.0)[0].extent;
    let at = slots(kind, count, carousel_max_scroll(kind, usable, count, LARGE));
    let last = at.iter().max_by(|a, b| a.offset.total_cmp(&b.offset)).expect("something");
    assert_eq!(last.index, count - 1, "the strip ends on {last:?}");
    assert!((last.extent - hero).abs() < 0.01, "ends on {} but the hero is {hero}", last.extent);
    assert!(
        (last.offset + last.extent - usable).abs() < 0.01,
        "not flush: {} of {usable}",
        last.offset + last.extent
    );
}

#[test]
fn every_item_takes_its_turn_as_the_widest_one() {
    // A page hands the widest slot to the next item, so each one must reach it before the
    // strip ends: an item that stalls at medium never got its turn.
    // 一页把最宽的槽位交给下一件，因此每件在条带收尾前都必须轮到过：
    // 停在中等宽度的条目就是没轮到。
    for (kind, count) in WEIGHTED {
        let usable = usable_of(kind);
        for index in 0..count {
            let at = crate::carousel::carousel_offset_of(kind, usable, count, index, LARGE);
            let row = slots(kind, count, at);
            let widest = row
                .iter()
                .max_by(|a, b| a.extent.total_cmp(&b.extent))
                .expect("a page shows at least one item");
            assert_eq!(widest.index, index, "{kind:?} item {index} is not widest at {at}: {row:?}");
        }
    }
}

#[test]
fn a_looped_strip_draws_the_same_strip_a_whole_pass_along() {
    // The widget re-seeds the offset by whole passes to keep it on the canvas, so one pass
    // along has to draw exactly the same strip: anything else would be a visible jump.
    // 控件按整遍重设偏移，好让它留在画布上；因此整遍之后必须画出同一条条带，
    // 否则就是一次看得见的跳变。
    for (kind, count) in [(CarouselKind::MultiBrowse, 6), (CarouselKind::Uncontained, 5)] {
        let usable = usable_of(kind);
        let cycle = carousel_cycle(kind, usable, count, LARGE);
        for at in [cycle, cycle * 3.0 + 17.0] {
            let here = carousel_slots_looped(kind, usable, count, at, LARGE);
            let along = carousel_slots_looped(kind, usable, count, at + cycle, LARGE);
            assert_eq!(here.len(), along.len(), "{kind:?} at {at}");
            for (a, b) in here.iter().zip(&along) {
                assert_eq!(a.index, b.index, "{kind:?} at {at}: {a:?} vs {b:?}");
                assert!((a.offset - b.offset).abs() < 0.01, "{kind:?} at {at}: {a:?} vs {b:?}");
                assert!((a.extent - b.extent).abs() < 0.01, "{kind:?} at {at}: {a:?} vs {b:?}");
            }
        }
    }
}

#[test]
fn a_looped_strip_carries_the_items_past_the_last_one() {
    // No item may fall off the canvas: past the count the strip shows the first item again.
    // 任何一件都不能从画布上掉下去：越过条目总数后，条带又露出第一件。
    let kind = CarouselKind::MultiBrowse;
    let count = 6;
    let usable = usable_of(kind);
    let cycle = carousel_cycle(kind, usable, count, LARGE);
    let row = carousel_slots_looped(kind, usable, count, cycle - carousel_page(kind, usable, count) * 0.5, LARGE);
    let indices: Vec<usize> = row.iter().map(|slot| slot.index).collect();
    assert!(indices.contains(&0), "the first item is missing from {indices:?}");
    assert!(indices.iter().any(|index| *index >= count - 2), "the tail is missing from {indices:?}");
}

#[test]
fn a_press_brings_its_item_as_near_the_middle_as_the_strip_gets() {
    // The strip answers where the item sits, not where the press landed: an item it can
    // centre lands with its own middle on the viewport's, and the two ends hold the rest.
    // 条带按条目所在的位置回答，而不是按按下的落点：能居中的条目都让自己的正中落在视口正中，
    // 条带两端则把其余的拦住。
    for (kind, count) in WEIGHTED {
        let usable = usable_of(kind);
        let max = carousel_max_scroll(kind, usable, count, LARGE);
        let half = usable / 2.0;
        for index in 0..count {
            let at = carousel_centre_of(kind, usable, count, index, 0.0, LARGE, false);
            assert!((0.0..=max).contains(&at), "{kind:?} item {index}: {at} outside 0..={max}");
            let row = slots(kind, count, at);
            let me = row
                .iter()
                .find(|slot| slot.index == index)
                .unwrap_or_else(|| panic!("{kind:?} item {index} is off the strip at {at}"));
            assert!(
                me.offset < usable && me.offset + me.extent > 0.0,
                "{kind:?} item {index} is cut off at {at}: {me:?}"
            );
            let middle = me.offset + me.extent / 2.0;
            if at > 0.0 && at < max {
                assert!(
                    (middle - half).abs() < 0.5,
                    "{kind:?} item {index} sits at {middle} of {half}"
                );
            }
        }
    }
}

#[test]
fn a_looped_press_lands_on_the_copy_nearest_the_scroll() {
    // Every pass draws the same view, so the answer is a copy of it; taking the one nearest
    // the current offset is what keeps the travel short.
    // 每一遍画出同一幅画面，答案因此是它的一个副本；取离当前偏移最近的那一份，行程才短。
    for (kind, count) in WEIGHTED {
        let usable = usable_of(kind);
        let cycle = carousel_cycle(kind, usable, count, LARGE);
        let near = carousel_looped_start(kind, usable, count, LARGE) + cycle * 0.3;
        for index in 0..count {
            let at = carousel_centre_of(kind, usable, count, index, near, LARGE, true);
            assert!(
                (at - near).abs() <= cycle / 2.0 + 0.5,
                "{kind:?} item {index}: {at} is {} from {near}",
                (at - near).abs()
            );
            let row = carousel_slots_looped(kind, usable, count, at, LARGE);
            assert!(row.iter().any(|slot| slot.index == index), "{kind:?} item {index} not shown at {at}");
        }
    }
}

#[test]
fn a_pressed_item_asks_the_engine_to_ease_the_strip_along_its_own_axis() {
    // The move is the engine's to animate, and it has to travel the strip's own axis: a jump
    // would land the item off-centre, and the other axis would not move it at all.
    // 移动交给引擎缓动，而且必须走条带自己的轴：瞬移会让条目到达时偏出正中，
    // 走错轴则根本不会移动。
    for (kind, vertical) in [(CarouselKind::MultiBrowse, false), (CarouselKind::FullScreen, true)] {
        let hit = STRIP.with(("item", 2usize));
        let routing = Routing {
            clicked_path: vec![STRIP, STRIP.with("strip"), hit],
            ..Routing::default()
        };
        let mut store = AnimStore::new();
        let mut core =
            ui_core::cx::Cx::new(&mut store, 0, WIDTH as u32, HEIGHT as u32, 0.0, 0.0, 1.0, None);
        core.route(routing);
        let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
        let items: Vec<CarouselItem> = (0..4usize)
            .map(|k| CarouselItem::new(STRIP.with(("item", k)), vec![swatch(STRIP.with(("art", k)))]))
            .collect();
        let content = CarouselParams {
            id: STRIP,
            kind,
            items: &items,
            width: WIDTH,
            height: HEIGHT,
            large: LARGE,
            infinite: false,
        };
        let strip = Md3Carousel::new_with(Md3Options::default(), content, &mut cx, &crate::pack::pack());
        let _ = cx.with_cx(|cx| strip.decl(cx));
        let wanted = strip.centre_scroll(2, 0.0);
        let requests = cx.core().take_scroll_requests();
        let asked = requests
            .iter()
            .find(|req| req.id == STRIP.with("strip") && req.animate)
            .unwrap_or_else(|| panic!("{kind:?} asked for {requests:?}, wanted {wanted}"));
        let (along, across) =
            if vertical { (asked.y, asked.x) } else { (asked.x, asked.y) };
        assert!((along - wanted).abs() < 0.5, "{kind:?} asked for {along}, wanted {wanted}");
        assert_eq!(across, 0.0, "{kind:?} moved the other axis too: {asked:?}");
    }
}
