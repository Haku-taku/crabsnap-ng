//! The MD3 standard navigation drawer: the 360dp surface, the inset capsule, the headline
//! groups and the press that names a destination.
//! MD3 标准导航抽屉：360dp 表面、内缩胶囊、标题分组，以及指认目标的按下。

use super::*;

use crate::spec::navigation_drawer_spec;
use crate::{DrawerEntry, DrawerItem, DrawerParams, Md3NavDrawer};
use ui_core::cx::Routing;
use ui_core::draw::Shape;
use ui_core::geom::{Point, Rect};
use ui_core::{NodeData, Weight};

const DRAWER: Id = Id::str("drawer");
const HOME: Id = Id::str("home");
const SEARCH: Id = Id::str("search");

/// A 24dp mark in the destination's ink: the stand-in for a real glyph.
/// 24dp、按目标墨色绘制的标记：真实字形的替身。
fn dot(id: Id, ink: Color) -> Decl {
    Decl::container(id, NodeKind::Box)
        .size(SizeClass::fixed(24.0, 24.0))
        .shapes(vec![Shape::Box {
            corners: ui_core::Corners::ZERO,
            fill: ink,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }])
}

fn build(store: &mut AnimStore, selected: Option<Id>) -> (Md3NavDrawer, Decl) {
    build_at(store, selected, 0.0)
}

fn build_at(store: &mut AnimStore, selected: Option<Id>, now: f64) -> (Md3NavDrawer, Decl) {
    let mut core = ui_core::cx::Cx::new(store, 0, 500, 500, now, 0.0, 1.0, None);
    core.route(Routing::default());
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let entries = vec![
        DrawerEntry::Headline("Mail"),
        DrawerEntry::Item(DrawerItem::new(HOME, "Home", ui_widgets::IconSource::Custom(dot))),
        DrawerEntry::Item(DrawerItem::new(SEARCH, "Search", ui_widgets::IconSource::Custom(dot))),
    ];
    let control = Md3NavDrawer::new_with(
        Md3Options::default(),
        DrawerParams { id: DRAWER, entries: &entries, selected, disabled: false },
        &mut cx,
        &crate::pack::pack(),
    );
    let decl = cx.with_cx(|cx| control.decl(cx));
    (control, decl)
}

fn laid(decl: Decl) -> Tree {
    let root = Decl::container(Id::str("root"), NodeKind::Column).child(decl);
    lay_out(&root, (500.0, 400.0))
}

fn find(decl: &Decl, id: Id) -> Option<&Decl> {
    if decl.id == id {
        return Some(decl);
    }
    decl.children.iter().find_map(|c| find(c, id))
}

fn capsule(decl: &Decl, id: Id) -> Option<(f32, f32, f32)> {
    find(decl, id).expect("the destination exists").shapes.iter().find_map(|s| match s {
        Shape::Rect { rect, corners, .. } => Some((rect.size.w, rect.size.h, corners.tl)),
        _ => None,
    })
}

#[test]
fn the_drawer_is_the_exported_width_and_its_capsules_are_inset() {
    // The export's 360dp is the drawer's whole width, and Flutter's `tilePadding` of 12dp
    // leaves a 336×56 capsule; a full-bleed row is a different control.
    // 导出的 360dp 是抽屉整宽，Flutter 的 `tilePadding` 12dp 留下 336×56 胶囊；
    // 整宽的行是另一个控件。
    let spec = navigation_drawer_spec(false, false, true, false, false, false);
    assert_eq!(spec.container.width, 360.0);
    let mut store = AnimStore::new();
    let (control, decl) = build(&mut store, Some(HOME));
    assert_eq!(control.width(), spec.container.width);
    let tree = laid(decl);
    let (_, _, w, _) = region_rect(&tree, DRAWER);
    assert!((w - spec.container.width).abs() < 1e-4, "the drawer is {w} wide");
    let (x, _, iw, ih) = region_rect(&tree, HOME);
    assert!((x - 12.0).abs() < 1e-4, "the capsule starts at {x}");
    assert!((iw - spec.active_indicator.width).abs() < 1e-4, "the capsule is {iw} wide");
    assert!((ih - spec.active_indicator.height).abs() < 1e-4, "the capsule is {ih} tall");
}

#[test]
fn an_outgoing_capsule_dissolves_with_its_width() {
    // Selection is a dissolve here too: a half-open capsule is also half transparent, or the
    // first frame is a hairline of solid colour.
    // 这里的选中同样是溶解：展开一半的胶囊也半透明，否则第一帧就是一条满色细线。
    let spec = navigation_drawer_spec(true, false, true, false, false, false);
    let mut store = AnimStore::new();
    let (_, _) = build_at(&mut store, Some(HOME), 0.0);
    // The frame that commits the new target is still at the old value; the next one moves.
    // 提交新目标的那一帧还停在旧值；下一帧才开始移动。
    let (_, _) = build_at(&mut store, Some(SEARCH), 0.0);
    let (_, decl) = build_at(&mut store, Some(SEARCH), 0.25);
    let capsule = find(&decl, HOME).expect("the destination exists");
    let Some(Shape::Rect { rect, fill, .. }) = capsule.shapes.first() else {
        panic!("the outgoing capsule is still drawn mid-transition");
    };
    assert!(
        rect.size.w > 0.0 && rect.size.w < spec.active_indicator.width,
        "width {} is mid-scale",
        rect.size.w
    );
    assert!(fill.a > 0.0 && fill.a < 1.0, "alpha {} is mid-dissolve", fill.a);
}

#[test]
fn a_destinations_ink_clips_to_its_own_capsule() {
    // The ripple belongs to the capsule, not the whole row: the capsule is the effective
    // background, so the splash stays inside its rounded corners.
    // 涟漪属于胶囊而不是整行：胶囊才是有效背景，水花因此留在它的圆角之内。
    let spec = navigation_drawer_spec(false, false, true, false, false, false);
    let want = ui_core::InkTarget::Rect {
        rect: Rect::new(0.0, 0.0, spec.active_indicator.width, spec.active_indicator.height),
        corners: ui_core::Corners::all(spec.active_indicator.height * 0.5),
    };
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Some(HOME));
    for id in [HOME, SEARCH] {
        let dest = find(&decl, id).expect("the destination exists");
        let ink = match &dest.data {
            NodeData::Container(p) => p.press_ink.expect("every destination declares press ink"),
            _ => panic!("the destination is a container"),
        };
        assert_eq!(ink.target, want, "{id:?} clips to its capsule slot");
    }
}

#[test]
fn a_selected_destination_paints_the_exported_container_and_bolds_its_label() {
    // Selection is the drawer's only per-row colour change: the capsule takes
    // `secondary-container` and the label goes to 700, exactly as the export's active state.
    // 选中是抽屉唯一的逐行颜色变化：胶囊取 `secondary-container`、标签变 700，
    // 与导出的 active 态一致。
    let spec = navigation_drawer_spec(true, false, true, false, false, false);
    let idle = navigation_drawer_spec(false, false, true, false, false, false);
    let pack = crate::pack::pack();
    let on = crate::toggle::spec_ink(&pack, spec.active_indicator.color, 1.0);
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Some(HOME));
    let (w, h, radius) = capsule(&decl, HOME).expect("the selected capsule is painted");
    assert!((w - spec.active_indicator.width).abs() < 1e-4, "the capsule is {w} wide");
    assert!((h - spec.active_indicator.height).abs() < 1e-4, "the capsule is {h} tall");
    assert_eq!(radius, 28.0, "a stadium, not a rounded box");
    let fill = find(&decl, HOME).unwrap().shapes.iter().find_map(|s| match s {
        Shape::Rect { fill, .. } => Some(*fill),
        _ => None,
    });
    assert_eq!(fill, Some(on), "in the exported indicator colour");
    // The slot is always first so `Shape(0)` names the capsule; an unselected one is zero wide.
    // 槽位永远在第一位，使 `Shape(0)` 指向胶囊；未选中的胶囊宽度为零。
    let idle_capsule = capsule(&decl, SEARCH).expect("the slot is always painted");
    assert_eq!(idle_capsule.0, 0.0, "an unselected destination paints no visible capsule");
    let weight = |id: Id| match &find(&decl, id.with("label")).expect("the label exists").data {
        NodeData::Text { block, .. } => block.runs[0].style.weight,
        _ => panic!("the label is a text node"),
    };
    assert_eq!(weight(HOME), Weight(spec.label_text.weight as u16));
    assert_eq!(weight(SEARCH), Weight(idle.label_text.weight as u16));
}

#[test]
fn a_headline_uses_the_exported_type_and_sits_above_its_group() {
    // The headline is the drawer's group label: `title-small` 14/500 in `on-surface-variant`,
    // and the group's first capsule starts below it rather than under the drawer's top edge.
    // 标题是抽屉的分组标签：`title-small` 14/500、`on-surface-variant`；
    // 该组的第一个胶囊从它下方开始，而不是贴着抽屉顶边。
    let spec = navigation_drawer_spec(false, false, true, false, false, false);
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, Some(HOME));
    let headline = DRAWER.with(("headline", 0usize));
    match &find(&decl, headline.with("text")).expect("the headline exists").data {
        NodeData::Text { block, ink, .. } => {
            assert_eq!(block.runs[0].style.size, spec.headline.size);
            assert_eq!(block.runs[0].style.weight, Weight(spec.headline.weight as u16));
            assert_eq!(*ink, crate::toggle::spec_ink(&crate::pack::pack(), spec.headline.color, 1.0));
        }
        _ => panic!("the headline is a text node"),
    }
    let tree = laid(decl);
    let (_, hy, _, hh) = region_rect(&tree, headline);
    let (_, ry, _, _) = region_rect(&tree, HOME);
    assert!((hy - 12.0).abs() < 1e-4, "the headline starts at {hy}");
    assert!((ry - (hy + hh)).abs() < 1e-4, "the first capsule starts at {ry}");
}

#[test]
fn a_press_names_the_destination_under_the_pointer_and_reselection_reports_nothing() {
    // The drawer walks its own rows, headlines included; a headline is not a destination, and
    // re-selecting the current one must not make the app re-render.
    // 抽屉按自己的行（含标题）映射按下点；标题不是目标，重选当前目标也不该让 app 白刷新。
    let mut store = AnimStore::new();
    let (control, _) = build(&mut store, Some(HOME));
    let bounds = Rect::new(0.0, 0.0, control.width(), 400.0);
    let press = |y: f32| ui_widgets::WidgetState {
        clicked: true,
        local: Some(Point::new(100.0, y)),
        ..Default::default()
    };
    match control.change(&press(120.0), bounds) {
        Some(ui_core::Change::Selected(Some(id))) => assert_eq!(id, SEARCH),
        other => panic!("expected Selected(search), got {other:?}"),
    }
    assert!(control.change(&press(60.0), bounds).is_none(), "the current destination");
    // Just above the second capsule: the bands must follow the layout's 12dp top inset.
    // 第二个胶囊上方一点：条带必须跟着布局的 12dp 顶内缩走。
    assert!(control.change(&press(110.0), bounds).is_none(), "still the first destination");
    assert!(control.change(&press(20.0), bounds).is_none(), "the headline is no destination");
    assert!(control.change(&press(300.0), bounds).is_none(), "below the last destination");
    let hover = ui_widgets::WidgetState { local: Some(Point::new(100.0, 120.0)), ..Default::default() };
    assert!(control.change(&hover, bounds).is_none(), "no click, no selection");
}
