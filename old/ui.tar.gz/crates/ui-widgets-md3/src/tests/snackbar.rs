//! The MD3 snackbar: the inverse-surface bar, its two heights, the body and action type, and
//! the fade the app drives.
//! MD3 提示条：`inverse-surface` 的条、两种高度、正文与动作的字级，以及由应用驱动的淡变。

use super::*;

use crate::spec::snackbar_spec;
use crate::{Md3Snackbar, SnackbarParams};
use ui_core::cx::Routing;
use ui_core::draw::Shape;
use ui_core::geom::Rect;
use ui_core::{NodeData, Weight};

const BAR: Id = Id::str("snack");
const WIDTH: f32 = 400.0;

fn build(
    store: &mut AnimStore,
    two_lines: bool,
    visible: bool,
    overlay: Option<f32>,
) -> (Md3Snackbar, Decl) {
    let mut core = ui_core::cx::Cx::new(store, 0, 600, 200, 0.0, 0.0, 1.0, None);
    core.route(Routing::default());
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let control = Md3Snackbar::new_with(
        Md3Options::default(),
        SnackbarParams {
            id: BAR,
            message: "Message archived",
            action: Some("Undo"),
            two_lines,
            floating: false,
            width: WIDTH,
            visible,
            overlay,
        },
        &mut cx,
        &crate::pack::pack(),
    );
    let decl = cx.with_cx(|cx| control.decl(cx));
    (control, decl)
}

fn find(decl: &Decl, id: Id) -> Option<&Decl> {
    if decl.id == id {
        return Some(decl);
    }
    decl.children.iter().find_map(|c| find(c, id))
}

#[test]
fn the_snackbar_is_the_exported_height_for_one_and_two_lines() {
    // The export makes height a branch: 48 for one line, 68 for two; a single fixed height
    // would clip the second line or leave a gap under the first.
    // 导出把高度做成分支：一行 48、两行 68；钉死一个高度就会裁掉第二行或在第一行下留空。
    let one = snackbar_spec(false, true, false, false, false, false);
    let two = snackbar_spec(false, false, true, false, false, false);
    assert_eq!((one.container.height, two.container.height), (48.0, 68.0));
    let mut store = AnimStore::new();
    let (control, _) = build(&mut store, false, true, None);
    assert_eq!(control.height(), one.container.height);
    let mut store = AnimStore::new();
    let (control, _) = build(&mut store, true, true, None);
    assert_eq!(control.height(), two.container.height);
    let (_, decl) = build(&mut store, true, true, None);
    match decl.shapes.first() {
        Some(Shape::Box { corners, fill, .. }) => {
            assert_eq!(corners.tl, 4.0, "the export's rounded corners are 4dp");
            assert_ne!(*fill, Color::TRANSPARENT);
        }
        other => panic!("the bar paints a box, got {other:?}"),
    }
}

#[test]
fn the_body_is_body_medium_and_the_action_is_label_large() {
    // The body is `supporting-text`, not `label-text`; the action is the only `label-text`
    // in this export, and the two take different inks and weights.
    // 正文是 `supporting-text` 而不是 `label-text`；动作才是这份导出里唯一的 `label-text`，
    // 两者的墨色与字重都不同。
    let spec = snackbar_spec(false, true, false, false, false, false);
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, false, true, None);
    let text = |id: Id| match &find(&decl, id).expect("the node exists").data {
        NodeData::Text { block, ink, .. } => {
            (block.runs[0].style.size, block.runs[0].style.weight, *ink)
        }
        _ => panic!("the node is text"),
    };
    let (size, weight, _) = text(BAR.with("message"));
    assert_eq!(size, spec.supporting_text.size);
    assert_eq!(weight, Weight(spec.supporting_text.weight as u16));
    let (asize, aweight, _) = text(BAR.with("action").with("label"));
    assert_eq!(asize, spec.action_label_text.size);
    assert_eq!(aweight, Weight(spec.action_label_text.weight as u16));
    assert_ne!(spec.supporting_text.color, spec.action_label_text.color, "the inks differ");
}

#[test]
fn a_hidden_snackbar_paints_nothing_and_reports_nothing() {
    // The app keeps the bar mounted through its exit; at zero progress it must paint no
    // container and no text, or the "gone" snackbar would still cover the page.
    // 应用在退场期间让条留在树里；进度为零时它不得画容器与文字，否则「已消失」的条仍盖住页面。
    let mut store = AnimStore::new();
    let (_, hidden) = build(&mut store, false, false, None);
    assert!(hidden.shapes.is_empty(), "a faded bar paints no container");
    assert!(hidden.children.is_empty(), "and no text");
    let state = ui_widgets::WidgetState { clicked: true, ..Default::default() };
    let bounds = Rect::new(0.0, 0.0, WIDTH, 48.0);
    let mut store = AnimStore::new();
    let (control, _) = build(&mut store, false, false, None);
    assert!(control.change(&state, bounds).is_none(), "a hidden bar reports nothing");
}

#[test]
fn a_click_reports_the_action_and_the_message_area_stays_inert() {
    // Only the action carries a click sense, so the bar's own click state means "the action
    // was pressed"; a press on the message must not activate anything.
    // 只有动作带点击语义，因此条的点击态就等于「动作被按下」；按在正文上不得激活任何东西。
    let bounds = Rect::new(0.0, 0.0, WIDTH, 48.0);
    let mut store = AnimStore::new();
    let (control, _) = build(&mut store, false, true, None);
    let click = ui_widgets::WidgetState { clicked: true, ..Default::default() };
    assert!(matches!(control.change(&click, bounds), Some(ui_core::Change::Activated)));
    let hover = ui_widgets::WidgetState::default();
    assert!(control.change(&hover, bounds).is_none(), "no click, no change");
    // The action node is the only sense owner under the bar.
    let (_, decl) = build(&mut store, false, true, None);
    let action = find(&decl, BAR.with("action")).expect("the action exists");
    assert!(action.sense.contains(ui_core::Sense::CLICK), "the action is clickable");
    assert!(decl.sense == ui_core::Sense::NONE, "the bar itself is not");
}

#[test]
fn an_overlay_snackbar_is_fixed_and_inset_to_the_page_bottom() {
    // The floating variant leaves the flow and pins itself to the bottom of its containing
    // block: the auto left and right sides centre it, the bottom inset holds the 24dp gap.
    // 浮动变体移出流并钉在包含块底部：左右 auto 让它居中，下内缩保持 24dp 的间距。
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, false, true, Some(24.0));
    assert_eq!(decl.placement.position, ui_core::layout::Position::Fixed, "the bar is out of flow");
    assert_eq!(decl.placement.inset.bottom, ui_core::Len::Px(24.0));
    assert_eq!(decl.placement.inset.left, ui_core::Len::Auto, "the left side is auto");
    assert_eq!(decl.placement.inset.right, ui_core::Len::Auto, "the right side is auto");
}
