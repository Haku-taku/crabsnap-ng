//! The MD3 toolbar: the 64dp bar, its 48dp icon-button slots, the two variants and the two
//! member themes.
//! MD3 工具条：64dp 的条、48dp 图标按钮槽、两种变体与两套成员主题。

use super::*;

use crate::spec::{
    toolbar_docked_spec, toolbar_floating_spec, toolbar_standard_spec, toolbar_vibrant_spec,
};
use crate::{
    Md3Toolbar, ToolbarAction, ToolbarParams, ToolbarTheme, ToolbarVariant, TOOLBAR_DISC,
    TOOLBAR_ICON, TOOLBAR_SLOT,
};
use ui_core::cx::Routing;
use ui_core::draw::Shape;
use ui_core::geom::{Point, Rect};

const TOOL: Id = Id::str("tool");

fn member_id(k: usize) -> Id {
    TOOL.with(("m", k))
}

/// A 24dp mark in the member's ink: the stand-in for a real glyph.
/// 24dp、按成员墨色绘制的标记：真实字形的替身。
fn dot(id: Id, ink: Color) -> Decl {
    Decl::container(id, NodeKind::Box)
        .size(SizeClass::fixed(24.0, 24.0))
        .shapes(vec![Shape::Box {
            corners: ui_core::Corners::ZERO,
            fill: ink,
            gradient: None,
            border: None,
            shadow: None,
            image: None,
        }])
}

fn build(
    store: &mut AnimStore,
    variant: ToolbarVariant,
    theme: ToolbarTheme,
    selected: &[usize],
) -> (Md3Toolbar, Decl) {
    let mut core = ui_core::cx::Cx::new(store, 0, 600, 200, 0.0, 0.0, 1.0, None);
    core.route(Routing::default());
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let actions: Vec<ToolbarAction<'_>> = (0..3)
        .map(|k| {
            let a = ToolbarAction::new(member_id(k), ui_widgets::IconSource::Custom(dot));
            if selected.contains(&k) {
                a.selected()
            } else {
                a
            }
        })
        .collect();
    let control = Md3Toolbar::new_with(
        Md3Options::default(),
        ToolbarParams { id: TOOL, variant, theme, actions: &actions, disabled: false },
        &mut cx,
        &crate::pack::pack(),
    );
    let decl = cx.with_cx(|cx| control.decl(cx));
    (control, decl)
}

/// Lay the bar out as the only child of a 600-wide column; `stretch` decides whether the
/// column forces its width, which a `fill` bar needs and a hugging one must not get.
/// 把条作为 600 宽列的唯一子节点布局；`stretch` 决定列是否强制宽度——`fill` 的条需要它，
/// 贴合内容的条不能要。
fn laid(decl: Decl, stretch: bool) -> Tree {
    let mut root = Decl::container(Id::str("root"), NodeKind::Column).child(decl);
    if !stretch {
        root = root.cross_align(0.0).cross_pos(0.0);
    }
    lay_out(&root, (600.0, 200.0))
}

fn find(decl: &Decl, id: Id) -> Option<&Decl> {
    if decl.id == id {
        return Some(decl);
    }
    decl.children.iter().find_map(|c| find(c, id))
}

fn disc_fill(decl: &Decl, k: usize) -> Color {
    match find(decl, member_id(k)).expect("the member exists").shapes.first() {
        Some(Shape::Rect { fill, .. }) => *fill,
        other => panic!("the member paints its disc first, got {other:?}"),
    }
}

#[test]
fn the_docked_bar_is_the_exported_height_with_48dp_slots() {
    // The docked bar is 64dp of `surface-container` with square corners, and each member is
    // the icon button's 48dp target around a 40dp disc; the app bar uses the same constants,
    // so a token change must move both.
    // 停靠式是 64dp 的 `surface-container`、方角；每个成员是图标按钮的 48dp 触控区套
    // 40dp 圆盘；app bar 用同一组常量，改令牌必须两处一起动。
    let spec = toolbar_docked_spec();
    assert_eq!(spec.container.height, 64.0);
    assert_eq!((TOOLBAR_SLOT, TOOLBAR_DISC, TOOLBAR_ICON), (48.0, 40.0, 24.0));
    assert_eq!(TOOLBAR_SLOT, crate::app_bar::APP_BAR_SLOT, "the slot is the app bar's");
    assert_eq!(TOOLBAR_ICON, crate::app_bar::APP_BAR_ICON, "and so is the mark");
    let mut store = AnimStore::new();
    let (control, decl) = build(&mut store, ToolbarVariant::Docked, ToolbarTheme::Standard, &[]);
    assert_eq!(control.height(), spec.container.height);
    match decl.shapes.first() {
        Some(Shape::Box { corners, .. }) => assert!(corners.is_zero(), "the docked bar is square"),
        other => panic!("the bar paints a box, got {other:?}"),
    }
    let tree = laid(decl, true);
    let (_, _, w, h) = region_rect(&tree, TOOL);
    assert!((h - spec.container.height).abs() < 1e-4, "the bar is {h} tall");
    assert!((w - 600.0).abs() < 1e-4, "a docked bar fills its parent, got {w}");
}

#[test]
fn the_floating_bar_is_a_stadium_raised_by_the_exported_elevation() {
    // Floating is the same height but `corner.full` (a stadium), hugs its members and carries
    // elevation 6 — the shadow is what tells it apart from a docked bar at a glance.
    // 浮动式同样高，但取 `corner.full`（胶囊）、宽度贴合成员，并带 elevation 6——
    // 阴影是它与停靠式一眼可辨的差别。
    let spec = toolbar_floating_spec();
    let mut store = AnimStore::new();
    let (control, decl) = build(&mut store, ToolbarVariant::Floating, ToolbarTheme::Standard, &[]);
    match decl.shapes.first() {
        Some(Shape::Box { corners, shadow, .. }) => {
            assert_eq!(corners.tl, control.height() * 0.5, "the ends are half the height");
            let shadow = shadow.expect("the floating bar casts a shadow");
            assert_eq!(shadow.blur, spec.container.elevation * 2.0);
            assert_eq!(shadow.dy, spec.container.elevation * 0.5);
        }
        other => panic!("the bar paints a box, got {other:?}"),
    }
    let tree = laid(decl, false);
    let (_, _, w, _) = region_rect(&tree, TOOL);
    let want = spec.container.leading_space * 2.0 + TOOLBAR_SLOT * 3.0 + spec.container.between_space * 2.0;
    assert!((w - want).abs() < 1e-4, "the floating bar hugs its members, got {w}");
}

#[test]
fn a_selected_member_takes_its_themes_selected_disc() {
    // The two theme tables disagree about which colour means "selected": standard highlights
    // `secondary-container`, vibrant highlights `surface-container` on a `primary-container` bar.
    // 两套主题对「选中」的颜色说法不同：标准在 `surface-container` 条上高亮
    // `secondary-container`，鲜艳在 `primary-container` 条上高亮 `surface-container`。
    let pack = crate::pack::pack();
    let ink = |name| crate::toggle::spec_ink(&pack, name, 1.0);
    let std = toolbar_standard_spec(false, false, false, false, false);
    let std_sel = toolbar_standard_spec(true, false, false, false, false);
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, ToolbarVariant::Docked, ToolbarTheme::Standard, &[1]);
    assert_eq!(disc_fill(&decl, 1), ink(std_sel.button_container.color), "selected, standard");
    assert_eq!(disc_fill(&decl, 0), ink(std.button_container.color), "unselected, standard");
    assert_ne!(std_sel.button_container.color, std.button_container.color);

    let vib = toolbar_vibrant_spec(false, false, false, false, false);
    let vib_sel = toolbar_vibrant_spec(true, false, false, false, false);
    let mut store = AnimStore::new();
    let (_, decl) = build(&mut store, ToolbarVariant::Docked, ToolbarTheme::Vibrant, &[1]);
    assert_eq!(disc_fill(&decl, 1), ink(vib_sel.button_container.color), "selected, vibrant");
    assert_eq!(disc_fill(&decl, 0), ink(vib.button_container.color), "unselected, vibrant");
    assert_ne!(vib_sel.button_container.color, vib.button_container.color);
}

#[test]
fn a_press_names_the_member_under_the_pointer() {
    // Members are 48dp slots with the export's spacing between them; a press in the gap or
    // past the last member belongs to nobody.
    // 成员是 48dp 槽，间距取自导出；按在缝里或最后一个之后不属于任何人。
    let spec = toolbar_docked_spec();
    let mut store = AnimStore::new();
    let (control, _) = build(&mut store, ToolbarVariant::Docked, ToolbarTheme::Standard, &[]);
    let bounds = Rect::new(0.0, 0.0, 600.0, control.height());
    let press = |x: f32| ui_widgets::WidgetState {
        clicked: true,
        local: Some(Point::new(x, 20.0)),
        ..Default::default()
    };
    let step = TOOLBAR_SLOT + spec.container.min_spacing;
    for k in 0..3 {
        let x = spec.container.leading_space + step * k as f32 + TOOLBAR_SLOT * 0.5;
        match control.change(&press(x), bounds) {
            Some(ui_core::Change::Selected(Some(id))) => assert_eq!(id, member_id(k), "x={x}"),
            other => panic!("x={x} expected Selected(member {k}), got {other:?}"),
        }
    }
    let gap = spec.container.leading_space + TOOLBAR_SLOT + spec.container.min_spacing * 0.5;
    assert!(control.change(&press(gap), bounds).is_none(), "the gap belongs to no member");
    let after = spec.container.leading_space + step * 3.0 + 1.0;
    assert!(control.change(&press(after), bounds).is_none(), "past the last member");
    let hover = ui_widgets::WidgetState { local: Some(Point::new(24.0, 20.0)), ..Default::default() };
    assert!(control.change(&hover, bounds).is_none(), "no click, no change");
}
