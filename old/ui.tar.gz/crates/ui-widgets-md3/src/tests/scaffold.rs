//! The MD3 scaffold: six regions, their sizes and their independence.
//! MD3 骨架：六个区域、它们的尺寸与彼此独立。

use super::*;

/// The same square, placed as `main`, lands at each style's content origin unchanged.
/// 同一个方块作为 `main`，在三种骨架里都被原样放进各自的内容原点。
#[test]
fn the_content_does_not_know_the_skeleton() {
    let content = Square {
        id: Id::str("content"),
        side: 40.0,
    };
    let header = Square {
        id: Id::str("header-content"),
        side: 30.0,
    };
    let mut store = AnimStore::new();
    let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 200, 0.0, 0.0, 1.0, None);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let spec = ScaffoldSpec::main_only(Id::str("root"), &content).header(&header);
    let md3 = scaffold_decl(&Md3Kit::new(), &spec, &mut cx);
    let fluent = scaffold_decl(&ui_widgets_fluent::FluentKit::new(), &spec, &mut cx);
    let glass = scaffold_decl(&ui_widgets_glass::HigKit::new(), &spec, &mut cx);
    let cases = [
        ("md3", md3, SCAFFOLD_HEADER_H),
        ("fluent", fluent, ui_widgets_fluent::SCAFFOLD_HEADER_H),
        ("glass", glass, ui_widgets_glass::SCAFFOLD_HEADER_H),
    ];
    for (name, decl, header_h) in cases {
        let tree = lay_out(&decl, (800.0, 600.0));
        let (x, y, w, h) = region_rect(&tree, Id::str("content"));
        // The skeleton places, never resizes: the square keeps its own 40x40.
        // 骨架只负责摆放、绝不改尺寸：方块保持自己的 40x40。
        assert_eq!((w, h), (40.0, 40.0), "{name}: content was resized");
        assert_eq!((x, y), (0.0, header_h), "{name}: content origin");
        assert_eq!(
            region_rect(&tree, Id::str("root").with("header")),
            (0.0, 0.0, 800.0, header_h),
            "{name}: header slot"
        );
    }
}

/// A missing region must not redefine the others: `main` stays valid and only shifts.
/// 缺失区域不改变其他区域的含义：`main` 仍有效，只是位移与收窄。
#[test]
fn a_missing_region_does_not_change_the_meaning_of_the_others() {
    let content = Square {
        id: Id::str("content"),
        side: 40.0,
    };
    let nav = Square {
        id: Id::str("nav-content"),
        side: 20.0,
    };
    let mut store = AnimStore::new();
    let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 200, 0.0, 0.0, 1.0, None);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let bare = ScaffoldSpec::main_only(Id::str("root"), &content);
    let with_nav = ScaffoldSpec::main_only(Id::str("root"), &content).nav(&nav);
    let cases = [
        (
            "md3",
            scaffold_decl(&Md3Kit::new(), &bare, &mut cx),
            scaffold_decl(&Md3Kit::new(), &with_nav, &mut cx),
            SCAFFOLD_NAV_W,
        ),
        (
            "fluent",
            scaffold_decl(&ui_widgets_fluent::FluentKit::new(), &bare, &mut cx),
            scaffold_decl(&ui_widgets_fluent::FluentKit::new(), &with_nav, &mut cx),
            ui_widgets_fluent::SCAFFOLD_PANE_W,
        ),
        (
            "glass",
            scaffold_decl(&ui_widgets_glass::HigKit::new(), &bare, &mut cx),
            scaffold_decl(&ui_widgets_glass::HigKit::new(), &with_nav, &mut cx),
            ui_widgets_glass::SCAFFOLD_RAIL_W,
        ),
    ];
    for (name, no_nav, nav_on, nav_w) in cases {
        let a = lay_out(&no_nav, (800.0, 600.0));
        let b = lay_out(&nav_on, (800.0, 600.0));
        let (ax, ay, aw, ah) = region_rect(&a, Id::str("root").with("main"));
        let (bx, by, bw, bh) = region_rect(&b, Id::str("root").with("main"));
        // `nav: None` still yields a valid, non-zero region that fills the page.
        // `nav: None` 仍给出有效非零、铺满页面的内容区。
        assert!(aw > 0.0 && ah > 0.0, "{name}: empty main without nav");
        assert_eq!((ax, ay, aw, ah), (0.0, 0.0, 800.0, 600.0), "{name}: bare main");
        // Adding nav shifts the origin right by exactly the rail width and narrows main.
        // 加导航把原点右移恰好一个栏宽，并收窄 main。
        assert_eq!(bx, nav_w, "{name}: main origin x");
        assert_eq!((by, bh), (ay, ah), "{name}: nav must not move main vertically");
        assert_eq!(bw, aw - nav_w, "{name}: main width");
    }
}

/// Six regions reachable, and `overlay` floats over `main` instead of pushing it.
/// 六个区域都可达，且 `overlay` 浮在 `main` 上而不推挤它。
#[test]
fn the_six_regions_are_all_reachable() {
    let nav = Square {
        id: Id::str("nav-content"),
        side: 20.0,
    };
    let header = Square {
        id: Id::str("header-content"),
        side: 24.0,
    };
    let content = Square {
        id: Id::str("main-content"),
        side: 40.0,
    };
    let context = Square {
        id: Id::str("context-content"),
        side: 28.0,
    };
    let inline = Square {
        id: Id::str("inline-content"),
        side: 18.0,
    };
    let overlay = Square {
        id: Id::str("overlay-content"),
        side: 30.0,
    };
    let mut store = AnimStore::new();
    let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 200, 0.0, 0.0, 1.0, None);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let full = ScaffoldSpec::main_only(Id::str("root"), &content)
        .nav(&nav)
        .header(&header)
        .context(&context)
        .inline(&inline)
        .overlay(&overlay);
    let without_overlay = ScaffoldSpec::main_only(Id::str("root"), &content)
        .nav(&nav)
        .header(&header)
        .context(&context)
        .inline(&inline);
    let cases = [
        (
            "md3",
            scaffold_decl(&Md3Kit::new(), &full, &mut cx),
            scaffold_decl(&Md3Kit::new(), &without_overlay, &mut cx),
        ),
        (
            "fluent",
            scaffold_decl(&ui_widgets_fluent::FluentKit::new(), &full, &mut cx),
            scaffold_decl(&ui_widgets_fluent::FluentKit::new(), &without_overlay, &mut cx),
        ),
        (
            "glass",
            scaffold_decl(&ui_widgets_glass::HigKit::new(), &full, &mut cx),
            scaffold_decl(&ui_widgets_glass::HigKit::new(), &without_overlay, &mut cx),
        ),
    ];
    let six = [
        "nav-content",
        "header-content",
        "main-content",
        "context-content",
        "inline-content",
        "overlay-content",
    ];
    for (name, with_float, without) in cases {
        let tree = lay_out(&with_float, (800.0, 600.0));
        for id in six {
            assert!(
                tree.find_by_id(Id::str(id)).is_some(),
                "{name}: region {id} is unreachable"
            );
        }
        let main = region_rect(&tree, Id::str("root").with("main"));
        let float = region_rect(&tree, Id::str("overlay-content"));
        // The float starts at main's origin and stays inside it: overlap, not a slot.
        // 浮层从 main 原点开始并在其内：是重叠，不是占位。
        assert!(
            float.0 < main.0 + main.2
                && main.0 < float.0 + float.2
                && float.1 < main.1 + main.3
                && main.1 < float.1 + float.3,
            "{name}: overlay {float:?} does not overlap main {main:?}"
        );
        let bare_tree = lay_out(&without, (800.0, 600.0));
        assert_eq!(
            main,
            region_rect(&bare_tree, Id::str("root").with("main")),
            "{name}: overlay must not push main"
        );
    }
}

#[test]
fn the_scaffold_decl_is_reentrant() {
    let content = Square {
        id: Id::str("content"),
        side: 40.0,
    };
    let mut store = AnimStore::new();
    let mut core = ui_core::cx::Cx::new(&mut store, 0, 400, 200, 0.0, 0.0, 1.0, None);
    let mut cx = ui_widgets::Cx::new(&mut core, ui_style::Env::root());
    let spec = ScaffoldSpec::main_only(Id::str("root"), &content);
    let control = Md3Kit::new().scaffold(
        &spec,
        &mut cx,
    );
    assert_eq!(
        ui_widgets::Cx::for_test(|cx| control.decl(cx)),
        ui_widgets::Cx::for_test(|cx| control.decl(cx)),
        "decl() must be reentrant"
    );
}

#[test]
fn a_scaffold_spec_carries_the_subtree_scope_to_its_style() {
    let content = Square {
        id: Id::str("content"),
        side: 40.0,
    };
    let plain = ScaffoldSpec::main_only(Id::str("root"), &content);
    let scoped = ScaffoldSpec::main_only(Id::str("root"), &content)
        .scoped(Md3Options { outline_width: 5.0, ..Default::default() });
    assert!(plain.env().find::<Md3Options>().is_none());
    assert_eq!(
        scoped.env().find::<Md3Options>(),
        Some(&Md3Options { outline_width: 5.0, ..Default::default() })
    );
    // A second scope nests: it hides only its own type, the outer one still resolves.
    // 第二层只遮住自己的类型，外层依然可解析。
    let nested = ScaffoldSpec::main_only(Id::str("root"), &content)
        .scoped(Md3Options { outline_width: 5.0, ..Default::default() })
        .scoped(
            ui_widgets_fluent::FluentOptions { slider_track_h: 8.0 },
        );
    assert_eq!(
        nested.env().find::<Md3Options>(),
        Some(&Md3Options { outline_width: 5.0, ..Default::default() })
    );
    assert_eq!(
        nested.env().find::<ui_widgets_fluent::FluentOptions>(),
        Some(&ui_widgets_fluent::FluentOptions { slider_track_h: 8.0 })
    );
}

