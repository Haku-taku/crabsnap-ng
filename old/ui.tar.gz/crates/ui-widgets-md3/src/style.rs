//! The kit: options resolved from the scope, controls built here.
//! 风格包：从作用域解析选项，并在此构建控件。

use ui_style::{Style};
use ui_widgets::ScaffoldSpec;
use ui_widgets::{Widget, StyleKit};

use crate::{Md3Scaffold, Md3Toggle};

/// MD3-specific knobs the semantic specs cannot express; scopes override the instance default.
/// 语义规格表达不了的 MD3 专属旋钮；作用域覆盖实例默认值。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Md3Options {
    /// `trackOutlineWidth` while unselected; it lerps to 0 as the fill arrives.
    /// 未选中时的 `trackOutlineWidth`；随填充到来插值到 0。
    pub outline_width: f32,
    /// Whether the thumb carries a glyph. Decides the 24-vs-16 handle rule, so it is a
    /// build-time knob, not a per-frame state.
    /// 滑块是否带字形。它决定 24 与 16 的滑块规则，故是构建期旋钮，而非逐帧状态。
    pub has_icon: bool,
    /// Draw the switch in its disabled appearance. A static sample needs this without a live
    /// disabled ancestor, so it travels on the params with the icon flag.
    /// 以禁用外观绘制开关。静态样本需要它而不必有真实的禁用祖先，故与图标标志一同放在参数里。
    pub disabled: bool,
}

impl Default for Md3Options {
    fn default() -> Self {
        Self {
            outline_width: crate::OUTLINE_WIDTH,
            has_icon: true,
            disabled: false,
        }
    }
}

/// MD3's kit: every control this crate draws, built from one resolved pack.
/// MD3 风格包：本 crate 绘制的所有控件，皆由一份解析好的包构建。
pub struct Md3Kit {
    /// This kit's own pack constructor, so a scope-driven theme switch needs no rebuild.
    /// 本包自己的建包函数，使作用域驱动的主题切换无需重建。
    resolver: fn(ui_design::Appearance) -> Style,
    /// Every control in a frame shares one resolved pack per context.
    /// 同一帧内所有控件按上下文共用一份解析好的包。
    cache: ui_style::StyleCache,
    options: Md3Options,
    /// The context used when no `StyleScope` is on the chain.
    /// 链上没有 `StyleScope` 时使用的上下文。
    home: ui_style::StyleScope,
}

impl Md3Kit {
    /// A kit whose home context is the standard light one.
    /// 回落上下文为标准浅色上下文的风格包。
    pub fn new() -> Self {
        Self::with_scope(ui_style::StyleScope::default(), Md3Options::default())
    }

    /// An instance whose home context and unprefixed defaults are the given ones.
    /// 以给定上下文与默认值作为无作用域时回落的实例。
    pub fn with_scope(scope: ui_style::StyleScope, options: Md3Options) -> Self {
        Self {
            resolver: crate::pack::pack_owned,
            cache: ui_style::StyleCache::new(),
            options,
            home: scope,
        }
    }

    fn options_in(&self, env: &ui_style::Env) -> Md3Options {
        env.find::<Md3Options>().copied().unwrap_or(self.options)
    }

    /// The pack for the scope in force, with any running theme transition applied.
    /// 当前作用域下的包，并应用正在进行的主题过渡。
    fn pack_in(&self, cx: &ui_widgets::Cx<'_, '_>) -> ui_style::Style {
        let scope = cx.env().scope().unwrap_or(self.home);
        self.cache.get(scope, self.resolver)
    }

    /// The resolved pack for `cx`, with a running theme transition applied — the same
    /// value `pack_in` feeds the kit's own controls, so a direct `new_with` caller (e.g. a
    /// gallery shell) blends through the transition instead of snapping to the target scheme.
    /// 为 `cx` 解析出的包，应用正在进行的主题过渡——与 `pack_in` 供给控件自身的值一致，
    /// 因此直接调用 `new_with` 的调用方（如 gallery 外壳）也会平滑过渡而不是硬切到目标方案。
    pub fn pack_for(&self, cx: &ui_widgets::Cx<'_, '_>) -> ui_style::Style {
        self.pack_in(cx)
    }

    /// A dot badge, or a pill when `label` is given.
    /// 圆点徽标；给出 `label` 时为胶囊。
    pub fn badge(
        &self,
        id: ui_core::Id,
        label: Option<&str>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let pack = self.pack_in(cx);
        Box::new(match label {
            Some(text) => crate::Md3Badge::with_label(id, text, &pack),
            None => crate::Md3Badge::dot(id, &pack),
        })
    }

    /// A checkbox; `error` paints the error role, disabled comes from the state.
    /// 复选框；`error` 取错误角色，禁用态来自状态。
    pub fn checkbox(
        &self,
        id: ui_core::Id,
        checked: bool,
        error: bool,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        self.checkbox_tri(id, crate::CheckState::from_bool(checked), error, cx)
    }

    /// The three-valued checkbox: `Mixed` draws the dash, `error` paints the error role.
    /// 三值复选框：`Mixed` 画横杠，`error` 取错误角色。
    pub fn checkbox_tri(
        &self,
        id: ui_core::Id,
        value: crate::CheckState,
        error: bool,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        let mut node = cx.at(id);
        Box::new(crate::Md3Checkbox::new_tri(p, id, value, error, &mut node, &pack))
    }

    /// A slider `width` dp wide at `size`; `value` is 0..=1.
    /// 宽 `width` dp、尺寸为 `size` 的滑块；`value` 取 0..=1。
    pub fn slider_sized(
        &self,
        id: ui_core::Id,
        value: f32,
        width: f32,
        size: crate::spec::SliderSize,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        self.slider_opts(id, value, width, size, crate::SliderOpts::default(), cx)
    }

    /// The same slider with discrete stops and/or a trailing handle.
    /// 同一滑块，带离散刻度与/或尾手柄。
    pub fn slider_opts(
        &self,
        id: ui_core::Id,
        value: f32,
        width: f32,
        size: crate::spec::SliderSize,
        opts: crate::SliderOpts,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        let mut node = cx.at(id);
        Box::new(crate::Md3Slider::with_opts(
            id,
            value,
            width,
            size,
            p,
            opts,
            Some(&mut node),
            &pack,
        ))
    }

    /// A radio button; the group's selected id belongs to the app, not to the control.
    /// 单选框；整组的选中项归应用，控件不持有。
    pub fn radio(
        &self,
        id: ui_core::Id,
        selected: bool,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        let mut node = cx.at(id);
        Box::new(crate::Md3Radio::new_with(p, id, selected, &mut node, &pack))
    }

    /// A divider; `inset` is the MD3 inset, `Insets::ZERO` for full bleed.
    /// 分隔线；`inset` 是 MD3 的内缩量，`Insets::ZERO` 表示通栏。
    pub fn divider(
        &self,
        id: ui_core::Id,
        axis: crate::DividerAxis,
        inset: ui_core::geom::Insets,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let pack = self.pack_in(cx);
        Box::new(crate::Md3Divider::new(id, axis, inset, &pack))
    }

    /// A secondary navigation tab bar; `selected` is the index the app considers current and
    /// `width` is the width it will be laid out at, which the underline's travel needs.
    /// 次级导航页签栏；`selected` 是应用认为当前选中的下标，`width` 是它将被布局成的宽度，
    /// 下划线的行程需要它。
    pub fn tab_bar(
        &self,
        id: ui_core::Id,
        items: &[crate::Md3TabItem<'_>],
        selected: usize,
        width: f32,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3TabBar::new_with(p, id, items, selected, width, cx, &pack))
    }

    /// A button: every axis is chosen through `ButtonParams`, in the order the label reads.
    /// 一个按钮：每个轴都通过 `ButtonParams` 选定，顺序与标签一致。
    pub fn button(
        &self,
        spec: crate::ButtonParams,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3Button::new_with(p, spec, cx, &pack))
    }

    /// A toggle button: `selected` is the state the app owns, and a press flips it.
    /// 切换按钮：`selected` 是应用持有的状态，按下即翻转。
    pub fn toggle_button(
        &self,
        spec: crate::ButtonParams,
        selected: bool,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let toggle = if selected { crate::ButtonToggle::Selected } else { crate::ButtonToggle::Unselected };
        self.button(spec.toggle(toggle), cx)
    }

    /// A FAB menu: items above the close button that replaced the FAB. `tone` and `open`
    /// belong to the app.
    /// 一个 FAB 菜单：取代 FAB 的关闭按钮上方一列菜单项。`tone` 与 `open` 归应用所有。
    pub fn fab_menu(
        &self,
        id: ui_core::Id,
        items: &[crate::Md3FabMenuItem<'_>],
        tone: crate::FabMenuColour,
        open: bool,
        close_icon: ui_widgets::IconSource,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3FabMenu::new_with(p, id, items, tone, open, close_icon, cx, &pack))
    }

    /// A chip: kind, variant and the two marks are all chosen through `ChipParams`.
    /// 一颗芯片：类型、变体与两个标记都通过 `ChipParams` 选定。
    pub fn chip(
        &self,
        spec: crate::ChipParams,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3Chip::new_with(p, spec, cx, &pack))
    }

    /// A card: one surface in the chosen variant, holding the app's own content.
    /// 一张卡片：所选变体的表面，承载应用自身的内容。
    pub fn card(
        &self,
        id: ui_core::Id,
        variant: crate::CardVariant,
        content: Vec<ui_core::Decl>,
        clickable: bool,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3Card::new_with(p, id, variant, content, clickable, cx, &pack))
    }

    /// A list item: one row of a list, with its content chosen when it is built.
    /// 一个列表项：列表中的一行，内容在构建时选定。
    pub fn list_item(
        &self,
        item: crate::ListItemParams,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3ListItem::new_with(p, item, cx, &pack))
    }

    /// A dialog: one modal surface, with everything it shows chosen when it is built.
    /// 一个对话框：一个模态表面，它展示的一切在构建时选定。
    pub fn dialog(
        &self,
        content: crate::DialogContent,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3Dialog::new_with(p, content, cx, &pack))
    }

    /// A top app bar; `scrolled` and `collapsed` are the two facts its app owns.
    /// 一个顶部应用栏；`scrolled` 与 `collapsed` 是应用持有的两个事实。
    pub fn app_bar(
        &self,
        content: crate::AppBarParams<'_>,
        scrolled: bool,
        collapsed: bool,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3AppBar::new_with(p, content, scrolled, collapsed, cx, &pack))
    }

    /// A carousel; `scroll` is the one fact its app owns.
    /// 一个轮播；`scroll` 是应用持有的那个事实。
    pub fn carousel(
        &self,
        content: crate::CarouselParams<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3Carousel::new_with(p, content, cx, &pack))
    }

    /// A text field; the app owns the buffer the engine edits.
    /// 一个文本字段；引擎编辑的缓冲归应用所有。
    pub fn text_field(
        &self,
        content: crate::TextFieldParams<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3TextField::new_with(p, content, cx, &pack))
    }

    /// A search bar; the app owns the query the engine edits.
    /// 一个搜索栏；引擎编辑的查询归应用所有。
    pub fn search_bar(
        &self,
        content: crate::SearchBarParams<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3SearchBar::new_with(p, content, cx, &pack))
    }

    /// A search view; the app owns the query, the openness and the results.
    /// 一个搜索视图；查询、开合与结果都归应用所有。
    pub fn search_view(
        &self,
        content: crate::SearchViewParams<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3SearchView::new_with(p, content, cx, &pack))
    }

    /// A shortcut field; the app owns the chord it reports.
    /// 一个快捷键字段；它上报的组合键归应用所有。
    pub fn shortcut_field(
        &self,
        content: crate::ShortcutFieldParams<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let pack = self.pack_in(cx);
        Box::new(crate::Md3ShortcutField::new(content, &pack))
    }

    /// How the engine should paint its context menu, in this scope's colours.
    /// 引擎应当如何绘制它的上下文菜单，取本作用域的颜色。
    pub fn menu_style(&self, cx: &mut ui_widgets::Cx<'_, '_>) -> ui_widgets::MenuStyle {
        let pack = self.pack_in(cx);
        crate::menu_style(&pack)
    }

    /// A connected button group: one pill whose members share their edges.
    /// 一个连通按钮组：一颗胶囊，成员共用彼此的边缘。
    pub fn button_group(
        &self,
        content: crate::ButtonGroupParams,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3ButtonGroup::new_with(p, content, cx, &pack))
    }

    /// An outlined segmented button: equal segments, one pill, selection the app owns.
    /// 轮廓分段按钮：等宽分段合成一颗胶囊，选中归应用所有。
    pub fn segmented_button(
        &self,
        content: crate::SegmentedParams<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3SegmentedButton::new_with(p, content, cx, &pack))
    }

    /// A bottom navigation bar: equal destinations, one selected by the app.
    /// 底部导航栏：等宽目标，选中项由应用给出。
    pub fn nav_bar(
        &self,
        content: crate::NavBarParams<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3NavBar::new_with(p, content, cx, &pack))
    }

    /// A navigation rail: the same destinations stacked in a fixed-width column.
    /// 导航轨道：同一套目标纵向堆在定宽列里。
    pub fn nav_rail(
        &self,
        content: crate::RailParams<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3NavRail::new_with(p, content, cx, &pack))
    }

    /// A standard navigation drawer: headline groups over 336dp destination capsules.
    /// 标准导航抽屉：标题分组，下面是 336dp 的目标胶囊。
    pub fn nav_drawer(
        &self,
        content: crate::DrawerParams<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3NavDrawer::new_with(p, content, cx, &pack))
    }

    /// A toolbar of icon-button slots, docked or floating.
    /// 由图标按钮槽组成的工具条，停靠式或浮动式。
    pub fn toolbar(
        &self,
        content: crate::ToolbarParams<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3Toolbar::new_with(p, content, cx, &pack))
    }

    /// A snackbar with body text and an optional action; the app owns its lifetime.
    /// 带正文与可选动作的提示条；生命周期归应用所有。
    pub fn snackbar(
        &self,
        content: crate::SnackbarParams<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3Snackbar::new_with(p, content, cx, &pack))
    }

    /// A determinate linear progress bar of `width`; `value` is `0.0..=1.0`.
    /// 宽 `width` 的确定态线性进度条；`value` 取 `0.0..=1.0`。
    pub fn progress_indicator(
        &self,
        id: ui_core::Id,
        value: f32,
        width: f32,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3ProgressIndicator::new_with(p, id, width, value, cx, &pack))
    }

    /// The same bar with no value: it sweeps on its own clock until the app has one.
    /// 同一个条但没有数值：在应用拿到数值之前按自己的时钟扫动。
    pub fn progress_indicator_indeterminate(
        &self,
        id: ui_core::Id,
        width: f32,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3ProgressIndicator::indeterminate_with(p, id, width, cx, &pack))
    }

    /// A `size` ring showing `value`: a track, then an arc from twelve o'clock.
    /// 一个 `size` 大小、显示 `value` 的圆环：轨道，再加一段从十二点起的弧。
    pub fn progress_ring(
        &self,
        id: ui_core::Id,
        size: f32,
        value: f32,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3ProgressIndicator::ring_with(p, id, size, value, cx, &pack))
    }

    /// A `size` ring with no value: its arc grows, travels and shrinks on its own clock.
    /// 一个 `size` 大小、没有数值的圆环：弧按自己的时钟长大、行进、收回。
    pub fn progress_ring_indeterminate(
        &self,
        id: ui_core::Id,
        size: f32,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        Box::new(crate::Md3ProgressIndicator::ring_indeterminate_with(p, id, size, cx, &pack))
    }
}

impl Default for Md3Kit {
    fn default() -> Self {
        Self::new()
    }
}

impl StyleKit for Md3Kit {
    fn slider(
        &self,
        spec: &ui_style::SliderSpec<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        self.slider_sized(
            spec.id,
            spec.value,
            crate::SLIDER_WIDTH,
            crate::spec::SliderSize::XSmall,
            cx,
        )
    }

    fn toggle(
        &self,
        spec: &ui_style::ToggleSpec<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        let node = cx.at(spec.id);
        let mut ctx = node;
        Box::new(Md3Toggle::new_with(
            p,
            spec.id,
            spec.on,
            &mut ctx,
            &pack,
        ))
    }

    fn scaffold(
        &self,
        spec: &ScaffoldSpec<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        Box::new(cx.with_cx(|cx| Md3Scaffold::new(spec, cx)))
    }
}

