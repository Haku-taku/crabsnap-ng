//! MD3 radio button, rebuilt from Flutter's `_RadioPainter`: a 20dp ring whose colour is the
//! mark, and an inner dot that grows out of the centre with the selection.
//! MD3 单选框，按 Flutter `_RadioPainter` 重建：20dp 圆环，环色即标记色；
//! 内点随选中从中心长出。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Rect};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::{AnimSpec, CursorShape, Decl, Easing, Id, NodeKind, Sense};
use ui_style::Style;
use ui_widgets::build::param;
use ui_widgets::{Cx, NodeCx, Widget, WidgetState};

use crate::layer::state_disc;
use crate::spec::{radio_button_spec, RadioButtonSpec};
use crate::toggle::{between, spec_ink};
use crate::Md3Options;

/// The unselected state; its `icon.size` is the ring's outer diameter.
/// 未选中态；其 `icon.size` 就是圆环外径。
const OFF: RadioButtonSpec = radio_button_spec(false, false, false, false, false);

/// `icon.size`: the ring's outer diameter.
/// `icon.size`：圆环外径。
pub const RING: f32 = OFF.icon.size;
/// The export carries no ring width; Flutter's M3 default side is 2dp.
/// 导出里没有环宽；Flutter 的 M3 默认描边是 2dp。
pub(crate) const STROKE: f32 = 2.0;
/// Flutter's `_kInnerRadius`; the dot's radius at full selection.
/// Flutter 的 `_kInnerRadius`；完全选中时内点的半径。
pub const DOT_RADIUS: f32 = 4.5;
/// `MaterialTapTargetSize.padded`: the ring sits in a 48dp target.
/// `MaterialTapTargetSize.padded`：圆环放在 48dp 触控区里。
pub(crate) const TOUCH: f32 = 48.0;

/// The position clock. The export carries no duration; Flutter animates the toggleable
/// position linearly, and the dot's radius is linear in it.
/// 位置时钟。导出不带时长；Flutter 的开关位置是线性动画，内点半径对它是线性的。
const SELECT_MS: f32 = 0.2;
const SELECT: AnimSpec = AnimSpec::new(SELECT_MS, Easing::Linear);

/// One MD3 radio button; every animation is advanced in `new_with`, so `decl` stays pure.
/// 一个 MD3 单选框；所有动画都在 `new_with` 里推进，因此 `decl` 是纯函数。
pub struct Md3Radio {
    id: Id,
    ring: Color,
    /// The inner dot's colour and radius, painted only once the selection has begun.
    /// 内点的颜色与半径，只在选中开始后绘制。
    dot: Option<(Color, f32)>,
    /// The state-layer disc: colour and radius.
    /// 状态层圆盘：颜色与半径。
    layer: Option<(Color, f32)>,
    semantic_on: bool,
    disabled: bool,
}

impl Md3Radio {
    /// The unprefixed form: constants only, as a direct caller expects.
    /// 无参数版本：只用常量，直接调用方会这样用。
    pub fn new(
        id: Id,
        selected: bool,
        ctx: &mut NodeCx<'_>,
        pack: &Style,
    ) -> Self {
        Self::new_with(Md3Options::default(), id, selected, ctx, pack)
    }

    /// Same control with explicit parameters, so the semantic path and a direct caller
    /// produce identical `Decl`s. 带显式参数的同一控件，使语义路径与直接调用产出相同的 Decl。
    pub fn new_with(
        params: Md3Options,
        id: Id,
        selected: bool,
        ctx: &mut NodeCx<'_>,
        pack: &Style,
    ) -> Self {
        let state = ctx.state();
        let disabled = state.disabled || params.disabled;
        let position = ctx.animate(
            id.with(param::PROGRESS),
            if selected { 1.0 } else { 0.0 },
            SELECT,
        );

        // Both states read one `icon.color`, and the ring *is* the mark, so the colour lerps
        // across the whole travel rather than switching at a threshold.
        // 两个状态都只读一个 `icon.color`，而环本身就是标记，故颜色在整段行程上插值，
        // 而不是在某个阈值处切换。
        let lit = state.hovered || state.focus_visible;
        let on = radio_button_spec(true, lit, state.focus_visible, state.pressed, disabled);
        let off = radio_button_spec(false, lit, state.focus_visible, state.pressed, disabled);
        let ring = between(
            spec_ink(pack, off.icon.color, off.icon.opacity),
            spec_ink(pack, on.icon.color, on.icon.opacity),
            position,
        );
        // `drawCircle(center, innerRadius * position.value)`: the dot grows from nothing.
        // `drawCircle(center, innerRadius * position.value)`：内点从无到有地长大。
        let dot = (position > 0.0).then_some((ring, DOT_RADIUS * position));

        let layer = state_disc(ctx, id, OFF.state_layer.size, disabled, state.pressed, |hovered, focused, pressed| {
            let s = radio_button_spec(selected, hovered, focused, pressed, disabled);
            spec_ink(pack, s.state_layer.color, s.state_layer.opacity)
        });

        Self {
            id,
            ring,
            dot,
            layer,
            semantic_on: selected,
            disabled,
        }
    }
}

impl Widget for Md3Radio {
    fn handles_disabled(&self) -> bool {
        // The token table paints disabled (38%) itself; the adapter must not fade again.
        // 令牌表已自行按 38% 画禁用；适配器不得再淡化一次。
        true
    }

    fn change(&self, state: &WidgetState, _bounds: Rect) -> Option<ui_core::Change> {
        // A radio that is already selected has nothing to report: the group is unchanged.
        // 已选中的单选框无事可报：整组选择没有变化。
        if self.disabled || !state.activation() || self.semantic_on {
            return None;
        }
        Some(ui_core::Change::Selected(Some(self.id)))
    }

    fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
        let origin = (TOUCH - RING) * 0.5;
        let mut shapes = Vec::with_capacity(3);
        if let Some((colour, radius)) = self.layer {
            shapes.push(Shape::Rect {
                rect: Rect::new(
                    TOUCH * 0.5 - radius,
                    TOUCH * 0.5 - radius,
                    radius * 2.0,
                    radius * 2.0,
                ),
                corners: Corners::all(radius),
                fill: colour,
                gradient: None,
                border: None,
            });
        }
        // The ring is an inward border on a 20dp circle, so the mark never grows the control.
        // 圆环是 20dp 圆上的向内描边，标记因此永不撑大控件。
        shapes.push(Shape::Rect {
            rect: Rect::new(origin, origin, RING, RING),
            corners: Corners::all(RING * 0.5),
            fill: Color::TRANSPARENT,
            gradient: None,
            border: Some((self.ring, STROKE)),
        });
        if let Some((colour, radius)) = self.dot {
            shapes.push(Shape::Rect {
                rect: Rect::new(
                    TOUCH * 0.5 - radius,
                    TOUCH * 0.5 - radius,
                    radius * 2.0,
                    radius * 2.0,
                ),
                corners: Corners::all(radius),
                fill: colour,
                gradient: None,
                border: None,
            });
        }
        Decl::container(self.id, NodeKind::Box)
            .size(SizeClass {
                width: AxisSize::fixed(TOUCH),
                height: AxisSize::fixed(TOUCH),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            // The radio takes hover, click and focus; its shapes take nothing.
            // 单选框接受悬停、点击与焦点；它的形状不接受任何交互。
            .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
            .cursor(if self.disabled {
                CursorShape::Arrow
            } else {
                CursorShape::PointingHand
            })
            .disabled(self.disabled)
            .shapes(shapes)
    }
}
