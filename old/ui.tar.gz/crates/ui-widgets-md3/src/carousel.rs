//! MD3 carousel: a strip of items that change size as they pass the leading edge.
//! MD3 轮播：一条条带，条目越前缘时改变尺寸。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Corners, Insets};
use ui_core::layout::{AxisSize, Clip, Grow, Overflow, SizeClass, AUTO};
use ui_core::tree::ShadowSpec;
use ui_core::{AnimSpec, Change, CursorShape, Decl, Easing, Id, InkRadius, NodeKind, PressInk, Sense};
use ui_style::Style;
use ui_widgets::build::param;
use ui_widgets::{Cx, Widget, WidgetState};

use crate::layer::press_ink_shape;
use crate::spec::carousel_item_spec;
use crate::toggle::{role, spec_ink};
use crate::Md3Options;

/// MD3's gutter: 16dp at the container's edges, 8dp above and below the strip.
/// MD3 的边距：容器两侧 16dp，条带上下 8dp。
pub const CAROUSEL_PAD: f32 = 16.0;
/// Top/bottom gutter of a horizontal carousel.
/// 横向轮播上下两侧的边距。
pub const CAROUSEL_VPAD: f32 = 8.0;
/// Space between two items in every layout but full-screen.
/// 除全屏外，各布局的条目间距。
pub const CAROUSEL_GAP: f32 = 8.0;
/// Full-screen carousels drop the gutter and separate items by 16dp.
/// 全屏轮播没有边距，条目间距 16dp。
pub const CAROUSEL_FULL_GAP: f32 = 16.0;
/// `rounded_corners` in the export, 28dp on the MD3 shape scale.
/// 导出里写作 `rounded_corners`，MD3 形状刻度上为 28dp。
pub const CAROUSEL_RADIUS: f32 = 28.0;
/// MD3's small-item width range, in dp.
/// MD3 小号条目的宽度范围，单位 dp。
pub const CAROUSEL_SMALL: (f32, f32) = (40.0, 56.0);

/// `kRadialReactionDuration`, shared by hover and focus.
/// `kRadialReactionDuration`，悬停与焦点共用。
const REACTION: AnimSpec = AnimSpec::new(0.1, Easing::Linear);

/// The five layouts MD3 names; each fixes its strip geometry at build time.
/// MD3 给出的五种布局；每种都在构建期固定条带几何。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CarouselKind {
    /// A large, a medium and a small item, the leading one largest.
    /// 大、中、小三件同屏，前缘那件最大。
    MultiBrowse,
    /// One large item with a small one peeking in from the trailing edge.
    /// 一件大条目，尾缘露出小条目的一角。
    Hero,
    /// A large item centred between two small ones.
    /// 大条目居中，两侧各一件小条目。
    HeroCentered,
    /// Items keep one size and run off the edges.
    /// 条目尺寸不变，从两侧滑出。
    Uncontained,
    /// One edge-to-edge item at a time, scrolling vertically.
    /// 一次一件、贴边，纵向滚动。
    FullScreen,
}

impl CarouselKind {
    /// The relative widths that fill one page, from the leading edge backwards.
    /// 填满一页的相对宽度，从前缘往后排列。
    ///
    /// These come from Flutter's weighted carousel; the export sizes nothing but the gaps
    /// and the small range, so the ratios are what turn a width into item extents.
    /// 取自 Flutter 的加权轮播；导出只给了间距与小号范围，
    /// 比例才是把容器宽度变成条目宽度的东西。
    pub fn weights(self) -> &'static [u32] {
        match self {
            Self::MultiBrowse => &[3, 2, 1],
            Self::Hero => &[7, 1],
            Self::HeroCentered => &[1, 5, 1],
            Self::Uncontained | Self::FullScreen => &[1],
        }
    }

    /// Whether items resize as the strip scrolls.
    /// 条目是否随条带滚动改变尺寸。
    pub fn shrinking(self) -> bool {
        matches!(self, Self::MultiBrowse | Self::Hero | Self::HeroCentered)
    }

    /// Whether the strip runs vertically.
    /// 条带是否纵向排列。
    pub fn vertical(self) -> bool {
        matches!(self, Self::FullScreen)
    }

    fn gap(self) -> f32 {
        if self.vertical() {
            CAROUSEL_FULL_GAP
        } else {
            CAROUSEL_GAP
        }
    }

    /// The gutter the container insets its strip by; uncontained items bleed over it.
    /// 容器为条带让出的边距；非受限布局的条目会漫过它。
    fn gutter(self) -> (f32, f32) {
        if self.shrinking() {
            (CAROUSEL_PAD, CAROUSEL_VPAD)
        } else {
            (0.0, 0.0)
        }
    }
}

/// One slot of the strip this frame: which item, where it starts, and how far it runs.
/// 本帧条带上的一个槽位：哪一项、从哪里开始，以及延伸多远。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct CarouselSlot {
    pub index: usize,
    /// Distance from the strip's leading edge to this item's, in dp.
    /// 从条带前缘到这一件前缘的距离，单位 dp。
    pub offset: f32,
    pub extent: f32,
}

/// The id of the strip a carousel scrolls, for an app that reads or sets its offset.
/// 轮播滚动的条带 id，供需要读取或设置偏移的应用使用。
pub fn carousel_strip_id(id: Id) -> Id {
    id.with("strip")
}

/// The weights in play: a strip with fewer items than weights uses the first ones.
/// 实际生效的权重：条目少于权重时取前几个。
fn active_weights(kind: CarouselKind, count: usize) -> &'static [u32] {
    let all = kind.weights();
    &all[..all.len().min(count.max(1))]
}

/// What one unit of weight covers, with the gaps between a page's items taken out first.
/// 一个权重单位覆盖多宽，先扣掉一页之内条目之间的间距。
fn extent_unit(kind: CarouselKind, usable: f32, count: usize) -> f32 {
    let w = active_weights(kind, count);
    if !kind.shrinking() || usable <= 0.0 {
        return 0.0;
    }
    let sum: u32 = w.iter().sum();
    let gaps = kind.gap() * w.len().saturating_sub(1) as f32;
    ((usable - gaps) / sum as f32).max(0.0)
}

/// The width one page of a weighted layout gives its leading slot: one unit of its weight.
/// 加权布局一页给前缘槽位的宽度：一个权重单位。
fn leading_extent(kind: CarouselKind, usable: f32, count: usize) -> f32 {
    let w = active_weights(kind, count);
    w.first().copied().unwrap_or(0) as f32 * extent_unit(kind, usable, count)
}

/// How far one page moves the strip: one widest item, not the leading slot — a centred hero
/// leads with a small one, and that slot as a page would rush the whole strip past.
/// 一页让条带前进多远：一个最宽条目，而不是前缘槽位——居中英雄以小条目领先，
/// 把那个槽位当一页，整条条带就会一晃而过。
pub fn carousel_page(kind: CarouselKind, usable: f32, count: usize) -> f32 {
    let w = active_weights(kind, count);
    let widest = w.iter().copied().max().unwrap_or(0);
    widest as f32 * extent_unit(kind, usable, count)
}

/// How many leading weights sit before the first maximum one.
/// 第一个最大权重之前还有几个权重。
///
/// Such a strip expands its first item to the maximum weight, leaving that much space
/// before it — which is what centres a hero item.
/// 这类条带把首件撑到最大权重，并在它之前留下这么多空档——英雄条目因此居中。
fn leading_smaller(kind: CarouselKind, count: usize) -> usize {
    let w = active_weights(kind, count);
    let max = w.iter().copied().max().unwrap_or(0);
    w.iter().take_while(|weight| **weight != max).count()
}

/// The last page that still lays its items out from the leading edge.
/// 仍从前缘锚排布条目的最后一页。
fn last_full_page(kind: CarouselKind, count: usize) -> usize {
    let k = active_weights(kind, count).len();
    (count + leading_smaller(kind, count)).saturating_sub(k)
}

/// How many pages a strip spends walking its widest weight to the last slot.
/// 条带为把最宽的一格挪到末位所花的页数。
///
/// Each step hands the focal role to the next item, so every item takes its turn as the
/// widest one before the strip ends; a pattern that already ends wide needs no step.
/// 每一步把焦点角色交给下一件，因此收尾之前每一件都轮到过最宽；
/// 末位已是最宽的花样不需要这一步。
fn turning_pages(kind: CarouselKind, count: usize) -> usize {
    if !kind.shrinking() {
        return 0;
    }
    let w = active_weights(kind, count);
    w.len() - 1 - leading_smaller(kind, count)
}

/// The weights after `step` turns: the trailing weights move in front of the widest one.
/// 掉头 `step` 步之后的权重：尾部的权重逐个挪到最宽那一格之前。
fn turned_weights(w: &[u32], step: usize) -> Vec<u32> {
    let max = w.iter().copied().max().unwrap_or(0);
    let at = w.iter().position(|weight| *weight == max).unwrap_or(0);
    let tail = &w[at + 1..];
    let step = step.min(tail.len());
    let mut out = Vec::with_capacity(w.len());
    out.extend_from_slice(&w[..at]);
    out.extend(tail.iter().rev().take(step));
    out.push(max);
    out.extend_from_slice(&tail[step..]);
    out
}

/// The width a fixed-size layout gives each item: the large width, or the viewport when it
/// runs vertically.
/// 固定尺寸布局给每件的宽度：大条目宽度；纵向时取视口。
fn fixed_extent(kind: CarouselKind, usable: f32, large: f32) -> f32 {
    if kind.vertical() {
        usable
    } else {
        large.max(1.0)
    }
}

/// The gutter a horizontal fixed-size strip keeps in front of its first item.
/// 横向固定尺寸条带在首件之前留出的边距。
fn fixed_lead(kind: CarouselKind) -> f32 {
    if kind.vertical() {
        0.0
    } else {
        CAROUSEL_PAD
    }
}

/// The strip's full content length: what the scroller clamps against, minus the viewport.
/// 条带的完整内容长度：滚动容器据此钳位，再减去视口。
///
/// It ends where the last item's trailing edge does, so the clamp lands flush at the end.
/// 它止于最后一件的尾缘，钳位因此正好停在末端、右缘贴齐。
pub fn carousel_content(kind: CarouselKind, usable: f32, count: usize, large: f32) -> f32 {
    if count == 0 || usable <= 0.0 {
        return 0.0;
    }
    if kind.shrinking() {
        return usable + carousel_max_scroll(kind, usable, count, large);
    }
    let gaps = kind.gap() * count.saturating_sub(1) as f32;
    fixed_lead(kind) + count as f32 * fixed_extent(kind, usable, large) + gaps
}

/// The furthest the strip may scroll: where its last item ends on the trailing edge.
/// 条带最多能滚多远：最后一件的尾缘正好落在后缘处。
pub fn carousel_max_scroll(kind: CarouselKind, usable: f32, count: usize, large: f32) -> f32 {
    if count == 0 || usable <= 0.0 {
        return 0.0;
    }
    if !kind.shrinking() {
        return (carousel_content(kind, usable, count, large) - usable).max(0.0);
    }
    // Every item takes a turn at the leading edge, so the strip ends one page short of
    // one page per item: the last page is where the widest weight reaches the last slot.
    // 每一件都会轮到前缘，因此条带止于“每件一页”少一页处：最后一页正是最宽一格落到末位的地方。
    (count - 1) as f32 * carousel_page(kind, usable, count)
}

/// The scroll at which `index` is the strip's widest item.
/// `index` 成为条带最宽一件时的滚动偏移。
///
/// The widest slot is the leading one, and one page hands it to the next item, so item `i`
/// holds it on page `i`; the turn walks it to the last item on the page that same item leads.
/// 最宽的槽位就是前缘槽位，一页把它交给下一件，因此第 `i` 件在第 `i` 页持有它；
/// 掉头把前缘走到最后一件，所用的也正是它领先的那一页。
pub fn carousel_offset_of(
    kind: CarouselKind,
    usable: f32,
    count: usize,
    index: usize,
    large: f32,
) -> f32 {
    if !kind.shrinking() {
        let lead = fixed_lead(kind) + index as f32 * (fixed_extent(kind, usable, large) + kind.gap());
        return lead.min(carousel_max_scroll(kind, usable, count, large));
    }
    let page = carousel_page(kind, usable, count);
    (index as f32 * page).min(carousel_max_scroll(kind, usable, count, large))
}

/// How far one page press moves the strip: a page for a weighted layout, an item for a fixed
/// one.
/// 一次翻页移动的距离：加权布局是一页，固定布局是一件。
pub fn carousel_step(kind: CarouselKind, usable: f32, count: usize, large: f32) -> f32 {
    if kind.shrinking() {
        carousel_page(kind, usable, count)
    } else {
        fixed_extent(kind, usable, large) + kind.gap()
    }
}

/// How far one full pass of the items covers: the period a looped strip repeats on.
/// 全部条目走一遍的距离：循环条带据此重复。
pub fn carousel_cycle(kind: CarouselKind, usable: f32, count: usize, large: f32) -> f32 {
    if count == 0 || usable <= 0.0 {
        return 0.0;
    }
    count as f32 * carousel_step(kind, usable, count, large)
}

/// Passes a looped strip lays out: an end that is never reached on a canvas that needs one,
/// and few enough that item positions stay inside f32's exact range.
/// 循环条带铺开的遍数：画布必须有尽头，而它到不了；又少到条目位置仍在 f32 精确范围内。
const LOOP_PASSES: usize = 101;

/// The canvas a looped strip is laid out on, and the furthest it may scroll.
/// 循环条带铺开的画布，以及它最多能滚多远。
pub fn carousel_looped_content(kind: CarouselKind, usable: f32, count: usize, large: f32) -> f32 {
    let cycle = carousel_cycle(kind, usable, count, large);
    (cycle * LOOP_PASSES as f32).max(cycle + usable)
}

pub fn carousel_looped_max(kind: CarouselKind, usable: f32, count: usize, large: f32) -> f32 {
    (carousel_looped_content(kind, usable, count, large) - usable).max(0.0)
}

/// Where a looped strip starts: the middle pass, so it can travel both ways from the first
/// frame.
/// 循环条带起步的位置：正中间那一遍，因此第一帧起就能往两边走。
pub fn carousel_looped_start(kind: CarouselKind, usable: f32, count: usize, large: f32) -> f32 {
    carousel_cycle(kind, usable, count, large) * (LOOP_PASSES / 2) as f32
}

/// The scroll that puts `index` in the middle of the viewport, or as near as the strip gets,
/// chosen among the copies of it nearest `near`.
/// 把 `index` 放到视口正中的滚动偏移；条带到不了正中时取最接近的位置，
/// 并从离 `near` 最近的那一份里挑。
pub fn carousel_centre_of(
    kind: CarouselKind,
    usable: f32,
    count: usize,
    index: usize,
    near: f32,
    large: f32,
    looped: bool,
) -> f32 {
    if count == 0 || usable <= 0.0 || index >= count {
        return 0.0;
    }
    let step = carousel_step(kind, usable, count, large);
    let max = if looped {
        carousel_looped_max(kind, usable, count, large)
    } else {
        carousel_max_scroll(kind, usable, count, large)
    };
    if step <= 0.0 {
        return 0.0;
    }
    // The item reaches the middle during the page before it leads, so that page is the whole
    // search range; a looped strip takes the copy one pass along so the range stays inside.
    // 条目在它领先的前一页里经过正中，因此那一页就是全部搜索范围；
    // 循环条带取后一遍的那一份，范围因此留在画布内。
    let pass = if looped { carousel_cycle(kind, usable, count, large) } else { 0.0 };
    let lead = (index + leading_smaller(kind, count)) as f32 * step + pass;
    let lo = (lead - step).max(0.0);
    let hi = lead.min(max).max(lo);
    let half = usable / 2.0;
    let centre = |at: f32| -> f32 {
        slots_at(kind, usable, count, at, large, looped)
            .iter()
            .find(|slot| slot.index == index)
            .map_or(if at < lead { f32::INFINITY } else { f32::NEG_INFINITY }, |slot| {
                slot.offset + slot.extent / 2.0
            })
    };
    // The item reaches the middle somewhere in that page; when it cannot (a strip end holds
    // it short), the nearest end of the range is the answer.
    // 条目在那一页之内经过正中；到不了时（条带的尽头把它拦住），范围里最近的那一端就是答案。
    let found = if centre(lo) <= half {
        lo
    } else if centre(hi) >= half {
        hi
    } else {
        let (mut a, mut b) = (lo, hi);
        for _ in 0..24 {
            let mid = (a + b) / 2.0;
            if centre(mid) > half {
                a = mid;
            } else {
                b = mid;
            }
        }
        (a + b) / 2.0
    };
    if looped {
        // The layout repeats every pass, so any copy of the answer is the same view.
        // 布局每一遍都重复，因此答案的哪一份都是同一幅画面。
        let cycle = carousel_cycle(kind, usable, count, large);
        found + ((near - found) / cycle).round() * cycle
    } else {
        found
    }
}

/// The slots that reach the viewport at `scroll`, in paint order.
/// 在 `scroll` 处进入视口的槽位，按绘制顺序排列。
///
/// A weighted strip shrinks its leading item away; its last page turns the pattern around,
/// so it can end on its widest item. A fixed one keeps every item and slides the strip.
/// 加权条带的前缘条目收窄退场，最后一页把花样掉头，因此能以最宽的一件收尾；
/// 固定条带则每件不变，整体平移。
pub fn carousel_slots(
    kind: CarouselKind,
    usable: f32,
    count: usize,
    scroll: f32,
    large: f32,
) -> Vec<CarouselSlot> {
    slots_at(kind, usable, count, scroll, large, false)
}

/// The slots of a strip that repeats its items for ever, so it has no first or last one.
/// 无限重复条目的条带上的槽位：它没有第一件，也没有最后一件。
pub fn carousel_slots_looped(
    kind: CarouselKind,
    usable: f32,
    count: usize,
    scroll: f32,
    large: f32,
) -> Vec<CarouselSlot> {
    slots_at(kind, usable, count, scroll, large, true)
}

fn slots_at(
    kind: CarouselKind,
    usable: f32,
    count: usize,
    scroll: f32,
    large: f32,
    looped: bool,
) -> Vec<CarouselSlot> {
    if count == 0 || usable <= 0.0 {
        return Vec::new();
    }
    let max = if looped {
        carousel_looped_max(kind, usable, count, large)
    } else {
        carousel_max_scroll(kind, usable, count, large)
    };
    let scroll = scroll.clamp(0.0, max);
    if !kind.shrinking() {
        let extent = fixed_extent(kind, usable, large);
        let lead = fixed_lead(kind);
        let step = extent + kind.gap();
        // Every item keeps its place on the canvas, so the whole strip slides by `scroll`.
        // 每件在画布上的位置不变，整条条带因此随 `scroll` 平移。
        if !looped {
            return (0..count)
                .map(|index| CarouselSlot { index, offset: lead + index as f32 * step - scroll, extent })
                .collect();
        }
        // A looped strip only needs the items the viewport can reach; the rest repeat.
        // 循环条带只需视口够得着的几件，其余重复即可。
        let mut slots = Vec::new();
        let mut i = ((scroll - lead) / step).floor() as i64 - 1;
        loop {
            let offset = lead + i as f32 * step - scroll;
            if offset >= usable {
                break;
            }
            if offset + extent > 0.0 {
                slots.push(CarouselSlot { index: i.rem_euclid(count as i64) as usize, offset, extent });
            }
            i += 1;
        }
        return slots;
    }
    let w = active_weights(kind, count);
    let k = w.len();
    let unit = extent_unit(kind, usable, count);
    let first = leading_extent(kind, usable, count);
    let pitch = carousel_page(kind, usable, count);
    if unit <= 0.0 || first <= 0.0 || pitch <= 0.0 {
        return Vec::new();
    }
    if !looped {
        let steps = turning_pages(kind, count);
        let start = last_full_page(kind, count) as f32 * pitch;
        if steps > 0 && scroll >= start - 0.01 {
            // The turn is one page per step, so a strip whose widest weight is already last
            // has none, and a leading-anchored one takes as many as it has weights behind it.
            // 掉头每步一页：最宽一格已在末位的条带没有掉头，锚前缘的条带有几格就掉几步。
            let walked = ((scroll - start) / pitch).clamp(0.0, steps as f32);
            let step = (walked.floor() as usize).min(steps - 1);
            return turned_slots(kind, usable, count, step, walked - step as f32);
        }
    }
    let max_weight = w.iter().copied().max().unwrap_or(1) as f32;
    let max_extent = max_weight * unit;
    let page = (scroll / pitch).floor();
    let progress = (scroll - page * pitch) / pitch;
    // The leading slot may be a phantom before item 0: a centred hero expands its first
    // item into the maximum weight and leaves that much space in front of it.
    // 前缘槽位可能是第 0 件之前的空位：居中的英雄把首件撑到最大权重，并在它前面留下同样多的空档。
    let head = page as i64 - leading_smaller(kind, count) as i64;
    let mut slots = Vec::with_capacity(k + 1);
    let mut cursor = 0.0_f32;
    for j in 0.. {
        if cursor >= usable - 0.01 {
            break;
        }
        // A slot owns the gap behind it; the card is what the slot has left. The leading
        // slot shrinks whole, so its pad stays a pad until the card is gone.
        // 槽位连同它身后的间距一起算；卡片是槽位扣掉间距剩下的部分。前缘槽位整体收拢，
        // 因此卡片消失之前，它的间距始终是完整的间距。
        let (extent, slot) = if j == 0 {
            let slot = (first + kind.gap()) * (1.0 - progress);
            ((slot - kind.gap()).max(0.0), slot)
        } else if j < k {
            let weight = w[j] as f32;
            // The item behind the leading one grows toward the weight in front of it, so
            // the two meet when the page turns.
            // 前缘之后的那一件朝着前面的权重长大，翻页时两者正好接上。
            let extent =
                weight * unit + (w[j - 1] as f32 - weight) / max_weight * progress * max_extent;
            (extent, extent + kind.gap())
        } else {
            // Past the weights, an item only fills what the viewport has left.
            // 超出权重表之后，条目只填视口剩下的那一段。
            let extent = (usable - cursor).max(0.0);
            (extent, extent)
        };
        let index = head + j as i64;
        let within = index >= 0 && (index as usize) < count;
        if extent > 0.0 && (looped || within) {
            let index = if looped { index.rem_euclid(count as i64) } else { index };
            slots.push(CarouselSlot { index: index as usize, offset: cursor, extent });
        }
        cursor += slot;
    }
    slots
}

/// One step of the turn: the sizes trade places as the widest weight walks to the last slot,
/// keeping the page exactly full, so the strip ends wide and flush.
/// 掉头的一步：最宽的一格走向末位、两端尺寸易位，整页始终是满的，
/// 条带因此以最宽的一件贴齐收尾。
fn turned_slots(kind: CarouselKind, usable: f32, count: usize, step: usize, t: f32) -> Vec<CarouselSlot> {
    let w = active_weights(kind, count);
    let from_w = turned_weights(w, step);
    let to_w = turned_weights(w, step + 1);
    let k = w.len();
    let unit = extent_unit(kind, usable, count);
    let mut slots = Vec::with_capacity(k);
    let mut cursor = 0.0_f32;
    for j in 0..k {
        let from = from_w[j] as f32 * unit;
        let to = to_w[j] as f32 * unit;
        let extent = from + (to - from) * t;
        if extent > 0.0 {
            slots.push(CarouselSlot { index: count - k + j, offset: cursor, extent });
        }
        cursor += extent + kind.gap();
    }
    slots
}

/// One item: the id the app knows it by, and what it holds.
/// 一个条目：应用认识它的 id，以及它装的东西。
#[derive(Clone)]
pub struct CarouselItem {
    pub id: Id,
    pub content: Vec<Decl>,
    /// The export's `with-outline` state: a 1dp border around the item.
    /// 导出的 `with-outline` 状态：条目外加 1dp 描边。
    pub outlined: bool,
}

impl CarouselItem {
    pub fn new(id: Id, content: Vec<Decl>) -> Self {
        Self { id, content, outlined: false }
    }

    pub fn outlined(mut self) -> Self {
        self.outlined = true;
        self
    }
}

/// Everything a carousel is built with. Kind and size are fixed at build time.
/// 构建轮播所需的一切。布局与尺寸在构建期固定。
pub struct CarouselParams<'a> {
    pub id: Id,
    pub kind: CarouselKind,
    pub items: &'a [CarouselItem],
    pub width: f32,
    pub height: f32,
    /// The width a large item asks for in the fixed-size layouts.
    /// 固定尺寸布局里大条目想要的宽度。
    pub large: f32,
    /// Repeat the items for ever instead of ending on the last one.
    /// 无限重复条目，而不是在最后一件处收尾。
    pub infinite: bool,
}

/// The resolved surface of one item for this frame.
/// 某条目本帧解析出的表面。
struct Face {
    fill: Color,
    shadow: Option<ShadowSpec>,
    layer: Option<Color>,
    press: Option<PressInk>,
    outline: Option<(Color, f32)>,
    ring: Option<(Color, f32)>,
}

/// A carousel. Its offset lives in the engine, keyed by the strip's id, so each one scrolls
/// on its own and is clamped against its own content.
/// 一个轮播。偏移由引擎按条带 id 持有，因此各自滚动、各自按自己的内容钳位。
pub struct Md3Carousel {
    id: Id,
    kind: CarouselKind,
    width: f32,
    height: f32,
    large: f32,
    infinite: bool,
    items: Vec<CarouselItem>,
    faces: Vec<Face>,
    disabled: bool,
    /// The item whose press landed this frame.
    /// 本帧按下所落的条目。
    fired: Option<Id>,
}

impl Md3Carousel {
    pub fn new_with(
        params: Md3Options,
        content: CarouselParams<'_>,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let CarouselParams { id, kind, items, width, height, large, infinite } = content;
        let faces = items
            .iter()
            .map(|item| face(item, params.disabled, cx, pack))
            .collect::<Vec<_>>();
        let disabled = params.disabled || items.iter().any(|item| cx.state(item.id).disabled);
        let fired = items.iter().map(|item| item.id).find(|item| cx.state(*item).activation());
        Self { id, kind, width, height, large, infinite, items: items.to_vec(), faces, disabled, fired }
    }

    /// The layout this carousel was built as.
    /// 这个轮播构建时选定的布局。
    pub fn kind(&self) -> CarouselKind {
        self.kind
    }

    /// The width one page of scrolling covers, for an app that snaps.
    /// 一页滚动覆盖的距离，供需要吸附的应用使用。
    pub fn page(&self) -> f32 {
        carousel_page(self.kind, self.usable(), self.items.len())
    }

    /// The furthest this carousel can scroll.
    /// 这个轮播最多能滚多远。
    pub fn max_scroll(&self) -> f32 {
        let (usable, count) = (self.usable(), self.items.len());
        if self.infinite {
            carousel_looped_max(self.kind, usable, count, self.large)
        } else {
            carousel_max_scroll(self.kind, usable, count, self.large)
        }
    }

    /// The scroll that brings item `index` into the middle of the viewport, from `near`.
    /// 把第 `index` 件带到视口正中的滚动偏移，从 `near` 出发取最近的那一份。
    pub fn centre_scroll(&self, index: usize, near: f32) -> f32 {
        carousel_centre_of(
            self.kind,
            self.usable(),
            self.items.len(),
            index,
            near,
            self.large,
            self.infinite,
        )
    }

    fn usable(&self) -> f32 {
        if self.kind.vertical() {
            self.height
        } else if self.kind.shrinking() {
            (self.width - 2.0 * CAROUSEL_PAD).max(0.0)
        } else {
            self.width
        }
    }

    /// Move the strip at once, along its own axis.
    /// 沿条带自己的轴立即移动它。
    fn jump(&self, cx: &Cx<'_, '_>, strip: Id, at: f32) {
        if self.kind.vertical() {
            cx.core().set_scroll(strip, 0.0, at);
        } else {
            cx.core().set_scroll(strip, at, 0.0);
        }
    }

    /// Move the strip under the engine's spring, along its own axis.
    /// 借引擎的弹簧沿条带自己的轴移动它。
    fn settle(&self, cx: &Cx<'_, '_>, strip: Id, at: f32) {
        if self.kind.vertical() {
            cx.core().scroll_to(strip, 0.0, at);
        } else {
            cx.core().scroll_to(strip, at, 0.0);
        }
    }

    fn item_decl(&self, slot: &CarouselSlot, inner: (f32, f32), scroll: f32) -> Decl {
        let face = &self.faces[slot.index];
        let item = &self.items[slot.index];
        let (w, h) = if self.kind.vertical() {
            (inner.0, slot.extent)
        } else {
            (slot.extent, inner.1)
        };
        // Slot offsets are measured from the viewport's leading edge; the canvas itself is
        // scrolled back by `scroll`, so the two add up to the item's place on the canvas.
        // 槽位偏移从视口前缘量起；画布自身被 `scroll` 往回推，两者相加才是条目在画布上的位置。
        let at = slot.offset + scroll;
        let placement = if self.kind.vertical() {
            Insets { left: 0.0, top: at, right: AUTO, bottom: AUTO }
        } else {
            Insets { left: at, top: 0.0, right: AUTO, bottom: AUTO }
        };
        let mut shapes = Vec::with_capacity(3);
        shapes.push(Shape::Box {
            corners: Corners::all(CAROUSEL_RADIUS),
            fill: face.fill,
            gradient: None,
            border: face.outline,
            shadow: face.shadow,
            image: None,
        });
        if let Some(layer) = face.layer {
            shapes.push(Shape::Box {
                corners: Corners::all(CAROUSEL_RADIUS),
                fill: layer,
                gradient: None,
                border: None,
                shadow: None,
                image: None,
            });
        }
        // The export puts the ring `focus.indicator.outline.offset` outside the item; it is
        // drawn on the item's edge instead, since the decl cannot know the final rect.
        // 导出要求焦点环外移 `focus.indicator.outline.offset`；改为画在条目边缘，
        // 因为声明阶段拿不到最终矩形。
        if let Some((ink, width)) = face.ring {
            shapes.push(Shape::Box {
                corners: Corners::all(CAROUSEL_RADIUS),
                fill: Color::TRANSPARENT,
                gradient: None,
                border: Some((ink, width)),
                shadow: None,
                image: None,
            });
        }
        Decl::container(item.id, NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fixed(w),
                height: AxisSize::fixed(h),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .absolute()
            .inset(placement)
            .shapes(shapes)
            // The item's own content must be cut to its rounded box, or a square child
            // fill paints over the 28dp corners the item declares.
            // 条目自身的内容必须裁到它的圆角盒子，否则方角子填充会盖住声明的 28dp 圆角。
            .clip(Clip { x: Overflow::Hidden, y: Overflow::Hidden })
            .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
            .cursor(if self.disabled { CursorShape::Arrow } else { CursorShape::PointingHand })
            .disabled(self.disabled)
            .press_ink(face.press)
            .children(item.content.iter().cloned())
    }
}

/// Resolve one item's surface for this frame.
/// 解析某条目本帧的表面。
fn face(item: &CarouselItem, disabled: bool, cx: &mut Cx<'_, '_>, pack: &Style) -> Face {
    let mut node = cx.at(item.id);
    let state = node.state();
    let disabled = disabled || state.disabled;
    let rest = carousel_item_spec(item.outlined, state.hovered, state.focus_visible, state.pressed, disabled);
    let hover = carousel_item_spec(item.outlined, true, false, false, disabled);
    let focus = carousel_item_spec(item.outlined, false, true, false, disabled);
    let press = carousel_item_spec(item.outlined, false, false, true, disabled);
    let hover_t = node.animate(item.id.with(param::HOVER), f32::from(state.hovered), REACTION);
    let focus_t = node.animate(item.id.with(param::FOCUS), f32::from(state.focus_visible), REACTION);
    // The base state names no state layer; the ink lives on the state that has one.
    // 基态没有状态层；墨色取自带状态层的那一档。
    let layer_ink = role(pack, hover.state_layer.color);
    let strength = (hover_t * hover.state_layer.opacity).max(focus_t * focus.state_layer.opacity);
    let layer = (strength > 0.0 && !disabled)
        .then_some(Color { a: layer_ink.a * strength, ..layer_ink });
    // The background box is always the first shape the item paints, so the ripple binds
    // to that shape rather than to whatever the node happens to draw this frame.
    // 背景盒恒为条目绘制的第一个形状，涟漪因此绑定到该形状，而不是本帧碰巧画的东西。
    let ink = (!disabled).then(|| {
        press_ink_shape(
            Color { a: layer_ink.a * press.state_layer.opacity, ..layer_ink },
            InkRadius::Cover,
            0,
        )
    });
    let ring_t = node.animate(item.id.with(param::THICKNESS), f32::from(state.focus_visible), REACTION);
    let ring = (ring_t > 0.0 && !disabled).then(|| {
        (spec_ink(pack, rest.focus_indicator.color, ring_t), rest.focus_indicator.thickness)
    });
    Face {
        fill: spec_ink(pack, rest.container.color, rest.container.opacity),
        shadow: (rest.container.elevation > 0.0).then(|| {
            ShadowSpec::black(
                rest.container.elevation * 2.0,
                0.18,
                rest.container.elevation * 0.5,
            )
        }),
        layer,
        press: ink,
        outline: (rest.outline.width > 0.0 && !rest.outline.color.is_empty())
            .then(|| (spec_ink(pack, rest.outline.color, rest.outline.opacity), rest.outline.width)),
        ring,
    }
}

impl Widget for Md3Carousel {
    fn handles_disabled(&self) -> bool {
        // The export carries the disabled container itself, so the adapter must not fade again.
        // 导出自带禁用容器，适配器不得再淡化一次。
        true
    }

    fn change(&self, _state: &WidgetState, _bounds: ui_core::geom::Rect) -> Option<Change> {
        // The items are decls, so their own `change()` never runs; the carousel names the
        // one that was pressed or the app cannot tell one item from another.
        // 条目是声明，自己的 `change()` 从不执行；轮播必须指出被按下的是哪一件，
        // 否则应用分不清条目。
        self.fired.map(|id| Change::Selected(Some(id)))
    }

    fn decl(&self, cx: &Cx<'_, '_>) -> Decl {
        let (gx, gy) = self.kind.gutter();
        let inner = (
            (self.width - 2.0 * gx).max(0.0),
            (self.height - 2.0 * gy).max(0.0),
        );
        let usable = self.usable();
        let strip_id = carousel_strip_id(self.id);
        // The engine holds the offset and clamps it against the canvas's extent, so the
        // widget reads it rather than owning it.
        // 偏移由引擎持有、按画布范围钳位，因此控件读取它而不是持有它。
        let known = cx.core().scroll_of(strip_id);
        let mut offset = known
            .map(|g| if self.kind.vertical() { g.offset_y } else { g.offset_x })
            .unwrap_or(0.0);
        let count = self.items.len();
        // A looped strip starts on the middle pass so it can travel both ways; the first
        // frame still lays out at 0, where the engine is, not where it is about to be.
        // 循环条带从中段那一遍起步，两边都能走；第一帧仍按引擎所在的 0 排布，
        // 而不是按它即将到达的位置。
        if self.infinite {
            let cycle = carousel_cycle(self.kind, usable, count, self.large);
            let start = carousel_looped_start(self.kind, usable, count, self.large);
            if cycle > 0.0 {
                if known.is_none() {
                    self.jump(cx, strip_id, start);
                } else if offset < cycle {
                    offset += start;
                    self.jump(cx, strip_id, offset);
                }
            }
        }
        // The strip lays itself out at the offset it is allowed to reach; the engine adds its
        // own overscroll on top, and that difference is the rubber band.
        // 条带按它被允许到达的偏移排布；引擎再在其上叠加自己的越界量，这个差值就是橡皮筋。
        let max = if self.infinite {
            carousel_looped_max(self.kind, usable, count, self.large)
        } else {
            carousel_max_scroll(self.kind, usable, count, self.large)
        };
        let laid_out = offset.clamp(0.0, max);
        let (slots, content) = if self.infinite {
            let slots = carousel_slots_looped(self.kind, usable, count, laid_out, self.large);
            (slots, carousel_looped_content(self.kind, usable, count, self.large))
        } else {
            let slots = carousel_slots(self.kind, usable, count, laid_out, self.large);
            (slots, carousel_content(self.kind, usable, count, self.large))
        };
        // A press brings its item into the middle: the strip answers where the item sits,
        // not where the press landed.
        // 按下会把那一件带到正中：条带按条目所在的位置回答，而不是按按下的落点。
        if let Some(index) = self.fired.and_then(|id| self.items.iter().position(|it| it.id == id)) {
            let target = self.centre_scroll(index, offset);
            if (target - offset).abs() > 0.5 {
                self.settle(cx, strip_id, target);
            }
        }
        let strip_kind = if self.kind.vertical() { NodeKind::Column } else { NodeKind::Row };
        // Only the uncontained strip keeps a vertical gutter; the others already have one
        // from the container's padding, and full-screen has none at all.
        // 只有非受限条带自带纵向边距；其余布局的边距来自容器内衬，全屏则完全没有。
        let (inner, canvas_pad) = if self.kind.shrinking() || self.kind.vertical() {
            (inner, Insets::ZERO)
        } else {
            let pad = Insets { left: 0.0, top: CAROUSEL_VPAD, right: 0.0, bottom: CAROUSEL_VPAD };
            ((inner.0, (inner.1 - 2.0 * CAROUSEL_VPAD).max(0.0)), pad)
        };
        // The canvas is the one in-flow child, sized to the whole strip, and the items hang
        // off it out of flow: the scroller measures the canvas, so its clamp is our max.
        // 画布是唯一的流内子节点，尺寸等于整条条带，条目以流外方式挂在它上面：
        // 滚动容器量到的就是画布，其钳位因而正是我们的最大偏移。
        let canvas_size = if self.kind.vertical() {
            SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fixed(content),
                grow_x: Grow::No,
                grow_y: Grow::No,
            }
        } else {
            SizeClass {
                width: AxisSize::fixed(content),
                height: AxisSize::fill(0.0, 0.0),
                grow_x: Grow::No,
                grow_y: Grow::No,
            }
        };
        // Positioned, so the items hang off the canvas and travel with the strip: a static
        // parent would leave their containing block at the root.
        // 画布是定位祖先，条目因此挂在画布上、随条带一起移动：静态父节点会把包含块留在根上。
        let mut canvas = Decl::container(self.id.with("canvas"), NodeKind::Box)
            .size(canvas_size)
            .padding(canvas_pad)
            .relative();
        for slot in &slots {
            canvas = canvas.child(self.item_decl(slot, inner, laid_out));
        }
        let strip = Decl::container(strip_id, strip_kind)
            .size(SizeClass {
                width: AxisSize::fixed(inner.0),
                height: AxisSize::fixed(inner.1),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .scrollable()
            .sense(Sense::HOVER | Sense::SCROLL_OWNED)
            .cursor(if self.disabled { CursorShape::Arrow } else { CursorShape::Grab })
            .disabled(self.disabled)
            .child(canvas);
        Decl::container(self.id, NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fixed(self.width),
                height: AxisSize::fixed(self.height),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets { left: gx, top: gy, right: gx, bottom: gy })
            .disabled(self.disabled)
            .child(strip)
    }
}
