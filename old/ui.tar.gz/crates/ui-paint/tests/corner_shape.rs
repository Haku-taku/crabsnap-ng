//! Corner curve families: round, squircle, bevel, square.
//! 圆角曲线族：圆弧、超圆角、斜切、直角。
//!
//! These are presets on one continuous axis (`superellipse(k)` in CSS), not separate
//! kinds, so the tests check the *geometry* each k produces rather than a switch.
//! 它们是同一连续轴（CSS 的 `superellipse(k)`）上的预设而非独立种类，
//! 因此测试检查每个 k 产生的几何，而不是某个分支。

use ui_core::damage::Damage;
use ui_core::draw::{DrawList, RectPrim};
use ui_core::geom::{Color, CornerShape, Corners, Rect};
use ui_core::NodeId;
use ui_paint::{CpuRenderer, Pixels};

const SIDE: u32 = 40;
const RADIUS: f32 = 20.0;

/// Render one square with the given corner shape.
/// 按给定圆角形状渲染一个正方形。
fn render(shape: CornerShape) -> Pixels {
    let mut list = DrawList::new(Rect::new(0.0, 0.0, SIDE as f32, SIDE as f32));
    list.push_rect(
        NodeId::from_raw(1, 0),
        RectPrim {
            rect: Rect::new(0.0, 0.0, SIDE as f32, SIDE as f32),
            radius: Corners::all(RADIUS).with_shape(shape),
            fill: Color::WHITE,
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        },
    );
    let mut target = Pixels::new(SIDE, SIDE);
    CpuRenderer::new().render(&list, &mut target, &Damage::Full);
    target
}

fn alpha(p: &Pixels, x: u32, y: u32) -> u8 {
    p.data[((y * p.width + x) * 4 + 3) as usize]
}

/// Total coverage inside the top-left corner box.
/// 左上角盒内的覆盖度总和。
fn corner_area(p: &Pixels) -> u32 {
    let r = RADIUS as u32;
    (0..r)
        .map(|y| (0..r).map(|x| alpha(p, x, y) as u32).sum::<u32>())
        .sum()
}

#[test]
fn round_corner_is_a_circular_arc() {
    // The pixel centred at (14.5, 14.5) is 7.8px from the arc centre (20, 20), so it is
    // inside radius 20; the one at (1.5, 1.5) is 26.2px away and must be empty.
    // 中心 (14.5,14.5) 的像素距弧心 (20,20) 7.8px，在半径 20 内；
    // (1.5,1.5) 距 26.2px，必须为空。
    let p = render(CornerShape::ROUND);
    assert_eq!(alpha(&p, 14, 14), 255, "inside the arc must be filled");
    assert_eq!(alpha(&p, 1, 1), 0, "outside the arc must be empty");
}

#[test]
fn squircle_fills_more_of_the_corner_than_round() {
    // A higher exponent hugs the corner box more tightly, so a pixel the circle
    // excludes can still be inside the squircle.
    // 指数越高越贴近角盒，圆排除的像素可能仍在超圆角内部。
    let round = render(CornerShape::ROUND);
    let squircle = render(CornerShape::SQUIRCLE);
    // (4,4) is 15.5px from the arc centre: the circle needs 21.9px (outside), the
    // squircle needs 18.4px (comfortably inside).
    // (4,4) 距弧心 15.5px：圆需要 21.9px（在外），超圆角需要 18.4px（明确在内）。
    assert_eq!(alpha(&round, 4, 4), 0, "the circle excludes (4,4)");
    assert_eq!(alpha(&squircle, 4, 4), 255, "the squircle includes (4,4)");
    assert!(
        corner_area(&squircle) > corner_area(&round),
        "a squircle must fill more corner area than a circle"
    );
}

#[test]
fn bevel_cuts_the_corner_with_a_straight_line() {
    // `superellipse(0)` is the L1 ball: the boundary is |dx| + |dy| == radius, so the
    // diagonal is cut flat and everything beyond it is empty.
    // `superellipse(0)` 是 L1 球：边界为 |dx| + |dy| == radius，
    // 对角线被平切，切掉的部分为空。
    let bevel = render(CornerShape::BEVEL);
    let round = render(CornerShape::ROUND);
    assert_eq!(alpha(&bevel, 7, 7), 0, "the bevel removes (7,7)");
    assert_eq!(alpha(&round, 7, 7), 255, "the circle keeps (7,7)");
    assert!(
        corner_area(&bevel) < corner_area(&round),
        "a bevel removes more than a circle"
    );
}

#[test]
fn square_corner_is_not_rounded_at_all() {
    let square = render(CornerShape::SQUARE);
    assert_eq!(alpha(&square, 0, 0), 255, "the corner pixel stays filled");
    assert_eq!(
        corner_area(&square),
        (RADIUS as u32).pow(2) * 255,
        "a square corner fills its whole corner box"
    );
}

#[test]
fn corner_fill_increases_monotonically_with_k() {
    // The axis is continuous, so filled area must be monotonic in k; a step backwards
    // would mean the exponent mapping is wrong.
    // 该轴连续，填充面积必须随 k 单调；倒退说明指数映射有误。
    let areas: Vec<u32> = [
        CornerShape::BEVEL,
        CornerShape::ROUND,
        CornerShape::SQUIRCLE,
        CornerShape::from_k(4.0),
        CornerShape::SQUARE,
    ]
    .into_iter()
    .map(|s| corner_area(&render(s)))
    .collect();
    assert!(
        areas.windows(2).all(|w| w[0] < w[1]),
        "corner area must grow with k, got {areas:?}"
    );
}
