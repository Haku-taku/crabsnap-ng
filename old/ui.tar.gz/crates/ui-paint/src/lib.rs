//! CPU rasterizer: turns a `DrawList` into straight-alpha sRGB8 pixels.
//! CPU 光栅器：把 `DrawList` 变成预乘 sRGB8 像素。
//!
//! `zeno` supplies coverage only; compositing stays here so both future backends
//! share one blending definition.
//! `zeno` 只产出覆盖率；合成留在这里，使将来两条后端共享同一份混合定义。

use ui_core::effect::{ColorMatrix, Effect, Kernel};
use ui_core::draw::{Batch, DrawList, GlyphKind, PrimKind, RectPrim, TextPrim};
use ui_core::geom::{Color, Corners, Rect};
use ui_core::Damage;

/// A CPU pixel buffer, straight (non-premultiplied) sRGB8 in BGRA byte order.
/// CPU 像素缓冲，预乘 sRGB8（内存序为 BGRA）。
#[derive(Clone, Debug)]
pub struct Pixels {
    pub width: u32,
    pub height: u32,
    /// Premultiplied BGRA, `width * height * 4` bytes.
    /// 预乘 BGRA，`width * height * 4` 字节。
    pub data: Vec<u8>,
}

impl Pixels {
    pub fn new(width: u32, height: u32) -> Self {
        Self {
            width,
            height,
            data: vec![0; (width as usize) * (height as usize) * 4],
        }
    }

    pub fn clear(&mut self) {
        self.data.fill(0);
    }

    pub fn as_bgra(&self) -> &[u8] {
        &self.data
    }

    pub fn as_bytes(&self) -> &[u8] {
        &self.data
    }

    /// Read one pixel as straight sRGB.
    /// 读一个像素为直通 sRGB。
    pub fn get(&self, x: u32, y: u32) -> [u8; 4] {
        let i = ((y as usize) * (self.width as usize) + x as usize) * 4;
        [
            self.data[i + 2],
            self.data[i + 1],
            self.data[i],
            self.data[i + 3],
        ]
    }

    /// Fill the whole buffer with one straight-alpha colour.
    /// 用单一颜色填满整个缓冲。
    pub fn fill(&mut self, color: Color) {
        let c = Color::rgba(color.r, color.g, color.b, 1.0);
        for px in self.data.as_chunks_mut::<4>().0 {
            let mut tmp = [0u8; 4];
            blend_pixel(&mut tmp, c, 1.0);
            px.copy_from_slice(&tmp);
        }
    }

    /// Copy the region of `src` covered by `rect` into `self`.
    /// 把 `src` 中被 `rect` 覆盖的区域拷入 `self`。
    pub fn restore_region(&mut self, src: &Pixels, rect: Rect) {
        let (x0, y0, x1, y1) = clip_to(rect, self.width, self.height);
        let stride = self.width as usize * 4;
        for y in y0..y1 {
            let row = y as usize * stride;
            let a = row + x0 as usize * 4;
            let b = row + x1 as usize * 4;
            self.data[a..b].copy_from_slice(&src.data[a..b]);
        }
    }
}

fn clip_to(rect: Rect, w: u32, h: u32) -> (u32, u32, u32, u32) {
    let x0 = rect.min_x().floor().max(0.0) as u32;
    let y0 = rect.min_y().floor().max(0.0) as u32;
    let x1 = rect.max_x().ceil().clamp(0.0, w as f32) as u32;
    let y1 = rect.max_y().ceil().clamp(0.0, h as f32) as u32;
    (x0.min(w), y0.min(h), x1.min(w), y1.min(h))
}

/// Counters for diagnostics and tests.
/// 供诊断与测试的计数。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct RenderStats {
    pub batches: usize,
    pub rects: usize,
    pub texts: usize,
    pub glyphs: usize,
    /// Primitives this backend does not implement; GPU-only kinds land here.
    /// 本后端未实现的图元；只有 GPU 实现的种类会落在这里。
    pub skipped_primitives: u32,
    pub pixels_written: u64,
}

/// The CPU renderer.
/// CPU 渲染器。
#[derive(Default)]
pub struct CpuRenderer {
    pub stats: RenderStats,
    /// Device pixels per logical point. Primitives are authored in logical units.
    /// 每逻辑 point 的设备像素数。图元按逻辑单位编写。
    scale: f32,
    /// Coverage atlas uploaded by the caller, if glyphs are in play.
    /// 调用方上传的覆盖率图集，有字形时使用。
    atlas: Option<CoverageAtlas>,
    /// Colour atlas uploaded by the caller, if colour glyphs are in play.
    /// 调用方上传的颜色图集，有颜色字形时使用。
    color_atlas: Option<ColorAtlas>,
    /// Scratch targets for offscreen layers, indexed by nesting depth.
    /// 离屏层的暂存目标，按嵌套深度索引。
    scratch: Vec<Pixels>,
}

/// A coverage atlas the renderer samples for glyph blits.
/// 供渲染器采样以贴字形的覆盖率图集。
#[derive(Clone, Debug)]
pub struct CoverageAtlas {
    pub width: u32,
    pub height: u32,
    /// One byte of coverage per pixel.
    /// 每像素一字节覆盖率。
    pub data: Vec<u8>,
}

/// A colour atlas: premultiplied RGBA, four bytes per pixel.
/// 颜色图集：预乘 RGBA，每像素四字节。
#[derive(Clone, Debug)]
pub struct ColorAtlas {
    pub width: u32,
    pub height: u32,
    pub data: Vec<u8>,
}

impl CpuRenderer {
    pub fn new() -> Self {
        Self {
            scale: 1.0,
            ..Self::default()
        }
    }

    /// Set device pixels per logical point (fractional scaling, HiDPI).
    /// 设置每逻辑 point 的设备像素数（分数缩放、高 DPI）。
    pub fn set_scale(&mut self, scale: f32) {
        self.scale = if scale.is_finite() && scale > 0.0 {
            scale
        } else {
            1.0
        };
    }

    pub fn scale(&self) -> f32 {
        self.scale
    }

    /// Scale a logical rect into device pixels.
    /// 把逻辑矩形缩放到设备像素。
    fn to_device(&self, r: Rect) -> Rect {
        if (self.scale - 1.0).abs() < f32::EPSILON {
            return r;
        }
        Rect::new(
            r.origin.x * self.scale,
            r.origin.y * self.scale,
            r.size.w * self.scale,
            r.size.h * self.scale,
        )
    }

    /// Set the coverage atlas glyph blits sample from.
    /// 设置字形贴图采样的覆盖率图集。
    pub fn set_atlas(&mut self, atlas: CoverageAtlas) {
        self.atlas = Some(atlas);
    }

    /// Set the colour atlas colour glyphs sample from.
    /// 设置颜色字形采样的颜色图集。
    pub fn set_color_atlas(&mut self, atlas: ColorAtlas) {
        self.color_atlas = Some(atlas);
    }

    /// Render `list` into `target`. When `damage` names rects, untouched pixels come
    /// from `previous`.
    /// 把 `list` 渲染进 `target`。当 `damage` 给出矩形时，未触及的像素来自 `previous`。
    /// Render `list` into `target`, repainting the whole surface.
    /// 把 `list` 渲染进 `target`，重画整个表面。
    ///
    /// `damage` now only decides *whether* to repaint at all: any non-empty damage repaints
    /// everything. Partial repainting by copying last frame's pixels was removed together
    /// with the rest of the incremental machinery (`docs/effect-cache-plan.md` §11) — it is
    /// what let a backdrop see stale pixels, and it also ran each backdrop once per damaged
    /// rect, which double-blurred a frost that two rects happened to cover.
    /// `damage` 现在只决定**是否**重画：非空脏区即整帧重画。靠拷贝上帧像素实现的局部重绘
    /// 已随增量机制一并撤除（`docs/effect-cache-plan.md` §11）——它既让背景看到陈旧像素，
    /// 又会对每个脏矩形各跑一遍背景模糊，两个矩形覆盖同一块磨砂时就被模糊两次。
    pub fn render(&mut self, list: &DrawList, target: &mut Pixels, damage: &Damage) {
        self.stats = RenderStats::default();
        if damage.is_none() {
            return;
        }
        target.clear();
        let full = Rect::new(0.0, 0.0, target.width as f32, target.height as f32);
        let batches = list.plan_batches();
        self.render_region(list, &batches, target, full);
    }

    /// Draw one region, honouring offscreen layers.
    /// 绘制一个区域，处理离屏层。
    fn render_region(
        &mut self,
        list: &DrawList,
        batches: &[Batch],
        target: &mut Pixels,
        region: Rect,
    ) {
        // Active layer chain; depth `d` draws into `self.scratch[d]`.
        // 当前层链；深度 `d` 画进 `self.scratch[d]`。
        let mut stack: Vec<u32> = Vec::new();
        // A layer starts empty, so a frosted surface inside one samples its parent, the
        // buffer the layer is composited back over.
        // 层初始为空，因此层内的磨砂面采样它的父级，也就是层最终合成回去的那块缓冲。
        let backdrops = list.backdrop_order();
        let mut done = 0usize;

        for batch in batches {
            self.sync_layers(list, &mut stack, &batch.layers, target, region);
            while done < backdrops.len() && backdrops[done].0 <= batch.epoch {
                let (_, entry) = backdrops[done];
                done += 1;
                self.frost_backdrop(&stack, target, entry.sigma, frost_area(entry));
            }
            if stack.is_empty() {
                self.draw_batch(list, batch, target, region);
            } else {
                let depth = stack.len() - 1;
                let mut scratch = self.take_scratch(depth, target.width, target.height);
                self.draw_batch(list, batch, &mut scratch, region);
                self.put_scratch(depth, scratch);
            }
        }
        // A backdrop with no batch after it would otherwise never run: the loop only
        // advances the queue when it sees a later epoch.
        // 后面没有批次的 backdrop 否则永远不会执行：循环只在遇到更晚的世代时才推进队列。
        while done < backdrops.len() {
            let (_, entry) = backdrops[done];
            done += 1;
            self.frost_backdrop(&stack, target, entry.sigma, frost_area(entry));
        }
        while let Some(index) = stack.pop() {
            let depth = stack.len();
            let (effects, bounds, radius) = layer_plan(list, index);
            self.composite(depth, &effects, bounds, radius, target, region);
        }
    }

    /// Pop and push layers so the active chain equals `want`.
    /// 弹入弹出层，使活动层链等于 `want`。
    fn sync_layers(
        &mut self,
        list: &DrawList,
        stack: &mut Vec<u32>,
        want: &[u32],
        target: &mut Pixels,
        region: Rect,
    ) {
        let mut common = 0;
        while common < stack.len() && common < want.len() && stack[common] == want[common] {
            common += 1;
        }
        while stack.len() > common {
            let index = stack.pop().expect("non-empty");
            let depth = stack.len();
            let (effects, bounds, radius) = layer_plan(list, index);
            self.composite(depth, &effects, bounds, radius, target, region);
        }
        for &index in &want[common..] {
            let depth = stack.len();
            let mut scratch = self.take_scratch(depth, target.width, target.height);
            // A layer starts empty; leftovers from an earlier frame would leak through.
            // 层从空开始；上一帧的残留会渗进来。
            clear_region(&mut scratch, region);
            self.put_scratch(depth, scratch);
            stack.push(index);
        }
    }

    /// Frost `rect` for the layer in force: a layer starts empty, so a surface inside one
    /// frosts its parent — the buffer the layer is composited back over.
    /// 按当前层磨砂 `rect`：层初始为空，因此层内的表面磨的是它的父级——
    /// 层最终又合成回这个缓冲之上。
    fn frost_backdrop(&mut self, stack: &[u32], target: &mut Pixels, sigma: f32, rect: Rect) {
        if rect.size.w <= 0.0 || rect.size.h <= 0.0 {
            return;
        }
        // Material shading is GPU-only; the CPU path keeps the plain blur.
        // 材质着色只在 GPU 实现；CPU 路径只做纯模糊。
        let Some(depth) = stack.len().checked_sub(1) else {
            backdrop_blur(target, sigma, rect);
            return;
        };
        let mut scratch = self.take_scratch(depth, target.width, target.height);
        let band = if depth == 0 {
            Band::take(target, sigma, rect)
        } else {
            Band::take(&self.scratch[depth - 1], sigma, rect)
        };
        if let Some(band) = band {
            band.write_into(&mut scratch, rect);
        }
        self.put_scratch(depth, scratch);
    }

    fn take_scratch(&mut self, depth: usize, w: u32, h: u32) -> Pixels {
        while self.scratch.len() <= depth {
            self.scratch.push(Pixels::new(0, 0));
        }
        let slot = &mut self.scratch[depth];
        if slot.width != w || slot.height != h {
            *slot = Pixels::new(w, h);
        }
        std::mem::replace(slot, Pixels::new(0, 0))
    }

    fn put_scratch(&mut self, depth: usize, pixels: Pixels) {
        while self.scratch.len() <= depth {
            self.scratch.push(Pixels::new(0, 0));
        }
        self.scratch[depth] = pixels;
    }

    /// Composite scratch level `depth` into its parent after running its effects.
    /// 先跑完本层效果，再把第 `depth` 层暂存合成到父级。
    fn composite(
        &mut self,
        depth: usize,
        effects: &[Effect],
        bounds: Rect,
        radius: ui_core::geom::Corners,
        target: &mut Pixels,
        region: Rect,
    ) {
        let mut src = self.take_scratch(depth, target.width, target.height);
        // `bounds` is logical and `region` is device pixels; convert before intersecting.
        // `bounds` 是逻辑单位、`region` 是设备像素；求交前先换算。
        let effect_region = self
            .to_device(bounds)
            .intersection(region)
            .filter(|r| r.size.w > 0.0 && r.size.h > 0.0)
            .unwrap_or(region);
        let opacity = apply_effects(&mut src, effects, effect_region);
        // Corner rounding is a device-space property; the layer's bounds are logical.
        // 圆角是设备空间的属性，而层的 bounds 是逻辑单位。
        let device = self.to_device(bounds);
        let scaled = scale_corners(radius, self.scale);
        if depth == 0 {
            composite_over_rounded(target, &src, opacity, region, device, scaled);
        } else {
            // The parent level has to be borrowed at the same time, so take it out too.
            // 需要同时借用父层，因此也先取出。
            let mut parent = self.take_scratch(depth - 1, target.width, target.height);
            composite_over_rounded(&mut parent, &src, opacity, region, device, scaled);
            self.put_scratch(depth - 1, parent);
        }
        self.put_scratch(depth, src);
    }

    fn draw_batch(&mut self, list: &DrawList, batch: &Batch, target: &mut Pixels, region: Rect) {
        // `batch.clip` is in logical units while `region` is in device pixels; comparing
        // them directly is only correct at scale 1.
        // `batch.clip` 是逻辑单位，`region` 是设备像素；直接比较只在 scale 为 1 时成立。
        let (clip, rounded) = match batch.clip {
            Some(c) => {
                let device = self.to_device(c.rect);
                let rect = device.intersection(region).unwrap_or(Rect::ZERO);
                // The shape only matters when the radius is non-zero.
                // 只有半径非零时形状才有意义。
                let shape = if c.corners.is_zero() {
                    None
                } else {
                    // The corners follow the uncut box: an outer clip narrows `rect` but the
                    // node's own rounded edges stay where they were.
                    // 圆角跟随未裁切的盒子：外层只收窄 `rect`，节点自己的圆边留在原处。
                    let clamped = c.corners.clamp_to(c.shape.size);
                    let s = self.scale;
                    Some((
                        self.to_device(c.shape),
                        Corners {
                            tl: clamped.tl * s,
                            tr: clamped.tr * s,
                            br: clamped.br * s,
                            bl: clamped.bl * s,
                            shape: clamped.shape,
                        },
                    ))
                };
                (rect, shape)
            }
            None => (region, None),
        };
        if clip.is_empty() {
            return;
        }
        let extent = clip_to(clip, target.width, target.height);
        if extent.0 >= extent.2 || extent.1 >= extent.3 {
            return;
        }
        let clip = ClipRegion { extent, rounded };

        match batch.kind {
            // Images are GPU-only; count them as skipped so the gap is visible in stats.
            // 图像只有 GPU 实现；计为跳过，使缺口在 stats 里可见。
            PrimKind::Image | PrimKind::Shadow => {
                self.stats.skipped_primitives += batch.range.len() as u32;
            }
            PrimKind::Sector => {
                for i in batch.range.clone() {
                    if let Some(prim) = list.prims.sectors.get(i as usize).copied() {
                        self.draw_sector(&prim, target, &clip);
                    }
                }
            }
            PrimKind::Rect => {
                for i in batch.range.clone() {
                    if let Some(prim) = list.prims.rects.get(i as usize).copied() {
                        self.draw_rect(&prim, target, &clip);
                        self.stats.rects += 1;
                    }
                }
            }
            PrimKind::Text => {
                for i in batch.range.clone() {
                    if let Some(prim) = list.prims.texts.get(i as usize).cloned() {
                        self.draw_text(&prim, target, &clip);
                        self.stats.texts += 1;
                    }
                }
            }
            PrimKind::Glyph => {
                for i in batch.range.clone() {
                    if let Some(prim) = list.prims.glyphs.get(i as usize).copied() {
                        self.draw_glyph(&prim, target, &clip);
                        self.stats.glyphs += 1;
                    }
                }
            }
        }
    }

    fn draw_rect(&mut self, prim: &RectPrim, target: &mut Pixels, clip: &ClipRegion) {
        let (cx0, cy0, cx1, cy1) = clip.extent;
        let r = self.to_device(prim.rect);
        if r.is_empty() {
            return;
        }
        let s = self.scale;
        let radius = Corners {
            tl: prim.radius.tl * s,
            tr: prim.radius.tr * s,
            br: prim.radius.br * s,
            bl: prim.radius.bl * s,
            shape: prim.radius.shape,
        }
        .clamp_to(r.size);
        let stride_w = target.width as usize * 4;

        let x0 = r.min_x().floor().max(cx0 as f32) as u32;
        let y0 = r.min_y().floor().max(cy0 as f32) as u32;
        let x1 = r.max_x().ceil().min(cx1 as f32) as u32;
        let y1 = r.max_y().ceil().min(cy1 as f32) as u32;
        if x0 >= x1 || y0 >= y1 {
            return;
        }

        let inner_rect = prim.border.map(|(_, bw)| {
            let bw = bw * s;
            Rect::new(
                r.origin.x + bw,
                r.origin.y + bw,
                (r.size.w - bw * 2.0).max(0.0),
                (r.size.h - bw * 2.0).max(0.0),
            )
        });
        let inner_radius = prim.border.map(|(_, bw)| {
            let bw = bw * s;
            Corners {
                tl: (radius.tl - bw).max(0.0),
                tr: (radius.tr - bw).max(0.0),
                br: (radius.br - bw).max(0.0),
                bl: (radius.bl - bw).max(0.0),
                shape: radius.shape,
            }
        });

        for y in y0..y1 {
            let py = y as f32 + 0.5;
            for x in x0..x1 {
                let px = x as f32 + 0.5;
                // The rounded clip attenuates coverage instead of just bounding it.
                // 圆角裁剪以衰减覆盖度的方式生效，而不只是限制范围。
                let cc = clip.coverage(px, py);
                if cc <= 0.0 {
                    continue;
                }
                let cov = coverage_rounded_rect(r, radius, px, py) * cc;
                if cov <= 0.0 {
                    continue;
                }
                let idx = y as usize * stride_w + x as usize * 4;
                // A gradient varies per pixel, so the fill colour is sampled here rather
                // than hoisted out of the loop. It is sampled in device space: the stops
                // and extent are lengths, and lengths scale with the output.
                // 渐变逐像素变化，因此填充色在此采样，而不是提到循环外。采样在设备空间进行：
                // 停点与跨度都是长度，长度随输出缩放。
                let fill = match &prim.gradient {
                    Some(g) => {
                        let (px_l, py_l) = (px / s, py / s);
                        let (pos, extent) = match g.axis {
                            ui_core::draw::GradientAxis::Vertical => (
                                py_l - r.origin.y / s,
                                r.size.h / s,
                            ),
                            ui_core::draw::GradientAxis::Horizontal => (
                                px_l - r.origin.x / s,
                                r.size.w / s,
                            ),
                        };
                        g.sample(pos, extent)
                    }
                    None => prim.fill,
                };
                // The ring and the inner area are disjoint parts of one shape: mix them by
                // area and blend once. Two stacked blends count the feather twice.
                // 环与内部是同一形状的互斥面积：按面积混合后只混合一次。
                // 叠加两次混合会把羽化算重。
                let src = match (prim.border, inner_rect, inner_radius) {
                    (Some((_, bw)), Some(ir), Some(irad)) => {
                        // A gradient stroke is sampled per pixel, like the fill above.
                        // 渐变描边与上面的填充一样逐像素采样。
                        let bc = match &prim.border_gradient {
                            Some(g) => {
                                let (px_l, py_l) = (px / s, py / s);
                                let (pos, extent) = match g.axis {
                                    ui_core::draw::GradientAxis::Vertical => {
                                        (py_l - r.origin.y / s, r.size.h / s)
                                    }
                                    ui_core::draw::GradientAxis::Horizontal => {
                                        (px_l - r.origin.x / s, r.size.w / s)
                                    }
                                };
                                g.sample(pos, extent)
                            }
                            None => prim.border.map(|(c, _)| c).unwrap_or(Color::TRANSPARENT),
                        };
                        let inner_cov = coverage_rounded_rect(ir, irad, px, py) * cc;
                        let mut ring = ((cov - inner_cov) / cov).clamp(0.0, 1.0);
                        // A notch cuts the stroke where it crosses the top edge; the fill
                        // survives, so a transparent box shows the backdrop through it.
                        // 缺口在描边穿过顶边处切掉它；填充仍在，因此透明盒子会透出背景。
                        // The notch is stated in logical units while this loop runs in device
                        // pixels; scaling only the border width left the gap half as wide at
                        // scale 2, so a hairline of stroke stayed under the floating label.
                        // 缺口按逻辑单位声明，而本循环按设备像素跑；只缩放描边宽度会让
                        // scale 2 下缺口只有一半宽，浮起标签下因此留下一条细线。
                        let (lx, ly) = (px - r.origin.x, py - r.origin.y);
                        if prim.in_notch(lx / s, ly / s, bw, 0.0) {
                            ring = 0.0;
                        }
                        ring_mix(fill, bc, ring)
                    }
                    _ => fill,
                };
                blend_pixel(&mut target.data[idx..idx + 4], src, cov);
                self.stats.pixels_written += 1;
            }
        }
    }

    /// One stroked arc: an annulus clipped to a sweep, with optional round caps.
    /// 一段描边弧：环带按扫动区间裁剪，两端可选圆头帽。
    fn draw_sector(
        &mut self,
        prim: &ui_core::draw::SectorPrim,
        target: &mut Pixels,
        clip: &ClipRegion,
    ) {
        let s = self.scale;
        let (cx0, cy0, cx1, cy1) = clip.extent;
        let c = (
            prim.sector.centre.x * s,
            prim.sector.centre.y * s,
        );
        let r_out = prim.sector.radius * s;
        let w = prim.sector.thickness * s;
        let r_in = (r_out - w).max(0.0);
        let r_mid = (r_out + r_in) * 0.5;
        let sweep = prim.sector.sweep();
        if r_out <= 0.0 || w <= 0.0 || sweep <= 0.0 {
            return;
        }
        let (start, end) = (prim.sector.trim.0, prim.sector.trim.0 + sweep);
        // The caps are circles at the two end points, centred on the stroke.
        // 圆头帽是两端端点处的圆，圆心在描边中线上。
        let cap = |turns: f32| {
            let a = turns * std::f32::consts::TAU;
            (c.0 + r_mid * a.cos(), c.1 + r_mid * a.sin())
        };
        let caps = prim
            .sector
            .round_caps
            .then(|| [cap(start), cap(end)]);

        let x0 = (c.0 - r_out - w * 0.5).floor().max(cx0 as f32) as u32;
        let y0 = (c.1 - r_out - w * 0.5).floor().max(cy0 as f32) as u32;
        let x1 = (c.0 + r_out + w * 0.5).ceil().min(cx1 as f32) as u32;
        let y1 = (c.1 + r_out + w * 0.5).ceil().min(cy1 as f32) as u32;
        if x0 >= x1 || y0 >= y1 {
            return;
        }
        let stride_w = target.width as usize * 4;
        for y in y0..y1 {
            let py = y as f32 + 0.5;
            for x in x0..x1 {
                let px = x as f32 + 0.5;
                let cc = clip.coverage(px, py);
                if cc <= 0.0 {
                    continue;
                }
                let mut cov = sector_coverage(c, r_in, r_out, start, sweep, px, py);
                if let Some(caps) = caps {
                    for (ccx, ccy) in caps {
                        let d = ((px - ccx).powi(2) + (py - ccy).powi(2)).sqrt();
                        cov = cov.max((w * 0.5 + 0.5 - d).clamp(0.0, 1.0));
                    }
                }
                let cov = cov * cc;
                if cov <= 0.0 {
                    continue;
                }
                let idx = y as usize * stride_w + x as usize * 4;
                blend_pixel(&mut target.data[idx..idx + 4], prim.colour, cov);
                self.stats.pixels_written += 1;
            }
        }
    }

    /// Blit one glyph: coverage is tinted by `color`, colour pixels are used as-is.
    /// 贴一个字形：覆盖率由 `color` 着色，颜色像素直接使用。
    fn draw_glyph(&mut self, prim: &ui_core::draw::GlyphPrim, target: &mut Pixels, clip: &ClipRegion) {
        let (cx0, cy0, cx1, cy1) = clip.extent;
        let dst = self.to_device(prim.rect);
        // Round, not floor: glyph origins are already quantized to whole device
        // pixels, and `logical * scale` can land a hair below the integer.
        // 用 round 而非 floor：字形原点已量化到整设备像素，
        // 而 `逻辑 * scale` 可能落在整数下方一点点。
        let (x0, y0, x1, y1) = (
            dst.min_x().round().max(cx0 as f32) as u32,
            dst.min_y().round().max(cy0 as f32) as u32,
            dst.max_x().round().min(cx1 as f32) as u32,
            dst.max_y().round().min(cy1 as f32) as u32,
        );
        if x0 >= x1 || y0 >= y1 || prim.atlas.is_empty() {
            return;
        }
        let stride = target.width as usize * 4;
        // Glyphs blit 1:1 in practice; integer offsets avoid sampling drift that
        // would make letter spacing uneven.
        // 字形实际是 1:1 贴图；整数偏移避免采样漂移导致字距不均。
        let off_x = prim.atlas.min_x().round() as i32 - dst.min_x().round() as i32;
        let off_y = prim.atlas.min_y().round() as i32 - dst.min_y().round() as i32;
        let one_to_one = (prim.atlas.size.w - dst.size.w).abs() < 0.01
            && (prim.atlas.size.h - dst.size.h).abs() < 0.01;
        match prim.kind {
            GlyphKind::Coverage => {
                let Some(atlas) = self.atlas.as_ref() else {
                    return;
                };
                for y in y0..y1 {
                    let sy = if one_to_one {
                        (y as i32 + off_y).max(0) as u32
                    } else {
                        let v = (y as f32 - dst.min_y()) / dst.size.h.max(1.0);
                        (prim.atlas.min_y() + v * prim.atlas.size.h) as u32
                    };
                    if sy >= atlas.height {
                        continue;
                    }
                    for x in x0..x1 {
                        let sx = if one_to_one {
                            (x as i32 + off_x).max(0) as u32
                        } else {
                            let u = (x as f32 - dst.min_x()) / dst.size.w.max(1.0);
                            (prim.atlas.min_x() + u * prim.atlas.size.w) as u32
                        };
                        if sx >= atlas.width {
                            continue;
                        }
                        let cov = atlas.data[(sy * atlas.width + sx) as usize];
                        if cov == 0 {
                            continue;
                        }
                        let alpha = cov as f32 / 255.0
                            * prim.alpha
                            * clip.coverage(x as f32 + 0.5, y as f32 + 0.5);
                        if alpha <= 0.0 {
                            continue;
                        }
                        let idx = y as usize * stride + x as usize * 4;
                        blend_pixel(&mut target.data[idx..idx + 4], prim.color, alpha);
                        self.stats.pixels_written += 1;
                    }
                }
            }
            GlyphKind::Color => {
                let Some(atlas) = self.color_atlas.as_ref() else {
                    return;
                };
                for y in y0..y1 {
                    let sy = if one_to_one {
                        (y as i32 + off_y).max(0) as u32
                    } else {
                        let v = (y as f32 - dst.min_y()) / dst.size.h.max(1.0);
                        (prim.atlas.min_y() + v * prim.atlas.size.h) as u32
                    };
                    if sy >= atlas.height {
                        continue;
                    }
                    for x in x0..x1 {
                        let sx = if one_to_one {
                            (x as i32 + off_x).max(0) as u32
                        } else {
                            let u = (x as f32 - dst.min_x()) / dst.size.w.max(1.0);
                            (prim.atlas.min_x() + u * prim.atlas.size.w) as u32
                        };
                        if sx >= atlas.width {
                            continue;
                        }
                        let base = (sy * atlas.width + sx) as usize * 4;
                        let (r, g, b, a) = (
                            atlas.data[base],
                            atlas.data[base + 1],
                            atlas.data[base + 2],
                            atlas.data[base + 3],
                        );
                        if a == 0 {
                            continue;
                        }
                        let m = prim.alpha
                            * prim.color.a
                            * clip.coverage(x as f32 + 0.5, y as f32 + 0.5);
                        if m <= 0.0 {
                            continue;
                        }
                        let idx = y as usize * stride + x as usize * 4;
                        blend_premul_pixel(&mut target.data[idx..idx + 4], r, g, b, a, m);
                        self.stats.pixels_written += 1;
                    }
                }
            }
        }
    }

    fn draw_text(&mut self, prim: &TextPrim, target: &mut Pixels, clip: &ClipRegion) {
        // Placeholder: one bar per character cell, enough to prove layout wiring.
        // Replaced by a real glyph atlas when `ui-text` lands.
        // 占位：每个字符格画一条，足以验证布局接线。`ui-text` 落地后换真图集。
        let (text, spans) = prim.block.flatten();
        let style = prim
            .block
            .runs
            .first()
            .map_or_else(Default::default, |r| r.style);
        let _ = spans;
        let char_w = (style.size * 0.6).max(1.0);
        let line_h = style.size * 1.3;
        // The line block sits centred in a taller node box, as the glyph path places it.
        // 行块在更高的节点盒里居中，与字形路径的摆放一致。
        let spare = prim
            .layout
            .as_ref()
            .map_or(0.0, |l| (prim.height - l.height).max(0.0));
        let bar = RectPrim {
            rect: Rect::new(
                prim.origin.x,
                prim.origin.y + spare * 0.5 + line_h * 0.3,
                char_w * text.chars().count() as f32,
                style.size * 0.55,
            ),
            radius: Corners::ZERO,
            fill: prim.ink,
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        };
        self.draw_rect(&bar, target, clip);
    }
}

/// Blend a straight-alpha colour over the straight BGRA pixel, emitting straight.
/// 把直通颜色混到直通 BGRA 像素上，输出仍是直通。
fn blend_pixel(dst: &mut [u8], color: Color, coverage: f32) {
    let sa = (color.a * coverage).clamp(0.0, 1.0);
    if sa <= 0.0 {
        return;
    }
    let a_src = (sa * 255.0).round() as u32;
    let a_dst = dst[3] as u32;
    let inv = 255 - a_src;
    let a_out = a_src + a_dst * inv / 255;
    if a_out == 0 {
        dst.copy_from_slice(&[0, 0, 0, 0]);
        return;
    }
    let blend = |s: f32, d: u32| -> u8 {
        let sc = (s.clamp(0.0, 1.0) * 255.0) as u32;
        ((sc * a_src + d * inv) / a_out).min(255) as u8
    };
    dst[0] = blend(color.b, dst[0] as u32);
    dst[1] = blend(color.g, dst[1] as u32);
    dst[2] = blend(color.r, dst[2] as u32);
    dst[3] = a_out.min(255) as u8;
}

/// Blend one premultiplied RGBA texel over the straight BGRA destination.
/// 把一个预乘 RGBA 纹素混合到直通 BGRA 目标上。
///
/// `scale` folds the primitive alpha and clip coverage into the texel.
/// `scale` 把图元 alpha 与裁剪覆盖度折进纹素。
fn blend_premul_pixel(dst: &mut [u8], r: u8, g: u8, b: u8, a: u8, scale: f32) {
    let ea = (a as f32 / 255.0 * scale).clamp(0.0, 1.0);
    let sa = (ea * 255.0).round() as u32;
    if sa == 0 {
        return;
    }
    let inv = 255 - sa;
    let da = dst[3] as u32;
    let a_out = sa + da * inv / 255;
    if a_out == 0 {
        dst.copy_from_slice(&[0, 0, 0, 0]);
        return;
    }
    // The source is premultiplied, the destination is straight: scale the source by
    // `scale` and combine it with the destination's premultiplied contribution.
    // 源是预乘、目标是直通：源按 `scale` 缩放，再与目标的预乘贡献相加。
    let channel = |s: u8, d: u8| -> u8 {
        let src = (s as f32 * scale).round() as u32;
        let out_premul = src + (d as u32 * da / 255) * inv / 255;
        ((out_premul * 255 + a_out / 2) / a_out).min(255) as u8
    };
    dst[0] = channel(b, dst[0]);
    dst[1] = channel(g, dst[1]);
    dst[2] = channel(r, dst[2]);
    dst[3] = a_out.min(255) as u8;
}

/// Analytic coverage of a rounded rect at a sample point (0..=1).
/// 采样点处的圆角矩形解析覆盖率（0..=1）。
/// The clip in force for one batch: a rect extent plus an optional rounded shape.
/// 单个批次的裁剪：矩形范围加可选的圆角形状。
#[derive(Clone, Copy)]
struct ClipRegion {
    extent: (u32, u32, u32, u32),
    /// Device-space rounded rect, or `None` for a plain rectangle.
    /// 设备空间的圆角矩形；`None` 表示普通矩形。
    rounded: Option<(Rect, Corners)>,
}

impl ClipRegion {
    fn coverage(&self, px: f32, py: f32) -> f32 {
        match self.rounded {
            Some((rect, corners)) => coverage_rounded_rect(rect, corners, px, py),
            None => 1.0,
        }
    }
}

/// Superellipse norm of a non-negative pair, `(|x|^n + |y|^n)^(1/n)`.
/// 非负数对的超椭圆范数，`(|x|^n + |y|^n)^(1/n)`。
///
/// n = 2 is the circle, n = 1 a straight bevel, n -> inf a square corner.
/// n = 2 为圆，n = 1 为直线斜切，n 趋于无穷为直角。
fn superellipse_norm(x: f32, y: f32, n: f32) -> f32 {
    if n <= 1.0 {
        return x + y;
    }
    if n >= 64.0 {
        return x.max(y);
    }
    (x.powf(n) + y.powf(n)).powf(1.0 / n)
}

/// One pixel that is part ring, part fill: mix them by area in premultiplied space.
/// 一个像素由环与填充按面积构成：在预乘空间里按面积混合。
fn ring_mix(fill: Color, border: Color, ring: f32) -> Color {
    let f = [fill.r * fill.a, fill.g * fill.a, fill.b * fill.a, fill.a];
    let b = [border.r * border.a, border.g * border.a, border.b * border.a, border.a];
    // Border composited over the fill, then weighted by the ring's share of the pixel.
    // 边框合成在填充之上，再按环占该像素的面积加权。
    let inv = 1.0 - b[3];
    let over = [
        b[0] + f[0] * inv,
        b[1] + f[1] * inv,
        b[2] + f[2] * inv,
        b[3] + f[3] * inv,
    ];
    let m = [
        f[0] + (over[0] - f[0]) * ring,
        f[1] + (over[1] - f[1]) * ring,
        f[2] + (over[2] - f[2]) * ring,
        f[3] + (over[3] - f[3]) * ring,
    ];
    if m[3] <= 0.0 {
        return Color::TRANSPARENT;
    }
    Color {
        r: m[0] / m[3],
        g: m[1] / m[3],
        b: m[2] / m[3],
        a: m[3],
    }
}

/// Coverage of one stroked arc at a device pixel, analytic and one pixel wide.
/// 一个设备像素处描边弧的覆盖度，解析计算，羽化一像素宽。
///
/// Both boundaries are distances in device pixels, so the feather is round everywhere:
/// the ring uses the radial distance, the sweep uses arc length (`angle × radius`).
/// 两条边界都以设备像素计距，因此各处羽化都等宽：环带用径向距离，扫动用弧长
/// （`角度 × 半径`）。
fn sector_coverage(
    c: (f32, f32),
    r_in: f32,
    r_out: f32,
    start: f32,
    sweep: f32,
    px: f32,
    py: f32,
) -> f32 {
    let (dx, dy) = (px - c.0, py - c.1);
    let d = (dx * dx + dy * dy).sqrt();
    // Negative inside the annulus.
    // 环带内部为负。
    let ring = (r_in - d).max(d - r_out);
    if sweep >= 1.0 {
        return (0.5 - ring).clamp(0.0, 1.0);
    }
    let mut turns = dy.atan2(dx) / std::f32::consts::TAU;
    if turns < 0.0 {
        turns += 1.0;
    }
    let rel = (turns - start).rem_euclid(1.0);
    let arc = d * std::f32::consts::TAU;
    let angle = if rel <= sweep {
        -rel.min(sweep - rel) * arc
    } else {
        (rel - sweep).min(1.0 - rel) * arc
    };
    (0.5 - ring.max(angle)).clamp(0.0, 1.0)
}

fn coverage_rounded_rect(r: Rect, radius: Corners, px: f32, py: f32) -> f32 {
    if px < r.min_x() || px > r.max_x() || py < r.min_y() || py > r.max_y() {
        return 0.0;
    }
    let corners = [
        (
            r.origin.x + radius.tl,
            r.origin.y + radius.tl,
            radius.tl,
            px < r.origin.x + radius.tl && py < r.origin.y + radius.tl,
        ),
        (
            r.max_x() - radius.tr,
            r.origin.y + radius.tr,
            radius.tr,
            px > r.max_x() - radius.tr && py < r.origin.y + radius.tr,
        ),
        (
            r.max_x() - radius.br,
            r.max_y() - radius.br,
            radius.br,
            px > r.max_x() - radius.br && py > r.max_y() - radius.br,
        ),
        (
            r.origin.x + radius.bl,
            r.max_y() - radius.bl,
            radius.bl,
            px < r.origin.x + radius.bl && py > r.max_y() - radius.bl,
        ),
    ];
    let n = radius.shape.exponent();
    for (cx, cy, rad, in_corner) in corners {
        if rad <= 0.0 || !in_corner {
            continue;
        }
        // The corner arc is the level set `norm(|dx|, |dy|) == rad`; using the norm
        // itself as the distance keeps the 1px feather consistent with the edges.
        // 圆角弧线是等值线 `norm(|dx|, |dy|) == rad`；直接把范数当距离，
        // 使 1 像素羽化与直边一致。
        let d = superellipse_norm((px - cx).abs(), (py - cy).abs(), n);
        return (rad + 0.5 - d).clamp(0.0, 1.0);
    }
    1.0
}

/// Encode premultiplied pixels into straight-alpha sRGB bytes.
/// 把预乘像素编码成直通 alpha 的 sRGB 字节。
pub fn encode_straight(pixels: &Pixels) -> Vec<u8> {
    let mut out = pixels.data.clone();
    for px in out.as_chunks_mut::<4>().0 {
        let a = px[3] as u32;
        if a == 0 {
            px.copy_from_slice(&[0, 0, 0, 0]);
            continue;
        }
        if a < 255 {
            for c in px.iter_mut().take(3) {
                *c = ((*c as u32 * 255) / a).min(255) as u8;
            }
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;
    use ui_core::id::NodeId;

    fn nid(i: u32) -> NodeId {
        NodeId::from_raw(i, 0)
    }

    fn prim(x: f32, y: f32, w: f32, h: f32, color: Color) -> RectPrim {
        RectPrim {
            rect: Rect::new(x, y, w, h),
            radius: Corners::ZERO,
            fill: color,
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        }
    }

    /// The CPU backend has no image path, so an image must be counted, not silently dropped.
    /// CPU 后端没有图像路径，因此图像必须被计数，而不是静默丢弃。
    #[test]
    fn an_image_primitive_is_counted_as_skipped_and_paints_nothing() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 64.0, 64.0));
        let texture = list.push_image(ui_core::draw::ImageEntry {
            id: 1,
            width: 2,
            height: 2,
            data: std::sync::Arc::new(vec![255u8; 2 * 2 * 4]),
        });
        list.push_image_prim(
            nid(0),
            ui_core::draw::ImagePrim {
                rect: Rect::new(8.0, 8.0, 48.0, 48.0),
                corners: Corners::ZERO,
                texture,
                src: Rect::new(0.0, 0.0, 2.0, 2.0),
            },
        );

        let mut target = Pixels::new(64, 64);
        let mut cpu = CpuRenderer::new();
        cpu.render(&list, &mut target, &Damage::Full);

        assert_eq!(cpu.stats.skipped_primitives, 1, "the image must be reported");
        assert_eq!(cpu.stats.rects, 0, "nothing may be rasterised for it");
        assert!(
            target.data.iter().all(|b| *b == 0),
            "the image must not paint anything"
        );
    }

    /// A colour glyph must paint its own texel, not the primitive's ink; coverage
    /// glyphs must keep taking the ink.
    /// 颜色字形必须画自己的纹素而不是图元墨色；覆盖率字形仍取墨色。
    #[test]
    fn a_colour_glyph_ignores_the_ink_while_a_coverage_glyph_uses_it() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 4.0, 4.0));
        list.push_glyph(
            nid(0),
            ui_core::draw::GlyphPrim {
                rect: Rect::new(0.0, 0.0, 1.0, 1.0),
                atlas: Rect::new(0.0, 0.0, 1.0, 1.0),
                alpha: 1.0,
                color: Color::from_rgba8(0, 0, 255, 255),
                kind: GlyphKind::Coverage,
            },
        );
        list.push_glyph(
            nid(1),
            ui_core::draw::GlyphPrim {
                rect: Rect::new(1.0, 0.0, 1.0, 1.0),
                atlas: Rect::new(0.0, 0.0, 1.0, 1.0),
                alpha: 1.0,
                color: Color::from_rgba8(0, 0, 255, 255),
                kind: GlyphKind::Color,
            },
        );

        let mut target = Pixels::new(4, 4);
        let mut cpu = CpuRenderer::new();
        cpu.set_atlas(CoverageAtlas {
            width: 1,
            height: 1,
            data: vec![255],
        });
        cpu.set_color_atlas(ColorAtlas {
            width: 1,
            height: 1,
            data: vec![255, 0, 0, 255],
        });
        cpu.render(&list, &mut target, &Damage::Full);

        assert_eq!(&target.data[0..4], &[255, 0, 0, 255], "coverage takes the ink");
        assert_eq!(&target.data[4..8], &[0, 0, 255, 255], "colour texel wins");
    }

    /// A backdrop must soften what is already painted under it, on the CPU path too.
    /// CPU 路径同样必须柔化已经画好的背景内容。
    #[test]
    fn a_backdrop_blurs_what_was_painted_before_it() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 120.0, 60.0));
        // A hard-edged white block on black, then a backdrop over it.
        // 黑底上的一块硬边白方块，然后在它上面做背景模糊。
        list.push_rect(
            nid(0),
            prim(40.0, 0.0, 20.0, 60.0, Color::from_rgba8(255, 255, 255, 255)),
        );
        list.push_backdrop(ui_core::draw::BackdropEntry {
            rect: Rect::new(10.0, 10.0, 100.0, 40.0),
            clip: Rect::new(10.0, 10.0, 100.0, 40.0),
            corners: Corners::ZERO,
            radius: 12,
            sigma: 6.0,
            material: ui_core::draw::BackdropMaterial::PLAIN,
        });
        // A full-frame black rect supplies the dark surround the blur mixes in.
        // 一块铺满的黑矩形提供模糊要混合进来的深色周围。
        list.push_rect(
            nid(1),
            prim(0.0, 0.0, 0.0, 0.0, Color::from_rgba8(0, 0, 0, 0)),
        );

        let mut target = Pixels::new(120, 60);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);

        // The block's interior must no longer be pure white: the blur pulled the black
        // surround inward, which a skipped backdrop would not do.
        // 方块内部不再纯白：模糊把周围的黑色带了进来，跳过背景模糊则不会发生。
        let inside = target.get(50, 30);
        assert!(
            inside[0] < 250,
            "the backdrop must soften the block's interior, got {inside:?}"
        );
        // Far outside the backdrop rect nothing may change.
        // 远离模糊矩形的地方不得改变。
        assert_eq!(
            target.get(115, 55),
            [0, 0, 0, 0],
            "outside the backdrop must stay untouched"
        );
    }

    /// A frosted surface inside a group layer frosts its parent: the layer starts empty,
    /// so without that the surface would land on nothing.
    /// 组层内的磨砂面磨的是它的父级：层初始为空，不这么做这块表面就落在空处。
    #[test]
    fn a_backdrop_inside_a_group_layer_frosts_its_parent() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 120.0, 60.0));
        // The white block sits beside the frost rect, so only the blur can bring it in.
        // 白方块位于磨砂矩形之外，只有模糊能把它带进来。
        list.push_rect(
            nid(0),
            prim(45.0, 0.0, 15.0, 60.0, Color::from_rgba8(255, 255, 255, 255)),
        );
        list.push_layer(
            Rect::new(60.0, 10.0, 50.0, 40.0),
            vec![ui_core::Effect::opacity(0.5)],
            Corners::ZERO,
        );
        list.push_backdrop(ui_core::draw::BackdropEntry {
            rect: Rect::new(60.0, 10.0, 50.0, 40.0),
            clip: Rect::new(60.0, 10.0, 50.0, 40.0),
            corners: Corners::ZERO,
            radius: 12,
            sigma: 6.0,
            material: ui_core::draw::BackdropMaterial::PLAIN,
        });
        // The frosted surface's own clear box keeps the layer open past the backdrop.
        // 磨砂面自身的透明盒形让层在背景模糊之后仍然开着。
        list.push_rect(
            nid(2),
            prim(60.0, 10.0, 50.0, 40.0, Color::TRANSPARENT),
        );
        list.pop_layer();
        list.push_rect(
            nid(1),
            prim(0.0, 0.0, 0.0, 0.0, Color::from_rgba8(0, 0, 0, 0)),
        );

        let mut target = Pixels::new(120, 60);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);

        // The frost pulls the block's white into the layer, which then composites at 50%;
        // an empty layer would leave the black frame showing through instead.
        // 磨砂把方块的白色带进层内，再按 50% 合成；层若为空，透出的就是黑帧。
        let inside = target.get(63, 30);
        assert!(
            inside[0] > 5,
            "the layer must carry the frosted parent, got {inside:?}"
        );
    }

    #[test]
    fn a_translucent_rect_looks_identical_in_or_out_of_a_layer() {
        // The buffer is straight alpha (blend_pixel divides by a_out), so the layer
        // composite must use the same formula; premultiplied reading over-brightens
        // every partial-alpha layer pixel. Blur aside, bare and layered must match bit-exact.
        // 缓冲是直通 alpha，层合成必须用同一公式；按预乘读会把每个半透明层像素画亮。
        let prim = RectPrim {
            rect: Rect::new(1.0, 1.0, 2.0, 2.0),
            radius: Corners::ZERO,
            fill: Color::from_rgba8(255, 0, 0, 128),
            border: None,
            border_gradient: None,
            gradient: None,
            notch: None,
        };
        let mut bare = DrawList::new(Rect::new(0.0, 0.0, 4.0, 4.0));
        bare.push_rect(NodeId::from_raw(1, 0), prim);
        let mut layered = DrawList::new(Rect::new(0.0, 0.0, 4.0, 4.0));
        layered.push_layer(Rect::new(0.0, 0.0, 4.0, 4.0), Vec::new(), Corners::ZERO);
        layered.push_rect(NodeId::from_raw(1, 0), prim);
        layered.pop_layer();
        let mut a = Pixels::new(4, 4);
        a.fill(Color::from_rgba8(0, 0, 255, 255));
        let mut b = Pixels::new(4, 4);
        b.fill(Color::from_rgba8(0, 0, 255, 255));
        let dmg = ui_core::damage::Damage::Rects(vec![Rect::new(0.0, 0.0, 4.0, 4.0)]);
        CpuRenderer::new().render(&bare, &mut a, &dmg);
        CpuRenderer::new().render(&layered, &mut b, &dmg);
        eprintln!("BARE {:?} LAYERED {:?}", a.get(2, 2), b.get(2, 2));
        assert_eq!(a.as_bytes(), b.as_bytes(), "layer path must equal the bare path");
    }

    #[test]
    fn a_translucent_layer_composites_by_coverage_not_by_raw_channel() {
        // A layer holds one straight-alpha pixel (red at ~50%); the destination below is
        // opaque blue. Straight-over halves both channels; a premultiplied reading kept
        // the red whole and let no blue through.
        // 层里只有一个直通 alpha 像素（约 50% 红），下面是不透明的蓝。
        // 直通合成两边各留一半；按预乘读会留满红、完全挡住蓝。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 4.0, 4.0));
        // The blue must be painted in this frame: the renderer repaints the whole surface,
        // so a colour pre-filled into the target would be cleared before the layer runs.
        // 蓝必须在本帧画出来：渲染器整帧重画，预填进目标的颜色会在层执行前被清掉。
        list.push_rect(
            NodeId::from_raw(0, 0),
            RectPrim {
                rect: Rect::new(0.0, 0.0, 4.0, 4.0),
                radius: Corners::ZERO,
                fill: Color::from_rgba8(0, 0, 255, 255),
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
        list.push_layer(Rect::new(0.0, 0.0, 4.0, 4.0), Vec::new(), Corners::ZERO);
        list.push_rect(
            NodeId::from_raw(1, 0),
            RectPrim {
                rect: Rect::new(1.0, 1.0, 2.0, 2.0),
                radius: Corners::ZERO,
                fill: Color::from_rgba8(255, 0, 0, 128),
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
        list.pop_layer();
        let mut px = Pixels::new(4, 4);
        CpuRenderer::new().render(
            &list,
            &mut px,
            &ui_core::damage::Damage::Rects(vec![Rect::new(0.0, 0.0, 4.0, 4.0)]),
        );
        let got = px.get(2, 2);
        assert!(
            got[0].abs_diff(128) <= 2 && got[2].abs_diff(127) <= 2,
            "expected red and blue halved, got {got:?}"
        );
    }

    #[test]
    fn a_trailing_backdrop_still_runs() {
        // A backdrop with no batch after it never advances the queue, so the drain after the
        // batch loop is what makes it run at all.
        // 后面没有批次的 backdrop 永远不会推进队列，因此靠批次循环之后的排空才会执行。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 120.0, 60.0));
        list.push_rect(
            nid(0),
            prim(0.0, 0.0, 120.0, 60.0, Color::from_rgba8(0, 0, 0, 255)),
        );
        list.push_rect(
            nid(1),
            prim(40.0, 0.0, 20.0, 60.0, Color::from_rgba8(255, 255, 255, 255)),
        );
        list.push_backdrop(ui_core::draw::BackdropEntry {
            rect: Rect::new(10.0, 10.0, 100.0, 40.0),
            clip: Rect::new(10.0, 10.0, 100.0, 40.0),
            corners: Corners::ZERO,
            radius: 12,
            sigma: 6.0,
            material: ui_core::draw::BackdropMaterial::PLAIN,
        });

        let mut target = Pixels::new(120, 60);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);

        let inside = target.get(50, 30);
        assert!(
            inside[0] < 250,
            "the trailing backdrop must blur, got {inside:?}"
        );
    }

    #[test]
    fn a_backdrop_reads_pixels_beyond_its_own_rect() {
        // The step sits exactly on the frost's left edge. Without padding the window clamps
        // to that edge and reads only white; with padding it reads the black outside.
        // 台阶正好落在磨砂的左边缘。不外延的话窗口夹取在边缘、只读到白色；外延后才读到界外的黑。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 120.0, 60.0));
        list.push_rect(
            nid(0),
            prim(0.0, 0.0, 120.0, 60.0, Color::from_rgba8(0, 0, 0, 255)),
        );
        list.push_rect(
            nid(1),
            prim(10.0, 0.0, 110.0, 60.0, Color::from_rgba8(255, 255, 255, 255)),
        );
        list.push_backdrop(ui_core::draw::BackdropEntry {
            rect: Rect::new(10.0, 10.0, 100.0, 40.0),
            clip: Rect::new(10.0, 10.0, 100.0, 40.0),
            corners: Corners::ZERO,
            radius: 12,
            sigma: 6.0,
            material: ui_core::draw::BackdropMaterial::PLAIN,
        });
        // An op after the backdrop keeps this test about padding alone, not the drain.
        // 在 backdrop 之后放一个图元，使这条测试只检验外延，而不牵扯末尾排空。
        list.push_rect(nid(2), prim(0.0, 0.0, 0.0, 0.0, Color::from_rgba8(0, 0, 0, 0)));

        let mut target = Pixels::new(120, 60);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);

        let edge = target.get(10, 30);
        assert!(
            edge[0] < 200,
            "the frost edge must mix in the darker side, got {edge:?}"
        );
    }

    #[test]
    fn opaque_rect_fills_its_area_and_nothing_else() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 20.0, 20.0));
        list.push_rect(nid(0), prim(5.0, 5.0, 10.0, 10.0, Color::WHITE));

        let mut target = Pixels::new(20, 20);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);

        assert_eq!(
            target.get(10, 10),
            [255, 255, 255, 255],
            "inside must be white"
        );
        assert_eq!(target.get(1, 1), [0, 0, 0, 0], "outside must stay clear");
    }

    #[test]
    fn a_transparent_border_does_not_shrink_the_fill() {
        // A bordered box used to fill only the inset rect, so a transparent border left a
        // ring of nothing: a 2 dp border made the visible box 4 dp narrower than laid out.
        // 带边框的盒子过去只填充内缩矩形，透明边框会留下一圈空白：2dp 边框使可见盒子比布局
        // 窄 4dp。这条把「铺满再叠环」钉住。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 20.0, 20.0));
        list.push_rect(
            nid(0),
            RectPrim {
                rect: Rect::new(0.0, 0.0, 20.0, 20.0),
                radius: Corners::ZERO,
                fill: Color::from_rgba8(0, 200, 0, 255),
                gradient: None,
                border: Some((Color::TRANSPARENT, 2.0)),
                border_gradient: None,
                notch: None,
            },
        );
        let mut target = Pixels::new(20, 20);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);
        // Every pixel of the rect, including the 2 dp rim, must carry the fill.
        // 矩形内每个像素（含 2dp 边缘）都必须带填充。
        for (x, y) in [(0, 0), (19, 0), (0, 19), (19, 19), (10, 1), (1, 10)] {
            let got = target.get(x, y);
            assert!(got[1] > 190 && got[3] > 250, "({x},{y}) = {got:?} must be filled");
        }
    }

    #[test]
    fn a_notch_cuts_the_top_border_and_leaves_the_fill_under_it() {
        // An outlined field's label sits in this gap: the stroke must be absent there and
        // the box's own fill must still paint, or the label would cover a see-through hole.
        // 带描边字段的标签居于此缺口：那里必须没有描边，而盒子自身的填充仍要画，
        // 否则标签会盖在一个透空的洞上。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 40.0, 20.0));
        list.push_rect(
            nid(0),
            RectPrim {
                rect: Rect::new(0.0, 0.0, 40.0, 20.0),
                radius: Corners::ZERO,
                fill: Color::from_rgba8(0, 200, 0, 255),
                gradient: None,
                border: Some((Color::from_rgba8(200, 0, 0, 255), 2.0)),
                border_gradient: None,
                notch: Some((10.0, 30.0)),
            },
        );
        let mut target = Pixels::new(40, 20);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);
        let top_in_gap = target.get(20, 1);
        assert!(
            top_in_gap[1] > 190 && top_in_gap[0] < 40,
            "inside the notch the fill must show, got {top_in_gap:?}"
        );
        for (x, y, what) in [
            (5, 1, "top left of the gap"),
            (35, 1, "top right of the gap"),
            (20, 19, "bottom edge"),
            (1, 10, "left edge"),
        ] {
            let got = target.get(x, y);
            assert!(got[0] > 190 && got[1] < 40, "{what} must stay bordered, got {got:?}");
        }
    }

    #[test]
    fn a_quarter_arc_paints_its_sweep_and_nothing_else() {
        // Trim is measured in turns clockwise from 3 o'clock, as Lottie and WinUI's
        // `TrimEnd` do: 0.0..=0.25 is the lower-right quadrant on a y-down screen.
        // 扫动以“圈”计、自三点钟顺时针，与 Lottie 和 WinUI 的 `TrimEnd` 一致：
        // 在 y 向下的屏幕上，0.0..=0.25 即右下四分之一。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 40.0, 40.0));
        list.push_sector(
            nid(0),
            ui_core::draw::SectorPrim {
                bounds: Rect::new(0.0, 0.0, 40.0, 40.0),
                colour: Color::from_rgba8(0, 200, 0, 255),
                sector: ui_core::draw::Sector {
                    centre: ui_core::geom::Point::new(20.0, 20.0),
                    radius: 16.0,
                    thickness: 4.0,
                    trim: (0.0, 0.25),
                    round_caps: false,
                },
            },
        );
        let mut target = Pixels::new(40, 40);
        let mut renderer = CpuRenderer::new();
        renderer.render(&list, &mut target, &Damage::Full);
        // Mid-stroke of each diagonal, all 14 px from the centre.
        // 每条对角线上的描边中点，距圆心都是 14 像素。
        let lit = target.get(30, 30);
        assert!(lit[1] > 150, "the lower-right quadrant is painted, got {lit:?}");
        for (x, y, what) in [(10, 30, "lower left"), (30, 10, "upper right"), (10, 10, "upper left")] {
            let got = target.get(x, y);
            assert!(got[1] < 40, "{what} is outside the sweep, got {got:?}");
        }
        // The inner disc stays empty: this is a stroke, not a wedge.
        // 内部圆盘是空的：这是一段描边，不是扇形。
        let hole = target.get(20, 26);
        assert!(hole[1] < 40, "inside the stroke's inner edge stays clear, got {hole:?}");
    }

    #[test]
    fn a_full_turn_paints_the_whole_ring() {
        // A span of exactly one turn is the closed ring; folding it with `rem_euclid`
        // alone would make a 100% progress ring disappear.
        // 跨度恰为一整圈即闭合圆环；只用 `rem_euclid` 折叠会让 100% 的进度环消失。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 40.0, 40.0));
        list.push_sector(
            nid(0),
            ui_core::draw::SectorPrim {
                bounds: Rect::new(0.0, 0.0, 40.0, 40.0),
                colour: Color::from_rgba8(0, 200, 0, 255),
                sector: ui_core::draw::Sector {
                    centre: ui_core::geom::Point::new(20.0, 20.0),
                    radius: 16.0,
                    thickness: 4.0,
                    trim: (0.0, 1.0),
                    round_caps: false,
                },
            },
        );
        let mut target = Pixels::new(40, 40);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);
        for (x, y, what) in [(34, 20, "three o'clock"), (20, 6, "twelve"), (6, 20, "nine")] {
            let got = target.get(x, y);
            assert!(got[1] > 150, "{what} lies on the ring, got {got:?}");
        }
        let hole = target.get(20, 20);
        assert!(hole[1] < 40, "the inner disc stays clear, got {hole:?}");
    }

    #[test]
    fn a_notch_keeps_its_logical_width_at_a_fractional_scale() {
        // The notch is stated in logical units; the loop runs in device pixels. Comparing
        // device x against the logical range made the gap half as wide at scale 2, leaving a
        // hairline of stroke under a floating label.
        // 缺口按逻辑单位声明，而循环跑在设备像素上。拿设备 x 比逻辑区间会让 scale 2 下缺口
        // 只有一半宽，浮起标签下因此留下一条细线。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 40.0, 20.0));
        list.push_rect(
            nid(0),
            RectPrim {
                rect: Rect::new(0.0, 0.0, 40.0, 20.0),
                radius: Corners::ZERO,
                fill: Color::from_rgba8(0, 200, 0, 255),
                gradient: None,
                border: Some((Color::from_rgba8(200, 0, 0, 255), 2.0)),
                border_gradient: None,
                notch: Some((10.0, 30.0)),
            },
        );
        let mut target = Pixels::new(80, 40);
        let mut renderer = CpuRenderer::new();
        renderer.set_scale(2.0);
        renderer.render(&list, &mut target, &Damage::Full);
        // Logical 10..30 is device 20..60, and the top border is device 0..4; the stroke's
        // antialiased skirt reaches half a device pixel further and must be cut with it.
        // 逻辑 10..30 即设备 20..60，顶边描边为设备 0..4；描边的抗锯齿边缘再伸半个设备像素，
        // 也要一并切掉。
        for (x, y, what) in [
            (24, 4, "left end of the gap"),
            (40, 4, "middle of the gap"),
            (56, 4, "right end of the gap"),
        ] {
            let got = target.get(x, y);
            assert!(got[1] > 190 && got[0] < 40, "{what} must show fill, got {got:?}");
        }
        for (x, y, what) in [
            (10, 2, "left of the gap"),
            (70, 2, "right of the gap"),
            (40, 36, "bottom edge"),
        ] {
            let got = target.get(x, y);
            assert!(got[0] > 190 && got[1] < 40, "{what} must stay bordered, got {got:?}");
        }
    }

    #[test]
    fn the_ring_band_carries_no_fill_colour_on_its_antialiased_edge() {
        // Stacking two blends double-counts the feather: the fill shows through the ring's
        // outer edge. Outside the inner shape only the border may appear, so those pixels
        // must be pure red — the bug made them (255,183,183) at alpha 185.
        // 叠加两次混合会把羽化算重：填充从环的外缘透出来。内形状之外只应有边框，
        // 那些像素必须是纯红——缺陷版本给出 (255,183,183)、alpha 185。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 24.0, 24.0));
        list.push_rect(
            nid(0),
            RectPrim {
                rect: Rect::new(0.0, 0.0, 24.0, 24.0),
                radius: Corners::all(12.0),
                fill: Color::from_rgba8(255, 255, 255, 255),
                gradient: None,
                border: Some((Color::from_rgba8(255, 0, 0, 255), 2.0)),
                border_gradient: None,
                notch: None,
            },
        );
        let mut target = Pixels::new(24, 24);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);
        // The inner shape is inset by the border width, so its boundary sits at radius 10;
        // anything beyond 10.6 can only be ring or background.
        // 内形状按边框宽度内缩，边界在半径 10；超过 10.6 的像素只可能是环或背景。
        let mut checked = 0;
        for y in 0..24u32 {
            for x in 0..24u32 {
                let dx = x as f32 + 0.5 - 12.0;
                let dy = y as f32 + 0.5 - 12.0;
                if (dx * dx + dy * dy).sqrt() < 10.6 {
                    continue;
                }
                let [r, g, b, a] = target.get(x, y);
                if a == 0 {
                    continue;
                }
                assert!(
                    r > 240 && g < 3 && b < 3,
                    "({x},{y}) is ring-only but reads rgba({r},{g},{b},{a})"
                );
                checked += 1;
            }
        }
        assert!(checked > 40, "the ring band must actually be sampled, got {checked}");
    }

    #[test]
    fn a_vertical_gradient_varies_down_the_box() {
        // A gradient is only real if the rasteriser samples per pixel: a backend that
        // ignores it draws the flat `fill` and this test reads one colour three times.
        // 渐变只有在光栅器逐像素采样时才真实存在：忽略它的后端会画成平面 `fill`，
        // 本测试就会读到三个相同的颜色。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 8.0, 32.0));
        list.push_rect(
            nid(0),
            RectPrim {
                rect: Rect::new(0.0, 0.0, 8.0, 32.0),
                radius: Corners::ZERO,
                fill: Color::from_rgba8(255, 0, 0, 255),
                gradient: Some(ui_core::draw::Gradient::new(
                    Color::WHITE,
                    Color::BLACK,
                    ui_core::draw::GradientAxis::Vertical,
                )),
                border: None,
                border_gradient: None,
                notch: None,
            },
        );
        let mut target = Pixels::new(8, 32);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);
        let top = target.get(4, 1)[0];
        let mid = target.get(4, 16)[0];
        let bottom = target.get(4, 30)[0];
        assert!(top > mid && mid > bottom, "top {top} mid {mid} bottom {bottom}");
        assert!(top > 240 && bottom < 16, "the stops must reach the ends: {top}/{bottom}");
        // The solid fill is the fallback only; it must not leak into the gradient.
        // 实色只是回落；不得渗进渐变结果。
        assert!(target.get(4, 1)[1] > 200, "green must follow the gradient, not the red fill");
    }

    #[test]
    fn any_damage_repaints_the_whole_surface() {
        // The contract after removing incremental repaint: `damage` only says *whether* to
        // draw, never *where*. A surface that kept last frame's pixels outside the named
        // rects is exactly what let a backdrop read stale content, so the untouched area
        // must come out cleared rather than inherited.
        // 撤除增量重绘后的契约：`damage` 只决定**是否**绘制，绝不决定**哪里**。保留上帧
        // 矩形之外像素，正是背景能读到陈旧内容的来源，因此未被重画的区域必须是被清空的，
        // 而不是继承来的。
        let mut renderer = CpuRenderer::new();
        let mut first = Pixels::new(20, 20);
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 20.0, 20.0));
        list.push_rect(nid(0), prim(0.0, 0.0, 20.0, 20.0, Color::WHITE));
        renderer.render(&list, &mut first, &Damage::Full);
        assert_eq!(first.get(15, 15), [255, 255, 255, 255]);

        let empty = DrawList::new(Rect::new(0.0, 0.0, 20.0, 20.0));
        let mut second = Pixels::new(20, 20);
        second.fill(Color::from_rgba8(0, 0, 255, 255));
        renderer.render(
            &empty,
            &mut second,
            &Damage::Rects(vec![Rect::new(0.0, 0.0, 4.0, 4.0)]),
        );
        assert_eq!(
            second.get(15, 15),
            [0, 0, 0, 0],
            "a damaged frame is repainted whole, so the far corner is cleared"
        );
    }

    #[test]
    fn half_alpha_white_over_black_lands_mid_grey() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 4.0, 4.0));
        list.push_rect(nid(0), prim(0.0, 0.0, 4.0, 4.0, Color::from_rgba8(0, 0, 0, 255)));
        list.push_rect(
            nid(1),
            prim(0.0, 0.0, 4.0, 4.0, Color::from_rgba8(255, 255, 255, 128)),
        );

        let mut target = Pixels::new(4, 4);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);
        let px = target.get(2, 2);
        assert!(
            px[0] > 100 && px[0] < 160,
            "50% white over black should be mid grey, got {px:?}"
        );
    }

    #[test]
    fn clip_excludes_pixels_outside_the_clip_rect() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 20.0, 20.0));
        list.push_clip(Rect::new(0.0, 0.0, 10.0, 20.0), Corners::ZERO);
        list.push_rect(nid(0), prim(0.0, 0.0, 20.0, 20.0, Color::WHITE));
        list.pop_clip();

        let mut target = Pixels::new(20, 20);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);

        assert_eq!(target.get(5, 10), [255, 255, 255, 255], "inside clip");
        assert_eq!(
            target.get(15, 10),
            [0, 0, 0, 0],
            "outside clip must be untouched"
        );
    }

    #[test]
    fn fractional_scale_enlarges_geometry_by_the_scale_factor() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 40.0, 40.0));
        list.push_rect(nid(0), prim(10.0, 10.0, 10.0, 10.0, Color::WHITE));

        let mut target = Pixels::new(40, 40);
        let mut renderer = CpuRenderer::new();
        renderer.set_scale(2.0);
        renderer.render(&list, &mut target, &Damage::Full);

        // Logical (10,10,10,10) at 2x covers device pixels 20..40.
        // 逻辑 (10,10,10,10) 在 2 倍下覆盖设备像素 20..40。
        assert_eq!(target.get(10, 10)[3], 0, "logical area is now elsewhere");
        assert_eq!(target.get(25, 25), [255, 255, 255, 255], "scaled area filled");
    }

    #[test]
    fn scale_of_one_leaves_pixels_unchanged() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 20.0, 20.0));
        list.push_rect(nid(0), prim(4.0, 4.0, 8.0, 8.0, Color::WHITE));

        let mut unscaled = Pixels::new(20, 20);
        CpuRenderer::new().render(&list, &mut unscaled, &Damage::Full);

        let mut scaled = Pixels::new(20, 20);
        let mut r = CpuRenderer::new();
        r.set_scale(1.0);
        r.render(&list, &mut scaled, &Damage::Full);

        assert_eq!(unscaled.as_bytes(), scaled.as_bytes());
    }

    #[test]
    fn invalid_scale_falls_back_to_one() {
        let mut r = CpuRenderer::new();
        r.set_scale(0.0);
        assert_eq!(r.scale(), 1.0);
        r.set_scale(f32::NAN);
        assert_eq!(r.scale(), 1.0);
    }

    #[test]
    fn rounded_corner_leaves_the_corner_pixel_clear() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 20.0, 20.0));
        list.push_rect(
            nid(0),
            RectPrim {
                rect: Rect::new(0.0, 0.0, 20.0, 20.0),
                radius: Corners::all(8.0),
                fill: Color::WHITE,
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
        let mut target = Pixels::new(20, 20);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);

        assert_eq!(
            target.get(0, 0)[3],
            0,
            "corner outside the radius stays clear"
        );
        assert_eq!(
            target.get(10, 10),
            [255, 255, 255, 255],
            "centre is filled"
        );
    }
}

/// Effects and bounds recorded for a layer index; empty when absent.
/// 层索引记录的效果链与边界，缺失时为空。
fn layer_plan(list: &DrawList, index: u32) -> (Vec<Effect>, Rect, ui_core::geom::Corners) {
    list.layers
        .get(index as usize)
        .map(|l| (l.effects.clone(), l.bounds, l.radius))
        .unwrap_or_default()
}

/// Run an effect chain over a layer buffer, returning the residual uniform opacity.
/// 对层缓冲执行效果链，返回剩余的均匀不透明度。
///
/// Kernels are separable, so each costs two 1D passes instead of one 2D pass.
/// 卷积核可分离，因此每个核用两趟一维而不是一趟二维。
fn apply_effects(pixels: &mut Pixels, effects: &[Effect], region: Rect) -> f32 {
    let mut opacity = 1.0f32;
    for effect in effects {
        if effect.is_box() {
            box_blur(pixels, effect.kernel.radius, region);
        } else if !effect.kernel.is_identity() {
            convolve(pixels, &effect.kernel, region);
        }
        if effect.color.is_identity() {
            continue;
        }
        match effect.color.as_opacity() {
            // Keep the cheap case cheap: a pure fade folds into the blend below.
            // 便宜的情形保持便宜：纯淡出折进下面的混合。
            Some(a) => opacity *= a,
            None => transform(pixels, &effect.color, region),
        }
    }
    opacity
}

/// The blurred band covering `rect`, taken from `src` with the padding the kernel reads.
/// 覆盖 `rect` 的模糊工带，取自 `src`，带内核要读的外延。
struct Band {
    x0: u32,
    y0: u32,
    w: u32,
    data: Vec<u8>,
}

impl Band {
    /// Blur `rect` of `src` into a band, or `None` when it falls outside the surface.
    /// 把 `src` 的 `rect` 模糊成工带；矩形落在表面之外时为 `None`。
    fn take(src: &Pixels, sigma: f32, rect: Rect) -> Option<Band> {
        let radius = ui_core::boxblur::radius_for_sigma(sigma);
        if radius == 0 {
            return None;
        }
        // The chain reads one radius per pass, so the neighbourhood must reach the whole band.
        // 链中每趟读一个半径，因此邻域必须覆盖整个工带。
        let band = radius * ui_core::boxblur::BOX_PASSES;
        let padded = ui_core::geom::Insets::all(band as f32).expand(rect);
        let (px0, py0, px1, py1) = clip_to(padded, src.width, src.height);
        if px1 <= px0 || py1 <= py0 {
            return None;
        }
        let (w, h) = ((px1 - px0) as usize, (py1 - py0) as usize);
        let mut temp = Pixels::new(w as u32, h as u32);
        for row in 0..h {
            let from = ((py0 as usize + row) * src.width as usize + px0 as usize) * 4;
            let to = row * w * 4;
            temp.data[to..to + w * 4].copy_from_slice(&src.data[from..from + w * 4]);
        }
        box_blur(&mut temp, radius, Rect::new(0.0, 0.0, w as f32, h as f32));
        Some(Band { x0: px0, y0: py0, w: w as u32, data: temp.data })
    }

    /// Keep only `rect`, written into `dst` at the same place it was read from.
    /// 只保留 `rect`，写回 `dst` 中它被读出的同一位置。
    fn write_into(&self, dst: &mut Pixels, rect: Rect) {
        let (rx0, ry0, rx1, ry1) = clip_to(rect, dst.width, dst.height);
        if rx1 <= rx0 || ry1 <= ry0 {
            return;
        }
        let w = self.w as usize;
        let stride = dst.width as usize * 4;
        for y in ry0..ry1 {
            let from = ((y - self.y0) as usize * w + (rx0 - self.x0) as usize) * 4;
            let to = y as usize * stride + rx0 as usize * 4;
            let n = (rx1 - rx0) as usize * 4;
            dst.data[to..to + n].copy_from_slice(&self.data[from..from + n]);
        }
    }
}

/// Blur the backdrop under `rect` in place, padded so edge taps read real neighbours.
/// 就地模糊 `rect` 下方的背景，并做外延，使边缘的 tap 读到真实邻居。
fn backdrop_blur(target: &mut Pixels, sigma: f32, rect: Rect) {
    // The band is copied out before anything is written, so one buffer serves both ends.
    // 工带在写入任何像素前就被取出，因此同一块缓冲可以既作源又作目标。
    if let Some(band) = Band::take(target, sigma, rect) {
        band.write_into(target, rect);
    }
}

/// Three box averages over `region`: a Gaussian whose cost does not grow with radius.
/// 在 `region` 上做三次箱式平均：代价不随半径增长的高斯。
fn box_blur(pixels: &mut Pixels, radius: u32, region: Rect) {
    let (x0, y0, x1, y1) = clip_to(region, pixels.width, pixels.height);
    if x1 <= x0 || y1 <= y0 {
        return;
    }
    let stride = pixels.width as usize;
    let (bx, by) = (x0 as usize, y0 as usize);
    let (bw, bh) = ((x1 - x0) as usize, (y1 - y0) as usize);
    for _ in 0..3 {
        ui_core::boxblur::box_h(&mut pixels.data, stride, bx, by, bw, bh, radius);
        ui_core::boxblur::box_v(&mut pixels.data, stride, bx, by, bw, bh, radius);
    }
}

/// Two 1D passes of `kernel` over `region`, edges clamped to the border pixel.
/// 在 `region` 上做两趟一维 `kernel`，边缘取边界像素。
fn convolve(pixels: &mut Pixels, kernel: &Kernel, region: Rect) {
    let (x0, y0, x1, y1) = clip_to(region, pixels.width, pixels.height);
    if x1 <= x0 || y1 <= y0 {
        return;
    }
    let w = pixels.width as usize;
    let r = kernel.radius as i32;
    let mut scratch = pixels.data.clone();
    for y in y0..y1 {
        let row = y as usize * w;
        for x in x0..x1 {
            let mut acc = [0.0f32; 4];
            for (i, weight) in kernel.weights.iter().enumerate() {
                let sx = (x as i32 + i as i32 - r).clamp(x0 as i32, x1 as i32 - 1) as usize;
                let o = (row + sx) * 4;
                for c in 0..4 {
                    acc[c] += weight * scratch[o + c] as f32;
                }
            }
            let o = (row + x as usize) * 4;
            for c in 0..4 {
                pixels.data[o + c] = acc[c].clamp(0.0, 255.0) as u8;
            }
        }
    }
    scratch.copy_from_slice(&pixels.data);
    for x in x0..x1 {
        for y in y0..y1 {
            let mut acc = [0.0f32; 4];
            for (i, weight) in kernel.weights.iter().enumerate() {
                let sy = (y as i32 + i as i32 - r).clamp(y0 as i32, y1 as i32 - 1) as usize;
                let o = (sy * w + x as usize) * 4;
                for c in 0..4 {
                    acc[c] += weight * scratch[o + c] as f32;
                }
            }
            let o = (y as usize * w + x as usize) * 4;
            for c in 0..4 {
                pixels.data[o + c] = acc[c].clamp(0.0, 255.0) as u8;
            }
        }
    }
}

/// Apply a colour matrix to every pixel in `region`.
/// 对 `region` 内每个像素应用颜色矩阵。
fn transform(pixels: &mut Pixels, matrix: &ColorMatrix, region: Rect) {
    let (x0, y0, x1, y1) = clip_to(region, pixels.width, pixels.height);
    let w = pixels.width as usize;
    for y in y0..y1 {
        for x in x0..x1 {
            let o = (y as usize * w + x as usize) * 4;
            let px = [
                pixels.data[o] as f32,
                pixels.data[o + 1] as f32,
                pixels.data[o + 2] as f32,
                pixels.data[o + 3] as f32,
            ];
            let out = matrix.apply(px);
            for c in 0..4 {
                pixels.data[o + c] = out[c].clamp(0.0, 255.0) as u8;
            }
        }
    }
}

/// The pixels a frost may touch: its box cut by the clip, as its own fill would be.
/// 磨砂可以触及的像素：盒子被裁剪后剩下的部分，与它自己的填充一致。
fn frost_area(entry: ui_core::draw::BackdropEntry) -> Rect {
    entry.rect.intersection(entry.clip).unwrap_or(Rect::ZERO)
}

/// Zero a rectangle of a premultiplied buffer.
/// 把预乘缓冲中的一个矩形清零。
fn clear_region(pixels: &mut Pixels, region: Rect) {
    let (x0, y0, x1, y1) = clip_to(region, pixels.width, pixels.height);
    for y in y0..y1 {
        let start = (y as usize * pixels.width as usize + x0 as usize) * 4;
        let end = (y as usize * pixels.width as usize + x1 as usize) * 4;
        pixels.data[start..end].fill(0);
    }
}

/// Source-over composite of a straight-alpha layer scaled by `opacity`.
/// 把直通 alpha 层按 `opacity` 缩放后做 source-over 合成。
/// Same, but the layer only shows inside `bounds` with rounded corners.
/// 同上，但层只在 `bounds` 内、按圆角显示。
fn composite_over_rounded(
    dst: &mut Pixels,
    src: &Pixels,
    opacity: f32,
    region: Rect,
    bounds: Rect,
    radius: ui_core::geom::Corners,
) {
    composite_over_in(
        dst,
        src,
        opacity,
        region,
        ui_core::colour::Encoding::SDR_PREMULTIPLIED,
        bounds,
        radius,
    );
}

fn scale_corners(c: ui_core::geom::Corners, scale: f32) -> ui_core::geom::Corners {
    ui_core::geom::Corners {
        tl: c.tl * scale,
        tr: c.tr * scale,
        br: c.br * scale,
        bl: c.bl * scale,
        ..c
    }
}

/// Composite in `encoding`'s domain; a linear domain decodes, blends, re-encodes.
/// 在 `encoding` 的域里合成；线性域要解码、混合、再编码。
///
/// Premultiplied encoded values cannot be decoded directly, so this un-premultiplies
/// first. That is why a linear domain must be chosen when the buffer is filled, not here.
/// 预乘的编码值不能直接解码，因此先解预乘。也正因如此，线性域必须在填充时决定，不能在这里。
fn composite_over_in(
    dst: &mut Pixels,
    src: &Pixels,
    opacity: f32,
    region: Rect,
    encoding: ui_core::colour::Encoding,
    bounds: Rect,
    radius: ui_core::geom::Corners,
) {
    if opacity <= 0.0 {
        return;
    }
    if encoding.is_linear() {
        composite_linear(dst, src, opacity, region, encoding.transfer);
        return;
    }
    // The buffer contract is straight alpha end to end (AGENTS 1.5: a premultiplied
    // reading over-brightened every layered partial-alpha pixel), so reuse `blend_pixel`.
    // 缓冲从头到尾是直通 alpha，因此复用 `blend_pixel`，保证层内层外同一条公式。
    let width = dst.width as usize;
    let (x0, y0, x1, y1) = clip_to(region, dst.width, dst.height);
    for y in y0..y1 {
        for x in x0..x1 {
            let i = (y as usize * width + x as usize) * 4;
            let cov = coverage_rounded_rect(bounds, radius, x as f32 + 0.5, y as f32 + 0.5);
            if cov <= 0.0 {
                continue;
            }
            let color = Color::rgba(
                src.data[i + 2] as f32 / 255.0,
                src.data[i + 1] as f32 / 255.0,
                src.data[i] as f32 / 255.0,
                src.data[i + 3] as f32 / 255.0,
            );
            blend_pixel(&mut dst.data[i..i + 4], color, opacity * cov);
        }
    }
}

/// Float blend in linear light on straight buffers: decode, alpha-weight, blend, re-encode.
/// 直通缓冲上的线性光浮点混合：解码、按 alpha 加权、混合、再编码。
fn composite_linear(
    dst: &mut Pixels,
    src: &Pixels,
    opacity: f32,
    region: Rect,
    tf: ui_core::colour::TransferFunction,
) {
    let width = dst.width as usize;
    let (x0, y0, x1, y1) = clip_to(region, dst.width, dst.height);
    for y in y0..y1 {
        for x in x0..x1 {
            let i = (y as usize * width + x as usize) * 4;
            let sa = src.data[i + 3] as f32 / 255.0;
            if sa <= 0.0 {
                continue;
            }
            let a = sa * opacity;
            let da = dst.data[i + 3] as f32 / 255.0;
            let out_a = a + da * (1.0 - a);
            if out_a <= 0.0 {
                continue;
            }
            for ch in 0..3 {
                let s_lin = tf.decode(src.data[i + ch] as f32 / 255.0) * a;
                let d_lin = if da > 0.0 {
                    tf.decode(dst.data[i + ch] as f32 / 255.0) * da
                } else {
                    0.0
                };
                let out = s_lin + d_lin * (1.0 - a);
                let enc = tf.encode(out / out_a) * out_a;
                dst.data[i + ch] = (enc * 255.0).round().clamp(0.0, 255.0) as u8;
            }
            dst.data[i + 3] = (out_a * 255.0).round().clamp(0.0, 255.0) as u8;
        }
    }
}

#[cfg(test)]
mod blend_domain_tests {
    use super::*;
    use ui_core::colour::{Encoding, TransferFunction};
    use ui_core::geom::Rect;

    /// Half-transparent white over opaque black, in one 1x1 pixel.
    /// 半透明白叠在不透明黑上，1x1 像素。
    fn white_half_over_black(decode_first: bool) -> u8 {
        let mut dst = Pixels::new(1, 1);
        dst.data[0..4].copy_from_slice(&[0, 0, 0, 255]);
        let mut src = Pixels::new(1, 1);
        // Straight contract: full-white channel at half alpha, not premultiplied halves.
        // 直通约定：满白通道配半透明 alpha，而不是预乘的一半。
        src.data[0..4].copy_from_slice(&[255, 255, 255, 128]);
        let region = Rect::new(0.0, 0.0, 1.0, 1.0);
        if decode_first {
            composite_linear(&mut dst, &src, 1.0, region, TransferFunction::Srgb);
        } else {
            composite_over_rounded(&mut dst, &src, 1.0, region, region, ui_core::geom::Corners::all(0.0));
        }
        dst.data[0]
    }

    #[test]
    fn decoding_before_blending_brightens_a_mid_tone_by_tens_of_levels() {
        // 50% white over black: encoded blend gives 128, decode-blend-encode gives ~187.
        // The gap is ~59 levels, so the earlier "within one LSB" note was simply wrong.
        // 50% 白叠黑：编码域混合得 128，解码后混合再编码得约 187。
        // 差约 59 级，所以先前「在 1 LSB 内」的笔记是错的。
        let encoded = white_half_over_black(false);
        let decoded = white_half_over_black(true);
        assert!((encoded as i32 - 128).abs() <= 2, "encoded gave {encoded}");
        assert!((decoded as i32 - 187).abs() <= 4, "decoded gave {decoded}");
        assert!(
            decoded > encoded + 40,
            "gap {encoded} -> {decoded} is too small to be a real domain difference"
        );
    }

    #[test]
    fn an_opaque_source_gives_the_same_result_in_both_domains() {
        // With alpha 1 the blend is a copy, so the domain must not matter.
        // alpha 为 1 时混合就是复制，因此域不应有影响。
        let mut dst = Pixels::new(1, 1);
        dst.data[0..4].copy_from_slice(&[0, 0, 0, 255]);
        let mut src = Pixels::new(1, 1);
        src.data[0..4].copy_from_slice(&[200, 200, 200, 255]);
        let mut linear = dst.clone();
        composite_over_rounded(
            &mut dst,
            &src,
            1.0,
            Rect::new(0.0, 0.0, 1.0, 1.0),
            Rect::new(0.0, 0.0, 1.0, 1.0),
            ui_core::geom::Corners::all(0.0),
        );
        composite_over_in(
            &mut linear,
            &src,
            1.0,
            Rect::new(0.0, 0.0, 1.0, 1.0),
            Encoding {
                transfer: TransferFunction::Srgb,
                premultiplied: true,
            },
            Rect::new(0.0, 0.0, 1.0, 1.0),
            ui_core::geom::Corners::all(0.0),
        );
        assert_eq!(dst.data[0], 200);
        assert_eq!(linear.data[0], 200);
    }
}

#[cfg(test)]
mod layer_tests {
    use super::*;
    use ui_core::draw::{DrawList, RectPrim};
    use ui_core::geom::{Color, Corners};
    use ui_core::NodeId;

    fn opaque_white(x: f32, y: f32) -> RectPrim {
        RectPrim {
            rect: Rect::new(x, y, 20.0, 20.0),
            radius: Corners::ZERO,
            fill: Color::WHITE,
            gradient: None,
            border: None,
            border_gradient: None,
            notch: None,
        }
    }

    /// Two opaque squares that overlap, inside a layer at `opacity`.
    /// 层内两个重叠的不透明方块。
    fn overlapping_in_layer(opacity: f32) -> DrawList {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        list.push_layer(Rect::new(0.0, 0.0, 100.0, 100.0), vec![ui_core::Effect::opacity(opacity)], Corners::ZERO);
        list.push_rect(NodeId::from_raw(1, 0), opaque_white(10.0, 10.0));
        list.push_rect(NodeId::from_raw(2, 0), opaque_white(20.0, 10.0));
        list.pop_layer();
        list
    }

    fn render(list: &DrawList) -> Pixels {
        let mut target = Pixels::new(100, 100);
        let mut renderer = CpuRenderer::new();
        renderer.render(list, &mut target, &Damage::Full);
        target
    }

    fn alpha_at(pixels: &Pixels, x: u32, y: u32) -> u8 {
        pixels.data[((y * pixels.width + x) * 4 + 3) as usize]
    }

    #[test]
    fn group_opacity_does_not_double_darken_overlaps() {
        // The defining property of a layer: the group composites once, so two
        // overlapping opaque children stay at exactly the layer's opacity.
        // 层的定义性质：整组只合成一次，两个重叠的不透明子节点都恰好是层的不透明度。
        let pixels = render(&overlapping_in_layer(0.5));
        let single = alpha_at(&pixels, 15, 20);
        let overlap = alpha_at(&pixels, 25, 20);
        assert_eq!(
            single, overlap,
            "overlap must not be darker than a single child: {single} vs {overlap}"
        );
        assert!(
            (120..=136).contains(&single),
            "50% layer should land near 128, got {single}"
        );
    }

    #[test]
    fn per_primitive_alpha_would_double_darken() {
        // Contrast case: the same two squares with alpha 0.5 on each primitive and no
        // layer. This is what a layer must *not* look like.
        // 对照：同样两个方块，每个图元自带 0.5 alpha 且无层。层不能长成这样。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        for (i, x) in [10.0f32, 20.0].into_iter().enumerate() {
            let mut prim = opaque_white(x, 10.0);
            prim.fill = Color::rgba(1.0, 1.0, 1.0, 0.5);
            list.push_rect(NodeId::from_raw(i as u32 + 1, 0), prim);
        }
        let pixels = render(&list);
        let single = alpha_at(&pixels, 15, 20);
        let overlap = alpha_at(&pixels, 25, 20);
        assert!(
            overlap > single,
            "per-primitive alpha must darken the overlap ({overlap}) beyond a single ({single})"
        );
    }

    #[test]
    fn a_fully_opaque_layer_is_transparent_to_the_result() {
        // opacity 1.0 must be a no-op, so introducing a layer cannot change pixels.
        let mut with_layer = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        with_layer.push_layer(Rect::new(0.0, 0.0, 100.0, 100.0), Vec::new(), Corners::ZERO);
        with_layer.push_rect(NodeId::from_raw(1, 0), opaque_white(10.0, 10.0));
        with_layer.pop_layer();

        let mut plain = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        plain.push_rect(NodeId::from_raw(1, 0), opaque_white(10.0, 10.0));

        assert_eq!(
            render(&with_layer).data,
            render(&plain).data,
            "an opaque layer must not alter any pixel"
        );
    }

    #[test]
    fn nested_layers_multiply_their_opacities() {
        // Inner 0.5 inside outer 0.5 composites to 0.25.
        // 外层 0.5 套内层 0.5 合成后为 0.25。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        list.push_layer(Rect::new(0.0, 0.0, 100.0, 100.0), vec![ui_core::Effect::opacity(0.5)], Corners::ZERO);
        list.push_layer(Rect::new(0.0, 0.0, 100.0, 100.0), vec![ui_core::Effect::opacity(0.5)], Corners::ZERO);
        list.push_rect(NodeId::from_raw(1, 0), opaque_white(10.0, 10.0));
        list.pop_layer();
        list.pop_layer();

        let pixels = render(&list);
        let a = alpha_at(&pixels, 15, 20);
        assert!(
            (56..=72).contains(&a),
            "nested 0.5 * 0.5 should land near 64, got {a}"
        );
    }

    #[test]
    fn content_outside_a_layer_is_unaffected() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        list.push_rect(NodeId::from_raw(1, 0), opaque_white(60.0, 60.0));
        list.push_layer(Rect::new(0.0, 0.0, 100.0, 100.0), vec![ui_core::Effect::opacity(0.25)], Corners::ZERO);
        list.push_rect(NodeId::from_raw(2, 0), opaque_white(10.0, 10.0));
        list.pop_layer();

        let pixels = render(&list);
        assert_eq!(
            alpha_at(&pixels, 65, 65),
            255,
            "a primitive outside the layer stays opaque"
        );
        assert!(
            alpha_at(&pixels, 15, 15) < 80,
            "the layered primitive must be faded"
        );
    }
}

#[cfg(test)]
mod effect_tests {
    use super::*;
    use ui_core::effect::Effect;
    use ui_core::geom::{Color, Rect};
    use ui_core::NodeId;

    const SIZE: u32 = 96;

    /// One white 24x24 square at (36,36) inside a layer, everything else transparent.
    /// 一个位于 (36,36) 的白色 24x24 方块放在层里，其余透明。
    fn scene(effects: Vec<Effect>) -> Pixels {
        scene_with_bounds(effects, Rect::new(0.0, 0.0, SIZE as f32, SIZE as f32))
    }

    fn scene_with_bounds(effects: Vec<Effect>, bounds: Rect) -> Pixels {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, SIZE as f32, SIZE as f32));
        list.push_layer(
            bounds,
            effects,
            Corners::ZERO,
        );
        list.push_rect(
            NodeId::from_raw(1, 0),
            RectPrim {
                rect: Rect::new(36.0, 36.0, 24.0, 24.0),
                radius: Corners::ZERO,
                fill: Color::WHITE,
                border: None,
                border_gradient: None,
                gradient: None,
                notch: None,
            },
        );
        list.pop_layer();
        let mut target = Pixels::new(SIZE, SIZE);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);
        target
    }

    fn ink(px: &Pixels) -> u64 {
        px.data
            .as_chunks::<4>().0.iter()
            .map(|c| c[0] as u64 + c[1] as u64 + c[2] as u64)
            .sum()
    }

    fn at(px: &Pixels, x: u32, y: u32) -> [u8; 4] {
        let o = ((y * px.width + x) * 4) as usize;
        [px.data[o], px.data[o + 1], px.data[o + 2], px.data[o + 3]]
    }

    #[test]
    fn a_normalised_kernel_redistributes_ink_without_creating_it() {
        // Only u8 quantisation may move the total, so allow 1% and no more.
        // 只有 u8 量化能让总量变化，因此容许 1%，不能更多。
        let sharp = ink(&scene(vec![Effect::none()]));
        let blurred = ink(&scene(vec![Effect::blur(6, 2.5)]));
        let drift = (sharp as i64 - blurred as i64).abs();
        // 2%: u8 rounding on a small spot is the only legitimate drift, and it is not zero.
        // 2%：小色块上的 u8 取整是唯一合法的漂移，且它不为零。
        assert!(
            drift * 50 <= sharp as i64,
            "ink {sharp} -> {blurred} (drift {drift})"
        );
    }

    #[test]
    fn a_blur_lowers_the_peak_and_widens_the_spot() {
        // Spreading and dimming are one fact seen from two pixels.
        // 摊开与变暗是同一件事从两个像素看到的两个面。
        let sharp = scene(vec![Effect::none()]);
        let blurred = scene(vec![Effect::blur(6, 2.5)]);
        let centre_sharp = at(&sharp, 48, 48)[3];
        let centre_blur = at(&blurred, 48, 48)[3];
        let edge_sharp = at(&sharp, 34, 48)[3];
        let edge_blur = at(&blurred, 34, 48)[3];
        assert!(
            centre_blur < centre_sharp,
            "centre {centre_sharp} -> {centre_blur}"
        );
        assert!(edge_blur > edge_sharp, "edge {edge_sharp} -> {edge_blur}");
    }

    #[test]
    fn a_blur_does_not_reach_beyond_its_radius() {
        // The kernel is truncated, so a pixel farther than `radius` must be untouched.
        // 核被截断，因此距离超过 `radius` 的像素必须不受影响。
        let sharp = scene(vec![Effect::none()]);
        let blurred = scene(vec![Effect::blur(4, 1.5)]);
        // Square spans 36..60, so with radius 4 the last reachable pixel is 63.
        // 方块覆盖 36..60，因此半径 4 时最后一个可触及像素是 63。
        let far = 60 + 4;
        assert_eq!(
            at(&sharp, far, 48),
            at(&blurred, far, 48),
            "pixel at x={far} must be untouched"
        );
        // Just inside the reach must have changed, or the test proves nothing.
        // 刚好在触及范围内侧的像素必须改变，否则本测试什么也没证明。
        assert!(
            at(&blurred, far - 2, 48)[3] > at(&sharp, far - 2, 48)[3],
            "x={} must have gained ink",
            far - 2
        );
    }

    #[test]
    fn a_layer_whose_bounds_cover_the_reach_matches_the_full_canvas() {
        // Restricting the effect region must not change a single pixel.
        // 收紧效果区域不得改变任何一个像素。
        let reach = 4.0;
        let dot = Rect::new(36.0, 36.0, 24.0, 24.0);
        let tight = Rect::new(
            dot.origin.x - reach,
            dot.origin.y - reach,
            dot.size.w + 2.0 * reach,
            dot.size.h + 2.0 * reach,
        );
        let full = scene(vec![Effect::blur(4, 1.5)]);
        let clipped = scene_with_bounds(vec![Effect::blur(4, 1.5)], tight);
        assert_eq!(full.data, clipped.data, "reach-sized bounds must be enough");
    }

    #[test]
    fn bounds_that_ignore_the_reach_clip_the_blur() {
        // The negative control: without the dilation the ink cannot leave the box.
        // 反向对照：不外扩时墨迹无法离开盒子。
        let dot = Rect::new(36.0, 36.0, 24.0, 24.0);
        let full = scene(vec![Effect::blur(4, 1.5)]);
        let clipped = scene_with_bounds(vec![Effect::blur(4, 1.5)], dot);
        assert!(at(&full, 62, 48)[3] > 0, "the dilated layer spreads here");
        assert_eq!(at(&clipped, 62, 48)[3], 0, "the tight layer cannot");
    }
}

#[cfg(test)]
mod fill_tests {
    use super::*;
    use ui_core::draw::{DrawList, RectPrim};
    use ui_core::geom::{Color, Corners, Rect};
    use ui_core::NodeId;

    const SIZE: u32 = 64;

    /// A dark canvas with one pill on it; the pill's fill and border come from `fill`.
    /// 深色画布上放一个胶囊；填充色与描边由 `fill` 决定。
    fn pill(fill: Color, border: Option<(Color, f32)>) -> Pixels {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, SIZE as f32, SIZE as f32));
        list.push_rect(
            NodeId::from_raw(1, 0),
            RectPrim {
                rect: Rect::new(0.0, 0.0, SIZE as f32, SIZE as f32),
                radius: Corners::ZERO,
                fill: Color::from_rgba8(30, 32, 40, 255),
                gradient: None,
                border: None,
                border_gradient: None,
                notch: None,
            },
        );
        list.push_rect(
            NodeId::from_raw(2, 0),
            RectPrim {
                rect: Rect::new(8.0, 16.0, 48.0, 16.0),
                radius: Corners::all(8.0),
                fill,
                gradient: None,
                border,
                border_gradient: None,
                notch: None,
            },
        );
        let mut target = Pixels::new(SIZE, SIZE);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);
        target
    }

    fn bgra_at(p: &Pixels, x: u32, y: u32) -> (u8, u8, u8) {
        let i = ((y * p.width + x) * 4) as usize;
        (p.data[i], p.data[i + 1], p.data[i + 2])
    }

    #[test]
    fn a_gradient_stroke_runs_from_its_near_colour_to_its_far_colour() {
        // WinUI draws every control's elevation border as a vertical two-stop gradient;
        // a single flat stroke is a different control at the top edge.
        // WinUI 把每个控件的立面描边画成竖向双停渐变；单一实色描边在顶边就是另一个控件。
        use ui_core::draw::{Gradient, GradientAxis};
        let near = Color::from_rgba8(255, 0, 0, 255);
        let far = Color::from_rgba8(0, 0, 255, 255);
        let mut list = DrawList::new(Rect::new(0.0, 0.0, SIZE as f32, SIZE as f32));
        list.push_rect(
            NodeId::from_raw(9, 0),
            RectPrim {
                rect: Rect::new(8.0, 8.0, 48.0, 48.0),
                radius: Corners::ZERO,
                fill: Color::TRANSPARENT,
                gradient: None,
                border: Some((near, 4.0)),
                border_gradient: Some(Gradient::new(near, far, GradientAxis::Vertical)),
                notch: None,
            },
        );
        let mut target = Pixels::new(SIZE, SIZE);
        CpuRenderer::new().render(&list, &mut target, &Damage::Full);
        let top = bgra_at(&target, 32, 10); // BGRA
        let bottom = bgra_at(&target, 32, 53);
        assert!(top.2 > 200 && top.0 < 40, "the top edge is the near colour: {top:?}");
        assert!(bottom.0 > 200 && bottom.2 < 40, "the bottom edge is the far colour: {bottom:?}");
    }

    #[test]
    fn an_opaque_track_pixel_equals_the_track_colour_not_the_background() {
        // MD3's unselected slider track is `secondaryContainer`; the rect is wide enough
        // that the centre pixel lies well inside it. 未选段轨道是 `secondaryContainer`；矩形够宽，中心像素完全在内部。
        let track = Color::from_rgba8(0xE8, 0xDE, 0xF8, 255);
        let pixels = pill(track, None);
        assert_eq!(bgra_at(&pixels, 32, 24), (0xF8, 0xDE, 0xE8));
        assert_ne!(bgra_at(&pixels, 32, 24), (40, 32, 30));
    }

    #[test]
    fn a_near_transparent_track_pixel_is_painted_rather_than_dropped() {
        // WinUI's unchecked switch track is a 2.4% black wash; painting it must still
        // change the pixel by one or two levels. 未选轨道是 2.4% 黑洗；画上去至少要改变一两级。
        let wash = Color::from_rgba8(0, 0, 0, 6);
        let pixels = pill(wash, None);
        let (b, g, r) = bgra_at(&pixels, 32, 24);
        assert_eq!((r, g, b), (29, 31, 39), "2.4% black over (30,32,40)");
        assert_ne!((r, g, b), (30, 32, 40), "the wash must not be dropped");
    }

    #[test]
    fn a_transparent_border_keeps_the_whole_body_filled() {
        // The old defect hollowed the edge band; area mixing fills the whole body.
        // 旧缺陷把边缘带挖空；按面积混合后整体保持填充。
        let fill = Color::from_rgba8(0xE8, 0xDE, 0xF8, 255);
        let clear = Color::TRANSPARENT;
        let pixels = pill(fill, Some((clear, 2.0)));
        // 9 and 54 sit in the 2dp ring band itself, where the old code drew nothing.
        // 9 与 54 落在 2dp 的环带内，旧实现那里什么都不画。
        for x in [9u32, 16, 32, 48, 54] {
            assert_eq!(
                bgra_at(&pixels, x, 24),
                (0xF8, 0xDE, 0xE8),
                "x={x} lost its fill under a clear border"
            );
        }
    }
}
