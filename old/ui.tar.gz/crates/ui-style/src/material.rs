//! A surface's material: what to do with the pixels behind it, and what to fall back to.
//! 平面的材质：如何处理它身后的像素，以及退路是什么。

use ui_core::geom::Color;

/// The fill recipe one surface draws with.
/// 一个平面绘制所用的填充配方。
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Material {
    /// Opaque paint; nothing behind is read.
    /// 不透明绘制，不读身后任何东西。
    Solid(Color),
    /// Translucent fill over a blurred backdrop, with an opaque stand-in for when the
    /// backend cannot sample or the user asked for reduced transparency.
    /// 模糊背景上的半透明填充；后端无法采样或用户要求减少透明度时用那个不透明替身。
    Frost {
        /// Gaussian sigma of the backdrop blur.
        /// 背景模糊的高斯 sigma。
        sigma: f32,
        /// The tint laid over the blurred pixels.
        /// 覆在模糊像素上的着色。
        tint: Color,
        /// What to draw instead, with nothing sampled behind it.
        /// 退路：什么都不采样时应画的颜色。
        fallback: Color,
    },
    /// WinUI acrylic: luminosity wash, colour tint, grain over the blurred backdrop.
    /// WinUI acrylic：模糊背景之上的亮度洗色、色相着色与噪点。
    Acrylic {
        /// Gaussian sigma of the backdrop blur.
        /// 背景模糊的高斯 sigma。
        sigma: f32,
        /// The acrylic recipe itself.
        /// acrylic 配方本身。
        params: ui_core::draw::Acrylic,
        /// What to draw instead, with nothing sampled behind it.
        /// 退路：什么都不采样时应画的颜色。
        fallback: Color,
    },
    /// WinUI Mica: a wallpaper sample under a theme-tinted layer. No blur, no grain, and
    /// opaque with respect to app content — content behind it does not show through.
    /// WinUI Mica：壁纸采样之上覆一层主题色。不模糊、无噪点，且对应用内容不透明——
    /// 其后的内容不会透出来。
    Mica {
        /// Stable id of the wallpaper texture to sample.
        /// 作为壁纸采样的纹理标识。
        source: u64,
        /// The layer laid over it; `a` is WinUI's mica layer opacity.
        /// 覆在其上的层；`a` 是 WinUI 的 mica 层不透明度。
        tint: Color,
        /// `MicaAlt`: the stronger layer WinUI uses behind tabbed title bars.
        /// `MicaAlt`：WinUI 在标签式标题栏后面用的更强的一层。
        alt: bool,
    },
    /// Glass: LiquidGlassKit's lens, reading a capture of the backdrop at its own density.
    /// 玻璃：LiquidGlassKit 的透镜，按自身密度读取背景捕获。
    Glass {
        /// Gaussian sigma of the backdrop blur.
        /// 背景模糊的高斯 sigma。
        sigma: f32,
        /// The glass recipe itself.
        /// 玻璃配方本身。
        params: ui_core::draw::LiquidGlass,
        /// What to draw instead, with nothing sampled behind it.
        /// 退路：什么都不采样时应画的颜色。
        fallback: Color,
    },
}

impl Material {
    /// The colour an opaque surface would have had; used by the fallback path.
    /// 不透明平面应有的颜色，退路路径使用。
    pub fn fallback_color(&self) -> Color {
        match self {
            Material::Solid(c) => *c,
            Material::Frost { fallback, .. }
            | Material::Acrylic { fallback, .. }
            | Material::Glass { fallback, .. } => *fallback,
            // Mica never falls back: without a wallpaper it is the tint over the base.
            // Mica 没有退路：拿不到壁纸时它就是底色上的那层着色。
            Material::Mica { tint, .. } => *tint,
        }
    }

    /// How the blurred backdrop should be shaded, if this material samples one.
    /// 本材质采样背景时，模糊结果应如何着色。
    pub fn backdrop(&self) -> Option<ui_core::draw::BackdropMaterial> {
        match self {
            Material::Solid(_) | Material::Frost { .. } => None,
            Material::Acrylic { params, .. } => {
                Some(ui_core::draw::BackdropMaterial::Acrylic(*params))
            }
            Material::Glass { params, .. } => {
                Some(ui_core::draw::BackdropMaterial::LiquidGlass(*params))
            }
            // Mica is painted from an image plus a tint, not filtered from the backdrop.
            // Mica 由图像加一层着色绘制，不从背景滤镜来。
            Material::Mica { .. } => None,
        }
    }

    /// Gaussian sigma of the backdrop blur, if this material asks for one.
    /// 本材质要求背景模糊时的高斯 sigma。
    pub fn sigma(&self) -> Option<f32> {
        match self {
            Material::Solid(_) => None,
            Material::Frost { sigma, .. }
            | Material::Acrylic { sigma, .. }
            | Material::Glass { sigma, .. } => Some(*sigma),
            // No blur: mica is a wallpaper sample, so there is nothing to filter.
            // 不模糊：mica 采的是壁纸，没有需要过滤的东西。
            Material::Mica { .. } => None,
        }
    }

    /// Whether this material needs pixels from behind the widget.
    /// 本材质是否需要控件身后的像素。
    pub fn needs_backdrop(&self) -> bool {
        self.sigma().is_some()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ui_core::geom::Color;

    #[test]
    fn a_frost_carries_its_own_fallback_colour() {
        let m = Material::Frost {
            sigma: 14.0,
            tint: Color::from_rgba8(255, 255, 255, 90),
            fallback: Color::from_rgba8(40, 44, 54, 255),
        };
        assert!(m.needs_backdrop());
        assert_eq!(m.fallback_color(), Color::from_rgba8(40, 44, 54, 255));
    }

    #[test]
    fn a_solid_needs_nothing_behind_it() {
        let m = Material::Solid(Color::from_rgba8(1, 2, 3, 255));
        assert!(!m.needs_backdrop());
        assert_eq!(m.fallback_color(), Color::from_rgba8(1, 2, 3, 255));
    }
}
