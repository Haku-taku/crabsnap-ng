//! What the renderer underneath can actually do, so a style resolves to a recipe it
//! can run instead of drawing a plausible lie.
//! 渲染器实际能做到什么，好让风格解析成跑得动的配方，而不是画出看似合理的错画面。

/// Reported by the backend at build time; widgets read it through the style pack.
/// 后端在建立时报出；控件经由风格包读取它。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Capability {
    /// Pixels behind a widget can be sampled, so backdrop blur and frost are real.
    /// 能采样控件身后的像素，背景模糊与磨砂才是真的。
    pub backdrop: bool,
    /// Reduced-transparency preference is set by the user or the environment.
    /// 用户或环境设定了「减少透明度」。
    pub reduced_transparency: bool,
}

impl Capability {
    /// The floor for a backend that cannot sample behind anything at all. The CPU
    /// rasterizer is NOT here: it blurs its own frame, so in-scene backdrop works.
    /// 完全不能采样身后内容的后端底线。CPU 光栅器不在此列：它会模糊自己的帧，场景内背景可用。
    pub const NO_BACKDROP: Self = Self {
        backdrop: false,
        reduced_transparency: false,
    };

    /// The GL path today: backdrop and offscreen passes exist, arbitrary shaders do not.
    /// 当前 GL 路径：有背景与离屏，没有任意着色器阶段。
    pub const GPU_BASELINE: Self = Self {
        backdrop: true,
        reduced_transparency: false,
    };

    /// Whether a frosted surface may draw its blur here, or must use its fallback colour.
    /// 此处能否画磨砂的模糊，还是必须改用回退实色。
    pub fn supports_frost(self) -> bool {

        self.backdrop && !self.reduced_transparency
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reduced_transparency_downgrades_frost_to_no_frost() {
        // Fluent proves the pattern: `DisableAcrylic` yields an opaque fallback, no filter,
        // no noise; the capability must flip the same question.
        // Fluent 证明了这个模式：`DisableAcrylic` 给不透明回退色，无滤波无噪声；能力项要回答同一个问题。
        assert!(Capability::GPU_BASELINE.supports_frost());
        let strict = Capability {
            reduced_transparency: true,
            ..Capability::GPU_BASELINE
        };
        assert!(!strict.supports_frost());
        assert!(!Capability::NO_BACKDROP.supports_frost());
    }
}
