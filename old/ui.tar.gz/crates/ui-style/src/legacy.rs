//! The look the examples drew with literal colours before any pack existed. Data here,
//! not in the widgets, is what makes a style switch possible.
//! 示例在风格包出现前用字面量画出的那套外观。把它放成数据而非留在控件里，切换风格才可能。

use ui_core::geom::{Color, CornerShape, Insets};
use ui_core::Weight;

use crate::capability::Capability;
use crate::motion::MotionTable;
use crate::roles::{RoleDict, RoleName};
use crate::types::{MetricsSet, TextStyleToken, TypeTable, WidgetMetrics};
use crate::Style;

fn c(v: [u8; 4]) -> Color {
    Color::from_rgba8(v[0], v[1], v[2], v[3])
}

/// The colours and metrics lifted from `window_gpu`'s inline literals.
/// `window_gpu` 内联字面量里提出的颜色与度量。
pub fn legacy_pack() -> Style {
    // Values are the example's own literals: the pill's three states, the card's blue
    // with its lighter hover lift, the scroller's fill, the panel's tint and its dark
    // stand-in. Nothing here invents a shade the example never drew.
    // 数值就是示例自己的字面量：药丸三态、卡片蓝与其悬停的亮蓝、滚动区底色、面板着色与其深色替身。
    let mut roles = RoleDict::new();
    roles.set(RoleName("buttonFill"), c([255, 255, 255, 255]));
    roles.set(RoleName("buttonFillHover"), c([255, 240, 170, 255]));
    roles.set(RoleName("buttonFillPressed"), c([255, 170, 90, 255]));
    roles.set(RoleName("buttonText"), c([20, 30, 50, 255]));
    roles.set(RoleName("buttonBorder"), Color::TRANSPARENT);
    roles.set(RoleName("focusStroke"), c([20, 30, 50, 255]));
    roles.set(RoleName("cardFill"), c([60, 130, 220, 255]));
    roles.set(RoleName("cardBorder"), c([210, 225, 245, 255]));
    roles.set(RoleName("scrollerFill"), c([30, 60, 110, 255]));
    roles.set(RoleName("rowText"), c([210, 225, 250, 255]));
    roles.set(RoleName("glassFallback"), c([18, 20, 26, 255]));
    roles.set(RoleName("glassBorder"), c([255, 255, 255, 90]));

    let style = |size: f32, weight: Weight, _color: Color| TextStyleToken {
        size,
        weight,
        line_gap: 0.0,
        indent: 0.0,
    };
    // The five roles the widgets actually request. The example's other texts (a CJK
    // probe, an RTL probe, a blurred group) are diagnostics, not widgets, and stay inline.
    // 五档只覆盖控件真正请求的角色。示例其余文本（中日韩探针、从右到左探针、模糊组）是诊断件而非控件，保持内联。
    let type_table = TypeTable::new([
        style(18.0, Weight::BOLD, Color::WHITE),
        style(16.0, Weight::BOLD, c([255, 255, 255, 240])),
        style(12.0, Weight::REGULAR, c([225, 235, 250, 255])),
        style(13.0, Weight::REGULAR, c([210, 225, 250, 255])),
        style(12.0, Weight::REGULAR, c([235, 240, 255, 210])),
    ]);

    let surface = WidgetMetrics {
        radius: 10.0,
        corner: CornerShape::SQUIRCLE,
        border: 2.0,
        padding: Insets {
            left: 12.0,
            right: 12.0,
            top: 10.0,
            bottom: 10.0,
        },
        elevation: 1,
    };
    let overlay = WidgetMetrics {
        radius: 14.0,
        corner: CornerShape::SQUIRCLE,
        border: 1.0,
        padding: Insets {
            left: 14.0,
            right: 14.0,
            top: 10.0,
            bottom: 10.0,
        },
        // A floating panel sits above the surface it covers.
        // 浮起的面板高于它所遮盖的表面。
        elevation: 3,
    };
    let control = WidgetMetrics {
        radius: 6.0,
        corner: CornerShape::ROUND,
        border: 2.0,
        padding: Insets {
            left: 8.0,
            right: 8.0,
            top: 4.0,
            bottom: 4.0,
        },
        elevation: 0,
    };

    let tint = c([255, 255, 255, 90]);
    Style {
        common: None,
        roles,
        motion: MotionTable::legacy(),
        metrics: MetricsSet {
            control,
            surface,
            overlay,
        },
        controls: crate::ControlMetricsTable::EMPTY,
        type_table,
        material: Some(crate::material::Material::Frost {
            sigma: 14.0,
            tint,
            fallback: c([18, 20, 26, 255]),
        }),
        device: Capability::GPU_BASELINE,
        palette: None,
        selection: None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::motion::MotionName;
    use crate::types::TextRole;

    #[test]
    fn every_legacy_text_role_is_distinct_where_the_example_differs() {
        let p = legacy_pack();
        let title = p.type_table.get(TextRole::Title);
        let subtitle = p.type_table.get(TextRole::Subtitle);
        assert_eq!(title.size, 18.0);
        assert_ne!(title.size, subtitle.size);
    }

    #[test]
    fn the_legacy_card_is_squircle_and_the_overlay_keeps_its_own_radius() {
        let p = legacy_pack();
        assert_eq!(p.metrics.surface.radius, 10.0);
        assert_eq!(p.metrics.surface.corner, CornerShape::SQUIRCLE);
        assert_eq!(p.metrics.overlay.radius, 14.0);
    }

    #[test]
    fn the_legacy_material_carries_the_examples_sigma_and_tint() {
        let p = legacy_pack();
        match p.material {
            Some(crate::material::Material::Frost { sigma, tint, .. }) => {
                assert_eq!(sigma, 14.0);
                assert_eq!(tint, c([255, 255, 255, 90]));
            }
            other => panic!("legacy must frost, got {other:?}"),
        }
    }

    #[test]
    fn a_legacy_pack_moves_with_the_one_150ms_token() {
        let p = legacy_pack();
        assert_eq!(p.motion.get(MotionName::StateChange).spec.duration, 0.15);
    }
}
