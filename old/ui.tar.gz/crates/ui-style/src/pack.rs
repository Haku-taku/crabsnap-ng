//! One swappable style: colours, motion, shape, and the capability floor it resolves under.
//! 一套可切换的风格：颜色、动效、形状，以及它解析时依据的能力底线。

use crate::capability::Capability;
use crate::common_plane::CommonPlane;
use crate::material::Material;
use crate::motion::MotionTable;
use crate::roles::RoleDict;
use crate::control_metrics::ControlMetricsTable;
use crate::types::{MetricsSet, TypeTable, WidgetMetrics};
use crate::roles::RoleName;
use std::sync::Arc;

/// A flat all-default table; a real pack fills every role with its own numbers.
/// 全默认的平表；真实包会逐角色填入自己的数值。
pub fn stub_type_table() -> TypeTable {
    let base = crate::types::TextStyleToken {
        size: 13.0,
        weight: ui_core::Weight::REGULAR,
        line_gap: 0.0,
        indent: 0.0,
    };
    TypeTable::new([base; 5])
}

/// A trait-object palette in a `Style`, made `Debug`/`PartialEq` so the pack stays comparable.
/// `Style` 里的 trait 对象调色板；实现 `Debug`/`PartialEq` 使包保持可比较。
#[derive(Clone)]
pub struct PaletteHandle(pub Arc<dyn ui_design::Palette>);

impl core::fmt::Debug for PaletteHandle {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.write_str("<palette>")
    }
}

impl PartialEq for PaletteHandle {
    fn eq(&self, other: &Self) -> bool {
        Arc::ptr_eq(&self.0, &other.0)
    }
}

/// A widget resolves through exactly one of these per frame; an ancestor may override.
/// 控件每帧恰好经由一个这样的包解析；祖先节点可以覆写。
#[derive(Clone, Debug, PartialEq)]
pub struct Style {
    /// The cross-system plane: every common token, resolved once for this system and context.
    /// `None` for a hand-written pack that names no design system at all (`legacy_pack`).
    /// 跨体系平面：每个公共令牌，按本体系与上下文解析一次。手写包不指名体系时为 `None`。
    pub common: Option<CommonPlane>,
    pub roles: RoleDict,
    pub motion: MotionTable,
    /// Corner radius, curvature family, border and padding per depth tier. The only
    /// shape source: a second radius table would drift against this one.
    /// 每层的圆角半径、曲率家族、边框与内衬。唯一的形状来源：再一张半径表就会与这张漂移。
    pub metrics: MetricsSet,
    /// Per-control envelope: floor, padding, outline, focus reach. Tier metrics cannot hold a
    /// checkbox's 20 pt box next to a button's 11 pt inset.
    /// 每控件信封：下限、内衬、轮廓、焦点外扩。层级度量装不下勾选框 20 点方块与按钮 11 点内衬。
    pub controls: ControlMetricsTable,
    /// Named text styles, resolved from the roles at pack build time.
    /// 具名文本样式，建包时由角色解出。
    pub type_table: TypeTable,
    /// The default surface material for panels in this style; `None` means solid fill.
    /// 本风格面板的默认材质；`None` 表示实色填充。
    pub material: Option<Material>,
    /// What the backend under this app can actually do.
    /// 本 app 之下后端实际能做到什么。
    pub device: Capability,
    /// The live native vocabulary this pack was built from, so a token the curated `roles`
    /// list forgot can still resolve instead of painting transparent.
    /// 建本包所用的活的原生词汇；`roles` 手工清单遗漏的令牌仍能解析，而不是画成透明。
    pub palette: Option<PaletteHandle>,
    /// How this style draws a text selection; `None` means the engine's flat rect.
    /// 本风格如何绘制文本选区；`None` 表示用引擎的平直矩形。
    pub selection: Option<ui_core::SelectionPainterRef>,
}

impl Style {
    /// Which design system this snapshot came from, if any.
    /// 这份快照来自哪套设计体系（若有）。
    pub fn system(&self) -> Option<ui_design::SystemId> {
        self.common.as_ref().map(|p| p.system())
    }

    /// The appearance the pack was resolved for; `None` when it names no system.
    /// 本包按哪个外观解析；不指名体系时为 `None`。
    pub fn appearance(&self) -> Option<ui_design::Appearance> {
        self.common.as_ref().map(|p| p.context().appearance)
    }

    /// What the system can do beyond the common layer.
    /// 体系在公共层之外能做什么。
    pub fn caps(&self) -> ui_design::StyleCaps {
        self.common
            .as_ref()
            .map(|p| p.caps())
            .unwrap_or(ui_design::StyleCaps::MINIMAL)
    }

    /// A cross-system role. A pack that names no system has no concept of one.
    /// 跨体系角色。不指名体系的包对它没有概念。
    pub fn colour(
        &self,
        role: ui_design::CommonColor,
    ) -> ui_design::Resolution<ui_design::Resolved<ui_core::geom::Color>> {
        match &self.common {
            Some(plane) => plane.colour(role),
            None => ui_design::Resolution::Absent(ui_design::Reason::NotAConcept),
        }
    }

    /// A cross-system metric, in points.
    /// 跨体系度量，单位为点。
    pub fn metric(
        &self,
        metric: ui_design::CommonMetric,
    ) -> ui_design::Resolution<ui_design::Resolved<f32>> {
        match &self.common {
            Some(plane) => plane.metric(metric),
            None => ui_design::Resolution::Absent(ui_design::Reason::NotAConcept),
        }
    }

    /// A common colour, or `fallback` when this pack has no such concept (a hand-written pack).
    /// 公共颜色；本包没有这个概念（手写包）时用 `fallback`。
    pub fn colour_or(&self, role: ui_design::CommonColor, fallback: ui_core::geom::Color) -> ui_core::geom::Color {
        self.colour(role).value().map(|r| r.value).unwrap_or(fallback)
    }

    /// A common metric, or `fallback` when this pack has no such concept.
    /// 公共度量；本包没有这个概念时用 `fallback`。
    pub fn metric_or(&self, metric: ui_design::CommonMetric, fallback: f32) -> f32 {
        self.metric(metric).value().map(|r| r.value).unwrap_or(fallback)
    }

    /// What the pack may draw given what the backend can do.
    /// 依据后端能力，这个包允许画些什么。
    pub fn frost_allowed(&self, device: Capability) -> bool {
        device.supports_frost()
    }

    /// The brush under `id` when the system paints more than a flat colour, e.g. WinUI's
    /// elevation border; `None` means the flat colour is the whole brush.
    /// 体系在 `id` 下画的不止纯色时给出画刷，例如 WinUI 的立面描边；`None` 表示纯色即全部。
    pub fn brush(&self, id: &'static str) -> Option<ui_design::Paint> {
        self.palette.as_ref()?.0.native_brush(id)
    }

    /// A colour for `id`: curated role first, then the live native palette, else `None`.
    /// 按 `id` 取色：先查手工角色，再问活的原生调色板，都没有就返回 `None`。
    ///
    /// Returning `None` — never `TRANSPARENT` — makes a forgotten token a visible bug, not a
    /// silently blank pixel. Widgets that must draw something pick their own honest fallback.
    /// 返回 `None`——绝不返回 `TRANSPARENT`——让遗漏的令牌成为可见缺陷，而不是静默空白像素。
    pub fn ink(&self, id: &'static str) -> Option<ui_core::geom::Color> {
        if let Some(c) = self.roles.get(crate::roles::RoleName(id)) {
            return Some(c);
        }
        let argb = self.palette.as_ref()?.0.native_colour(id).value()?.argb();
        Some(ui_core::geom::Color::from_rgba8(
            (argb >> 16) as u8,
            (argb >> 8) as u8,
            argb as u8,
            (argb >> 24) as u8,
        ))
    }
}

/// The one place a `Style` is assembled, so its two planes always name the same system.
/// 组装 `Style` 的唯一去处，使它的两个平面始终指名同一个体系。
pub struct StyleBuilder {
    system: Arc<dyn ui_design::StyleSystem>,
    roles: RoleDict,
    motion: MotionTable,
    metrics: MetricsSet,
    controls: ControlMetricsTable,
    type_table: TypeTable,
    material: Option<Material>,
    device: Capability,
    selection: Option<ui_core::SelectionPainterRef>,
}

impl StyleBuilder {
    /// Start from a system; every other field has a documented default the pack overrides.
    /// 从一个体系起步；其余各项有文档化的默认值，由包按需覆写。
    pub fn new(system: Arc<dyn ui_design::StyleSystem>) -> Self {
        Self {
            system,
            roles: RoleDict::new(),
            motion: MotionTable::legacy(),
            metrics: MetricsSet::NONE,
            controls: ControlMetricsTable::EMPTY,
            type_table: stub_type_table(),
            material: None,
            device: Capability::GPU_BASELINE,
            selection: None,
        }
    }

    /// How this style draws a text selection; a pack sets its own, an app may override it.
    /// 本风格如何绘制文本选区；包各自设置，应用可以覆盖。
    pub fn selection_painter(mut self, painter: ui_core::SelectionPainterRef) -> Self {
        self.selection = Some(painter);
        self
    }

    /// A colour the pack computed itself, e.g. a component-composed wash.
    /// 包自己算出的颜色，例如组件自合成的洗色。
    pub fn role(mut self, role: &'static str, colour: ui_core::geom::Color) -> Self {
        self.roles.set(RoleName(role), colour);
        self
    }

    /// Write role `role` from the system's own token `native`. A system that does not know a
    /// token it was told to use fails the build; it never becomes a transparent pixel.
    /// 把角色 `role` 写成体系自身的令牌 `native`。体系不认识被告知要用的令牌即构建失败，
    /// 绝不变成透明像素。
    pub fn role_from(mut self, role: &'static str, native: &str) -> Self {
        let rgba = self
            .system
            .native_colour(native)
            .value()
            .unwrap_or_else(|| panic!("{} has no native token {native}", self.system.id().name()));
        self.roles.set(RoleName(role), colour_of_argb(rgba.argb()));
        self
    }

    /// The same through the common vocabulary, for a role the system only answers in translation.
    /// 同上但走公共词汇，用于体系只能以翻译作答的角色。
    pub fn role_common(mut self, role: &'static str, common: ui_design::CommonColor) -> Self {
        let rgba = self
            .system
            .common_colour(common)
            .value()
            .unwrap_or_else(|| panic!("{} has no common role {common:?}", self.system.id().name()));
        self.roles.set(RoleName(role), colour_of_argb(rgba.value.argb()));
        self
    }

    /// Derive the three depth tiers from one radius step of the system's own scale.
    /// 由体系自身刻度的一个半径档推出三个层级。
    pub fn metrics_from_scale(mut self, step: &str) -> Self {
        let scale = self.system.radius();
        let radius = scale
            .points(step)
            .unwrap_or_else(|| panic!("{} has no radius step {step}", self.system.id().name()));
        let control = WidgetMetrics {
            radius,
            corner: scale.curvature.corner_shape(),
            border: 1.0,
            padding: ui_core::geom::Insets { left: 8.0, right: 8.0, top: 4.0, bottom: 4.0 },
            elevation: 0,
        };
        // Floating panels sit above the surface; controls stay flat.
        // 浮起的面板高于表面；控件保持平放。
        let overlay = WidgetMetrics { elevation: 3, ..control };
        self.metrics = MetricsSet { control, surface: control, overlay };
        self
    }

    /// Replace the derived metrics wholesale, for a pack that shapes its depths differently.
    /// 整体替换推导出的度量，供层级形状不同的包使用。
    pub fn metrics(mut self, metrics: MetricsSet) -> Self {
        self.metrics = metrics;
        self
    }

    /// Replace the per-control envelope table, for a pack that sizes controls its own way.
    /// 整体替换每控件信封表，供按自己方式确定控件尺寸的包使用。
    pub fn controls(mut self, controls: ControlMetricsTable) -> Self {
        self.controls = controls;
        self
    }

    pub fn motion(mut self, motion: MotionTable) -> Self {
        self.motion = motion;
        self
    }

    pub fn type_table(mut self, type_table: TypeTable) -> Self {
        self.type_table = type_table;
        self
    }

    pub fn material(mut self, material: Material) -> Self {
        self.material = Some(material);
        self
    }

    pub fn device(mut self, device: Capability) -> Self {
        self.device = device;
        self
    }

    /// Hand the one `Arc` to both planes and produce the snapshot.
    /// 把同一个 `Arc` 交给两个平面，产出快照。
    pub fn build(self) -> Style {
        Style {
            common: Some(CommonPlane::resolve(self.system.clone())),
            roles: self.roles,
            motion: self.motion,
            metrics: self.metrics,
            controls: self.controls,
            type_table: self.type_table,
            material: self.material,
            device: self.device,
            palette: Some(PaletteHandle(self.system)),
            selection: self.selection,
        }
    }
}

/// One colour blended between two palettes at the same `t`, so a palette-only token fades too.
/// 两套调色板在同一 `t` 下混出的颜色；纯 palette 令牌也能一起渐变。
struct BlendedPalette {
    from: Arc<dyn ui_design::Palette>,
    to: Arc<dyn ui_design::Palette>,
    t: f32,
}

impl ui_design::Palette for BlendedPalette {
    fn native_colour(&self, id: &str) -> ui_design::Resolution<ui_design::Rgba> {
        use ui_design::Resolution;
        match (self.from.native_colour(id).value(), self.to.native_colour(id).value()) {
            (Some(a), Some(b)) => Resolution::Value(blend_rgba(a, b, self.t)),
            (Some(a), None) => Resolution::Value(a),
            (None, Some(b)) => Resolution::Value(b),
            (None, None) => self.to.native_colour(id),
        }
    }

    fn native_brush(&self, id: &str) -> Option<ui_design::Paint> {
        use ui_design::{GradientBrush, Paint};
        // Geometry snaps to the target; only the stop colours blend, as `native_colour` does.
        // 几何取目标一侧；只有停点颜色混合，与 `native_colour` 一致。
        match (self.from.native_brush(id), self.to.native_brush(id)) {
            (Some(Paint::Gradient(a)), Some(Paint::Gradient(b)))
                if a.stops.len() == b.stops.len() =>
            {
                let stops = b
                    .stops
                    .iter()
                    .zip(&a.stops)
                    .map(|((off, to), (_, from))| (*off, blend_rgba(*from, *to, self.t)))
                    .collect();
                Some(Paint::Gradient(GradientBrush {
                    stops,
                    ..b
                }))
            }
            (_, Some(brush)) => Some(brush),
            (Some(brush), None) => Some(brush),
            (None, None) => None,
        }
    }

    fn provenance(&self, id: &str) -> ui_design::Source {
        self.to.provenance(id)
    }
}

fn colour_of_argb(argb: u32) -> ui_core::geom::Color {
    ui_core::geom::Color::from_rgba8(
        (argb >> 16) as u8,
        (argb >> 8) as u8,
        argb as u8,
        (argb >> 24) as u8,
    )
}

fn rgba_of_colour(c: ui_core::geom::Color) -> ui_design::Rgba {
    let q = |v: f32| (v * 255.0).round().clamp(0.0, 255.0) as u32;
    ui_design::Rgba((q(c.a) << 24) | (q(c.r) << 16) | (q(c.g) << 8) | q(c.b))
}

fn blend_rgba(a: ui_design::Rgba, b: ui_design::Rgba, t: f32) -> ui_design::Rgba {
    let ca = colour_of_argb(a.argb());
    let cb = colour_of_argb(b.argb());
    rgba_of_colour(ca.lerp(cb, t))
}

/// Blend two packs into one at `t` (0 = `from`, 1 = `to`). Colours and lengths interpolate;
/// motion, metrics, type and material switch wholesale at the midpoint.
/// 把两个包在 `t` 下混成一个（0=`from`，1=`to`）。颜色与长度插值；动效、几何、字阶与材质在中点整体切换。
pub fn lerp_style(from: &Style, to: &Style, t: f32) -> Style {
    let t = t.clamp(0.0, 1.0);
    // The endpoints are the packets themselves, so a finished transition leaves no residue.
    // 端点就是那两个包本身，故走完的过渡不留残余。
    if t <= 0.0 {
        return from.clone();
    }
    if t >= 1.0 {
        return to.clone();
    }
    // A half-way duration or sigma is a value neither end ever meant; switch instead.
    // 半途的时长或 sigma 是两端都不曾表示的数值；改为整体切换。
    let side = if t < 0.5 { from } else { to };
    let mut roles = RoleDict::new();
    for name in from.roles.names().chain(to.roles.names()) {
        if let Some(c) = match (from.ink(name.0), to.ink(name.0)) {
            (Some(a), Some(b)) => Some(a.lerp(b, t)),
            (Some(a), None) => Some(a),
            (None, Some(b)) => Some(b),
            (None, None) => None,
        } {
            roles.set(name, c);
        }
    }
    let palette = match (&from.palette, &to.palette) {
        (Some(pf), Some(pt)) => Some(PaletteHandle(Arc::new(BlendedPalette {
            from: pf.0.clone(),
            to: pt.0.clone(),
            t,
        }))),
        (Some(p), None) | (None, Some(p)) => Some(p.clone()),
        (None, None) => None,
    };
    let common = match (&from.common, &to.common) {
        (Some(a), Some(b)) => Some(CommonPlane::lerp(a, b, t)),
        (Some(p), None) | (None, Some(p)) => Some(p.clone()),
        (None, None) => None,
    };
    Style {
        common,
        roles,
        motion: side.motion.clone(),
        metrics: side.metrics,
        controls: side.controls.clone(),
        type_table: side.type_table.clone(),
        material: side.material,
        device: to.device,
        palette,
        selection: to.selection,
    }
}

impl Style {
    /// The style for `scope`, resolved directly; the memoized entry point is `StyleCache::get`.
    /// 作用域对应的样式，直接解析；带记忆的入口是 `StyleCache::get`。
    pub fn resolve(
        scope: crate::env::StyleScope,
        resolver: fn(ui_design::Appearance) -> Style,
    ) -> Self {
        let scope = scope.settled();
        match scope.theme_from {
            Some(f) => lerp_style(&resolver(f), &resolver(scope.appearance), scope.theme_t),
            None => resolver(scope.appearance),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ui_core::geom::Color;
    use ui_design::{Rgba, StyleSystem};

    // A style must be able to travel inside a scope, whose params are `Send + Sync`.
    // 样式必须能装进作用域，而后者的参数要求 `Send + Sync`。
    #[test]
    fn a_style_can_travel_inside_a_scope() {
        fn assert_send_sync<T: Send + Sync>() {}
        assert_send_sync::<Style>();
    }

    #[test]
    fn a_pack_reports_frost_only_where_the_backend_allows_it() {
        let pack = Style {
            common: None,
            roles: RoleDict::new(),
            motion: MotionTable::legacy(),
            metrics: MetricsSet::NONE,
            controls: ControlMetricsTable::EMPTY,
            type_table: stub_type_table(),
            material: None,
            device: Capability::GPU_BASELINE,
            palette: None,
            selection: None,
        };
        assert!(pack.frost_allowed(Capability::GPU_BASELINE));
        assert!(!pack.frost_allowed(Capability::NO_BACKDROP));
    }

    #[test]
    fn two_packs_differ_by_data_and_compare_by_value() {
        // Runtime switching depends on this: identity comparison would miss a re-tinted
        // pack and skip the redraw.
        // 运行时切换依赖值比较：用身份比较会漏掉重新着色的包而不重绘。
        let base = Style {
            common: None,
            roles: RoleDict::with_pairs(&[(crate::roles::RoleName("primary"), Color::from_rgba8(1, 2, 3, 255))]),
            motion: MotionTable::legacy(),
            metrics: MetricsSet::NONE,
            controls: ControlMetricsTable::EMPTY,
            type_table: stub_type_table(),
            material: None,
            device: Capability::GPU_BASELINE,
            palette: None,
            selection: None,
        };
        let mut recoloured = base.clone();
        recoloured
            .roles
            .set(crate::roles::RoleName("primary"), Color::from_rgba8(9, 9, 9, 255));
        assert_ne!(base, recoloured);
        assert_eq!(base, base.clone());
    }

    fn pack_with(roles: &[(&'static str, Color)], palette: Option<PaletteHandle>) -> Style {
        let mut dict = RoleDict::new();
        for (n, c) in roles {
            dict.set(crate::roles::RoleName(n), *c);
        }
        Style {
            common: None,
            roles: dict,
            motion: MotionTable::legacy(),
            metrics: MetricsSet::NONE,
            controls: ControlMetricsTable::EMPTY,
            type_table: stub_type_table(),
            material: None,
            device: Capability::GPU_BASELINE,
            palette,
            selection: None,
        }
    }

    struct Fixed(Rgba);

    impl ui_design::Palette for Fixed {
        fn native_colour(&self, _id: &str) -> ui_design::Resolution<Rgba> {
            ui_design::Resolution::Value(self.0)
        }
        fn provenance(&self, _id: &str) -> ui_design::Source {
            ui_design::Source::Convention("test")
        }
    }

    #[test]
    fn lerp_style_blends_each_role_and_only_at_the_ends() {
        let a = pack_with(&[("primary", Color::from_rgba8(0, 0, 0, 255))], None);
        let b = pack_with(&[("primary", Color::from_rgba8(200, 100, 40, 255))], None);
        let mid = lerp_style(&a, &b, 0.5);
        let got = mid.ink("primary").expect("primary");
        assert!((got.r - 100.0 / 255.0).abs() < 0.01, "{got:?}");
        assert!((got.g - 50.0 / 255.0).abs() < 0.01, "{got:?}");
        assert_eq!(lerp_style(&a, &b, 0.0).ink("primary"), a.ink("primary"));
        assert_eq!(lerp_style(&a, &b, 1.0).ink("primary"), b.ink("primary"));
    }

    #[test]
    fn a_palette_only_token_blends_through_the_blended_palette() {
        // A token missing from both role dicts resolves via the palette; it must still fade.
        // 两张角色表都没有的令牌经调色板解析；它也必须过渡。
        let a = pack_with(&[], Some(PaletteHandle(std::sync::Arc::new(Fixed(Rgba(0xff00_0000))))));
        let b = pack_with(&[], Some(PaletteHandle(std::sync::Arc::new(Fixed(Rgba(0xffff_ffff))))));
        let mid = lerp_style(&a, &b, 0.5).ink("accent").expect("accent");
        assert!((mid.r - 0.5).abs() < 0.02 && (mid.g - 0.5).abs() < 0.02, "{mid:?}");
    }

    #[test]
    fn a_transition_at_its_endpoints_is_the_pack_itself() {
        // A finished transition must leave no residue — not even a blended palette handle.
        // 走完的过渡不得留下任何残余——连混合过的调色板句柄也不行。
        let a = pack_with(
            &[("primary", Color::from_rgba8(10, 20, 30, 255))],
            Some(PaletteHandle(Arc::new(Fixed(Rgba(0xff00_0000))))),
        );
        let b = pack_with(
            &[("primary", Color::from_rgba8(200, 100, 40, 255))],
            Some(PaletteHandle(Arc::new(Fixed(Rgba(0xffff_ffff))))),
        );
        assert_eq!(lerp_style(&a, &b, 0.0), a);
        assert_eq!(lerp_style(&a, &b, 1.0), b);
    }

    #[test]
    fn non_colour_tokens_switch_at_the_midpoint_while_colours_keep_moving() {
        let a = pack_with(&[("primary", Color::from_rgba8(0, 0, 0, 255))], None);
        let mut b = pack_with(&[("primary", Color::from_rgba8(200, 100, 40, 255))], None);
        b.metrics.control.radius = 7.0;
        let before = lerp_style(&a, &b, 0.49);
        let after = lerp_style(&a, &b, 0.5);
        assert_eq!(before.metrics.control.radius, a.metrics.control.radius);
        assert_eq!(after.metrics.control.radius, b.metrics.control.radius);
        let (cb, ca) = (before.ink("primary").unwrap(), after.ink("primary").unwrap());
        assert!(cb.r < ca.r && cb.r > 0.0, "{cb:?} -> {ca:?}");
    }

    // A system that answers both vocabularies, so the builder's wiring is observable.
    // 一个两套词汇都作答的体系，使构建器的接线可被观察。
    struct Both;

    impl ui_design::StyleSystem for Both {
        fn id(&self) -> ui_design::SystemId {
            ui_design::SystemId::Md3
        }
        fn context(&self) -> ui_design::Context {
            ui_design::Context::new(ui_design::Appearance::Light, ui_design::Platform::Android)
        }
        fn common_colour(
            &self,
            role: ui_design::CommonColor,
        ) -> ui_design::Resolution<ui_design::Resolved<Rgba>> {
            match role {
                ui_design::CommonColor::Accent => ui_design::Resolution::Value(
                    ui_design::Resolved::new(Rgba(0xff11_2233), ui_design::Source::Spec("test spec")),
                ),
                _ => ui_design::Resolution::Unmapped,
            }
        }
        fn common_metric(
            &self,
            _metric: ui_design::CommonMetric,
        ) -> ui_design::Resolution<ui_design::Resolved<f32>> {
            ui_design::Resolution::Unmapped
        }
        fn caps(&self) -> ui_design::StyleCaps {
            ui_design::StyleCaps::MINIMAL
        }
    }

    impl ui_design::Palette for Both {
        fn native_colour(&self, id: &str) -> ui_design::Resolution<Rgba> {
            match id {
                "primaryContainer" => ui_design::Resolution::Value(Rgba(0xff44_5566)),
                _ => ui_design::Resolution::Unmapped,
            }
        }
        fn provenance(&self, _id: &str) -> ui_design::Source {
            ui_design::Source::Convention("test")
        }
    }

    impl ui_design::WithDimensions for Both {
        fn dimensions(&self) -> ui_design::DimensionTokens {
            ui_design::dimensions_of(ui_design::SystemId::Md3, self.context())
        }
    }

    impl ui_design::Geometry for Both {}
    impl ui_design::Typography for Both {}
    impl ui_design::Motion for Both {}

    #[test]
    fn a_built_style_answers_both_vocabularies_from_its_one_system() {
        let style = StyleBuilder::new(Arc::new(Both))
            .role_from("primaryContainer", "primaryContainer")
            .metrics_from_scale("medium")
            .build();
        let common = style.colour(ui_design::CommonColor::Accent).value().expect("common");
        assert_eq!(common.value, Color::from_rgba8(0x11, 0x22, 0x33, 0xff));
        assert_eq!(
            style.roles.get(RoleName("primaryContainer")),
            Some(Color::from_rgba8(0x44, 0x55, 0x66, 0xff))
        );
        assert_eq!(style.metrics.control.radius, 12.0);
        assert_eq!(style.metrics.overlay.elevation, 3);
    }

    #[test]
    #[should_panic(expected = "MD3 has no native token nope")]
    fn a_token_the_system_does_not_know_fails_the_build() {
        let _ = StyleBuilder::new(Arc::new(Both)).role_from("x", "nope").build();
    }
}
