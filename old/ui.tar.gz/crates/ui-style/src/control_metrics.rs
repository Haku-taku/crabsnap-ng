//! Per-control geometry: one row per control kind, two densities.
//! 每控件几何：每个控件一行，两种密度。
//!
//! Only the envelope every control shares lives here. Control-specific shapes
//! (checkbox box, slider thumb, switch track) stay in the control's own spec.
//! 这里只放所有控件共享的信封。控件专属形状（勾选框、滑块拇指、开关轨道）留在各自的规格里。

use crate::types::TextRole;
use ui_core::geom::Insets;

/// The control kinds a pack may size; the index is the table row.
/// 包可为之下发尺寸的控件种类；序号就是表行号。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(usize)]
pub enum ControlKind {
    Button = 0,
    CheckBox,
    RadioButton,
    ToggleSwitch,
    Slider,
    TextBox,
    ComboBox,
    ListViewItem,
    NavigationViewItem,
    TabViewItem,
    MenuFlyoutItem,
    InfoBar,
    ContentDialog,
    ToolTip,
    ProgressBar,
    ProgressRing,
}

impl ControlKind {
    pub const COUNT: usize = 16;

    pub const ALL: [Self; Self::COUNT] = [
        Self::Button,
        Self::CheckBox,
        Self::RadioButton,
        Self::ToggleSwitch,
        Self::Slider,
        Self::TextBox,
        Self::ComboBox,
        Self::ListViewItem,
        Self::NavigationViewItem,
        Self::TabViewItem,
        Self::MenuFlyoutItem,
        Self::InfoBar,
        Self::ContentDialog,
        Self::ToolTip,
        Self::ProgressBar,
        Self::ProgressRing,
    ];
}

/// Touch density. WinUI 3 ships no density dictionary; a pack that has one fills `Compact`.
/// 触控密度。WinUI 3 没有密度字典；有该概念的包才填 `Compact`。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Density {
    Standard,
    Compact,
}

/// The size envelope of one control: floor, insets, outline, focus reach, glyph, type.
/// 一个控件的尺寸信封：下限、内衬、轮廓、焦点外扩、图标、字号。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ControlMetrics {
    pub min_width: f32,
    pub min_height: f32,
    pub padding: Insets,
    /// Uniform border width; per-side thicknesses live in the control's spec.
    /// 四边等宽的描边；逐边不同的厚度留在控件规格里。
    pub border: f32,
    pub radius: f32,
    /// How far the focus adorner reaches outside the box, as XAML `FocusVisualMargin`.
    /// 焦点装饰伸出盒外的距离，对应 XAML 的 `FocusVisualMargin`。
    pub focus_margin: Insets,
    /// Glyph box side; `0` when the control carries no glyph of its own.
    /// 图标框边长；控件本身不带图标时为 `0`。
    pub icon_size: f32,
    pub font: TextRole,
}

impl ControlMetrics {
    /// No floor, no inset, no outline: the row of a control nobody has sized yet.
    /// 无下限、无内衬、无轮廓：尚未定尺寸的控件的行。
    pub const EMPTY: Self = Self {
        min_width: 0.0,
        min_height: 0.0,
        padding: Insets::ZERO,
        border: 0.0,
        radius: 0.0,
        focus_margin: Insets::ZERO,
        icon_size: 0.0,
        font: TextRole::Body,
    };
}

/// Standard and compact rows for every `ControlKind`, indexed by the kind's discriminant.
/// 每个 `ControlKind` 的标准与紧凑行，按种类的判别式索引。
#[derive(Clone, Debug, PartialEq)]
pub struct ControlMetricsTable {
    standard: [ControlMetrics; ControlKind::COUNT],
    compact: [ControlMetrics; ControlKind::COUNT],
}

impl ControlMetricsTable {
    pub const EMPTY: Self = Self {
        standard: [ControlMetrics::EMPTY; ControlKind::COUNT],
        compact: [ControlMetrics::EMPTY; ControlKind::COUNT],
    };

    /// A pack with one density: compact reads the same rows.
    /// 只有一种密度的包：紧凑密度读同一组行。
    pub const fn from_standard(standard: [ControlMetrics; ControlKind::COUNT]) -> Self {
        Self {
            standard,
            compact: standard,
        }
    }

    pub fn get(&self, kind: ControlKind, density: Density) -> &ControlMetrics {
        match density {
            Density::Standard => &self.standard[kind as usize],
            Density::Compact => &self.compact[kind as usize],
        }
    }

    /// Fill one compact row, leaving every other kind on its standard row.
    /// 填入一行紧凑值，其余种类仍用标准行。
    pub fn set_compact(&mut self, kind: ControlKind, metrics: ControlMetrics) {
        self.compact[kind as usize] = metrics;
    }
}

impl Default for ControlMetricsTable {
    fn default() -> Self {
        Self::EMPTY
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_compact_row_that_was_never_filled_reads_the_standard_row() {
        let button = ControlMetrics {
            min_height: 32.0,
            ..ControlMetrics::EMPTY
        };
        let mut standard = [ControlMetrics::EMPTY; ControlKind::COUNT];
        standard[ControlKind::Button as usize] = button;
        let rows = ControlMetricsTable::from_standard(standard);

        assert_eq!(rows.get(ControlKind::Button, Density::Compact), &button);
        assert_eq!(
            rows.get(ControlKind::CheckBox, Density::Standard),
            &ControlMetrics::EMPTY
        );
    }
}
