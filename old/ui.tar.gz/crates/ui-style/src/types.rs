//! Text and metric tokens: what size a title is, what padding a card carries.
//! 文本与度量令牌：标题该多大、卡片该有多少内衬。

use ui_core::geom::{CornerShape, Insets};
use ui_core::Weight;

/// The named text styles widgets may ask for. Fluent ships eight of these
/// (`typography.dart:42-78`); five covers what the built-in widgets need today.
/// 控件可请求的具名文本样式。Fluent 有八档（`typography.dart:42-78`）；五档够当前内置控件用。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum TextRole {
    /// Largest heading a surface carries.
    /// 平面上最大的标题。
    Title,
    /// Secondary heading, still bold.
    /// 次级标题，仍带粗体。
    Subtitle,
    /// Running text, possibly wrapped.
    /// 成段文本，可能换行。
    Body,
    /// Compact text inside a control.
    /// 控件内的紧凑文本。
    Caption,
    /// Smallest supporting text.
    /// 最小的辅助文本。
    Hint,
}

/// One resolved text style: metrics only. Ink is the widget's role choice, not a ramp field.
/// 一条解出的文本样式：只有度量。墨色是控件对角色的选择，不是字阶字段。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TextStyleToken {
    pub size: f32,
    pub weight: Weight,
    /// Extra leading between lines; MD3 carries it per style, not per widget.
    /// 行间距；MD3 按样式携带，不按控件。
    pub line_gap: f32,
    /// First-line indent, CSS `text-indent` in logical units.
    /// 首行缩进，逻辑单位，相当于 CSS `text-indent`。
    pub indent: f32,
}

/// The five styles for one brightness of one pack.
/// 某个包在某亮度下的五档样式。
#[derive(Clone, Debug, PartialEq)]
pub struct TypeTable {
    entries: [TextStyleToken; 5],
}

impl TypeTable {
    pub fn new(entries: [TextStyleToken; 5]) -> Self {
        Self { entries }
    }

    pub fn get(&self, role: TextRole) -> &TextStyleToken {
        &self.entries[role as usize]
    }
}

/// The envelope one depth level draws with: radius, corner curve, border, padding.
/// 一个层级绘制所用的外框：圆角、曲线、边框、内衬。
///
/// Grouped so a widget cannot take a radius from one tier and padding from another.
/// 成组是为了让控件无法从一层取圆角、另一层取内衬。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct WidgetMetrics {
    pub radius: f32,
    pub corner: CornerShape,
    pub border: f32,
    pub padding: Insets,
    /// Elevation level, `0` = flat. Overlays sit above controls.
    /// 立面层级，`0` 为平放。浮出层高于控件。
    pub elevation: u8,
}

impl WidgetMetrics {
    pub fn flat(radius: f32, corner: CornerShape) -> Self {
        Self {
            radius,
            corner,
            border: 0.0,
            padding: Insets::ZERO,
            elevation: 0,
        }
    }
}

/// Control / surface / overlay: the three depths a pack styles.
/// 控件 / 平面 / 浮层：一个包要着色的三个层级。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct MetricsSet {
    pub control: WidgetMetrics,
    pub surface: WidgetMetrics,
    pub overlay: WidgetMetrics,
}

impl MetricsSet {
    /// Square corners with no borders; a starting point for real packs.
    /// 直角无边框，供真实风格包起步用。
    pub const NONE: Self = Self {
        control: WidgetMetrics {
            radius: 0.0,
            corner: CornerShape::ROUND,
            border: 0.0,
            padding: Insets::ZERO,
            elevation: 0,
        },
        surface: WidgetMetrics {
            radius: 0.0,
            corner: CornerShape::ROUND,
            border: 0.0,
            padding: Insets::ZERO,
            elevation: 0,
        },
        overlay: WidgetMetrics {
            radius: 0.0,
            corner: CornerShape::ROUND,
            border: 0.0,
            padding: Insets::ZERO,
            elevation: 0,
        },
    };
}

impl Default for MetricsSet {
    fn default() -> Self {
        Self::NONE
    }
}
