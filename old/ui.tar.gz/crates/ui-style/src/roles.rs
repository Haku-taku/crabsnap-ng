//! Named colour roles held by name, not by struct field, so a style pack can add or
//! deprecate slots without touching every widget's code.
//! 颜色角色按键存储而非结构体字段，风格包增删槽位不必改动每个控件。

use ui_core::collections::FastMap;

use ui_core::geom::Color;

/// A role slot, interned by its own `&'static str`.
/// 角色槽，以自身的 `&'static str` 驻留。
#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub struct RoleName(pub &'static str);

impl RoleName {
    pub fn as_str(self) -> &'static str {
        self.0
    }
}

/// One theme's colour set: values plus the alias chain that migrates old names.
/// 一套主题的颜色集合：值，加上让旧名字迁移的别名链。
#[derive(Clone, Debug, PartialEq)]
#[derive(Default)]
pub struct RoleDict {
    values: FastMap<RoleName, Color>,
    // Aliases resolve at lookup, not at construction: a pack may define a role only
    // through a legacy name.
    // 别名在查询时解析而非构造时：风格包可能只用旧名字定义某角色。
    aliases: FastMap<RoleName, RoleName>,
}

impl RoleDict {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn with_pairs(pairs: &[(RoleName, Color)]) -> Self {
        let mut dict = Self::new();
        for (name, color) in pairs {
            dict.set(*name, *color);
        }
        dict
    }

    pub fn set(&mut self, role: RoleName, color: Color) -> &mut Self {
        self.values.insert(role, color);
        self
    }

    /// Point an old role name at a live one, the way MD3 redirects deprecated getters.
    /// 把旧角色名指向存活的角色，如同 MD3 对弃用 getter 的重定向。
    pub fn alias(&mut self, from: RoleName, to: RoleName) -> &mut Self {
        self.aliases.insert(from, to);
        self
    }

    /// Resolve a role, following at most a short alias chain; cycles yield `None`.
    /// 解析角色，最多沿一小段别名链；出现环则返回 `None`。
    pub fn get(&self, role: RoleName) -> Option<Color> {
        let mut current = role;
        for _ in 0..8 {
            if let Some(color) = self.values.get(&current) {
                return Some(*color);
            }
            current = *self.aliases.get(&current)?;
        }
        None
    }

    /// Overlay `other` on top of `self`: the higher layer wins per key.
    /// 用 `other` 覆盖 `self`：逐键以上层为准。
    pub fn merged_with(&self, other: &Self) -> Self {
        let mut out = self.clone();
        for (role, color) in &other.values {
            out.values.insert(*role, *color);
        }
        for (from, to) in &other.aliases {
            out.aliases.insert(*from, *to);
        }
        out
    }

    pub fn len(&self) -> usize {
        self.values.len()
    }

    /// Whether the pack declares no role at all; every lookup on it misses.
    /// 包里没有声明任何角色；对它的每次查找都落空。
    pub fn is_empty(&self) -> bool {
        self.values.is_empty()
    }

    /// Every concrete role name (alias keys excluded); used to blend two packs.
    /// 所有具体角色名（不含别名键）；用于混合两个包。
    pub fn names(&self) -> impl Iterator<Item = RoleName> + '_ {
        self.values.keys().copied()
    }
}


#[cfg(test)]
mod tests {
    use super::*;

    fn role(name: &'static str) -> RoleName {
        RoleName(name)
    }

    fn gray(v: u8) -> Color {
        Color::from_rgba8(v, v, v, 255)
    }

    #[test]
    fn a_deprecated_name_resolves_to_the_role_it_redirects_to() {
        let mut dict = RoleDict::new();
        dict.set(role("surface"), gray(240));
        dict.alias(role("surfaceVariant"), role("surface"));
        assert_eq!(dict.get(role("surfaceVariant")), Some(gray(240)));
    }

    #[test]
    fn a_defined_legacy_name_wins_over_its_alias() {
        // MD3 keeps the redirect only for callers that never moved; a pack that still
        // defines the old key means it deliberately, so the value must be its own.
        // MD3 的重定向只服务于没迁移的调用方；风格包若仍定义旧键就是故意的，值应归它自己。
        let mut dict = RoleDict::new();
        dict.set(role("background"), gray(250));
        dict.set(role("surface"), gray(240));
        dict.alias(role("background"), role("surface"));
        assert_eq!(dict.get(role("background")), Some(gray(250)));
    }

    #[test]
    fn an_alias_cycle_resolves_to_nothing_instead_of_hanging() {
        let mut dict = RoleDict::new();
        dict.alias(role("a"), role("b"));
        dict.alias(role("b"), role("a"));
        assert_eq!(dict.get(role("a")), None);
    }

    #[test]
    fn merging_overlays_only_the_keys_the_upper_layer_names() {
        let base = RoleDict::with_pairs(&[(role("primary"), gray(10)), (role("surface"), gray(20))]);
        let over = RoleDict::with_pairs(&[(role("primary"), gray(99))]);
        let merged = base.merged_with(&over);
        assert_eq!(merged.get(role("primary")), Some(gray(99)));
        assert_eq!(merged.get(role("surface")), Some(gray(20)));
        assert_eq!(merged.len(), 2, "overlaying an existing key must not add one");
    }
}
