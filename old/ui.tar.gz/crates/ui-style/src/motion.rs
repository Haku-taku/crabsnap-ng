//! Motion tokens: named durations and curves that widgets reference instead of literals.
//! 动效令牌：具名的时长与曲线，控件引用它而不是写死字面量。

use ui_core::anim::{AnimSpec, Easing, PieceCubic};

/// A slot every widget resolves its animation through.
/// 每个控件都经由这些槽解析自己的动画。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum MotionName {
    /// State swaps: hover, focus, press.
    /// 状态切换：悬停、焦点、按下。
    StateChange,
    /// Small popups opening.
    /// 小弹窗展开。
    Quick,
    /// Standard transitions: expand, page swap.
    /// 标准过渡：展开、换页。
    Standard,
    /// Large or prominent motion.
    /// 更大更显眼的运动。
    Slow,
    /// A colour or brush swap. WinUI's `BrushTransition` is linear where its transform
    /// transitions use the fast-out-slow-in spline, so the two cannot share a slot.
    /// 颜色/画刷切换。WinUI 的 `BrushTransition` 是线性，而变换过渡用 fast-out-slow-in 曲线，
    /// 两者不能共用一槽。
    ColourChange,
}

/// One entry: duration in seconds, a curve, and an optional reverse override.
/// 一条令牌：秒为的时长、曲线，以及可选的反向覆写。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct MotionToken {
    pub spec: AnimSpec,
    /// A different travel back; MD3/Fluent both reverse curves for closing.
    /// 回程走不同曲线；MD3/Fluent 都会在关闭时反放。
    pub reverse: Option<AnimSpec>,
}

impl MotionToken {
    pub fn new(duration: f32, easing: Easing) -> Self {
        Self {
            spec: AnimSpec::new(duration, easing),
            reverse: None,
        }
    }

    /// The spec to use leaving this state; falls back to the forward curve.
    /// 离开该状态时应采用的规格；缺省回退到正向曲线。
    pub fn reverse_spec(&self) -> AnimSpec {
        self.reverse.unwrap_or_else(|| self.spec.mirrored())
    }
}

/// A whole style's motion vocabulary; swap the table, the widgets change feel.
/// 一种风格的完整动效词汇；换表即换控件的观感。
#[derive(Clone, Debug, PartialEq)]
pub struct MotionTable {
    state_change: MotionToken,
    quick: MotionToken,
    standard: MotionToken,
    slow: MotionToken,
    colour_change: MotionToken,
}

impl MotionTable {
    pub fn get(&self, name: MotionName) -> &MotionToken {
        match name {
            MotionName::StateChange => &self.state_change,
            MotionName::Quick => &self.quick,
            MotionName::Standard => &self.standard,
            MotionName::Slow => &self.slow,
            MotionName::ColourChange => &self.colour_change,
        }
    }

    /// The legacy feel currently painted in the examples: 150 ms ease-out everywhere.
    /// 示例里当前画出的旧观感：处处 150 毫秒 ease-out。
    pub fn legacy() -> Self {
        let quick = MotionToken::new(0.15, Easing::EaseOut);
        Self {
            state_change: quick,
            quick,
            standard: quick,
            slow: quick,
            colour_change: quick,
        }
    }

    /// The WinUI durations 83/167/250 ms plus Flutter's 358 ms slow, on `EaseInOut`.
    /// 83/167/250 取自 WinUI XAML，358 的 slow 来自 Flutter `fluent_ui`；曲线 `EaseInOut`
    /// 也不是 WinUI 的 `standardCurve`（`0,0,0,1`）。两处替换待用户定。
    pub fn fluent() -> Self {
        let curve = Easing::EaseInOut;
        Self {
            state_change: MotionToken::new(0.083, curve),
            quick: MotionToken::new(0.167, curve),
            standard: MotionToken::new(0.250, curve),
            slow: MotionToken::new(0.358, curve),
            colour_change: MotionToken::new(0.083, curve),
        }
    }

    /// WinUI 3's own durations and spline, from `Common_themeresources_any.xaml`.
    /// WinUI 3 自己的时长与曲线，取自 `Common_themeresources_any.xaml`。
    ///
    /// `ControlFastOutSlowInKeySpline` is `0,0,0,1`; brush transitions are linear at 83 ms.
    /// `ControlFastOutSlowInKeySpline` 为 `0,0,0,1`；画刷过渡是 83 毫秒线性。
    pub fn winui() -> Self {
        let spline = Easing::Cubic(0.0, 0.0, 0.0, 1.0);
        Self {
            state_change: MotionToken::new(0.083, spline),
            quick: MotionToken::new(0.167, spline),
            standard: MotionToken::new(0.250, spline),
            // WinUI's longest control animation is the normal 250 ms one; no 358 ms slot.
            // WinUI 控件动效最长即 normal 的 250 毫秒，没有 358 毫秒一档。
            slow: MotionToken::new(0.250, spline),
            colour_change: MotionToken::new(0.083, Easing::Linear),
        }
    }

    /// MD3 buckets: 100 ms state layers, 200 ms/300 ms/400 ms standard/emphasized ramps.
    /// MD3 分档：状态层 100 毫秒，standard/emphasized 为 200/300/400 毫秒。
    pub fn material() -> Self {
        let standard = Easing::Cubic(0.2, 0.0, 0.0, 1.0);
        Self {
            state_change: MotionToken::new(0.100, standard),
            quick: MotionToken::new(0.200, standard),
            standard: MotionToken::new(0.300, Easing::Piece(&EMPHASIZED_DECELERATE)),
            slow: MotionToken::new(0.400, Easing::Piece(&EMPHASIZED_DECELERATE)),
            // MD3 state layers fade linearly; `kRadialReactionDuration` is the 100 ms clock.
            // MD3 状态层线性淡入；时钟是 100 毫秒的 `kRadialReactionDuration`。
            colour_change: MotionToken::new(0.100, Easing::Linear),
        }
    }

    /// All four slots share one token; a pack uses this then dials individual slots.
    /// 四槽共用同一令牌；风格包以此起步再逐槽微调。
    pub fn uniform(token: MotionToken) -> Self {
        Self {
            state_change: token,
            quick: token,
            standard: token,
            slow: token,
            colour_change: token,
        }
    }
}

/// Material's emphasized decelerate; piecewise because one cubic cannot express it.
/// MD3 的 emphasized decelerate；单条 cubic 表达不了所以必须分段。
pub static EMPHASIZED_DECELERATE: PieceCubic = PieceCubic {
    a1: (0.05, 0.0),
    b1: (0.133_333, 0.06),
    mid: (0.166_666, 0.4),
    a2: (0.208_333, 0.82),
    b2: (0.25, 1.0),
};

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_fluent_table_carries_its_measured_durations() {
        let t = MotionTable::fluent();
        assert_eq!(t.get(MotionName::StateChange).spec.duration, 0.083);
        assert_eq!(t.get(MotionName::Quick).spec.duration, 0.167);
        assert_eq!(t.get(MotionName::Standard).spec.duration, 0.250);
        assert_eq!(t.get(MotionName::Slow).spec.duration, 0.358);
    }

    #[test]
    fn the_winui_table_uses_the_xaml_spline_and_a_linear_brush_clock() {
        // `ControlFastOutSlowInKeySpline` is 0,0,0,1; `BrushTransition` is 83 ms linear.
        // `ControlFastOutSlowInKeySpline` 是 0,0,0,1；`BrushTransition` 是 83 毫秒线性。
        let t = MotionTable::winui();
        let spline = Easing::Cubic(0.0, 0.0, 0.0, 1.0);
        assert_eq!(t.get(MotionName::StateChange).spec.duration, 0.083);
        assert_eq!(t.get(MotionName::StateChange).spec.easing, spline);
        assert_eq!(t.get(MotionName::Quick).spec.duration, 0.167);
        assert_eq!(t.get(MotionName::Standard).spec.duration, 0.250);
        assert_eq!(t.get(MotionName::ColourChange).spec.easing, Easing::Linear);
        assert_eq!(t.get(MotionName::ColourChange).spec.duration, 0.083);
    }

    #[test]
    fn reversing_a_fluent_token_mirrors_its_curve() {
        // No explicit reverse: going back must start where the forward motion ended.
        // 未显式给反向：回程必须从正向的终点起步。
        let t = MotionToken::new(0.2, Easing::EaseOut);
        assert_eq!(t.reverse_spec().easing, Easing::EaseIn);
    }

    #[test]
    fn an_explicit_reverse_beats_the_mirrored_fallback() {
        let mut t = MotionToken::new(0.2, Easing::EaseOut);
        t.reverse = Some(AnimSpec::new(0.075, Easing::Linear));
        assert_eq!(t.reverse_spec().duration, 0.075);
    }

    #[test]
    fn the_piecewise_curve_anchors_at_both_ends_and_rises() {
        let p = &EMPHASIZED_DECELERATE;
        assert_eq!(Easing::Piece(p).apply(0.0), 0.0);
        assert_eq!(Easing::Piece(p).apply(1.0), 1.0);
        // Emphasized decelerate rushes ahead of linear early, then crawls to the end.
        // emphasized decelerate 前段远超线性，尾段贴着终点缓行。
        let early = Easing::Piece(p).apply(0.25);
        assert!(
            early > 0.7,
            "expected the front-loaded shape, got {early}"
        );
        assert!(Easing::Piece(p).apply(0.75) > Easing::Piece(p).apply(0.5));
    }

    #[test]
    fn a_cubic_matches_its_css_preset_at_the_midpoint() {
        // cubic-bezier(0.4, 0, 0.2, 1) (MD3 standard family) is ahead of linear at t=0.5.
        // MD3 standard 家族在 t=0.5 领先线性。
        let v = Easing::Cubic(0.4, 0.0, 0.2, 1.0).apply(0.5);
        assert!(v > 0.5 && v < 1.0, "got {v}");
    }

    #[test]
    fn legacy_table_collapses_all_slots_to_one_token() {
        let t = MotionTable::legacy();
        assert_eq!(t.get(MotionName::Slow), t.get(MotionName::StateChange));
    }
}
