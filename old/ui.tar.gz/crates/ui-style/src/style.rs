//! The semantic specs a style is asked to turn into concrete controls.
//! 向风格索取具体控件时使用的语义规格。

use ui_core::Id;

/// One slider request: a value and a label, never geometry.
/// 一次滑块请求：值与标签，不含几何。
#[derive(Clone, Copy, Debug)]
pub struct SliderSpec<'a> {
    pub id: Id,
    /// Normalised 0..=1 value; the app owns the range and maps it.
    /// 归一化 0..=1 的值；取值范围由应用拥有并映射。
    pub value: f32,
    pub label: &'a str,
}

/// One toggle request: the semantic bit and a label, never geometry.
/// 一次开关请求：语义位与标签，不含几何。
#[derive(Clone, Copy, Debug)]
pub struct ToggleSpec<'a> {
    pub id: Id,
    pub on: bool,
    pub label: &'a str,
}

impl<'a> SliderSpec<'a> {
    pub fn new(id: Id, value: f32, label: &'a str) -> Self {
        Self { id, value, label }
    }
}

impl<'a> ToggleSpec<'a> {
    pub fn new(id: Id, on: bool, label: &'a str) -> Self {
        Self { id, on, label }
    }
}
