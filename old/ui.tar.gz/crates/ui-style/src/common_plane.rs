//! The cross-system plane: every common token resolved once, each carrying its source.
//! 跨体系平面：每个公共令牌解析一次，各带来源。

use std::sync::Arc;

use ui_core::geom::Color;
use ui_design::{
    CommonColor, CommonMetric, Context, Resolution, Resolved, Rgba, StyleCaps, StyleSystem,
    SystemId,
};

/// A snapshot of one system's answers to the closed common lists. Refusals stay refusals:
/// a role the system cannot fill is `Absent`/`Unmapped`, never a made-up colour.
/// 某体系对封闭公共清单的一份答案。拒绝仍是拒绝：填不上的角色就是 `Absent`/`Unmapped`，
/// 绝不臆造颜色。
#[derive(Clone)]
pub struct CommonPlane {
    system: SystemId,
    context: Context,
    source: Arc<dyn StyleSystem>,
    colours: [Resolution<Resolved<Color>>; CommonColor::COUNT],
    metrics: [Resolution<Resolved<f32>>; CommonMetric::COUNT],
    caps: StyleCaps,
}

impl CommonPlane {
    /// Resolve every common token once. Cheap enough to do per scope, not per widget.
    /// 一次解析全部公共令牌。代价小到可按作用域做，而不必按控件做。
    pub fn resolve(source: Arc<dyn StyleSystem>) -> Self {
        let mut colours = [Resolution::Unmapped; CommonColor::COUNT];
        for (slot, role) in colours.iter_mut().zip(CommonColor::ALL) {
            *slot = source.common_colour(role).map(to_color);
        }
        let mut metrics = [Resolution::Unmapped; CommonMetric::COUNT];
        for (slot, metric) in metrics.iter_mut().zip(CommonMetric::ALL) {
            *slot = source.common_metric(metric);
        }
        Self {
            system: source.id(),
            context: source.context(),
            caps: source.caps(),
            source,
            colours,
            metrics,
        }
    }

    pub fn system(&self) -> SystemId {
        self.system
    }

    pub fn context(&self) -> Context {
        self.context
    }

    pub fn caps(&self) -> StyleCaps {
        self.caps
    }

    /// The system itself, which is also the entry to its own vocabulary.
    /// 体系本身，同时也是其自有词汇的入口。
    pub fn source(&self) -> &Arc<dyn StyleSystem> {
        &self.source
    }

    pub fn colour(&self, role: CommonColor) -> Resolution<Resolved<Color>> {
        self.colours[role_index(role)]
    }

    pub fn metric(&self, metric: CommonMetric) -> Resolution<Resolved<f32>> {
        self.metrics[metric_index(metric)]
    }

    /// Blend two planes for a theme transition. The endpoints return the endpoint snapshots
    /// unchanged, so `t = 0`/`1` is exactly the from/to style.
    /// 为主题过渡混合两个平面。端点原样返回端点快照，故 `t = 0`/`1` 就是 from/to 本身。
    pub fn lerp(from: &Self, to: &Self, t: f32) -> Self {
        let t = t.clamp(0.0, 1.0);
        if t <= 0.0 {
            return from.clone();
        }
        if t >= 1.0 {
            return to.clone();
        }
        Self {
            system: to.system,
            context: to.context,
            caps: to.caps,
            source: to.source.clone(),
            colours: std::array::from_fn(|i| blend_colour(from.colours[i], to.colours[i], t)),
            metrics: std::array::from_fn(|i| blend_metric(from.metrics[i], to.metrics[i], t)),
        }
    }
}

// The Arc is how the values were obtained, not part of them: two snapshots resolved separately
// from the same system and context are equal.
// Arc 只是取得值的方式，不属于值本身：同一体系与上下文下分别解析的两份快照相等。
impl PartialEq for CommonPlane {
    fn eq(&self, other: &Self) -> bool {
        self.system == other.system
            && self.context == other.context
            && self.colours == other.colours
            && self.metrics == other.metrics
            && self.caps == other.caps
    }
}

impl core::fmt::Debug for CommonPlane {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        f.debug_struct("CommonPlane")
            .field("system", &self.system)
            .field("context", &self.context)
            .finish_non_exhaustive()
    }
}

fn role_index(role: CommonColor) -> usize {
    CommonColor::ALL
        .iter()
        .position(|r| *r == role)
        .expect("CommonColor::ALL lists every role")
}

fn metric_index(metric: CommonMetric) -> usize {
    CommonMetric::ALL
        .iter()
        .position(|m| *m == metric)
        .expect("CommonMetric::ALL lists every metric")
}

fn to_color(r: Resolved<Rgba>) -> Resolved<Color> {
    let argb = r.value.argb();
    Resolved::new(
        Color::from_rgba8(
            (argb >> 16) as u8,
            (argb >> 8) as u8,
            argb as u8,
            (argb >> 24) as u8,
        ),
        r.source,
    )
}

/// A blend is nobody's published value, so it says so.
/// 混合值不是任何一方公布的值，因此它如实标注。
const BLEND_SOURCE: ui_design::Source = ui_design::Source::Derived("theme transition blend");

fn blend_colour(
    a: Resolution<Resolved<Color>>,
    b: Resolution<Resolved<Color>>,
    t: f32,
) -> Resolution<Resolved<Color>> {
    match (a.value(), b.value()) {
        (Some(x), Some(y)) => Resolution::Value(Resolved::new(x.value.lerp(y.value, t), BLEND_SOURCE)),
        (Some(x), None) => Resolution::Value(x),
        (None, Some(y)) => Resolution::Value(y),
        (None, None) => b,
    }
}

fn blend_metric(
    a: Resolution<Resolved<f32>>,
    b: Resolution<Resolved<f32>>,
    t: f32,
) -> Resolution<Resolved<f32>> {
    match (a.value(), b.value()) {
        (Some(x), Some(y)) => Resolution::Value(Resolved::new(
            x.value + (y.value - x.value) * t,
            BLEND_SOURCE,
        )),
        (Some(x), None) => Resolution::Value(x),
        (None, Some(y)) => Resolution::Value(y),
        (None, None) => b,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ui_design::{Appearance, HigSystem, Md3Scheme, Platform, Reason};

    fn md3(appearance: Appearance) -> Arc<dyn StyleSystem> {
        Arc::new(Md3Scheme::baseline(Context::new(appearance, Platform::Android)))
    }

    fn hig(appearance: Appearance) -> Arc<dyn StyleSystem> {
        Arc::new(HigSystem::new(Context::new(appearance, Platform::Ios)))
    }

    // The snapshot must copy the system's answer verbatim, source included; re-deriving it
    // here would let the two drift.
    // 快照必须原样复制体系的答案（含来源）；在此重新推导会让两者漂移。
    #[test]
    fn the_snapshot_returns_the_systems_own_answer_and_source() {
        let system = md3(Appearance::Light);
        let plane = CommonPlane::resolve(system.clone());
        for role in CommonColor::ALL {
            let answer = system.common_colour(role).value().unwrap_or_else(|| panic!("{role:?}"));
            let snapshot = plane.colour(role).value().unwrap_or_else(|| panic!("{role:?}"));
            assert_eq!(snapshot.value, to_color(answer).value, "{role:?}");
            assert_eq!(snapshot.source, answer.source, "{role:?}");
        }
    }

    // HIG resolves a scrim at the compositor, not as a colour; a snapshot must not invent one.
    // HIG 的 scrim 由合成器解析而非某个颜色；快照不得臆造一个。
    #[test]
    fn a_refusal_survives_the_snapshot() {
        let plane = CommonPlane::resolve(hig(Appearance::Light));
        assert_eq!(
            plane.colour(CommonColor::Scrim),
            Resolution::Absent(Reason::PlatformResolved("sheet backdrop"))
        );
    }

    // A transition that starts must show exactly the from-style, not a 0% blend of the two.
    // 刚开始的过渡必须就是 from 本身，而不是两者的 0% 混合。
    #[test]
    fn a_transition_at_its_endpoints_equals_the_endpoint_snapshots() {
        let from = CommonPlane::resolve(md3(Appearance::Light));
        let to = CommonPlane::resolve(md3(Appearance::Dark));
        assert_eq!(CommonPlane::lerp(&from, &to, 0.0), from);
        assert_eq!(CommonPlane::lerp(&from, &to, 1.0), to);
    }

    // Redraw decisions compare styles by value; comparing the `Arc` would miss a re-resolved
    // snapshot and skip the repaint.
    // 重绘判定按值比较样式；比较 `Arc` 会漏掉重新解析过的快照而不重绘。
    #[test]
    fn two_separately_resolved_snapshots_of_one_system_are_equal() {
        assert_eq!(
            CommonPlane::resolve(md3(Appearance::Light)),
            CommonPlane::resolve(md3(Appearance::Light))
        );
        assert_ne!(
            CommonPlane::resolve(md3(Appearance::Light)),
            CommonPlane::resolve(md3(Appearance::Dark))
        );
    }
}
