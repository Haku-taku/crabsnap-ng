//! Opaque, chainable style-parameter scopes; the semantic layer never interprets them.
//! 不透明、可链式嵌套的风格参数作用域；语义层从不解释它们。

use std::any::Any;
use std::sync::Arc;

/// One layer of the scope chain: its parameters, its context, and the enclosing scope.
/// 作用域链的一层：它的参数、上下文，以及外层作用域。
pub struct Env {
    parent: Option<Arc<Env>>,
    /// Present only on layers that state a context; `None` inherits from the parent.
    /// 只有明说上下文的层才有值；`None` 表示继承父层。
    scope: Option<StyleScope>,
    params: Arc<dyn Any + Send + Sync>,
}

impl Env {
    /// Push a layer; `None` starts a chain, which is what a top-level call passes.
    /// 压入一层；`None` 表示链首，顶层调用传它。
    pub fn with<P: 'static + Send + Sync>(parent: Option<Arc<Env>>, params: P) -> Arc<Env> {
        Self::layered(parent, None, params)
    }

    /// The same layer, also stating the context its tokens resolve in.
    /// 同一层，同时指明其令牌解析所依据的上下文。
    pub fn with_scope<P: 'static + Send + Sync>(
        parent: Option<Arc<Env>>,
        scope: StyleScope,
        params: P,
    ) -> Arc<Env> {
        Self::layered(parent, Some(scope), params)
    }

    fn layered<P: 'static + Send + Sync>(
        parent: Option<Arc<Env>>,
        scope: Option<StyleScope>,
        params: P,
    ) -> Arc<Env> {
        Arc::new(Env { parent, scope, params: Arc::new(params) })
    }

    /// Re-layer an existing scope's parameters onto a new parent, keeping the chain intact.
    /// 把既有作用域的参数挂到新的父层上，保持链条完整。
    ///
    /// A `Scoped` container needs this: the scope it opens is defined by its own value, but
    /// it must still see whatever its ancestors said.
    /// `Scoped` 容器需要它：它开启的作用域由自身的值定义，但仍必须看得见祖先说过的话。
    pub fn relayer(&self, parent: Option<Arc<Env>>) -> Arc<Env> {
        Arc::new(Env {
            parent,
            scope: self.scope,
            params: self.params.clone(),
        })
    }

    /// Read a scope back out of the opaque handle the declaration tree stores.
    /// 从不透明句柄中读回作用域，声明树存的就是它。
    ///
    /// `ui-core` only knows `Arc<dyn Any>`; this is the one place that knows better.
    /// `ui-core` 只认识 `Arc<dyn Any>`；知道它其实是什么的地方只有这里。
    pub fn from_opaque(v: &Arc<dyn Any + Send + Sync>) -> Option<&Arc<Env>> {
        v.downcast_ref::<Arc<Env>>()
    }

    /// Whether two handles are the same layer, by identity rather than by value.
    /// 两个句柄是不是同一层，按同一性而非值判断。
    pub fn same(a: &Arc<Env>, b: &Arc<Env>) -> bool {
        Arc::ptr_eq(a, b)
    }

    /// The root a top-level call may pass; it carries no parameters at all.
    /// 顶层调用可传的根作用域；其中不含任何参数。
    pub fn root() -> Arc<Env> {
        Env::with(None, ())
    }

    /// The nearest layer whose parameters are a `P`; a type mismatch is skipped, not an error.
    /// 链上最近一个参数为 `P` 的层；类型不符就跳过，不算错误。
    pub fn find<P: 'static>(&self) -> Option<&P> {
        let mut cur = Some(self);
        while let Some(env) = cur {
            if let Some(p) = env.params.downcast_ref::<P>() {
                return Some(p);
            }
            cur = env.parent.as_deref();
        }
        None
    }

    /// The nearest layer that states a context; layers below inherit it.
    /// 链上最近一个明说上下文的层；下层继承它。
    pub fn scope(&self) -> Option<StyleScope> {
        let mut cur = Some(self);
        while let Some(env) = cur {
            if let Some(s) = env.scope {
                return Some(s);
            }
            cur = env.parent.as_deref();
        }
        None
    }

    pub fn parent(&self) -> Option<&Arc<Env>> {
        self.parent.as_ref()
    }
}

/// The context a subtree resolves its style in: which appearance, and any transition in flight.
/// `Env` carries it, so a family kit need not repeat these three fields in its own parameters.
/// 子树解析风格所依据的上下文：哪个外观，以及正在进行的过渡。它由 `Env` 承载，家族包不必在自己的
/// 参数里重抄这三个字段。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct StyleScope {
    pub appearance: ui_design::Appearance,
    /// Appearance to blend from while a theme transition runs; `None` means no transition.
    /// 主题过渡中从哪个外观混起；`None` 表示无过渡。
    pub theme_from: Option<ui_design::Appearance>,
    /// Transition progress, 0..=1; 1 means fully `appearance`.
    /// 过渡进度，0..=1；1 表示完全是 `appearance`。
    pub theme_t: f32,
}

impl Default for StyleScope {
    fn default() -> Self {
        Self { appearance: ui_design::Appearance::Light, theme_from: None, theme_t: 1.0 }
    }
}

impl StyleScope {
    /// A plain context for `appearance`, with no transition running.
    /// 针对 `appearance` 的朴素上下文，没有进行中的过渡。
    pub const fn new(appearance: ui_design::Appearance) -> Self {
        Self { appearance, theme_from: None, theme_t: 1.0 }
    }

    /// The nearest scope on the chain, or the standard light context.
    /// 链上最近的上下文；都没有则为标准浅色上下文。
    pub fn of(env: &Env) -> Self {
        env.scope().unwrap_or_default()
    }

    /// The same context with no transition when the transition is over or a no-op.
    /// 过渡已结束或本就无效时，返回不含过渡的同一上下文。
    pub fn settled(self) -> Self {
        let theme_t = self.theme_t.clamp(0.0, 1.0);
        let theme_from = self
            .theme_from
            .filter(|from| *from != self.appearance && theme_t < 1.0);
        Self { appearance: self.appearance, theme_from, theme_t }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[derive(Clone, Copy, Debug, PartialEq)]
    struct A(u32);
    #[derive(Clone, Copy, Debug, PartialEq)]
    struct B(u32);

    #[test]
    fn the_nearest_layer_of_the_matching_type_wins() {
        let root = Env::root();
        let outer = Env::with(Some(root.clone()), A(1));
        let middle = Env::with(Some(outer.clone()), B(2));
        let inner = Env::with(Some(middle.clone()), A(3));
        assert_eq!(inner.find::<A>(), Some(&A(3)));
        assert_eq!(middle.find::<A>(), Some(&A(1)));
        assert_eq!(middle.find::<B>(), Some(&B(2)));
        assert_eq!(root.find::<A>(), None);
        assert!(inner.parent().is_some());
    }

    #[test]
    fn a_layer_for_another_type_is_skipped_without_failing() {
        let outer = Env::with(Some(Env::root()), B(7));
        let inner = Env::with(Some(outer), A(1));
        assert_eq!(inner.find::<A>(), Some(&A(1)));
        assert_eq!(inner.find::<B>(), Some(&B(7)));
        assert_eq!(inner.find::<u64>(), None);
    }
}
