//! Style tokens: named, data-only, and swappable at runtime.
//! 风格令牌：具名、纯数据、运行时可换。

pub mod capability;
pub mod cache;
pub mod common_plane;
pub mod control_metrics;
pub mod env;
pub mod material;
pub mod pack;
pub mod motion;
pub mod roles;
pub mod legacy;
pub mod types;
pub mod style;

pub use capability::Capability;
pub use cache::StyleCache;
pub use common_plane::CommonPlane;
pub use control_metrics::{ControlKind, ControlMetrics, ControlMetricsTable, Density};
pub use material::Material;
pub use pack::{lerp_style, stub_type_table, PaletteHandle, Style, StyleBuilder};
pub use legacy::legacy_pack;
pub use style::{SliderSpec, ToggleSpec};
pub use types::{MetricsSet, TextRole, TextStyleToken, TypeTable, WidgetMetrics};
pub use motion::{MotionName, MotionTable, MotionToken};
pub use roles::{RoleDict, RoleName};
pub use env::{Env, StyleScope};
