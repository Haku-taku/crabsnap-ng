//! Named slots: a container declares a fixed vocabulary, the app fills what it has.
//! 命名槽：容器声明固定的词汇表，应用只填充自己有的那些。

use std::rc::Rc;

use crate::id::Id;
use crate::tree::Decl;

/// One slot's name, chosen by the container and fixed for its lifetime.
/// 一个槽的名字，由容器选定并在其生命周期内固定。
#[derive(Clone, Copy, Debug, PartialEq, Eq, PartialOrd, Ord, Hash)]
pub struct SlotName(&'static str);

impl SlotName {
    pub const fn new(name: &'static str) -> Self {
        Self(name)
    }

    /// The name as the container wrote it.
    /// 容器写下的原始名字。
    pub const fn as_str(self) -> &'static str {
        self.0
    }

    /// The salt this name contributes to its slot's node id.
    /// 该名字为其槽的节点 id 贡献的盐。
    pub(crate) const fn salt(self) -> (&'static str, &'static str) {
        ("slot", self.0)
    }
}

/// The node id a named slot takes under `container`; derived, never app-chosen.
/// 命名槽在 `container` 下占用的节点 id；由引擎派生，应用不得自编。
pub fn slot_id(container: Id, name: SlotName) -> Id {
    container.with(name.salt())
}

/// The app's fills, keyed by name; filling one name twice keeps the last.
/// 应用的填充，按名字索引；同名填充两次，保留最后一次。
#[derive(Clone, Debug, Default, PartialEq)]
pub struct SlotFills {
    fills: Vec<(SlotName, Rc<Decl>)>,
}

impl SlotFills {
    pub const fn new() -> Self {
        Self { fills: Vec::new() }
    }

    /// Fill one slot; a later fill of the same name replaces the earlier one.
    /// 填充一个槽；同名后填会替换先前的填充。
    pub fn fill(mut self, name: SlotName, content: impl Into<Rc<Decl>>) -> Self {
        self.insert(name, content);
        self
    }

    /// The in-place form of [`SlotFills::fill`], for a container merging in its defaults.
    /// [`SlotFills::fill`] 的就地版本，供容器并入自己的默认内容。
    pub fn insert(&mut self, name: SlotName, content: impl Into<Rc<Decl>>) {
        let content = content.into();
        match self.fills.iter_mut().find(|(n, _)| *n == name) {
            Some(slot) => slot.1 = content,
            None => self.fills.push((name, content)),
        }
    }

    pub fn get(&self, name: SlotName) -> Option<&Rc<Decl>> {
        self.fills.iter().find(|(n, _)| *n == name).map(|(_, d)| d)
    }

    pub fn is_empty(&self) -> bool {
        self.fills.is_empty()
    }

    pub fn len(&self) -> usize {
        self.fills.len()
    }

    /// The first fill naming a slot outside `vocabulary`, so a container can reject it.
    /// 第一个不在 `vocabulary` 里的填充名，供容器拒绝未知槽。
    pub fn outside(&self, vocabulary: &[SlotName]) -> Option<SlotName> {
        self.fills
            .iter()
            .map(|(n, _)| *n)
            .find(|n| !vocabulary.contains(n))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::geom::{Insets, Point, Rect};
    use crate::layout::{LayoutEngine, SizeClass};
    use crate::tree::{NodeKind, Tree};

    const LEADING: SlotName = SlotName::new("leading");
    const TRAILING: SlotName = SlotName::new("trailing");

    fn leaf(id: &'static str, w: f32, h: f32) -> Decl {
        Decl::container(crate::id::Id::str(id), NodeKind::Box).size(SizeClass::fixed(w, h))
    }

    fn row() -> Decl {
        Decl::container(crate::id::Id::str("row"), NodeKind::Row)
    }

    #[test]
    fn a_slot_keeps_its_id_when_its_content_changes() {
        // A slot's identity is (container, name). If the id followed the content instead,
        // every content swap would retire the node and the element cache would never hold.
        // 槽的身份是 (容器, 名字)。若 id 跟随内容，每次换内容都会回收节点，元素缓存永远命不中。
        let frame = |content: &'static str| row().slot(LEADING, leaf(content, 4.0, 4.0));
        let mut tree = Tree::new();
        tree.apply(&frame("a"));
        let slot = tree
            .find_by_id(super::slot_id(crate::id::Id::str("row"), LEADING))
            .expect("the slot node");
        let stats = tree.apply(&frame("b"));
        assert_eq!(
            tree.find_by_id(super::slot_id(crate::id::Id::str("row"), LEADING)),
            Some(slot),
            "the slot must keep its node when its content is replaced"
        );
        assert_eq!(stats.reused, 2, "the row and the slot survive the swap");
        assert_eq!(stats.created, 1, "only the new content node is created");
        assert_eq!(stats.retired, 1, "only the old content node is retired");
    }

    #[test]
    fn filling_one_slot_twice_keeps_the_last_content_where_the_first_landed() {
        // A container may fill a slot twice (a default, then an override); the last one wins
        // without moving the slot, so its position in the layout stays put.
        // 容器可能填同一个槽两次（默认值，再覆盖）；最后一次生效且槽不挪位，布局位置因此不变。
        let decl = row()
            .slot(TRAILING, leaf("t", 1.0, 1.0))
            .slot(LEADING, leaf("a", 1.0, 1.0))
            .slot(LEADING, leaf("b", 1.0, 1.0));
        assert_eq!(decl.children.len(), 2, "a second fill replaces, it does not append");
        assert_eq!(decl.children[0].id, super::slot_id(crate::id::Id::str("row"), TRAILING));
        assert_eq!(decl.children[1].id, super::slot_id(crate::id::Id::str("row"), LEADING));
        assert_eq!(
            decl.children[1].children[0].id,
            crate::id::Id::str("b"),
            "the last fill is the one that stays"
        );
    }

    #[test]
    fn a_name_nobody_filled_reads_as_absent() {
        // Slots are 0..n: a container asks only for the names it has fills for, and a
        // lookup must never fall back to another fill or the missing slot draws wrong content.
        // 槽是 0..n：容器只查自己有填充的名字，查找绝不回退到别的填充，
        // 否则缺席的槽会画出错误内容。
        let fills = SlotFills::new().fill(LEADING, leaf("a", 1.0, 1.0));
        assert_eq!(fills.len(), 1);
        assert!(fills.get(TRAILING).is_none(), "an unfilled name must read as absent");
        let decl = row().slot(LEADING, leaf("a", 1.0, 1.0));
        assert_eq!(decl.children.len(), 1, "only a filled slot becomes a node");
    }

    #[test]
    fn a_slot_keeps_the_frames_style_and_puts_the_content_inside_it() {
        // The container styles its slot (padding, size, kind); the app only supplies what
        // goes in, so a slot is not an anonymous child handed back to the container.
        // 容器给槽套样式（内衬、尺寸、类型）；应用只提供槽里的内容，槽不是交回容器的匿名子节点。
        let frame = Decl::container(crate::id::Id::str("ignored"), NodeKind::Column)
            .padding(Insets::all(7.0))
            .size(SizeClass::fixed(30.0, 20.0));
        let decl = row().slot_with(LEADING, frame, leaf("a", 4.0, 4.0));
        let slot = &decl.children[0];
        assert_eq!(slot.id, super::slot_id(crate::id::Id::str("row"), LEADING));
        assert_eq!(slot.kind, NodeKind::Column);
        assert_eq!(slot.size_class, SizeClass::fixed(30.0, 20.0));
        assert_eq!(slot.box_model.padding, Insets::all(7.0), "the frame's inset was dropped");
        assert_eq!(slot.children[0].id, crate::id::Id::str("a"));
    }

    #[test]
    fn a_fill_outside_the_vocabulary_is_reported() {
        // The vocabulary is the container's; a name it never declared must be caught, not
        // silently placed under whatever position the app guessed.
        // 词汇表归容器所有；容器没声明的名字必须被发现，而不是按应用猜的位置悄悄放下。
        let fills = SlotFills::new()
            .fill(LEADING, leaf("a", 1.0, 1.0))
            .fill(SlotName::new("sideways"), leaf("b", 1.0, 1.0));
        assert_eq!(fills.outside(&[LEADING, TRAILING]), Some(SlotName::new("sideways")));
        assert_eq!(fills.len(), 2);
    }

    #[test]
    fn a_bare_slot_adds_no_padding_gap_or_displacement() {
        // The wrapper exists for identity, not geometry: a 10x10 content in a hugging row
        // must not be inset, separated or moved by the node that carries the slot's id.
        // 外壳只为身份存在，不为几何：紧贴行里 10x10 的内容不得被承载槽 id 的节点
        // 加内衬、加间隙或挪动。
        let decl = row()
            .size(SizeClass::fixed(40.0, 40.0))
            .cross_align(0.0)
            .slot(LEADING, leaf("a", 10.0, 10.0));
        let mut tree = Tree::new();
        tree.apply(&decl);
        let root = tree.root().expect("root");
        let mut engine = crate::BuiltinLayout::new(crate::MonospaceMeasure::default());
        engine.solve(
            &mut tree,
            root,
            crate::Constraints::loose(crate::geom::Size::new(40.0, 40.0)),
        );
        let slot = tree
            .find_by_id(super::slot_id(crate::id::Id::str("row"), LEADING))
            .expect("slot");
        let content = tree.find_by_id(crate::id::Id::str("a")).expect("content");
        assert_eq!(tree.get(slot).expect("node").rect, Rect::new(0.0, 0.0, 10.0, 10.0));
        assert_eq!(tree.get(content).expect("node").rect, Rect::new(0.0, 0.0, 10.0, 10.0));
        assert_eq!(
            tree.get(slot).expect("node").offset,
            Point::new(0.0, 0.0),
            "the wrapper must not displace its content"
        );
    }
}
