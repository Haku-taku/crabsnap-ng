//! Context-menu items a node declares, and the engine shows.
//! 节点声明的上下文菜单项，由引擎显示。

use crate::id::Id;

/// One row of a context menu.
/// 上下文菜单的一行。
///
/// The label is the app's: the engine never invents text, only lays it out.
/// 标签属于应用：引擎从不自己编文字，只负责排版。
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct MenuItem {
    /// Stable id, reported back when the row is chosen.
    /// 稳定 id，行被选中时原样上报。
    pub id: Id,
    pub label: String,
    /// The chord the row runs, shown at its trailing edge, already in the app's words.
    /// 该行执行的组合键，显示在行的尾缘；文字已由应用给出。
    pub shortcut: Option<String>,
    /// A greyed row that cannot be chosen, e.g. Copy with nothing selected.
    /// 变灰不可选的行，例如没有选区时的"复制"。
    pub enabled: bool,
}

impl MenuItem {
    pub fn new(id: Id, label: impl Into<String>) -> Self {
        Self {
            id,
            label: label.into(),
            shortcut: None,
            enabled: true,
        }
    }

    /// Show `shortcut` at the row's trailing edge.
    /// 在行的尾缘显示 `shortcut`。
    pub fn with_shortcut(mut self, shortcut: impl Into<String>) -> Self {
        self.shortcut = Some(shortcut.into());
        self
    }

    /// A row that is shown but cannot be chosen.
    /// 显示出来但不可选中的行。
    pub fn disabled(mut self) -> Self {
        self.enabled = false;
        self
    }
}
