//! Key chords, and the stable ids a shortcut is registered under.
//! 组合键，以及快捷键注册所用的稳定 ID。

use crate::event::{Key, Modifiers};

/// A key plus the modifiers that must be held with it.
/// 一个键，以及必须同时按住的修饰键。
///
/// Matching is exact: one extra modifier makes it a different chord, as in Qt and GPUI.
/// 匹配是精确的：多按一个修饰键就是另一条组合键，与 Qt、GPUI 一致。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct KeyChord {
    /// The key, with letters stored unshifted so `Ctrl+Shift+Z` has one spelling.
    /// 键；字母按未加 Shift 的形式存放，使 `Ctrl+Shift+Z` 只有一种写法。
    pub key: Key,
    pub mods: Modifiers,
}

impl KeyChord {
    pub const fn new(key: Key, mods: Modifiers) -> Self {
        Self { key, mods }
    }

    /// Whether the chord is the one pressed: same modifiers, same key.
    /// 按下的组合是否就是本条：修饰键与键都相同。
    pub fn matches(&self, key: Key, mods: Modifiers) -> bool {
        self.mods == mods && same_key(self.key, key)
    }
}

/// Case-insensitive for letters: the platform reports the shifted character.
/// 字母忽略大小写：平台上报的是加上 Shift 之后的字符。
fn same_key(a: Key, b: Key) -> bool {
    match (a, b) {
        (Key::Char(x), Key::Char(y)) => x.eq_ignore_ascii_case(&y),
        _ => a == b,
    }
}

/// A stable name for a shortcut, so an app can override a built-in by id.
/// 快捷键的稳定名字，应用据此改写内置绑定。
///
/// `&'static str` on purpose: an id that changes between runs cannot be overridden.
/// 刻意用 `&'static str`：会变的 id 无法被改写。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct ShortcutId(pub &'static str);

impl ShortcutId {
    /// The ids the engine binds by default; every one of them is overridable.
    /// 引擎默认绑定的 id；每一条都可以被改写。
    pub const COPY: Self = Self("text.copy");
    pub const CUT: Self = Self("text.cut");
    pub const PASTE: Self = Self("text.paste");
    pub const SELECT_ALL: Self = Self("text.select-all");
    /// Deletes the character after the caret, as in Emacs and readline.
    /// 删除插入符之后的字符，与 Emacs、readline 一致。
    pub const DELETE_FORWARD: Self = Self("text.delete-forward");
    pub const HOME: Self = Self("text.home");
    pub const END: Self = Self("text.end");
    pub const DOCUMENT_HOME: Self = Self("text.document-home");
    pub const DOCUMENT_END: Self = Self("text.document-end");
    pub const EXTEND_LEFT: Self = Self("text.extend-left");
    pub const EXTEND_RIGHT: Self = Self("text.extend-right");
    pub const EXTEND_UP: Self = Self("text.extend-up");
    pub const EXTEND_DOWN: Self = Self("text.extend-down");
    pub const EXTEND_WORD_LEFT: Self = Self("text.extend-word-left");
    pub const EXTEND_WORD_RIGHT: Self = Self("text.extend-word-right");
    pub const EXTEND_HOME: Self = Self("text.extend-home");
    pub const EXTEND_END: Self = Self("text.extend-end");
    pub const EXTEND_DOCUMENT_HOME: Self = Self("text.extend-document-home");
    pub const EXTEND_DOCUMENT_END: Self = Self("text.extend-document-end");
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_shifted_letter_matches_the_unshifted_chord_with_shift_held() {
        let chord = KeyChord::new(
            Key::Char('z'),
            Modifiers {
                ctrl: true,
                shift: true,
                ..Modifiers::default()
            },
        );
        assert!(chord.matches(
            Key::Char('Z'),
            Modifiers {
                ctrl: true,
                shift: true,
                ..Modifiers::default()
            }
        ));
        // The same letter without Shift is a different chord, not a near miss.
        // 同一个字母不带 Shift 是另一条组合键，而不是近似匹配。
        assert!(!chord.matches(
            Key::Char('Z'),
            Modifiers {
                ctrl: true,
                ..Modifiers::default()
            }
        ));
    }
}
