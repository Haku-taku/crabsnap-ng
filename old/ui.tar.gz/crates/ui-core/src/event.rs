//! Input events, kept as plain data so every backend can produce them.
//! 输入事件，保持为纯数据，任何后端都能产生。

use crate::geom::Point;

/// Which pointer button an event refers to.
/// 事件涉及的指针按键。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum PointerButton {
    Primary,
    Secondary,
    Middle,
}

/// Keys the framework names itself; text input arrives as `Text`.
/// 框架自己命名的按键；文本输入通过 `Text` 送达。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Key {
    Escape,
    Enter,
    /// Space: activates like Enter on most toolkits.
    /// 空格：在多数工具包里与 Enter 一样用于激活。
    Space,
    Tab,
    Backspace,
    /// Forward delete: removes the character after the caret.
    /// 向前删除：移除插入符之后的字符。
    Delete,
    Home,
    End,
    Left,
    Right,
    Up,
    Down,
    /// A character pressed with a command modifier (Ctrl/Alt/Logo), so it is a command and
    /// not text: the platform sends it here instead of `Text`, and nothing gets inserted.
    /// 带命令修饰键（Ctrl/Alt/Logo）按下的字符，因此是命令而非文本：
    /// 平台送到这里而不是 `Text`，于是什么都不会被插入。
    Char(char),
}

/// Held modifier keys, reported whenever the set changes.
/// 按住的修饰键；集合变化时上报。
///
/// Ambient rather than per-key: a key press does not say which modifiers were down,
/// because the platform reports them separately and a client may miss either.
/// 作为环境状态而非逐键携带：平台单独上报修饰键，客户端可能只收到其中之一。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash)]
pub struct Modifiers {
    pub shift: bool,
    pub ctrl: bool,
    pub alt: bool,
    pub logo: bool,
}

impl Modifiers {
    /// Nothing held, for a chord that must match a bare key.
    /// 什么都没按，用于必须匹配裸键的组合。
    pub const NONE: Self = Self { shift: false, ctrl: false, alt: false, logo: false };

    /// No modifier held.
    /// 没有按住任何修饰键。
    pub fn is_empty(&self) -> bool {
        !(self.shift || self.ctrl || self.alt || self.logo)
    }
}

/// One input event.
/// 一个输入事件。
///
/// Positions are logical units, the same space as layout, so hit testing needs no conversion.
/// 位置是逻辑单位，与布局同一坐标系，因此命中测试不需要换算。
#[derive(Clone, Debug, PartialEq)]
pub enum Event {
    PointerMoved {
        pos: Point,
    },
    /// The pointer left the surface; nothing is hovered afterwards.
    /// 指针离开表面；之后没有节点被悬停。
    PointerLeft,
    PointerPressed {
        pos: Point,
        button: PointerButton,
    },
    PointerReleased {
        pos: Point,
        button: PointerButton,
    },
    /// A committed character or string, already decoded by the platform.
    /// 已由平台解码完成的一个字符或字符串。
    Text(String),
    /// Clipboard text the platform read for a paste request.
    /// 平台为一次粘贴请求读回的剪贴板文本。
    ///
    /// Separate from `Text`: a paste replaces the selection as one edit, and an app that
    /// filters typed characters must not filter it the same way.
    /// 与 `Text` 分开：粘贴作为一次编辑替换选区，过滤键入字符的应用不该同样过滤它。
    Paste(String),
    KeyPressed {
        key: Key,
    },
    KeyReleased {
        key: Key,
    },
    /// A wheel or trackpad step, in pixels per axis; a plain wheel reports `y` only.
    /// 滚轮或触控板的一步，按轴给出像素；普通滚轮只报 `y`。
    Scroll {
        pos: Point,
        delta: Point,
    },
    /// The set of held modifiers changed.
    /// 按住的修饰键集合发生变化。
    Modifiers(Modifiers),
    /// The input method's composition changed; `None` ends it without committing.
    /// 输入法的组合发生变化；`None` 表示组合结束且没有提交。
    Preedit(Option<crate::ime::Preedit>),
    /// The input method asks for the bytes before and after the caret to be removed.
    /// 输入法要求删除插入符前后的若干**字节**。
    DeleteSurrounding {
        before: usize,
        after: usize,
    },
}

impl Event {
    /// A vertical wheel step, the shape every plain mouse reports.
    /// 纵向滚轮步进，所有普通鼠标都报这个形状。
    pub fn wheel(pos: Point, dy: f32) -> Self {
        Event::Scroll { pos, delta: Point::new(0.0, dy) }
    }

    /// Pointer position this event carries, if any.
    /// 本事件携带的指针位置（若有）。
    pub fn pos(&self) -> Option<Point> {
        match self {
            Event::PointerMoved { pos }
            | Event::PointerPressed { pos, .. }
            | Event::PointerReleased { pos, .. }
            | Event::Scroll { pos, .. } => Some(*pos),
            Event::PointerLeft | Event::Text(_) | Event::KeyPressed { .. } => None,
            Event::KeyReleased { .. } | Event::Modifiers(_) => None,
            Event::Preedit(_) | Event::DeleteSurrounding { .. } | Event::Paste(_) => None,
        }
    }

    /// True for a pure position report: a higher rate of these cannot add anything.
    /// 纯粹的坐标上报：再高的报告率也加不进新东西。
    ///
    /// A wheel is not one of these: it changes a scroller's offset, so the frame has to be
    /// rebuilt. Only a move that cannot change a pixel may be skipped.
    /// 滚轮不算：它改变滚动容器的偏移，帧必须重建。只有改变不了像素的移动才可以跳过。
    pub fn is_continuous(&self) -> bool {
        matches!(self, Event::PointerMoved { .. })
    }

    /// True when this event can change what is hovered.
    /// 本事件是否可能改变悬停状态。
    pub fn moves_pointer(&self) -> bool {
        matches!(
            self,
            Event::PointerMoved { .. } | Event::PointerLeft | Event::PointerPressed { .. }
        )
    }
}
