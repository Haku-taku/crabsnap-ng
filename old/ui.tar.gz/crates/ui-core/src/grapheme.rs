//! Grapheme cluster boundaries (UAX #29): the unit the caret and shaping both step by.
//! 字簇边界（UAX #29）：插入符与整形共同步进的单位。
//!
//! A user perceives `3️⃣`, `👨‍👩‍👧` and `e\u{301}` as one character, so every place that walks
//! a string by `char` here walks it by cluster instead.
//! 用户把 `3️⃣`、`👨‍👩‍👧`、`e\u{301}` 都看作一个字符，因此这里按字符逐个走的地方一律改走字簇。

use unicode_segmentation::UnicodeSegmentation;

/// `text`'s clusters as `(byte offset, cluster)`, in order.
/// 按顺序给出 `text` 的字簇 `(字节偏移, 字簇)`。
pub fn clusters(text: &str) -> impl Iterator<Item = (usize, &str)> + '_ {
    text.grapheme_indices(true)
}

/// The cluster boundary at or before `at`; `at` may be any byte offset, even mid-character.
/// `at` 之前（含）最近的字簇边界；`at` 可以是任意字节偏移，甚至落在字符中间。
pub fn snap(text: &str, at: usize) -> usize {
    let at = at.min(text.len());
    let mut floor = 0;
    for (i, g) in clusters(text) {
        if i + g.len() > at {
            break;
        }
        floor = i + g.len();
    }
    floor
}

/// The cluster boundary at or after `at`; a boundary stays put, the end caps it.
/// `at` 之后（含）最近的边界；本身是边界则不动，超出则以末尾为上限。
pub fn ceil(text: &str, at: usize) -> usize {
    let at = at.min(text.len());
    match snap(text, at) == at {
        true => at,
        false => next(text, at),
    }
}

/// The boundary after the cluster that contains `at`; the end when there is none.
/// `at` 所在字簇之后的边界；没有下一个时返回末尾。
pub fn next(text: &str, at: usize) -> usize {
    let from = snap(text, at);
    text[from..]
        .graphemes(true)
        .next()
        .map_or(text.len(), |g| from + g.len())
}

/// The boundary before the cluster that contains `at`; the start when there is none.
/// `at` 所在字簇之前的边界；没有上一个时返回开头。
pub fn prev(text: &str, at: usize) -> usize {
    let at = snap(text, at);
    text[..at]
        .graphemes(true)
        .next_back()
        .map_or(0, |g| at - g.len())
}

#[cfg(test)]
mod tests {
    use super::*;

    /// One keycap, one ZWJ family, one flag and one decomposed `é`, in that order.
    /// 依次为一个键帽、一个 ZWJ 家庭、一面旗帜与一个分解形式的 `é`。
    const MIXED: [&str; 4] = [
        "3\u{fe0f}\u{20e3}",
        "\u{1f468}\u{200d}\u{1f469}\u{200d}\u{1f467}",
        "\u{1f1e8}\u{1f1f3}",
        "e\u{301}",
    ];

    fn mixed() -> String {
        MIXED.concat()
    }

    #[test]
    fn a_cluster_is_one_step_for_the_caret() {
        // Arrow keys cross each sequence as a whole; stepping by `char` would land inside.
        // 方向键整段跨过每个序列；按字符步进会落在序列内部。
        let text = mixed();
        let mut bounds = Vec::new();
        let mut at = 0;
        for part in MIXED {
            at += part.len();
            bounds.push(at);
        }
        let found: Vec<usize> = clusters(&text).map(|(i, g)| i + g.len()).collect();
        assert_eq!(found, bounds, "four clusters, no boundary inside one");
        assert_eq!(found.len(), 4, "ten code points, four characters");
        let mut at = 0;
        for &b in &bounds {
            assert_eq!(next(&text, at), b);
            assert_eq!(prev(&text, b), at);
            at = b;
        }
        assert_eq!(next(&text, at), text.len(), "the end is a wall");
        assert_eq!(prev(&text, 0), 0, "the start is a wall");
    }

    #[test]
    fn an_offset_inside_a_cluster_snaps_to_its_start_and_steps_past_it() {
        // A stale or hand-made offset must never split a cluster on the next edit.
        // 过期或手工给出的偏移绝不能在下次编辑时劈开字簇。
        let text = mixed();
        let keycap = MIXED[0].len();
        assert_eq!(snap(&text, 3), 0, "inside the keycap");
        assert_eq!(snap(&text, keycap), keycap, "a boundary stays put");
        assert_eq!(snap(&text, 999), text.len(), "past the end is the end");
        assert_eq!(next(&text, 3), keycap, "forward leaves the whole cluster");
        assert_eq!(prev(&text, 3), 0, "backward leaves the whole cluster");
        assert_eq!(snap(&text, 2), 0, "mid-character still snaps");
        assert_eq!(ceil(&text, 2), keycap, "an IME byte range grows to a whole cluster");
        assert_eq!(ceil(&text, keycap), keycap, "a boundary stays put");
        assert_eq!(ceil(&text, 999), text.len(), "past the end is the end");
    }
}
