//! Input-method composition: the preedit string, which the app never sees.
//! 输入法组合：预编辑串，应用永远看不到它。

/// The string an input method is composing, and where its own caret sits inside it.
/// 输入法正在组合的串，以及它自己的插入符在该串中的位置。
///
/// The app's buffer stays committed-only: this is engine state, drawn after the caret and
/// reported to the compositor as the cursor position, never merged until it commits.
/// 应用的缓冲只含已提交内容：这是引擎状态，画在插入符处、并作为光标位置报给合成器，
/// 提交之前绝不并入。
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub struct Preedit {
    /// Bytes being composed, in the order the input method gave them.
    /// 正在组合的字节，按输入法给出的顺序。
    pub text: String,
    /// The input method's caret inside `text`, in bytes.
    /// 输入法在 `text` 内的插入符，字节偏移。
    pub cursor: usize,
}

impl Preedit {
    pub fn new(text: impl Into<String>, cursor: usize) -> Self {
        Self {
            text: text.into(),
            cursor,
        }
    }

    /// Nothing is being composed.
    /// 没有正在组合的内容。
    pub fn is_empty(&self) -> bool {
        self.text.is_empty()
    }
}
