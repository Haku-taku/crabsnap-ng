//! Draw primitives, the order log, and batch planning.
//! 绘制图元、顺序日志与批次计划。
//!
//! Order and data are stored separately, so a backend can upload a whole typed
//! slice at once. A single `enum Cmd` would force a match per command.
//! 顺序与数据分开存储，后端可整段上传同类型数据。单一 `enum Cmd` 会逼出逐条 match。

use crate::geom::{Color, Corners, Insets, Rect};
use crate::id::{Id, NodeId};

/// Direction a linear gradient runs in.
/// 线性渐变的走向。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum GradientAxis {
    /// Top to bottom.
    /// 自上而下。
    Vertical,
    /// Left to right.
    /// 自左而右。
    Horizontal,
}

/// A two-stop linear gradient in the primitive's own rect.
/// 图元自身矩形内的两段线性渐变。
///
/// XAML states the stops separately from the brush's extent, and WinUI's elevation borders
/// use both: a 3-unit run at offset 0.33 rather than a ramp across the whole control.
/// XAML 把停点与画刷的跨度分开写，WinUI 的立面描边两者都用：3 个单位、起点 0.33，
/// 而不是横跨整个控件的斜坡。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Gradient {
    pub from: Color,
    pub to: Color,
    pub axis: GradientAxis,
    /// Where the near and far stops sit in the gradient's own 0..1 space.
    /// 近端与远端停点在渐变自身 0..1 空间里的位置。
    pub stops: (f32, f32),
    /// `None` spans the whole box; `Some(len)` covers only the first `len` units on the axis.
    /// `None` 横跨整个盒子；`Some(len)` 只覆盖轴上头 `len` 个单位。
    pub extent: Option<f32>,
    /// Measure from the far edge inward: WinUI's light theme mirrors its elevation borders.
    /// 从远端向内度量：WinUI 的明色主题把立面描边镜像过来。
    pub flip: bool,
}

impl Gradient {
    /// A full-box gradient, near stop at the start and far stop at the end.
    /// 横跨整个盒子的渐变，近端在起点、远端在终点。
    pub const fn new(from: Color, to: Color, axis: GradientAxis) -> Self {
        Self { from, to, axis, stops: (0.0, 1.0), extent: None, flip: false }
    }

    /// Anchor the run at the box's far edge instead of its near edge.
    /// 把渐变锚在盒子的远端而不是近端。
    pub const fn flipped(mut self) -> Self {
        self.flip = true;
        self
    }

    /// Move the two stops inside the gradient's own space.
    /// 把两个停点移到渐变自身空间里的位置。
    pub const fn with_stops(mut self, near: f32, far: f32) -> Self {
        self.stops = (near, far);
        self
    }

    /// Cover only the first `len` units along the axis, holding the far colour after.
    /// 只覆盖轴上头 `len` 个单位，其后保持远端色。
    pub const fn over(mut self, len: f32) -> Self {
        self.extent = Some(len);
        self
    }

    /// Colour at `u`, the gradient's own 0..=1 coordinate.
    /// 渐变自身 0..=1 坐标 `u` 处的颜色。
    pub fn at(&self, u: f32) -> Color {
        let (near, far) = self.stops;
        let span = if far > near { far - near } else { 1.0 };
        self.from.lerp(self.to, ((u - near) / span).clamp(0.0, 1.0))
    }

    /// Colour at `pos` units along the axis, in a box `extent` units long.
    /// 轴上 `pos` 处的颜色，盒子在该轴上的长度为 `extent`。
    pub fn sample(&self, pos: f32, extent: f32) -> Color {
        // A flip mirrors the whole box before the run is measured into it.
        // 翻转先把整个盒子镜像，再在其中度量渐变。
        let pos = if self.flip { extent - pos } else { pos };
        let len = self.extent.unwrap_or(extent);
        let u = if len > 0.0 { pos / len } else { 0.0 };
        self.at(u)
    }
}

/// How far a press splat grows, and whether it drifts to the node's centre.
/// 按压墨迹扩到多大，以及是否漂移到节点中心。
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum InkRadius {
    /// A fixed radius around the press point; the splat never drifts.
    /// 绕按下点的固定半径；墨迹不漂移。
    Fixed(f32),
    /// Covers the node: the splat drifts to the centre and grows to half the diagonal.
    /// 盖住整个节点：墨迹漂到中心，半径长到对角线的一半。
    Cover,
}

/// Where a ripple takes its rect and curve from: its effective background.
/// 涟漪从哪取矩形与曲线：它的有效背景。
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum InkTarget {
    /// The node's own box and its declared (or inferred) curve.
    /// 节点自身的盒子与声明（或推断）的曲线。
    Node,
    /// An explicit rect and curve in the node's own space: the control's effective
    /// background, whether or not this frame paints one.
    /// 节点自身空间中的显式矩形与曲线：控件的有效背景，与本帧是否画了背景无关。
    Rect { rect: crate::geom::Rect, corners: crate::geom::Corners },
    /// The nth shape the node paints, in declaration order: that shape's rect and curve.
    /// 节点按声明顺序绘制的第 n 个形状：它的矩形与曲线。
    Shape(usize),
    /// A descendant node's box and curve, as Flutter's `getRectCallback`.
    /// 后代节点的盒子与曲线（Flutter 的 `getRectCallback`）。
    Descendant(Id),
}

/// Press ink the engine splats where a press lands and fades out after release.
/// 引擎在按下落点泼出、松手后淡出的按压墨迹。
///
/// The engine owns the splat's origin and lifetime: `Widget::decl` is a pure function and
/// cannot hold the press point across frames, so a control only states colour and size.
/// 落点与寿命由引擎持有：`Widget::decl` 是纯函数，留不住跨帧的按下点，控件只声明颜色与大小。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct PressInk {
    /// Ink colour; its alpha is the strength the state layer would have.
    /// 墨色；alpha 即状态层应有的强度。
    pub colour: Color,
    pub radius: InkRadius,
    /// The ink's effective background; the ripple sizes to it and is clipped to it.
    /// 墨迹的有效背景；涟漪以它为尺寸与裁剪基准。
    pub target: InkTarget,
    /// Opacity ramp while held; Flutter's `_kFadeInDuration`.
    /// 按住期间的透明度爬升；Flutter 的 `_kFadeInDuration`。
    pub fade_in: crate::anim::AnimSpec,
    /// Radius and drift; Flutter's `_kRadiusDuration`.
    /// 半径与漂移；Flutter 的 `_kRadiusDuration`。
    pub grow: crate::anim::AnimSpec,
    /// Fade after the press ends.
    /// 按下结束后的淡出。
    pub fade: crate::anim::AnimSpec,
}

impl PressInk {
    /// Flutter `InkRipple`: 75ms fade-in, 225ms radius on `Curves.ease`, then 375ms from the
    /// release with the fade in its last 150ms — a quick tap still shows the whole splash.
    /// Flutter `InkRipple`：75ms 淡入、225ms 半径（`Curves.ease`）；松手后 375ms，
    /// 淡出占最后 150ms——轻点一下也看得到完整墨迹。
    pub const fn new(colour: Color, radius: InkRadius) -> Self {
        Self::with_target(colour, radius, InkTarget::Node)
    }

    /// Ink sized to and clipped by `target`, its effective background.
    /// 涟漪以 `target`（有效背景）为尺寸与裁剪基准。
    pub const fn with_target(colour: Color, radius: InkRadius, target: InkTarget) -> Self {
        use crate::anim::{AnimSpec, Easing};
        Self {
            colour,
            radius,
            target,
            fade_in: AnimSpec::new(0.075, Easing::Linear),
            grow: AnimSpec::new(0.225, Easing::Cubic(0.25, 0.1, 0.25, 1.0)),
            fade: AnimSpec::new(0.15, Easing::Linear).delayed(0.225),
        }
    }
}

/// One filled (optionally rounded) box.
/// 一个填充（可圆角）盒。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct RectPrim {
    pub rect: Rect,
    pub radius: Corners,
    /// Solid colour; also the fallback where `gradient` is unsupported.
    /// 实色；同时也是 `gradient` 不被支持时的回落色。
    pub fill: Color,
    /// Optional gradient across `rect`; backends that cannot draw it use `fill`.
    /// 可选的、横跨 `rect` 的渐变；画不了的后端使用 `fill`。
    pub gradient: Option<Gradient>,
    pub border: Option<(Color, f32)>,
    /// A gradient across the stroke; `border` stays the near-stop fallback.
    /// 沿描边的渐变；`border` 仍是近端色回落。
    pub border_gradient: Option<Gradient>,
    /// Omit the border over this x-range of its top edge, measured from `rect`'s left.
    /// 在顶边这一段 x 区间（自 `rect` 左缘量起）不画描边。
    ///
    /// An outlined field's label cuts this gap; it is a property of the stroke, so it
    /// lives on the primitive rather than in a clip.
    /// 带描边字段的标签切出这个缺口；它是描边的属性，因此落在图元上而不是裁剪里。
    pub notch: Option<(f32, f32)>,
}

/// One stroked circular arc, with its bounding box for clipping and damage.
/// 一段圆形描边弧，附带用于裁剪与脏区的包围盒。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct SectorPrim {
    pub bounds: Rect,
    /// Stroke colour.
    /// 描边颜色。
    pub colour: Color,
    pub sector: Sector,
}

/// A stroked circular arc, measured in turns clockwise from 3 o'clock.
/// 一段圆形描边弧，以“圈”计，从三点钟方向顺时针量起。
///
/// Turns rather than radians because the reference (Lottie's `TrimEnd`) expresses arcs
/// that way; a quarter turn is `0.25`, a full ring `0.0..=1.0`.
/// 用“圈”而非弧度，因为参考实现（Lottie 的 `TrimEnd`）就是这么表达弧的；
/// 四分之一圈是 `0.25`，整圈是 `0.0..=1.0`。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Sector {
    /// Centre, relative to `rect`'s origin.
    /// 圆心，相对 `rect` 原点。
    pub centre: crate::geom::Point,
    /// Radius of the stroke's outer edge.
    /// 描边外缘的半径。
    pub radius: f32,
    /// Stroke width, growing inwards.
    /// 描边宽度，向内生长。
    pub thickness: f32,
    /// Start and end in turns; the sweep runs clockwise from start to end.
    /// 起止位置（圈）；扫动自起点顺时针到终点。
    pub trim: (f32, f32),
    /// Round caps at both ends, as WinUI's `StrokeDashCap="Round"` draws them.
    /// 两端圆头帽，与 WinUI 的 `StrokeDashCap="Round"` 一致。
    pub round_caps: bool,
}

impl Sector {
    /// The sweep in turns; a span of one full turn or more is the whole ring.
    /// 扫动量（圈）；跨度达到一整圈或更多即为整环。
    ///
    /// `rem_euclid` alone would fold a full turn back to zero, which is how a 100% ring
    /// would vanish.
    /// 只用 `rem_euclid` 会把一整圈折回零，100% 的环便会消失。
    pub fn sweep(&self) -> f32 {
        let span = self.trim.1 - self.trim.0;
        if span >= 1.0 {
            1.0
        } else {
            span.rem_euclid(1.0)
        }
    }

    /// The bounding box of the stroke, in the same space as the primitive's `rect`.
    /// 描边包围盒，与图元的 `rect` 同一坐标系。
    ///
    /// Damage and the vertex quad both round this out to the pixel grid, so the feather's
    /// half pixel is covered without the box carrying a margin of its own.
    /// 脏区与顶点四边形都把它按像素网格向外取整，羽化的半个像素因此被覆盖，
    /// 盒子本身无需再留余量。
    pub fn bounds(&self) -> Rect {
        let r = self.radius;
        Rect::new(self.centre.x - r, self.centre.y - r, 2.0 * r, 2.0 * r)
    }
}

impl RectPrim {
    /// Colour at a point: the gradient if present, else the solid fill.
    /// 某点处的颜色：有渐变用渐变，否则用实色。
    pub fn colour_at(&self, px: f32, py: f32) -> Color {
        match &self.gradient {
            Some(g) => {
                let (pos, extent) = match g.axis {
                    GradientAxis::Vertical => (py - self.rect.origin.y, self.rect.size.h),
                    GradientAxis::Horizontal => (px - self.rect.origin.x, self.rect.size.w),
                };
                g.sample(pos, extent)
            }
            None => self.fill,
        }
    }

    /// The stroke's colour at a point: its gradient if present, else the solid.
    /// 描边在某点处的颜色：有渐变用渐变，否则用实色。
    pub fn border_colour_at(&self, px: f32, py: f32) -> Color {
        let Some((solid, _)) = self.border else {
            return Color::TRANSPARENT;
        };
        match &self.border_gradient {
            Some(g) => {
                let (pos, extent) = match g.axis {
                    GradientAxis::Vertical => (py - self.rect.origin.y, self.rect.size.h),
                    GradientAxis::Horizontal => (px - self.rect.origin.x, self.rect.size.w),
                };
                g.sample(pos, extent)
            }
            None => solid,
        }
    }

    /// Whether a point, relative to the rect's origin, falls in the stroke's top-edge gap.
    /// 某点（相对矩形原点）是否落在描边顶边的缺口里。
    ///
    /// The band is the stroke plus half a pixel: the antialiased skirt reaches past the
    /// nominal width, and leaving it behind draws a hairline under a floating label.
    /// 带为描边宽度再加半像素：抗锯齿边缘会越过名义宽度，留下它会在浮起标签下画出一条细线。
    pub fn in_notch(&self, x: f32, y: f32, width: f32, skirt: f32) -> bool {
        let Some((from, to)) = self.notch else {
            return false;
        };
        x >= from && x <= to && y <= width + 0.5 + skirt.max(0.0)
    }
}

/// Build a flat draw list from a laid-out tree: backgrounds then text, in tree order.
/// 从已布局的树生成扁平绘制列表：按树序先背景后文本。
///
/// Every primitive is placed at `visual_rect`, never `rect`: an offset lives only in the
/// visual rect, so painting the layout rect pins every offset child to its parent origin.
/// 每个图元都按 `visual_rect` 放置，绝不用 `rect`：偏移只存在于视觉矩形里，用布局矩形会把
/// 每个带偏移的子节点钉在父原点上。
pub fn list_from_tree(tree: &crate::tree::Tree, viewport: Rect) -> DrawList {
    let mut list = DrawList::new(viewport);
    for nid in tree.walk() {
        let Some(node) = tree.get(nid) else { continue };
        let visual = node.visual_rect();
        push_shapes(&mut list, nid, node, visual, |_, _| None);
        if let crate::tree::NodeData::Text {
            block,
            ink,
            caret,
            selection,
            composing,
            ..
        } = &node.data
        {
            list.push_text(
                nid,
                TextPrim {
                    block: block.clone(),
                    origin: visual.origin,
                    max_width: visual.size.w,
                    layout: node.inline.clone(),
                    height: visual.size.h,
                    ink: *ink,
                    caret: *caret,
                    selection: selection.clone(),
                    composing: composing.clone(),
                    zoom: None,
                },
            );
        }
    }
    list
}

/// Emit one node's shapes in paint order; `image` resolves a texture slot for box images.
/// 按绘制顺序发出一个节点的形状；`image` 为盒子图像解析纹理槽位。
pub fn push_shapes(
    list: &mut DrawList,
    owner: NodeId,
    node: &crate::tree::Node,
    visual: Rect,
    mut image: impl FnMut(&crate::tree::ImageSpec, Rect) -> Option<ImagePrim>,
) {
    for shape in &node.shapes {
        match shape {
            Shape::Box {
                corners,
                fill,
                gradient,
                border,
                shadow,
                image: spec,
            } => {
                if let Some(sh) = shadow {
                    list.push_shadow(
                        owner,
                        ShadowPrim {
                            rect: visual.inflate(sh.spread),
                            corners: *corners,
                            colour: sh.colour,
                            blur: sh.blur,
                            dy: sh.dy,
                            ring: 0.0,
                        },
                    );
                }
                list.push_rect(
                    owner,
                    RectPrim {
                        rect: visual,
                        radius: *corners,
                        fill: *fill,
                        gradient: *gradient,
                        border: *border,
                        border_gradient: None,
                        notch: None,
                    },
                );
                if let Some(spec) = spec
                    && let Some(prim) = image(spec, visual) {
                        list.push_image_prim(owner, prim);
                    }
            }
            Shape::Rect {
                rect,
                corners,
                fill,
                gradient,
                border,
            } => {
                list.push_rect(
                    owner,
                    RectPrim {
                        rect: rect.translate(visual.origin),
                        radius: *corners,
                        fill: *fill,
                        gradient: *gradient,
                        border: *border,
                        border_gradient: None,
                        notch: None,
                    },
                );
            }
            Shape::Shadow {
                rect,
                corners,
                colour,
                blur,
                dy,
                ring,
            } => {
                list.push_shadow(
                    owner,
                    ShadowPrim {
                        rect: rect.translate(visual.origin),
                        corners: *corners,
                        colour: *colour,
                        blur: *blur,
                        dy: *dy,
                        ring: *ring,
                    },
                );
            }
            Shape::Outline {
                corners,
                colour,
                gradient,
                width,
                gap,
            } => {
                list.push_rect(
                    owner,
                    RectPrim {
                        rect: visual,
                        radius: *corners,
                        fill: Color::TRANSPARENT,
                        gradient: None,
                        border: Some((*colour, *width)),
                        border_gradient: *gradient,
                        notch: *gap,
                    },
                );
            }
            Shape::Sector {
                centre,
                radius,
                thickness,
                trim,
                round_caps,
                colour,
            } => {
                let sector = Sector {
                    centre: crate::geom::Point::new(
                        visual.origin.x + centre.x,
                        visual.origin.y + centre.y,
                    ),
                    radius: *radius,
                    thickness: *thickness,
                    trim: *trim,
                    round_caps: *round_caps,
                };
                list.push_sector(
                    owner,
                    SectorPrim {
                        bounds: sector.bounds(),
                        colour: *colour,
                        sector,
                    },
                );
            }
        }
    }
}

/// The focus adorner a node asks the engine to draw around itself.
/// 节点要求引擎在其周围绘制的焦点装饰。
///
/// It is a *post-layout* drawing: the rect is only known after layout, and the adorner
/// deliberately extends past the node's box (`margin` is negative, as WinUI writes it).
/// 它是**布局之后**的绘制：矩形只有在布局完成才确定，而装饰刻意伸出节点盒子
/// （`margin` 取负，与 WinUI 的写法一致）。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct FocusVisual {
    /// The outer stroke and its width. WinUI: `FocusVisualPrimaryBrush`, 2 px.
    /// 外圈颜色与宽度。WinUI：`FocusVisualPrimaryBrush`，2 像素。
    pub outer: Color,
    pub outer_width: f32,
    /// The inner stroke drawn just inside the outer one. WinUI: `FocusVisualSecondaryBrush`, 1 px.
    /// 紧贴外圈内侧画的内圈。WinUI：`FocusVisualSecondaryBrush`，1 像素。
    pub inner: Color,
    pub inner_width: f32,
    /// How far the adorner reaches outside the node on each side; negative, as XAML writes it.
    /// 装饰每边伸出节点的距离；取负，与 XAML 写法一致。
    pub margin: crate::geom::Insets,
    /// Extra radius over the node's own, so the two curves stay concentric.
    /// 在节点自身圆角上加的量，使两条曲线同心。
    pub radius: f32,
}

/// A paint-only shape in the node's own space: no identity, no layout slot, no hit target.
/// 节点自身坐标系中的纯绘制形状：无身份、不占布局槽位、不可命中。
#[derive(Clone, Debug, PartialEq)]
pub enum Shape {
    /// The node's own box: its fill, gradient, border, shadow and image.
    /// 节点自身的盒子：填充、渐变、描边、阴影与图像。
    Box {
        corners: Corners,
        fill: Color,
        gradient: Option<Gradient>,
        border: Option<(Color, f32)>,
        shadow: Option<crate::tree::ShadowSpec>,
        image: Option<crate::tree::ImageSpec>,
    },
    /// An explicit rect: circles, pills and thumbnails inside the node's box.
    /// 显式矩形：节点盒子内的圆、胶囊与缩略图。
    Rect {
        rect: Rect,
        corners: Corners,
        fill: Color,
        gradient: Option<Gradient>,
        border: Option<(Color, f32)>,
    },
    /// A soft shadow under an explicit rect.
    /// 显式矩形下的柔和阴影。
    Shadow {
        rect: Rect,
        corners: Corners,
        colour: Color,
        blur: f32,
        dy: f32,
        /// How deep the casting band is: 0 shadows the whole shape, a positive depth shadows
        /// only its rim, leaving the interior clear for a translucent surface above it.
        /// 投射带的深度：0 投整个形状，正值只投它的边缘，内部留给上方半透明的表面。
        ring: f32,
    },
    /// The node's own box drawn as a border only, its top edge interrupted over `gap`:
    /// an outlined field's label notch, measured from the node's left edge.
    /// 节点自身盒子只画描边，顶边在 `gap` 这一段中断：带描边字段的标签缺口，自节点左缘量起。
    Outline {
        corners: Corners,
        colour: Color,
        /// A gradient along the stroke; `colour` stays the near-stop fallback.
        /// 沿描边的渐变；`colour` 仍是近端色回落。
        gradient: Option<Gradient>,
        width: f32,
        gap: Option<(f32, f32)>,
    },
    /// A stroked circular arc: rings and progress sweeps.
    /// 一段圆形描边弧：圆环与进度扫动。
    Sector {
        /// Centre in the node's own space.
        /// 圆心，位于节点自身坐标系。
        centre: crate::geom::Point,
        radius: f32,
        thickness: f32,
        trim: (f32, f32),
        round_caps: bool,
        colour: Color,
    },
}

impl Shape {
    /// The area this shape can touch, given the box of the node that owns it.
    /// 该形状可能触及的区域，参数为其所属节点的盒子。
    pub fn bounds(&self, node: Rect) -> Rect {
        match self {
            // Same extent as the prim it becomes: spread goes into the rect, the rest pads it.
            // 与它变成的图元范围一致：spread 进了矩形，其余按外扩计。
            Shape::Box { shadow, .. } => match shadow {
                Some(s) => shadow_painted(node.inflate(s.spread), s.blur, s.dy, 0.0),
                None => node,
            },
            // Sub-shapes are declared in the node's own space, so lift them into absolute.
            // 子形状声明在节点自身坐标系，因此需要抬到绝对坐标。
            Shape::Rect { rect, .. } => rect.translate(node.origin),
            Shape::Shadow {
                rect,
                blur,
                dy,
                ring,
                ..
            } => shadow_painted(rect.translate(node.origin), *blur, *dy, *ring),
            Shape::Outline { .. } => node,
            // The arc is declared in the node's space too.
            // 弧同样声明在节点自身坐标系。
            Shape::Sector {
                centre,
                radius,
                ..
            } => Rect::new(
                node.origin.x + centre.x - radius,
                node.origin.y + centre.y - radius,
                2.0 * radius,
                2.0 * radius,
            ),
        }
    }
}

/// A uniform scale, applied to everything a subtree paints.
/// 作用于一棵子树绘制的一切的等比缩放。
///
/// Affine rather than scale-about-a-point: two scales about different centres compose to a
/// translation, which a fixed point cannot express; nesting would drift.
/// 用仿射而非「绕某点缩放」：两个不同中心的缩放复合出来是平移，定点表达不了，嵌套会漂移。
///
/// Paint-only: layout never sees it. Non-uniform and rotational transforms are a different,
/// later problem; a scale is what presence animations and the slider lens need.
/// 纯绘制：布局看不见它。非等比与旋转是另一件、更晚的事；进出场动画与滑杆透镜只要缩放。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Transform {
    pub scale: f32,
    /// Added after scaling: `p * scale + offset`.
    /// 缩放之后再加：`p × scale + offset`。
    pub offset: crate::geom::Point,
}

impl Transform {
    pub const IDENTITY: Self = Self {
        scale: 1.0,
        offset: crate::geom::Point::ZERO,
    };

    /// The scale that leaves `origin` where it is.
    /// 让 `origin` 保持不动的缩放。
    pub fn about(origin: crate::geom::Point, scale: f32) -> Self {
        Self {
            scale,
            offset: origin - origin * scale,
        }
    }

    pub fn is_identity(self) -> bool {
        (self.scale - 1.0).abs() < 1e-6 && self.offset.x.abs() < 1e-6 && self.offset.y.abs() < 1e-6
    }

    pub fn apply_point(self, p: crate::geom::Point) -> crate::geom::Point {
        p * self.scale + self.offset
    }

    pub fn apply_rect(self, r: Rect) -> Rect {
        let origin = self.apply_point(r.origin);
        Rect::new(
            origin.x,
            origin.y,
            r.size.w * self.scale,
            r.size.h * self.scale,
        )
    }

    pub fn apply_corners(self, c: crate::geom::Corners) -> crate::geom::Corners {
        crate::geom::Corners {
            tl: c.tl * self.scale,
            tr: c.tr * self.scale,
            br: c.br * self.scale,
            bl: c.bl * self.scale,
            shape: c.shape,
        }
    }

    /// Compose: `self` wraps `inner`, so the inner scale happens first.
    /// 复合：`self` 包住 `inner`，因此内层缩放先发生。
    pub fn then(self, inner: Self) -> Self {
        Self {
            scale: self.scale * inner.scale,
            offset: self.apply_point(inner.offset),
        }
    }
}

/// One run of text.
/// 一段文字。
#[derive(Clone, Debug, PartialEq)]
pub struct TextPrim {
    /// Styled runs plus paragraph properties; rich text adds runs here.
    /// 带样式的 run 与段落属性；富文本在这里增加 run。
    pub block: crate::text::TextBlock,
    pub origin: crate::geom::Point,
    /// Wrap width in logical units; `f32::INFINITY` means one line.
    /// 换行宽度（逻辑单位）；`f32::INFINITY` 表示不换行。
    pub max_width: f32,
    /// The lines layout wrapped this block into; `None` makes the painter wrap it itself.
    /// 布局把本块断成的行；`None` 时由绘制端自行断行。
    pub layout: Option<std::rc::Rc<crate::text::InlineLayout>>,
    /// The node's own box height; `0.0` when the caller does not know it.
    /// 节点自身的盒高；调用方不知道时为 `0.0`。
    ///
    /// A symbol is centred by its ink inside this box; text ignores it.
    /// 符号按墨在此盒中居中；文字忽略它。
    pub height: f32,
    /// Ink this text is drawn in; the component picks the role, the type ramp never does.
    /// 绘制这段文字的墨色；角色由控件选，字阶从不决定它。
    pub ink: Color,
    /// Draw the insertion caret at this byte offset.
    /// 在该字节偏移处绘制插入符。
    pub caret: Option<Caret>,
    /// Selected bytes and how this style draws them; `None` when nothing is selected.
    /// 被选中的字节以及本风格如何绘制它；没有选区时为 `None`。
    pub selection: Option<crate::selection::SelectionPrim>,
    /// Bytes the input method is composing; drawn with an underline.
    /// 输入法正在组合的字节；带下划线绘制。
    pub composing: Option<std::ops::Range<usize>>,
    /// The scale in force where this run was pushed; shaping happens first, then this applies.
    /// 压入本段文字处生效的缩放；先成形，再施加它。
    ///
    /// It sits here because glyphs exist only after shaping, which happens after painting.
    /// 它放在这里，是因为字形要等成形之后才存在，而成形发生在绘制之后。
    pub zoom: Option<Transform>,
}

/// A text input's insertion caret: where it sits and what colour it takes.
/// 文本输入的插入符：位置与其颜色。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Caret {
    pub offset: usize,
    pub color: Color,
}

/// Which atlas a glyph primitive samples.
/// 字形图元采样哪张图集。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum GlyphKind {
    /// One coverage byte per pixel, tinted by `GlyphPrim::color`.
    /// 每像素一字节覆盖率，由 `GlyphPrim::color` 着色。
    #[default]
    Coverage,
    /// Premultiplied RGBA per pixel, used as-is; `color` only scales alpha.
    /// 每像素预乘 RGBA，直接使用；`color` 只缩放 alpha。
    Color,
}

/// One pre-rasterized glyph blitted from an atlas.
/// 从图集贴上的一个已光栅化字形。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct GlyphPrim {
    /// Destination rect on screen.
    /// 屏幕上的目标矩形。
    pub rect: Rect,
    /// Atlas slot origin and size.
    /// 图集槽位的原点与尺寸。
    pub atlas: Rect,
    /// Linear multiplier applied to coverage or alpha (0..=1).
    /// 覆盖率或 alpha 上的线性乘子（0..=1）。
    pub alpha: f32,
    pub color: Color,
    /// Whether `atlas` indexes the coverage atlas or the colour atlas.
    /// `atlas` 指向覆盖率图集还是颜色图集。
    pub kind: GlyphKind,
}

/// One RGBA8 texture drawn into a rounded rect, sampling a source sub-rect.
/// 把一张 RGBA8 纹理画进圆角矩形，采样其源子矩形。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ImagePrim {
    /// Destination in logical units.
    /// 目标矩形，逻辑单位。
    pub rect: Rect,
    pub corners: Corners,
    /// Index into `DrawList::images`.
    /// `DrawList::images` 的下标。
    pub texture: u32,
    /// Source rect in texture pixels, already resolved by the node's fit.
    /// 源矩形（纹理像素），已由节点的 fit 算好。
    pub src: Rect,
}

/// A soft shadow under a rounded rect. The falloff is analytic, so there is no blur pass.
/// 圆角矩形下的柔和阴影。衰减是解析的，因此不需要模糊趟。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ShadowPrim {
    /// The shape being shadowed; the shadow extends `blur` beyond it.
    /// 被投影的形状；阴影向外延伸 `blur`。
    pub rect: Rect,
    pub corners: Corners,
    /// Colour and peak alpha.
    /// 颜色与峰值 alpha。
    pub colour: Color,
    /// Falloff width in logical units: the shadow fades over roughly `2 * blur`.
    /// 衰减宽度，逻辑单位：阴影大约在 `2 × blur` 内淡出。
    pub blur: f32,
    /// Vertical offset; WinUI's elevation shadows sit slightly below their surface.
    /// 垂直偏移；WinUI 的立面阴影略微落在表面下方。
    pub dy: f32,
    /// Depth of the casting band, in logical units; 0 shadows the whole shape.
    /// 投射带的深度，逻辑单位；0 表示投整个形状。
    pub ring: f32,
}

/// The area a shadow cast by `rect` can paint: the shader's own quad extent.
/// 以 `rect` 为投射体的阴影可能画到的区域：与着色器的四边形外扩完全一致。
fn shadow_painted(rect: Rect, blur: f32, dy: f32, ring: f32) -> Rect {
    rect.inflate(ring * 0.5 + blur * 1.5 + dy.abs())
}

impl ShadowPrim {
    /// The area this shadow can paint, for damage and clipping.
    /// 该阴影可能画到的区域，供脏区与裁剪使用。
    pub fn painted(&self) -> Rect {
        shadow_painted(self.rect, self.blur, self.dy, self.ring)
    }
}

/// One texture the frame refers to. `id` is stable across frames so a renderer can cache.
/// 本帧引用的一张纹理。`id` 跨帧稳定，渲染器据此缓存。
#[derive(Clone, Debug)]
pub struct ImageEntry {
    pub id: u64,
    pub width: u32,
    pub height: u32,
    /// RGBA8, straight alpha, row-major.
    /// RGBA8、直通 alpha、行优先。
    pub data: std::sync::Arc<Vec<u8>>,
}

/// Primitive kinds, ordered so that `PrimKind as usize` indexes the bank array.
/// 图元种类；`as usize` 可直接索引各类型数组。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
#[repr(usize)]
pub enum PrimKind {
    Rect = 0,
    Text = 1,
    Glyph = 2,
    Image = 3,
    Shadow = 4,
    Sector = 5,
}

impl PrimKind {
    pub const COUNT: usize = 6;

    pub const fn index(self) -> usize {
        self as usize
    }
}

/// Why a datum is in the list, and where it lives.
/// 一条操作：什么种类、第几个。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct PrimRef {
    pub kind: PrimKind,
    pub index: u32,
}

/// One entry in the paint-order log.
/// 绘制顺序日志中的一条。
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Op {
    /// Draw the referenced primitive.
    /// 绘制引用的图元。
    Prim(PrimRef),
    /// Push a clip rect (index into `clips`).
    /// 压入裁剪矩形（`clips` 的下标）。
    PushClip(u32),
    /// Pop the innermost clip.
    /// 弹出最内层裁剪。
    PopClip,
    /// Push an offscreen layer (index into `layers`).
    /// 压入离屏层（`layers` 的下标）。
    PushLayer(u32),
    /// Pop the innermost layer.
    /// 弹出最内层层。
    PopLayer,
    /// Blur whatever is already painted inside a rect (index into `backdrops`).
    /// 模糊矩形内已画好的内容（`backdrops` 的下标）。
    Backdrop(u32),
}

/// WinUI acrylic: a luminosity wash, a colour-blended tint, then a grain layer.
/// WinUI acrylic：先亮度洗色、再色相着色、最后铺一层噪点。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Acrylic {
    /// Tint colour; `a` is `TintOpacity` times the tint-opacity modifier.
    /// 着色色；`a` 是 `TintOpacity` 乘上 tint 不透明度修正系数。
    pub tint: Color,
    /// Luminosity colour; `a` is `TintLuminosityOpacity`.
    /// 亮度色；`a` 是 `TintLuminosityOpacity`。
    pub luminosity: Color,
    /// Grain layer opacity; the reference tiles a 2% noise image here.
    /// 噪点层不透明度；参考实现在这里平铺一张 2% 的噪点图。
    pub noise: f32,
}

/// What glass does to its capture before any colour: a neutral luminance transfer plus a
/// chroma scale. Apple's regular glass lifts luminance toward white and keeps the hue.
/// 玻璃在着色之前对捕获做的事：一次中性亮度变换加一次色度缩放。Apple 的 regular 玻璃把
/// 亮度朝白抬升，色相保留。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct GlassBody {
    /// Share of the way the luminance moves toward `pole`.
    /// 亮度朝 `pole` 移动的比例。
    pub mix: f32,
    /// The luminance `mix` heads toward.
    /// `mix` 所趋近的亮度。
    pub pole: f32,
    /// Chroma scale about that luminance; `1` keeps the backdrop's saturation.
    /// 围绕该亮度的色度缩放；`1` 保持背景饱和度。
    pub chroma: f32,
    /// Strength of the dark appearance's shadow-lifting tone curve, `0..=1.5`.
    /// 暗色外观抬升暗部的色调曲线强度，`0..=1.5`。
    pub tone: f32,
}

impl GlassBody {
    /// No body: the capture reaches the eye untouched.
    /// 无本体：捕获原样到达眼睛。
    pub const CLEAR: Self = Self {
        mix: 0.0,
        pole: 1.0,
        chroma: 1.0,
        tone: 0.0,
    };
}

/// LiquidGlassKit's glass material (`LiquidGlassView.swift:56-78`): the backdrop is captured
/// at the material's own density, the rim bends by a thin prism, then Fresnel and glare.
/// LiquidGlassKit 的玻璃材质（`LiquidGlassView.swift:56-78`）：背景按材质自身的密度捕获，
/// 边缘按薄棱镜偏角弯折，再叠菲涅尔与眩光。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct LiquidGlass {
    /// The neutral body; it carries no hue, so an untinted pane never casts one.
    /// 中性本体；它不带色相，因此未着色的玻璃永远不投出色偏。
    pub body: GlassBody,
    /// A semantic brand colour laid over the body, at `a`; transparent means untinted.
    /// 覆在本体上的语义品牌色，按 `a` 混入；透明即未着色。
    pub tint: Color,
    /// `refractiveIndex`: how hard the rim's thin prism bends.
    /// `refractiveIndex`：边缘薄棱镜的弯折强度。
    pub refractive_index: f32,
    /// `glassThickness` in dp: how deep the rim bend reaches.
    /// `glassThickness`（dp）：边缘弯折深入多远。
    pub thickness: f32,
    /// `backgroundTextureSizeCoefficient`: how much wider than the node the capture is.
    /// `backgroundTextureSizeCoefficient`：捕获区域比节点宽多少。
    pub capture_size: f32,
    /// `backgroundTextureScaleCoefficient`: capture density against the node's device size.
    /// `backgroundTextureScaleCoefficient`：捕获密度相对节点设备尺寸的比例。
    pub capture_scale: f32,
    /// Content scale under the glass: `1` shows 1:1, `0.75` shows a wider field (shrinks).
    /// 玻璃下内容的比例：`1` 为 1:1，`0.75` 显示更宽的范围（内容缩小）。
    pub magnification: f32,
    /// How far the backdrop is blurred before it is captured, in dp; `0` keeps it sharp.
    /// 捕获前把背景模糊多远（dp）；`0` 表示保持清晰。
    pub frost: f32,
    /// `dispersionStrength`: per-channel prism split, scaled by 0.02 in the shader.
    /// `dispersionStrength`：逐通道棱镜色散，着色器里乘 0.02。
    pub dispersion: f32,
    /// `fresnelIntensity`: how much the grazing angle lifts the rim, `0..=1`.
    /// `fresnelIntensity`：掠射角提亮边缘的量，`0..=1`。
    pub fresnel_intensity: f32,
    /// `fresnelDistanceRange` in dp: how far from the edge Fresnel builds.
    /// `fresnelDistanceRange`（dp）：菲涅尔从边缘向内延伸多远。
    pub fresnel_distance: f32,
    /// `fresnelEdgeSharpness`: power of the Fresnel falloff.
    /// `fresnelEdgeSharpness`：菲涅尔衰减的幂次。
    pub fresnel_sharpness: f32,
    /// `glareIntensity`: strength of the specular streak.
    /// `glareIntensity`：镜面条纹的强度。
    pub glare_intensity: f32,
    /// `glareDistanceRange` in dp: how far the streak reaches inward.
    /// `glareDistanceRange`（dp）：条纹向内延伸多远。
    pub glare_distance: f32,
    /// `glareEdgeSharpness`: power of the streak's falloff.
    /// `glareEdgeSharpness`：条纹衰减的幂次。
    pub glare_sharpness: f32,
    /// `glareAngleConvergence`: focuses the streak toward the light axis, `0..=π`.
    /// `glareAngleConvergence`：把条纹聚向光轴，`0..=π`。
    pub glare_convergence: f32,
    /// `glareOppositeSideBias`: `>1` amplifies the far-side highlight.
    /// `glareOppositeSideBias`：大于 1 时放大背面高光。
    pub glare_bias: f32,
    /// `glareDirectionOffset` in radians: tilts the streak's asymmetry.
    /// `glareDirectionOffset`（弧度）：倾斜条纹的不对称。
    pub glare_offset: f32,
    /// Extra shapes fused with the node's own rect, which is always shape zero.
    /// 与节点自身矩形融合的其他形状；节点自身矩形永远是第 0 个。
    pub blend: [BlendShape; BLEND_SHAPES],
    /// How many entries of `blend` are live; `0` shades the node's rect alone.
    /// `blend` 中有效的条目数；`0` 表示只按节点矩形着色。
    pub blend_count: u8,
    /// The smooth-union radius in logical px: how far a neck reaches between shapes.
    /// 平滑并集半径（逻辑像素）：两个形状之间的液桥延伸多远。
    pub blend_k: f32,
}

/// How many extra shapes one glass surface may fuse with.
/// 一块玻璃表面最多能融合多少个额外形状。
pub const BLEND_SHAPES: usize = 4;

/// One member of a blend group, in the node's own logical coordinates.
/// 融合组的一个成员，坐标在节点自身的逻辑空间。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BlendShape {
    pub rect: Rect,
    pub corners: Corners,
}

impl BlendShape {
    /// A shape that contributes nothing; the slot's default.
    /// 不参与任何贡献的形状；槽位的默认值。
    pub const NONE: Self = Self {
        rect: Rect::new(0.0, 0.0, 0.0, 0.0),
        corners: Corners::ZERO,
    };
}

/// How a blurred backdrop is shaded before it is written back over the frame.
/// 模糊后的背景在写回帧之前如何着色。
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum BackdropMaterial {
    /// Plain blit of the blurred pixels; the node's own translucent fill supplies the tint.
    /// 直接写回模糊像素；着色由节点自己的半透明填充提供。
    Plain,
    Acrylic(Acrylic),
    LiquidGlass(LiquidGlass),
}

impl BackdropMaterial {
    /// The material that leaves the blur untouched.
    /// 不改动模糊结果的那种材质。
    pub const PLAIN: Self = Self::Plain;
}

/// A backdrop blur recorded by `Op::Backdrop`.
/// `Op::Backdrop` 记录的背景模糊。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BackdropEntry {
    /// The shape whose backdrop is read; its corners belong to this box.
    /// 读取背景的盒形；圆角属于这个盒子。
    pub rect: Rect,
    /// The clip the box is cut by, in visual space: the frost is cut the same way.
    /// 盒子被裁到的矩形（视觉空间）：磨砂也照此裁切。
    pub clip: Rect,
    pub corners: Corners,
    pub radius: u32,
    pub sigma: f32,
    /// How the blurred result is shaded; `PLAIN` keeps the tinted blur.
    /// 模糊结果如何着色；`PLAIN` 保留普通着色模糊。
    pub material: BackdropMaterial,
}

/// A clip region recorded by `Op::PushClip`.
/// `Op::PushClip` 记录的裁剪区域。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ClipEntry {
    pub rect: Rect,
    /// Corner shape of the clip; `Corners::ZERO` means a plain rectangle.
    /// 裁剪的圆角形状；`Corners::ZERO` 表示普通矩形。
    pub corners: Corners,
    /// The uncut box the corners belong to; equals `rect` unless an outer clip cut it.
    /// 圆角所属的未裁切盒子；除非被外层裁切，否则等于 `rect`。
    pub shape: Rect,
}

impl ClipEntry {
    pub fn rect(rect: Rect) -> Self {
        Self {
            rect,
            corners: Corners::ZERO,
            shape: rect,
        }
    }
}

/// A layer recorded by `Op::PushLayer`.
/// `Op::PushLayer` 记录的层。
#[derive(Clone, Debug, PartialEq)]
pub struct LayerEntry {
    pub bounds: Rect,
    /// Applied in order to the layer's pixels before compositing; empty means none.
    /// 合成前按顺序作用于本层像素；空表示无效果。
    pub effects: Vec<crate::effect::Effect>,
    pub radius: Corners,
    /// When set, the target outlives the frame under this key and is reused while nothing
    /// inside the layer changes; `None` renders the layer afresh every frame.
    /// 设置后，目标以该键跨帧保留，层内无变化时复用；`None` 表示每帧重画。
    pub cache_key: Option<u64>,
}

impl LayerEntry {
    /// Uniform fade when the chain is exactly one opacity matrix.
    /// 当效果链恰好是一个透明度矩阵时给出均匀淡出值。
    pub fn opacity(&self) -> Option<f32> {
        match self.effects.as_slice() {
            [] => Some(1.0),
            [e] if e.kernel.is_identity() => e.color.as_opacity(),
            _ => None,
        }
    }
}

/// Typed primitive banks.
/// 按类型分组的图元数组。
#[derive(Default, Debug)]
pub struct Primitives {
    pub rects: Vec<RectPrim>,
    pub texts: Vec<TextPrim>,
    pub glyphs: Vec<GlyphPrim>,
    pub images: Vec<ImagePrim>,
    pub shadows: Vec<ShadowPrim>,
    pub sectors: Vec<SectorPrim>,
}

impl Primitives {
    pub fn len_of(&self, kind: PrimKind) -> usize {
        match kind {
            PrimKind::Rect => self.rects.len(),
            PrimKind::Text => self.texts.len(),
            PrimKind::Glyph => self.glyphs.len(),
            PrimKind::Image => self.images.len(),
            PrimKind::Shadow => self.shadows.len(),
            PrimKind::Sector => self.sectors.len(),
        }
    }
}

/// A contiguous run of same-kind primitives under one clip, one layer.
/// 同一裁剪、同一层下连续的一段同类型图元。
#[derive(Clone, Debug, PartialEq)]
pub struct Batch {
    pub kind: PrimKind,
    /// Range into the typed bank.
    /// 在对应类型数组中的区间。
    pub range: core::ops::Range<u32>,
    /// Clip in force for this batch (`None` = unlimited).
    /// 本批次的裁剪（`None` 表示不裁剪）。
    pub clip: Option<ClipEntry>,
    /// Layer chain from outermost to innermost; empty means the root target.
    /// 从最外层到最内层的层链；空表示根目标。
    pub layers: Vec<u32>,
    /// Backdrop generation; a batch never spans two different values.
    /// 背景模糊世代；批次绝不跨越两个不同的值。
    pub epoch: u32,
    /// Union of the prims' bounds: a backend may skip a batch that misses the redraw band.
    /// 本批图元边界的并集：后端可以跳过不与重绘带相交的批次。
    pub bounds: Option<Rect>,
}

/// The per-frame draw list.
/// 每帧的绘制列表。
#[derive(Default, Debug)]
pub struct DrawList {
    pub ops: Vec<Op>,
    pub prims: Primitives,
    pub clips: Vec<ClipEntry>,
    pub layers: Vec<LayerEntry>,
    pub backdrops: Vec<BackdropEntry>,
    /// Textures this frame samples, indexed by `ImagePrim::texture`.
    /// 本帧采样的纹理，由 `ImagePrim::texture` 索引。
    pub images: Vec<ImageEntry>,
    /// Owning node per primitive, for per-node damage diffing.
    /// 每个图元所属节点，供按节点做脏区差分。
    pub owners: Owners,
    /// Canvas size, for batching decisions.
    /// 画布尺寸，供批次决策。
    pub canvas: Rect,
    /// Scale applied to every primitive pushed from now on; `None` paints as laid out.
    /// 此后压入的每个图元都要乘上的缩放；`None` 按布局原样绘制。
    ///
    /// The painter sets it for the span of one subtree, so a subtree that scales is scaled
    /// whole — shapes, clips, layers and glyphs alike — without touching layout.
    /// 绘制端在一棵子树的范围内设置它，因此做缩放的子树整体被缩放——形状、裁剪、层与字形
    /// 一视同仁，而布局不受影响。
    pub transform: Option<Transform>,
}

/// Per-kind ownership tables, parallel to `Primitives`.
/// 与 `Primitives` 平行的归属表。
#[derive(Default, Debug)]
pub struct Owners {
    pub rects: Vec<NodeId>,
    pub texts: Vec<NodeId>,
    pub glyphs: Vec<NodeId>,
    pub images: Vec<NodeId>,
    pub shadows: Vec<NodeId>,
    pub sectors: Vec<NodeId>,
}

impl Owners {
    pub fn push(&mut self, kind: PrimKind, node: NodeId) {
        match kind {
            PrimKind::Rect => self.rects.push(node),
            PrimKind::Text => self.texts.push(node),
            PrimKind::Glyph => self.glyphs.push(node),
            PrimKind::Image => self.images.push(node),
            PrimKind::Shadow => self.shadows.push(node),
            PrimKind::Sector => self.sectors.push(node),
        }
    }

    pub fn of(&self, kind: PrimKind, index: usize) -> Option<NodeId> {
        match kind {
            PrimKind::Rect => self.rects.get(index).copied(),
            PrimKind::Text => self.texts.get(index).copied(),
            PrimKind::Glyph => self.glyphs.get(index).copied(),
            PrimKind::Image => self.images.get(index).copied(),
            PrimKind::Shadow => self.shadows.get(index).copied(),
            PrimKind::Sector => self.sectors.get(index).copied(),
        }
    }
}

impl DrawList {
    pub fn new(canvas: Rect) -> Self {
        Self {
            canvas,
            ..Default::default()
        }
    }

    pub fn clear(&mut self) {
        self.ops.clear();
        self.prims.rects.clear();
        self.prims.texts.clear();
        self.prims.glyphs.clear();
        self.prims.images.clear();
        self.prims.shadows.clear();
        self.prims.sectors.clear();
        self.clips.clear();
        self.layers.clear();
        self.backdrops.clear();
        self.images.clear();
        self.owners.rects.clear();
        self.owners.texts.clear();
        self.owners.glyphs.clear();
        self.owners.images.clear();
        self.owners.shadows.clear();
        self.owners.sectors.clear();
    }

    /// The transform in force for pushes right now, when it would change anything.
    /// 此刻生效的缩放；它不改变任何东西时为 `None`。
    fn tf(&self) -> Option<Transform> {
        self.transform.filter(|t| !t.is_identity())
    }

    pub fn push_rect(&mut self, owner: NodeId, mut prim: RectPrim) -> u32 {
        if let Some(t) = self.tf() {
            prim.rect = t.apply_rect(prim.rect);
            prim.radius = t.apply_corners(prim.radius);
            if let Some((_, width)) = prim.border.as_mut() {
                *width *= t.scale;
            }
            prim.notch = prim.notch.map(|(a, b)| (a * t.scale, b * t.scale));
            if let Some(g) = prim.gradient.as_mut() {
                g.extent = g.extent.map(|len| len * t.scale);
            }
            if let Some(g) = prim.border_gradient.as_mut() {
                g.extent = g.extent.map(|len| len * t.scale);
            }
        }
        let index = self.prims.rects.len() as u32;
        self.prims.rects.push(prim);
        self.owners.push(PrimKind::Rect, owner);
        self.ops.push(Op::Prim(PrimRef {
            kind: PrimKind::Rect,
            index,
        }));
        index
    }

    /// Register a texture for this frame and return its index.
    /// 为本帧登记一张纹理并返回下标。
    pub fn push_image(&mut self, entry: ImageEntry) -> u32 {
        let index = self.images.len() as u32;
        self.images.push(entry);
        index
    }

    /// Add one stroked arc; its bounds ride along for damage and culling.
    /// 加入一段描边弧；包围盒一并带上，供脏区与裁剪使用。
    pub fn push_sector(&mut self, owner: NodeId, mut prim: SectorPrim) -> u32 {
        if let Some(t) = self.tf() {
            // The centre is relative to the bounds' origin, so it scales on its own.
            // 圆心相对包围盒原点，因此它自己按比例缩放。
            prim.bounds = t.apply_rect(prim.bounds);
            prim.sector.centre = prim.sector.centre * t.scale;
            prim.sector.radius *= t.scale;
            prim.sector.thickness *= t.scale;
        }
        let index = self.prims.sectors.len() as u32;
        self.prims.sectors.push(prim);
        self.owners.push(PrimKind::Sector, owner);
        self.ops.push(Op::Prim(PrimRef {
            kind: PrimKind::Sector,
            index,
        }));
        index
    }

    pub fn push_shadow(&mut self, owner: NodeId, mut prim: ShadowPrim) -> u32 {
        if let Some(t) = self.tf() {
            prim.rect = t.apply_rect(prim.rect);
            prim.corners = t.apply_corners(prim.corners);
            prim.blur *= t.scale;
            prim.dy *= t.scale;
            prim.ring *= t.scale;
        }
        let index = self.prims.shadows.len() as u32;
        self.prims.shadows.push(prim);
        self.owners.push(PrimKind::Shadow, owner);
        self.ops.push(Op::Prim(PrimRef {
            kind: PrimKind::Shadow,
            index,
        }));
        index
    }

    pub fn push_image_prim(&mut self, owner: NodeId, mut prim: ImagePrim) -> u32 {
        if let Some(t) = self.tf() {
            prim.rect = t.apply_rect(prim.rect);
            prim.corners = t.apply_corners(prim.corners);
        }
        let index = self.prims.images.len() as u32;
        self.prims.images.push(prim);
        self.owners.push(PrimKind::Image, owner);
        self.ops.push(Op::Prim(PrimRef {
            kind: PrimKind::Image,
            index,
        }));
        index
    }

    pub fn push_glyph(&mut self, owner: NodeId, mut prim: GlyphPrim) -> u32 {
        if let Some(t) = self.tf() {
            // Scaling the destination quad scales the glyph; the atlas rect stays as it is.
            // 缩放目标四边形就是缩放字形；图集矩形原样不动。
            prim.rect = t.apply_rect(prim.rect);
        }
        let index = self.prims.glyphs.len() as u32;
        self.prims.glyphs.push(prim);
        self.owners.push(PrimKind::Glyph, owner);
        self.ops.push(Op::Prim(PrimRef {
            kind: PrimKind::Glyph,
            index,
        }));
        index
    }

    pub fn push_text(&mut self, owner: NodeId, mut prim: TextPrim) -> u32 {
        // Glyphs do not exist yet, so the scale rides along and the pass applies it later.
        // 字形此刻还不存在，因此缩放随图元同行，由解析那一趟施加。
        if let Some(t) = self.tf() {
            prim.zoom = Some(match prim.zoom {
                Some(inner) => t.then(inner),
                None => t,
            });
        }
        let index = self.prims.texts.len() as u32;
        self.prims.texts.push(prim);
        self.owners.push(PrimKind::Text, owner);
        self.ops.push(Op::Prim(PrimRef {
            kind: PrimKind::Text,
            index,
        }));
        index
    }

    pub fn push_clip(&mut self, rect: Rect, corners: Corners) {
        self.push_clip_shaped(rect, corners, rect);
    }

    /// Push a clip whose corners belong to `shape`, an uncut box that an outer clip narrowed
    /// to `rect`: the cut edge stays square while the node's own corners stay round.
    /// 压入圆角属于 `shape` 的裁剪：外层把盒子裁到 `rect`，切口保持方角，节点自身的角仍是圆的。
    pub fn push_clip_shaped(&mut self, rect: Rect, corners: Corners, shape: Rect) {
        let (rect, corners, shape) = match self.tf() {
            Some(t) => (
                t.apply_rect(rect),
                t.apply_corners(corners),
                t.apply_rect(shape),
            ),
            None => (rect, corners, shape),
        };
        let index = self.clips.len() as u32;
        self.clips.push(ClipEntry { rect, corners, shape });
        self.ops.push(Op::PushClip(index));
    }

    pub fn pop_clip(&mut self) {
        self.ops.push(Op::PopClip);
    }

    /// Push a layer that is rebuilt every frame; returns its index in `layers`.
    /// 压入每帧重建的层；返回它在 `layers` 中的下标。
    pub fn push_layer(
        &mut self,
        bounds: Rect,
        effects: Vec<crate::effect::Effect>,
        radius: Corners,
    ) -> u32 {
        self.push_layer_inner(bounds, effects, radius, None)
    }

    /// Push a layer whose target is cached across frames under `key`; returns its index.
    /// 压入以 `key` 跨帧缓存目标的层；返回它的下标。
    pub fn push_cached_layer(
        &mut self,
        key: u64,
        bounds: Rect,
        effects: Vec<crate::effect::Effect>,
        radius: Corners,
    ) -> u32 {
        self.push_layer_inner(bounds, effects, radius, Some(key))
    }

    fn push_layer_inner(
        &mut self,
        bounds: Rect,
        effects: Vec<crate::effect::Effect>,
        radius: Corners,
        cache_key: Option<u64>,
    ) -> u32 {
        // A scaled subtree's layer covers its scaled pixels, so its target scales too.
        // 被缩放的子树，其层覆盖的是缩放后的像素，因此目标范围一并缩放。
        let (bounds, radius) = match self.tf() {
            Some(t) => (t.apply_rect(bounds), t.apply_corners(radius)),
            None => (bounds, radius),
        };
        let index = self.layers.len() as u32;
        self.layers.push(LayerEntry {
            bounds,
            effects,
            radius,
            cache_key,
        });
        self.ops.push(Op::PushLayer(index));
        index
    }

    pub fn pop_layer(&mut self) {
        self.ops.push(Op::PopLayer);
    }

    pub fn push_backdrop(&mut self, mut entry: BackdropEntry) {
        if let Some(t) = self.tf() {
            entry.rect = t.apply_rect(entry.rect);
            entry.clip = t.apply_rect(entry.clip);
            entry.corners = t.apply_corners(entry.corners);
            entry.sigma *= t.scale;
        }
        let index = self.backdrops.len() as u32;
        self.backdrops.push(entry);
        self.ops.push(Op::Backdrop(index));
    }

    /// Backdrops in paint order, paired with the epoch after which each must run.
    /// 按绘制顺序列出背景模糊，并给出每个应在哪个世代之后执行。
    pub fn backdrop_order(&self) -> Vec<(u32, BackdropEntry)> {
        let mut out = Vec::new();
        let mut epoch = 0u32;
        for op in &self.ops {
            if let Op::Backdrop(i) = *op {
                epoch += 1;
                if let Some(e) = self.backdrops.get(i as usize) {
                    out.push((epoch, *e));
                }
            }
        }
        out
    }

    /// Rect a primitive occupies, for damage and culling.
    /// 图元占据的矩形，供脏区与裁剪使用。
    pub fn prim_bounds(&self, pr: PrimRef) -> Rect {
        match pr.kind {
            PrimKind::Rect => self
                .prims
                .rects
                .get(pr.index as usize)
                .map(|p| p.rect)
                .unwrap_or(Rect::ZERO),
            PrimKind::Glyph => self
                .prims
                .glyphs
                .get(pr.index as usize)
                .map(|p| p.rect)
                .unwrap_or(Rect::ZERO),
            PrimKind::Image => self
                .prims
                .images
                .get(pr.index as usize)
                .map(|p| p.rect)
                .unwrap_or(Rect::ZERO),
            PrimKind::Shadow => self
                .prims
                .shadows
                .get(pr.index as usize)
                .map(|p| p.painted())
                .unwrap_or(Rect::ZERO),
            PrimKind::Sector => self
                .prims
                .sectors
                .get(pr.index as usize)
                .map(|p| p.bounds)
                .unwrap_or(Rect::ZERO),
            PrimKind::Text => {
                let t = self.prims.texts.get(pr.index as usize);
                match t {
                    Some(t) => {
                        // Approximation: width unknown here, so report the origin and a
                        // generous box; text damage is refined by the owning node rect.
                        // 近似：此处不知宽度，用来源点加一个宽松盒；文字脏区由所属节点矩形细化。
                        let (text, _) = t.block.flatten();
                        let size = t
                            .block
                            .runs
                            .first()
                            .map_or(14.0, |r| r.style.size);
                        Rect::new(
                            t.origin.x,
                            t.origin.y,
                            (text.chars().count() as f32 * size * 0.6).max(1.0),
                            size * 1.3,
                        )
                    }
                    None => Rect::ZERO,
                }
            }
        }
    }

    /// Group the order log into batches usable by a backend.
    /// 把顺序日志归并成后端可用的批次。
    ///
    /// A batch breaks when the kind, clip, or layer changes. Layers switch the
    /// render target, so primitives across them must never merge; this is why the
    /// plan is not a plain k-way merge of the typed banks.
    /// 种类、裁剪或层变化即断批。层会切换渲染目标，跨层图元绝不能合并；
    /// 这也是为什么批次计划不是对类型数组的简单 k 路归并。
    pub fn plan_batches(&self) -> Vec<Batch> {
        let mut out: Vec<Batch> = Vec::new();
        let mut clip_stack: Vec<ClipEntry> = Vec::new();
        let mut layer_stack: Vec<u32> = Vec::new();
        // A backdrop reads and rewrites the target, so nothing may batch across it.
        // 背景模糊会读并改写目标，因此不能有任何批次跨越它。
        let mut backdrop_epoch = 0u32;

        for op in &self.ops {
            match *op {
                Op::PushClip(i) => {
                    if let Some(c) = self.clips.get(i as usize) {
                        clip_stack.push(*c);
                    }
                }
                Op::PopClip => {
                    clip_stack.pop();
                }
                Op::Backdrop(_) => backdrop_epoch += 1,
                Op::PushLayer(i) => layer_stack.push(i),
                Op::PopLayer => {
                    layer_stack.pop();
                }
                Op::Prim(pr) => {
                    // Rects intersect; the shape comes from the clip that still bounds the
                    // intersection, since a narrower square clip must not inherit outer curves.
                    // 矩形求交；形状取自仍界定交集的那层裁剪，更窄的方角裁剪不得继承外层圆角。
                    let clip = clip_stack.split_first().map(|(first, rest)| {
                        let rect = rest
                            .iter()
                            .fold(first.rect, |acc, c| acc.intersection(c.rect).unwrap_or(Rect::ZERO));
                        let shaped = clip_stack.iter().rev().find(|c| same_rect(c.rect, rect));
                        let corners = shaped.map(|c| c.corners).unwrap_or(Corners::ZERO);
                        let shape = shaped.map(|c| c.shape).unwrap_or(rect);
                        ClipEntry { rect, corners, shape }
                    });
                    let layers = &layer_stack;
                    // Bounds are what the renderer culls by: narrower than the paint would
                    // drop that paint from every frame whose band misses the rest.
                    // 边界是渲染器裁剪的依据：比实际绘制窄，就会把它从重绘带不覆盖的帧里丢掉。
                    let bounds = self.prim_bounds(pr);
                    match out.last_mut() {
                        Some(last)
                            if last.kind == pr.kind
                                && last.clip == clip
                                && last.layers == *layers
                                && last.epoch == backdrop_epoch =>
                        {
                            last.range.end += 1;
                            last.bounds = Some(last.bounds.map_or(bounds, |u| u.union(bounds)));
                        }
                        _ => out.push(Batch {
                            kind: pr.kind,
                            range: pr.index..pr.index + 1,
                            clip,
                            layers: layers.clone(),
                            epoch: backdrop_epoch,
                            bounds: Some(bounds),
                        }),
                    }
                }
            }
        }
        out
    }
}

/// Area a node affects, including ink margin.
/// 节点影响的区域，含绘制外扩。
pub fn node_ink_rect(rect: Rect, ink: Insets) -> Rect {
    ink.expand(rect)
}

/// True when `rect` is the one that shaped `clip`: equal within rounding noise.
/// 当 `rect` 就是塑造了 `clip` 的那一个时返回 true：在取整噪声内相等。
fn same_rect(rect: Rect, clip: Rect) -> bool {
    const EPS: f32 = 0.01;
    (rect.origin.x - clip.origin.x).abs() < EPS
        && (rect.origin.y - clip.origin.y).abs() < EPS
        && (rect.size.w - clip.size.w).abs() < EPS
        && (rect.size.h - clip.size.h).abs() < EPS
}

/// Convenience for tests and examples.
/// 供测试与示例使用。
pub fn prim_ref(kind: PrimKind, index: u32) -> PrimRef {
    PrimRef { kind, index }
}

/// Owner of the primitive with this id, if any (debug helper).
/// 该 id 对应的图元归属（调试辅助）。
pub fn owner_of(list: &DrawList, id: Id) -> Option<NodeId> {
    let _ = (list, id);
    None
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::id::NodeId;

    fn nid(i: u32) -> NodeId {
        NodeId {
            index: i,
            generation: 0,
        }
    }

    #[test]
    fn a_laid_out_offset_reaches_the_draw_list() {
        // `rect` is the un-offset layout box; only `visual_rect` carries the offset. A
        // builder that reads `rect` pins every offset child to its parent's origin, which
        // is how a switch thumb ended up stuck at the start of its track.
        // `rect` 是未加偏移的布局盒，只有 `visual_rect` 带偏移。读 `rect` 的构建器会把每个
        // 带偏移的子节点钉在父原点上——滑块因此一直卡在轨道开头。
        use crate::layout::LayoutEngine as _;
        let mut tree = crate::tree::Tree::new();
        tree.apply(
            &crate::Decl::container(crate::Id::str("track"), crate::NodeKind::Box)
                .size(crate::layout::SizeClass::fixed(52.0, 32.0))
                .background(crate::geom::Color::WHITE, crate::geom::Corners::ZERO)
                .child(
                    crate::Decl::container(crate::Id::str("thumb"), crate::NodeKind::Box)
                        .size(crate::layout::SizeClass::fixed(16.0, 16.0))
                        .offset(8.0, 8.0)
                        .background(crate::geom::Color::WHITE, crate::geom::Corners::ZERO),
                ),
        );
        let root = tree.root().expect("root");
        crate::BuiltinLayout::new(crate::MonospaceMeasure::default()).solve(
            &mut tree,
            root,
            crate::Constraints::loose(crate::geom::Size::new(200.0, 200.0)),
        );
        let list = list_from_tree(&tree, Rect::new(0.0, 0.0, 200.0, 200.0));
        // The thumb is the only 16x16 primitive; the track is 52x32.
        // 滑块是唯一的 16x16 图元；轨道是 52x32。
        let thumb = list
            .prims
            .rects
            .iter()
            .find(|p| p.rect.size.w == 16.0)
            .expect("thumb primitive");
        assert_eq!(thumb.rect.origin.x, 8.0, "offset must be applied horizontally");
        assert_eq!(thumb.rect.origin.y, 8.0, "offset must be applied vertically");
    }

    fn rect_prim(w: f32) -> RectPrim {
        RectPrim {
            rect: Rect::new(0.0, 0.0, w, w),
            radius: Corners::ZERO,
            fill: Color::WHITE,
            gradient: None,
            border: None,
            border_gradient: None,
            notch: None,
        }
    }

    #[test]
    fn a_transform_scales_about_its_origin_and_composes_inside_out() {
        // The origin is the fixed point; composing two scales must equal applying them in
        // turn, or a nested scaled subtree would drift towards the wrong centre.
        // 原点是不动点；两次缩放的复合必须等于依次施加，否则嵌套缩放会朝错的中心漂移。
        let t = Transform::about(crate::geom::Point::new(20.0, 20.0), 0.5);
        let r = t.apply_rect(Rect::new(10.0, 10.0, 20.0, 20.0));
        assert_eq!(r, Rect::new(15.0, 15.0, 10.0, 10.0));
        assert_eq!(t.apply_corners(Corners::all(8.0)).tl, 4.0);
        assert_eq!(t.apply_point(crate::geom::Point::new(20.0, 20.0)), crate::geom::Point::new(20.0, 20.0));

        let outer = Transform::about(crate::geom::Point::ZERO, 2.0);
        let composed = outer.then(t);
        let p = crate::geom::Point::new(3.0, 7.0);
        assert_eq!(composed.apply_point(p), outer.apply_point(t.apply_point(p)));
        // Two scales about different centres are not the identity when their factors cancel:
        // they leave a translation behind, which is why the offset is part of the type.
        // 绕不同中心的两个缩放即使在系数上抵消也不是恒等：它们留下平移，偏移因此是类型的一部分。
        assert_eq!(composed.scale, 1.0);
        assert_ne!(composed.offset, crate::geom::Point::ZERO);
    }

    #[test]
    fn a_draw_list_scales_every_primitive_it_pushes() {
        // Corners, stroke widths and clip boxes are separate fields; a scale that only
        // moves rects leaves a scaled box with unscaled corners.
        // 圆角、描边宽度与裁剪盒是各自独立的字段；只移动矩形的缩放会留下未缩放的圆角。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        list.transform = Some(Transform::about(crate::geom::Point::new(50.0, 50.0), 0.5));
        let mut prim = rect_prim(20.0);
        prim.rect = Rect::new(40.0, 40.0, 20.0, 20.0);
        prim.radius = Corners::all(8.0);
        prim.border = Some((Color::WHITE, 2.0));
        list.push_rect(nid(0), prim);
        list.push_glyph(
            nid(1),
            GlyphPrim {
                rect: Rect::new(40.0, 40.0, 10.0, 10.0),
                atlas: Rect::new(0.0, 0.0, 10.0, 10.0),
                alpha: 1.0,
                color: Color::WHITE,
                kind: GlyphKind::Coverage,
            },
        );
        list.push_clip(Rect::new(40.0, 40.0, 20.0, 20.0), Corners::all(4.0));

        let rect = list.prims.rects[0];
        assert_eq!(rect.rect, Rect::new(45.0, 45.0, 10.0, 10.0));
        assert_eq!(rect.radius.tl, 4.0);
        assert_eq!(rect.border.map(|(_, w)| w), Some(1.0));
        assert_eq!(list.prims.glyphs[0].rect, Rect::new(45.0, 45.0, 5.0, 5.0));
        assert_eq!(list.clips[0].rect, Rect::new(45.0, 45.0, 10.0, 10.0));
        assert_eq!(list.clips[0].corners.tl, 2.0);
    }

    #[test]
    fn consecutive_same_kind_primitives_form_one_batch() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        list.push_rect(nid(0), rect_prim(10.0));
        list.push_rect(nid(1), rect_prim(10.0));
        list.push_rect(nid(2), rect_prim(10.0));

        let batches = list.plan_batches();
        assert_eq!(batches.len(), 1);
        assert_eq!(batches[0].range, 0..3);
    }

    #[test]
    fn a_batch_bounds_cover_the_whole_paint_of_every_primitive() {
        // The renderer skips a batch whose bounds miss the redraw band. Bounds narrower
        // than the paint drop it from every frame that band leaves alone — silently.
        // 渲染器会跳过边界不与重绘带相交的批次。边界比实际绘制窄，
        // 就会在重绘带没覆盖到的帧里悄悄丢掉那部分像素。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 200.0, 200.0));
        let at = |x: f32, y: f32| RectPrim {
            rect: Rect::new(x, y, 20.0, 20.0),
            ..rect_prim(20.0)
        };
        list.push_rect(nid(0), at(10.0, 10.0));
        list.push_rect(nid(1), at(150.0, 150.0));
        let shadow = ShadowPrim {
            rect: Rect::new(60.0, 60.0, 20.0, 20.0),
            corners: Corners::ZERO,
            colour: Color::WHITE,
            blur: 8.0,
            dy: 0.0,
            ring: 0.0,
        };
        list.push_shadow(nid(2), shadow);

        let batches = list.plan_batches();

        assert_eq!(batches.len(), 2, "a kind change splits the run");
        assert_eq!(
            batches[0].bounds,
            Some(Rect::new(10.0, 10.0, 160.0, 160.0)),
            "the union must span both rects"
        );
        assert_eq!(
            batches[1].bounds,
            Some(shadow.painted()),
            "a shadow's falloff paints outside its own rect"
        );
    }

    #[test]
    fn clear_empties_every_side_table_not_just_the_ops() {
        // A table that outlives its ops accumulates stale entries; indices then point at
        // the wrong entry or the table grows without bound.
        // 与 op 不同步的表会累积陈旧条目；下标随即指错，或表无限增长。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        list.push_rect(nid(0), rect_prim(10.0));
        list.push_clip(Rect::new(0.0, 0.0, 50.0, 50.0), Corners::ZERO);
        list.push_layer(
            Rect::new(0.0, 0.0, 50.0, 50.0),
            Vec::new(),
            Corners::ZERO,
        );
        list.push_backdrop(BackdropEntry {
            rect: Rect::new(0.0, 0.0, 50.0, 50.0),
            clip: Rect::new(0.0, 0.0, 50.0, 50.0),
            corners: Corners::ZERO,
            radius: 6,
            sigma: 2.0,
            material: BackdropMaterial::PLAIN,
        });

        list.clear();

        assert!(list.ops.is_empty());
        assert!(list.clips.is_empty(), "clips must be cleared with the ops");
        assert!(list.layers.is_empty(), "layers must be cleared with the ops");
        assert!(
            list.backdrops.is_empty(),
            "backdrops must be cleared with the ops"
        );
    }

    #[test]
    fn a_backdrop_breaks_the_batch_so_nothing_paints_across_it() {
        // A backdrop rewrites the target in place; a batch spanning it would draw rects
        // that were meant to land after the blur, or blur pixels already drawn over.
        // 背景模糊会就地改写目标；跨越它的批次会把本该在模糊后画的矩形提前画上。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        list.push_rect(nid(0), rect_prim(10.0));
        list.push_backdrop(BackdropEntry {
            rect: Rect::new(0.0, 0.0, 50.0, 50.0),
            clip: Rect::new(0.0, 0.0, 50.0, 50.0),
            corners: Corners::ZERO,
            radius: 6,
            sigma: 2.0,
            material: BackdropMaterial::PLAIN,
        });
        list.push_rect(nid(1), rect_prim(10.0));

        let batches = list.plan_batches();
        assert_eq!(batches.len(), 2, "the two rects must not share a batch");
        assert!(batches[0].epoch < batches[1].epoch);
    }

    #[test]
    fn backdrop_order_reports_each_blur_at_its_own_epoch() {
        // The renderer interleaves by epoch, so the numbering must be strictly increasing.
        // 渲染器按世代交织，因此编号必须严格递增。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        let entry = BackdropEntry {
            rect: Rect::new(0.0, 0.0, 50.0, 50.0),
            clip: Rect::new(0.0, 0.0, 50.0, 50.0),
            corners: Corners::ZERO,
            radius: 6,
            sigma: 2.0,
            material: BackdropMaterial::PLAIN,
        };
        list.push_rect(nid(0), rect_prim(10.0));
        list.push_backdrop(entry);
        list.push_rect(nid(1), rect_prim(10.0));
        list.push_backdrop(entry);

        let order = list.backdrop_order();
        assert_eq!(order.len(), 2);
        assert_eq!(order[0].0, 1);
        assert_eq!(order[1].0, 2);
    }

    #[test]
    fn clip_change_breaks_the_batch() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        list.push_rect(nid(0), rect_prim(10.0));
        list.push_clip(Rect::new(0.0, 0.0, 50.0, 50.0), Corners::ZERO);
        list.push_rect(nid(1), rect_prim(10.0));
        list.pop_clip();
        list.push_rect(nid(2), rect_prim(10.0));

        let batches = list.plan_batches();
        assert_eq!(batches.len(), 3, "clip must split batches");
        assert_eq!(
            batches[1].clip.map(|c| c.rect),
            Some(Rect::new(0.0, 0.0, 50.0, 50.0))
        );
    }

    #[test]
    fn a_narrower_square_clip_drops_the_outer_rounded_shape() {
        // The curve belongs to the clip that still bounds the intersection; an outer rounded
        // panel must not round a child that clips itself square.
        // 曲线属于仍界定交集的那层裁剪；外层圆角面板不得给自身方角裁剪的子节点加圆角。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        let row = Rect::new(10.0, 10.0, 50.0, 20.0);
        list.push_clip(Rect::new(0.0, 0.0, 100.0, 100.0), Corners::all(12.0));
        list.push_clip(row, Corners::ZERO);
        list.push_rect(nid(0), rect_prim(10.0));
        list.pop_clip();
        list.pop_clip();

        let clip = list.plan_batches()[0].clip.expect("a clip is in force");
        assert_eq!(clip.rect, row);
        assert!(clip.corners.is_zero(), "the square row inherited the panel's corners");
    }

    #[test]
    fn the_tight_rounded_clip_keeps_its_corners() {
        // The other direction of the same rule: when the rounded clip is the one bounding the
        // intersection, its curve is the one the batch must draw with.
        // 同一条规则的另一面：当界定交集的是圆角裁剪时，批次必须按它的曲线绘制。
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        let panel = Rect::new(0.0, 0.0, 100.0, 100.0);
        list.push_clip(Rect::new(-20.0, -20.0, 300.0, 300.0), Corners::ZERO);
        list.push_clip(panel, Corners::all(12.0));
        list.push_rect(nid(0), rect_prim(10.0));
        list.pop_clip();
        list.pop_clip();

        let clip = list.plan_batches()[0].clip.expect("a clip is in force");
        assert_eq!(clip.rect, panel);
        assert_eq!(clip.corners, Corners::all(12.0));
    }

    #[test]
    fn layer_change_breaks_the_batch() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        list.push_rect(nid(0), rect_prim(10.0));
        list.push_layer(Rect::new(0.0, 0.0, 40.0, 40.0), vec![crate::effect::Effect::opacity(0.5)], Corners::ZERO);
        list.push_rect(nid(1), rect_prim(10.0));
        list.pop_layer();
        list.push_rect(nid(2), rect_prim(10.0));

        let batches = list.plan_batches();
        assert_eq!(batches.len(), 3, "layer must split batches");
        assert_eq!(batches[1].layers, vec![0]);
        assert!(batches[2].layers.is_empty());
    }

    #[test]
    fn kind_change_breaks_the_batch() {
        let mut list = DrawList::new(Rect::new(0.0, 0.0, 100.0, 100.0));
        list.push_rect(nid(0), rect_prim(10.0));
        list.push_text(
            nid(1),
            TextPrim {
                block: crate::text::TextBlock::plain(
                    "hi",
                    crate::text::TextStyle::new(12.0),
                ),
                origin: crate::geom::Point::new(0.0, 0.0),
                max_width: f32::INFINITY,
                layout: None,
                height: 0.0,
                ink: Color::WHITE,
                caret: None,
                selection: None,
                composing: None,
                zoom: None,
            },
        );

        let batches = list.plan_batches();
        assert_eq!(batches.len(), 2);
        assert_eq!(batches[0].kind, PrimKind::Rect);
        assert_eq!(batches[1].kind, PrimKind::Text);
    }

    #[test]
    fn owner_table_tracks_each_primitive() {
        let mut list = DrawList::new(Rect::ZERO);
        list.push_rect(nid(7), rect_prim(1.0));
        list.push_rect(nid(9), rect_prim(1.0));
        assert_eq!(list.owners.of(PrimKind::Rect, 0), Some(nid(7)));
        assert_eq!(list.owners.of(PrimKind::Rect, 1), Some(nid(9)));
    }
}
