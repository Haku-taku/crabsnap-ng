//! What a control reports upward, and the callback that receives it.
//! 控件向上报告的内容，以及接收它的回调。

use std::any::Any;

use crate::id::Id;

/// A semantic report from a control: only what every style can agree on.
/// 控件上报的语义结果：只包含所有风格都能一致同意的东西。
///
/// The closed variants are the common vocabulary and match in the compiler's eyes.
/// `Data` is the escape hatch for a control's own compound type; the framework never
/// looks inside it, so nothing generic may depend on what it holds.
/// 封闭变体是通用词汇，可在编译期 `match`。
/// `Data` 是控件自有复合类型的出口；框架从不看它内部，任何通用代码都不得依赖其内容。
#[derive(Debug)]
pub enum Change {
    /// A control settled on a new state; `None` is the indeterminate state a three-way
    /// checkbox reports. A two-way control only ever reports `Some`.
    /// 控件落定到新状态；`None` 是三态复选框上报的不确定态。两态控件只会报 `Some`。
    Toggled { on: Option<bool> },

    /// A continuous control settled on a new value, in its own units. `f64` because the
    /// units are the control's, not the screen's: percent, seconds and money all fit.
    /// 连续控件落定到新值，使用该控件自己的单位。用 `f64` 是因为单位归控件而非屏幕：
    /// 百分比、秒、货币都装得下。
    Value(f64),

    /// The whole text buffer after an edit; never a diff.
    /// 编辑后的完整文本缓冲；绝不是差量。
    Text(String),

    /// A member was chosen from a set; `None` means the selection was cleared.
    /// 从集合中选定一项；`None` 表示清空选择。
    Selected(Option<Id>),

    /// A popup asked to close: a press outside it, or Escape. The app owns `open`.
    /// 浮层请求关闭：外部按下或 Escape。开与关仍归应用。
    Dismissed,

    /// Activated without producing a value: a click, or Enter/Space on a focused node.
    /// The control decides which; the engine reports neither pointer nor key on its own.
    /// 激活但未产生值：一次点击，或聚焦节点上的 Enter/Space。
    /// 由控件决定是哪一种；引擎自身不上报指针或按键。
    Activated,

    /// A drag gesture began on the control, with no value yet.
    /// 控件上开始了一次拖拽手势，尚无值。
    ///
    /// Distinct from `Activated`: a press that turns into a drag is not a click, and a
    /// control that must not confuse the two needs to see them apart.
    /// 与 `Activated` 不同：变成拖拽的按下不是点击，必须区分二者的控件要能看出差别。
    DragStarted,

    /// A control was dragged by `delta` since the press. The press point itself is not
    /// here: a control that maps position to a value reads it from its own `WidgetState`.
    /// 控件被拖拽，`delta` 相对按下点。按下点本身不在此处：
    /// 用位置映射值的控件从自己的 `WidgetState` 读它。
    Moved { dx: f64, dy: f64 },

    /// A drag ended on `target`, the node under the pointer that accepts drops.
    /// 拖拽在 `target` 上结束，即指针下接受放置的节点。
    ///
    /// Placeholder: nothing declares `Sense::DROP` yet, so `target` is always `None` and
    /// this only says "the gesture ended". Real drop targets fill it in later.
    /// 占位：目前无人声明 `Sense::DROP`，因此 `target` 恒为 `None`，本条只表示「手势结束」。
    /// 真正的放置目标以后再来填它。
    Dropped(Option<Id>),

    /// The interaction that would have reported a change was abandoned.
    /// 本应报告变化的交互被中止。
    Cancelled,

    /// A registered shortcut fired on this node, named by its stable id.
    /// 注册在该节点上的快捷键被触发，以其稳定 id 命名。
    ///
    /// The node is the one that registered the binding, so a control can tell its own
    /// shortcut from a global one bound to the same chord.
    /// 节点就是注册该绑定的那个，因此控件能把自己的快捷键与绑到同一组合的全局快捷键区分开。
    Shortcut(crate::shortcut::ShortcutId),

    /// A node that captures keys reported the chord the user pressed.
    /// 捕获按键的节点上报用户按下的组合键。
    ///
    /// Only a node subscribing to [`crate::Sense::CAPTURE_KEYS`] ever sees this.
    /// 只有订阅了 [`crate::Sense::CAPTURE_KEYS`] 的节点才会收到它。
    KeyChord(crate::shortcut::KeyChord),

    /// A row of this node's context menu was chosen, named by the row's stable id.
    /// 本节点上下文菜单中的一行被选中，以该行的稳定 id 命名。
    MenuItem(Id),

    /// A control asked the keyboard focus to move to `target`.
    /// 控件请求把键盘焦点移到 `target`。
    ///
    /// The engine applies it and does not forward it, like `ScrollBy`: focus belongs to the
    /// engine, and a menu walking its rows must not teach the app its own indices.
    /// 引擎自行执行、不转发，与 `ScrollBy` 相同：焦点归引擎所有，
    /// 逐行走动的菜单不该把自己的下标知识泄漏给应用。
    Focus(Id),

    /// A control asked a scroller to move by this much.
    /// 控件请求某个滚动容器移动这么多。
    ///
    /// `owner` names the scroller; `None` lets the nearest owning ancestor take the request,
    /// which is what an arrow *inside* the viewport wants and a sibling arrow does not.
    /// `owner` 指名滚动容器；`None` 则由最近的、确实滚这条轴的祖先接住——
    /// 视口内的箭头要的就是前者，而视口旁边的箭头不是。
    ///
    /// The engine applies it with the same clamping and easing as `Cx::scroll_to`; an app
    /// that wants its own offset calls that instead.
    /// 引擎按与 `Cx::scroll_to` 相同的钳位与缓动执行；要自定义偏移的应用改用它。
    ScrollBy {
        dx: f64,
        dy: f64,
        owner: Option<Id>,
    },

    /// A control's own type, carried opaquely; read it with [`Change::data`].
    /// 控件自己的类型，以不透明方式携带；用 [`Change::data`] 取回。
    Data(Box<dyn Any + Send>),
}

impl Change {
    /// Recover a control's own type. A mismatched type comes back unchanged, not as a panic.
    /// 取回控件自己的类型。类型不符时原样返回，而不是 panic。
    pub fn data<T: 'static>(self) -> Result<T, Change> {
        match self {
            Change::Data(b) => match b.downcast::<T>() {
                Ok(v) => Ok(*v),
                Err(b) => Err(Change::Data(b)),
            },
            other => Err(other),
        }
    }

}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_control_type_comes_back_or_the_change_is_returned_unchanged() {
        // Neither wrong-type nor wrong-variant may panic or silently vanish.
        // 类型不符与变体不符都不得 panic，也不得静默消失。
        let change = Change::Data(Box::new(7u32));
        assert_eq!(change.data::<u32>().ok(), Some(7u32));

        let wrong_type = Change::Data(Box::new(7u32));
        assert!(matches!(wrong_type.data::<String>(), Err(Change::Data(_))));

        let wrong_variant = Change::Activated;
        assert!(matches!(
            wrong_variant.data::<u32>(),
            Err(Change::Activated)
        ));
    }

}
