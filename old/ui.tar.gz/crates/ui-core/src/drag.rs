//! Drag: a press that turns into a movement, and the four things it can become.
//! 拖拽：一次按下转为移动，以及它可能变成的四件事。

use crate::geom::Point;
use crate::id::Id;

/// Distance in logical units a press must travel before it becomes a drag.
/// 按下后要移动多少逻辑单位才算拖拽。
///
/// Small enough to feel immediate, large enough that a shaky click stays a click.
/// 小到感觉即时，大到手抖的点击仍算点击。
pub const DRAG_THRESHOLD: f32 = 4.0;

/// Whether a move from `from` to `to` is far enough to count as a drag.
/// 从 `from` 到 `to` 的移动是否远到足以算作拖拽。
///
/// One predicate for both "starts a drag" and "is no longer a click", so no press can fall
/// between the two. The metric is the larger axis, not the diagonal: a straight line of
/// `DRAG_THRESHOLD` on either axis is already a drag.
/// 同一个判据同时用于「开始拖拽」与「不再是点击」，按下不会落在两者之间。度量取较大的一轴
/// 而非对角线：沿任一轴走满 `DRAG_THRESHOLD` 即为拖拽。
pub fn past_threshold(from: Point, to: Point) -> bool {
    (to.x - from.x).abs().max((to.y - from.y).abs()) >= DRAG_THRESHOLD
}

/// Where a drag currently is.
/// 拖拽当前处于哪一步。
#[derive(Clone, Copy, Debug, PartialEq)]
#[derive(Default)]
pub enum DragState {
    /// Nothing pressed.
    /// 没有按下。
    #[default]
    Idle,
    /// Pressed on `on` at `at`, but not yet past the threshold.
    /// 在 `at` 按下 `on`，但还没超过阈值。
    Pressed { on: Id, at: Point },
    /// Moving; `on` keeps receiving moves even outside its own rect.
    /// 移动中；`on` 即使移出自身矩形也继续收到移动事件。
    Dragging { on: Id, from: Point, current: Point },
}


impl DragState {
    /// The node that owns this drag, if any.
    /// 拥有本次拖拽的节点（若有）。
    pub fn owner(&self) -> Option<Id> {
        match self {
            DragState::Idle => None,
            DragState::Pressed { on, .. } | DragState::Dragging { on, .. } => Some(*on),
        }
    }

    /// Whether the pointer is captured: moves keep going to the owner regardless of
    /// where the pointer is.
    /// 指针是否被捕获：无论指针在哪，移动都继续送给所有者。
    pub fn captures_pointer(&self) -> bool {
        matches!(self, DragState::Dragging { .. })
    }

    /// Total displacement from the press point.
    /// 相对按下点的总位移。
    pub fn delta(&self) -> Point {
        match self {
            DragState::Idle | DragState::Pressed { .. } => Point::new(0.0, 0.0),
            DragState::Dragging { from, current, .. } => {
                Point::new(current.x - from.x, current.y - from.y)
            }
        }
    }
}

/// What the framework tells the app about a drag.
/// 框架告诉 app 的拖拽进展。
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum DragEvent {
    /// The press passed the threshold; the drag is live.
    /// 按下已越过阈值；拖拽开始生效。
    ///
    /// `local` is the press point in the dragged node's own space. The tracker has no tree,
    /// so it fills it with the surface point and the platform rewrites it.
    /// `local` 是按下点在被拖节点自身空间中的位置。跟踪器没有树，先填表面坐标，
    /// 由平台层改写成节点本地坐标。
    Started { on: Id, from: Point, local: Point },
    /// The pointer moved; `delta` is from the press point, `step` is since the previous
    /// event, `local` is the current pointer.
    /// 指针移动；`delta` 相对按下点，`step` 相对上一次事件，`local` 是当前指针位置。
    Moved {
        on: Id,
        delta: Point,
        step: Point,
        local: Point,
    },
    /// Released over `target` (or over nothing).
    /// 在 `target` 上松开（或松开时不在任何目标上）。
    Dropped { on: Id, target: Option<Id> },
    /// Cancelled by `Escape`; the app should restore its starting state.
    /// 被 `Escape` 取消；app 应恢复到起始状态。
    Cancelled { on: Id },
}

/// The drag state machine, fed one pointer event at a time.
/// 拖拽状态机，每次喂一个指针事件。
#[derive(Clone, Debug, Default)]
pub struct DragTracker {
    state: DragState,
}

impl DragTracker {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn state(&self) -> DragState {
        self.state
    }

    pub fn is_dragging(&self) -> bool {
        matches!(self.state, DragState::Dragging { .. })
    }

    /// A button went down on `on`.
    /// 在 `on` 上按下按钮。
    pub fn press(&mut self, on: Id, at: Point) {
        self.state = DragState::Pressed { on, at };
    }

    /// The pointer moved to `to`; returns `Started` exactly once per drag.
    /// 指针移动到 `to`；每次拖拽恰好返回一次 `Started`。
    pub fn moved(&mut self, to: Point) -> Option<DragEvent> {
        match self.state {
            DragState::Idle => None,
            DragState::Pressed { on, at } => {
                if !past_threshold(at, to) {
                    return None;
                }
                self.state = DragState::Dragging {
                    on,
                    from: at,
                    current: to,
                };
                Some(DragEvent::Started {
                    on,
                    from: at,
                    local: at,
                })
            }
            DragState::Dragging { on, from, current } => {
                self.state = DragState::Dragging {
                    on,
                    from,
                    current: to,
                };
                Some(DragEvent::Moved {
                    on,
                    delta: Point::new(to.x - from.x, to.y - from.y),
                    step: Point::new(to.x - current.x, to.y - current.y),
                    local: to,
                })
            }
        }
    }

    /// The button came up; `target` is what is under the pointer.
    /// 按钮松开；`target` 是指针下的东西。
    ///
    /// A press that never passed the threshold produces nothing: it was a click, and
    /// the click path already handled it.
    /// 未越过阈值的按下不产生任何事件：那是一次点击，点击路径已经处理过了。
    pub fn release(&mut self, target: Option<Id>) -> Option<DragEvent> {
        let state = std::mem::take(&mut self.state);
        match state {
            DragState::Idle | DragState::Pressed { .. } => None,
            DragState::Dragging { on, .. } => Some(DragEvent::Dropped { on, target }),
        }
    }

    /// `Escape` while dragging; restores `Idle` and reports the cancellation.
    /// 拖拽中按下 `Escape`；恢复 `Idle` 并报告取消。
    pub fn cancel(&mut self) -> Option<DragEvent> {
        let state = std::mem::take(&mut self.state);
        match state {
            DragState::Idle | DragState::Pressed { .. } => None,
            DragState::Dragging { on, .. } => Some(DragEvent::Cancelled { on }),
        }
    }

    /// Forget the current drag without reporting anything, e.g. on pointer leave.
    /// 静默丢弃当前拖拽，例如指针离开时。
    pub fn reset(&mut self) {
        self.state = DragState::Idle;
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn id(n: u64) -> Id {
        Id::from_u64(n)
    }

    #[test]
    fn a_shaky_click_never_becomes_a_drag() {
        // Below the threshold the press is a click; emitting `Started` would make every
        // click also drag whatever it hit.
        // 低于阈值时按下就是点击；发出 `Started` 会让每次点击都顺带拖动它命中的东西。
        let mut t = DragTracker::new();
        t.press(id(1), Point::new(10.0, 10.0));
        assert_eq!(t.moved(Point::new(12.0, 11.0)), None);
        assert_eq!(t.release(Some(id(1))), None);
        assert!(!t.is_dragging());
    }

    #[test]
    fn passing_the_threshold_starts_the_drag_exactly_once() {
        // A second `Started` would make the app record its "from" state twice and lose
        // the original position.
        // 第二个 `Started` 会让 app 记录两次起始状态，丢掉原始位置。
        let mut t = DragTracker::new();
        t.press(id(1), Point::new(10.0, 10.0));
        assert_eq!(
            t.moved(Point::new(20.0, 10.0)),
            Some(DragEvent::Started {
                on: id(1),
                from: Point::new(10.0, 10.0),
                local: Point::new(10.0, 10.0),
            })
        );
        assert_eq!(
            t.moved(Point::new(30.0, 10.0)),
            Some(DragEvent::Moved {
                on: id(1),
                delta: Point::new(20.0, 0.0),
                // The threshold move is already accounted for by `Started`.
                // 越过阈值的这一下已由 `Started` 记下。
                step: Point::new(10.0, 0.0),
                local: Point::new(30.0, 10.0),
            })
        );
    }

    #[test]
    fn the_step_is_the_movement_since_the_previous_event() {
        // `primaryDelta` in the reference: what a control accumulates, event by event.
        // 参考里的 `primaryDelta`：控件逐事件累加的就是它。
        let mut t = DragTracker::new();
        t.press(id(1), Point::new(100.0, 100.0));
        t.moved(Point::new(110.0, 100.0));
        let Some(DragEvent::Moved { step, .. }) = t.moved(Point::new(118.0, 100.0)) else {
            panic!("expected a move");
        };
        assert_eq!(step, Point::new(8.0, 0.0), "step must be from the last event");
        let Some(DragEvent::Moved { step, delta, .. }) = t.moved(Point::new(125.0, 100.0))
        else {
            panic!("expected a move");
        };
        assert_eq!(step, Point::new(7.0, 0.0));
        assert_eq!(delta, Point::new(25.0, 0.0), "delta stays from the press");
    }

    #[test]
    fn the_delta_is_measured_from_the_press_not_the_last_move() {
        // Measuring from the last move would make the app accumulate drift.
        // 从上次移动量起会让 app 累积漂移。
        let mut t = DragTracker::new();
        t.press(id(1), Point::new(100.0, 100.0));
        t.moved(Point::new(110.0, 100.0));
        t.moved(Point::new(130.0, 100.0));
        assert_eq!(
            t.state().delta(),
            Point::new(30.0, 0.0),
            "delta must be from the press point"
        );
    }

    #[test]
    fn a_drag_captures_the_pointer() {
        // Once dragging, moves must keep reaching the owner even when the pointer has
        // left its rect; otherwise a drag that leaves the widget silently dies.
        // 一旦开始拖拽，即使指针离开矩形，移动也必须继续送达所有者；
        // 否则拖出控件后拖拽会静默失效。
        let mut t = DragTracker::new();
        assert!(!t.state().captures_pointer(), "a bare press captures nothing");
        t.press(id(1), Point::new(10.0, 10.0));
        assert!(!t.state().captures_pointer(), "a press is not yet a drag");
        t.moved(Point::new(50.0, 50.0));
        assert!(t.state().captures_pointer());
        assert_eq!(t.state().owner(), Some(id(1)));
    }

    #[test]
    fn escape_cancels_without_dropping() {
        // A cancelled drag must not also report a drop: the app would apply the move it
        // was told to abandon.
        // 被取消的拖拽不得同时报告放下：否则 app 会应用它刚被告知放弃的移动。
        let mut t = DragTracker::new();
        t.press(id(1), Point::new(10.0, 10.0));
        t.moved(Point::new(50.0, 50.0));
        assert_eq!(
            t.cancel(),
            Some(DragEvent::Cancelled { on: id(1) })
        );
        assert_eq!(t.release(Some(id(2))), None, "cancel already ended it");
        assert_eq!(t.state(), DragState::Idle);
    }

    #[test]
    fn a_drop_reports_whatever_is_under_the_pointer() {
        let mut t = DragTracker::new();
        t.press(id(1), Point::new(10.0, 10.0));
        t.moved(Point::new(50.0, 50.0));
        assert_eq!(
            t.release(Some(id(9))),
            Some(DragEvent::Dropped {
                on: id(1),
                target: Some(id(9))
            })
        );
        assert_eq!(t.state(), DragState::Idle);
    }

    #[test]
    fn a_drop_over_nothing_reports_no_target() {
        // Dropping into empty space is a valid outcome, not an error.
        // 丢到空白处是合法结果，不是错误。
        let mut t = DragTracker::new();
        t.press(id(1), Point::new(10.0, 10.0));
        t.moved(Point::new(50.0, 50.0));
        assert_eq!(
            t.release(None),
            Some(DragEvent::Dropped {
                on: id(1),
                target: None
            })
        );
    }

    #[test]
    fn a_press_that_is_reset_reports_nothing() {
        let mut t = DragTracker::new();
        t.press(id(1), Point::new(10.0, 10.0));
        t.moved(Point::new(50.0, 50.0));
        t.reset();
        assert_eq!(t.state(), DragState::Idle);
        assert_eq!(t.release(Some(id(1))), None);
    }

    #[test]
    fn movement_without_a_press_is_ignored() {
        // The pointer moves constantly; only a pressed button may start a drag.
        // 指针一直在移动；只有按下按钮才可能开始拖拽。
        let mut t = DragTracker::new();
        assert_eq!(t.moved(Point::new(500.0, 500.0)), None);
        assert_eq!(t.state(), DragState::Idle);
    }
}
