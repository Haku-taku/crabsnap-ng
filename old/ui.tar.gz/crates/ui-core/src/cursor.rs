//! Pointer shapes, named after the CSS keywords `wp_cursor_shape_v1` itself derives from.
//! 指针形状，按 `wp_cursor_shape_v1` 所本源的 CSS 关键字命名。

/// A named pointer shape.
/// 命名指针形状。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash)]
pub enum CursorShape {
    /// The ordinary pointer.
    /// 普通箭头。
    #[default]
    Arrow,
    /// Text may be selected or entered.
    /// 可选或可输入文本。
    Text,
    /// Precision work.
    /// 精确操作。
    Crosshair,
    /// An interactive element, e.g. a link.
    /// 可点元素，如链接。
    PointingHand,
    /// The hovered thing can be grabbed.
    /// 悬停物可被抓取。
    Grab,
    /// A grab is in progress.
    /// 正在抓取。
    Grabbing,
    /// Something may be moved.
    /// 可移动。
    Move,
    /// The action will not be carried out.
    /// 操作不会被执行。
    NotAllowed,
    /// A drop here copies.
    /// 在此放下会复制。
    Copy,
    /// A drop here creates a shortcut.
    /// 在此放下会创建快捷方式。
    Alias,
    /// The dragged item cannot be dropped here.
    /// 拖动物不能放在此处。
    NoDrop,
    /// Resize left/right.
    /// 左右缩放。
    ResizeHorizontal,
    /// Resize up/down.
    /// 上下缩放。
    ResizeVertical,
    /// Resize along `\`.
    /// 沿 `\` 缩放。
    ResizeDiagonalDownRight,
    /// Resize along `/`.
    /// 沿 `/` 缩放。
    ResizeDiagonalUpRight,
    /// A column may be resized.
    /// 列可缩放。
    ResizeColumn,
    /// A row may be resized.
    /// 行可缩放。
    ResizeRow,
    /// Pan in any direction.
    /// 任意方向平移。
    AllScroll,
    /// Zoom in.
    /// 放大。
    ZoomIn,
    /// Zoom out.
    /// 缩小。
    ZoomOut,
}
