//! Styled text: a paragraph is a list of runs, not one string with one style.
//! 带样式的文本：一个段落是 run 的列表，而不是一个字符串配一种样式。

use crate::geom::Size;

/// Requested font weight, CSS 1..=1000.
/// 请求的字重，CSS 1..=1000。
///
/// A continuous scale with named anchors: a provider matches the closest available face
/// rather than switching between two buckets, so 600 is meaningful on its own.
/// 连续刻度配命名锚点：提供者匹配最接近的可用字面，而不是在两个档位间切换，
/// 因此 600 自身有意义。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, PartialOrd, Ord)]
pub struct Weight(pub u16);

impl Weight {
    pub const THIN: Self = Self(100);
    pub const LIGHT: Self = Self(300);
    pub const REGULAR: Self = Self(400);
    pub const MEDIUM: Self = Self(500);
    pub const SEMIBOLD: Self = Self(600);
    pub const BOLD: Self = Self(700);
    pub const BLACK: Self = Self(900);
}

/// Visual style of one run.
/// 单个 run 的视觉样式。
///
/// Rich text (Markdown/HTML/XML) reduces to many runs sharing a small set of styles, so
/// this is the unit to grow: adding weight or underline happens here, not in new fields.
/// 富文本（Markdown/HTML/XML）最终归约为共享少量样式的多个 run，因此增长点在这里：
/// 加粗体或下划线改这里，而不是再加字段。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TextStyle {
    pub size: f32,
    /// Font weight; `REGULAR` for normal text.
    /// 字重；普通文本为 `REGULAR`。
    ///
    /// Weight picks the *face*, so it is not part of `Variations`: a run asking for 700
    /// must reach a Bold face, not just a heavier axis of Regular.
    /// 字重决定选哪个**字面**，因此不属于 `Variations`：请求 700 必须落到粗体字面，
    /// 而不只是常规字面的一个更重的轴值。
    pub weight: Weight,
    /// Italic (or oblique) face.
    /// 斜体（或仿斜）。
    pub italic: bool,
    /// Which family this run asks for.
    /// 本 run 请求的字体族。
    pub family: Family,
    /// Variable-font axes beyond weight; `NONE` keeps the face's defaults.
    /// 字重之外的可变字体轴；`NONE` 保持字面默认。
    pub variations: Variations,
    /// OpenType features; `NONE` keeps the shaper's defaults.
    /// OpenType 特性；`NONE` 保持整形器默认。
    pub features: Features,
}

impl TextStyle {
    pub const fn new(size: f32) -> Self {
        Self {
            size,
            weight: Weight::REGULAR,
            italic: false,
            family: Family::Generic(GenericFamily::SystemUi),
            variations: Variations::NONE,
            features: Features::NONE,
        }
    }

    /// Builder: this run asks for `w`.
    /// 构造器：本 run 请求 `w`。
    pub const fn weight(mut self, w: Weight) -> Self {
        self.weight = w;
        self
    }

    /// Builder: this run asks for an italic face.
    /// 构造器：本 run 请求斜体字面。
    pub const fn italic(mut self) -> Self {
        self.italic = true;
        self
    }

    /// Builder: this run asks for `family`, named or generic.
    /// 构造器：本 run 请求 `family`，具名或通用。
    pub const fn family(mut self, family: Family) -> Self {
        self.family = family;
        self
    }

    /// Builder: this run asks for a named family.
    /// 构造器：本 run 请求具名族。
    pub const fn named(mut self, family: &'static str) -> Self {
        self.family = Family::Named(family);
        self
    }

    /// Builder: this run asks for a generic family.
    /// 构造器：本 run 请求通用族。
    pub const fn generic(mut self, family: GenericFamily) -> Self {
        self.family = Family::Generic(family);
        self
    }

    /// Builder: variable-font axes for this run.
    /// 构造器：本 run 的可变字体轴。
    pub const fn variations(mut self, variations: Variations) -> Self {
        self.variations = variations;
        self
    }

    /// Builder: OpenType features for this run.
    /// 构造器：本 run 的 OpenType 特性。
    pub const fn features(mut self, features: Features) -> Self {
        self.features = features;
        self
    }
}

impl Default for TextStyle {
    fn default() -> Self {
        Self::new(14.0)
    }
}

/// A family a run can ask for: a name, or the platform's generic slot for a class.
/// run 可以请求的族：一个具名族，或平台对该类别的通用槽位。
///
/// `&'static str` keeps `TextStyle` copyable and the cache key cheap; families are
/// compile-time constants, never user data. Mainline engines carry the same pair —
/// Flutter `fontFamily` / `fontFamilyFallback`, GPUI `font_family`, egui `FontFamily`.
/// `&'static str` 让 `TextStyle` 可 Copy、缓存键廉价；族是编译期常量，绝不是用户数据。
/// 主流引擎携带的是同一对概念——Flutter 的 `fontFamily`、GPUI 的 `font_family`、
/// egui 的 `FontFamily`。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum Family {
    /// The platform's own choice for a class of text.
    /// 平台对某一类文本自己的选择。
    Generic(GenericFamily),
    /// A named family, resolved by the provider (system or registered).
    /// 具名族，由提供者解析（系统字体或已注册字体）。
    Named(&'static str),
}

impl Default for Family {
    fn default() -> Self {
        Self::Generic(GenericFamily::SystemUi)
    }
}

impl Family {
    /// Whether this family draws symbols rather than text.
    /// 该族画的是符号而不是文字。
    ///
    /// A symbol's ink *is* its glyph: one em-sized mark that fills the box, so it is
    /// centred by its ink. Text is centred by its line box, because its ink (cap height
    /// above the baseline) sits high inside it.
    /// 符号的墨就是它的字形：一个填满盒子的 em 标记，因此按墨居中。文字按行盒居中，
    /// 因为它的墨（基线上的大写高）在行盒里偏上。
    pub fn is_symbol(self) -> bool {
        match self {
            Family::Named(name) => {
                name.starts_with("Material Symbols") || name == "SFSymbols"
            }
            Family::Generic(_) => false,
        }
    }
}

/// Which generic family a request maps to.
/// 请求映射到哪个通用族。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash)]
pub enum GenericFamily {
    #[default]
    SansSerif,
    Serif,
    Monospace,
    /// The platform's own widget font.
    /// 平台自己的控件字体。
    SystemUi,
}

/// Variable-font axes for one run, excluding weight (that picks the face).
/// 单个 run 的可变字体轴，不含字重（字重决定字面）。
///
/// The four axes Material Symbols exposes are `wght` (in `TextStyle::weight`), `opsz`,
/// `FILL` and `GRAD`; a style that leaves them unset gets the face's defaults.
/// Material Symbols 暴露四个轴：`wght`（在 `TextStyle::weight` 里）、`opsz`、`FILL`、`GRAD`；
/// 不设的轴取字面默认值。
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Variations {
    /// `opsz`: optical size; `None` follows the font size.
    /// `opsz`：光学尺寸；`None` 跟随字号。
    pub optical_size: Option<f32>,
    /// `FILL`: 0 outlined, 1 filled.
    /// `FILL`：0 空心，1 实心。
    pub fill: Option<f32>,
    /// `GRAD`: emphasis, typically -50..200.
    /// `GRAD`：强调程度，通常 -50..200。
    pub grade: Option<f32>,
}

impl Variations {
    pub const NONE: Self = Self {
        optical_size: None,
        fill: None,
        grade: None,
    };

    /// Builder: filled or outlined, as the `FILL` axis.
    /// 构造器：按 `FILL` 轴设定实心或空心。
    pub const fn fill(mut self, fill: f32) -> Self {
        self.fill = Some(fill);
        self
    }

    /// Builder: optical size, as the `opsz` axis.
    /// 构造器：按 `opsz` 轴设定光学尺寸。
    pub const fn optical_size(mut self, size: f32) -> Self {
        self.optical_size = Some(size);
        self
    }

    /// Builder: emphasis, as the `GRAD` axis.
    /// 构造器：按 `GRAD` 轴设定强调程度。
    pub const fn grade(mut self, grade: f32) -> Self {
        self.grade = Some(grade);
        self
    }

    /// The axes at 1/64 precision, the form caches key on.
    /// 轴值按 1/64 量化，作为缓存键的形式。
    ///
    /// Quantising is what keeps an animated `FILL` finite: 0..1 yields 65 instances, not one
    /// per frame.
    /// 量化让动画中的 `FILL` 有界：0..1 只有 65 个实例，而不是每帧一个。
    pub fn quantized(&self) -> [Option<i32>; 3] {
        [self.optical_size, self.fill, self.grade].map(|v| {
            v.filter(|v| v.is_finite())
                .map(|v| (v * 64.0).round() as i32)
        })
    }
}

/// At most `CAPACITY` OpenType feature switches for one run, as `(tag, value)` pairs.
/// 单个 run 至多 `CAPACITY` 个 OpenType 特性开关，形式为 `(tag, value)`。
///
/// Mainline engines carry a list here (Flutter `fontFeatures`, GPUI `FontFeatures`); a
/// fixed capacity keeps `TextStyle` copyable, which per-span styles depend on.
/// 主流引擎这里是列表（Flutter 的 `fontFeatures`、GPUI 的 `FontFeatures`）；
/// 固定容量让 `TextStyle` 保持可 Copy，而逐区间样式依赖这一点。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash)]
pub struct Features {
    settings: [Option<([u8; 4], u32)>; FEATURE_CAPACITY],
}

/// Feature switches one run can carry.
/// 单个 run 能携带的特性开关数。
pub const FEATURE_CAPACITY: usize = 4;

impl Features {
    pub const CAPACITY: usize = FEATURE_CAPACITY;
    /// The shaper's own defaults.
    /// 整形器自身的默认值。
    pub const NONE: Self = Self {
        settings: [None; FEATURE_CAPACITY],
    };
    /// `tnum`: digits take one advance, so columns line up.
    /// `tnum`：数字等宽，表格列因此对齐。
    pub const TABULAR: Self = Self::NONE.set(*b"tnum", 1);
    /// `calt`/`liga` off: no contextual or standard ligatures.
    /// 关闭 `calt`/`liga`：没有上下文连字或标准连字。
    pub const NO_LIGATURES: Self = Self::NONE.set(*b"calt", 0).set(*b"liga", 0);

    /// Builder: set `tag` to `value`; a full set ignores the extra setting.
    /// 构造器：把 `tag` 设为 `value`；已满时忽略多余的设置。
    pub const fn set(mut self, tag: [u8; 4], value: u32) -> Self {
        let mut i = 0;
        while i < Self::CAPACITY {
            match self.settings[i] {
                Some((t, _)) if same_tag(t, tag) => {
                    self.settings[i] = Some((tag, value));
                    return self;
                }
                None => {
                    self.settings[i] = Some((tag, value));
                    return self;
                }
                Some(_) => i += 1,
            }
        }
        self
    }

    /// The switches in effect, in the order they were set.
    /// 生效的开关，按设置顺序。
    pub fn iter(&self) -> impl Iterator<Item = ([u8; 4], u32)> + '_ {
        self.settings.iter().flatten().copied()
    }

    pub fn is_empty(&self) -> bool {
        self.settings.iter().all(Option::is_none)
    }
}

const fn same_tag(a: [u8; 4], b: [u8; 4]) -> bool {
    a[0] == b[0] && a[1] == b[1] && a[2] == b[2] && a[3] == b[3]
}

/// Object replacement character: the byte an atom occupies in the flattened text.
/// 对象替换字符：原子在拼接文本中占据的字节。
pub const OBJECT: char = '\u{FFFC}';

/// How an atom sits against its line's box; only atoms use this.
/// 原子相对所在行盒的纵向位置；只有原子使用。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum VerticalAlign {
    /// The atom's own baseline meets the line's text baseline.
    /// 原子自身的基线对齐行的文字基线。
    #[default]
    Baseline,
    /// The atom's top meets the line box's top.
    /// 原子顶边对齐行盒顶边。
    Top,
    /// Split the leftover space above and below.
    /// 上下各分一半剩余空间。
    Middle,
    /// The atom's bottom meets the line box's bottom.
    /// 原子底边对齐行盒底边。
    Bottom,
}

impl VerticalAlign {
    /// Space the atom claims above and below the baseline, as `(above, below)`.
    /// 原子在基线上下索要的空间，`(上, 下)`。
    pub fn extents(self, size: Size, baseline: f32) -> (f32, f32) {
        match self {
            Self::Baseline => (baseline, size.h - baseline),
            Self::Top => (0.0, size.h),
            Self::Middle => (size.h * 0.5, size.h * 0.5),
            Self::Bottom => (size.h, 0.0),
        }
    }

    /// Where the atom's top sits inside a line box of `height` whose baseline is `ascent` down.
    /// 原子顶边落在行盒内的位置；行盒高 `height`，基线在顶边下 `ascent`。
    pub fn top(self, size: Size, baseline: f32, ascent: f32, height: f32) -> f32 {
        let y = match self {
            Self::Baseline => ascent - baseline,
            Self::Top => 0.0,
            Self::Middle => (height - size.h) * 0.5,
            Self::Bottom => height - size.h,
        };
        y.max(0.0)
    }
}

/// An object embedded in a paragraph, occupying one U+FFFC at `at`.
/// 嵌在段落里的对象，在 `at` 处占据一个 U+FFFC。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct AtomBox {
    /// Byte offset of its U+FFFC in the flattened text.
    /// 它的 U+FFFC 在拼接文本中的字节偏移。
    pub at: usize,
    pub size: Size,
    /// Its own baseline, from its top; the default sits it on the text baseline.
    /// 自身基线，从顶边量起；默认让它坐在文字基线上。
    pub baseline: f32,
    pub align: VerticalAlign,
}

impl AtomBox {
    /// An atom of `size` sitting on the text baseline, like a replaced element in CSS.
    /// 与 CSS 替换元素一样坐在文字基线上的、尺寸为 `size` 的原子。
    pub fn new(at: usize, size: Size) -> Self {
        Self {
            at,
            size,
            baseline: size.h,
            align: VerticalAlign::Baseline,
        }
    }

    pub fn align(mut self, align: VerticalAlign) -> Self {
        self.align = align;
        self
    }

    pub fn baseline(mut self, baseline: f32) -> Self {
        self.baseline = baseline;
        self
    }
}

/// Horizontal placement of every line in a paragraph.
/// 段落中每一行的水平对齐方式。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum TextAlign {
    /// Leading edge: left in LTR, right in RTL.
    /// 起始边：LTR 为左，RTL 为右。
    #[default]
    Start,
    Center,
    End,
}

/// A contiguous piece of text sharing one style.
/// 共享一种样式的连续文本片段。
#[derive(Clone, Debug, PartialEq)]
pub struct TextRun {
    pub text: String,
    pub style: TextStyle,
}

impl TextRun {
    pub fn new(text: impl Into<String>, style: TextStyle) -> Self {
        Self {
            text: text.into(),
            style,
        }
    }
}

/// One paragraph: runs plus the properties that apply to the whole block.
/// 一个段落：run 列表，加上作用于整块的属性。
#[derive(Clone, Debug, Default, PartialEq)]
pub struct TextBlock {
    pub runs: Vec<TextRun>,
    pub align: TextAlign,
    /// Line cap; `None` wraps freely, `Some(n)` ellipsizes past `n` lines.
    /// 行数上限；`None` 自由换行，`Some(n)` 超过 `n` 行时加省略号。
    pub max_lines: Option<u32>,
    /// Extra space between lines, not after the last one.
    /// 行间额外空隙，最后一行之后不加。
    ///
    /// Separate from the font's own line gap: that one belongs to the face, this one to
    /// the paragraph, and a caller tuning density must not have to fake a font metric.
    /// 与字体自带的 line gap 分开：那个属于字面，这个属于段落；
    /// 想调整疏密的调用方不该去伪造字体度量。
    pub line_gap: f32,
    /// First-line indent; later lines start at the block's left edge.
    /// 首行缩进；后续行从块的左边缘开始。
    pub indent: f32,
    /// Objects embedded in the flow, each occupying a U+FFFC in `runs`.
    /// 嵌在流中的对象，各自占据 `runs` 里的一个 U+FFFC。
    pub atoms: Vec<AtomBox>,
}

impl TextBlock {
    /// A block of one run, the shape most callers want.
    /// 单 run 块，多数调用方需要的形态。
    pub fn plain(text: impl Into<String>, style: TextStyle) -> Self {
        Self {
            runs: vec![TextRun::new(text, style)],
            align: TextAlign::Start,
            max_lines: None,
            line_gap: 0.0,
            indent: 0.0,
            atoms: Vec::new(),
        }
    }

    pub fn is_empty(&self) -> bool {
        self.runs.iter().all(|r| r.text.is_empty())
    }

    /// The atom occupying `byte`, if one does.
    /// 占据 `byte` 的原子（若有）。
    pub fn atom_at(&self, byte: usize) -> Option<&AtomBox> {
        self.atoms.iter().find(|a| a.at == byte)
    }

    /// Builder: embed one more atom.
    /// 构造器：再嵌一个原子。
    pub fn atom(mut self, atom: AtomBox) -> Self {
        self.atoms.push(atom);
        self
    }

    /// Concatenated text plus the span table that maps byte ranges back to styles.
    /// 拼接后的文本，以及把字节区间映射回样式的区间表。
    ///
    /// The breaker and shaper work on the flat string; the span table is how they still
    /// see per-run styles. Runs are contiguous, so the table covers every byte exactly once.
    /// 断行与整形作用于拼接字符串；区间表让它们仍能看到逐 run 的样式。
    /// run 是连续的，因此区间表恰好覆盖每个字节一次。
    pub fn flatten(&self) -> (String, Vec<Span>) {
        let mut text = String::new();
        let mut spans = Vec::with_capacity(self.runs.len());
        for run in &self.runs {
            let start = text.len();
            text.push_str(&run.text);
            if text.len() > start {
                spans.push(Span {
                    range: start..text.len(),
                    style: run.style,
                });
            }
        }
        (text, spans)
    }

    /// Style in effect at `offset`, used by painters walking a line.
    /// `offset` 处的生效样式，供逐行绘制的代码使用。
    pub fn style_at(spans: &[Span], offset: usize) -> TextStyle {
        spans
            .iter()
            .find(|s| s.range.contains(&offset))
            .or_else(|| spans.last())
            .map_or_else(TextStyle::default, |s| s.style)
    }
}

/// A byte range and the style that applies to it.
/// 一个字节区间及其适用样式。
#[derive(Clone, Debug, PartialEq)]
pub struct Span {
    pub range: std::ops::Range<usize>,
    pub style: TextStyle,
}

/// One laid-out line: where it sits, how tall it is, and the runs it holds.
/// 一条排好的行：位置、高度，以及它承载的 run。
#[derive(Clone, Debug, PartialEq)]
pub struct InlineLine {
    /// Top edge, relative to the block's origin.
    /// 顶边，相对块的原点。
    pub y: f32,
    /// Line box height: `max(line_height, ascent + descent)`.
    /// 行盒高度：`max(line_height, ascent + descent)`。
    pub height: f32,
    /// Baseline, from this line's top edge.
    /// 基线，从本行顶边量起。
    pub baseline: f32,
    /// Ink width of the line, which alignment measures.
    /// 本行的墨迹宽度，对齐按它计算。
    pub width: f32,
    /// Truncated by `max_lines`; a painter appends the ellipsis itself.
    /// 被 `max_lines` 截断；省略号由绘制端追加。
    pub ellipsis: bool,
    /// The runs on this line, in logical order.
    /// 本行上的 run，按逻辑顺序。
    pub runs: Vec<InlineRun>,
    /// Atoms sitting on this line, in logical order.
    /// 落在本行上的原子，按逻辑顺序。
    pub atoms: Vec<InlineAtom>,
}

/// Where an atom landed on its line: relative to the line's left edge and top.
/// 原子落在行内的位置：相对行左缘与行顶。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct InlineAtom {
    /// Byte offset of its U+FFFC.
    /// 其 U+FFFC 的字节偏移。
    pub at: usize,
    /// Left edge, from the line's left edge.
    /// 左缘，从行的左缘量起。
    pub x: f32,
    /// Top edge, from the line's top edge.
    /// 顶边，从行的顶边量起。
    pub y: f32,
    pub size: Size,
    pub align: VerticalAlign,
}

impl InlineAtom {
    /// Its rect on the surface, given the line's top-left corner.
    /// 给定行的左上角后，它在表面上的矩形。
    pub fn rect(&self, line_origin: crate::geom::Point) -> crate::geom::Rect {
        crate::geom::Rect::new(
            line_origin.x + self.x,
            line_origin.y + self.y,
            self.size.w,
            self.size.h,
        )
    }
}

impl InlineLine {
    /// Byte range this line covers; empty for the caret line of an empty block.
    /// 本行覆盖的字节区间；空块的插入符行是空区间。
    pub fn range(&self) -> std::ops::Range<usize> {
        match (self.runs.first(), self.runs.last()) {
            (Some(first), Some(last)) => first.range.start..last.range.end,
            _ => 0..0,
        }
    }

    /// Bottom edge, relative to the block's origin.
    /// 底边，相对块的原点。
    pub fn bottom(&self) -> f32 {
        self.y + self.height
    }
}

/// One styled piece of a line, in logical order.
/// 行上一段带样式的片段，按逻辑顺序。
#[derive(Clone, Debug, PartialEq)]
pub struct InlineRun {
    pub range: std::ops::Range<usize>,
    pub style: TextStyle,
    /// An object embedded in the flow at this run's start (U+FFFC); P4b places it.
    /// 嵌在流中的原子（U+FFFC）占用本区间起点；由 P4b 摆放。
    pub atomic: Option<Size>,
}

/// A block wrapped once: layout sizes from it and paint draws from it.
/// 只换行一次的整块：布局按它定尺寸，绘制按它落笔。
///
/// Sharing one result is what keeps a caret, a selection and a painted line on the same
/// fact; measuring twice lets them drift apart.
/// 共用一份结果，插入符、选区与绘制的行才建立在同一个事实上；量两遍就会漂移。
#[derive(Clone, Debug, Default, PartialEq)]
pub struct InlineLayout {
    pub lines: Vec<InlineLine>,
    /// Widest line plus the first-line indent.
    /// 最宽的一行加首行缩进。
    pub width: f32,
    /// Sum of the line boxes plus the gaps *between* them.
    /// 各行的行盒之和，加上它们**之间**的空隙。
    pub height: f32,
    /// First line's baseline from the block's top edge; 0 when there are no lines.
    /// 首行基线，从块顶边量起；没有行时为 0。
    pub baseline: f32,
}

impl InlineLayout {
    /// The size layout reserves for the block.
    /// 布局为整块预留的尺寸。
    pub fn size(&self) -> Size {
        Size::new(self.width, self.height)
    }
}

/// A line's box from its text metrics and the atoms it carries: `(height, baseline)`.
/// 由本行文字度量与所载原子求出行盒：`(高度, 基线)`。
pub fn line_metrics(
    text_ascent: f32,
    text_descent: f32,
    text_height: f32,
    atoms: &[AtomBox],
) -> (f32, f32) {
    let mut ascent = text_ascent;
    let mut descent = text_descent;
    for atom in atoms {
        let (above, below) = atom.align.extents(atom.size, atom.baseline);
        ascent = ascent.max(above);
        descent = descent.max(below);
    }
    (text_height.max(ascent + descent).max(1.0), ascent)
}

/// Split every span overlapping `range` into runs clipped to it, cutting at atoms.
/// 把与 `range` 相交的区间裁剪并切成 run，并在原子处切开。
pub fn runs_in(
    block: &TextBlock,
    spans: &[Span],
    range: std::ops::Range<usize>,
) -> Vec<InlineRun> {
    let mut out = Vec::new();
    for span in spans
        .iter()
        .filter(|s| s.range.start < range.end && s.range.end > range.start)
    {
        let start = span.range.start.max(range.start);
        let end = span.range.end.min(range.end);
        let mut from = start;
        for atom in block.atoms.iter().filter(|a| a.at >= start && a.at < end) {
            if atom.at > from {
                out.push(InlineRun {
                    range: from..atom.at,
                    style: span.style,
                    atomic: None,
                });
            }
            let stop = (atom.at + OBJECT.len_utf8()).min(end);
            from = stop;
            out.push(InlineRun {
                range: atom.at..stop,
                style: span.style,
                atomic: Some(atom.size),
            });
        }
        if from < end {
            out.push(InlineRun {
                range: from..end,
                style: span.style,
                atomic: None,
            });
        }
    }
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    fn style(size: f32) -> TextStyle {
        TextStyle::new(size)
    }

    #[test]
    fn flatten_joins_runs_and_covers_every_byte() {
        let block = TextBlock {
            runs: vec![
                TextRun::new("ab", style(10.0)),
                TextRun::new("cd", style(20.0)),
            ],
            align: TextAlign::Start,
            max_lines: None,
            line_gap: 0.0,
            indent: 0.0,
            atoms: Vec::new(),
        };
        let (text, spans) = block.flatten();
        assert_eq!(text, "abcd");
        assert_eq!(spans.len(), 2);
        assert_eq!(spans[0].range, 0..2);
        assert_eq!(spans[1].range, 2..4);
        // Contiguous and non-overlapping: the table is a partition of the text.
        // 连续且不重叠：区间表是文本的一个划分。
        assert_eq!(spans[1].range.start, spans[0].range.end);
        assert_eq!(spans[1].range.end, text.len());
    }

    #[test]
    fn empty_runs_do_not_produce_spans() {
        // A zero-length span would make `style_at` ambiguous for no benefit.
        // 零长度区间只会让 `style_at` 产生歧义，没有好处。
        let block = TextBlock {
            runs: vec![
                TextRun::new("", style(10.0)),
                TextRun::new("x", style(20.0)),
            ],
            align: TextAlign::Start,
            max_lines: None,
            line_gap: 0.0,
            indent: 0.0,
            atoms: Vec::new(),
        };
        let (text, spans) = block.flatten();
        assert_eq!(text, "x");
        assert_eq!(spans.len(), 1);
        assert_eq!(spans[0].style.size, 20.0);
    }

    #[test]
    fn style_at_reads_the_run_covering_the_offset() {
        let block = TextBlock {
            runs: vec![
                TextRun::new("ab", style(10.0)),
                TextRun::new("cd", style(20.0)),
            ],
            align: TextAlign::Start,
            max_lines: None,
            line_gap: 0.0,
            indent: 0.0,
            atoms: Vec::new(),
        };
        let (_, spans) = block.flatten();
        assert_eq!(TextBlock::style_at(&spans, 0).size, 10.0);
        assert_eq!(TextBlock::style_at(&spans, 3).size, 20.0);
    }
}
