//! Single-pass deterministic layout.
//! 单趟确定性布局。

use crate::geom::{Insets, Rect, Size};
use crate::id::NodeId;
use crate::layout::{Constraints, LayoutStats, OverlayAlign, SizeClass};
use crate::tree::{NodeData, NodeKind, Tree};

/// The offset a box of `slack` spare space takes for one axis's alignment.
/// 一个轴上 `slack` 剩余空间对应的对齐偏移。
fn align_offset(align: OverlayAlign, slack: f32) -> f32 {
    match align {
        OverlayAlign::Start => 0.0,
        OverlayAlign::Center => slack * 0.5,
        OverlayAlign::End => slack,
    }
}

/// Slack for the I1 check: float arithmetic must not turn an exact fit into a violation.
/// I1 检查的容差：浮点运算不得把恰好贴合变成越界。
const I1_EPS: f32 = 1e-3;

/// Text measurement, injected so layout stays pure.
/// 文本测量，由外部注入，保持布局是纯函数。
pub trait TextMeasure {
    /// Wrap `block` at `max_width`: the one result layout sizes and paint draws from.
    /// 在 `max_width` 下给 `block` 换行：布局定尺寸与绘制落笔共用的那一份结果。
    ///
    /// Returns a shared handle because both sides keep it for the frame; wrapping twice
    /// is what makes a caret and its painted line disagree.
    /// 返回共享句柄，因为两侧都会在整个帧里持有它；换行两遍正是插入符与绘制行分歧的来源。
    ///
    /// Takes the whole block so per-run styles reach the measurer: rich text measures
    /// each span at its own size.
    /// 传入整个块，使逐 run 的样式能到达测量器：富文本按各段自身字号测量。
    fn layout(
        &mut self,
        block: &crate::text::TextBlock,
        max_width: f32,
    ) -> std::rc::Rc<crate::text::InlineLayout>;

    /// Size of `block` wrapped at `max_width`, honouring its own `max_lines`.
    /// `block` 在 `max_width` 换行下的尺寸，遵循其自身的 `max_lines`。
    ///
    /// Derived from [`TextMeasure::layout`], so the two can never disagree.
    /// 由 [`TextMeasure::layout`] 推导，二者因此不可能不一致。
    fn measure(&mut self, block: &crate::text::TextBlock, max_width: f32) -> Size {
        self.layout(block, max_width).size()
    }

    /// Smallest and largest size the block can take: min-content and max-content.
    /// 块能取到的最小与最大尺寸：min-content 与 max-content。
    ///
    /// The default treats the whole block as unbreakable; a real measurer refines it.
    /// 默认把整个块当作不可断；真实测量器再细化。
    fn intrinsic(&mut self, block: &crate::text::TextBlock) -> (Size, Size) {
        let max = self.measure(block, f32::INFINITY);
        (max, max)
    }
}

/// A text measurer that assumes a fixed advance per character.
/// 按固定字宽估算的测量器。
///
/// Deterministic and dependency-free: good enough for layout tests and the
/// first window example. A real one lives in `ui-text`.
/// 确定且无依赖：足够布局测试与首个窗口示例使用。真实实现在 `ui-text`。
#[derive(Clone, Copy, Debug)]
pub struct MonospaceMeasure {
    /// Advance as a fraction of font size.
    /// 字宽占字号的比例。
    pub advance: f32,
    /// Line height as a fraction of font size.
    /// 行高占字号的比例。
    pub line_height: f32,
}

impl Default for MonospaceMeasure {
    fn default() -> Self {
        Self {
            advance: 0.6,
            line_height: 1.3,
        }
    }
}
/// Lets an engine be swapped between measurers at runtime.
/// 使引擎可在运行时更换测量器。
impl TextMeasure for Box<dyn TextMeasure> {
    fn layout(
        &mut self,
        block: &crate::text::TextBlock,
        max_width: f32,
    ) -> std::rc::Rc<crate::text::InlineLayout> {
        (**self).layout(block, max_width)
    }

    fn intrinsic(&mut self, block: &crate::text::TextBlock) -> (Size, Size) {
        (**self).intrinsic(block)
    }
}

impl TextMeasure for MonospaceMeasure {
    fn layout(
        &mut self,
        block: &crate::text::TextBlock,
        max_width: f32,
    ) -> std::rc::Rc<crate::text::InlineLayout> {
        use crate::text::{AtomBox, InlineAtom, InlineLayout, InlineLine};
        let (text, spans) = block.flatten();
        if spans.is_empty() {
            let line_h = crate::text::TextStyle::default().size * self.line_height;
            return std::rc::Rc::new(InlineLayout {
                lines: vec![InlineLine {
                    y: 0.0,
                    height: line_h,
                    baseline: 0.0,
                    width: 0.0,
                    ellipsis: false,
                    runs: Vec::new(),
                    atoms: Vec::new(),
                }],
                width: 0.0,
                height: line_h,
                baseline: 0.0,
            });
        }
        // Per character: byte offset, byte length, advance, ascent, descent, line box, atom.
        // 逐字符：字节偏移、字节长度、步进、上升、下降、行盒、原子。
        //
        // The estimator has no face, so it assumes an ascent of 1em and a descent of 0.3em;
        // an atom takes its own size and never the room left on the line.
        // 估算器没有字面，故取上升 1em、下降 0.3em；原子取自身尺寸，绝不用行内剩余空间。
        struct Piece {
            start: usize,
            len: usize,
            w: f32,
            ascent: f32,
            descent: f32,
            line_h: f32,
            atom: Option<AtomBox>,
        }
        let mut chars: Vec<Piece> = Vec::new();
        for span in &spans {
            let size = span.style.size;
            let advance = (size * self.advance).max(1.0);
            let ascent = size;
            let descent = size * 0.3;
            let line_h = (size * self.line_height).max(ascent + descent);
            for (offset, ch) in text[span.range.clone()].char_indices() {
                let start = span.range.start + offset;
                let (w, a, d, h, atom) = match block.atom_at(start) {
                    Some(atom) if ch == crate::text::OBJECT => {
                        let (a, d) = atom.align.extents(atom.size, atom.baseline);
                        (atom.size.w, a, d, atom.size.h, Some(*atom))
                    }
                    _ => (advance, ascent, descent, line_h, None),
                };
                chars.push(Piece {
                    start,
                    len: ch.len_utf8(),
                    w,
                    ascent: a,
                    descent: d,
                    line_h: h,
                    atom,
                });
            }
        }
        // Greedy fill: an atom as wide as the block starts a line of its own.
        // 贪心填充：与块同宽的原子独占一行。
        let limit = if max_width.is_finite() && max_width > 0.0 {
            max_width
        } else {
            f32::INFINITY
        };
        let mut chunks: Vec<Vec<usize>> = Vec::new();
        let mut current: Vec<usize> = Vec::new();
        let mut used = 0.0f32;
        for (index, piece) in chars.iter().enumerate() {
            if !current.is_empty() && used + piece.w > limit + 0.01 {
                chunks.push(std::mem::take(&mut current));
                used = 0.0;
            }
            used += piece.w;
            current.push(index);
        }
        if !current.is_empty() {
            chunks.push(current);
        }
        // `max_lines` keeps the first lines and marks the last one ellipsized.
        // `max_lines` 保留前几行，并给最后一行标上省略号。
        let raw = chunks.len();
        let cap = block.max_lines.map_or(raw, |c| (c.max(1) as usize).min(raw));
        let truncated = cap < raw;
        chunks.truncate(cap);

        let mut lines = Vec::with_capacity(chunks.len());
        let mut y = 0.0f32;
        for (n, chunk) in chunks.iter().enumerate() {
            let mut text_ascent = 0.0f32;
            let mut text_descent = 0.0f32;
            let mut text_box = 0.0f32;
            let mut width = 0.0f32;
            for &i in chunk {
                let piece = &chars[i];
                width += piece.w;
                if piece.atom.is_none() {
                    text_ascent = text_ascent.max(piece.ascent);
                    text_descent = text_descent.max(piece.descent);
                    text_box = text_box.max(piece.line_h);
                }
            }
            let mut ascent = text_ascent;
            let mut descent = text_descent;
            for &i in chunk {
                if let Some(atom) = chars[i].atom {
                    let (above, below) = atom.align.extents(atom.size, atom.baseline);
                    ascent = ascent.max(above);
                    descent = descent.max(below);
                }
            }
            let height = text_box.max(ascent + descent).max(1.0);
            let mut atoms = Vec::new();
            let mut pen = 0.0f32;
            for &i in chunk {
                let piece = &chars[i];
                if let Some(atom) = piece.atom {
                    atoms.push(InlineAtom {
                        at: piece.start,
                        x: pen,
                        y: atom
                            .align
                            .top(atom.size, atom.baseline, ascent, height),
                        size: atom.size,
                        align: atom.align,
                    });
                }
                pen += piece.w;
            }
            let first = &chars[chunk[0]];
            let last = &chars[*chunk.last().unwrap()];
            lines.push(InlineLine {
                y,
                height,
                baseline: ascent,
                width,
                ellipsis: truncated && n + 1 == chunks.len(),
                runs: crate::text::runs_in(block, &spans, first.start..last.start + last.len),
                atoms,
            });
            // A gap sits between lines only; the last line adds none.
            // 空隙只在行与行之间；最后一行之后不加。
            y += height + block.line_gap;
        }
        let height = (y - block.line_gap).max(0.0);
        let baseline = lines.first().map_or(0.0, |l| l.baseline);
        std::rc::Rc::new(InlineLayout {
            width: lines.iter().fold(0.0f32, |acc, l| acc.max(l.width)),
            lines,
            height,
            baseline,
        })
    }

    fn intrinsic(&mut self, block: &crate::text::TextBlock) -> (Size, Size) {
        let max = self.measure(block, f32::INFINITY);
        let (text, spans) = block.flatten();
        if spans.is_empty() {
            return (Size::new(0.0, max.h), max);
        }
        let mut widest = 0.0f32;
        let mut line_h = 0.0f32;
        for span in &spans {
            let char_w = (span.style.size * self.advance).max(1.0);
            line_h = line_h.max(span.style.size * self.line_height);
            // Breaks happen at whitespace; the longest run fixes the narrowest line.
            // 断行发生在空白处；最长的一段决定最窄的一行。
            for word in text[span.range.clone()].split_whitespace() {
                widest = widest.max(char_w * word.chars().count() as f32);
            }
        }
        // An atom is unbreakable: its own width, never its U+FFFC's advance, floors the line.
        // 原子不可断：给下限的是它自身的宽度，而不是 U+FFFC 的步进。
        for atom in &block.atoms {
            widest = widest.max(atom.size.w);
            line_h = line_h.max(atom.size.h);
        }
        (Size::new(widest, line_h), max)
    }
}

/// The built-in layout engine.
/// 内置布局引擎。
pub struct BuiltinLayout<M: TextMeasure> {
    measure: M,
    /// Nodes measured since the current solve began; reported as `LayoutStats::remeasured`.
    /// 本次解算开始以来真正测量的节点数；报为 `LayoutStats::remeasured`。
    remeasured: usize,
}


/// Resolve a `Len` upper bound; `Auto` is unbounded and an unresolvable `Pct` acts as one.
/// 解析 `Len` 上界；`Auto` 无界，无法解析的 `Pct` 也按无界处理。
fn max_len(len: crate::layout::Len, avail: f32) -> f32 {
    match len {
        crate::layout::Len::Px(v) => v,
        crate::layout::Len::Pct(p) if avail.is_finite() => avail * p / 100.0,
        _ => f32::INFINITY,
    }
}

/// The size class layout works with: a text leaf's height hint is its line box, so it is a
/// floor for one line and never a ceiling on the block.
/// 布局实际使用的尺寸意愿：文本叶子的身高 hint 是行盒，因此它是单行的下限，绝不是整块的上限。
fn layout_size_class(kind: NodeKind, sc: SizeClass) -> SizeClass {
    let h = sc.height;
    if kind != NodeKind::Text
        || h.sizing != crate::layout::Sizing::Fit
        || !h.hint.is_finite()
        || h.hint <= h.min
    {
        return sc;
    }
    // Making the hint the minimum leaves the derived maximum open (`sizes()` only caps a
    // hint it can shrink to).
    // 把 hint 当作下限，推导出的上限就敞开（`sizes()` 只封顶还能被压缩的 hint）。
    SizeClass {
        height: crate::layout::AxisSize { min: h.hint, ..h },
        ..sc
    }
}

/// Resolve a `Len` lower bound; `Auto` means zero.
/// 解析 `Len` 下界；`Auto` 表示零。
fn min_len(len: crate::layout::Len, avail: f32) -> f32 {
    match len {
        crate::layout::Len::Px(v) => v.max(0.0),
        crate::layout::Len::Pct(p) if avail.is_finite() => (avail * p / 100.0).max(0.0),
        _ => 0.0,
    }
}

/// One axis' used size: the tentative size clamped into `[floor, ceiling]`.
/// 单轴的实际尺寸：候选尺寸被夹进 `[floor, ceiling]`。
///
/// `floor` is the content minimum clamped by the declared bounds (CSS clamps a size's
/// min-content contribution by its own max); `ceiling` never falls below it.
/// P1 reads `Stretch` as content.
/// `floor` 是内容下限被声明上下界夹住的结果（CSS 会用自身 max 夹 min-content 贡献）；
/// 上限不低于它。P1 里 `Stretch` 仍按内容计。
fn used_axis(
    sizing: crate::layout::Sizing,
    avail: f32,
    min_content: f32,
    max_content: f32,
    measured: f32,
    decl_min: f32,
    decl_max: f32,
) -> f32 {
    use crate::layout::{Len, Sizing};
    let tentative = match sizing {
        Sizing::Definite(Len::Px(v)) => v,
        Sizing::Definite(Len::Pct(p)) if avail.is_finite() => avail * p / 100.0,
        // Fit / Stretch / Auto all start from the content measured under `avail`.
        // Fit / Stretch / Auto 都从按 `avail` 测得的内容尺寸出发。
        _ => measured.max(min_content).min(max_content.max(min_content)),
    };
    let (floor, ceiling) = content_bounds(min_content, decl_min, decl_max);
    tentative.max(floor).min(ceiling)
}

/// The usable `[floor, ceiling]` for a node: content floor clamped by its declared bounds.
/// 节点的可用 `[floor, ceiling]`：内容下限被声明的上下界夹住。
fn content_bounds(min_content: f32, decl_min: f32, decl_max: f32) -> (f32, f32) {
    let ceiling = decl_max.max(decl_min).max(0.0);
    let floor = decl_min.max(min_content.min(ceiling)).max(0.0);
    (floor, ceiling)
}

/// In-flow margins: finite edges only. `auto` has no free-space meaning inside the flow yet.
/// A stacked parent reads the child's alternate margin, which is how one child lines up two ways.
/// 流内外边距：只取有限值。`auto` 在流内尚无“余量”含义，按零处理。
/// 堆叠的父容器读子节点的替代边距，一个子节点因此能有两种对齐。
fn flow_margin(tree: &Tree, kid: NodeId, stacked: bool) -> crate::geom::Insets {
    use crate::geom::Insets;
    let m = tree
        .get(kid)
        .map(|n| match (stacked, n.box_model.margin_alt) {
            (true, Some(alt)) => alt,
            _ => n.box_model.margin,
        })
        .unwrap_or(Insets::ZERO);
    let finite = |v: f32| if v.is_finite() { v } else { 0.0 };
    Insets {
        top: finite(m.top),
        right: finite(m.right),
        bottom: finite(m.bottom),
        left: finite(m.left),
    }
}

/// One axis reading of a flow container while it measures: extents and intrinsics.
/// 流容器测量时对一种朝向的读数：范围与内在尺寸。
#[derive(Clone, Copy, Default)]
struct FlowSum {
    main: f32,
    cross: f32,
    main_min: f32,
    main_max: f32,
    cross_min: f32,
    cross_max: f32,
}

/// What one measuring pass over a flow container's children produced.
/// 对某流容器子节点做的一趟测量所得到的结果。
#[derive(Clone, Copy, Default)]
struct FlowAgg {
    row: FlowSum,
    col: FlowSum,
    widest: f32,
    tallest: f32,
    axis_min: [f32; 2],
    axis_max: [f32; 2],
    flow: usize,
}

/// The size placement will give a child along one axis, from its own size class.
/// 定位阶段会沿某一轴给子节点的尺寸，由它自己的尺寸类别决定。
fn placed_along(
    sizes: crate::layout::AxisSizes,
    hint: f32,
    min_c: f32,
    inner: f32,
    grow: crate::layout::Grow,
    measured: f32,
) -> f32 {
    let (floor, ceiling) = content_bounds(min_c, min_len(sizes.min, inner), max_len(sizes.max, inner));
    match (grow, sizes.size) {
        // A zero-basis grower's size comes from the line, not content.
        // 零基准增长者的尺寸由行分配决定，与内容无关。
        (crate::layout::Grow::Split(_), _) => measured,
        (_, crate::layout::Sizing::Definite(crate::layout::Len::Px(v))) => v,
        // Fitting content already measured itself against its hint cap.
        // 适应内容的项已按自身的 hint 上限量过尺寸。
        (_, crate::layout::Sizing::Fit) => measured,
        _ => measured.max(preferred(hint)),
    }
    .max(floor)
    .min(ceiling)
}

/// The flex items one line solves over, from the sizes its children already carry.
/// 一行据此求解的弹性项，取自各子节点已携带的尺寸。
fn line_items(tree: &Tree, line: &[NodeId], horizontal: bool, box_main: f32) -> Vec<crate::flex::Item> {
    line.iter()
        .map(|kid| {
            let n = tree.get(*kid);
            let sc = n
                .map(|n| layout_size_class(n.kind, n.size_class))
                .unwrap_or(SizeClass::fixed(0.0, 0.0));
            let axes = sc.axes();
            let axis_sizes = if horizontal { axes.0 } else { axes.1 };
            let (min_c, max_c, measured) = n
                .map(|n| {
                    if horizontal {
                        (n.min_content.w, n.max_content.w, n.rect.size.w)
                    } else {
                        (n.min_content.h, n.max_content.h, n.rect.size.h)
                    }
                })
                .unwrap_or((0.0, 0.0, 0.0));
            let grow = if horizontal { sc.grow_x } else { sc.grow_y };
            // Every item shrinks by default, as CSS `flex-shrink: 1` does; a declared floor
            // (a `fixed` size) is what stops it.
            // 每项默认都可压缩，与 CSS `flex-shrink: 1` 相同；声明的下限（`fixed` 尺寸）才拦住它。
            let (grow_f, shrink_f) = match grow {
                crate::layout::Grow::No => (0.0, 1.0),
                crate::layout::Grow::Yes => (1.0, 1.0),
                crate::layout::Grow::Flex(w) => (w as f32, 1.0),
                crate::layout::Grow::Split(w) => (w as f32, 1.0),
            };
            // The basis is the declared size, else content clamped into the item's own
            // bounds; a zero-basis grower (`Split`) starts at 0.
            // 基准取声明尺寸，否则取被自身上下界夹住的内容尺寸；零基准增长者（`Split`）从零开始。
            let hint = if horizontal { sc.width.hint } else { sc.height.hint };
            let preferred = if hint.is_finite() && hint > 0.0 { hint } else { 0.0 };
            let content = if max_c.is_finite() { max_c } else { measured };
            let decl_min = min_len(axis_sizes.min, box_main);
            let decl_max = max_len(axis_sizes.max, box_main);
            let (floor, ceiling) = content_bounds(min_c, decl_min, decl_max);
            let basis = match (grow, axis_sizes.size) {
                (crate::layout::Grow::Split(_), _) => 0.0,
                (_, crate::layout::Sizing::Definite(crate::layout::Len::Px(v))) => v,
                // A fitting item hugs content; its hint caps it, it is no floor.
                // 适应内容的项紧贴内容；它的 hint 是上限而不是下限。
                (_, crate::layout::Sizing::Fit) => content.clamp(floor, ceiling),
                _ => content.max(preferred),
            };
            crate::flex::Item {
                basis,
                grow: grow_f,
                shrink: shrink_f,
                min: floor,
                max: ceiling.max(floor),
                hypothetical: basis.max(floor).min(ceiling.max(floor)),
            }
        })
        .collect()
}

/// Total in-flow margin the line has to subtract before it can solve.
/// 行求解前必须扣除的流内边距总和。
fn flow_margins_total(tree: &Tree, line: &[NodeId], horizontal: bool, stacked: bool) -> f32 {
    line.iter()
        .map(|k| {
            let m = flow_margin(tree, *k, stacked);
            if horizontal {
                m.left + m.right
            } else {
                m.top + m.bottom
            }
        })
        .sum()
}

/// Per-child main-axis caps for the children a line squeezes below their measured size.
/// 行把子节点压到测量尺寸以下时，各自的主轴封顶值。
fn squeezed_limits(
    tree: &Tree,
    kids: &[NodeId],
    horizontal: bool,
    inner: Size,
    gap: f32,
    stacked: bool,
) -> Option<Vec<f32>> {
    let line: Vec<NodeId> = kids
        .iter()
        .copied()
        .filter(|k| !tree.floats(*k) && !tree.out_of_flow(*k))
        .collect();
    if line.is_empty() {
        return None;
    }
    let box_main = if horizontal { inner.w } else { inner.h };
    let items = line_items(tree, &line, horizontal, box_main);
    let margins = flow_margins_total(tree, &line, horizontal, stacked);
    let mains = crate::flex::solve_line(&items, (box_main - margins).max(0.0), gap);
    let mut caps = Vec::with_capacity(line.len());
    let mut squeezed = false;
    for (i, kid) in line.iter().enumerate() {
        let measured = tree
            .get(*kid)
            .map(|n| if horizontal { n.rect.size.w } else { n.rect.size.h })
            .unwrap_or(0.0);
        let main = mains.get(i).copied().unwrap_or(measured);
        squeezed |= main + I1_EPS < measured;
        caps.push(if main + I1_EPS < measured { main } else { f32::INFINITY });
    }
    squeezed.then_some(caps)
}

/// Whether the last measure stacked this flow container along its cross axis.
/// 上一次测量是否把这个流容器改成了沿交叉轴堆叠。
fn stacked_axis(tree: &Tree, nid: NodeId) -> bool {
    tree.get(nid).map(|n| n.flow_vertical).unwrap_or(false)
}

/// Whether the wheel may move this container along its own main axis.
/// 滚轮是否可以沿本容器的主轴移动内容。
/// Whether this axis cuts content, which drops the item's automatic minimum to zero.
/// 该轴是否裁切内容；裁切的轴上，项的自动最小尺寸降为零。
fn main_clips(horizontal: bool, clip: crate::layout::Clip) -> bool {
    let overflow = if horizontal { clip.x } else { clip.y };
    overflow != crate::layout::Overflow::Visible
}

fn main_scrolls(horizontal: bool, clip: crate::layout::Clip) -> bool {
    if horizontal {
        clip.x == crate::layout::Overflow::Scroll
    } else {
        clip.y == crate::layout::Overflow::Scroll
    }
}

/// Intersect `mask` with `rect` only on the axes this clip actually cuts.
/// 只在裁剪确实生效的轴上把 `mask` 与 `rect` 求交。
fn apply_clip(mask: Rect, rect: Rect, clip: crate::layout::Clip) -> Rect {
    use crate::layout::Overflow;
    let (x0, x1) = if clip.x == Overflow::Visible {
        (mask.min_x(), mask.max_x())
    } else {
        (mask.min_x().max(rect.min_x()), mask.max_x().min(rect.max_x()))
    };
    let (y0, y1) = if clip.y == Overflow::Visible {
        (mask.min_y(), mask.max_y())
    } else {
        (mask.min_y().max(rect.min_y()), mask.max_y().min(rect.max_y()))
    };
    Rect::new(x0, y0, (x1 - x0).max(0.0), (y1 - y0).max(0.0))
}

/// The clip a keyboard cares about: a scroll viewport translates content, it does not hide it.
/// 键盘在意的裁剪：滚动视口只是平移内容，并没有把内容藏起来。
fn focus_clip(clip: crate::layout::Clip) -> crate::layout::Clip {
    use crate::layout::Overflow;
    let unclip = |o: Overflow| {
        if o == Overflow::Scroll {
            Overflow::Visible
        } else {
            o
        }
    };
    crate::layout::Clip {
        x: unclip(clip.x),
        y: unclip(clip.y),
    }
}

/// A resolved grid: where each item goes and how wide the tracks are.
/// 解算好的网格：每个项目的位置与各轨道尺寸。
struct GridLayout {
    cells: Vec<crate::grid::Cell>,
    widths: Vec<f32>,
    heights: Vec<f32>,
}

/// The template, or a single auto column when the author declared none.
/// 轨道模板；作者没有声明时就是一条 auto 列。
fn grid_tracks_of(params: &crate::tree::ContainerParams) -> crate::layout::TrackList {
    params
        .tracks
        .as_deref()
        .cloned()
        .unwrap_or(crate::layout::TrackList {
            cols: vec![crate::layout::Track::Auto],
            rows: Vec::new(),
            auto_flow: crate::layout::AutoFlow::Row,
        })
}

/// Place the items and size both axes; `use_min` takes min-content for the floor pass.
/// 摆放项目并解算两轴尺寸；`use_min` 时用 min-content 做下限那一趟。
fn grid_layout(
    tree: &Tree,
    kids: &[NodeId],
    params: &crate::tree::ContainerParams,
    available: Size,
    definite: (bool, bool),
    use_min: bool,
) -> GridLayout {
    let tracks = grid_tracks_of(params);
    let areas: Vec<Option<crate::layout::GridArea>> = kids
        .iter()
        .map(|k| tree.get(*k).and_then(|n| n.grid.area))
        .collect();
    // An auto repeat counts the tracks that fit, so the template is spelled out before
    // anything is placed; `auto-fit` collapses its empty tracks only afterwards.
    // auto 重复按能容纳的条数计，因此模板在放置之前就展开；`auto-fit` 的空轨要等放置后才塌缩。
    let mut cols_t = crate::grid::expand_repeat(&tracks.cols, available.w, params.gap);
    let mut rows_t = crate::grid::expand_repeat(&tracks.rows, available.h, params.gap);
    let spans_of = |kid: &NodeId| -> (usize, usize) {
        tree.get(*kid)
            .map(|n| (n.grid.span.0 as usize, n.grid.span.1 as usize))
            .unwrap_or((1, 1))
    };
    let auto_spans: Vec<(usize, usize)> = kids.iter().map(spans_of).collect();
    let (mut cells, mut ncols, nrows) = crate::grid::place_items(
        &areas,
        &auto_spans,
        cols_t.tracks.len(),
        rows_t.tracks.len(),
        tracks.auto_flow,
    );
    if !cols_t.auto_fit.is_empty() {
        ncols = crate::grid::collapse_auto_fit(&mut cells, &mut cols_t.tracks, &cols_t.auto_fit, true);
    }
    if !rows_t.auto_fit.is_empty() {
        crate::grid::collapse_auto_fit(&mut cells, &mut rows_t.tracks, &rows_t.auto_fit, false);
    }
    let cols = crate::grid::expand(&cols_t.tracks, ncols);
    let rows = crate::grid::expand(&rows_t.tracks, nrows);
    let spans = |axis: usize| -> Vec<crate::grid::Span> {
        let avail = if axis == 0 { available.w } else { available.h };
        cells
            .iter()
            .zip(kids)
            .map(|(cell, kid)| {
                // A declared size is what the item contributes, exactly as in CSS: an
                // intrinsic-only read would give a `fixed(20)` item a zero-sized track.
                // 声明的尺寸就是项目的贡献，与 CSS 一致：只读内在值会让 `fixed(20)` 的项目撑不出轨道。
                let declared = tree
                    .get(*kid)
                    .map(|n| {
                        let axes = n.size_class.axes();
                        let axis_sizes = if axis == 0 { axes.0 } else { axes.1 };
                        match axis_sizes.size {
                            crate::layout::Sizing::Definite(crate::layout::Len::Px(v)) => v.max(0.0),
                            crate::layout::Sizing::Definite(crate::layout::Len::Pct(p))
                                if avail.is_finite() =>
                            {
                                (avail * p / 100.0).max(0.0)
                            }
                            _ => 0.0,
                        }
                    })
                    .unwrap_or(0.0);
                let (min, max) = match (tree.get(*kid), axis) {
                    (Some(n), 0) => (n.min_content.w.max(declared), n.max_content.w.max(declared)),
                    (Some(n), _) => (n.min_content.h.max(declared), n.max_content.h.max(declared)),
                    (None, _) => (0.0, 0.0),
                };
                // A margin is outside the item, so the track must hold it too.
                // 外边距在项目之外，轨道因此也要容下它。
                let m = flow_margin(tree, *kid, false);
                let margin = if axis == 0 { m.left + m.right } else { m.top + m.bottom };
                crate::grid::Span {
                    start: if axis == 0 { cell.col } else { cell.row },
                    span: if axis == 0 { cell.col_span } else { cell.row_span },
                    min: min + margin,
                    max: max + margin,
                }
            })
            .collect()
    };
    let widths = crate::grid::track_sizes(
        &cols,
        &spans(0),
        available.w,
        params.gap,
        definite.0,
        use_min,
    );
    let heights = crate::grid::track_sizes(
        &rows,
        &spans(1),
        available.h,
        params.gap,
        definite.1,
        use_min,
    );
    GridLayout {
        cells,
        widths,
        heights,
    }
}

/// Size and offset one item inside its cell; stretch fills, the rest keep their own size.
/// 在单元格内定尺寸与偏移：拉伸填满，其余保持自身尺寸。
fn place_in_cell(
    cell: f32,
    align: Option<crate::layout::Align>,
    axis: crate::layout::AxisSize,
    measured: f32,
) -> (f32, f32) {
    use crate::layout::{Align, Len, Sizing};
    let definite = match axis.sizing {
        Sizing::Definite(Len::Px(v)) => Some(v),
        Sizing::Definite(Len::Pct(p)) => Some(cell * p / 100.0),
        _ => None,
    };
    let own = definite.unwrap_or(measured).max(0.0);
    match align.unwrap_or(Align::Stretch) {
        Align::Stretch if definite.is_none() => (cell, 0.0),
        Align::Stretch | Align::Start => (own, 0.0),
        Align::Center => (own, ((cell - own) * 0.5).max(0.0)),
        Align::End => (own, (cell - own).max(0.0)),
    }
}

/// The author's "comfortable size" for one axis, or 0 when none was declared.
/// 作者在该轴上的「舒适尺寸」；未声明时为 0。
fn preferred(hint: f32) -> f32 {
    if hint.is_finite() && hint > 0.0 {
        hint
    } else {
        0.0
    }
}

/// The hint a parent may treat as a floor: a fitting item's hint caps it instead.
/// 父容器可以当作下限的 hint；适应内容的项的 hint 只是上限。
fn hint_floor(axis: crate::layout::AxisSize) -> f32 {
    if axis.sizing == crate::layout::Sizing::Fit {
        0.0
    } else {
        preferred(axis.hint)
    }
}

/// What one child contributes to its parent's intrinsic range on one axis.
/// 子节点在单一轴上向父节点的内在范围贡献什么。
///
/// An explicit size wins over content; the lower bound always folds in the content floor.
/// 显式尺寸压过内容；下限始终折入内容下限。
fn contribution(
    sizes: crate::layout::AxisSizes,
    min_c: f32,
    max_c: f32,
    avail: f32,
) -> (f32, f32) {
    use crate::layout::{Len, Sizing};
    let (lo, ceiling) = content_bounds(
        min_c,
        min_len(sizes.min, avail),
        max_len(sizes.max, avail),
    );
    let declared = match sizes.size {
        Sizing::Definite(Len::Px(v)) => v,
        Sizing::Definite(Len::Pct(p)) if avail.is_finite() => avail * p / 100.0,
        _ => max_c,
    };
    (lo, declared.max(lo).min(ceiling))
}

/// The rect a modal node covers: its nearest `modal_host` ancestor, else the window.
/// 模态节点覆盖的矩形：最近的 `modal_host` 祖先，否则窗口。
fn modal_target_rect(tree: &Tree, nid: NodeId, target: crate::tree::ModalTarget) -> Option<Rect> {
    let root = tree.root()?;
    // The root is being placed right now, so its stored rect is last frame's or nothing.
    // 根节点此刻正在被放置，它存着的矩形是上一帧的，或者根本还没有。
    if nid == root {
        return None;
    }
    let window = tree.get(root)?.rect;
    if target == crate::tree::ModalTarget::Global {
        return Some(window);
    }
    let mut cur = tree.get(nid)?.parent;
    while let Some(host) = cur {
        let node = tree.get(host)?;
        if node.data.params().is_some_and(|p| p.modal_host) {
            return Some(node.rect);
        }
        cur = node.parent;
    }
    Some(window)
}

/// The visual displacement a relative node's insets declare.
/// 相对节点由内边距声明的视觉位移。
///
/// Over-constrained pairs follow CSS: `left` wins horizontally, `top` vertically.
/// Percentages resolve against the containing block, as CSS does for a relative node.
/// 双端都声明时按 CSS：水平取 `left`，垂直取 `top`。百分比相对包含块解析，
/// 与 CSS 对相对定位节点的规则一致。
fn relative_shift(
    position: crate::layout::Position,
    inset: crate::layout::LenInsets,
    cb: crate::geom::Size,
) -> crate::geom::Point {
    if position != crate::layout::Position::Relative {
        return crate::geom::Point::ZERO;
    }
    let inset = inset.resolve(cb);
    let x = if inset.left.is_finite() {
        inset.left
    } else if inset.right.is_finite() {
        -inset.right
    } else {
        0.0
    };
    let y = if inset.top.is_finite() {
        inset.top
    } else if inset.bottom.is_finite() {
        -inset.bottom
    } else {
        0.0
    };
    crate::geom::Point::new(x, y)
}

/// Fold each node's absolute offset and the nearest declared environment down the tree.
/// 沿树折入每个节点的绝对偏移与最近一层声明的环境。
fn accumulate_offsets(
    tree: &mut Tree,
    nid: NodeId,
    inherited: crate::geom::Point,
    inherited_env: Option<std::sync::Arc<dyn std::any::Any + Send + Sync>>,
) {
    let own = {
        let Some(node) = tree.get(nid) else {
            return;
        };
        // `offset` and a relative inset meet here, in the one place that adds them.
        // `offset` 与相对内边距只在这一处相加。
        let cb = containing_block(tree, nid).size;
        let shift = relative_shift(node.placement.position, node.placement.inset, cb);
        crate::geom::Point::new(
            inherited.x + node.offset.x + shift.x,
            inherited.y + node.offset.y + shift.y,
        )
    };
    let env = inherited_env;
    if let Some(node) = tree.get_mut(nid) {
        node.offset = own;
    }
    // Indexed rather than iterated: the child walk mutates the tree it is reading.
    // 用下标而不是迭代：这次子节点遍历会改动它正在读的那棵树。
    let count = tree.children_of(Some(nid)).len();
    for i in 0..count {
        let Some(child) = tree.child_at(Some(nid), i) else {
            continue;
        };
        accumulate_offsets(tree, child, own, env.clone());
    }
}

/// The containing block of an out-of-flow node: the padding box of its nearest positioned
/// ancestor, else the root box.
/// 流外节点的包含块：最近的定位祖先的内边距盒，否则根盒子。
fn containing_block(tree: &Tree, nid: NodeId) -> Rect {
    let mut cur = tree.get(nid).and_then(|n| n.parent);
    while let Some(a) = cur {
        let Some(node) = tree.get(a) else {
            break;
        };
        if node.placement.position != crate::layout::Position::Static {
            // A border is ink inside the box, so the padding box is the whole rect.
            // 边框是盒内的墨迹，因此内边距盒就是整个矩形。
            return node.rect;
        }
        cur = node.parent;
    }
    tree.root()
        .and_then(|r| tree.get(r))
        .map(|n| n.rect)
        .unwrap_or(Rect::ZERO)
}

/// Room an axis has once its declared insets are taken out.
/// 一条轴扣掉已声明内边距后剩下的空间。
fn inset_avail(cb: f32, a: f32, b: f32) -> f32 {
    let a = if a.is_finite() { a } else { 0.0 };
    let b = if b.is_finite() { b } else { 0.0 };
    (cb - a - b).max(0.0)
}

/// Solve one axis of an out-of-flow box: its size, and where its margin edge starts.
/// 解算流外盒子的一条轴：尺寸，以及外边距边从何处开始。
///
/// `None` for the offset means neither inset is declared, so the caller uses the static
/// position. A non-finite margin is `auto`, split evenly when both sides are.
/// 偏移为 `None` 表示两端都未声明内边距，由调用方退回静态位置。
/// 非有限的外边距表示 `auto`；两端都是 `auto` 时均分。
fn solve_oof_axis(
    cb: f32,
    a: f32,
    b: f32,
    size_auto: bool,
    measured: f32,
    ma: f32,
    mb: f32,
    align: crate::layout::Align,
) -> (f32, Option<f32>) {
    use crate::layout::Align;
    let a = a.is_finite().then_some(a);
    let b = b.is_finite().then_some(b);
    let ma_auto = !ma.is_finite();
    let mb_auto = !mb.is_finite();
    let ma0 = if ma_auto { 0.0 } else { ma };
    let mb0 = if mb_auto { 0.0 } else { mb };
    let mut size = measured;
    // Stretch-fit: both insets fix the edges, so an auto size is whatever is left.
    // 拉伸适配：两端内边距确定了边缘，自动尺寸就是剩下的全部。
    if size_auto
        && let (Some(a), Some(b)) = (a, b) {
            size = (cb - a - b - ma0 - mb0).max(0.0);
        }
    let pos = match (a, b) {
        (Some(a), Some(b)) => {
            let leftover = cb - a - b - size - ma0 - mb0;
            let extra = if ma_auto && mb_auto {
                leftover * 0.5
            } else if ma_auto {
                leftover
            } else if mb_auto {
                0.0
            } else {
                // Over-constrained: self-alignment decides where the spare space goes.
                // 双端确定：由自对齐决定剩余空间落在哪边。
                match align {
                    Align::Start | Align::Stretch => 0.0,
                    Align::Center => leftover * 0.5,
                    Align::End => leftover,
                }
            };
            Some(a + ma0 + extra)
        }
        (Some(a), None) => Some(a + ma0),
        (None, Some(b)) => Some(cb - b - size - mb0),
        (None, None) => None,
    };
    (size, pos)
}

/// Recompute every mask from the visual boxes, after offsets are folded in.
/// 偏移折入之后，按视觉盒重算每个节点的遮罩。
///
/// Hit and paint both test against the mask, so it has to live in the same space the
/// pixels do; computing it during placement would leave a displaced clip behind.
/// 命中与绘制都以遮罩为准，因此它必须与像素同处一个空间；在定位阶段算会落后于位移。
fn compute_masks(
    tree: &mut Tree,
    nid: NodeId,
    parent_mask: Rect,
    parent_focus: Rect,
    viewport: Rect,
) {
    let Some(node) = tree.get(nid) else {
        return;
    };
    let visual = node.visual_rect();
    let clip = node
        .data
        .params()
        .map(|p| p.clip)
        .unwrap_or(crate::layout::Clip::VISIBLE);
    // A modal covers its target, an overlay hangs off its anchor and a lifted node floats
    // above its layout: none of them sits inside the clip of wherever it is declared.
    // 模态覆盖目标，浮层挂在锚点上，被抬起的节点浮在布局之上：三者都不在声明处的裁剪内。
    let detached = node.data.params().and_then(|p| p.modal).is_some()
        || node.placement.overlay.is_some();
    let lifted = node.placement.lift;
    let base = if detached {
        visual
    } else if lifted {
        viewport
    } else {
        parent_mask
    };
    let child_count = tree.children_of(Some(nid)).len();
    let mask = apply_clip(base, visual, clip);
    let focus_base = if detached {
        visual
    } else if lifted {
        viewport
    } else {
        parent_focus
    };
    let focus_mask = apply_clip(focus_base, visual, focus_clip(clip));
    if let Some(n) = tree.get_mut(nid) {
        n.mask = mask;
        n.focus_mask = focus_mask;
    }
    for i in 0..child_count {
        let Some(child) = tree.child_at(Some(nid), i) else {
            continue;
        };
        compute_masks(tree, child, mask, focus_mask, viewport);
    }
}

impl<M: TextMeasure> crate::layout::LayoutEngine for BuiltinLayout<M> {
    fn solve(&mut self, tree: &mut Tree, root: NodeId, constraints: Constraints) -> LayoutStats {
        let max = constraints.max;
        self.remeasured = 0;
        // Bottom-up demand, then top-down placement: one pass each, no retry.
        // 自下而上求需求，再自上而下定位：各一趟，不重跑。
        //
        // The root fills the available space unless it declares a fixed size or an
        // explicit grow policy; otherwise nothing inside it could ever grow.
        // 根节点默认撑满可用空间，除非它声明了固定尺寸或显式增长策略；
        // 否则其内部任何 grow 都拿不到剩余空间。
        let (root_res, _) = self.measure_node(tree, root, constraints);
        let root_grows = tree
            .get(root)
            .map(|n| {
                let axes = n.size_class.axes();
                n.size_class.grow_x != crate::layout::Grow::No
                    || n.size_class.grow_y != crate::layout::Grow::No
                    || max_len(axes.0.max, max.w).is_infinite()
                    || max_len(axes.1.max, max.h).is_infinite()
            })
            .unwrap_or(false);
        let size = if root_grows {
            max
        } else {
            Size::new(
                root_res.size.w.min(max.w).max(0.0),
                root_res.size.h.min(max.h).max(0.0),
            )
        };
        let mut stats = LayoutStats::default();
        self.place_node(
            tree,
            root,
            Rect::from_origin_size(crate::geom::Point::ZERO, size),
            &mut stats,
        );
        // Out-of-flow boxes come second: they are solved against boxes that are already
        // down, so a static ancestor's size never waits on them.
        // 流外盒子放在第二趟：它们相对已经落定的盒子求解，静态祖先的尺寸不必等它们。
        self.place_out_of_flow(tree, root, &mut stats);
        // Offsets are inherited: a displaced container must carry its whole subtree, or
        // its background moves while its children stay behind.
        // 偏移可继承：被位移的容器必须带着整棵子树，否则背景动了子节点没动。
        accumulate_offsets(tree, root, crate::geom::Point::ZERO, None);
        // Masks follow the pixels, so they are derived after the offsets are folded in.
        // 遮罩跟随像素，因此在偏移折入之后再求。
        let root_visual = tree
            .get(root)
            .map(|n| n.visual_rect())
            .unwrap_or(Rect::ZERO);
        compute_masks(tree, root, root_visual, root_visual, root_visual);
        stats.remeasured = self.remeasured;
        tree.set_layout_clean();
        stats
    }
}

impl<M: TextMeasure> BuiltinLayout<M> {
    pub fn new(measure: M) -> Self {
        Self {
            measure,
            remeasured: 0,
        }
    }

    /// The cached measurement, when the node is clean and was last asked the same question.
    /// 节点未脏、且上次问的是同一个问题时，返回缓存的测量。
    ///
    /// A clean subtree answers from its cache; a dirty one invalidates the whole chain above
    /// it, so a hit here means nothing below changed either.
    /// 干净的子树用缓存作答；脏的会让整条祖先链失效，因此命中即表示其下也没变。
    fn measure_node(
        &mut self,
        tree: &mut Tree,
        nid: NodeId,
        constraints: Constraints,
    ) -> (crate::layout::MeasureResult, usize) {
        let cached = tree.get(nid).and_then(|n| {
            if n.dirty {
                return None;
            }
            n.last_measure
                .filter(|m| m.constraints == constraints)
                .map(|m| m.result)
        });
        if let Some(result) = cached {
            return (result, 0);
        }
        self.remeasured += 1;
        let (result, count) = self.measure_node_uncached(tree, nid, constraints);
        if let Some(n) = tree.get_mut(nid) {
            n.last_measure = Some(crate::layout::LastMeasure {
                constraints,
                result,
            });
        }
        (result, count)
    }

    /// One pass over a flow container's children. `limits` caps each in-flow child's main
    /// axis at the size the line will actually give it, so its content reflows there.
    /// 对某流容器的子节点测量一趟。`limits` 按行实际分配给流内子节点的主轴尺寸封顶，
    /// 其内容因此在实得宽度上重新排版。
    fn measure_flow_children(
        &mut self,
        tree: &mut Tree,
        kids: &[NodeId],
        switchable: bool,
        gap: f32,
        kid_avail: Size,
        limits: Option<(&[f32], bool)>,
        count: &mut usize,
    ) -> FlowAgg {
        let mut agg = FlowAgg::default();
        let mut flow = 0usize;
        for kid in kids.iter() {
            let floating = tree.floats(*kid) || tree.out_of_flow(*kid);
            let mut avail = kid_avail;
            if !floating
                && let Some((caps, horizontal)) = limits
                    && let Some(cap) = caps.get(flow) {
                        if horizontal {
                            avail.w = avail.w.min(*cap);
                        } else {
                            avail.h = avail.h.min(*cap);
                        }
                    }
            let (res, c) = self.measure_node(tree, *kid, Constraints::loose(avail));
            *count += c;
            // Remember the measured size; placement only assigns origins.
            // 记住测得尺寸；定位阶段只指派原点。
            if let Some(n) = tree.get_mut(*kid) {
                n.rect.size = res.size;
                n.min_content = res.min_content;
                n.max_content = res.max_content;
            }
            // A floating child contributes nothing to its parent's content size: it floats
            // above the flow instead of taking a slot; out-of-flow is sized by its containing
            // block. 浮起的子节点不占位置、不参与父内容尺寸；流外节点由自己的包含块定尺寸。
            if floating {
                continue;
            }
            if flow > 0 {
                agg.row.main += gap;
                agg.col.main += gap;
            }
            flow += 1;
            // Margins sit outside the border box, so they enlarge the parent's content
            // extent on both axes. 外边距在边框盒之外，因此两轴上都撑大父内容范围。
            let m = flow_margin(tree, *kid, false);
            // Only a switchable row has a second reading; any other parent would be reading
            // its own margins twice under another name.
            // 只有可切换的行才有第二种读法；其他父容器换个名字重读同一套边距而已。
            let m_alt = if switchable { flow_margin(tree, *kid, true) } else { m };
            agg.widest = agg.widest.max(res.size.w + m.left + m.right);
            agg.tallest = agg.tallest.max(res.size.h + m.top + m.bottom);
            // The main axis counts the size placement will give the child, not only the
            // measured one, or a declared comfortable size overflows its parent.
            // 主轴计入定位阶段会给子节点的尺寸，而不只是测得值；否则声明的舒适尺寸会撑破父容器。
            let kid_sc = tree
                .get(*kid)
                .map(|n| layout_size_class(n.kind, n.size_class))
                .unwrap_or(SizeClass::fixed(0.0, 0.0));
            let axes = kid_sc.axes();
            let placed = placed_along(
                axes.0,
                kid_sc.width.hint,
                res.min_content.w,
                kid_avail.w,
                kid_sc.grow_x,
                res.size.w,
            );
            let placed_v = placed_along(
                axes.1,
                kid_sc.height.hint,
                res.min_content.h,
                kid_avail.h,
                kid_sc.grow_y,
                res.size.h,
            );
            agg.row.main += placed + m.left + m.right;
            agg.row.cross = agg.row.cross.max(res.size.h + m.top + m.bottom);
            agg.col.main += placed_v + m_alt.top + m_alt.bottom;
            agg.col.cross = agg.col.cross.max(res.size.w + m_alt.left + m_alt.right);
            // An explicit size wins over content; the content floor bounds both ends.
            // 显式尺寸压过内容；两端都由内容下限兜住。
            let (wlo0, whi0) = contribution(
                axes.0,
                res.min_content.w,
                res.max_content.w.max(hint_floor(kid_sc.width)),
                kid_avail.w,
            );
            let (hlo0, hhi0) = contribution(
                axes.1,
                res.min_content.h,
                res.max_content.h.max(hint_floor(kid_sc.height)),
                kid_avail.h,
            );
            let (wlo, whi) = (wlo0 + m.left + m.right, whi0 + m.left + m.right);
            let (hlo, hhi) = (hlo0 + m.top + m.bottom, hhi0 + m.top + m.bottom);
            let (wlo_alt, whi_alt) = (
                wlo0 + m_alt.left + m_alt.right,
                whi0 + m_alt.left + m_alt.right,
            );
            let (hlo_alt, hhi_alt) = (
                hlo0 + m_alt.top + m_alt.bottom,
                hhi0 + m_alt.top + m_alt.bottom,
            );
            agg.axis_min[0] = agg.axis_min[0].max(wlo);
            agg.axis_min[1] = agg.axis_min[1].max(hlo);
            agg.axis_max[0] = agg.axis_max[0].max(whi);
            agg.axis_max[1] = agg.axis_max[1].max(hhi);
            agg.row.main_min += wlo;
            agg.row.main_max += whi;
            agg.row.cross_min = agg.row.cross_min.max(hlo);
            agg.row.cross_max = agg.row.cross_max.max(hhi);
            agg.col.main_min += hlo_alt;
            agg.col.main_max += hhi_alt;
            agg.col.cross_min = agg.col.cross_min.max(wlo_alt);
            agg.col.cross_max = agg.col.cross_max.max(whi_alt);
        }
        agg.flow = flow;
        agg
    }

    /// Bottom-up: compute a node's demanded size from its children, storing each
    /// child's own size in `child.rect.size` so the top-down pass only has to place.
    /// 自下而上：由子节点算出本节点的需求尺寸，并把每个子节点自身的尺寸存进
    /// `child.rect.size`，使自上而下那一趟只需定位。
    fn measure_node_uncached(
        &mut self,
        tree: &mut Tree,
        nid: NodeId,
        constraints: Constraints,
    ) -> (crate::layout::MeasureResult, usize) {
        let Some(node) = tree.get(nid) else {
            return (crate::layout::MeasureResult::default(), 0);
        };
        let available = constraints.max;
        // I2: a parent may only tighten, so the constraint it hands down must be well formed.
        // I2：父只能收紧，故它传下来的约束本身必须自洽。
        debug_assert!(
            constraints.min.w <= constraints.max.w + I1_EPS
                && constraints.min.h <= constraints.max.h + I1_EPS,
            "I2 violated at {nid:?}: {constraints:?}"
        );
        let node_id = node.id;
        let kind = node.kind;
        let data = node.data.clone();
        let sc = layout_size_class(kind, node.size_class);
        let box_model = node.box_model;
        let sizes = sc.axes();
        // Declared bounds resolved against the offered space, read once and used everywhere.
        // 声明上下界按给出的空间解析；只读一次，处处使用。
        let decl_max = Size::new(
            max_len(sizes.0.max, available.w),
            max_len(sizes.1.max, available.h),
        );
        let decl_min = Size::new(
            min_len(sizes.0.min, available.w),
            min_len(sizes.1.min, available.h),
        );
        let mut count = 1usize;

        // A grid has to measure its children before it can size a track, so it takes its
        // own pass; every other kind answers inside the match below.
        // 网格必须先量完子节点才能定轨道，因此走自己的一趟；其余类型由下面的 match 回答。
        let grid_out = (kind == NodeKind::Grid && data.params().is_some())
            .then(|| self.measure_grid(tree, nid, &data, available, &mut count));
        // First baseline: only a text leaf has one until the inline pass places runs.
        // 首基线：在行内那一趟摆放 run 之前，只有文本叶子有。
        let mut baseline = 0.0f32;
        // Which axis a flow container settled on; placement must not re-decide it.
        // 流容器最终采用的轴；定位不得再决定一次。
        let mut flow_axis_vertical = false;
        let (used, min_content, max_content) = match grid_out {
            Some(out) => out,
            None => match &data {
            NodeData::Text { block, nowrap, .. } => {
                // The box's padding belongs to the box, not to the text: a line only gets the
                // room left inside it, and the painter starts at the content origin.
                // 内边距属于盒子而非文字：一行只拿到盒内剩下的宽度，绘制从内容原点开始。
                let pad = box_model.padding;
                let pad_w = pad.left + pad.right;
                let pad_h = pad.top + pad.bottom;
                // Wrap at the width this node can actually occupy; the painter reuses it.
                // 按本节点实际可占用的宽度换行；绘制端复用同一个值。
                // A `nowrap` node ignores the room it was given: a single-line editor scrolls.
                // `nowrap` 的节点无视分到的空间：单行编辑器靠滚动。
                let inner = (available.w.min(decl_max.w) - pad_w).max(0.0);
                let wrap = if *nowrap { f32::INFINITY } else { inner };
                let layout = self.measure.layout(block, wrap);
                let m = layout.size();
                // A one-line node still reports the box it declared, or a wide line would be
                // centred on its narrow parent and start off-screen.
                // 单行节点仍报出自己声明的盒子，否则过宽的一行会在窄父节点里居中、起点跑到屏幕外。
                let m = if *nowrap {
                    Size::new(
                        m.w.min((sc.width.hint - pad_w).max(0.0)).min(inner),
                        m.h,
                    )
                } else {
                    m
                };
                let (min_c, max_c) = self.measure.intrinsic(block);
                // A nowrap line cannot be broken: its floor is the capped line itself.
                // nowrap 的行不能断：它的下限就是被上界夹住的那一行。
                let (mut min_c, mut max_c) = if *nowrap {
                    (Size::new(m.w, min_c.h), Size::new(m.w, max_c.h))
                } else {
                    (min_c, max_c)
                };
                // The declared height hint is the author's line box; glyphs sit inside it.
                // 声明的身高 hint 就是作者的行盒；字形高度落在这个盒子之内。
                let line_hint = preferred(sc.height.hint);
                // The block is as tall as the lines it wrapped into: min/max-content heights
                // belong to the axis that picks the breaks, not to the height axis.
                // 块与它排出的行数等高：min/max-content 高度属于决定断行的那个轴，不属于高度轴。
                let height = m.h.max(line_hint);
                let content = Size::new(m.w + pad_w, height + pad_h);
                min_c.w += pad_w;
                max_c.w += pad_w;
                min_c.h = content.h;
                max_c.h = content.h;
                // Hand the painter the very lines layout sized, instead of a second wrap.
                // 把布局定尺寸所用的那份行交给绘制端，而不是让它再断一次。
                baseline = pad.top + layout.baseline;
                if let Some(n) = tree.get_mut(nid) {
                    n.wrap_width = wrap;
                    n.inline = Some(layout);
                }
                let used = Size::new(
                    used_axis(
                        sizes.0.size,
                        available.w,
                        min_c.w,
                        max_c.w,
                        content.w,
                        decl_min.w,
                        decl_max.w,
                    ),
                    used_axis(
                        sizes.1.size,
                        available.h,
                        min_c.h,
                        max_c.h,
                        content.h,
                        decl_min.h,
                        decl_max.h,
                    ),
                );
                (used, min_c, max_c)
            }
            NodeData::Container(_) => {
                let params = data.params().cloned().unwrap_or_default();
                let pad = box_model.padding;
                // A capped box cannot hand its children more room than it will itself take;
                // otherwise a `fixed(380)` column measures its text against the whole window.
                // 有上限的盒子不能给子节点超过自身的空间；否则 `fixed(380)` 的列会按整窗宽度量文字。
                let own_avail = Size::new(
                    available.w.min(decl_max.w),
                    available.h.min(decl_max.h),
                );
                let inner_avail = Size::new(
                    (own_avail.w - pad.left - pad.right).max(0.0),
                    (own_avail.h - pad.top - pad.bottom).max(0.0),
                );
                // A scrolling axis hands children no bound at all: the content is measured
                // at its own size and the viewport scrolls over it.
                // 滚动轴不给子节点任何上界：内容按自身尺寸测量，视口在其上滚动。
                let flows = matches!(kind, NodeKind::Row | NodeKind::Column);
                let kid_avail = if flows && main_scrolls(kind == NodeKind::Row, params.clip) {
                    if kind == NodeKind::Row {
                        Size::new(f32::INFINITY, inner_avail.h)
                    } else {
                        Size::new(inner_avail.w, f32::INFINITY)
                    }
                } else {
                    inner_avail
                };
                // Ask children first.
                // 先问子节点。
                // Copied because the measure pass mutates the tree it walks.
                // 需要副本：测量过程会改动它正在遍历的树。
                let kids = tree.children_of(Some(nid)).to_vec();
                // A row that may stack keeps both readings at once: one measure pass feeds
                // the row and the column interpretation, so the switch costs no second pass.
                // 可能堆叠的行同时记下两种读法：一趟测量同时喂给「行」与「列」，
                // 切换因此不需要第二趟。
                let switchable = kind == NodeKind::Row && params.switch_axis.is_some();
                let mut agg = self.measure_flow_children(
                    tree,
                    &kids,
                    switchable,
                    params.gap,
                    kid_avail,
                    None,
                    &mut count,
                );
                let decide = |agg: &FlowAgg| {
                    let stacked = kind == NodeKind::Row
                        && params.switch_axis.is_some_and(|sw| {
                            agg.flow == 1
                                || agg.row.main > inner_avail.w + 0.01
                                || sw.max_cross.is_some_and(|h| agg.row.cross > h)
                        });
                    (stacked, kind == NodeKind::Row && !stacked)
                };
                // A line can hand a child less than it measured at. Its own content then
                // has to reflow at the size it will actually occupy, or a text keeps the
                // wider wrap and overflows. 行可能给子节点的空间小于其测量尺寸；
                // 其内容必须在实得尺寸上重排，否则文本仍按更宽的宽度换行并溢出。
                let (stacked, mut horizontal) = decide(&agg);
                if matches!(kind, NodeKind::Row | NodeKind::Column)
                    && !main_scrolls(horizontal, params.clip)
                    && let Some(limits) =
                        squeezed_limits(tree, &kids, horizontal, inner_avail, params.gap, stacked)
                    {
                        agg = self.measure_flow_children(
                            tree,
                            &kids,
                            switchable,
                            params.gap,
                            kid_avail,
                            Some((&limits, horizontal)),
                            &mut count,
                        );
                        horizontal = decide(&agg).1;
                    }
                let FlowAgg {
                    mut row,
                    mut col,
                    widest,
                    tallest,
                    axis_min,
                    axis_max,
                    flow,
                } = agg;
                let gaps = params.gap * (flow.saturating_sub(1)) as f32;
                // Main-axis intrinsics include the gaps between flow children.
                // 主轴内在尺寸含流内子节点之间的间隙。
                row.main_min += gaps;
                row.main_max += gaps;
                col.main_min += gaps;
                col.main_max += gaps;
                flow_axis_vertical = matches!(kind, NodeKind::Row | NodeKind::Column) && !horizontal;
                let sum = if horizontal { row } else { col };
                let content = match kind {
                    NodeKind::Row | NodeKind::Column => {
                        if horizontal {
                            Size::new(sum.main, sum.cross)
                        } else {
                            Size::new(sum.cross, sum.main)
                        }
                    }
                    NodeKind::Stack => Size::new(widest, tallest),
                    _ => Size::new(sum.cross, sum.main),
                };
                let pad_w = pad.left + pad.right;
                let pad_h = pad.top + pad.bottom;
                // The content size is the box's own, so the padding around the children is
                // part of it; leaving it out sizes a hugging box narrower than its content.
                // 内容尺寸即盒子自身的尺寸，环绕子节点的内边距属于它；漏掉它会让紧贴的盒子比内容还窄。
                let content = Size::new(content.w + pad_w, content.h + pad_h);
                let (min_c, max_c) = match kind {
                    NodeKind::Row | NodeKind::Column => {
                        if horizontal {
                            (
                                Size::new(sum.main_min + pad_w, sum.cross_min + pad_h),
                                Size::new(sum.main_max + pad_w, sum.cross_max + pad_h),
                            )
                        } else {
                            (
                                Size::new(sum.cross_min + pad_w, sum.main_min + pad_h),
                                Size::new(sum.cross_max + pad_w, sum.main_max + pad_h),
                            )
                        }
                    }
                    NodeKind::Stack => (
                        Size::new(axis_min[0] + pad_w, axis_min[1] + pad_h),
                        Size::new(axis_max[0] + pad_w, axis_max[1] + pad_h),
                    ),
                    _ => (
                        Size::new(axis_min[0] + pad_w, sum.main_min + pad_h),
                        Size::new(axis_max[0] + pad_w, sum.main_max + pad_h),
                    ),
                };
                // A scroll viewport never demands its content on the scrolling axis: the
                // content overflows by design and the app scrolls it.
                // 滚动视口在滚动轴上不索要内容尺寸：内容本就溢出，由 app 滚动。
                let (min_c, max_c) = if main_clips(horizontal, params.clip) {
                    if horizontal {
                        (Size::new(0.0, min_c.h), max_c)
                    } else {
                        (Size::new(min_c.w, 0.0), max_c)
                    }
                } else {
                    (min_c, max_c)
                };
                let used = Size::new(
                    used_axis(
                        sizes.0.size,
                        own_avail.w,
                        min_c.w,
                        max_c.w,
                        content.w,
                        decl_min.w,
                        decl_max.w,
                    ),
                    used_axis(
                        sizes.1.size,
                        own_avail.h,
                        min_c.h,
                        max_c.h,
                        content.h,
                        decl_min.h,
                        decl_max.h,
                    ),
                );
                (used, min_c, max_c)
            }
        },
        };

        // Store this node's answer; the placement pass reads sizes and intrinsics here.
        // 存下本节点的答案；定位那一趟从这里读尺寸与内在值。
        if let Some(n) = tree.get_mut(nid) {
            n.rect.size = used;
            n.min_content = min_content;
            n.max_content = max_content;
            n.baseline = baseline;
            // Placement reads the axis this measure settled on, not the declared kind.
            // 定位读测量定下的轴，而不是声明的类型。
            n.flow_vertical = flow_axis_vertical;
        }
        // I1: the answer stays between the content floor and the declared ceiling.
        // I1：答案落在内容下限与声明上限之间。
        let (floor_w, ceiling_w) = content_bounds(min_content.w, decl_min.w, decl_max.w);
        let (floor_h, ceiling_h) = content_bounds(min_content.h, decl_min.h, decl_max.h);
        let floor = Size::new(floor_w, floor_h);
        let ceiling = Size::new(ceiling_w, ceiling_h);
        debug_assert!(
            used.w + I1_EPS >= floor.w
                && used.h + I1_EPS >= floor.h
                && used.w <= ceiling.w + I1_EPS
                && used.h <= ceiling.h + I1_EPS,
            "I1 violated at {node_id:?}: used {used:?}, floor {floor:?}, ceiling {ceiling:?}, {constraints:?}"
        );
        (
            crate::layout::MeasureResult {
                size: used,
                min_content,
                max_content,
                baseline,
            },
            count,
        )
    }

    /// Top-down: assign origins and recurse. Sizes come from the measure pass.
    /// 自上而下：指派原点并递归。尺寸来自 measure 那一趟。
    fn place_node(&mut self, tree: &mut Tree, nid: NodeId, rect: Rect, stats: &mut LayoutStats) {
        stats.measured += 1;
        let (kind, data, box_model) = match tree.get(nid) {
            Some(n) => (n.kind, n.data.clone(), n.box_model),
            None => return,
        };
        // A modal covers its target, not the place the tree happened to put it: the target
        // is an ancestor, already placed, so this needs no rect from outside and follows
        // every resize in the same frame.
        // 模态盖住它的目标，而不是树恰好给它的位置：目标是祖先、已经定位，
        // 因此不需要外部传矩形，也会在同一帧跟上每一次尺寸变化。
        let rect = match data.params().and_then(|p| p.modal) {
            Some(target) => modal_target_rect(tree, nid, target).unwrap_or(rect),
            None => rect,
        };
        if let Some(n) = tree.get_mut(nid) {
            n.rect.origin = rect.origin;
            n.rect.size = rect.size;
        }

        if let Some(params) = data.params().cloned() {
            let pad: Insets = box_model.padding;
            let content_w = (rect.size.w - pad.left - pad.right).max(0.0);
            let content_h = (rect.size.h - pad.top - pad.bottom).max(0.0);
            // The wheel may not move content past its own end; the extent is the content
            // measured on the previous pass, so the clamp only bites at the boundary.
            // 滚轮不能把内容移过自己的末端；范围取自上一趟量得的内容，因此只在边界处生效。
            let extent = tree
                .get(nid)
                .map(|n| n.scroll_extent)
                .unwrap_or(Size::ZERO);
            // An elastic frame carries the engine's own overscroll and must reach the paint;
            // clamping it would make the rubber band and the spring return invisibly.
            // 弹性帧携带的是引擎自己的越界量，必须到达绘制端；夹住它会让橡皮筋与回弹都看不见。
            let clamp = |offset: f32, extent: f32, view: f32| {
                if extent > 0.0 && !params.scroll_elastic {
                    offset.clamp(0.0, (extent - view).max(0.0))
                } else {
                    offset
                }
            };
            // Scrolling shifts the content box; the container's own box stays put, so
            // children scrolled outside are clipped by the mask it already has.
            // 滚动只平移内容盒，容器自身的盒不动，因此滚出去的子节点会被已有的遮罩裁掉。
            let content_origin = crate::geom::Point::new(
                rect.origin.x + pad.left - clamp(params.scroll_x, extent.w, content_w),
                rect.origin.y + pad.top - clamp(params.scroll_y, extent.h, content_h),
            );
            // Copied because placement mutates the tree it walks.
            // 需要副本：定位过程会改动它正在遍历的树。
            let kids = tree.children_of(Some(nid)).to_vec();
            // The measure pass settled the axis; a switchable row may have stacked.
            // 轴由测量那一趟定下；可切换的行可能已经改为堆叠。
            let horizontal = kind == NodeKind::Row && !stacked_axis(tree, nid);
            if kind == NodeKind::Grid {
                self.place_grid(
                    tree,
                    nid,
                    &params,
                    content_origin,
                    Size::new(content_w, content_h),
                    stats,
                );
                return;
            }
            // A stack gives every child the content origin and its own measured size, so
            // layers overlap instead of taking turns down the box.
            // 叠放容器把内容原点与各自测得尺寸给每个子节点，于是各层互相重叠，
            // 而不是在盒子里依次排开。
            if kind == NodeKind::Stack {
                let (align_x, align_y) = params.stack_align;
                for kid in kids.iter() {
                    // An out-of-flow layer is placed by the OOF pass, not stacked here.
                    // 流外的层由 OOF 那一趟定位，不在此叠放。
                    if tree.out_of_flow(*kid) {
                        continue;
                    }
                    let size = tree.get(*kid).map(|n| n.rect.size).unwrap_or(Size::ZERO);
                    // A stack has no main axis, so both axes take the same rule.
                    // 叠放容器没有主轴，两个轴因此用同一套规则。
                    let origin = crate::geom::Point::new(
                        content_origin.x + align_offset(align_x, content_w - size.w),
                        content_origin.y + align_offset(align_y, content_h - size.h),
                    );
                    let rect = Rect::from_origin_size(origin, size);
                    self.place_node(tree, *kid, rect, stats);
                }
                return;
            }

            // Resolve the line with the flex algorithm: basis, grow and scaled shrink,
            // freezing an item once it reaches its own bound.
            // 用 flex 算法解算一行：基准、增长与缩放压缩，触到自身界限的项随即冻结。
            // Floating children take no slot, so they take no gap either.
            // 浮起的子节点不占位置，也就不占间隙。
            let flow: Vec<NodeId> = kids
                .iter()
                .copied()
                .filter(|k| !tree.floats(*k) && !tree.out_of_flow(*k))
                .collect();
            let gap_total = params.gap * (flow.len().saturating_sub(1)) as f32;
            let box_main = if horizontal {
                content_w
            } else {
                (rect.size.h - pad.top - pad.bottom).max(0.0)
            };
            let items = line_items(tree, &flow, horizontal, box_main);
            // A scrolling container is sized by its content: hand the line exactly the
            // basis sum, so nothing is squeezed and nothing has spare space to grow into.
            // 滚动容器由内容决定尺寸：正好给出一行的基准总和，既不压缩也不留可增长空间。
            // Margins are outside the border box, so the line solves on what is left.
            // 外边距在边框盒之外，行在扣除它之后的空间里求解。
            let margins_total = flow_margins_total(tree, &flow, horizontal, stacked_axis(tree, nid));
            let main_avail = if main_scrolls(horizontal, params.clip) {
                items.iter().map(|i| i.basis).sum::<f32>() + gap_total + margins_total
            } else {
                (box_main - margins_total).max(0.0)
            };
            let mains = crate::flex::solve_line(&items, main_avail, params.gap);
            let mut next_main = 0usize;

            // The content extent is what a scrollbar needs; it is not the viewport.
            // 内容范围是滚动条需要的值，不是视口。
            let mut main_end = 0.0_f32;
            let mut cross_max = 0.0_f32;
            let mut cursor = 0.0_f32;
            for (i, kid) in kids.iter().enumerate() {
                // An out-of-flow child is placed against its containing block afterwards.
                // 流外子节点稍后相对其包含块定位。
                if tree.out_of_flow(*kid) {
                    continue;
                }
                // A floating child keeps its own measured size and sits at the content
                // origin; it neither consumes a slot nor receives spare space.
                // 浮起的子节点保持自身测得尺寸、落在内容原点；既不占位置也不参与分配。
                if tree.floats(*kid) {
                    let size = tree.get(*kid).map(|n| n.rect.size).unwrap_or(Size::ZERO);
                    let rect = Rect::from_origin_size(content_origin, size);
                    self.place_node(tree, *kid, rect, stats);
                    continue;
                }
                let kid_size = tree.get(*kid).map(|n| n.rect.size).unwrap_or(Size::ZERO);
                // In-flow margins offset the child and consume the line's space.
                // 流内外边距把子节点推开，并占去行内的空间。
                let m = flow_margin(tree, *kid, stacked_axis(tree, nid));
                let (m_main_start, m_main_end) = if horizontal {
                    (m.left, m.right)
                } else {
                    (m.top, m.bottom)
                };
                let (m_cross_start, m_cross_end) = if horizontal {
                    (m.top, m.bottom)
                } else {
                    (m.left, m.right)
                };
                cursor += m_main_start;
                // `mains` no longer has one entry per kid: overlays were filtered out.
                // `mains` 不再与子节点一一对应：悬浮节点已被滤掉。
                let slot = next_main;
                next_main += 1;
                let main = mains.get(slot).copied().unwrap_or({
                    if horizontal {
                        kid_size.w
                    } else {
                        kid_size.h
                    }
                });
                // Cross axis: `cross_align` is the fraction of the spare cross space the
                // child takes (0 = hug, 1 = stretch to fill); a deficit shrinks it too.
                // 交叉轴：`cross_align` 是子节点占用的交叉剩余空间比例（0 = 紧贴，1 = 撑满）；
                // 剩余为负时同样按比例收缩。
                let cross_avail = (if horizontal {
                    (rect.size.h - pad.top - pad.bottom).max(0.0)
                } else {
                    content_w
                } - m_cross_start
                    - m_cross_end)
                    .max(0.0);
                let cross_measured = if horizontal { kid_size.h } else { kid_size.w };
                // Stretching is bounded by the child's own cross-axis bounds: `fixed` and a
                // declared max are hard caps, an unbounded `hug`/`fill` may stretch.
                // 拉伸受子节点自身交叉轴上下界约束：`fixed` 与声明上界是硬上限，
                // 无界的 `hug`/`fill` 才能撑满。
                // The same resolution measure used: a text's height hint is a line-box floor,
                // and reading the raw class here would cap it at one line.
                // 与测量相同的解析：文本的身高 hint 是行盒下限，这里读原始声明会把它封顶成一行。
                let (cross_sizes, cross_min_c) = tree
                    .get(*kid)
                    .map(|n| {
                        let axes = layout_size_class(n.kind, n.size_class).axes();
                        (
                            if horizontal { axes.1 } else { axes.0 },
                            if horizontal { n.min_content.h } else { n.min_content.w },
                        )
                    })
                    .unwrap_or((
                        crate::layout::AxisSizes {
                            size: crate::layout::Sizing::Fit,
                            min: crate::layout::Len::Px(0.0),
                            max: crate::layout::Len::Auto,
                        },
                        0.0,
                    ));
                let stretched =
                    cross_measured + (cross_avail - cross_measured) * params.cross_align;
                let (floor, ceiling) = content_bounds(
                    cross_min_c,
                    min_len(cross_sizes.min, cross_avail),
                    max_len(cross_sizes.max, cross_avail),
                );
                let cross = stretched.max(floor).min(ceiling);
                let (w, h) = if horizontal {
                    (main, cross)
                } else {
                    (cross, main)
                };
                // `cross_pos` places what the child did not take: 0 hugs the start, 0.5 centres.
                // `cross_pos` 决定子节点让出的空间怎么分：0 贴起点，0.5 居中。
                let slack = if horizontal {
                    (cross_avail - h).max(0.0) * params.cross_pos + m_cross_start
                } else {
                    (cross_avail - w).max(0.0) * params.cross_pos + m_cross_start
                };
                let _ = content_w;
                let origin = if horizontal {
                    crate::geom::Point::new(content_origin.x + cursor, content_origin.y + slack)
                } else {
                    crate::geom::Point::new(content_origin.x + slack, content_origin.y + cursor)
                };
                let child_rect = Rect::from_origin_size(origin, Size::new(w, h));
                self.place_node(tree, *kid, child_rect, stats);
                cursor += (if horizontal { w } else { h }) + m_main_end;
                main_end = cursor;
                cross_max = cross_max.max(
                    (if horizontal { h } else { w }) + m_cross_start + m_cross_end,
                );
                if i + 1 < kids.len() {
                    cursor += params.gap;
                }
            }
            if let Some(n) = tree.get_mut(nid) {
                n.scroll_extent = if horizontal {
                    Size::new(main_end, cross_max)
                } else {
                    Size::new(cross_max, main_end)
                };
            }
        }
    }

    /// Place every out-of-flow node, parents before children, after the flow is down.
    /// 在所有流内盒子落定之后，自父到子定位每个流外节点。
    fn place_out_of_flow(&mut self, tree: &mut Tree, nid: NodeId, stats: &mut LayoutStats) {
        let count = tree.children_of(Some(nid)).len();
        for i in 0..count {
            let Some(kid) = tree.child_at(Some(nid), i) else {
                continue;
            };
            if tree.out_of_flow(kid) {
                self.place_out_of_flow_node(tree, kid, stats);
            }
            // A nested OOF node hangs off its own containing block, so it comes after.
            // 嵌套的流外节点挂在各自的包含块上，因此排在后面。
            self.place_out_of_flow(tree, kid, stats);
        }
    }

    /// Resolve one out-of-flow node against its containing block, then place its subtree.
    /// 相对包含块解算一个流外节点，再定位它的子树。
    fn place_out_of_flow_node(&mut self, tree: &mut Tree, nid: NodeId, stats: &mut LayoutStats) {
        use crate::layout::Position;
        let Some(node) = tree.get(nid) else {
            return;
        };
        let placement = node.placement;
        let box_model = node.box_model;
        let size_class = node.size_class;
        let grid = node.grid;
        let parent = node.parent;
        // An overlay answers to its anchor, not to a containing block or to insets.
        // 浮层听命于锚点，而不是包含块或内边距。
        if let Some(overlay) = placement.overlay {
            self.place_overlay(tree, nid, overlay, stats);
            return;
        }
        // Fixed pins to the initial containing block: the root's border box.
        // 固定定位钉在初始包含块上：根的边框盒。
        let cb = match placement.position {
            Position::Fixed => tree
                .root()
                .and_then(|r| tree.get(r))
                .map(|n| n.rect)
                .unwrap_or(Rect::ZERO),
            _ => containing_block(tree, nid),
        };
        // The static position is the parent's content origin, where the node would have sat.
        // 静态位置是父节点的内容原点，也就是它本会落到的位置。
        let static_origin = parent
            .and_then(|p| tree.get(p))
            .map(|p| {
                let pad = p.box_model.padding;
                let (sx, sy) = p
                    .data
                    .params()
                    .map(|q| (q.scroll_x, q.scroll_y))
                    .unwrap_or((0.0, 0.0));
                crate::geom::Point::new(
                    p.rect.origin.x + pad.left - sx,
                    p.rect.origin.y + pad.top - sy,
                )
            })
            .unwrap_or(cb.origin);
        // Percent insets were declared against this same containing block.
        // 百分比内边距正是相对这个包含块声明的。
        let inset = placement.inset.resolve(cb.size);
        let margin = box_model.margin;
        // Auto margins are written as non-finite values; only an OOF node reads them.
        // 自动外边距写成非有限值；只有流外节点会读它。
        let margin_left = if margin.left.is_finite() { margin.left } else { crate::layout::AUTO };
        let margin_right = if margin.right.is_finite() { margin.right } else { crate::layout::AUTO };
        let margin_top = if margin.top.is_finite() { margin.top } else { crate::layout::AUTO };
        let margin_bottom = if margin.bottom.is_finite() { margin.bottom } else { crate::layout::AUTO };
        // The inset-modified containing block bounds the measurement.
        // 内边距修正后的包含块限定测量空间。
        let avail_w = inset_avail(cb.size.w, inset.left, inset.right);
        let avail_h = inset_avail(cb.size.h, inset.top, inset.bottom);
        let (res, c) = self.measure_node(
            tree,
            nid,
            Constraints::loose(Size::new(avail_w, avail_h)),
        );
        stats.measured += c;
        if let Some(n) = tree.get_mut(nid) {
            n.min_content = res.min_content;
            n.max_content = res.max_content;
        }
        let width_auto = matches!(size_class.width.sizing, crate::layout::Sizing::Fit);
        let height_auto = matches!(size_class.height.sizing, crate::layout::Sizing::Fit);
        let justify = grid.justify.unwrap_or(crate::layout::Align::Stretch);
        let align = grid.align.unwrap_or(crate::layout::Align::Stretch);
        let mut measured = res.size;
        let (w, x_off) = solve_oof_axis(
            cb.size.w,
            inset.left,
            inset.right,
            width_auto,
            measured.w,
            margin_left,
            margin_right,
            justify,
        );
        // Text wraps to the width it is given, so a stretched width must be measured again.
        // 文本按分到的宽度换行，因此被拉伸的宽度要重新测量。
        if width_auto && (w - measured.w).abs() > 0.01 {
            let (again, c) = self.measure_node(tree, nid, Constraints::loose(Size::new(w, avail_h)));
            stats.measured += c;
            measured = again.size;
            if let Some(n) = tree.get_mut(nid) {
                n.min_content = again.min_content;
                n.max_content = again.max_content;
            }
        }
        let (h, y_off) = solve_oof_axis(
            cb.size.h,
            inset.top,
            inset.bottom,
            height_auto,
            measured.h,
            margin_top,
            margin_bottom,
            align,
        );
        // An axis with no inset falls back to the static position.
        // 两轴都没有内边距时退回静态位置。
        let x = x_off.map(|off| cb.origin.x + off).unwrap_or(static_origin.x);
        let y = y_off.map(|off| cb.origin.y + off).unwrap_or(static_origin.y);
        self.place_node(
            tree,
            nid,
            Rect::from_origin_size(crate::geom::Point::new(x, y), Size::new(w, h)),
            stats,
        );
    }

    /// Place an anchored overlay: measure against the viewport, unfold from the anchor,
    /// flip at an edge, then clamp inside the viewport.
    /// 摆放锚定浮层：按视口量尺寸，从锚点展开，到边缘时翻转，最后钳进视口。
    fn place_overlay(
        &mut self,
        tree: &mut Tree,
        nid: NodeId,
        overlay: crate::layout::OverlayPlacement,
        stats: &mut LayoutStats,
    ) {
        use crate::geom::Point;
        use crate::layout::{Anchor, OverlayAlign, Side};
        let viewport = tree
            .root()
            .and_then(|r| tree.get(r))
            .map(|n| n.rect)
            .unwrap_or(Rect::ZERO);
        let anchor = match overlay.anchor {
            Anchor::Node(id) => tree
                .find_by_id(id)
                .and_then(|a| tree.get(a))
                .map(|n| n.rect),
            Anchor::Point(p) => Some(Rect::from_origin_size(p, Size::ZERO)),
        };
        // A missing anchor still gets a panel: it unfolds from the viewport's top-left.
        // 锚点缺失时面板照样出现：从视口的左上角展开。
        let anchor = anchor.unwrap_or(Rect::from_origin_size(viewport.origin, Size::ZERO));
        let (res, c) = self.measure_node(
            tree,
            nid,
            Constraints::loose(Size::new(viewport.size.w, viewport.size.h)),
        );
        stats.measured += c;
        if let Some(n) = tree.get_mut(nid) {
            n.min_content = res.min_content;
            n.max_content = res.max_content;
        }
        let mut size = res.size;
        // A panel told to span its anchor is re-measured inside the anchor's box, so its
        // text wraps and its fill children stretch to that box, not to the viewport.
        // 要求与锚点同宽/同高的面板在锚点的盒子里重量一次：文字在那个宽度上换行，
        // 撑满的子节点对着那个盒子伸展，而不是视口。
        let span_w = (overlay.match_anchor_width && anchor.size.w > 0.0)
            .then(|| anchor.size.w.max(overlay.min_width));
        let span_h = (overlay.match_anchor_height && anchor.size.h > 0.0).then_some(anchor.size.h);
        if span_w.is_some() || span_h.is_some() {
            let width = span_w.unwrap_or(size.w);
            // The other axis keeps the viewport as its ceiling: a hugging panel may grow
            // taller when its text rewraps at the anchor's width.
            // 另一条轴仍以视口为上限：按锚点宽度换行后，紧贴内容的面板可以变高。
            let height = span_h.unwrap_or(viewport.size.h);
            let (again, c) = self.measure_node(
                tree,
                nid,
                Constraints::loose(Size::new(width, height)),
            );
            stats.measured += c;
            // A spanned axis takes the anchor's extent outright: the panel's own content
            // rarely asks for it, and a background has to reach the host's edge anyway.
            // 同宽/同高的轴直接取锚点的范围：面板内容很少主动要这么大，
            // 而背景本来就得够到宿主的边缘。
            size = Size::new(width, span_h.unwrap_or(again.size.h));
        }
        let fits = |r: Rect| {
            r.min_x() >= viewport.min_x() - 0.01
                && r.min_y() >= viewport.min_y() - 0.01
                && r.max_x() <= viewport.max_x() + 0.01
                && r.max_y() <= viewport.max_y() + 0.01
        };
        let at = |side: Side| {
            let (mut x, mut y) = match side {
                Side::Below => (0.0, anchor.max_y() + overlay.offset),
                Side::Above => (0.0, anchor.min_y() - overlay.offset - size.h),
                Side::Right => (anchor.max_x() + overlay.offset, 0.0),
                Side::Left => (anchor.min_x() - overlay.offset - size.w, 0.0),
            };
            let horizontal = matches!(side, Side::Below | Side::Above);
            let (start, span, own) = if horizontal {
                (anchor.min_x(), anchor.size.w, size.w)
            } else {
                (anchor.min_y(), anchor.size.h, size.h)
            };
            let aligned = match overlay.align {
                OverlayAlign::Start => start,
                OverlayAlign::Center => start + (span - own) * 0.5,
                OverlayAlign::End => start + span - own,
            };
            if horizontal {
                x = aligned;
            } else {
                y = aligned;
            }
            Rect::from_origin_size(Point::new(x, y), size)
        };
        let mut rect = at(overlay.side);
        if overlay.flip && !fits(rect) {
            let opposite = match overlay.side {
                Side::Below => Side::Above,
                Side::Above => Side::Below,
                Side::Left => Side::Right,
                Side::Right => Side::Left,
            };
            let flipped = at(opposite);
            if fits(flipped) {
                rect = flipped;
            }
        }
        // The viewport wins over the anchor: a panel taller than the window still starts
        // at its top edge, so its first line stays readable.
        // 视口压过锚点：比窗口还高的面板仍从顶边开始，第一行因此可读。
        let x = rect
            .origin
            .x
            .clamp(viewport.min_x(), (viewport.max_x() - size.w).max(viewport.min_x()));
        let y = rect
            .origin
            .y
            .clamp(viewport.min_y(), (viewport.max_y() - size.h).max(viewport.min_y()));
        self.place_node(
            tree,
            nid,
            Rect::from_origin_size(Point::new(x, y), size),
            stats,
        );
    }

    /// Bottom-up grid answer: measure the items, size the tracks, return the box demand.
    /// 自下而上的网格答案：量完项目、定轨道，返回盒子需求。
    fn measure_grid(
        &mut self,
        tree: &mut Tree,
        nid: NodeId,
        data: &NodeData,
        available: Size,
        count: &mut usize,
    ) -> (Size, Size, Size) {
        let Some(node) = tree.get(nid) else {
            return (Size::ZERO, Size::ZERO, Size::ZERO);
        };
        let sc = node.size_class;
        let pad = node.box_model.padding;
        let sizes = sc.axes();
        let params = data.params().cloned().unwrap_or_default();
        // A capped box cannot offer its items more room than it will take itself.
        // 有上限的盒子不能给项目超过自身的空间。
        let own_avail = Size::new(
            available.w.min(max_len(sizes.0.max, available.w)),
            available.h.min(max_len(sizes.1.max, available.h)),
        );
        let inner = Size::new(
            (own_avail.w - pad.left - pad.right).max(0.0),
            (own_avail.h - pad.top - pad.bottom).max(0.0),
        );
        let decl_min = Size::new(
            min_len(sizes.0.min, available.w),
            min_len(sizes.1.min, available.h),
        );
        let decl_max = Size::new(
            max_len(sizes.0.max, available.w),
            max_len(sizes.1.max, available.h),
        );
        let layout = self.measure_grid_items(tree, nid, &params, inner, count);
        let definite = (
            !matches!(sizes.0.size, crate::layout::Sizing::Fit),
            !matches!(sizes.1.size, crate::layout::Sizing::Fit),
        );
        let floor = grid_layout(tree, &layout, &params, inner, (false, false), true);
        let max_layout = grid_layout(tree, &layout, &params, inner, definite, false);
        let gap = params.gap;
        let extent = |v: &[f32]| v.iter().sum::<f32>() + gap * v.len().saturating_sub(1) as f32;
        let content = Size::new(extent(&max_layout.widths), extent(&max_layout.heights));
        let min_c = Size::new(
            extent(&floor.widths) + pad.left + pad.right,
            extent(&floor.heights) + pad.top + pad.bottom,
        );
        let max_c = Size::new(
            content.w + pad.left + pad.right,
            content.h + pad.top + pad.bottom,
        );
        let used = Size::new(
            used_axis(
                sizes.0.size,
                own_avail.w,
                min_c.w,
                max_c.w,
                content.w,
                decl_min.w,
                decl_max.w,
            ),
            used_axis(
                sizes.1.size,
                own_avail.h,
                min_c.h,
                max_c.h,
                content.h,
                decl_min.h,
                decl_max.h,
            ),
        );
        (used, min_c, max_c)
    }

    /// Measure every in-flow item of a grid with the viewport as its space.
    /// 以视口为可用空间测量网格的每个流内项目。
    fn measure_grid_items(
        &mut self,
        tree: &mut Tree,
        nid: NodeId,
        _params: &crate::tree::ContainerParams,
        inner: Size,
        count: &mut usize,
    ) -> Vec<NodeId> {
        let mut kids = Vec::new();
        let child_count = tree.children_of(Some(nid)).len();
        for i in 0..child_count {
            let Some(kid) = tree.child_at(Some(nid), i) else {
                continue;
            };
            let (res, c) = self.measure_node(tree, kid, Constraints::loose(inner));
            *count += c;
            if let Some(n) = tree.get_mut(kid) {
                n.rect.size = res.size;
                n.min_content = res.min_content;
                n.max_content = res.max_content;
            }
            // Measured, but they own no cell: floating and out-of-flow items alike.
            // 照常测量，但不占单元格：浮起与流外的项目都是。
            if tree.floats(kid) || tree.out_of_flow(kid) {
                continue;
            }
            kids.push(kid);
        }
        kids
    }

    /// Top-down grid placement: assign every item its cell, then align it inside.
    /// 自上而下的网格定位：给每个项目分配单元格，再在格内对齐。
    fn place_grid(
        &mut self,
        tree: &mut Tree,
        nid: NodeId,
        params: &crate::tree::ContainerParams,
        origin: crate::geom::Point,
        content: Size,
        stats: &mut LayoutStats,
    ) {
        let mut kids = Vec::new();
        let count = tree.children_of(Some(nid)).len();
        for i in 0..count {
            let Some(kid) = tree.child_at(Some(nid), i) else {
                continue;
            };
            if tree.out_of_flow(kid) {
                // Placed by the OOF pass, which runs after every in-flow box is down.
                // 由 OOF 那一趟定位，它在所有流内盒子落定之后运行。
                continue;
            }
            if tree.floats(kid) {
                let size = tree.get(kid).map(|n| n.rect.size).unwrap_or(Size::ZERO);
                self.place_node(tree, kid, Rect::from_origin_size(origin, size), stats);
            } else {
                kids.push(kid);
            }
        }
        let sizes = tree
            .get(nid)
            .map(|n| n.size_class.axes())
            .unwrap_or_else(|| SizeClass::fixed(0.0, 0.0).axes());
        let definite = (
            !matches!(sizes.0.size, crate::layout::Sizing::Fit),
            !matches!(sizes.1.size, crate::layout::Sizing::Fit),
        );
        let layout = grid_layout(tree, &kids, params, content, definite, false);
        let gap = params.gap;
        let starts = |v: &[f32]| {
            let mut out = Vec::with_capacity(v.len());
            let mut acc = 0.0;
            for s in v {
                out.push(acc);
                acc += s + gap;
            }
            out
        };
        let xs = starts(&layout.widths);
        let ys = starts(&layout.heights);
        for (i, kid) in kids.iter().enumerate() {
            let Some(cell) = layout.cells.get(i).copied() else {
                continue;
            };
            let span = |v: &[f32], start: usize, span: usize| -> f32 {
                v[start..(start + span).min(v.len())].iter().sum::<f32>()
                    + gap * span.saturating_sub(1) as f32
            };
            let cell_w = span(&layout.widths, cell.col, cell.col_span);
            let cell_h = span(&layout.heights, cell.row, cell.row_span);
            let Some(n) = tree.get(*kid) else { continue };
            let (sc, grid, measured) = (n.size_class, n.grid, n.rect.size);
            // The margin sits outside the item: it offsets it and shrinks the cell it aligns in.
            // 外边距在项目之外：它推开项目，也缩小项目对齐用的那个单元格。
            let m = flow_margin(tree, *kid, false);
            let (w, dx) = place_in_cell(
                (cell_w - m.left - m.right).max(0.0),
                grid.justify,
                sc.width,
                measured.w,
            );
            let (h, dy) = place_in_cell(
                (cell_h - m.top - m.bottom).max(0.0),
                grid.align,
                sc.height,
                measured.h,
            );
            let rect = Rect::from_origin_size(
                crate::geom::Point::new(
                    origin.x + xs[cell.col] + m.left + dx,
                    origin.y + ys[cell.row] + m.top + dy,
                ),
                Size::new(w, h),
            );
            self.place_node(tree, *kid, rect, stats);
        }
        if let Some(n) = tree.get_mut(nid) {
            n.scroll_extent = Size::new(
                layout.widths.iter().sum::<f32>() + gap * layout.widths.len().saturating_sub(1) as f32,
                layout.heights.iter().sum::<f32>() + gap * layout.heights.len().saturating_sub(1) as f32,
            );
        }
    }
}

#[cfg(test)]
mod tests {
    use crate::layout::LayoutEngine;

    /// A stack overlays its children: same origin, parent sized by the largest layer.
    /// 叠放容器把子节点叠在一起：同一原点，父尺寸取最大的一层。
    #[test]
    fn a_stack_overlays_its_children_instead_of_stacking_them_down_the_box() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .cross_align(0.0)
                .child(
                Decl::container(Id::str("stack"), NodeKind::Stack)
                    .child(
                        Decl::container(Id::str("wide"), NodeKind::Box)
                            .size(crate::layout::SizeClass::fixed(120.0, 20.0)),
                    )
                    .child(
                        Decl::container(Id::str("tall"), NodeKind::Box)
                            .size(crate::layout::SizeClass::fixed(40.0, 50.0)),
                    ),
            ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(200.0, 200.0)));

        let wide = tree.get(tree.find_by_id(Id::str("wide")).unwrap()).unwrap();
        let tall = tree.get(tree.find_by_id(Id::str("tall")).unwrap()).unwrap();
        assert_eq!(
            (wide.rect.origin.x, wide.rect.origin.y),
            (tall.rect.origin.x, tall.rect.origin.y),
            "both layers sit at the content origin"
        );
        let stack = tree.get(tree.find_by_id(Id::str("stack")).unwrap()).unwrap();
        assert_eq!(
            (stack.rect.size.w, stack.rect.size.h),
            (120.0, 50.0),
            "the stack demands the widest and tallest layer, not their sum"
        );
    }

    /// A stack's alignment moves a smaller layer inside the content box, on both axes.
    /// 叠放容器的对齐把较小的层在内容盒里挪动，两个轴都生效。
    #[test]
    fn a_stack_aligns_a_smaller_layer_inside_its_content_box() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .cross_align(0.0)
                .child(
                    Decl::container(Id::str("slot"), NodeKind::Stack)
                        .size(crate::layout::SizeClass::fixed(20.0, 20.0))
                        .stack_align(OverlayAlign::Center)
                        .child(
                            Decl::container(Id::str("glyph"), NodeKind::Box)
                                .size(crate::layout::SizeClass::fixed(12.0, 12.0)),
                        ),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(100.0, 100.0)));

        let slot = tree.get(tree.find_by_id(Id::str("slot")).unwrap()).unwrap();
        let glyph = tree.get(tree.find_by_id(Id::str("glyph")).unwrap()).unwrap();
        assert_eq!(
            (
                glyph.rect.origin.x - slot.rect.origin.x,
                glyph.rect.origin.y - slot.rect.origin.y
            ),
            (4.0, 4.0),
            "the layer takes half of each axis's slack"
        );
    }

    /// A fitting item's hint caps it but never widens it: content decides the basis.
    /// 适应内容的项，hint 只封顶不撑宽：基准由内容决定。
    #[test]
    fn a_fitting_item_hugs_its_content_under_a_comfort_hint() {
        fn line(id: &'static str, content_w: f32) -> Decl {
            Decl::container(Id::str(id), NodeKind::Row)
                .size(crate::layout::SizeClass::fixed(400.0, 50.0))
                .child(
                    Decl::container(Id::of((id, "hug")), NodeKind::Box)
                        .size(crate::layout::SizeClass {
                            width: crate::layout::AxisSize::hug(100.0, 240.0),
                            height: crate::layout::AxisSize::hug(0.0, 0.0),
                            grow_x: crate::layout::Grow::No,
                            grow_y: crate::layout::Grow::No,
                        })
                        .child(
                            Decl::container(Id::of((id, "inner")), NodeKind::Box).size(
                                crate::layout::SizeClass::fixed(content_w, 20.0),
                            ),
                        ),
                )
        }
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .cross_align(0.0)
                .child(line("wide", 150.0))
                .child(line("narrow", 40.0)),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(400.0, 200.0)));

        let width = |id: &'static str| {
            let decl = tree.find_by_id(Id::of((id, "hug"))).unwrap();
            tree.get(decl).unwrap().rect.size.w
        };
        assert_eq!(width("wide"), 150.0, "content between the bounds is kept as is");
        assert_eq!(width("narrow"), 100.0, "the lower bound still lifts short content");
    }

    /// An in-flow margin offsets the child and takes its share of both axes.
    /// 流内外边距推开子节点，并在两轴上各占一份空间。
    #[test]
    fn an_in_flow_margin_offsets_the_child_and_consumes_its_share_of_the_line() {
        use crate::geom::Insets;
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Row)
                .size(crate::layout::SizeClass::fixed(200.0, 40.0))
                .child(
                    Decl::container(Id::str("a"), NodeKind::Box)
                        .size(crate::layout::SizeClass::fixed(50.0, 20.0))
                        .margin(Insets {
                            left: 10.0,
                            right: 20.0,
                            ..Insets::ZERO
                        }),
                )
                .child(
                    Decl::container(Id::str("b"), NodeKind::Box)
                        .size(crate::layout::SizeClass::fixed(30.0, 20.0))
                        .margin(Insets {
                            left: 5.0,
                            top: 7.0,
                            ..Insets::ZERO
                        }),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(200.0, 40.0)));

        let rect = |id: &'static str| tree.get(tree.find_by_id(Id::str(id)).unwrap()).unwrap().rect;
        assert_eq!(
            (rect("a").origin.x, rect("a").origin.y),
            (10.0, 0.0),
            "the lead margin pushes the child off the content edge"
        );
        assert_eq!(
            (rect("b").origin.x, rect("b").origin.y),
            (85.0, 7.0),
            "the main-axis margin lands between the two, the cross-axis one lowers b"
        );
    }

    /// Padding belongs to the box: the line wraps inside it and the box reports it.
    /// 内边距属于盒子：行在盒内换行，盒子也把内边距算进自己的尺寸。
    #[test]
    fn a_padded_text_wraps_inside_its_padding_and_sizes_with_it() {
        // MonospaceMeasure: 10px characters are 6 wide, so "abc def" is 42 and its longest
        // word 18. With 10pt on every side the box must be 20 wider and 20 taller.
        // MonospaceMeasure：10 号字宽 6，故 "abc def" 是 42、最长词 18；四边 10pt 后盒子
        // 必须宽 20、高 20。
        let mut text = paragraph("text", "abc def".into(), 10.0, f32::INFINITY);
        text.size_class.height = crate::layout::AxisSize::hug(0.0, f32::INFINITY);
        text.box_model.padding = crate::geom::Insets::all(10.0);
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Stack)
                .size(crate::layout::SizeClass::fixed(100.0, 200.0))
                .child(text),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(100.0, 200.0)));
        let node = tree.get(tree.find_by_id(Id::str("text")).unwrap()).unwrap();
        assert_eq!(node.wrap_width, 80.0, "the line wraps inside the padding");
        assert_eq!(node.rect.size.w, 62.0, "42 of text plus 20 of padding");
        assert_eq!(node.rect.size.h, 33.0, "a 13 line box plus 20 of padding");
        assert_eq!(node.min_content.w, 38.0, "18 of longest word plus 20 of padding");
    }

    /// A child the line squeezes reflows at the width it actually gets, not the wider one
    /// it measured at. 被行压缩的子节点按其实得宽度重新排版，而不是按测量时更宽的宽度。
    #[test]
    fn a_squeezed_child_reflows_at_the_width_the_line_gives_it() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("row"), NodeKind::Row)
                .size(crate::layout::SizeClass::fixed(100.0, 200.0))
                .child(
                    Decl::container(Id::str("fixed"), NodeKind::Box)
                        .size(crate::layout::SizeClass::fixed(60.0, 10.0)),
                )
                .child(paragraph("text", "abc def ghi jkl mno pqr".into(), 10.0, f32::INFINITY)),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(100.0, 200.0)));
        let text = tree.get(tree.find_by_id(Id::str("text")).unwrap()).unwrap();
        assert_eq!(text.rect.size.w, 40.0, "the line leaves the text what the box does not take");
        assert_eq!(text.wrap_width, 40.0, "the text wraps at the width it got");
        let inline = text.inline.as_ref().expect("the text was laid out");
        assert_eq!(inline.lines.len(), 4, "and takes the lines that width needs");
    }

    /// A margin belongs to the declaration, not to a container body: a text leaf takes one.
    /// 外边距属于声明而非容器实体：文本叶子同样能带外边距。
    #[test]
    fn a_text_leafs_margin_offsets_it_like_any_other_child() {
        use crate::geom::Insets;
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Row)
                .size(crate::layout::SizeClass::fixed(200.0, 40.0))
                .child(paragraph("a", "x".into(), 10.0, 200.0))
                .child(
                    paragraph("b", "y".into(), 10.0, 200.0).margin(Insets {
                        left: 12.0,
                        ..Insets::ZERO
                    }),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(200.0, 40.0)));

        let rect = |id: &'static str| tree.get(tree.find_by_id(Id::str(id)).unwrap()).unwrap().rect;
        assert_eq!(
            rect("b").origin.x - (rect("a").origin.x + rect("a").size.w),
            12.0,
            "the leaf's margin must separate it from the previous child"
        );
    }

    /// A switchable row stacks once its children no longer share a line, and then reads
    /// the alternate margin each child declared for that arrangement.
    /// 可切换的行在子节点无法共处一行时改为堆叠，并改读各子节点为那种排法声明的替代边距。
    #[test]
    fn a_switchable_row_stacks_when_its_children_no_longer_fit() {
        use crate::geom::Insets;
        use crate::layout::AxisSwitch;
        let solve = |width: f32| {
            let mut tree = Tree::new();
            let inline = |id: &'static str, top: f32, alt_top: f32| {
                Decl::container(Id::str(id), NodeKind::Box)
                    .size(crate::layout::SizeClass::fixed(80.0, 20.0))
                    .margin(Insets {
                        left: 12.0,
                        top,
                        ..Insets::ZERO
                    })
                    .margin_alt(Insets {
                        top: alt_top,
                        ..Insets::ZERO
                    })
            };
            tree.apply(
                &Decl::container(Id::str("root"), NodeKind::Column)
                    .size(crate::layout::SizeClass::fixed(width, 200.0))
                    .child(
                        Decl::container(Id::str("bar"), NodeKind::Row)
                            .switch_axis(AxisSwitch { max_cross: None })
                            .child(inline("a", 14.0, 4.0))
                            .child(inline("b", 8.0, 12.0)),
                    ),
            );
            let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
            let root = tree.root().unwrap();
            engine.solve(&mut tree, root, Constraints::loose(Size::new(width, 200.0)));
            let rect =
                |id: &'static str| tree.get(tree.find_by_id(Id::str(id)).unwrap()).unwrap().rect;
            (rect("a"), rect("b"), rect("bar"))
        };
        // 12 + 80 + 12 + 80 = 184 fits a 400-wide bar.
        let (a, b, bar) = solve(400.0);
        assert_eq!((a.origin.x, a.origin.y), (12.0, 14.0), "a leads the line");
        assert_eq!((b.origin.x, b.origin.y), (104.0, 8.0), "b follows it");
        assert_eq!(bar.size.h, 34.0, "the bar is one line tall: 14 above a 20px child");

        let (a, b, bar) = solve(150.0);
        assert_eq!((a.origin.x, a.origin.y), (0.0, 4.0), "a starts the stack");
        assert_eq!((b.origin.x, b.origin.y), (0.0, 36.0), "b sits under it");
        assert_eq!(bar.size.h, 56.0, "4 + 20 + 12 + 20");
    }

    /// A row whose child has already wrapped past `max_cross` stacks too.
    /// A stretching child stays inside the fixed width of the column that holds it.
    /// 撑满的子节点不会越出所在列的固定宽度。
    #[test]
    fn a_stretching_child_stays_inside_its_fixed_width_column() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(320.0, 200.0))
                .child(
                    Decl::container(Id::str("bar"), NodeKind::Box)
                        .size(crate::layout::SizeClass {
                            width: crate::layout::AxisSize::fill(0.0, 0.0),
                            height: crate::layout::AxisSize::hug(0.0, 0.0),
                            grow_x: crate::layout::Grow::No,
                            grow_y: crate::layout::Grow::No,
                        })
                        .child(Decl::container(Id::str("row"), NodeKind::Row).child(
                            paragraph("long", "word ".repeat(40), 10.0, f32::INFINITY),
                        )),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(320.0, 200.0)));
        let rect = |id: &'static str| tree.get(tree.find_by_id(Id::str(id)).unwrap()).unwrap().rect;
        assert_eq!(rect("bar").size.w, 320.0, "the bar fills the column, not its content");
    }

    /// 子节点已换行到超过 `max_cross` 的行同样改为堆叠。
    #[test]
    fn a_switchable_row_stacks_when_a_child_outgrows_the_allowed_line() {
        use crate::layout::AxisSwitch;
        let solve = |max_cross: Option<f32>| {
            let mut tree = Tree::new();
            tree.apply(
                &Decl::container(Id::str("root"), NodeKind::Column)
                    .size(crate::layout::SizeClass::fixed(400.0, 200.0))
                    .child(
                        Decl::container(Id::str("bar"), NodeKind::Row)
                            .switch_axis(AxisSwitch { max_cross })
                            .child(
                                Decl::container(Id::str("a"), NodeKind::Box)
                                    .size(crate::layout::SizeClass::fixed(60.0, 60.0)),
                            )
                            .child(
                                Decl::container(Id::str("b"), NodeKind::Box)
                                    .size(crate::layout::SizeClass::fixed(60.0, 20.0)),
                            ),
                    ),
            );
            let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
            let root = tree.root().unwrap();
            engine.solve(&mut tree, root, Constraints::loose(Size::new(400.0, 200.0)));
            tree.get(tree.find_by_id(Id::str("b")).unwrap()).unwrap().rect
        };
        assert_eq!(solve(None).origin.x, 60.0, "without a limit the two share a line");
        let b = solve(Some(48.0));
        assert_eq!(
            (b.origin.x, b.origin.y),
            (0.0, 60.0),
            "a child taller than the allowed line pushes the row into a stack"
        );
    }

    /// A hugging container includes its children's margins in its own extent.
    /// 适应内容的容器把子节点的外边距算进自身范围。
    #[test]
    fn a_hugging_container_counts_its_childrens_margins() {
        use crate::geom::Insets;
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .cross_align(0.0)
                .child(
                    Decl::container(Id::str("line"), NodeKind::Row)
                        .child(
                            Decl::container(Id::str("a"), NodeKind::Box)
                                .size(crate::layout::SizeClass::fixed(50.0, 20.0))
                                .margin(Insets {
                                    left: 10.0,
                                    right: 20.0,
                                    ..Insets::ZERO
                                }),
                        )
                        .child(
                            Decl::container(Id::str("b"), NodeKind::Box)
                                .size(crate::layout::SizeClass::fixed(30.0, 20.0))
                                .margin(Insets {
                                    left: 5.0,
                                    ..Insets::ZERO
                                }),
                        ),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(400.0, 200.0)));

        let line = tree.get(tree.find_by_id(Id::str("line")).unwrap()).unwrap();
        assert_eq!(line.rect.size.w, 115.0, "50 + 10 + 20 + 5 + 30");
    }

    /// An overlay hangs off its anchor and is not cut by the clip of where it is declared.
    /// 浮层挂在锚点上，不被声明处的裁剪切掉。
    #[test]
    fn an_overlay_escapes_the_clip_of_its_declaring_ancestor() {
        use crate::layout::{Anchor, Clip, Overflow, OverlayPlacement};
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(200.0, 200.0))
                .child(
                    Decl::container(Id::str("clip"), NodeKind::Column)
                        .size(crate::layout::SizeClass::fixed(100.0, 40.0))
                        .clip(Clip {
                            x: Overflow::Hidden,
                            y: Overflow::Hidden,
                        })
                        .child(
                            Decl::container(Id::str("anchor"), NodeKind::Box)
                                .size(crate::layout::SizeClass::fixed(40.0, 20.0)),
                        )
                        .child(
                            Decl::container(Id::str("panel"), NodeKind::Box)
                                .size(crate::layout::SizeClass::fixed(60.0, 80.0))
                                .overlay(OverlayPlacement::below(Anchor::Node(Id::str(
                                    "anchor",
                                )))),
                        ),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(200.0, 200.0)));

        let panel = tree.get(tree.find_by_id(Id::str("panel")).unwrap()).unwrap();
        assert_eq!(
            (panel.rect.origin.x, panel.rect.origin.y),
            (0.0, 20.0),
            "the panel unfolds right under its anchor"
        );
        assert!(
            panel.mask.max_y() >= panel.rect.max_y() - 0.01,
            "the declaring ancestor's clip must not cut the overlay: mask {:?}",
            panel.mask
        );
    }

    /// A lifted node keeps its slot but paints above the clip it was declared inside.
    /// 被抬起的节点保留自己的槽位，却画在声明处的裁剪之上。
    #[test]
    fn a_lifted_node_keeps_its_slot_and_escapes_the_clip_around_it() {
        use crate::layout::{Clip, Overflow};
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(200.0, 200.0))
                .child(
                    Decl::container(Id::str("clip"), NodeKind::Column)
                        .size(crate::layout::SizeClass::fixed(100.0, 40.0))
                        .clip(Clip {
                            x: Overflow::Hidden,
                            y: Overflow::Hidden,
                        })
                        .child(
                            Decl::container(Id::str("slot"), NodeKind::Box)
                                .size(crate::layout::SizeClass::fixed(100.0, 20.0)),
                        )
                        .child(
                            Decl::container(Id::str("lifted"), NodeKind::Box)
                                .size(crate::layout::SizeClass::fixed(50.0, 20.0))
                                .offset(0.0, 60.0)
                                .lifted(),
                        )
                        .child(
                            Decl::container(Id::str("tail"), NodeKind::Box)
                                .size(crate::layout::SizeClass::fixed(100.0, 20.0)),
                        ),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(200.0, 200.0)));

        let lifted = tree.get(tree.find_by_id(Id::str("lifted")).unwrap()).unwrap();
        assert_eq!(lifted.rect.origin.y, 20.0, "the slot stays in the flow");
        assert_eq!(
            lifted.visual_rect().origin.y,
            80.0,
            "the offset only moves the pixels"
        );
        assert_eq!(
            lifted.mask.max_y(),
            200.0,
            "the clip around it must not cut the lifted node: mask {:?}",
            lifted.mask
        );
        let last = *tree.walk().last().unwrap();
        assert_eq!(
            tree.get(last).map(|n| n.id),
            Some(Id::str("lifted")),
            "painted last, so it also hits first"
        );
    }

    /// A panel matching its anchor keeps the minimum a short trigger cannot provide.
    /// 跟随锚点宽度的面板保留最小值：很窄的触发器提供不了这个宽度。
    #[test]
    fn a_width_matching_panel_keeps_its_minimum_width() {
        use crate::layout::{Anchor, OverlayPlacement};
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(200.0, 200.0))
                .child(
                    Decl::container(Id::str("anchor"), NodeKind::Box)
                        .size(crate::layout::SizeClass::fixed(40.0, 20.0)),
                )
                .child(
                    Decl::container(Id::str("panel"), NodeKind::Column)
                        .size(crate::layout::SizeClass {
                            width: crate::layout::AxisSize::hug(0.0, 0.0),
                            height: crate::layout::AxisSize::fixed(60.0),
                            grow_x: crate::layout::Grow::No,
                            grow_y: crate::layout::Grow::No,
                        })
                        .child(
                            Decl::container(Id::str("row"), NodeKind::Box)
                                .size(crate::layout::SizeClass::fixed(10.0, 10.0)),
                        )
                        .overlay(
                            OverlayPlacement::below(Anchor::Node(Id::str("anchor")))
                                .match_anchor_width(true)
                                .min_width(80.0),
                        ),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(200.0, 200.0)));

        let panel = tree.get(tree.find_by_id(Id::str("panel")).unwrap()).unwrap();
        assert_eq!(panel.rect.size.w, 80.0, "40-wide anchor, 80 minimum");
    }

    /// A panel told to span its anchor is measured inside the anchor's box, so a fill child
    /// reaches the anchor's height rather than the viewport's.
    /// 要求与锚点同高的面板在锚点的盒子里量尺寸，撑满的子节点因此够到锚点的高度而非视口。
    #[test]
    fn an_overlay_spanning_its_anchor_takes_the_anchors_height() {
        use crate::layout::{Anchor, OverlayPlacement, Side};
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Box)
                .size(crate::layout::SizeClass::fixed(300.0, 400.0))
                .child(
                    Decl::container(Id::str("host"), NodeKind::Box)
                        .size(crate::layout::SizeClass::fixed(300.0, 120.0))
                        .child(
                            Decl::container(Id::str("panel"), NodeKind::Column)
                                .size(crate::layout::SizeClass {
                                    width: crate::layout::AxisSize::fixed(80.0),
                                    height: crate::layout::AxisSize::fill(0.0, 0.0),
                                    grow_x: crate::layout::Grow::No,
                                    grow_y: crate::layout::Grow::No,
                                })
                                .overlay(
                                    OverlayPlacement::below(Anchor::Node(Id::str("host")))
                                        .side(Side::Left)
                                        // The pane overlaps its host by its own width: it
                                        // starts on the host's left edge, not beside it.
                                        // 窗格以自身宽度压住宿主：起于宿主左缘，而非停在旁边。
                                        .offset(-80.0)
                                        .flip(false)
                                        .match_anchor_height(true),
                                ),
                        ),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(300.0, 400.0)));

        let panel = tree.get(tree.find_by_id(Id::str("panel")).unwrap()).unwrap();
        assert_eq!(
            (panel.rect.origin.x, panel.rect.origin.y),
            (0.0, 0.0),
            "the pane starts on the host's own left edge"
        );
        assert_eq!(
            panel.rect.size.h, 120.0,
            "a fill child reached the viewport instead of the 120-high host"
        );
    }

    /// A panel that would leave the viewport flips to the other side of its anchor.
    /// 会越出视口的面板翻到锚点的另一侧。
    #[test]
    fn an_overlay_flips_above_when_it_would_overflow_the_viewport() {
        use crate::layout::{Anchor, OverlayPlacement};
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(200.0, 200.0))
                .child(
                    Decl::container(Id::str("spacer"), NodeKind::Box)
                        .size(crate::layout::SizeClass::fixed(200.0, 150.0)),
                )
                .child(
                    Decl::container(Id::str("anchor"), NodeKind::Box)
                        .size(crate::layout::SizeClass::fixed(40.0, 20.0)),
                )
                .child(
                    Decl::container(Id::str("panel"), NodeKind::Box)
                        .size(crate::layout::SizeClass::fixed(60.0, 60.0))
                        .overlay(OverlayPlacement::below(Anchor::Node(Id::str("anchor")))),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(200.0, 200.0)));

        let panel = tree.get(tree.find_by_id(Id::str("panel")).unwrap()).unwrap();
        assert_eq!(
            (panel.rect.origin.y, panel.rect.max_y()),
            (90.0, 150.0),
            "below would reach 230 in a 200-tall viewport, so the panel sits above the anchor"
        );
    }

    /// A row squeezes a scrollable child to its own width instead of letting it overflow.
    /// 行把可滚动的子节点压到自身宽度，而不是让它溢出。
    #[test]
    fn a_row_squeezes_a_scrollable_child_to_the_line_before_it_overflows() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Row)
                .size(crate::layout::SizeClass::fixed(100.0, 40.0))
                .child(
                    Decl::container(Id::str("list"), NodeKind::Row)
                        .clip(crate::layout::Clip {
                            x: crate::layout::Overflow::Scroll,
                            y: crate::layout::Overflow::Hidden,
                        })
                        .child(
                            Decl::container(Id::str("wide"), NodeKind::Box)
                                .size(crate::layout::SizeClass::fixed(150.0, 20.0)),
                        ),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(100.0, 40.0)));

        let list = tree.get(tree.find_by_id(Id::str("list")).unwrap()).unwrap();
        assert_eq!(list.rect.size.w, 100.0, "the list takes the line, not its content");
        assert_eq!(list.scroll_extent.w, 150.0, "the content still overflows inside it");
    }

    /// An overlay takes no slot in the flow and lands at its parent's content origin.
    /// 悬浮节点在流中不占位置，并落在父的内容原点。
    #[test]
    fn an_overlay_child_takes_no_space_in_the_flow() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .child(Decl::container(Id::str("flow"), NodeKind::Column).size(
                    crate::layout::SizeClass::fixed(80.0, 40.0),
                ))
                .child(Decl::container(Id::str("float"), NodeKind::Overlay).size(
                    crate::layout::SizeClass::fixed(60.0, 30.0),
                )),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(200.0, 200.0)));

        let flow = tree.get(tree.find_by_id(Id::str("flow")).unwrap()).unwrap();
        let float = tree.get(tree.find_by_id(Id::str("float")).unwrap()).unwrap();
        assert_eq!(
            float.rect.size.h, 30.0,
            "the overlay keeps its own size instead of being squeezed by the flow"
        );
        assert_eq!(
            float.rect.origin.y, flow.rect.origin.y,
            "the overlay sits at the content origin, not after its siblings"
        );
    }

    /// Adding an overlay must not grow its parent: it takes no slot and no gap.
    /// 加一个悬浮节点不得把父容器撑大：它既不占位置，也不占间隙。
    #[test]
    fn an_overlay_child_does_not_add_a_gap_to_the_parents_size() {
        let build = |with_overlay: bool| {
            let mut inner = Decl::container(Id::str("inner"), NodeKind::Column)
                .gap(10.0)
                .child(Decl::container(Id::str("a"), NodeKind::Box).size(
                    crate::layout::SizeClass::fixed(50.0, 40.0),
                ))
                .child(Decl::container(Id::str("b"), NodeKind::Box).size(
                    crate::layout::SizeClass::fixed(50.0, 40.0),
                ));
            if with_overlay {
                inner = inner.child(
                    Decl::container(Id::str("float"), NodeKind::Overlay)
                        .size(crate::layout::SizeClass::fixed(180.0, 180.0)),
                );
            }
            let mut tree = Tree::new();
            tree.apply(&Decl::container(Id::str("root"), NodeKind::Column).child(inner));
            let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
            let root = tree.root().unwrap();
            engine.solve(&mut tree, root, Constraints::loose(Size::new(200.0, 400.0)));
            let rect = |id: &'static str| tree.get(tree.find_by_id(Id::str(id)).unwrap()).unwrap().rect;
            (rect("inner"), rect("a"), rect("b"))
        };
        let plain = build(false);
        assert_eq!(plain.0.size.h, 90.0, "40 + 10 + 40");
        assert_eq!(
            build(true),
            plain,
            "a trailing overlay added one gap and grew the parent by it"
        );
    }

    /// A modal covers its target, not the slot the tree gave it: the nearest declared host
    /// for `Proximate`, the window for `Global`.
    /// 模态盖住它的目标而不是树给它的位置：`Proximate` 取最近的声明宿主，`Global` 取窗口。
    #[test]
    fn a_modal_covers_its_target_instead_of_the_slot_the_tree_gave_it() {
        let solve = |target: crate::tree::ModalTarget| {
            let panel = Decl::container(Id::str("panel"), NodeKind::Box)
                .size(crate::layout::SizeClass::fixed(200.0, 100.0))
                .modal_host()
                .child(
                    Decl::container(Id::str("modal"), NodeKind::Box)
                        .size(crate::layout::SizeClass::fixed(40.0, 20.0))
                        .modal(target),
                );
            let root = Decl::container(Id::str("root"), NodeKind::Column)
                .padding(crate::geom::Insets::all(30.0))
                .child(panel);
            let mut tree = Tree::new();
            tree.apply(&root);
            let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
            let root = tree.root().unwrap();
            engine.solve(&mut tree, root, Constraints::loose(Size::new(400.0, 300.0)));
            let rect = |id: &'static str| tree.get(tree.find_by_id(Id::str(id)).unwrap()).unwrap().rect;
            (rect("panel"), rect("modal"))
        };
        let (panel, proximate) = solve(crate::tree::ModalTarget::Proximate);
        assert_eq!(panel.origin, crate::geom::Point::new(30.0, 30.0), "the panel sits in the padding");
        assert_eq!(proximate, panel, "the nearest declared host is the target");
        let (_, global) = solve(crate::tree::ModalTarget::Global);
        assert_eq!(
            global,
            Rect::from_origin_size(crate::geom::Point::ZERO, Size::new(400.0, 300.0)),
            "the window is the target, padding and all"
        );
    }

    /// A modal follows its host through a resize: it is placed on the host's rect in the
    /// same pass, so there is no second source of truth to go stale.
    /// 模态跟随宿主一起改变尺寸：它在同一趟里被放到宿主的矩形上，
    /// 因此没有第二份会变陈旧的事实来源。
    #[test]
    fn a_modal_follows_a_host_that_grows_with_the_window() {
        let solve = |h: f32| {
            let panel = Decl::container(Id::str("panel"), NodeKind::Box)
                .size(crate::layout::SizeClass {
                    width: crate::layout::AxisSize::fill(0.0, 0.0),
                    height: crate::layout::AxisSize::fill(0.0, 0.0),
                    grow_x: crate::layout::Grow::Yes,
                    grow_y: crate::layout::Grow::Yes,
                })
                .modal_host()
                .child(
                    Decl::container(Id::str("modal"), NodeKind::Box)
                        .size(crate::layout::SizeClass::fixed(40.0, 20.0))
                        .modal(crate::tree::ModalTarget::Proximate),
                );
            let mut tree = Tree::new();
            tree.apply(&Decl::container(Id::str("root"), NodeKind::Column).child(panel));
            let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
            let root = tree.root().unwrap();
            engine.solve(&mut tree, root, Constraints::loose(Size::new(200.0, h)));
            let rect = |id: &'static str| tree.get(tree.find_by_id(Id::str(id)).unwrap()).unwrap().rect;
            (rect("panel"), rect("modal"))
        };
        let (panel, modal) = solve(300.0);
        assert_eq!(modal, panel, "the modal covers the host it resolved to");
        let (grown, moved) = solve(500.0);
        assert!(grown.size.h > panel.size.h, "the host got taller: {grown:?}");
        assert_eq!(moved, grown, "and the modal came with it, in the same frame");
    }

    /// A fixed-size child in a Column keeps its width and sits where `cross_pos` says.
    /// Column 里固定尺寸的子节点保持自身宽度，并按 `cross_pos` 落位。
    #[test]
    fn a_cross_positioned_child_is_centred_in_the_space_it_left_over() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(100.0, 40.0))
                .cross_align(0.0)
                .cross_pos(0.5)
                .child(
                    Decl::container(Id::str("icon"), NodeKind::Box)
                        .size(crate::layout::SizeClass::fixed(24.0, 24.0)),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(100.0, 40.0)));
        let icon = tree.get(tree.find_by_id(Id::str("icon")).unwrap()).unwrap();
        assert_eq!(icon.rect.size.w, 24.0, "the child keeps its own width");
        assert_eq!(icon.rect.origin.x, 38.0, "centred: (100 - 24) / 2");
    }

    /// A stretched child whose content is taller than the line shrinks to the line, not
    /// past it: a scroll viewport must not be grown by the content it is meant to scroll.
    /// 内容高于行高的拉伸子节点收缩到行高，而不是被内容撑开：滚动视口不该被它要滚动的内容撑大。
    #[test]
    fn a_stretched_scroller_shrinks_to_the_line_instead_of_growing_past_it() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Row)
                .size(crate::layout::SizeClass::fixed(100.0, 40.0))
                .child(
                    Decl::container(Id::str("nav"), NodeKind::Column)
                        .size(crate::layout::SizeClass {
                            width: crate::layout::AxisSize::fixed(50.0),
                            height: crate::layout::AxisSize::fill(0.0, 0.0),
                            grow_x: crate::layout::Grow::No,
                            grow_y: crate::layout::Grow::No,
                        })
                        .scrollable()
                        .child(
                            Decl::container(Id::str("tall"), NodeKind::Box)
                                .size(crate::layout::SizeClass::fixed(50.0, 200.0)),
                        ),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(100.0, 40.0)));
        let nav = tree.get(tree.find_by_id(Id::str("nav")).unwrap()).unwrap();
        assert_eq!(nav.rect.size.h, 40.0, "the scroller takes the line's height");
    }

    /// A text leaf that may wrap anywhere has an infinite hint; inside a Row it must
    /// not turn the sibling widths into NaN (they then never paint).
    /// 可任意换行的文本叶子 hint 为无穷；在 Row 里它不得把兄弟宽度变成 NaN（那样就画不出来）。
    #[test]
    fn an_unbounded_text_hint_does_not_poison_sibling_widths_in_a_row() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Row)
                .size(crate::layout::SizeClass::fixed(300.0, 60.0))
                .child(
                    Decl::container(Id::str("ctl"), NodeKind::Box).size(
                        crate::layout::SizeClass::fixed(120.0, 40.0),
                    ),
                )
                // A text leaf's width hint is infinite until it is measured.
                // 文本叶子的宽度 hint 在被测量之前是无穷。
                .child(Decl {
                    id: Id::str("label"),
                    kind: NodeKind::Text,
                    shapes: Vec::new(),
                    data: crate::NodeData::Text {
                        ink: crate::geom::Color::WHITE,
                        block: crate::text::TextBlock {
                            runs: vec![crate::text::TextRun::new(
                                "a label that may wrap anywhere",
                                crate::text::TextStyle::new(14.0),
                            )],
                            align: crate::TextAlign::Start,
                            max_lines: None,
                            line_gap: 0.0,
                            indent: 0.0,
                            atoms: Vec::new(),
                        },
                        caret: None,
                        selection: None,
                        composing: None,
                        nowrap: false,
                    },
                    size_class: crate::layout::SizeClass {
                        width: crate::layout::AxisSize::hug(0.0, f32::INFINITY),
                        height: crate::layout::AxisSize::hug(14.0, 18.0),
                        ..crate::layout::SizeClass::fixed(0.0, 0.0)
                    },
                    ..Decl::container(Id::str("label"), NodeKind::Text)
                }),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(300.0, 60.0)));

        let ctl = tree.get(tree.find_by_id(Id::str("ctl")).unwrap()).unwrap();
        assert!(
            ctl.rect.size.w.is_finite() && ctl.rect.size.w > 0.0,
            "the control keeps a real width, got {}",
            ctl.rect.size.w
        );
    }

    /// A padded box hugging its text takes the text plus its padding; otherwise the box is
    /// narrower than the line inside it and the painter clips that line.
    /// 紧贴内容的带内边距盒子取其文本加内边距；否则盒子比其中一行更窄，绘制端会把这一行裁掉。
    #[test]
    fn a_padded_box_hugging_its_text_takes_the_text_plus_the_padding() {
        // MonospaceMeasure: 10px characters are 6 wide, so "Save the file" is 78 wide.
        // MonospaceMeasure：10 号字宽 6，故 "Save the file" 宽 78。
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(400.0, 200.0))
                .cross_align(0.0)
                .child(
                    Decl::container(Id::str("panel"), NodeKind::Box)
                        .size(crate::layout::SizeClass {
                            width: crate::layout::AxisSize::hug(0.0, 320.0),
                            height: crate::layout::AxisSize::hug(0.0, 0.0),
                            ..crate::layout::SizeClass::fixed(0.0, 0.0)
                        })
                        .padding(crate::geom::Insets::new(9.0, 6.0, 9.0, 8.0))
                        .child(paragraph("text", "Save the file".into(), 10.0, 302.0)),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(400.0, 200.0)));

        let panel = tree.get(tree.find_by_id(Id::str("panel")).unwrap()).unwrap();
        let text = tree.get(tree.find_by_id(Id::str("text")).unwrap()).unwrap();
        assert_eq!(panel.rect.size.w, 78.0 + 18.0, "panel hugs text plus padding");
        assert_eq!(text.rect.size.w, 78.0, "and never squeezes the line it holds");
    }

    /// A two-line text centred in a fixed-height row keeps both lines: the placement pass
    /// once read the raw size class and capped the block at its one-line hint.
    /// 固定高的行里居中的两行文本必须保住两行：定位趟曾读原始尺寸类，把块封顶成一行的高度。
    #[test]
    fn a_multi_line_text_keeps_both_lines_when_its_row_centres_it() {
        // MonospaceMeasure: 10px characters are 6 wide and 13 high, so 60 of them at the
        // row's 300 wrap into two lines of 26.
        // MonospaceMeasure：10 号字宽 6、高 13，60 个字符在行的 300 宽下排成两行，共高 26。
        let mut text = paragraph("message", "x".repeat(60), 10.0, f32::INFINITY);
        text.size_class.width = crate::layout::AxisSize::hug(0.0, 0.0);
        text.size_class.grow_x = crate::layout::Grow::Yes;
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(400.0, 200.0))
                .cross_align(0.0)
                .child(
                    Decl::container(Id::str("bar"), NodeKind::Row)
                        .size(crate::layout::SizeClass::fixed(300.0, 68.0))
                        .cross_align(0.0)
                        .cross_pos(0.5)
                        .child(text),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(400.0, 200.0)));

        let bar = tree.get(tree.find_by_id(Id::str("bar")).unwrap()).unwrap().rect;
        let message = tree.get(tree.find_by_id(Id::str("message")).unwrap()).unwrap();
        assert_eq!(message.rect.size.h, 26.0, "both lines keep their box");
        assert_eq!(message.rect.origin.y, bar.origin.y + 21.0, "centred, not top-pinned");
    }

    /// A `fixed(200)` column must wrap its text at 200, not at the window width: the measure
    /// pass otherwise hands children the whole constraint and the text overflows the column.
    /// `fixed(200)` 的列必须按 200 换行而不是按窗口宽度：否则测量趟把整个约束交给子节点，
    /// 文字会溢出列宽。
    #[test]
    fn a_fixed_width_column_measures_its_text_within_its_own_width() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(200.0, 400.0))
                .child(Decl {
                    id: Id::str("label"),
                    kind: NodeKind::Text,
                    shapes: Vec::new(),
                    data: crate::NodeData::Text {
                        ink: crate::geom::Color::WHITE,
                        block: crate::text::TextBlock {
                            runs: vec![crate::text::TextRun::new(
                                "a label far wider than the column it sits in, long enough to wrap",
                                crate::text::TextStyle::new(10.0),
                            )],
                            align: crate::TextAlign::Start,
                            max_lines: None,
                            line_gap: 0.0,
                            indent: 0.0,
                            atoms: Vec::new(),
                        },
                        caret: None,
                        selection: None,
                        composing: None,
                        nowrap: false,
                    },
                    size_class: crate::layout::SizeClass {
                        width: crate::layout::AxisSize::hug(0.0, 200.0),
                        height: crate::layout::AxisSize::hug(0.0, 0.0),
                        ..crate::layout::SizeClass::fixed(0.0, 0.0)
                    },
                    ..Decl::container(Id::str("label"), NodeKind::Text)
                }),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(800.0, 400.0)));

        let label = tree.get(tree.find_by_id(Id::str("label")).unwrap()).unwrap();
        assert_eq!(label.wrap_width, 200.0, "wrapped at the column, not at the window");
        assert!(label.rect.size.w <= 200.0, "text overflows its column: {}", label.rect.size.w);
    }

    /// A `nowrap` text is laid out on one line inside a box too narrow for it: the line is
    /// never broken, while the box it occupies stays the one it declared.
    /// `nowrap` 文本在过窄的盒子里仍排成一行：绝不换行，而它占用的盒子仍是自己声明的那个。
    #[test]
    fn a_nowrap_text_breaks_no_line_and_keeps_its_declared_width() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(120.0, 200.0))
                .child(
                    (Decl {
                        id: Id::str("label"),
                        kind: NodeKind::Text,
                        shapes: Vec::new(),
                        data: crate::NodeData::Text {
                            ink: crate::geom::Color::WHITE,
                            block: crate::text::TextBlock {
                                runs: vec![crate::text::TextRun::new(
                                    "a line that must not wrap at one hundred and twenty",
                                    crate::text::TextStyle::new(10.0),
                                )],
                                align: crate::TextAlign::Start,
                                max_lines: None,
                                line_gap: 0.0,
                                indent: 0.0,
                                atoms: Vec::new(),
                            },
                            caret: None,
                            selection: None,
                            composing: None,
                            nowrap: false,
                        },
                        size_class: crate::layout::SizeClass {
                            width: crate::layout::AxisSize::hug(0.0, 120.0),
                            height: crate::layout::AxisSize::hug(0.0, 0.0),
                            ..crate::layout::SizeClass::fixed(0.0, 0.0)
                        },
                        ..Decl::container(Id::str("label"), NodeKind::Text)
                    })
                    .nowrap(),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(800.0, 400.0)));

        let label = tree.get(tree.find_by_id(Id::str("label")).unwrap()).unwrap();
        assert_eq!(label.wrap_width, f32::INFINITY, "measured as one line");
        assert_eq!(label.rect.size.w, 120.0, "the box it declared still bounds it");
    }

    /// A text leaf declared the way `ui_widgets::Text` declares one: the width hugs a
    /// `max_width`, the height hugs a 1.4× line box.
    /// 按 `ui_widgets::Text` 的方式声明文本叶子：宽度按 `max_width` 收窄，高度按 1.4 倍行盒。
    fn text_decl(
        id: &'static str,
        block: crate::text::TextBlock,
        max_width: f32,
        line_hint: f32,
    ) -> Decl {
        Decl {
            id: Id::str(id),
            kind: NodeKind::Text,
            shapes: Vec::new(),
            data: crate::NodeData::Text {
                ink: crate::geom::Color::WHITE,
                block,
                caret: None,
                selection: None,
                composing: None,
                nowrap: false,
            },
            size_class: crate::layout::SizeClass {
                width: crate::layout::AxisSize::hug(0.0, max_width),
                height: crate::layout::AxisSize::hug(line_hint / 1.4, line_hint),
                ..crate::layout::SizeClass::fixed(0.0, 0.0)
            },
            ..Decl::container(Id::str(id), NodeKind::Text)
        }
    }

    fn paragraph(id: &'static str, body: String, size: f32, max_width: f32) -> Decl {
        text_decl(
            id,
            crate::text::TextBlock::plain(body, crate::text::TextStyle::new(size)),
            max_width,
            size * 1.4,
        )
    }

    /// Gaps sit between lines only: n lines add n-1 of them, so the block does not grow
    /// a trailing one.
    /// 空隙只在行之间：n 行加 n-1 个，块不会多出一个尾部空隙。
    #[test]
    fn line_gap_separates_lines_without_adding_a_trailing_gap() {
        // MonospaceMeasure: 10px characters are 6 wide and 13 high, so 40 of them wrap
        // to 4 lines at a width of 60.
        // MonospaceMeasure：10 号字宽 6、行盒 13，故 40 个字符在 60 宽下排成 4 行。
        let mut block = crate::text::TextBlock::plain(
            "0123456789".repeat(4),
            crate::text::TextStyle::new(10.0),
        );
        block.line_gap = 3.0;
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(60.0, 400.0))
                .child(text_decl("para", block, 60.0, 14.0)),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(60.0, 400.0)));

        let para = tree.get(tree.find_by_id(Id::str("para")).unwrap()).unwrap();
        let layout = para.inline.as_ref().expect("a text node keeps its lines");
        let ys: Vec<f32> = layout.lines.iter().map(|l| l.y).collect();
        for (got, want) in ys.iter().zip([0.0, 16.0, 32.0, 48.0]) {
            assert!((got - want).abs() < 0.01, "line tops are {ys:?}");
        }
        let want = 4.0 * 13.0 + 3.0 * 3.0;
        assert!(
            (para.rect.size.h - want).abs() < 0.01,
            "the block is {} tall, four lines and three gaps are {want}",
            para.rect.size.h
        );
        assert!(
            (layout.height - want).abs() < 0.01,
            "the layout reports {} rather than {want}",
            layout.height
        );
    }

    /// A scrolling axis never wraps its content: the viewport scrolls over one long line.
    /// 滚动轴不给内容换行：视口在一条长线上滚动。
    #[test]
    fn a_scrolling_row_measures_its_text_unwrapped() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Row)
                .size(crate::layout::SizeClass::fixed(100.0, 40.0))
                .scrollable()
                .child(paragraph("label", "0123456789".repeat(5), 10.0, 0.0)),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(100.0, 40.0)));

        let label = tree.get(tree.find_by_id(Id::str("label")).unwrap()).unwrap();
        let lines = label.inline.as_ref().map_or(0, |l| l.lines.len());
        assert_eq!(lines, 1, "a 300-wide text wrapped inside a 100-wide scroller");
        assert_eq!(label.rect.size.w, 300.0, "the line keeps its own width");
        let root = tree.get(tree.root().unwrap()).unwrap();
        assert!(
            root.scroll_extent.w >= 300.0,
            "the scrollbar needs the content width, got {}",
            root.scroll_extent.w
        );
    }

    /// An atom is measured at its own size, never squeezed into the room left on a line.
    /// 原子按自身尺寸测量，绝不被塞进行内剩余的空间。
    #[test]
    fn an_atom_is_measured_at_the_block_width() {
        use crate::text::{AtomBox, OBJECT};
        let atom_at_line = |width: f32| {
            let mut block = crate::text::TextBlock::plain(
                format!("before {OBJECT} after"),
                crate::text::TextStyle::new(10.0),
            );
            block.atoms.push(AtomBox::new(7, Size::new(80.0, 36.0)));
            let mut tree = Tree::new();
            tree.apply(
                &Decl::container(Id::str("root"), NodeKind::Column)
                    .size(crate::layout::SizeClass::fixed(width, 400.0))
                    .child(text_decl("para", block, width, 14.0)),
            );
            let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
            let root = tree.root().unwrap();
            engine.solve(&mut tree, root, Constraints::loose(Size::new(width, 400.0)));
            let node = tree.get(tree.find_by_id(Id::str("para")).unwrap()).unwrap();
            (
                node.inline.as_ref().expect("lines").clone(),
                node.rect.size.w,
                node.min_content.w,
            )
        };
        let (layout, _, _) = atom_at_line(70.0);
        let atom = layout
            .lines
            .iter()
            .flat_map(|l| l.atoms.iter())
            .next()
            .expect("the atom is on some line");
        assert_eq!(atom.size.w, 80.0, "the atom kept its own width");
        assert!(
            layout.lines[0].atoms.is_empty(),
            "an 80-wide atom cannot share a 70-wide line"
        );
        let line = layout
            .lines
            .iter()
            .find(|l| !l.atoms.is_empty())
            .expect("some line carries the atom");
        assert!(
            line.width >= 80.0,
            "the atom's line is {} wide, narrower than the atom itself",
            line.width
        );
        // An atom is unbreakable: it floors the block's min-content, so a hugging block
        // is never narrower than the atom inside it.
        // 原子不可断：它给出块 min-content 的下限，于是适应内容的块绝不比其中的原子窄。
        let (wide, used, min_w) = atom_at_line(200.0);
        let _ = wide;
        assert!(
            min_w >= 80.0,
            "min-content is {min_w}: the U+FFFC's own advance, not the atom's width"
        );
        assert!(
            used >= 80.0,
            "the block is {used} wide, below its atom's 80"
        );
    }

    /// A top-aligned atom hangs from the line's top and grows the box downwards.
    /// 顶对齐的原子挂在行盒顶边，把行盒向下撑高。
    #[test]
    fn a_top_aligned_atom_raises_the_line_box() {
        use crate::text::{AtomBox, VerticalAlign, OBJECT};
        let mut block = crate::text::TextBlock::plain(
            format!("aa{OBJECT}"),
            crate::text::TextStyle::new(10.0),
        );
        block.atoms.push(
            AtomBox::new(2, Size::new(16.0, 40.0)).align(VerticalAlign::Top),
        );
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(200.0, 400.0))
                .child(text_decl("para", block, 200.0, 14.0)),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(200.0, 400.0)));

        let para = tree.get(tree.find_by_id(Id::str("para")).unwrap()).unwrap();
        let layout = para.inline.as_ref().expect("a text node keeps its lines");
        let line = &layout.lines[0];
        assert!(
            (line.height - 50.0).abs() < 0.01,
            "the line is {} tall: 10 ascent + 40 descent",
            line.height
        );
        assert!(
            (line.baseline - 10.0).abs() < 0.01,
            "the text baseline stays at 10, got {}",
            line.baseline
        );
        assert!(
            line.atoms[0].y.abs() < 0.01,
            "a top-aligned atom starts at the line top, got {}",
            line.atoms[0].y
        );
        assert!(para.rect.size.h >= 50.0, "the box holds the raised line");
    }

    /// The node reports its first line's baseline, not zero and not the tallest run's.
    /// 节点报告的是首行的基线，既不是 0，也不是最高 run 的。
    #[test]
    fn the_first_line_baseline_is_reported() {
        let mut block = crate::text::TextBlock::plain(
            "0123456789".to_string(),
            crate::text::TextStyle::new(10.0),
        );
        // The rest of the paragraph is twice as large, so a block-wide baseline would
        // report 20 instead of the first line's 10.
        // 段落其余部分字号翻倍，因此「整块取最大」会报 20 而不是首行的 10。
        block.runs.push(crate::text::TextRun::new(
            "0123456789".repeat(6),
            crate::text::TextStyle::new(20.0),
        ));
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(60.0, 400.0))
                .child(text_decl("para", block, 60.0, 14.0)),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(60.0, 400.0)));

        let para = tree.get(tree.find_by_id(Id::str("para")).unwrap()).unwrap();
        let layout = para.inline.as_ref().expect("a text node keeps its lines");
        assert!(layout.lines.len() > 1, "the block must wrap for this test");
        assert!(
            (para.baseline - layout.lines[0].baseline).abs() < 0.01,
            "the node reports {} but its first line sits at {}",
            para.baseline,
            layout.lines[0].baseline
        );
        assert!(
            para.baseline > 0.0 && para.baseline < 20.0,
            "the first line's baseline is {}, not 0 and not the tallest run's 20",
            para.baseline
        );
    }


    /// A wrapped paragraph is as tall as the lines it wrapped into; the declared 1.4× line
    /// box is a floor for one line, not a cap on the whole block.
    /// 换行的段落与它排出的行数等高；声明的 1.4 倍行盒是单行的下限，不是整块的上限。
    #[test]
    fn a_wrapped_paragraph_is_as_tall_as_its_lines() {
        // MonospaceMeasure: advance 0.6, line height 1.3, so 70 characters of 10px wrap to
        // 7 lines at a width of 60.
        // MonospaceMeasure：字宽 0.6、行高 1.3，故 10 号的 70 个字符在 60 宽下排成 7 行。
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(60.0, 400.0))
                .child(paragraph("para", "0123456789".repeat(7), 10.0, 60.0)),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(60.0, 400.0)));

        let para = tree.get(tree.find_by_id(Id::str("para")).unwrap()).unwrap();
        let seven = 7.0 * 10.0 * 1.3;
        assert!(
            (para.rect.size.h - seven).abs() < 0.01,
            "paragraph is {} tall, seven lines are {seven}",
            para.rect.size.h
        );
    }

    /// Two identical paragraphs in a column stack by the height they wrapped into, so the
    /// second never starts above the first's bottom and their painted lines cannot overlap.
    /// 一列里两个相同段落按换行后的高度依次排开：后者不早于前者底边，绘制的行不会重叠。
    #[test]
    fn siblings_in_a_column_never_overlap() {
        let body = "0123456789".repeat(7);
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(60.0, 400.0))
                .gap(10.0)
                .child(paragraph("a", body.clone(), 10.0, 60.0))
                .child(paragraph("b", body, 10.0, 60.0)),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(60.0, 400.0)));

        let rect = |id: &'static str| tree.get(tree.find_by_id(Id::str(id)).unwrap()).unwrap().rect;
        let (a, b) = (rect("a"), rect("b"));
        // A box shorter than its own painted lines stacks the next paragraph on top of them.
        // 盒子矮于它自己绘制的行，下一段就会压在这些行上。
        assert!(
            a.size.h >= 3.0 * 10.0 * 1.3,
            "the paragraph wrapped to several lines but its box is only {} tall",
            a.size.h
        );
        assert!(
            b.origin.y >= a.origin.y + a.size.h,
            "the second paragraph starts at {} while the first ends at {}",
            b.origin.y,
            a.origin.y + a.size.h
        );
    }

    /// An environment opened on one declaration reaches every descendant, and `None` on a
    /// child means "inherit", not "clear".
    /// 某个声明上开启的环境会到达每个后代，子节点上的 `None` 表示「继承」而不是「清除」。
    #[test]
    fn an_environment_folds_down_to_every_descendant() {
        use std::sync::Arc;
        let mark = Arc::new(7u32) as Arc<dyn std::any::Any + Send + Sync>;
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(200.0, 200.0))
                .child(
                    Decl::container(Id::str("scoped"), NodeKind::Column)
                        .env(mark.clone())
                        .child(Decl::container(Id::str("inner"), NodeKind::Column).child(
                            Decl::container(Id::str("leaf"), NodeKind::Box),
                        )),
                )
                .child(Decl::container(Id::str("outside"), NodeKind::Box)),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(200.0, 200.0)));

        // Identity, not value: the same `Arc` is handed down, so pointer equality is exact.
        // 比同一性而不是值：同一个 `Arc` 被传下去，因此指针相等是精确判据。
        let env_of = |name: &'static str, tree: &Tree| -> Option<bool> {
            let id = Id::str(name);
            let nid = tree.find_by_id(id)?;
            tree.get(nid)?.env.as_ref().map(|e| Arc::ptr_eq(e, &mark))
        };
        assert_eq!(env_of("root", &tree), None, "the root declares nothing");
        assert_eq!(env_of("scoped", &tree), Some(true), "the opener carries it");
        assert_eq!(env_of("inner", &tree), Some(true), "a child inherits it");
        assert_eq!(env_of("leaf", &tree), Some(true), "and it reaches leaves");
        assert_eq!(
            env_of("outside", &tree),
            None,
            "a sibling outside the scope must not inherit it"
        );
    }

    /// An overlay must not be charged to a growing sibling: it takes no slot, so a
    /// fixed-size overlay above a filling child must leave that child its full height.
    /// 悬浮节点不得让可增长的兄弟替它买单：它不占槽，固定尺寸的浮层不能扣掉填充子节点的高度。
    #[test]
    fn an_overlay_does_not_shrink_a_growing_sibling() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(crate::layout::SizeClass::fixed(200.0, 200.0))
                .child(
                    Decl::container(Id::str("fill"), NodeKind::Column).size(crate::layout::SizeClass {
                        width: crate::layout::AxisSize::fill(0.0, 200.0),
                        height: crate::layout::AxisSize::fill(0.0, 200.0),
                        grow_x: crate::layout::Grow::Yes,
                        grow_y: crate::layout::Grow::Yes,
                    }),
                )
                .child(
                    Decl::container(Id::str("float"), NodeKind::Overlay)
                        .size(crate::layout::SizeClass::fixed(60.0, 30.0)),
                ),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(200.0, 200.0)));

        let fill = tree.get(tree.find_by_id(Id::str("fill")).unwrap()).unwrap();
        assert_eq!(
            fill.rect.size.h, 200.0,
            "the overlay is not a sibling in the main axis, so nothing may be taken from it"
        );
    }

    /// The flow's own size must ignore overlays, or a floating panel would push it open.
    /// 流自身的尺寸必须忽略悬浮节点，否则一块浮动面板会把它撑开。
    #[test]
    fn an_overlay_does_not_grow_its_hugging_parent() {
        // Compare the same tree with and without the overlay: a hug parent must be
        // identical, or the floating panel would push real content around.
        // 对比同一棵树有无悬浮节点：紧贴父节点必须完全相同，
        // 否则浮动面板会把真实内容挤开。
        let hug = || {
            Decl::container(Id::str("root"), NodeKind::Column).size(
                crate::layout::SizeClass {
                    width: crate::layout::AxisSize::hug(0.0, 400.0),
                    height: crate::layout::AxisSize::hug(0.0, 400.0),
                    ..crate::layout::SizeClass::fixed(0.0, 0.0)
                },
            )
        };
        let measure = |decl: Decl| {
            let mut tree = Tree::new();
            tree.apply(&decl);
            let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
            let root = tree.root().unwrap();
            engine.solve(&mut tree, root, Constraints::loose(Size::new(400.0, 400.0)));
            tree.get(root).unwrap().rect.size.h
        };
        let without = measure(hug().child(
            Decl::container(Id::str("a"), NodeKind::Column).size(
                crate::layout::SizeClass::fixed(60.0, 20.0),
            ),
        ));
        let with = measure(
            hug()
                .child(
                    Decl::container(Id::str("a"), NodeKind::Column).size(
                        crate::layout::SizeClass::fixed(60.0, 20.0),
                    ),
                )
                .child(
                    Decl::container(Id::str("float"), NodeKind::Overlay)
                        .size(crate::layout::SizeClass::fixed(60.0, 90.0)),
                ),
        );
        assert_eq!(with, without, "the overlay must not change the parent's height");
    }

    /// Column children stretch to the content width by default.
    /// Column 的子节点默认撑满内容宽度。
    #[test]
    fn column_children_stretch_across_the_cross_axis() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .padding(Insets::all(10.0))
                .child(Decl::container(Id::str("a"), NodeKind::Row)),
        );
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(200.0, 100.0)));
        let a = tree.get(tree.find_by_id(Id::str("a")).unwrap()).unwrap();
        assert_eq!(
            a.rect.size.w, 180.0,
            "child must fill the padded content width, got {}",
            a.rect.size.w
        );
    }

    use super::*;
    use crate::id::Id;
    use crate::tree::Decl;

    fn box_node(id: &'static str, w: f32, h: f32) -> Decl {
        Decl {
            id: Id::str(id),
            kind: NodeKind::Box,
            shapes: Vec::new(),
            data: NodeData::Container(crate::tree::ContainerParams::default()),
            size_class: SizeClass::fixed(w, h),
            ink_margin: Insets::ZERO,
            box_model: Default::default(),
            offset: crate::geom::Point::new(0.0, 0.0),
            cursor: None,
            sense: crate::Sense::NONE,
            disabled: false,
            grid: crate::tree::GridItem::default(),
            placement: crate::layout::Placement::default(),
            env: None,
            children: Vec::new(),
        }
    }

    fn text_node(id: &'static str, body: &str, grow_x: crate::layout::Grow) -> Decl {
        Decl {
            id: Id::str(id),
            kind: NodeKind::Text,
            shapes: Vec::new(),
            data: NodeData::Text {
                ink: crate::geom::Color::WHITE,
                block: crate::text::TextBlock {
                    runs: vec![crate::text::TextRun::new(
                        body,
                        crate::text::TextStyle::new(10.0),
                    )],
                    align: crate::TextAlign::Start,
                    max_lines: None,
                    line_gap: 0.0,
                    indent: 0.0,
                    atoms: Vec::new(),
                },
                caret: None,
                selection: None,
                composing: None,
                nowrap: false,
            },
            size_class: SizeClass {
                width: crate::layout::AxisSize::hug(0.0, 0.0),
                height: crate::layout::AxisSize::hug(0.0, 0.0),
                grow_x,
                grow_y: crate::layout::Grow::No,
            },
            ink_margin: Insets::ZERO,
            box_model: Default::default(),
            offset: crate::geom::Point::new(0.0, 0.0),
            cursor: None,
            sense: crate::Sense::NONE,
            disabled: false,
            grid: crate::tree::GridItem::default(),
            placement: crate::layout::Placement::default(),
            env: None,
            children: Vec::new(),
        }
    }

    /// One grid cell owner with no definite size, so the default stretch applies.
    /// 一个没有确定尺寸的网格单元格占用者，默认拉伸才会生效。
    fn cell_item(id: &'static str, row: u32, col: u32, row_span: u32, col_span: u32) -> Decl {
        Decl::container(Id::str(id), NodeKind::Box)
            .size(SizeClass::hug(0.0, 0.0))
            .grid_area(row, col, row_span, col_span)
    }

    fn grid_decl(id: &'static str, cols: Vec<crate::layout::Track>, rows: Vec<crate::layout::Track>) -> Decl {
        Decl::container(Id::str(id), NodeKind::Grid).tracks(crate::layout::TrackList {
            cols,
            rows,
            auto_flow: crate::layout::AutoFlow::Row,
        })
    }

    #[test]
    fn grid_tracks_sum_to_the_content_box() {
        // A definite grid fills its box exactly: fixed tracks keep their size, the fr
        // tracks split what is left, and the gaps count inside the same box.
        // 尺寸确定的网格正好填满盒子：固定轨道保持原值，fr 轨道分掉剩余，间隙也算在盒内。
        use crate::layout::Track;
        let grid = grid_decl(
            "grid",
            vec![Track::Fixed(100.0), Track::Fr(1.0), Track::Fr(1.0)],
            vec![Track::Fixed(100.0)],
        )
        .size(SizeClass::fixed(400.0, 100.0))
        .gap(10.0)
        // A `hug` item has no definite size, so the default stretch fills its cell.
        // `hug` 项目没有确定尺寸，因此默认拉伸会填满单元格。
        .child(cell_item("a", 0, 0, 1, 1))
        .child(cell_item("b", 0, 1, 1, 1))
        .child(cell_item("c", 0, 2, 1, 1));
        let mut tree = Tree::new();
        tree.apply(&grid);
        solve(&mut tree);
        let rect = |id: &'static str| {
            tree.get(tree.find_by_id(Id::str(id)).unwrap())
                .unwrap()
                .rect
        };
        let (a, b, c) = (rect("a"), rect("b"), rect("c"));
        assert!(
            (a.size.w - 100.0).abs() < 0.01 && (b.size.w - 140.0).abs() < 0.01,
            "fixed keeps 100, each fr takes 140: {a:?} {b:?}"
        );
        assert!(
            (b.origin.x - 110.0).abs() < 0.01,
            "the second track starts after the first plus one gap, got {}",
            b.origin.x
        );
        assert!(
            ((c.origin.x + c.size.w) - 400.0).abs() < 0.01,
            "the tracks and gaps must sum to the content box, got {}",
            c.origin.x + c.size.w
        );
    }

    #[test]
    fn a_grid_item_margin_insets_it_inside_its_cell() {
        // A margin is outside the item in a grid too: it widens an auto track, offsets the
        // item, and shrinks the cell the item aligns itself inside.
        // 网格里外边距同样在项目之外：它撑宽 auto 轨道、推开项目，并缩小项目据以对齐的格子。
        use crate::layout::Track;
        let grid = grid_decl("grid", vec![Track::Auto, Track::Fixed(38.0)], Vec::new())
            .size(SizeClass::fixed(300.0, 100.0))
            .child(
                box_node("label", 60.0, 20.0)
                    .grid_area(0, 0, 1, 1)
                    .margin(Insets {
                        left: 10.0,
                        right: 10.0,
                        ..Insets::ZERO
                    }),
            )
            .child(
                box_node("glyph", 12.0, 12.0)
                    .grid_area(0, 1, 1, 1)
                    .justify_self(crate::layout::Align::End)
                    .margin(Insets {
                        right: 14.0,
                        ..Insets::ZERO
                    }),
            );
        let mut tree = Tree::new();
        tree.apply(&grid);
        solve(&mut tree);
        let rect = |id: &'static str| {
            tree.get(tree.find_by_id(Id::str(id)).unwrap())
                .unwrap()
                .rect
        };
        let (label, glyph) = (rect("label"), rect("glyph"));
        assert!(
            (label.origin.x - 10.0).abs() < 0.01,
            "the lead margin pushes the item off the cell edge, got {}",
            label.origin.x
        );
        let cell_right = 60.0 + 20.0 + 38.0;
        assert!(
            ((cell_right - (glyph.origin.x + glyph.size.w)) - 14.0).abs() < 0.01,
            "the trailing margin keeps the item 14 from the cell edge, got {}",
            cell_right - (glyph.origin.x + glyph.size.w)
        );
    }

    #[test]
    fn a_spanning_item_sizes_its_auto_tracks() {
        // A wide item that spans two auto tracks has to be shared between them: neither
        // track can see the content alone, so ignoring spans leaves both at zero.
        // 横跨两条 auto 轨道的宽项目必须在两条轨道间分摊：单看任一轨道都看不到该内容，
        // 忽略跨度就会把两条轨道都留成零。
        use crate::layout::Track;
        let grid = grid_decl("grid", vec![Track::Auto, Track::Auto], Vec::new())
            .gap(10.0)
            .child(text_node("wide", "abcdefghij", crate::layout::Grow::No).grid_area(0, 0, 1, 2))
            .child(box_node("corner", 10.0, 10.0).grid_area(1, 1, 1, 1));
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .cross_align(0.0)
                .child(grid),
        );
        solve(&mut tree);
        let rect = |id: &'static str| {
            tree.get(tree.find_by_id(Id::str(id)).unwrap())
                .unwrap()
                .rect
        };
        let (wide, corner) = (rect("wide"), rect("corner"));
        assert!(
            (wide.size.w - 60.0).abs() < 0.01,
            "the spanning item keeps its 60-wide content, got {}",
            wide.size.w
        );
        assert!(
            (corner.origin.x - 35.0).abs() < 0.01,
            "each auto track took (60 - 10) / 2 = 25, so column 1 starts at 35, got {}",
            corner.origin.x
        );
    }

    /// A bare grid item: no definite size, so the default stretch fills its cell.
    /// 一个裸网格项目：没有确定尺寸，因此默认拉伸会填满单元格。
    fn auto_item(id: &'static str) -> Decl {
        Decl::container(Id::str(id), NodeKind::Box)
    }

    fn rect_of(tree: &Tree, id: &'static str) -> Rect {
        tree.get(tree.find_by_id(Id::str(id)).unwrap()).unwrap().rect
    }

    #[test]
    fn repeat_auto_fill_fits_as_many_tracks_as_the_width_allows() {
        // 340 wide with 80-wide tracks and 10 gaps fits three (3*80 + 2*10 = 260); a fourth
        // would need 350, so the fourth item wraps instead of starting a fourth track.
        // 340 宽、80 宽轨道、10 间隙放得下三条（3*80+2*10=260）；第四条要 350，
        // 因此第四个项目换行，而不是再开一条轨道。
        use crate::layout::{AutoFlow, Len, Repeat, Track, TrackBound, TrackList};
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("grid"), NodeKind::Grid)
                .tracks(TrackList {
                    cols: vec![Track::Repeat(
                        Repeat::AutoFill,
                        Box::new(Track::MinMax(TrackBound::Len(Len::Px(80.0)), TrackBound::Len(Len::Px(80.0)))),
                    )],
                    // Explicit row heights: an empty implicit row has no intrinsic height.
                    // 显式行高：空的隐式行没有内在高度。
                    rows: vec![Track::Fixed(20.0), Track::Fixed(20.0)],
                    auto_flow: AutoFlow::Row,
                })
                .size(SizeClass::fixed(340.0, 200.0))
                .gap(10.0)
                .child(box_node("a", 10.0, 10.0))
                .child(box_node("b", 10.0, 10.0))
                .child(box_node("c", 10.0, 10.0))
                .child(box_node("d", 10.0, 10.0)),
        );
        solve(&mut tree);
        let (a, b, c, d) = (
            rect_of(&tree, "a"),
            rect_of(&tree, "b"),
            rect_of(&tree, "c"),
            rect_of(&tree, "d"),
        );
        assert!(
            (a.origin.x - 0.0).abs() < 0.01
                && (b.origin.x - 90.0).abs() < 0.01
                && (c.origin.x - 180.0).abs() < 0.01,
            "three tracks should start at 0, 90 and 180, got {} {} {}",
            a.origin.x,
            b.origin.x,
            c.origin.x
        );
        assert!(
            (d.origin.x - 0.0).abs() < 0.01 && (d.origin.y - 30.0).abs() < 0.01,
            "the fourth item must wrap to the second row, got {:?}",
            d.origin
        );
    }

    #[test]
    fn auto_fit_collapses_the_tracks_no_item_lands_in() {
        // Three tracks fit the width; the pinned item sits in the last one and the auto
        // item in the first, so the middle track is empty. `auto-fill` keeps it and the
        // pinned item stays at 180; `auto-fit` collapses it and the item moves to 90.
        // 宽度能放下三条；钉住的项目在最后一条、自动项目在第一条，中间那条空着。
        // `auto-fill` 保留它，钉住的项目停在 180；`auto-fit` 把它塌掉，项目移到 90。
        use crate::layout::{AutoFlow, Len, Repeat, Track, TrackBound, TrackList};
        let run = |mode: Repeat| {
            let mut tree = Tree::new();
            tree.apply(
                &Decl::container(Id::str("grid"), NodeKind::Grid)
                    .tracks(TrackList {
                        cols: vec![Track::Repeat(
                            mode,
                            Box::new(Track::MinMax(TrackBound::Len(Len::Px(80.0)), TrackBound::Len(Len::Px(80.0)))),
                        )],
                        rows: vec![Track::Fixed(20.0)],
                        auto_flow: AutoFlow::Row,
                    })
                    .size(SizeClass::fixed(340.0, 60.0))
                    .gap(10.0)
                    .child(box_node("pinned", 10.0, 10.0).grid_area(0, 2, 1, 1))
                    .child(box_node("auto", 10.0, 10.0)),
            );
            solve(&mut tree);
            rect_of(&tree, "pinned").origin.x
        };
        let filled = run(Repeat::AutoFill);
        let fitted = run(Repeat::AutoFit);
        assert!(
            (filled - 180.0).abs() < 0.01,
            "auto-fill keeps the empty middle track, got {filled}"
        );
        assert!(
            (fitted - 90.0).abs() < 0.01,
            "auto-fit must collapse the empty track, got {fitted}"
        );
    }

    #[test]
    fn minmax_px_fr_is_the_auto_fill_idiom() {
        // `repeat(auto-fill, minmax(200px, 1fr))` at 1176 wide with 8 gaps: five tracks
        // (5*200 + 4*8 = 1032 fits, six would need 1240), each taking (1176 - 32) / 5.
        // 1176 宽、8 间隙下的 `repeat(auto-fill, minmax(200px, 1fr))`：五条轨道
        // （5*200+4*8=1032 放得下，六条要 1240），每条分到 (1176-32)/5。
        use crate::layout::{AutoFlow, Len, Repeat, Track, TrackBound, TrackList};
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("grid"), NodeKind::Grid)
                .tracks(TrackList {
                    cols: vec![Track::Repeat(
                        Repeat::AutoFill,
                        Box::new(Track::MinMax(
                            TrackBound::Len(Len::Px(200.0)),
                            TrackBound::Fr(1.0),
                        )),
                    )],
                    rows: vec![Track::Fixed(20.0)],
                    auto_flow: AutoFlow::Row,
                })
                .size(SizeClass::fixed(1176.0, 60.0))
                .gap(8.0)
                .child(auto_item("a"))
                .child(auto_item("b"))
                .child(auto_item("c"))
                .child(auto_item("d"))
                .child(auto_item("e")),
        );
        // The test harness offers 800 by default, so the run is given its own 1176 window.
        // 测试脚手架默认只给 800，因此这里单独按 1176 的可用宽度解算。
        let root = tree.root().expect("root");
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        engine.solve(&mut tree, root, Constraints::loose(Size::new(1176.0, 600.0)));
        let want = (1176.0 - 4.0 * 8.0) / 5.0;
        let rects: Vec<Rect> = ["a", "b", "c", "d", "e"]
            .iter()
            .map(|id| rect_of(&tree, id))
            .collect();
        for (i, r) in rects.iter().enumerate() {
            assert!(
                (r.size.w - want).abs() < 0.01,
                "track {i} is {:.1} wide, want {want:.1}",
                r.size.w
            );
            assert!(
                (r.origin.x - i as f32 * (want + 8.0)).abs() < 0.01,
                "track {i} starts at {:.1}, want {:.1}",
                r.origin.x,
                i as f32 * (want + 8.0)
            );
        }
        assert!(
            (rects[4].origin.x + rects[4].size.w - 1176.0).abs() < 0.01,
            "the last track must end on the content edge, got {:.1}",
            rects[4].origin.x + rects[4].size.w
        );
    }

    #[test]
    fn a_fixed_item_gives_an_auto_track_its_height() {
        // With no template, the row is only as tall as its items' contribution; a fixed
        // item contributes its declared height, not its (empty) content.
        // 没有模板时，行高只由项目的贡献决定；固定尺寸项目贡献的是声明高度，而不是（空的）内容。
        use crate::layout::{AutoFlow, TrackList};
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .cross_align(0.0)
                .child(
                    Decl::container(Id::str("grid"), NodeKind::Grid)
                        .tracks(TrackList {
                            cols: Vec::new(),
                            rows: Vec::new(),
                            auto_flow: AutoFlow::Row,
                        })
                        .size(SizeClass::hug(0.0, 0.0))
                        .child(box_node("a", 80.0, 24.0))
                        .child(box_node("b", 80.0, 24.0)),
                ),
        );
        solve(&mut tree);
        let grid = rect_of(&tree, "grid");
        let b = rect_of(&tree, "b");
        assert!(
            (grid.size.h - 48.0).abs() < 0.01,
            "two 24-tall rows make a 48-tall grid, got {}",
            grid.size.h
        );
        assert!(
            (b.origin.y - 24.0).abs() < 0.01,
            "the second item sits on the second row, got {}",
            b.origin.y
        );
    }

    /// A box whose id is computed, so a repeated item can be declared without a literal.
    /// 标识由计算得出的盒子，重复项目因此不必写字面量。
    fn sized_box(id: Id, w: f32, h: f32) -> Decl {
        Decl {
            size_class: SizeClass::fixed(w, h),
            ..Decl::container(id, NodeKind::Box)
        }
    }

    /// The knobs one edit may turn; each step changes exactly one of them.
    /// 一次编辑能拧的旋钮；每一步只改其中一个。
    #[derive(Clone, Debug)]
    struct Params {
        root_w: f32,
        root_gap: f32,
        items: usize,
        item_side: [f32; 3],
        item_abs: [bool; 3],
        body_len: usize,
        cell_w: f32,
        cell_h: f32,
        nested_gap: f32,
    }

    impl Default for Params {
        fn default() -> Self {
            Self {
                root_w: 340.0,
                root_gap: 4.0,
                items: 3,
                item_side: [20.0, 30.0, 40.0],
                item_abs: [false; 3],
                body_len: 6,
                cell_w: 24.0,
                cell_h: 18.0,
                nested_gap: 0.0,
            }
        }
    }

    fn scene(p: &Params) -> Decl {
        let mut root = Decl::container(Id::str("root"), NodeKind::Column)
            .size(SizeClass::fixed(p.root_w, 500.0))
            .gap(p.root_gap);
        for i in 0..p.items {
            let side = p.item_side[i];
            let mut item = sized_box(Id::str("item").with(i), side, side);
            if p.item_abs[i] {
                item = item
                    .absolute()
                    .inset(Insets::new(side, 0.0, crate::layout::AUTO, crate::layout::AUTO));
            }
            root = root.child(item);
        }
        root = root.child(paragraph("body", "x".repeat(p.body_len), 10.0, p.root_w));
        let mut nested = Decl::container(Id::str("nested"), NodeKind::Row).gap(p.nested_gap);
        for i in 0..2 {
            nested = nested.child(sized_box(Id::str("cell").with(i), p.cell_w, p.cell_h));
        }
        root.child(nested)
    }

    /// Turn one knob per step, cycling so every kind of edit shows up more than once.
    /// 每步拧一个旋钮并循环，于是每类改动都会出现不止一次。
    fn edit(p: &mut Params, step: usize) {
        match step % 7 {
            0 => p.root_w = 300.0 + (step % 5) as f32 * 40.0,
            1 => p.item_side[0] = 20.0 + (step % 4) as f32 * 10.0,
            2 => p.item_abs[1] = !p.item_abs[1],
            3 => p.body_len = 4 + step % 17,
            4 => p.cell_h = 18.0 + (step % 3) as f32 * 6.0,
            5 => p.items = 2 + step % 2,
            _ => p.root_gap = (step % 3) as f32 * 4.0,
        }
    }

    /// Assert every node of `decl` sits where a from-scratch solve of the same decl put it.
    /// 断言 `decl` 的每个节点都落在「同一份声明从头解算」给出的位置上。
    fn assert_same_layout(incremental: &Tree, full: &Tree, decl: &Decl) {
        let rect = |tree: &Tree| {
            tree.find_by_id(decl.id)
                .and_then(|n| tree.get(n))
                .map(|n| (n.rect, n.visual_rect(), n.mask))
        };
        assert_eq!(
            rect(incremental),
            rect(full),
            "node {:?} differs between the incremental and the full solve",
            decl.id
        );
        for child in &decl.children {
            assert_same_layout(incremental, full, child);
        }
    }

    #[test]
    fn incremental_layout_agrees_with_a_full_one_after_every_edit() {
        // Forty-two edits of one scene, each solved twice: once on the reused tree and once
        // on a fresh one. A stale cache shows up as a differing rect.
        // 同一场景改四十二次，每次解算两遍：一遍在复用树上，一遍在全新树上。
        // 陈旧的缓存会表现为矩形不一致。
        let mut tree = Tree::new();
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let constraints = Constraints::loose(Size::new(800.0, 600.0));
        let mut params = Params::default();
        for step in 0..42 {
            edit(&mut params, step);
            let decl = scene(&params);
            tree.apply(&decl);
            let root = tree.root().expect("root");
            engine.solve(&mut tree, root, constraints);

            let mut fresh = Tree::new();
            fresh.apply(&decl);
            let fresh_root = fresh.root().expect("root");
            BuiltinLayout::new(MonospaceMeasure::default()).solve(&mut fresh, fresh_root, constraints);

            assert_same_layout(&tree, &fresh, &decl);
        }
    }

    #[test]
    fn a_clean_tree_is_served_from_the_cache() {
        // The same tree asked the same question must not be measured a second time.
        // 同一棵树被问同一个问题时，不得再测量一遍。
        let mut tree = Tree::new();
        tree.apply(&scene(&Params::default()));
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().expect("root");
        let constraints = Constraints::loose(Size::new(800.0, 600.0));
        let first = engine.solve(&mut tree, root, constraints);
        let second = engine.solve(&mut tree, root, constraints);
        assert!(first.remeasured > 0, "the first pass measures everything");
        assert_eq!(second.remeasured, 0, "a clean tree is not measured again");
    }

    #[test]
    fn editing_a_leaf_remeasures_only_its_ancestors() {
        // root → column → [a, nested → leaf]: editing the leaf invalidates the leaf, the
        // nested row, the column and the root, and nothing else.
        // root → column → [a, nested → leaf]：改动叶子只会让叶子、嵌套行、列与根失效。
        let build = |side: f32| {
            Decl::container(Id::str("root"), NodeKind::Column).child(
                Decl::container(Id::str("column"), NodeKind::Column)
                    .child(sized_box(Id::str("a"), 40.0, 10.0))
                    .child(
                        Decl::container(Id::str("nested"), NodeKind::Row)
                            .child(sized_box(Id::str("leaf"), side, 10.0)),
                    ),
            )
        };
        let mut tree = Tree::new();
        tree.apply(&build(20.0));
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().expect("root");
        let constraints = Constraints::loose(Size::new(800.0, 600.0));
        let first = engine.solve(&mut tree, root, constraints);
        tree.apply(&build(30.0));
        let second = engine.solve(&mut tree, root, constraints);
        assert!(first.remeasured >= 5, "the first pass measures the whole tree");
        assert_eq!(
            second.remeasured, 4,
            "only the leaf and its three ancestors may be measured again"
        );
    }

    #[test]
    fn a_minmax_track_grows_past_its_minimum_but_not_past_its_max() {
        // A tiny item cannot lift the track over its 50 floor; a 156-wide line cannot push
        // it past its 120 ceiling.
        // 极小的项目顶不动 50 的下限；156 宽的一行也推不过 120 的上限。
        use crate::layout::{Len, Track, TrackBound};
        let run = |item: Decl| {
            let mut tree = Tree::new();
            tree.apply(
                &Decl::container(Id::str("grid"), NodeKind::Grid)
                    .tracks(crate::layout::TrackList {
                        cols: vec![Track::MinMax(TrackBound::Len(Len::Px(50.0)), TrackBound::Len(Len::Px(120.0)))],
                        rows: Vec::new(),
                        auto_flow: crate::layout::AutoFlow::Row,
                    })
                    .size(SizeClass::fixed(300.0, 60.0))
                    .child(item),
            );
            solve(&mut tree);
            rect_of(&tree, "item").size.w
        };
        let small = run(auto_item("item"));
        let large = run(
            text_node("item", "abcdefghijklmnopqrstuvwxyz", crate::layout::Grow::No),
        );
        assert!(
            (small - 50.0).abs() < 0.01,
            "an empty track must keep its 50 minimum, got {small}"
        );
        assert!(
            (large - 120.0).abs() < 0.01,
            "a 156-wide line must stop at the 120 maximum, got {large}"
        );
    }

    #[test]
    fn dense_flow_backfills_an_earlier_hole() {
        // Four 60-wide tracks: an item pinned to column 1 pushes the two-column item to
        // columns 2–3, leaving (0,0) free. Sparse flow moves on to row 1; dense returns.
        // 四条 60 宽轨道：钉在第 1 列的项目把跨两列的项目挤到 2–3 列，(0,0) 空出来。
        // 稀疏流继续走向第二行，dense 则回头填 (0,0)。
        use crate::layout::{AutoFlow, Track, TrackList};
        let run = |flow| {
            let mut tree = Tree::new();
            tree.apply(
                &Decl::container(Id::str("grid"), NodeKind::Grid)
                    .tracks(TrackList {
                        cols: vec![Track::Fixed(60.0); 4],
                        rows: vec![Track::Fixed(20.0), Track::Fixed(20.0)],
                        auto_flow: flow,
                    })
                    .size(SizeClass::fixed(240.0, 200.0))
                    .child(cell_item("pinned", 0, 1, 1, 1).size(SizeClass::fixed(10.0, 10.0)))
                    .child(
                        auto_item("wide")
                            .size(SizeClass::fixed(10.0, 10.0))
                            .grid_span(1, 2),
                    )
                    .child(auto_item("last").size(SizeClass::fixed(10.0, 10.0))),
            );
            solve(&mut tree);
            (rect_of(&tree, "wide").origin, rect_of(&tree, "last").origin)
        };
        let (wide_sparse, last_sparse) = run(AutoFlow::Row);
        let (wide_dense, last_dense) = run(AutoFlow::RowDense);
        assert!(
            (wide_sparse.x - 120.0).abs() < 0.01 && (wide_dense.x - 120.0).abs() < 0.01,
            "the two-column item skips the pinned cell in both flows: {wide_sparse:?} {wide_dense:?}"
        );
        assert!(
            (last_sparse.x - 0.0).abs() < 0.01 && (last_sparse.y - 20.0).abs() < 0.01,
            "sparse flow must move on to the second row, got {last_sparse:?}"
        );
        assert!(
            (last_dense.x - 0.0).abs() < 0.01 && (last_dense.y - 0.0).abs() < 0.01,
            "dense flow must backfill the hole at (0,0), got {last_dense:?}"
        );
    }

    /// A deficit squeezes a shrinkable child only down to its min_content, never below it.
    /// 空间不足只把可压缩子节点压到 min_content，绝不再低。
    #[test]
    fn a_child_never_shrinks_below_its_min_content() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Row)
                .size(SizeClass::fixed(50.0, 30.0))
                .child(text_node("label", "alpha beta", crate::layout::Grow::Flex(1)))
                .child(box_node("fixed", 90.0, 30.0)),
        );
        solve(&mut tree);
        let label = tree.get(tree.find_by_id(Id::str("label")).unwrap()).unwrap();
        // "alpha" and "beta" are five characters at six units each.
        // "alpha" 与 "beta" 各五个字符，每字符六单位。
        assert!(
            label.rect.size.w >= 30.0 - 0.01,
            "squeezed below the longest word: {}",
            label.rect.size.w
        );
        assert!(
            label.rect.size.w < 60.0,
            "the deficit did nothing: {}",
            label.rect.size.w
        );
    }

    /// Spare space goes to a grower, but never past the max it declares.
    /// 剩余空间会给可增长项，但绝不超过它声明的上界。
    #[test]
    fn grow_never_exceeds_the_declared_max() {
        let mut tree = Tree::new();
        let capped = Decl {
            size_class: SizeClass {
                width: crate::layout::AxisSize::hug(0.0, 100.0),
                height: crate::layout::AxisSize::fixed(20.0),
                grow_x: crate::layout::Grow::Yes,
                grow_y: crate::layout::Grow::No,
            },
            ..box_node("capped", 0.0, 20.0)
        };
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Row)
                .size(SizeClass::fixed(300.0, 30.0))
                .child(capped),
        );
        solve(&mut tree);
        let capped = tree.get(tree.find_by_id(Id::str("capped")).unwrap()).unwrap();
        assert_eq!(capped.rect.size.w, 100.0, "grew past the declared max");
    }

    fn solve(tree: &mut Tree) -> BuiltinLayout<MonospaceMeasure> {
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().expect("root");
        engine.solve(tree, root, Constraints::loose(Size::new(800.0, 600.0)));
        engine
    }

    #[test]
    fn column_stacks_children_with_gap() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .gap(8.0)
                .child(box_node("a", 20.0, 10.0))
                .child(box_node("b", 20.0, 30.0)),
        );
        solve(&mut tree);

        let a = tree.get(tree.find_by_id(Id::str("a")).unwrap()).unwrap();
        let b = tree.get(tree.find_by_id(Id::str("b")).unwrap()).unwrap();
        assert_eq!((a.rect.origin.x, a.rect.origin.y), (0.0, 0.0));
        assert_eq!((b.rect.origin.x, b.rect.origin.y), (0.0, 18.0));
    }

    #[test]
    fn row_places_children_left_to_right() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Row)
                .gap(4.0)
                .child(box_node("a", 10.0, 10.0))
                .child(box_node("b", 15.0, 10.0)),
        );
        solve(&mut tree);
        let a = tree.get(tree.find_by_id(Id::str("a")).unwrap()).unwrap();
        let b = tree.get(tree.find_by_id(Id::str("b")).unwrap()).unwrap();
        assert_eq!(a.rect.origin.x, 0.0);
        assert_eq!(b.rect.origin.x, 14.0);
    }

    #[test]
    fn padding_offsets_children() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .padding(Insets::all(5.0))
                .child(box_node("a", 10.0, 10.0)),
        );
        solve(&mut tree);
        let a = tree.get(tree.find_by_id(Id::str("a")).unwrap()).unwrap();
        assert_eq!((a.rect.origin.x, a.rect.origin.y), (5.0, 5.0));
    }

    #[test]
    fn growing_child_takes_spare_width() {
        let mut tree = Tree::new();
        let root = Decl::container(Id::str("root"), NodeKind::Row);
        let fill = Decl {
            size_class: SizeClass {
                width: crate::layout::AxisSize::fill(0.0, 10.0),
                height: crate::layout::AxisSize::fixed(20.0),
                grow_x: crate::layout::Grow::Yes,
                grow_y: crate::layout::Grow::No,
            },
            ..box_node("fill", 10.0, 20.0)
        };
        tree.apply(&root.child(box_node("fixed", 30.0, 20.0)).child(fill));
        solve(&mut tree);

        let fill_rect = tree.get(tree.find_by_id(Id::str("fill")).unwrap()).unwrap().rect;
        assert!(
            fill_rect.size.w > 10.0,
            "grower should absorb spare width, got {}",
            fill_rect.size.w
        );
    }

    #[test]
    fn a_zero_basis_grower_splits_the_row_evenly_whatever_its_content() {
        // Tabs need equal shares: `Yes` grows each child from its own content, so a long
        // label's tab stays wider. `Split` drops the content from the basis instead.
        // 页签需要等分：`Yes` 让每个子节点从自身内容增长，长标签的页签因此更宽。
        // `Split` 则把内容从基准里去掉。
        // Text carries the content difference; a box's `hug(0, X)` would now cap at `X`.
        // 内容差异由文本承载；盒子的 `hug(0, X)` 现在会以 `X` 为上限。
        let run = |grow: crate::layout::Grow| {
            let mut tree = Tree::new();
            tree.apply(
                &Decl::container(Id::str("root"), NodeKind::Row)
                    .child(text_node("short", "ab", grow))
                    .child(text_node("long", "a much longer label", grow)),
            );
            solve(&mut tree);
            let width = |id: &'static str| {
                tree.get(tree.find_by_id(Id::str(id)).unwrap())
                    .unwrap()
                    .rect
                    .size
                    .w
            };
            (width("short"), width("long"))
        };
        assert_eq!(run(crate::layout::Grow::Split(1)), (400.0, 400.0));
        let (short, long) = run(crate::layout::Grow::Yes);
        assert!(
            short < long,
            "growing from content keeps the difference: {short} vs {long}"
        );
    }

    #[test]
    fn scrolling_shifts_children_and_clips_them_without_extra_work() {
        // A 40-tall scroller holding two 30-tall children, scrolled by 20: the first
        // moves above the box, the second follows and is cut at the bottom edge.
        // 40 高的滚动容器里两个 30 高的子节点，滚 20：第一个移到盒子上方，
        // 第二个跟着上移并在下边缘被切掉。
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(SizeClass::fixed(40.0, 40.0))
                .scrollable()
                .scroll_y(20.0)
                .child(box_node("a", 40.0, 30.0))
                .child(box_node("b", 40.0, 30.0)),
        );
        solve(&mut tree);
        let a = tree.get(tree.find_by_id(Id::str("a")).unwrap()).unwrap();
        let b = tree.get(tree.find_by_id(Id::str("b")).unwrap()).unwrap();
        assert!(
            (a.rect.origin.y - -20.0).abs() < 0.01,
            "first child moved up by the offset, got {}",
            a.rect.origin.y
        );
        assert!(
            (b.rect.origin.y - 10.0).abs() < 0.01,
            "second child followed, got {}",
            b.rect.origin.y
        );
        assert!(
            (b.rect.size.h - 30.0).abs() < 0.01,
            "children keep their measured height instead of being squeezed, got {}",
            b.rect.size.h
        );
        // Clipping is the mask's job: it is the container box, not the child rect.
        // 裁剪由遮罩完成：它是容器盒，而不是子节点矩形。
        assert!(
            (b.mask.max_y() - 40.0).abs() < 0.01,
            "second child is clipped at the container edge, got {}",
            b.mask.max_y()
        );
    }

    /// A declared size is a border box: padding sits inside it instead of growing it.
    /// 声明尺寸是边框盒：内边距在盒内，不会把盒子撑大。
    #[test]
    fn a_declared_size_is_a_border_box() {
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(SizeClass::fixed(300.0, 300.0))
                .child(
                    Decl::container(Id::str("padded"), NodeKind::Column)
                        .size(SizeClass::fixed(100.0, 40.0))
                        .padding(crate::geom::Insets::all(10.0))
                        .child(box_node("kid", 20.0, 20.0)),
                ),
        );
        solve(&mut tree);
        let p = rect_of(&tree, "padded");
        let k = rect_of(&tree, "kid");
        assert_eq!((p.size.w, p.size.h), (100.0, 40.0), "padding must not grow it");
        assert_eq!((k.origin.x, k.origin.y), (10.0, 10.0), "content starts past the padding");
    }

    #[test]
    fn an_overflow_hidden_item_may_shrink_below_its_content() {
        // CSS Flexbox §4.5: the automatic minimum is zero whenever the axis is not
        // `visible` — `hidden` counts, and a clipped item must give way.
        // CSS Flexbox §4.5：该轴不是 `visible` 时自动最小尺寸为零——`hidden` 同样算数，
        // 被裁切的项必须让步。
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Row)
                .size(SizeClass::fixed(200.0, 40.0))
                .child(
                    Decl::container(Id::str("clipped"), NodeKind::Row)
                        .clip(crate::layout::Clip {
                            x: crate::layout::Overflow::Hidden,
                            y: crate::layout::Overflow::Hidden,
                        })
                        .child(box_node("wide", 300.0, 40.0)),
                )
                .child(box_node("b", 100.0, 40.0)),
        );
        solve(&mut tree);
        let clipped = tree
            .get(tree.find_by_id(Id::str("clipped")).unwrap())
            .unwrap();
        assert!(
            (clipped.rect.size.w - 100.0).abs() < 0.01,
            "the clipped item took the leftover width, got {}",
            clipped.rect.size.w
        );
    }

    #[test]
    fn a_horizontal_scroller_shifts_children_left_and_clips_at_the_box() {
        // The carousel needs the x counterpart of `scroll_y`: a 40-wide strip of two
        // 30-wide children scrolled by 20 puts the second at 10 and cuts it at 40.
        // 轮播需要 `scroll_y` 的横轴对应物：40 宽的条带里两个 30 宽的子节点滚 20，
        // 第二个落在 10，并在 40 处被裁掉。
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Row)
                .size(SizeClass::fixed(40.0, 40.0))
                .scrollable()
                .scroll_x(20.0)
                .child(box_node("a", 30.0, 40.0))
                .child(box_node("b", 30.0, 40.0)),
        );
        solve(&mut tree);
        let a = tree.get(tree.find_by_id(Id::str("a")).unwrap()).unwrap();
        let b = tree.get(tree.find_by_id(Id::str("b")).unwrap()).unwrap();
        assert!(
            (a.rect.origin.x - -20.0).abs() < 0.01,
            "first child moved left by the offset, got {}",
            a.rect.origin.x
        );
        assert!(
            (b.rect.origin.x - 10.0).abs() < 0.01,
            "second child followed, got {}",
            b.rect.origin.x
        );
        assert!(
            (a.mask.min_x() - 0.0).abs() < 0.01,
            "the first child is clipped at the leading edge, got {}",
            a.mask.min_x()
        );
        assert!(
            (b.mask.max_x() - 40.0).abs() < 0.01,
            "the second is clipped at the trailing edge, got {}",
            b.mask.max_x()
        );
    }

    fn node_of(tree: &Tree, id: &'static str) -> Rect {
        let nid = tree.find_by_id(Id::str(id)).expect("node id");
        tree.get(nid).expect("live node").rect
    }

    #[test]
    fn an_absolute_child_uses_the_padding_box_of_the_nearest_positioned_ancestor() {
        // The badge pins to the card's padding box even though a static box sits between
        // them; the card's 10px padding is not content space, so it cannot be the anchor.
        // 徽标钉在卡片的内边距盒上，尽管两者之间隔着一个静态盒子；
        // 卡片 10px 的内边距不是内容空间，因此不能作为锚点。
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(SizeClass::fixed(400.0, 300.0))
                .child(
                    Decl::container(Id::str("card"), NodeKind::Column)
                        .size(SizeClass::fixed(200.0, 100.0))
                        .padding(Insets::all(10.0))
                        .relative()
                        .child(
                            Decl::container(Id::str("middle"), NodeKind::Column).child(
                                box_node("badge", 20.0, 20.0).absolute().inset(Insets::new(
                                    crate::layout::AUTO,
                                    crate::layout::AUTO,
                                    0.0,
                                    0.0,
                                )),
                            ),
                        ),
                ),
        );
        solve(&mut tree);
        let card = node_of(&tree, "card");
        let badge = node_of(&tree, "badge");
        assert!(
            (badge.max_x() - card.max_x()).abs() < 0.01,
            "badge right edge {} is not the card's padding edge {}",
            badge.max_x(),
            card.max_x()
        );
        assert!(
            (badge.max_y() - card.max_y()).abs() < 0.01,
            "badge bottom edge {} is not the card's padding edge {}",
            badge.max_y(),
            card.max_y()
        );
        assert!(
            badge.origin.x > card.origin.x + 10.0,
            "badge starts at {}, inside the card's content box instead of its padding box",
            badge.origin.x
        );
    }

    #[test]
    fn a_percent_inset_resolves_against_the_containing_block() {
        // A percent side is the only way to place a bar by fraction of its parent, which an
        // indeterminate progress indicator needs; it must follow CSS, not the root.
        // 百分比边是唯一能按父宽比例摆放的办法——不确定进度条正需要它；
        // 它必须按 CSS 相对包含块，而不是相对根。
        use crate::layout::{Len, LenInsets};
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(SizeClass::fixed(400.0, 300.0))
                .child(
                    Decl::container(Id::str("card"), NodeKind::Column)
                        .size(SizeClass::fixed(200.0, 100.0))
                        .relative()
                        .child(
                            box_node("bar", 20.0, 10.0).absolute().inset(LenInsets::new(
                                Len::Pct(25.0),
                                Len::Pct(50.0),
                                Len::Auto,
                                Len::Auto,
                            )),
                        ),
                ),
        );
        solve(&mut tree);
        let card = node_of(&tree, "card");
        let bar = node_of(&tree, "bar");
        assert!(
            (bar.origin.x - (card.origin.x + 50.0)).abs() < 0.01,
            "left 25% of 200 is 50, got {}",
            bar.origin.x - card.origin.x
        );
        assert!(
            (bar.origin.y - (card.origin.y + 50.0)).abs() < 0.01,
            "top 50% of 100 is 50, got {}",
            bar.origin.y - card.origin.y
        );
    }

    #[test]
    fn a_percent_relative_inset_shifts_paint_and_leaves_the_slot_alone() {
        // CSS `position: relative; left: 10%` moves paint and hit only; the sibling must
        // still sit where layout put it.
        // CSS 的 `position: relative; left: 10%` 只移动绘制与命中；兄弟节点仍留在布局位置。
        use crate::layout::{Len, LenInsets};
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(SizeClass::fixed(200.0, 100.0))
                .child(
                    box_node("dot", 20.0, 20.0).relative().inset(LenInsets::new(
                        Len::Pct(10.0),
                        Len::Auto,
                        Len::Auto,
                        Len::Auto,
                    )),
                )
                .child(box_node("next", 20.0, 20.0)),
        );
        solve(&mut tree);
        let dot = node_of(&tree, "dot");
        let next = node_of(&tree, "next");
        assert_eq!(dot.origin.x, 0.0, "the slot is where layout put it");
        let visual = tree
            .get(tree.find_by_id(Id::str("dot")).unwrap())
            .unwrap()
            .visual_rect();
        assert!(
            (visual.origin.x - 20.0).abs() < 0.01,
            "10% of 200 shifts paint by 20, got {}",
            visual.origin.x
        );
        assert_eq!(next.origin.x, 0.0, "and the sibling did not move");
    }

    #[test]
    fn fixed_is_relative_to_the_root() {
        // A fixed badge pins to the root box even when declared deep inside a relatively
        // positioned card: the ancestor's displacement must not carry it.
        // 固定徽标钉在根盒上，即使声明在相对定位的卡片深处：祖先的位移不得带走它。
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(SizeClass::fixed(400.0, 300.0))
                .child(
                    Decl::container(Id::str("card"), NodeKind::Column)
                        .size(SizeClass::fixed(100.0, 100.0))
                        .relative()
                        .inset(Insets::new(
                            50.0,
                            60.0,
                            crate::layout::AUTO,
                            crate::layout::AUTO,
                        ))
                        .child(box_node("badge", 20.0, 20.0).fixed().inset(Insets::new(
                            crate::layout::AUTO,
                            crate::layout::AUTO,
                            0.0,
                            0.0,
                        ))),
                ),
        );
        solve(&mut tree);
        let card = tree.get(tree.find_by_id(Id::str("card")).unwrap()).unwrap();
        let badge = node_of(&tree, "badge");
        assert!(
            (card.visual_rect().origin.x - 50.0).abs() < 0.01,
            "the card itself moved to {:?}, so the test proves nothing",
            card.visual_rect().origin
        );
        assert!(
            (badge.max_x() - 400.0).abs() < 0.01 && (badge.max_y() - 300.0).abs() < 0.01,
            "fixed badge sits at {:?}, not the root's bottom-right corner",
            badge
        );
    }

    #[test]
    fn a_relative_offset_moves_the_hit_test_with_the_paint() {
        // A clip inside a displaced ancestor: the mask has to travel with the pixels, or a
        // click inside the painted box hits nothing and one past it hits anyway.
        // 被位移祖先内部的裁剪容器：遮罩必须跟随像素，否则点进画出来的盒子里命不中，
        // 点在它外面反倒命中。
        use crate::hit::{HitBehavior, HitIndex};
        use crate::layout::Overflow;
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(SizeClass::fixed(400.0, 300.0))
                .child(
                    Decl::container(Id::str("mover"), NodeKind::Column)
                        .size(SizeClass::fixed(200.0, 200.0))
                        .relative()
                        .inset(Insets::new(
                            30.0,
                            40.0,
                            crate::layout::AUTO,
                            crate::layout::AUTO,
                        ))
                        .child(
                            Decl::container(Id::str("clip"), NodeKind::Column)
                                .size(SizeClass::fixed(200.0, 200.0))
                                .clip(crate::layout::Clip {
                                    x: Overflow::Hidden,
                                    y: Overflow::Hidden,
                                })
                                .child(box_node("wide", 300.0, 100.0)),
                        ),
                ),
        );
        solve(&mut tree);
        let wide_id = tree.find_by_id(Id::str("wide")).unwrap();
        let clip = tree.get(tree.find_by_id(Id::str("clip")).unwrap()).unwrap();
        let wide = tree.get(wide_id).unwrap();
        assert!(
            (wide.mask.max_x() - clip.visual_rect().max_x()).abs() < 0.01,
            "mask ends at {}, the clipped pixels at {}",
            wide.mask.max_x(),
            clip.visual_rect().max_x()
        );
        let idx = HitIndex::build(&tree, |nid| {
            if tree.get(nid).map(|n| n.id) == Some(Id::str("root")) {
                HitBehavior::Ignore
            } else {
                HitBehavior::Opaque
            }
        });
        assert_eq!(
            idx.topmost(crate::geom::Point::new(210.0, 50.0)),
            Some(wide_id),
            "a click on painted pixels inside the clip found no target"
        );
        assert_eq!(
            idx.topmost(crate::geom::Point::new(250.0, 50.0)),
            None,
            "a click past the clip's edge still hit something"
        );
    }

    #[test]
    fn an_offset_and_a_relative_inset_add_up_once() {
        // `offset` and a relative inset are the same displacement; a second translation
        // anywhere would double it, and the whole subtree would drift.
        // `offset` 与相对内边距是同一种位移；别处再来一套平移就会翻倍，整棵子树都会漂。
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .size(SizeClass::fixed(200.0, 200.0))
                .child(
                    Decl::container(Id::str("mover"), NodeKind::Column)
                        .size(SizeClass::fixed(100.0, 100.0))
                        .offset(10.0, 5.0)
                        .relative()
                        .inset(Insets::new(
                            3.0,
                            7.0,
                            crate::layout::AUTO,
                            crate::layout::AUTO,
                        ))
                        .child(box_node("kid", 10.0, 10.0)),
                ),
        );
        solve(&mut tree);
        for id in ["mover", "kid"] {
            let node = tree.get(tree.find_by_id(Id::str(id)).unwrap()).unwrap();
            assert!(
                (node.offset.x - 13.0).abs() < 0.01 && (node.offset.y - 12.0).abs() < 0.01,
                "{id} carries {:?}, not the single sum (13, 12)",
                node.offset
            );
            let visual = node.visual_rect();
            assert!(
                (visual.origin.x - (node.rect.origin.x + 13.0)).abs() < 0.01
                    && (visual.origin.y - (node.rect.origin.y + 12.0)).abs() < 0.01,
                "{id} draws at {:?}, its layout rect is {:?}",
                visual,
                node.rect
            );
        }
    }

    #[test]
    fn a_visible_container_does_not_clip_its_child() {
        // Clipping is opt-in: a card that declares nothing must let a wide child paint,
        // or text whose ink exceeds its own rect gets cut for no reason.
        // 裁剪是显式选择：没声明裁切的卡片必须让宽子节点照常绘制，
        // 否则墨迹超出自身矩形的文本会被无故切掉。
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column).child(
                Decl::container(Id::str("card"), NodeKind::Column)
                    .size(SizeClass::fixed(100.0, 100.0))
                    .child(box_node("wide", 160.0, 20.0)),
            ),
        );
        solve(&mut tree);
        let wide = tree.get(tree.find_by_id(Id::str("wide")).unwrap()).unwrap();
        assert!(
            wide.mask.size.w + 0.01 >= wide.rect.size.w,
            "a visible parent cut its child's mask: mask {:?}, rect {:?}",
            wide.mask,
            wide.rect
        );
    }

    #[test]
    fn scroll_offset_moves_content_not_the_clip_rect() {
        // Scrolling moves the content inside a fixed viewport; the viewport itself must
        // not travel with it, or the clip edge follows the text and stays invisible.
        // 滚动移动的是固定视口里的内容；视口本身不得随内容移动，
        // 否则裁剪边缘跟着文本跑，看起来就像没裁。
        let run = |scroll: f32| {
            let mut tree = Tree::new();
            tree.apply(
                &Decl::container(Id::str("root"), NodeKind::Column)
                    .size(SizeClass::fixed(40.0, 40.0))
                    .scrollable()
                    .scroll_y(scroll)
                    .child(box_node("a", 40.0, 30.0))
                    .child(box_node("b", 40.0, 30.0)),
            );
            solve(&mut tree);
            let b = tree.get(tree.find_by_id(Id::str("b")).unwrap()).unwrap();
            (b.mask, b.rect.origin.y)
        };
        let (mask_rest, y_rest) = run(0.0);
        let (mask_scrolled, y_scrolled) = run(20.0);
        assert_eq!(
            mask_rest, mask_scrolled,
            "the viewport moved with the content: {mask_rest:?} vs {mask_scrolled:?}"
        );
        assert!(
            (y_rest - y_scrolled - 20.0).abs() < 0.01,
            "content must move by the offset: {y_rest} -> {y_scrolled}"
        );
    }

    #[test]
    fn a_clipping_container_intersects_its_child_mask() {
        // The opt-in half of the rule: once a container declares `Hidden`, its box is the
        // clip again, so the wide child's mask stops at the card's edge.
        // 规则的显式那一半：容器声明 `Hidden` 后，它的盒子重新成为裁剪，
        // 宽子节点的遮罩止于卡片边缘。
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column).child(
                Decl::container(Id::str("card"), NodeKind::Column)
                    .size(SizeClass::fixed(100.0, 100.0))
                    .clip(crate::layout::Clip {
                        x: crate::layout::Overflow::Hidden,
                        y: crate::layout::Overflow::Hidden,
                    })
                    .child(box_node("wide", 160.0, 20.0)),
            ),
        );
        solve(&mut tree);
        let wide = tree.get(tree.find_by_id(Id::str("wide")).unwrap()).unwrap();
        assert_eq!(
            (wide.mask.size.w, wide.mask.size.h),
            (100.0, 100.0),
            "a declared clip must cut the child's mask to the card box, got {:?}",
            wide.mask
        );
    }
}
