//! The hash containers and digests the engine uses internally.
//! 引擎内部使用的哈希容器与摘要。
//!
//! Every key here is produced by the engine itself — node ids, content digests, integer
//! buckets — so SipHash's collision resistance costs a frame real time and buys nothing.
//! 这里的键全部由引擎自己产生（节点 id、内容摘要、整数桶），因此 SipHash 的抗碰撞
//! 在每一帧上都要付时间，却换不来任何东西。
//!
//! One module so the choice has exactly one home: switching hashers is editing this file.
//! 只此一处定义，选择也就只有一个去处：换哈希器就是改这个文件。

/// A `HashMap` for engine-internal keys.
/// 引擎内部键使用的 `HashMap`。
pub type FastMap<K, V> = std::collections::HashMap<K, V, rustc_hash::FxBuildHasher>;

/// A `HashSet` for engine-internal keys.
/// 引擎内部键使用的 `HashSet`。
pub type FastSet<T> = std::collections::HashSet<T, rustc_hash::FxBuildHasher>;

/// A digest hasher, for the cases that hash content into one `u64` instead of keying a map.
/// 摘要用的哈希器：把内容压成一个 `u64`，而不是用来索引映射。
pub type FastHasher = rustc_hash::FxHasher;
