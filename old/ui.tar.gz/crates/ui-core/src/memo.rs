//! Cached declarations: what a build read, and whether it still reads the same.
//! 缓存的声明：一次构建读了什么，以及现在读到的还是不是同一个值。

use crate::collections::FastMap;
use std::rc::Rc;

use crate::geom::Point;
use crate::id::Id;
use crate::tree::Decl;
use crate::{AnimSpec, AnimStore};

/// One fact a build read, together with the value it saw.
/// 一次构建读到的一项事实，以及它当时看到的值。
#[derive(Clone, Debug, PartialEq)]
pub enum Dep {
    Hovered(Option<Id>),
    Pressed(Option<Id>),
    Focused(Option<Id>),
    FocusVisible(bool),
    /// The popup a press outside it dismissed this frame.
    /// 本帧因外部按下而被要求关闭的浮层。
    Dismissed(Option<Id>),
    /// The chord that fired this frame and the node that declared it.
    /// 本帧触发的组合键，以及声明它的节点。
    Shortcut(Option<(Id, crate::shortcut::ShortcutId)>),
    Caret(Option<(Id, usize)>),
    CaretInText(Option<(Id, f32)>),
    Selection(Option<(Id, crate::selection::TextSelection)>),
    Preedit(Option<(Id, crate::ime::Preedit)>),
    HoveredPath(Vec<Id>),
    PressedPath(Vec<Id>),
    HoveredWithin(Id, bool),
    PressedWithin(Id, bool),
    ClickedWithin(Id, bool),
    ActivatedWithin(Id, bool),
    DroppedWithin(Id, bool),
    DraggingWithin(Id, bool),
    DragStarted(Id, bool),
    Disabled(Id, bool),
    Local(Option<Point>),
    DragStep(Option<Point>),
    /// The held modifiers, as four bits; a cached control must not keep a stale preview.
    /// 按住的修饰键，四个比特；被缓存的控件不得留着过期的预览。
    Modifiers(u8),
    /// An animation call, replayed on validation so the instance keeps advancing.
    /// 一次动画调用，校验时重放，使该实例继续推进。
    Anim {
        id: Id,
        target: f32,
        spec: AnimSpec,
        value: f32,
    },
    AnimColour {
        id: Id,
        target: crate::geom::Color,
        spec: AnimSpec,
        value: crate::geom::Color,
    },
    AnimStops {
        id: Id,
        stops: Vec<crate::anim::Stop>,
        spec: AnimSpec,
        value: f32,
    },
    Value {
        id: Id,
        value: f32,
    },
    /// A scroll container's geometry a build read, both axes: content extent, viewport,
    /// offset, and whether a wheel moved it since the previous frame.
    /// 一次构建读到的滚动容器双轴几何：内容尺寸、视口、偏移，以及自上一帧以来
    /// 是否有滚轮移动过它。
    Scroll {
        id: Id,
        extent_w: f32,
        extent_h: f32,
        viewport_w: f32,
        viewport_h: f32,
        offset_x: f32,
        offset_y: f32,
        active: bool,
    },
    Status {
        id: Id,
        status: Option<crate::anim::Status>,
    },
    /// A time-driven read: the element wants every frame, and this one's clock at build.
    /// 一次时间驱动读取：该元素需要每一帧，这是构建时它的时钟值。
    Age {
        id: Id,
        age: f32,
    },
    /// Bit patterns, so a value that only moves in the low bits still invalidates.
    /// 位模式，低位发生变化也能使条目失效。
    Now(u64),
    Size(u32, u32),
    Scale(u32),
    Dt(u32),
    Frame(u64),
    Pointer(Option<Point>),
    /// A fact the engine cannot replay, so the entry never survives to the next frame.
    /// 引擎无法重放的事实，因此条目不会活到下一帧。
    Volatile,
}

/// The stack of dependency frames currently being recorded.
/// 正在记录依赖的栈。
#[derive(Default)]
pub struct Recorder {
    frames: Vec<Vec<Dep>>,
    /// Per recording frame: a child was rebuilt rather than reused, so this subtree changed.
    /// 每个记录帧一项：有子元素是重建而非复用的，因此这棵子树变了。
    rebuilt_child: Vec<bool>,
    muted: bool,
    /// Facts read outside every recording frame this frame, so no entry can own them.
    /// 本帧在任何记录帧之外读到的事实，因此没有条目能认领它们。
    unattributed: Vec<Dep>,
    /// Some live element asked for the clock this frame: the loop must keep running.
    /// 本帧有存活元素读取了时钟：帧循环必须继续。
    time_driven: bool,
    /// Some live element read the raw pointer position: any move can change what it draws.
    /// 本帧有存活元素读了原始指针位置：指针的任何移动都可能改变它的输出。
    pointer_read: bool,
}

impl Recorder {
    pub fn begin(&mut self) {
        self.frames.push(Vec::new());
        self.rebuilt_child.push(false);
    }

    pub fn end(&mut self) -> Vec<Dep> {
        self.rebuilt_child.pop();
        self.frames.pop().unwrap_or_default()
    }

    /// Close the frame and report whether every child came from a validated entry.
    /// 结束记录帧，并报告是否每个子元素都来自已校验的条目。
    pub fn end_whole(&mut self) -> (Vec<Dep>, bool) {
        let rebuilt = self.rebuilt_child.pop().unwrap_or(true);
        (self.frames.pop().unwrap_or_default(), !rebuilt)
    }

    /// Note that the child just built was rebuilt, not reused: its parent is no longer whole.
    /// 记录刚构建的子元素是重建而非复用：它的父节点因此不再完整。
    pub fn note_rebuilt_child(&mut self) {
        if let Some(top) = self.rebuilt_child.last_mut() {
            *top = true;
        }
    }

    pub fn push(&mut self, dep: Dep) {
        if self.muted {
            return;
        }
        if matches!(dep, Dep::Age { .. } | Dep::Now(_)) {
            self.time_driven = true;
        }
        if matches!(dep, Dep::Pointer(_)) {
            self.pointer_read = true;
        }
        match self.frames.last_mut() {
            Some(top) => top.push(dep),
            None => self.unattributed.push(dep),
        }
    }

    /// Whether a build in this frame asked for the clock; resets the flag.
    /// 本帧是否有构建读取了时钟；读取后复位。
    pub fn take_time_driven(&mut self) -> bool {
        std::mem::take(&mut self.time_driven)
    }

    /// Whether a build in this frame read the raw pointer position; resets the flag.
    /// 本帧是否有构建读取了原始指针位置；读取后复位。
    pub fn take_pointer_read(&mut self) -> bool {
        std::mem::take(&mut self.pointer_read)
    }

    /// Facts read outside every build since the last call. They belong to no entry, so the
    /// cache can only keep itself when they read the same as last frame; `DeclCache::
    /// settle_outside` makes that call, once per frame, and takes them with it.
    /// 自上次调用以来在所有构建之外读到的事实。它们不属于任何条目，因此只有与上一帧读到
    /// 相同的值时缓存才能留住；这个判断由 `DeclCache::settle_outside` 每帧做一次并取走它们。
    pub fn take_unattributed(&mut self) -> Vec<Dep> {
        std::mem::take(&mut self.unattributed)
    }

    /// Silence recording while the cache re-reads its own dependencies.
    /// 缓存重读自身依赖时静音记录。
    pub fn mute(&mut self) -> bool {
        std::mem::replace(&mut self.muted, true)
    }

    pub fn unmute(&mut self, was: bool) {
        self.muted = was;
    }
}

/// What an element offers to be cached under: its identity and a fingerprint of its own
/// inputs. The fingerprint is not a [`Dep`] — validation could not answer for it; only the
/// element knows what it was given this frame.
/// 元素用来换缓存的凭据：身份，以及它自身输入的指纹。指纹不是 [`Dep`]——校验期回答不了
/// 它，只有元素知道这一帧自己拿到了什么。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct CachedKey {
    pub id: Id,
    pub props: u64,
}

impl CachedKey {
    pub fn new(id: Id, props: u64) -> Self {
        Self { id, props }
    }
}

/// One cached declaration and the facts it was built from.
/// 一份缓存的声明，以及构建它时用到的事实。
pub struct Entry {
    pub decl: Rc<Decl>,
    pub deps: Vec<Dep>,
    /// Fingerprint of the element's own inputs when this declaration was built.
    /// 建这份声明时元素自身输入的指纹。
    pub props: u64,
    /// Every child was itself a validated entry, so this declaration is only still true
    /// while all of them still validate. A subtree with a rebuilt child is not whole.
    /// 每个子元素当时都是已校验的条目，因此只有在它们全都仍然成立时这份声明才成立；
    /// 有子元素被重建过的子树不算完整。
    pub whole: bool,
    /// Frame in which the entry was last validated, so a subtree is walked once per frame.
    /// 条目最后一次通过校验的帧号，使子树每帧只被走一遍。
    pub checked: u64,
}

/// Declarations kept across frames, keyed by the root id they were built for.
/// 跨帧保留的声明，按构建时的根 Id 索引。
#[derive(Default)]
pub struct DeclCache {
    entries: FastMap<Id, Entry>,
    hits: u64,
    misses: u64,
    /// Facts the app read outside every build last frame, in order.
    /// 上一帧 app 在所有构建之外读到的事实，按顺序。
    outside: Vec<Dep>,
    /// Whether `outside` is a reading rather than the initial emptiness.
    /// `outside` 是一次读数，还是初始的空。
    observed: bool,
}

/// Beyond this many entries the cache is dropped wholesale; ids are unbounded in principle.
/// 超过这么多条目就整体丢弃；Id 的数量原则上没有上限。
const MAX_ENTRIES: usize = 8192;

impl DeclCache {
    pub fn get(&self, key: Id) -> Option<&Entry> {
        self.entries.get(&key)
    }

    pub fn contains(&self, key: Id) -> bool {
        self.entries.contains_key(&key)
    }

    pub fn insert(&mut self, key: Id, entry: Entry) {
        if self.entries.len() >= MAX_ENTRIES {
            self.entries.clear();
        }
        self.entries.insert(key, entry);
    }

    pub fn clear(&mut self) {
        self.entries.clear();
    }

    /// Whether entries may stand, given what the app read outside every build this frame.
    ///
    /// Such a read cannot make any single entry stale — it belongs to none of them — but the
    /// app may have derived its own state from it, which later builds read without recording.
    /// So the cache survives exactly when the reads say what they said last frame.
    /// 这些读不能单独作废某个条目——它们不属于任何条目——但 app 可能据此改了自己的状态，
    /// 而后来的构建读到那份状态却不会记录它。因此只有与上一帧读到相同的值时，缓存才留下。
    pub fn settle_outside(&mut self, now: &[Dep]) -> bool {
        // A fact the engine cannot replay can never be proven unchanged.
        // 引擎无法重放的事实，永远无法证明它没变。
        let replayable = !now.iter().any(|d| matches!(d, Dep::Volatile));
        // The first reading has nothing to compare against, so it proves nothing.
        // 第一次读数没有可比对的对象，因此证明不了任何东西。
        let held = self.observed && replayable && now == self.outside;
        self.outside.clear();
        self.outside.extend_from_slice(now);
        self.observed = true;
        held
    }

    /// Record that `key` passed validation this frame.
    /// 记录 `key` 本帧通过了校验。
    pub fn mark_checked(&mut self, key: Id, frame: u64) {
        if let Some(entry) = self.entries.get_mut(&key) {
            entry.checked = frame;
        }
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }

    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    /// Record one lookup outcome, so a profile run can tell reuse from rebuilding.
    /// 记下一次查找结果，使剖析能区分复用与重建。
    pub fn note(&mut self, hit: bool) {
        if hit {
            self.hits += 1;
        } else {
            self.misses += 1;
        }
    }

    /// Entries held, and the running (hits, misses) totals.
    /// 持有的条目数，以及累计的（命中, 未命中）次数。
    pub fn stats(&self) -> (usize, u64, u64) {
        (self.entries.len(), self.hits, self.misses)
    }
}

/// Whether a recorded animation call still reads the same value when replayed.
/// 重放一次记录过的动画调用，看读到的还是不是同一个值。
pub fn anim_still_matches(anim: &mut AnimStore, dep: &Dep, now: f64) -> bool {
    match dep {
        Dep::Anim {
            id,
            target,
            spec,
            value,
        } => anim.animate(*id, *target, *spec, now) == *value,
        Dep::AnimColour {
            id,
            target,
            spec,
            value,
        } => anim.animate_colour(*id, *target, *spec, now) == *value,
        Dep::AnimStops {
            id,
            stops,
            spec,
            value,
        } => anim.animate_stops(*id, stops, *spec, now) == *value,
        Dep::Value { id, value } => anim.value(*id, now).unwrap_or(0.0) == *value,
        // A time-driven element is stale as soon as the clock moves, by design.
        // 时间驱动的元素一旦时钟移动就过期，这是设计如此。
        Dep::Age { id, age } => anim.age_of(*id, now).is_some_and(|a| a as f32 == *age),
        Dep::Status { id, status } => anim.status(*id, now) == *status,
        _ => true,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn entries_stand_only_while_the_apps_outside_reads_repeat() {
        let a = Id::of("a");
        let b = Id::of("b");
        let mut cache = DeclCache::default();
        let quiet = [Dep::Hovered(None), Dep::Pressed(None)];
        // The first reading has nothing to compare against, so it proves nothing.
        // 第一次读数没有可比对的对象，因此证明不了任何东西。
        assert!(!cache.settle_outside(&quiet));
        assert!(cache.settle_outside(&quiet));
        assert!(!cache.settle_outside(&[Dep::Hovered(Some(a)), Dep::Pressed(None)]));
        assert!(!cache.settle_outside(&[Dep::Hovered(Some(b)), Dep::Pressed(None)]));
        // A fact the engine cannot replay never proves itself unchanged.
        // 引擎无法重放的事实永远无法证明自己没变。
        assert!(!cache.settle_outside(&[Dep::Volatile]));
        assert!(!cache.settle_outside(&[Dep::Volatile]));
    }
}
