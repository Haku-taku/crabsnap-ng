//! Caret arithmetic for a single-line text input, independent of any font or widget.
//! 单行文本输入的插入符运算，独立于字体与控件。
//!
//! Every step is one grapheme cluster (UAX #29), so `3️⃣` or `👨‍👩‍👧` moves and deletes whole.
//! 每一步都是一个字簇（UAX #29），因此 `3️⃣`、`👨‍👩‍👧` 整体移动、整体删除。

use crate::grapheme;

/// `caret` brought to a cluster boundary of `value`, clamped to its length.
/// 把 `caret` 收到 `value` 的字簇边界上，并夹到长度之内。
///
/// Callers may hold an offset from a previous frame; a buffer that shrank must not split a
/// character when the next edit is applied.
/// 调用方可能持有上一帧的偏移；缓冲变短后，下一次编辑不得劈开字符。
pub fn clamp(value: &str, caret: usize) -> usize {
    grapheme::snap(value, caret)
}

/// Move the caret `delta` clusters from `caret`; negative moves towards the start.
/// 把插入符从 `caret` 移动 `delta` 个字簇；负值向开头移动。
pub fn moved(value: &str, caret: usize, delta: isize) -> usize {
    let mut at = clamp(value, caret);
    if delta >= 0 {
        for _ in 0..delta {
            at = grapheme::next(value, at);
        }
    } else {
        for _ in 0..delta.unsigned_abs() {
            at = grapheme::prev(value, at);
        }
    }
    at
}

/// `value` with `insert` spliced in at the caret; the caret lands after the inserted text.
/// 在插入符处插入 `insert` 后的 `value`；插入符停在插入文本之后。
pub fn insert(value: &str, caret: usize, insert: &str) -> (String, usize) {
    let at = clamp(value, caret);
    let mut out = String::with_capacity(value.len() + insert.len());
    out.push_str(&value[..at]);
    out.push_str(insert);
    out.push_str(&value[at..]);
    (out, at + insert.len())
}

/// `value` with the cluster before the caret removed; at the start nothing changes.
/// 删除插入符前一个字簇后的 `value`；在开头时不变。
pub fn backspace(value: &str, caret: usize) -> (String, usize) {
    let at = clamp(value, caret);
    let prev = grapheme::prev(value, at);
    if prev == at {
        return (value.to_string(), at);
    }
    let mut out = String::with_capacity(value.len());
    out.push_str(&value[..prev]);
    out.push_str(&value[at..]);
    (out, prev)
}

/// The word around `at`: a run of alphanumeric clusters, or one cluster off a word.
/// `at` 附近的词：一段字母数字字簇，或词外的一个字簇。
///
/// CJK characters are alphanumeric, so a double click selects a whole run of them; ICU
/// word breaking would pick one word, and that is a later refinement, not this contract.
/// CJK 字符属于字母数字，因此双击会选中整段；ICU 分词会选一个词，那是以后的细化，不属于本契约。
pub fn word_at(value: &str, at: usize) -> std::ops::Range<usize> {
    let at = clamp(value, at);
    if value.is_empty() {
        return at..at;
    }
    let mut start = at;
    while start > 0 {
        let prev = grapheme::prev(value, start);
        if !is_word_cluster(&value[prev..start]) {
            break;
        }
        start = prev;
    }
    let mut end = at;
    while end < value.len() {
        let next = grapheme::next(value, end);
        if !is_word_cluster(&value[end..next]) {
            break;
        }
        end = next;
    }
    if start == end {
        // Off a word: the cluster at the caret, or the one before it at the end.
        // 不在词上：取插入符处的一个字簇；在末尾时取前一个。
        if at < value.len() {
            end = grapheme::next(value, at);
        } else {
            start = grapheme::prev(value, at);
        }
    }
    start..end
}

/// What `word_at` counts as a word cluster: the base character decides, its marks follow it.
/// `word_at` 视为词的字簇：由基字符决定，其组合标记随之归属。
fn is_word_cluster(cluster: &str) -> bool {
    cluster.chars().next().is_some_and(is_word_char)
}

/// What `word_at` counts as a word character.
/// `word_at` 视为词字符的集合。
fn is_word_char(c: char) -> bool {
    c.is_alphanumeric() || c == '_'
}

/// The word-wise neighbour of `caret`: past the separators and over one word, in `delta`'s
/// direction. From inside a word it stops at that word's edge, like every mature editor.
/// `caret` 的词级邻居：越过分隔符再跨过一个词，方向由 `delta` 决定。
/// 从词中间出发时停在该词的边缘，与成熟编辑器一致。
pub fn step_word(value: &str, caret: usize, delta: isize) -> usize {
    let mut at = clamp(value, caret);
    if delta >= 0 {
        while at < value.len() && !is_word_cluster(&value[at..grapheme::next(value, at)]) {
            at = grapheme::next(value, at);
        }
        while at < value.len() && is_word_cluster(&value[at..grapheme::next(value, at)]) {
            at = grapheme::next(value, at);
        }
    } else {
        while at > 0 && !is_word_cluster(&value[grapheme::prev(value, at)..at]) {
            at = grapheme::prev(value, at);
        }
        while at > 0 && is_word_cluster(&value[grapheme::prev(value, at)..at]) {
            at = grapheme::prev(value, at);
        }
    }
    at
}

/// `value` with `range` removed; the caret lands where the range began.
/// 移除 `range` 后的 `value`；插入符停在区间起点。
pub fn delete_range(value: &str, range: std::ops::Range<usize>) -> (String, usize) {
    let a = clamp(value, range.start);
    let b = clamp(value, range.end);
    let (start, end) = (a.min(b), a.max(b));
    let mut out = String::with_capacity(value.len());
    out.push_str(&value[..start]);
    out.push_str(&value[end..]);
    (out, start)
}

/// `value` with the cluster after the caret removed; at the end nothing changes.
/// 删除插入符后一个字簇后的 `value`；在末尾时不变。
pub fn delete(value: &str, caret: usize) -> (String, usize) {
    let at = clamp(value, caret);
    let next = grapheme::next(value, at);
    if next == at {
        return (value.to_string(), at);
    }
    let mut out = String::with_capacity(value.len());
    out.push_str(&value[..at]);
    out.push_str(&value[next..]);
    (out, at)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn an_edit_lands_on_a_char_boundary_even_when_the_caret_is_stale() {
        // A buffer that shrank while the caret stayed put must not be split mid-character.
        // 缓冲变短而插入符未动时，不得从字符中间劈开。
        let value = "aé";
        assert_eq!(clamp(value, 2), 1, "2 is inside `é`");
        assert_eq!(clamp(value, 99), 3, "past the end is the end");
        let (out, at) = insert(value, 2, "x");
        assert_eq!((out.as_str(), at), ("axé", 2));
    }

    #[test]
    fn a_caret_step_counts_characters_not_bytes() {
        // The caret moves over `é` in one step, and stops at both ends.
        // 插入符一步跨过 `é`，并在两端停下。
        let value = "aéb";
        assert_eq!(moved(value, 0, 1), 1);
        assert_eq!(moved(value, 1, 1), 3);
        assert_eq!(moved(value, 3, -1), 1);
        assert_eq!(moved(value, 3, -2), 0);
        assert_eq!(moved(value, 3, 9), 4);
        assert_eq!(moved(value, 0, -1), 0);
    }

    #[test]
    fn an_arrow_step_crosses_a_keycap_as_one_character() {
        // UAX #29: `3️⃣` and `👨‍👩‍👧` are one cluster, so no step lands between their code points.
        // UAX #29：`3️⃣` 与 `👨‍👩‍👧` 各是一个字簇，因此任何一步都不会停在它们的码点之间。
        let value = "3\u{fe0f}\u{20e3}x\u{1f468}\u{200d}\u{1f469}\u{200d}\u{1f467}";
        let keycap = "3\u{fe0f}\u{20e3}".len();
        let family = keycap + 1 + "\u{1f468}\u{200d}\u{1f469}\u{200d}\u{1f467}".len();
        assert_eq!(moved(value, 0, 1), keycap);
        assert_eq!(moved(value, keycap, 1), keycap + 1);
        assert_eq!(moved(value, keycap + 1, 1), family);
        assert_eq!(moved(value, family, -1), keycap + 1);
        assert_eq!(moved(value, family, -3), 0);
        assert_eq!(clamp(value, 1), 0, "an offset inside the keycap snaps back");
    }

    #[test]
    fn a_delete_removes_whole_clusters_only() {
        // Backspace and Delete take the cluster next to the caret, never a code point of it.
        // 退格与删除取插入符旁的一整个字簇，绝不取它的某个码点。
        let keycap = "3\u{fe0f}\u{20e3}";
        assert_eq!(backspace(keycap, keycap.len()), (String::new(), 0));
        assert_eq!(delete(keycap, 0), (String::new(), 0));
        assert_eq!(backspace("a👨‍👩‍👧", "a👨‍👩‍👧".len()).0, "a");
        assert_eq!(delete("👨‍👩‍👧b", 0).0, "b");
    }

    #[test]
    fn a_word_stops_at_the_neighbouring_space() {
        // Double click picks the run of letters under the pointer, not the whole line.
        // 双击选中指针下的那段字母，而不是整行。
        let value = "alpha bravo";
        assert_eq!(word_at(value, 2), 0..5);
        assert_eq!(word_at(value, 5), 0..5, "the space picks the word before it");
        assert_eq!(word_at(value, 6), 6..11);
        assert_eq!(word_at(value, 11), 6..11, "the end picks the last word");
        assert_eq!(word_at(value, 99), 6..11, "a stale offset clamps first");
        assert_eq!(word_at(", ,", 1), 1..2, "off a word, one character");
    }

    #[test]
    fn a_word_step_crosses_the_separator_and_stops_at_the_next_word_end() {
        // Ctrl+arrow: from mid-word to that word's end, then over the space to the next end.
        // Ctrl+方向键：从词中间到该词末尾，再越过分隔符到下一个词末尾。
        let value = "alpha bravo";
        assert_eq!(step_word(value, 2, 1), 5);
        assert_eq!(step_word(value, 5, 1), 11);
        assert_eq!(step_word(value, 11, 1), 11, "the end is a wall");
        assert_eq!(step_word(value, 11, -1), 6);
        assert_eq!(step_word(value, 6, -1), 0);
        assert_eq!(step_word(value, 0, -1), 0);
        assert_eq!(step_word("  ab  ", 0, 1), 4, "leading separators are skipped");
        assert_eq!(step_word("  ab  ", 6, -1), 2, "so are trailing ones");
    }

    #[test]
    fn deleting_at_an_end_leaves_the_buffer_alone() {
        // Both deletes are no-ops at their end; the caret must not drift either.
        // 两种删除在各自端点都是空操作；插入符也不得漂移。
        assert_eq!(backspace("ab", 0), ("ab".to_string(), 0));
        assert_eq!(delete("ab", 2), ("ab".to_string(), 2));
        assert_eq!(backspace("aé", 3).0, "a");
        assert_eq!(delete("aé", 1).0, "a");
    }

    #[test]
    // The reversed range is the point of the second case, not a slip.
    // 反转区间是第二个用例的意图，不是笔误。
    #[allow(clippy::reversed_empty_ranges)]
    fn a_selection_is_removed_as_one_unit_and_the_caret_lands_at_its_start() {
        // Typing over a selection is one edit, not a delete followed by an insert.
        // 在选区上输入是一次编辑，而不是先删后插。
        assert_eq!(delete_range("alpha bravo", 6..11), ("alpha ".to_string(), 6));
        assert_eq!(delete_range("alpha bravo", 11..6), ("alpha ".to_string(), 6), "a backwards range still works");
        assert_eq!(delete_range("aé", 0..2), ("é".to_string(), 0), "the end clamps to a character boundary");
    }
}
