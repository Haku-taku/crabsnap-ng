//! Effects as a category: a separable convolution plus a colour transform.
//! 效果作为类别：一个可分离卷积加上一个颜色变换。
//!
//! The renderer never learns the name of an effect. It knows two operations — weighted
//! sampling of neighbours, and a 4x4 transform on premultiplied RGBA — and every effect is
//! expressed as those two. Adding a new one must not touch the renderer.
//! 渲染器永远不知道效果的名字。它只知道两个操作——邻域加权采样，以及预乘 RGBA 上的
//! 4x4 变换——所有效果都由这两者表达。新增效果不得改动渲染器。

/// A one-dimensional normalised kernel; the 2D kernel is its outer product.
/// 一维归一化卷积核；二维核是它的外积。
#[derive(Clone, Debug, PartialEq)]
pub struct Kernel {
    /// Samples on each side. `0` means the identity.
    /// 每侧的采样数。`0` 表示恒等。
    pub radius: u32,
    /// Standard deviation the weights came from; `0` for a non-gaussian kernel.
    /// 生成权重所用的标准差；非高斯核为 `0`。
    pub sigma: f32,
    /// `2 * radius + 1` weights summing to 1, or a single `1.0` for a windowed kernel.
    /// `2 * radius + 1` 个和为 1 的权重；窗口核则是单个 `1.0`。
    pub weights: Vec<f32>,
    /// Box passes per axis behind this kernel; `0` means an explicit weight row.
    /// 构成该核的每轴箱式趟数；`0` 表示使用显式权重行。
    pub boxes: u32,
}

impl Kernel {
    pub const IDENTITY: Kernel = Kernel {
        radius: 0,
        sigma: 0.0,
        weights: Vec::new(),
        boxes: 0,
    };

    /// Gaussian with `sigma`, truncated at three standard deviations.
    /// 标准差 `sigma` 的高斯核，在三个标准差处截断。
    ///
    /// `radius` is the *actual* truncation the caller can afford; `guaranteed_reach` reports
    /// the analytic one, so a cheap blur is visibly cheaper rather than silently wrong.
    /// `radius` 是调用方实际能负担的截断；`guaranteed_reach` 给出解析值，
    /// 使便宜的模糊看起来便宜，而不是悄悄算错。
    pub fn gaussian(radius: u32, sigma: f32) -> Self {
        if radius == 0 || sigma <= 0.0 {
            return Self::IDENTITY;
        }
        // A kernel wider than the shader's array loses its tail and stops summing to one,
        // which reads as "the image got darker" rather than "blurrier".
        // 比着色器数组更宽的核会丢掉尾部、不再归一，看起来像「画面变暗」而不是「更模糊」。
        let radius = radius.min(MAX_KERNEL_RADIUS);
        let r = radius as i32;
        let mut weights: Vec<f32> = (-r..=r)
            .map(|i| {
                let x = i as f32;
                (-(x * x) / (2.0 * sigma * sigma)).exp()
            })
            .collect();
        let sum: f32 = weights.iter().sum();
        if sum > 0.0 {
            for w in &mut weights {
                *w /= sum;
            }
        }
        Self {
            radius,
            sigma,
            weights,
            boxes: 0,
        }
    }

    /// Analytic reach needed to be indistinguishable from an infinite gaussian.
    /// 与无限高斯不可区分所需的解析半径。
    pub fn guaranteed_reach(&self) -> u32 {
        (3.0 * self.sigma).ceil().max(0.0) as u32
    }

    pub fn is_identity(&self) -> bool {
        self.radius == 0 || self.weights.is_empty()
    }

    /// How far this kernel samples outside its own pixel, in pixels.
    /// 本核在自身像素之外采样的距离，单位为像素。
    pub fn reach(&self) -> u32 {
        self.radius
    }

    /// Working band this kernel's passes need, which a windowed kernel widens per pass.
    /// 该核各趟所需的工带；窗口核会随趟数变宽。
    pub fn band(&self) -> u32 {
        // Each extra box pass reads one more radius, so the band grows with the count.
        // 每多一趟箱式就多读一个半径，因此工带随趟数增长。
        let passes = self.boxes.max(1);
        self.radius.saturating_mul(passes)
    }
}

/// Row-major 4x4 transform on premultiplied `[r, g, b, a]`.
/// 预乘 `[r, g, b, a]` 上的行主序 4x4 变换。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ColorMatrix(pub [f32; 16]);

impl ColorMatrix {
    pub const IDENTITY: ColorMatrix = ColorMatrix([
        1.0, 0.0, 0.0, 0.0, //
        0.0, 1.0, 0.0, 0.0, //
        0.0, 0.0, 1.0, 0.0, //
        0.0, 0.0, 0.0, 1.0,
    ]);

    /// Uniform fade. On premultiplied data every channel scales, alpha included.
    /// 均匀淡出。预乘数据上所有通道一起缩放，包括 alpha。
    pub fn opacity(alpha: f32) -> Self {
        let a = alpha.clamp(0.0, 1.0);
        ColorMatrix([
            a, 0.0, 0.0, 0.0, //
            0.0, a, 0.0, 0.0, //
            0.0, 0.0, a, 0.0, //
            0.0, 0.0, 0.0, a,
        ])
    }

    /// Luma-preserving saturation, applied to the colour part only.
    /// 保持亮度的饱和度调整，只作用于颜色部分。
    pub fn saturate(s: f32) -> Self {
        const R: f32 = 0.2126;
        const G: f32 = 0.7152;
        const B: f32 = 0.0722;
        let (r, g, b) = (R * (1.0 - s), G * (1.0 - s), B * (1.0 - s));
        ColorMatrix([
            r + s, g, b, 0.0, //
            r, g + s, b, 0.0, //
            r, g, b + s, 0.0, //
            0.0, 0.0, 0.0, 1.0,
        ])
    }

    pub fn is_identity(&self) -> bool {
        self.0 == ColorMatrix::IDENTITY.0
    }

    /// True when this is nothing but a uniform alpha scale.
    /// 仅当本矩阵只是均匀 alpha 缩放时为真。
    pub fn as_opacity(&self) -> Option<f32> {
        let m = self.0;
        let a = m[0];
        let diagonal = [m[0], m[5], m[10], m[15]];
        if diagonal.iter().all(|d| *d == a) && (0.0..=1.0).contains(&a) {
            let off = [m[1], m[2], m[3], m[4], m[6], m[7], m[8], m[9], m[11], m[12], m[13], m[14]];
            if off.iter().all(|v| *v == 0.0) {
                return Some(a);
            }
        }
        None
    }

    /// `self` applied after `inner`.
    /// 在 `inner` 之后应用 `self`。
    pub fn multiply(&self, inner: &ColorMatrix) -> Self {
        let a = self.0;
        let b = inner.0;
        let mut out = [0.0f32; 16];
        for row in 0..4 {
            for col in 0..4 {
                out[row * 4 + col] = (0..4).map(|k| a[row * 4 + k] * b[k * 4 + col]).sum();
            }
        }
        ColorMatrix(out)
    }

    pub fn apply(&self, px: [f32; 4]) -> [f32; 4] {
        let m = &self.0;
        let mut out = [0.0f32; 4];
        for row in 0..4 {
            out[row] = (0..4).map(|k| m[row * 4 + k] * px[k]).sum();
        }
        out
    }
}

impl Default for ColorMatrix {
    fn default() -> Self {
        Self::IDENTITY
    }
}

/// Widest radius every backend can run: the GLSL shader holds 33 taps, i.e. radius 16.
/// 所有后端都能跑的最大半径：GLSL 着色器只有 33 个 tap，即半径 16。
pub const MAX_KERNEL_RADIUS: u32 = 16;

/// One step of an effect chain.
/// 效果链中的一步。
#[derive(Clone, Debug, PartialEq)]
pub struct Effect {
    pub kernel: Kernel,
    pub color: ColorMatrix,
}

impl Effect {
    pub fn none() -> Self {
        Self {
            kernel: Kernel::IDENTITY,
            color: ColorMatrix::IDENTITY,
        }
    }

    /// Group opacity, expressed in the same algebra as everything else.
    /// 组透明度，用与其它效果相同的代数表达。
    pub fn opacity(alpha: f32) -> Self {
        Self {
            kernel: Kernel::IDENTITY,
            color: ColorMatrix::opacity(alpha),
        }
    }

    pub fn blur(radius: u32, sigma: f32) -> Self {
        Self {
            kernel: Kernel::gaussian(radius, sigma),
            color: ColorMatrix::IDENTITY,
        }
    }

    /// Gaussian approximated by three box passes, which costs the same at any radius.
    /// 用三趟箱式近似的高斯，任意半径代价相同。
    ///
    /// The box width lives in `radius`; `weights` stays a single tap so backends that only
    /// understand explicit kernels still see a well-formed (if unblurred) effect rather
    /// than an out-of-range array.
    /// 箱宽记在 `radius`；`weights` 只留一个 tap，使只认识显式核的后端仍得到一个合法的
    /// （尽管未模糊的）效果，而不是越界数组。
    pub fn box_blur(sigma: f32) -> Self {
        let radius = crate::boxblur::radius_for_sigma(sigma);
        Self {
            kernel: Kernel {
                radius,
                sigma: crate::boxblur::sigma_for_radius(radius),
                weights: vec![1.0],
                boxes: crate::boxblur::BOX_PASSES,
            },
            color: ColorMatrix::IDENTITY,
        }
    }

    /// Whether this effect expects a sliding-window box pass instead of a kernel row.
    /// 本效果是否要求滑动窗口箱式处理，而非一行核权重。
    pub fn is_box(&self) -> bool {
        self.kernel.boxes > 0
    }

    pub fn with_color(self, color: ColorMatrix) -> Self {
        Self {
            kernel: self.kernel,
            color: self.color.multiply(&color),
        }
    }

    pub fn is_noop(&self) -> bool {
        self.kernel.is_identity() && self.color.is_identity()
    }

    /// Pixels this effect's *result* depends on beyond its own rect; drives damage tests.
    /// 本效果**结果**在自身矩形之外依赖的像素数；用于脏区判定。
    ///
    /// This is the number a backend must not under-report: it decides which frame pixels
    /// invalidate the cached result.
    /// 这是后端不得少报的数字：它决定哪些帧像素会让缓存结果失效。
    pub fn reach(&self) -> u32 {
        self.kernel.reach()
    }

    /// Internal working band the backend needs to produce that result.
    /// 后端产生该结果所需的内部工带。
    ///
    /// Separate from [`Effect::reach`] because it covers intermediate passes, not the
    /// pixels the output depends on. Each effect kind states its own value.
    /// 与 [`Effect::reach`] 分开：它覆盖中间趟次，而非输出所依赖的像素。每种效果自报其值。
    pub fn band(&self) -> u32 {
        self.kernel.band()
    }
}

/// How far a chain of effects can reach, for damage and layer padding.
/// 效果链能触及的距离，用于脏区与层留白。
///
/// `guaranteed` is the analytic bound; `actual` is what the chain really uses. Keeping both
/// stops an approximation from being reported as if it were the real thing.
/// `guaranteed` 是解析界，`actual` 是链真正使用的值。两者都留着，
/// 避免把近似当成真值报告。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct EffectReach {
    pub guaranteed: u32,
    pub actual: u32,
}

impl EffectReach {
    pub fn of(effects: &[Effect]) -> Self {
        let mut reach = Self::default();
        for e in effects {
            // The band must cover the whole pass chain, not just the result's dependence.
            // 工带必须覆盖整条趟链，而不只是结果的依赖范围。
            reach.actual += e.band();
            reach.guaranteed += e.kernel.guaranteed_reach();
        }
        reach
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn identity_effect_changes_nothing() {
        let e = Effect::none();
        assert!(e.is_noop());
        assert_eq!(e.reach(), 0);
        let px = [0.25, 0.5, 0.125, 0.8];
        assert_eq!(e.color.apply(px), px);
    }

    #[test]
    fn gaussian_weights_sum_to_one() {
        // Mass conservation is what stops a blur from darkening the picture.
        // 质量守恒是模糊不会让画面变暗的原因。
        for sigma in [0.8f32, 1.5, 3.0, 6.0] {
            let k = Kernel::gaussian(8, sigma);
            let sum: f32 = k.weights.iter().sum();
            assert!((sum - 1.0).abs() < 1e-5, "sigma {sigma} sums to {sum}");
        }
    }

    #[test]
    fn gaussian_is_symmetric() {
        let k = Kernel::gaussian(4, 2.0);
        let n = k.weights.len();
        for i in 0..n / 2 {
            assert!(
                (k.weights[i] - k.weights[n - 1 - i]).abs() < 1e-6,
                "weights must be symmetric at {i}"
            );
        }
    }

    #[test]
    fn opacity_scales_every_premultiplied_channel() {
        // Alpha included: premultiplied data would otherwise lose its colour balance.
        // 包括 alpha：否则预乘数据会丢失颜色平衡。
        let m = ColorMatrix::opacity(0.5);
        assert_eq!(m.apply([0.4, 0.2, 0.1, 0.8]), [0.2, 0.1, 0.05, 0.4]);
        assert_eq!(m.as_opacity(), Some(0.5));
    }

    #[test]
    fn matrices_compose_in_application_order() {
        let outer = ColorMatrix::opacity(0.5);
        let inner = ColorMatrix::saturate(0.0);
        let px = [0.3, 0.6, 0.1, 0.9];
        let expected = outer.apply(inner.apply(px));
        let got = outer.multiply(&inner).apply(px);
        for i in 0..4 {
            assert!((got[i] - expected[i]).abs() < 1e-6, "channel {i}");
        }
    }

    /// A windowed kernel needs a wider working band than the pixels it depends on.
    /// 窗口核所需的工带比它依赖的像素范围更宽。
    #[test]
    fn a_box_chain_reports_a_band_wider_than_its_reach() {
        let boxed = Effect::box_blur(6.0);
        assert!(
            boxed.band() > boxed.reach(),
            "the pass chain must reserve more than the result's dependence: {} vs {}",
            boxed.band(),
            boxed.reach()
        );
        // A kernel with a different pass count must report a different band, which a
        // hardcoded multiplier cannot do.
        // 趟数不同的核必须报出不同的工带，写死的倍数做不到这一点。
        let mut two_pass = boxed.clone();
        two_pass.kernel.boxes = 2;
        assert_ne!(
            two_pass.band(),
            boxed.band(),
            "the band must follow the kernel's own pass count"
        );
        assert_eq!(two_pass.band(), two_pass.kernel.radius * 2);
    }

    /// An explicit weight row needs no extra band: it reads exactly its reach.
    /// 显式权重行不需要额外工带：它读取的正是自己的 reach。
    #[test]
    fn an_explicit_kernel_needs_no_extra_band() {
        let g = Effect::blur(8, 3.0);
        assert_eq!(
            g.band(),
            g.reach(),
            "a single separable pass reads only its own radius"
        );
    }

    #[test]
    fn a_blur_reports_its_own_reach() {
        let e = Effect::blur(6, 2.0);
        assert_eq!(e.reach(), 6);
        let chain = [Effect::blur(4, 1.5), Effect::opacity(0.5)];
        let reach = EffectReach::of(&chain);
        assert_eq!(reach.actual, 4, "only the kernel widens the read region");
    }

    #[test]
    fn guaranteed_reach_is_analytic_and_can_exceed_the_truncation() {
        // A cheap blur is honestly reported as cheaper, not as if it were exact.
        // 便宜的模糊要诚实地报成便宜，而不是假装精确。
        let truncated = Kernel::gaussian(4, 2.5);
        assert_eq!(truncated.reach(), 4);
        assert_eq!(truncated.guaranteed_reach(), 8, "ceil(3 * 2.5)");

        let full = Kernel::gaussian(8, 2.5);
        assert_eq!(full.guaranteed_reach(), full.reach(), "truncation reaches the bound");
    }
}
