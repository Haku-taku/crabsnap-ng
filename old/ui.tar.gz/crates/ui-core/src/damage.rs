//! Damage: which regions changed this frame.
//! 脏区：本帧变化的区域。

use crate::geom::Rect;

/// Regions that must be redrawn.
/// 需要重绘的区域。
#[derive(Clone, Debug, Default, PartialEq)]
pub enum Damage {
    /// Nothing changed; the frame can be skipped entirely.
    /// 无变化；整帧可跳过。
    #[default]
    None,
    /// Specific rects.
    /// 具体矩形。
    Rects(Vec<Rect>),
    /// Everything.
    /// 全部。
    Full,
}

impl Damage {
    pub fn is_none(&self) -> bool {
        matches!(self, Damage::None)
    }

    pub fn is_full(&self) -> bool {
        matches!(self, Damage::Full)
    }

    /// Rects as slices, flattening `Full` to the given bounds.
    /// 展平成矩形切片；`Full` 展成给定范围。
    pub fn rects(&self, full: Rect) -> Vec<Rect> {
        match self {
            Damage::None => Vec::new(),
            Damage::Rects(r) => r.clone(),
            Damage::Full => vec![full],
        }
    }
}

/// Collects damage rects across a frame, merging overlaps.
/// 跨帧收集脏矩形，合并相交者。
#[derive(Default, Debug)]
pub struct DamageAccum {
    rects: Vec<Rect>,
    full: bool,
}

impl DamageAccum {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn add(&mut self, r: Rect) {
        if r.is_empty() || self.full {
            return;
        }
        // Merge into an existing rect when they overlap; keeps the list short.
        // 与已有矩形相交时合并，保持列表短小。
        for existing in &mut self.rects {
            if existing.intersects(r) {
                *existing = existing.union(r);
                self.coalesce();
                return;
            }
        }
        self.rects.push(r);
    }

    /// Snapshot of what has been collected so far, for rules that depend on it.
    /// 已收集内容的快照，供依赖它的规则使用。
    pub fn snapshot(&self) -> Damage {
        if self.full {
            Damage::Full
        } else if self.rects.is_empty() {
            Damage::None
        } else {
            Damage::Rects(self.rects.clone())
        }
    }

    pub fn add_full(&mut self) {
        self.full = true;
        self.rects.clear();
    }

    fn coalesce(&mut self) {
        let mut merged = true;
        while merged {
            merged = false;
            'outer: for i in 0..self.rects.len() {
                for j in (i + 1)..self.rects.len() {
                    if self.rects[i].intersects(self.rects[j]) {
                        let u = self.rects[i].union(self.rects[j]);
                        self.rects[i] = u;
                        self.rects.remove(j);
                        merged = true;
                        break 'outer;
                    }
                }
            }
        }
    }

    pub fn finish(self) -> Damage {
        if self.full {
            Damage::Full
        } else if self.rects.is_empty() {
            Damage::None
        } else {
            Damage::Rects(self.rects)
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn r(x: f32, y: f32, w: f32, h: f32) -> Rect {
        Rect::new(x, y, w, h)
    }

    #[test]
    fn no_additions_produce_none() {
        assert_eq!(DamageAccum::new().finish(), Damage::None);
    }

    #[test]
    fn overlapping_rects_merge_into_one() {
        let mut acc = DamageAccum::new();
        acc.add(r(0.0, 0.0, 10.0, 10.0));
        acc.add(r(5.0, 5.0, 10.0, 10.0));
        match acc.finish() {
            Damage::Rects(v) => {
                assert_eq!(v.len(), 1);
                assert_eq!(v[0], r(0.0, 0.0, 15.0, 15.0));
            }
            other => panic!("expected rects, got {other:?}"),
        }
    }

    #[test]
    fn disjoint_rects_stay_separate() {
        let mut acc = DamageAccum::new();
        acc.add(r(0.0, 0.0, 10.0, 10.0));
        acc.add(r(100.0, 100.0, 10.0, 10.0));
        match acc.finish() {
            Damage::Rects(v) => assert_eq!(v.len(), 2),
            other => panic!("expected rects, got {other:?}"),
        }
    }

    #[test]
    fn full_swallows_everything() {
        let mut acc = DamageAccum::new();
        acc.add(r(0.0, 0.0, 10.0, 10.0));
        acc.add_full();
        acc.add(r(50.0, 50.0, 10.0, 10.0));
        assert_eq!(acc.finish(), Damage::Full);
    }
}
