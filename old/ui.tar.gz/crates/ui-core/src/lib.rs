//! Core of the UI engine: ids, tree, layout, drawing, damage, hit testing.
//! UI 引擎内核：标识、树、布局、绘制、脏区、命中测试。
//!
//! No platform, GPU, or windowing dependency lives here; that is what keeps the
//! engine testable without a compositor.
//! 这里不依赖平台、GPU 或窗口系统；这正是引擎能在无 compositor 环境下测试的原因。

pub mod anim;
pub mod change;
pub mod cx;
pub mod boxblur;
pub mod damage;
pub mod drag;
pub mod effect;
pub mod event;
pub mod flex;
pub mod grid;
pub mod collections;
pub mod colour;
pub mod cursor;
pub mod draw;
pub mod geom;
pub mod grapheme;
pub mod hit;
pub mod id;
pub mod layout;
pub mod layout_engine;
pub mod memo;
pub mod menu;
pub mod selection;
pub mod slot;
pub mod ime;
pub mod text;
pub mod text_input;
pub mod sense;
pub use change::Change;
pub use sense::Sense;
pub mod shortcut;
pub mod tree;

pub use anim::{AnimSpec, AnimStore, Easing, PieceCubic, Status, Travel};
pub use cursor::CursorShape;
pub use damage::{Damage, DamageAccum};
pub use drag::{past_threshold, DragEvent, DragState, DragTracker, DRAG_THRESHOLD};
pub use memo::{CachedKey, DeclCache, Dep};
pub use menu::MenuItem;
pub use ime::Preedit;
pub use selection::{
    flat_selection, SelectionFragment, SelectionGeometry, SelectionPaint, SelectionPainter,
    SelectionPainterRef, SelectionPrim, TextSelection,
};
pub use effect::{ColorMatrix, Effect, EffectReach, Kernel};
pub use event::{Event, Key, Modifiers, PointerButton};
pub use shortcut::{KeyChord, ShortcutId};
pub use draw::{Batch, Caret, DrawList, GlyphKind, GlyphPrim, InkRadius, InkTarget, PrimKind, Primitives, PressInk, RectPrim, TextPrim};
pub use geom::{Color, CornerShape, Corners, Insets, Point, Rect, Size};
pub use hit::{HitBehavior, HitIndex, HitTarget};
pub use text::{
    AtomBox, Family, Features, GenericFamily, InlineAtom, InlineLayout, InlineLine, InlineRun, Span,
    TextAlign, TextBlock, TextRun, TextStyle, Variations, VerticalAlign, Weight, OBJECT,
};
pub use id::{Id, NodeId};
pub use slot::{slot_id, SlotFills, SlotName};
pub use layout::{
    Align, AutoFlow, AxisSize, AxisSizes, BoxModel, Clip, Constraints, GridArea, Grow,
    LastMeasure, LayoutEngine, LayoutStats, Len, MeasureResult, Overflow, Placement, Position,
    SizeClass, Sizing, Track, TrackBound, TrackList, AUTO,
};
pub use layout_engine::{BuiltinLayout, MonospaceMeasure, TextMeasure};
pub use tree::{ApplyStats, BackdropBlur, ContainerParams, Decl, GridItem, ModalTarget, Node, NodeData, NodeKind, ScrollbarHit, Tree};

