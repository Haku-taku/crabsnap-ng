//! The engine's build context: this frame's facts, its routing, and its animation store.
//! 引擎的构建上下文：本帧事实、本帧路由，以及动画存储。
//!
//! This layer knows nothing about styles or widgets, which is what keeps the dependency
//! direction (`ui-core` → `ui-platform` → `ui-widgets`) intact. Anything style-shaped is
//! added by a wrapper one layer up.
//! 这一层不认识风格与控件，这正是依赖方向（`ui-core` → `ui-platform` → `ui-widgets`）不变的原因。
//! 任何与风格相关的东西都由上一层的包装提供。

use crate::geom::Point;
use crate::id::{Id, NodeId};
use crate::memo::{CachedKey, DeclCache, Dep, Entry, Recorder};
use crate::tree::Tree;
use crate::{AnimSpec, AnimStore};

use std::cell::RefCell;
use std::rc::Rc;

/// One `SCROLL_OWNED` container's geometry for the build to read, both axes: content
/// extent, viewport size, offset, and whether a wheel moved it since the previous frame.
/// 一个 `SCROLL_OWNED` 容器的双轴几何，供构建读取：内容尺寸、视口、偏移，
/// 以及自上一帧以来是否有滚轮移动过它。
#[derive(Clone, Debug, Copy, PartialEq)]
pub struct ScrollGeom {
    pub id: Id,
    pub extent_w: f32,
    pub extent_h: f32,
    pub viewport_w: f32,
    pub viewport_h: f32,
    pub offset_x: f32,
    pub offset_y: f32,
    /// A wheel moved it since the previous frame; an auto scrollbar fades in on it.
    /// 上一帧以来滚轮移动过它；自动滚动条据此淡入。
    pub active: bool,
}

/// One engine-owned scroller's stored offset, the source of truth across frames.
/// 一个引擎自有滚动容器的存储偏移，跨帧的事实源。
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct ScrollOffset {
    pub x: f32,
    pub y: f32,
}

/// An app's request to move an engine-owned scroller, merged after the view returns.
/// 应用要求移动引擎自有滚动容器的请求，在 view 返回后合并。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ScrollRequest {
    pub id: Id,
    pub x: f32,
    pub y: f32,
    /// Ease to the offset instead of landing on it at once.
    /// 缓动到该偏移，而不是立即落上去。
    pub animate: bool,
}

/// Engine facts for one build, plus the only writable door it offers.
/// 一次构建的引擎事实，以及它提供的唯一可写之门。
/// Everything the engine routes this frame, as named fields: positional arguments this
/// numerous invite silent swaps, and every new fact would break every call site.
/// 引擎本帧路由的全部事实，用具名字段：这么多位置参数极易被静默调换，
/// 而每加一项事实都会破坏所有调用点。
#[derive(Clone, Debug, Default)]
pub struct Routing {
    pub hovered: Option<Id>,
    pub pressed: Option<Id>,
    /// The clicked node and its ancestors, root first; empty when nothing was clicked.
    /// 被点击节点及其祖先，根在前；无点击时为空。
    pub clicked_path: Vec<Id>,
    /// The keyboard-activated node and its ancestors, root first; empty when nothing fired.
    /// 被键盘激活的节点及其祖先，根在前；无激活时为空。
    pub activated_path: Vec<Id>,
    /// The node a drag was released on, and its ancestors, root first.
    /// 拖拽释放所在的节点及其祖先，根在前。
    pub dropped_path: Vec<Id>,
    /// The node under the pointer that accepts drops, when a drag ended this frame.
    /// 拖拽本帧结束时，指针下接受放下的节点。
    pub drop_target: Option<Id>,
    pub focused: Option<Id>,
    /// True when focus came from the keyboard, which is what a focus ring keys on.
    /// 当焦点由键盘带来时为真，焦点环据此判断。
    pub focus_visible: bool,
    /// The popup a press outside it dismissed this frame: the light-dismiss every flyout has.
    /// 本帧因外部按下而被要求关闭的浮层：每个浮层都有的「点外面关掉」。
    pub dismissed: Option<Id>,
    /// The chord that fired this frame and the node that declared it.
    /// 本帧触发的组合键，以及声明它的节点。
    pub shortcut: Option<(Id, crate::shortcut::ShortcutId)>,
    /// The text input holding the caret and the caret's byte offset, when one is focused.
    /// 持有插入符的文本输入及其插入符的字节偏移；没有聚焦的输入时为 `None`。
    pub caret: Option<(Id, usize)>,
    /// The caret's x inside the text node that draws a buffer, in that node's layout space.
    /// 插入符在绘制缓冲的那个文本节点里的 x，位于该节点的布局坐标系。
    pub caret_in_text: Option<(Id, f32)>,
    /// The text node holding a selection, and that selection.
    /// 持有选区的文本节点，以及该选区。
    pub selection: Option<(Id, crate::selection::TextSelection)>,
    /// The text input an input method is composing into, and the preedit string.
    /// 输入法正在组合的文本输入，以及预编辑串。
    pub preedit: Option<(Id, crate::ime::Preedit)>,
    pub hovered_path: Vec<Id>,
    pub pressed_path: Vec<Id>,
    pub drag_owner: Option<Id>,
    /// Whether the live press has travelled past the click threshold.
    /// 进行中的按下是否已越过点击阈值。
    pub drag_started: bool,
    /// Pointer movement since the previous frame; the reference accumulates it directly.
    /// 指针相对上一帧的位移；参考直接累加它。
    pub drag_step: Option<Point>,
    pub local: Option<Point>,
    pub disabled: Vec<Id>,
}

pub struct Cx<'a> {
    /// Frame serial; every node in this build sees the same value.
    /// 帧序号；本次构建里每个节点看到的都是同一个值。
    frame: u64,
    width: u32,
    height: u32,
    /// Seconds since the engine's epoch; the engine ticks its clock once per frame.
    /// 相对引擎起点的秒数；引擎每帧只走一次时钟。
    now: f64,
    /// Whole-frame step, for readers that want it. Animations use `now` only.
    /// 整帧步长，供需要它的读取方。动画只用 `now`。
    dt: f32,
    scale: f32,
    pointer: Option<Point>,
    /// Held modifiers at build time; a shortcut editor shows them, an Alt-drag reads them.
    /// 构建时按住的修饰键；快捷键编辑器显示它，Alt 拖拽读取它。
    modifiers: crate::event::Modifiers,
    /// The clicked node's ancestor chain, root first; empty when nothing was clicked.
    /// 被点击节点的祖先链，根在前；无点击时为空。
    clicked_path: Vec<Id>,
    /// The keyboard-activated node's ancestor chain, root first.
    /// 被键盘激活节点的祖先链，根在前。
    activated_path: Vec<Id>,
    /// The drag-release chain, root first.
    /// 拖拽释放的祖先链，根在前。
    dropped_path: Vec<Id>,
    /// The node a drag was released onto, when it accepts drops.
    /// 拖拽释放到的节点，且它接受放下。
    drop_target: Option<Id>,
    /// Every node folded as inert this frame; normally empty.
    /// 本帧折入为惰性的全部节点；通常为空。
    disabled: Vec<Id>,
    hovered: Option<Id>,
    pressed: Option<Id>,
    focused: Option<Id>,
    focus_visible: bool,
    dismissed: Option<Id>,
    shortcut: Option<(Id, crate::shortcut::ShortcutId)>,
    caret: Option<(Id, usize)>,
    caret_in_text: Option<(Id, f32)>,
    selection: Option<(Id, crate::selection::TextSelection)>,
    preedit: Option<(Id, crate::ime::Preedit)>,
    /// Scroll geometry per `SCROLL_OWNED` container, both axes.
    /// 每个 `SCROLL_OWNED` 容器的双轴滚动几何。
    scrolls: Vec<ScrollGeom>,
    /// Offsets the app asked to write this frame, shared across reborrows.
    /// 应用本帧要求写入的偏移，跨重借出共享。
    scroll_req: Rc<RefCell<Vec<ScrollRequest>>>,
    /// Nodes the build asked to keep visible, resolved once geometry is known.
    /// 构建要求保持可见的节点，在几何确定后解析。
    bring_req: Rc<RefCell<Vec<Id>>>,
    hovered_path: Vec<Id>,
    pressed_path: Vec<Id>,
    drag_owner: Option<Id>,
    /// Whether the live press has travelled past the click threshold.
    /// 进行中的按下是否已越过点击阈值。
    drag_started: bool,
    /// Pointer movement since the previous event while a drag is live.
    /// 拖拽进行中，指针相对上一次事件的位移。
    drag_step: Option<Point>,
    /// The pointer in the pressed node's own space, when a press is live.
    /// 按下节点自身空间中的指针位置，按下有效时存在。
    ///
    /// A control cannot compute its own value from a surface point: only the node that was
    /// hit knows where the finger is inside it.
    /// 控件无法从表面坐标算出自己的值：只有被命中的节点知道手指在它内部的位置。
    local: Option<Point>,
    anim: &'a mut AnimStore,
    /// Dependency frames for the declaration cache; shared by every reborrow.
    /// 声明缓存的依赖帧；所有重借出的上下文共享它。
    rec: Rc<RefCell<Recorder>>,
    /// The cache itself, when a frame is building under one.
    /// 缓存本体，当某一帧在缓存之下构建时存在。
    cache: Option<&'a mut DeclCache>,
    /// Entries on the validation stack; a key met twice means the graph has a loop.
    /// 校验栈上的条目；同一个键出现两次说明图里有环。
    visiting: crate::collections::FastSet<Id>,
    /// The engine's text measurer, when the host has one: a build may size a label
    /// before layout runs, which is how an outline cuts its notch.
    /// 引擎的文本测量器（宿主有时）：构建期即可量出标签尺寸，描边的缺口由此得出。
    measure: Option<Rc<RefCell<dyn crate::TextMeasure>>>,
    /// The retained tree, for a build that needs last frame's geometry.
    /// 保留树，供需要上一帧几何的构建读取。
    tree: Option<&'a Tree>,
}

impl<'a> Cx<'a> {
    /// Assemble a context; the engine is the only intended caller.
    /// 组装上下文；预定只有引擎调用。
    #[allow(clippy::too_many_arguments)]
    pub fn new(
        anim: &'a mut AnimStore,
        frame: u64,
        width: u32,
        height: u32,
        now: f64,
        dt: f32,
        scale: f32,
        pointer: Option<Point>,
    ) -> Self {
        Self {
            frame,
            width,
            height,
            now,
            dt,
            scale,
            pointer,
            modifiers: crate::event::Modifiers::default(),
            hovered: None,
            pressed: None,
            clicked_path: Vec::new(),
            activated_path: Vec::new(),
            dropped_path: Vec::new(),
            drop_target: None,
            focused: None,
            focus_visible: false,
            dismissed: None,
            shortcut: None,
            caret: None,
            caret_in_text: None,
            selection: None,
            preedit: None,
            scrolls: Vec::new(),
            scroll_req: Rc::new(RefCell::new(Vec::new())),
            bring_req: Rc::new(RefCell::new(Vec::new())),
            hovered_path: Vec::new(),
            pressed_path: Vec::new(),
            drag_owner: None,
            drag_started: false,
            drag_step: None,
            local: None,
            disabled: Vec::new(),
            anim,
            rec: Rc::new(RefCell::new(Recorder::default())),
            cache: None,
            visiting: crate::collections::FastSet::default(),
            measure: None,
            tree: None,
        }
    }

    /// Share the layout's own measurer with this build, so a widget may size text early.
    /// 把布局用的同一个测量器交给本次构建，控件因此可以提前量出文本尺寸。
    pub fn attach_measure(&mut self, measure: Rc<RefCell<dyn crate::TextMeasure>>) {
        self.measure = Some(measure);
    }

    /// The size `block` takes wrapped at `max_width`, measured the way layout will measure it.
    /// `block` 在 `max_width` 下换行的尺寸，与布局所用的是同一次测量。
    ///
    /// `None` when the host supplied no measurer (tests, headless layout): a caller must then
    /// fall back to something it can derive without text, not invent a width.
    /// 宿主未提供测量器时（测试、无头布局）为 `None`：调用方此时必须回落到不依赖文本的做法，
    /// 而不是编一个宽度。
    pub fn text_size(&self, block: &crate::text::TextBlock, max_width: f32) -> Option<crate::geom::Size> {
        let measure = self.measure.as_ref()?;
        // A held borrow means paint is mid-flight; measuring is an optimisation, not a need.
        // 借用已被占用说明绘制正在进行；测量只是优化而非必需。
        let mut measure = measure.try_borrow_mut().ok()?;
        Some(measure.measure(block, max_width))
    }

    /// Build under a declaration cache, so subtrees whose facts held can be reused.
    /// 在声明缓存下构建，使事实未变的子树可以直接复用。
    pub fn attach_cache(&mut self, cache: &'a mut DeclCache) {
        self.cache = Some(cache);
    }

    /// Throw away every cached declaration; an app that mutated state must call this.
    /// 丢弃全部缓存声明；改动了状态的 app 必须调用它。
    pub fn invalidate_decls(&mut self) {
        if let Some(cache) = self.cache.as_deref_mut() {
            cache.clear();
        }
    }

    /// Stop recording while an engine pass reads routing after the declarations are built.
    /// 在引擎于声明构建之后读取路由时停止记录。
    ///
    /// Those reads cannot change this frame's declarations — they are already built — so they
    /// must not be mistaken for app state that later builds depend on.
    /// 这些读不可能改变本帧的声明——声明已经建好——因此不得被当成后续构建所依赖的 app 状态。
    pub fn mute(&self) -> bool {
        self.rec.borrow_mut().mute()
    }

    pub fn unmute(&self, was: bool) {
        self.rec.borrow_mut().unmute(was);
    }

    fn record(&self, dep: Dep) {
        if let Ok(mut rec) = self.rec.try_borrow_mut() {
            rec.push(dep);
        }
    }

    /// A handle on the recorder, for a narrower context that must record on its own.
    /// 记录器的句柄，供需要自行记录的更窄上下文使用。
    pub fn recorder_handle(&self) -> Rc<RefCell<Recorder>> {
        Rc::clone(&self.rec)
    }

    /// Whether the entries may stand, given the facts the app read outside every build.
    /// 依据 app 在所有构建之外读到的事实，决定缓存条目是否可以留下。
    ///
    /// Called once per frame, before the app builds: it takes the previous frame's readings,
    /// which must cover a whole frame for the comparison to mean anything.
    /// 每帧构建之前调用一次：取走上一帧的读数，只有覆盖完整一帧的读数才谈得上比对。
    pub fn settle_outside(&mut self) -> bool {
        let deps = self.rec.borrow_mut().take_unattributed();
        match self.cache.as_deref_mut() {
            Some(cache) => cache.settle_outside(&deps),
            None => true,
        }
    }

    /// Whether a build in this frame asked for the clock; resets the flag.
    /// 本帧是否有构建读取了时钟；读取后复位。
    pub fn take_time_driven(&mut self) -> bool {
        self.rec.borrow_mut().take_time_driven()
    }

    /// Whether this frame's builds read the raw pointer position; resets the flag.
    /// 本帧的构建是否读过原始指针位置；读取后复位。
    pub fn take_pointer_read(&mut self) -> bool {
        self.rec.borrow_mut().take_pointer_read()
    }

    /// Start recording the facts one element's build reads.
    /// 开始记录一个元素构建时读到的事实。
    pub fn begin_record(&mut self) {
        self.rec.borrow_mut().begin();
    }

    /// Stop recording and store the declaration under `key`, if it read any fact.
    /// 停止记录，若它读过事实就把声明按 `key` 存进去。
    ///
    /// A declaration that recorded nothing offers no way to prove it still holds; caching it
    /// would freeze the subtree for good, so it is kept out of the cache.
    /// 没有记录任何事实的声明无从证明自己仍然成立；缓存它会把整棵子树永久冻住，因此不入缓存。
    pub fn end_record(&mut self, key: CachedKey, decl: crate::Decl) -> Rc<crate::Decl> {
        let (deps, whole) = self.rec.borrow_mut().end_whole();
        let decl = Rc::new(decl);
        let frame = self.frame;
        if let Some(cache) = self.cache.as_deref_mut() {
            cache.insert(
                key.id,
                Entry {
                    decl: Rc::clone(&decl),
                    deps,
                    props: key.props,
                    whole,
                    checked: frame,
                },
            );
        }
        decl
    }

    /// Note that the child just built was rebuilt: its parent's declaration must not be reused.
    /// 记录刚构建的子元素是重建的：父节点的声明因此不得复用。
    pub fn note_rebuilt_child(&mut self) {
        self.rec.borrow_mut().note_rebuilt_child();
    }

    /// The cached declaration for `key`, if it was built for facts that still hold.
    /// 若 `key` 的缓存声明所依据的事实仍然成立，返回它。
    pub fn cached_decl(&mut self, key: CachedKey) -> Option<Rc<crate::Decl>> {
        self.cached_decl_matching(key, |_| true)
    }

    /// Same lookup, with the caller able to compare the cached declaration against its own
    /// inputs: a container's shell is app-built, so only a field-by-field match proves it.
    /// 同样的查找，但调用方可以拿缓存声明与自己的输入作比：容器的外壳由 app 构建，
    /// 只有逐字段相同才能证明它没变。
    pub fn cached_decl_matching(
        &mut self,
        key: CachedKey,
        same: impl FnOnce(&crate::Decl) -> bool,
    ) -> Option<Rc<crate::Decl>> {
        // The element's own inputs are half of what the declaration was built from; when
        // they moved, every recorded fact may still hold and the entry is still stale.
        // 元素自身的输入是这份声明的一半依据；它们变了时，已记录的事实可能全都成立，
        // 而条目依旧过期。
        // `whole` is part of the proof: an entry built while a child was rebuilt embeds that
        // child's old declaration, so reusing it would freeze the change that caused it.
        // `whole` 是证明的一部分：构建时有子元素被重建的条目嵌着那个子元素的旧声明，
        // 复用它会把造成这次重建的改动冻住。
        let fresh = self
            .cache
            .as_ref()
            .and_then(|c| c.get(key.id))
            .is_some_and(|e| e.props == key.props && e.whole && same(&e.decl));
        if !fresh {
            if let Some(cache) = self.cache.as_deref_mut() {
                cache.note(false);
            }
            return None;
        }
        let key = key.id;
        let hit = self.validate(key);
        if let Some(cache) = self.cache.as_deref_mut() {
            cache.note(hit);
        }
        if hit {
            self.cache.as_ref()?.get(key).map(|e| Rc::clone(&e.decl))
        } else {
            None
        }
    }

    /// Whether `key` and every cached descendant still read the facts they were built from.
    /// `key` 及其所有已缓存后代是否仍读到构建它们时的事实。
    fn validate(&mut self, key: Id) -> bool {
        let frame = self.frame;
        let (deps, kids) = {
            let Some(entry) = self.cache.as_ref().and_then(|c| c.get(key)) else {
                return false;
            };
            if entry.checked == frame {
                return true;
            }
            let cached = self.cache.as_ref().expect("looked up above");
            let kids = entry
                .decl
                .children
                .iter()
                .map(|c| c.id)
                .filter(|id| entry.whole || cached.contains(*id))
                .collect::<Vec<Id>>();
            (entry.deps.clone(), kids)
        };
        // A stale entry can point back at an ancestor after the tree was reshaped; a loop
        // here would recurse forever, so a second visit is simply a miss.
        // 树形重塑后，过期条目可能指回祖先；这里的环会无限递归，因此第二次造访直接算未命中。
        if !self.visiting.insert(key) {
            return false;
        }
        // Recording is muted while replaying: validation must not feed its own reads back.
        // 重放期间静音记录：校验不得把自己读到的事实再记一遍。
        let was = self.rec.borrow_mut().mute();
        let now = self.now;
        let held = deps.iter().all(|dep| self.dep_holds(dep, now));
        self.rec.borrow_mut().unmute(was);
        if !held {
            self.visiting.remove(&key);
            return false;
        }
        if !kids.into_iter().all(|kid| self.validate(kid)) {
            self.visiting.remove(&key);
            return false;
        }
        self.visiting.remove(&key);
        if let Some(cache) = self.cache.as_deref_mut() {
            cache.mark_checked(key, frame);
        }
        true
    }

    fn dep_holds(&mut self, dep: &Dep, now: f64) -> bool {
        match dep {
            Dep::Hovered(v) => self.hovered == *v,
            Dep::Pressed(v) => self.pressed == *v,
            Dep::Focused(v) => self.focused == *v,
            Dep::FocusVisible(v) => self.focus_visible == *v,
            Dep::Dismissed(v) => self.dismissed == *v,
            Dep::Shortcut(v) => self.shortcut == *v,
            Dep::Caret(v) => self.caret == *v,
            Dep::CaretInText(v) => self.caret_in_text == *v,
            Dep::Selection(v) => self.selection == *v,
            Dep::Preedit(v) => self.preedit == *v,
            Dep::Scroll {
                id,
                extent_w,
                extent_h,
                viewport_w,
                viewport_h,
                offset_x,
                offset_y,
                active,
            } => self
                .scrolls
                .iter()
                .find(|g| g.id == *id)
                .map(|g| {
                    g.extent_w == *extent_w
                        && g.extent_h == *extent_h
                        && g.viewport_w == *viewport_w
                        && g.viewport_h == *viewport_h
                        && g.offset_x == *offset_x
                        && g.offset_y == *offset_y
                        && g.active == *active
                })
                .unwrap_or(false),
            Dep::HoveredPath(v) => self.hovered_path == *v,
            Dep::PressedPath(v) => self.pressed_path == *v,
            Dep::HoveredWithin(id, v) => self.hovered_path.contains(id) == *v,
            Dep::PressedWithin(id, v) => self.pressed_path.contains(id) == *v,
            Dep::ClickedWithin(id, v) => self.clicked_path.contains(id) == *v,
            Dep::ActivatedWithin(id, v) => self.activated_path.contains(id) == *v,
            Dep::DroppedWithin(id, v) => self.dropped_path.contains(id) == *v,
            Dep::DraggingWithin(id, v) => (self.drag_owner == Some(*id)) == *v,
            Dep::DragStarted(id, v) => self.drag_started_within_now(*id) == *v,
            Dep::Disabled(id, v) => self.disabled.contains(id) == *v,
            Dep::Local(v) => self.local == *v,
            Dep::DragStep(v) => self.drag_step == *v,
            Dep::Modifiers(bits) => {
                let m = self.modifiers;
                let now = m.shift as u8
                    | (m.ctrl as u8) << 1
                    | (m.alt as u8) << 2
                    | (m.logo as u8) << 3;
                now == *bits
            }
            Dep::Anim { .. }
            | Dep::AnimColour { .. }
            | Dep::AnimStops { .. }
            | Dep::Value { .. }
            | Dep::Status { .. }
            | Dep::Age { .. } => crate::memo::anim_still_matches(self.anim, dep, now),
            Dep::Now(bits) => self.now.to_bits() == *bits,
            Dep::Size(w, h) => (self.width, self.height) == (*w, *h),
            Dep::Scale(bits) => self.scale.to_bits() == *bits,
            Dep::Dt(bits) => self.dt.to_bits() == *bits,
            Dep::Frame(f) => self.frame == *f,
            Dep::Pointer(p) => self.pointer == *p,
            Dep::Volatile => false,
        }
    }

    /// Attach this frame's routing; called once, before any node is built.
    /// 挂上本帧的路由；在任何节点构建之前调用一次。
    pub fn route(&mut self, r: Routing) {
        self.hovered = r.hovered;
        self.pressed = r.pressed;
        self.clicked_path = r.clicked_path;
        self.activated_path = r.activated_path;
        self.dropped_path = r.dropped_path;
        self.drop_target = r.drop_target;
        self.focused = r.focused;
        self.focus_visible = r.focus_visible;
        self.dismissed = r.dismissed;
        self.shortcut = r.shortcut;
        self.caret = r.caret;
        self.caret_in_text = r.caret_in_text;
        self.selection = r.selection;
        self.preedit = r.preedit;
        self.hovered_path = r.hovered_path;
        self.pressed_path = r.pressed_path;
        self.drag_owner = r.drag_owner;
        self.drag_started = r.drag_started;
        self.drag_step = r.drag_step;
        self.local = r.local;
        self.disabled = r.disabled;
    }

    /// Whether a drag ended on this node or a descendant this frame.
    /// 本帧是否有一次拖拽在本节点或其后代上结束。
    pub fn dropped_within(&self, id: Id) -> bool {
        let v = self.dropped_path.contains(&id);
        self.record(Dep::DroppedWithin(id, v));
        v
    }

    /// The node a drag was released onto this frame, when it accepts drops.
    /// 本帧拖拽释放到的节点，且它接受放下。
    ///
    /// Not recorded: it is only ever set on the frame `dropped_within` turns true, and
    /// cleared on the frame that turns it false, so that dependency already covers it.
    /// 不记录依赖：它只在 `dropped_within` 变真那一帧被设置、在变假那一帧被清空，
    /// 那条依赖已经覆盖了它。
    pub fn drop_target(&self) -> Option<Id> {
        self.drop_target
    }

    /// Whether this node or a descendant was activated by the keyboard this frame; a snackbar
    /// action is a child of the bar that reports it, exactly as with `clicked_within`.
    /// 本帧本节点或其后代是否由键盘激活；snackbar 的动作就是上报它的那条的子节点，
    /// 与 `clicked_within` 同理。
    pub fn activated_within(&self, id: Id) -> bool {
        let v = self.activated_path.contains(&id);
        self.record(Dep::ActivatedWithin(id, v));
        v
    }

    /// The popup a press outside it dismissed this frame, if any.
    /// 本帧因外部按下而被要求关闭的浮层，若有。
    pub fn dismissed(&self) -> Option<Id> {
        self.record(Dep::Dismissed(self.dismissed));
        self.dismissed
    }

    /// The chord that fired this frame, and the node that declared it.
    /// 本帧触发的组合键，以及声明它的节点。
    pub fn shortcut(&self) -> Option<(Id, crate::shortcut::ShortcutId)> {
        self.record(Dep::Shortcut(self.shortcut));
        self.shortcut
    }

    /// Whether a click completed on this node or a descendant this frame.
    /// 本帧是否有一次点击落在本节点或其后代上并已完成。
    pub fn clicked_within(&self, id: Id) -> bool {
        let v = self.clicked_path.contains(&id);
        self.record(Dep::ClickedWithin(id, v));
        v
    }

    /// Whether this node is inert; a disabled ancestor makes every descendant inert.
    /// 本节点是否惰性；被禁用的祖先会让所有后代惰性。
    pub fn is_disabled(&self, id: Id) -> bool {
        let v = self.disabled.contains(&id);
        self.record(Dep::Disabled(id, v));
        v
    }

    /// The pointer in the pressed node's own space.
    /// 按下节点自身空间中的指针位置。
    /// Pointer movement since the previous frame, while a drag is live.
    /// 拖拽进行中，指针相对上一次事件的位移。
    pub fn drag_step(&self) -> Option<Point> {
        self.record(Dep::DragStep(self.drag_step));
        self.drag_step
    }

    pub fn local(&self) -> Option<Point> {
        self.record(Dep::Local(self.local));
        self.local
    }

    pub fn hovered(&self) -> Option<Id> {
        self.record(Dep::Hovered(self.hovered));
        self.hovered
    }

    pub fn pressed(&self) -> Option<Id> {
        self.record(Dep::Pressed(self.pressed));
        self.pressed
    }

    /// True when focus arrived by keyboard, so a focus ring is expected.
    /// 当焦点由键盘带来时为真，此时应当显示焦点环。
    pub fn focus_visible(&self) -> bool {
        self.record(Dep::FocusVisible(self.focus_visible));
        self.focus_visible
    }

    pub fn focused(&self) -> Option<Id> {
        self.record(Dep::Focused(self.focused));
        self.focused
    }

    /// The caret's byte offset inside the text input `id`, when that input has focus.
    /// 当文本输入 `id` 持有焦点时，插入符在其中的字节偏移。
    pub fn caret_for(&self, id: Id) -> Option<usize> {
        self.record(Dep::Caret(self.caret));
        self.caret.filter(|(at, _)| *at == id).map(|(_, offset)| offset)
    }

    /// The caret's x inside the text node `id`, in that node's own layout space.
    /// 插入符在文本节点 `id` 内的 x，位于该节点自身的布局坐标系。
    ///
    /// Layout space, not visual: a control that scrolls text by this value must not read the
    /// offset it itself applied, or the scroll would chase its own tail.
    /// 用布局坐标而非视觉坐标：按这个值滚动文本的控件不得读到自己施加的偏移，
    /// 否则滚动会追着自己的尾巴跑。
    pub fn caret_in_text_for(&self, id: Id) -> Option<f32> {
        self.record(Dep::CaretInText(self.caret_in_text));
        self.caret_in_text
            .filter(|(at, _)| *at == id)
            .map(|(_, x)| x)
    }

    /// The selection inside the text node `id`, when that node holds one.
    /// 当文本节点 `id` 持有选区时，返回该选区。
    pub fn selection_for(&self, id: Id) -> Option<crate::selection::TextSelection> {
        self.record(Dep::Selection(self.selection));
        self.selection
            .filter(|(owner, _)| *owner == id)
            .map(|(_, selection)| selection)
    }

    /// The preedit string an input method is composing into `id`, if any.
    /// 输入法正在往 `id` 里组合的预编辑串（若有）。
    pub fn preedit_for(&self, id: Id) -> Option<crate::ime::Preedit> {
        self.record(Dep::Preedit(self.preedit.clone()));
        self.preedit
            .as_ref()
            .filter(|(owner, _)| *owner == id)
            .map(|(_, preedit)| preedit.clone())
    }

    /// The scroll geometry of the `SCROLL_OWNED` container `id`, both axes. `None` when
    /// `id` is not such a container this frame.
    /// `SCROLL_OWNED` 容器 `id` 的双轴滚动几何。当 `id` 本帧不是这种容器时返回 `None`。
    pub fn scroll_of(&self, id: Id) -> Option<ScrollGeom> {
        let got = self.scrolls.iter().find(|g| g.id == id).copied();
        self.record(Dep::Scroll {
            id,
            extent_w: got.map(|g| g.extent_w).unwrap_or(0.0),
            extent_h: got.map(|g| g.extent_h).unwrap_or(0.0),
            viewport_w: got.map(|g| g.viewport_w).unwrap_or(0.0),
            viewport_h: got.map(|g| g.viewport_h).unwrap_or(0.0),
            offset_x: got.map(|g| g.offset_x).unwrap_or(0.0),
            offset_y: got.map(|g| g.offset_y).unwrap_or(0.0),
            active: got.is_some_and(|g| g.active),
        });
        got
    }

    /// Ask an engine-owned scroller to hold this offset. The engine merges the request
    /// after the view returns; a wheel it handled itself still wins over a stale request.
    /// 要求引擎自有滚动容器持有该偏移。引擎在 view 返回后合并请求；
    /// 引擎自己处理的滚轮仍优先于过期的请求。
    pub fn set_scroll(&self, id: Id, x: f32, y: f32) {
        self.scroll_req.borrow_mut().push(ScrollRequest { id, x, y, animate: false });
    }

    /// Ask an engine-owned scroller to travel to this offset under its spring, so a
    /// programmatic move eases the way a hand would instead of jumping.
    /// 要求引擎自有滚动容器借弹簧走到该偏移：程序化的移动因此像手一样缓动，而不是跳过去。
    pub fn scroll_to(&self, id: Id, x: f32, y: f32) {
        self.scroll_req.borrow_mut().push(ScrollRequest { id, x, y, animate: true });
    }

    /// Take the offsets the app asked for; the engine calls this once the view returns.
    /// 取走应用要求的偏移；引擎在 view 返回后调用一次。
    pub fn take_scroll_requests(&self) -> Vec<ScrollRequest> {
        std::mem::take(&mut self.scroll_req.borrow_mut())
    }

    /// Ask the nearest engine-owned scroller to keep `id` visible once this frame is laid
    /// out; WinUI's `BringIntoViewOnFocusChange`, stated by the control that needs it.
    /// 要求最近的引擎自有滚动容器在本帧布局后保持 `id` 可见；即 WinUI 的
    /// `BringIntoViewOnFocusChange`，由需要它的控件声明。
    pub fn bring_into_view(&self, id: Id) {
        self.bring_req.borrow_mut().push(id);
    }

    /// Take the nodes the build asked to keep visible; the engine calls this after the view.
    /// 取走构建要求保持可见的节点；引擎在 view 返回后调用一次。
    pub fn take_bring_requests(&self) -> Vec<Id> {
        std::mem::take(&mut self.bring_req.borrow_mut())
    }

    /// Hand the build the frame's scroll geometry; the engine calls this before the view.
    /// 把本帧的滚动几何交给构建；引擎在 view 之前调用。
    pub fn set_scrolls(&mut self, scrolls: Vec<ScrollGeom>) {
        self.scrolls = scrolls;
    }

    pub fn hovered_path(&self) -> &[Id] {
        self.record(Dep::HoveredPath(self.hovered_path.clone()));
        &self.hovered_path
    }

    pub fn pressed_path(&self) -> &[Id] {
        self.record(Dep::PressedPath(self.pressed_path.clone()));
        &self.pressed_path
    }

    /// Whether the pointer is over `id` or anywhere inside it.
    /// 指针是否在 `id` 之上或其内部任意位置。
    ///
    /// `hovered` alone is the topmost node, so a container is never reported while the
    /// pointer is over its children; the ancestor path answers the container question.
    /// `hovered` 只是最上层节点，指针在子节点上时容器永远不会被报告；
    /// 「容器是否被悬停」由祖先路径回答。
    pub fn hovered_within(&self, id: Id) -> bool {
        let v = self.hovered_path.contains(&id);
        self.record(Dep::HoveredWithin(id, v));
        v
    }

    pub fn pressed_within(&self, id: Id) -> bool {
        let v = self.pressed_path.contains(&id);
        self.record(Dep::PressedWithin(id, v));
        v
    }

    /// Whether a drag that started inside `id` is in progress.
    /// 是否有从 `id` 内部开始的拖拽正在进行。
    pub fn dragging_within(&self, id: Id) -> bool {
        let v = self.drag_owner == Some(id);
        self.record(Dep::DraggingWithin(id, v));
        v
    }

    /// Whether the press on `id` has become a real drag, past `DRAG_THRESHOLD`.
    /// `id` 上的按下是否已成为真正的拖拽（越过 `DRAG_THRESHOLD`）。
    ///
    /// `dragging_within` is armed at the press so a control can hold its value for the whole
    /// gesture; this one starts only when the pointer actually travels, so a tap stays a tap.
    /// `dragging_within` 在按下时即成立，使控件能在整个手势中保持值；这一条只在指针真正
    /// 移动后成立，点击因此仍是点击。
    pub fn drag_started_within(&self, id: Id) -> bool {
        let v = self.drag_started_within_now(id);
        self.record(Dep::DragStarted(id, v));
        v
    }

    fn drag_started_within_now(&self, id: Id) -> bool {
        self.drag_started && self.drag_owner == Some(id)
    }

    /// Drive one animation instance toward `target` and read this frame's value.
    /// 把一个动画实例推向 `target`，并读出本帧的值。
    pub fn animate(&mut self, id: Id, target: f32, spec: AnimSpec) -> f32 {
        let v = self.anim.animate(id, target, spec, self.now);
        self.record(Dep::Anim {
            id,
            target,
            spec,
            value: v,
        });
        v
    }

    /// The current value without asking it to move.
    /// 只读当前值，不要求它移动。
    pub fn value(&self, id: Id) -> f32 {
        let v = self.anim.value(id, self.now).unwrap_or(0.0);
        self.record(Dep::Value { id, value: v });
        v
    }

    /// Seconds since this id first asked: a loop's own clock, zero on the first frame.
    /// 本 id 首次询问至今的秒数：循环自己的时钟，首帧为零。
    ///
    /// Reading it asks for every frame; a control that stops reading stops asking.
    /// 读取它即要求每一帧；不再读取的控件也就不再要求。
    pub fn age(&mut self, id: Id) -> f32 {
        let age = self.anim.age(id, self.now) as f32;
        self.record(Dep::Age { id, age });
        age
    }

    /// Borrow the same facts and store again, so a wrapper can hold it for one build.
    /// 重新借出同样的事实与存储，供包装层在一次构建中持有。
    pub fn reborrow(&mut self) -> Cx<'_> {
        Cx {
            frame: self.frame,
            width: self.width,
            height: self.height,
            now: self.now,
            dt: self.dt,
            scale: self.scale,
            pointer: self.pointer,
            modifiers: self.modifiers,
            hovered: self.hovered,
            pressed: self.pressed,
            clicked_path: self.clicked_path.clone(),
            activated_path: self.activated_path.clone(),
            dropped_path: self.dropped_path.clone(),
            drop_target: self.drop_target,
            focused: self.focused,
            focus_visible: self.focus_visible,
            dismissed: self.dismissed,
            shortcut: self.shortcut,
            caret: self.caret,
            caret_in_text: self.caret_in_text,
            selection: self.selection,
            preedit: self.preedit.clone(),
            scrolls: self.scrolls.clone(),
            scroll_req: Rc::clone(&self.scroll_req),
            bring_req: Rc::clone(&self.bring_req),
            hovered_path: self.hovered_path.clone(),
            pressed_path: self.pressed_path.clone(),
            disabled: self.disabled.clone(),
            drag_owner: self.drag_owner,
            drag_started: self.drag_started,
            drag_step: self.drag_step,
            local: self.local,
            anim: self.anim,
            rec: Rc::clone(&self.rec),
            tree: self.tree,
            cache: self.cache.as_deref_mut(),
            visiting: crate::collections::FastSet::default(),
            measure: self.measure.clone(),
        }
    }

    /// The store itself, for a wrapper that hands one node at a time to a control.
    /// 存储本身，供包装层逐节点交给控件。
    pub fn anim_mut(&mut self) -> &mut AnimStore {
        self.anim
    }

    /// One instance's state; read it *after* retargeting so it describes this frame.
    /// 单个实例的状态；要在重定向**之后**读取，它描述的才是本帧。
    pub fn status(&self, id: Id) -> Option<crate::anim::Status> {
        let status = self.anim.status(id, self.now);
        self.record(Dep::Status { id, status });
        status
    }

    /// The retained tree, when a caller needs geometry the declarations do not carry.
    /// 保留树，供需要声明中不存在的几何信息的调用方使用。
    ///
    /// Attached by the engine before the view runs; a build then reads last frame's layout,
    /// which is what a strip measuring its siblings for a drop needs.
    /// 由引擎在 view 之前挂上；构建因此读到上一帧的布局，
    /// 页签带要量兄弟节点以决定落点，靠的就是它。
    pub fn attach_tree(&mut self, tree: &'a Tree) {
        self.tree = Some(tree);
    }

    /// The rect `id` occupied in the last layout, if it exists and a tree is attached.
    /// `id` 在上一帧布局里占的矩形，节点存在且已挂上保留树时才有。
    ///
    /// Volatile: the engine cannot replay a layout, so no cached declaration survives it.
    /// 易变的：引擎无法重放一次布局，因此没有任何缓存声明能跨越它。
    pub fn rect_of(&self, id: Id) -> Option<crate::geom::Rect> {
        let tree = self.tree?;
        self.record(Dep::Volatile);
        let nid: NodeId = tree.find_by_id(id)?;
        tree.get(nid).map(|n| n.visual_rect())
    }

    /// The frame serial.
    /// 帧序号。
    pub fn frame(&self) -> u64 {
        self.record(Dep::Frame(self.frame));
        self.frame
    }

    /// The frame clock, recording a dependency: any reader rebuilds next frame.
    /// 帧时钟，并记录依赖：读取它的构建下一帧必须重建。
    pub fn now(&self) -> f64 {
        self.record(Dep::Now(self.now.to_bits()));
        self.now
    }

    /// The clock without recording, for snapshotting a narrower context.
    /// 不记录依赖的时钟，用于给更窄的上下文取快照。
    pub fn clock(&self) -> f64 {
        self.now
    }

    pub fn dt(&self) -> f32 {
        self.record(Dep::Dt(self.dt.to_bits()));
        self.dt
    }

    pub fn scale(&self) -> f32 {
        self.record(Dep::Scale(self.scale.to_bits()));
        self.scale
    }

    pub fn pointer(&self) -> Option<Point> {
        self.record(Dep::Pointer(self.pointer));
        self.pointer
    }

    /// Set the held modifiers for this build; the engine does it once per frame.
    /// 设置本次构建的按住修饰键；引擎每帧设置一次。
    pub fn set_modifiers(&mut self, modifiers: crate::event::Modifiers) {
        self.modifiers = modifiers;
    }

    /// Held modifiers, as of the last input event.
    /// 按住的修饰键，截至最近一次输入事件。
    pub fn modifiers(&self) -> crate::event::Modifiers {
        let m = self.modifiers;
        self.record(Dep::Modifiers(
            m.shift as u8 | (m.ctrl as u8) << 1 | (m.alt as u8) << 2 | (m.logo as u8) << 3,
        ));
        m
    }

    pub fn width(&self) -> u32 {
        self.record(Dep::Size(self.width, self.height));
        self.width
    }

    pub fn height(&self) -> u32 {
        self.record(Dep::Size(self.width, self.height));
        self.height
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::Easing;

    fn cx<'a>(anim: &'a mut AnimStore) -> Cx<'a> {
        Cx::new(anim, 3, 200, 100, 5.0, 0.016, 2.0, None)
    }

    #[test]
    fn a_container_sees_hover_through_its_children() {
        // The topmost node is a child, so only the ancestor path can answer for the parent.
        // 最上层是子节点，因此只有祖先路径能回答父容器的问题。
        let mut anim = AnimStore::new();
        let mut cx = cx(&mut anim);
        let parent = Id::str("row");
        let child = Id::str("label");
        cx.route(Routing {
            hovered: Some(child),
            hovered_path: vec![parent, child],
            ..Routing::default()
        });
        assert_eq!(cx.hovered(), Some(child), "the topmost node is the child");
        assert!(cx.hovered_within(parent), "the parent sees it through the path");
        assert!(!cx.hovered_within(Id::str("elsewhere")));
    }

    #[test]
    fn an_animation_written_here_is_readable_through_the_same_context() {
        // One store, one clock: a write and a read must agree inside the same frame.
        // 一份存储、一个时钟：同一帧内写入与读取必须一致。
        let mut anim = AnimStore::new();
        let mut cx = cx(&mut anim);
        let key = Id::str("k");
        cx.animate(key, 1.0, AnimSpec::new(0.1, Easing::Linear));
        assert_eq!(cx.value(key), 1.0, "first call settles at the target");
    }

    #[test]
    fn a_drag_belongs_to_the_node_that_owns_it() {
        let mut anim = AnimStore::new();
        let mut cx = cx(&mut anim);
        let panel = Id::str("panel");
        cx.route(Routing {
            drag_owner: Some(panel),
            ..Routing::default()
        });
        assert!(cx.dragging_within(panel));
        assert!(!cx.dragging_within(Id::str("other")));
    }
}
