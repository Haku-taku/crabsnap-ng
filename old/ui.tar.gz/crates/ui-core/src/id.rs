//! Stable widget identity.
//! 稳定的控件标识。

use core::fmt;
use core::hash::{Hash, Hasher};

/// A user-supplied, stable identifier.
/// 由用户提供、跨帧稳定的标识。
///
/// Users only ever hand the engine an `Id`; the engine owns `NodeId`.
/// 用户只交出 `Id`，`NodeId` 由引擎持有。
#[derive(Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Default)]
pub struct Id(u64);

impl Id {
    pub const fn from_u64(v: u64) -> Self {
        Self(v)
    }

    pub const fn as_u64(self) -> u64 {
        self.0
    }

    /// Derive a child id from a parent id and a salt.
    /// 由父 id 与 salt 派生一个子 id。
    ///
    /// Uses FNV-1a over the two halves, so it is stable across runs and platforms.
    /// 对两部分做 FNV-1a，跨运行与平台稳定。
    pub fn with(self, salt: impl Hash) -> Self {
        let mut h = Fnv1a::new();
        self.0.hash(&mut h);
        salt.hash(&mut h);
        Self(h.finish())
    }

    /// Derive an id from any hashable tuple.
    /// 由任意可哈希元组派生 id。
    pub fn of(v: impl Hash) -> Self {
        let mut h = Fnv1a::new();
        v.hash(&mut h);
        Self(h.finish())
    }

    /// Mnemonic id for `&str`, handy in examples.
    /// `&str` 的助记 id，便于示例使用。
    pub const fn str(s: &'static str) -> Self {
        // Compile-time FNV-1a over the bytes.
        // 编译期对字节做 FNV-1a。
        let bytes = s.as_bytes();
        let mut hash: u64 = 0xcbf2_9ce4_8422_2325;
        let mut i = 0;
        while i < bytes.len() {
            hash ^= bytes[i] as u64;
            hash = hash.wrapping_mul(0x1000_0000_01b3);
            i += 1;
        }
        Self(hash)
    }
}

impl fmt::Debug for Id {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "Id({:#018x})", self.0)
    }
}

/// Minimal FNV-1a hasher; no external dependency and no per-run seed.
/// 最小 FNV-1a 哈希器；无外部依赖、无每轮随机种子。
struct Fnv1a(u64);

impl Fnv1a {
    const fn new() -> Self {
        Self(0xcbf2_9ce4_8422_2325)
    }

    const fn finish(self) -> u64 {
        self.0
    }
}

impl Hasher for Fnv1a {
    fn write(&mut self, bytes: &[u8]) {
        for b in bytes {
            self.0 ^= *b as u64;
            self.0 = self.0.wrapping_mul(0x1000_0000_01b3);
        }
    }

    fn write_u64(&mut self, v: u64) {
        self.write(&v.to_le_bytes());
    }

    fn write_u32(&mut self, v: u32) {
        self.write(&v.to_le_bytes());
    }

    fn write_usize(&mut self, v: usize) {
        self.write(&(v as u64).to_le_bytes());
    }

    fn finish(&self) -> u64 {
        self.0
    }
}

/// Engine-internal node handle with a generation counter.
/// 引擎内部节点句柄，带代次计数。
///
/// A recycled slot bumps its generation, so a stale `NodeId` reads as absent
/// instead of silently pointing at a new node.
/// 回收的槽位会递增代次，过期 `NodeId` 读到的是"不存在"，而不是悄悄指向新节点。
#[derive(Clone, Copy, PartialEq, Eq, Hash, Debug)]
pub struct NodeId {
    pub(crate) index: u32,
    pub(crate) generation: u32,
}

impl NodeId {
    /// Construct a handle from raw parts. Test-only; production code gets ids from
    /// the tree.
    /// 由原始部分构造句柄。仅测试用；生产代码从树里取得 id。
    pub fn from_raw(index: u32, generation: u32) -> Self {
        Self { index, generation }
    }

    /// Slot index, for arena access.
    /// 槽位下标，用于访问 arena。
    pub const fn index(self) -> usize {
        self.index as usize
    }

    /// Generation counter, exposed for tests and diagnostics.
    /// 代次计数，供测试与诊断。
    pub const fn generation(self) -> u32 {
        self.generation
    }
}
