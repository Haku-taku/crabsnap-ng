//! What kinds of interaction a node is sensitive to.
//! 节点对哪类交互敏感。

/// A set of interaction kinds, as a bit set.
/// 交互类别集合，以位集表示。
///
/// Unlike egui's `Sense`, hover is an ordinary flag: some surfaces genuinely must not
/// react to the pointer, and treating it as an always-on floor would leave them no way
/// to say so.
/// 与 egui 的 `Sense` 不同，悬停是普通标志位：有些表面确实不该对指针有反应，
/// 若把它当成永远开启的底线，这些表面就无从表达这一点。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq, Hash)]
pub struct Sense(u16);

impl Sense {
    /// Nothing at all: the node is inert for routing purposes.
    /// 什么都不接受：该节点对路由而言是惰性的。
    pub const NONE: Sense = Sense(0);
    /// The pointer is over this node.
    /// 指针位于该节点之上。
    pub const HOVER: Sense = Sense(1 << 0);
    /// A press that never became a drag is delivered as an activation.
    /// 未成为拖拽的按下会作为一次激活送达。
    pub const CLICK: Sense = Sense(1 << 1);
    /// The node may be the origin of a drag gesture.
    /// 该节点可作为拖拽手势的来源。
    pub const DRAG: Sense = Sense(1 << 2);
    /// The node may accept a dropped item.
    /// 该节点可接受被放置的项目。
    pub const DROP: Sense = Sense(1 << 3);
    /// The node can hold keyboard focus.
    /// 该节点可持有键盘焦点。
    pub const FOCUSABLE: Sense = Sense(1 << 4);
    /// The node is a scroll container: wheel events route to it, not past it.
    /// 该节点是可滚动容器：滚轮事件送到它这里，而不穿透。
    pub const SCROLL: Sense = Sense(1 << 5);
    /// Hit testing passes through this node to whatever is beneath it.
    /// 命中测试穿过该节点，落到它下面的东西上。
    pub const PASS_THROUGH: Sense = Sense(1 << 6);
    /// A text node whose characters can be selected with the pointer.
    /// 文本节点的字符可以用指针选中。
    ///
    /// Opt-in: a label that defaulted to this would swallow the press of the control it
    /// sits in, and a text field's own text would start a read-only selection instead of
    /// taking focus.
    /// 显式开启：默认如此会让标签吞掉所在控件的按下，
    /// 输入框自己的文字也会变成只读选择而不是取得焦点。
    pub const SELECT: Sense = Sense(1 << 7);

    /// Takes raw chords while focused instead of letting the shortcut table read them.
    /// 聚焦时接收原始组合键，而不是让快捷键表去读它们。
    ///
    /// For a shortcut editor: it must see the very chord it is about to bind.
    /// 供快捷键编辑器使用：它必须看到自己即将绑定的那个组合。
    pub const CAPTURE_KEYS: Sense = Sense(1 << 8);

    /// A scroll container whose offset the engine owns: a wheel routes here and the engine
    /// accumulates it into the node's `scroll_y`, clamped, instead of reporting `Value` up.
    /// 由引擎管理偏移的滚动容器：滚轮送到这里，引擎把增量累进该节点的 `scroll_y`
    /// 并钳位，而不是把 `Value` 上报给应用。
    pub const SCROLL_OWNED: Sense = Sense(1 << 9);

    /// A bit-wise union, so subscriptions compose with `|`.
    /// 按位并集，使订阅可以用 `|` 组合。
    pub const fn union(self, other: Sense) -> Sense {
        Sense(self.0 | other.0)
    }

    /// Whether every flag in `other` is present.
    /// `other` 中的每个标志是否都存在。
    pub const fn contains(self, other: Sense) -> bool {
        self.0 & other.0 == other.0
    }

    /// Whether any flag in `other` is present; the cheap "is this subtree interesting".
    /// `other` 中是否有任一标志存在；「这棵子树值得处理吗」的廉价判据。
    pub const fn any(self, other: Sense) -> bool {
        self.0 & other.0 != 0
    }

    /// The raw bits, for storage in a node.
    /// 原始位，供存入节点。
    pub const fn bits(self) -> u16 {
        self.0
    }

    /// Rebuild from raw bits.
    /// 由原始位重建。
    pub const fn from_bits(bits: u16) -> Sense {
        Sense(bits)
    }

    pub const fn is_empty(self) -> bool {
        self.0 == 0
    }
}

impl std::ops::BitOr for Sense {
    type Output = Sense;
    fn bitor(self, rhs: Sense) -> Sense {
        Sense(self.0 | rhs.0)
    }
}

impl std::ops::BitOrAssign for Sense {
    fn bitor_assign(&mut self, rhs: Sense) {
        self.0 |= rhs.0;
    }
}

impl std::ops::BitAnd for Sense {
    type Output = Sense;
    fn bitand(self, rhs: Sense) -> Sense {
        Sense(self.0 & rhs.0)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn a_subscription_composes_with_or_and_reports_membership() {
        // The point of a bit set: a control states its needs in one expression.
        // 位集的用处：控件用一条表达式说清自己的需求。
        let slider = Sense::HOVER | Sense::DRAG | Sense::FOCUSABLE;
        assert!(slider.contains(Sense::DRAG));
        assert!(!slider.contains(Sense::CLICK), "never asked for clicks");
        assert!(
            slider.contains(Sense::HOVER | Sense::DRAG),
            "a compound check needs every bit"
        );
        assert!(slider.any(Sense::CLICK | Sense::DRAG), "any-ness is separate");
        // A half-satisfied compound must fail `contains` but pass `any`; without this the
        // two could be the same function and no test would notice.
        // 半满足的复合订阅必须 `contains` 失败而 `any` 成功；
        // 否则两者可以是同一个函数而无人察觉。
        assert!(!slider.contains(Sense::DRAG | Sense::DROP), "drag alone is not drag+drop");
        assert!(slider.any(Sense::DRAG | Sense::DROP), "but drag alone is enough for any");
    }

    #[test]
    fn an_inert_node_says_so_instead_of_accepting_everything() {
        // Hover is an ordinary flag here, so "nothing" is expressible.
        // 这里悬停是普通标志位，因此「什么都不接受」是可以表达的。
        assert!(Sense::NONE.is_empty());
        assert!(!Sense::NONE.contains(Sense::HOVER));
        assert!(Sense::HOVER.contains(Sense::HOVER));
        assert_ne!(Sense::NONE, Sense::HOVER);
    }

    #[test]
    fn the_bits_survive_a_trip_through_a_node() {
        // Nodes store a `u16`; nothing may be lost or reordered on the way there.
        // 节点存的是 `u16`；往返过程中不得丢失或错位。
        let s = Sense::DROP | Sense::SCROLL | Sense::PASS_THROUGH;
        assert_eq!(Sense::from_bits(s.bits()), s);
    }
}
