//! Hit testing: which node receives a pointer event.
//! 命中测试：哪个节点接收指针事件。

use crate::geom::{Point, Rect};
use crate::id::NodeId;
use crate::tree::Tree;

/// How a node participates in hit testing.
/// 节点如何参与命中测试。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum HitBehavior {
    /// Not interactive.
    /// 不可交互。
    #[default]
    Ignore,
    /// Receives events; consumes them.
    /// 接收事件并消费。
    Opaque,
    /// Receives events but lets the search continue underneath.
    /// 接收事件但允许继续向下查找。
    PassThrough,
}

/// One registered hit area.
/// 一个登记的命中区域。
#[derive(Clone, Copy, Debug)]
pub struct HitTarget {
    pub node: NodeId,
    pub bounds: Rect,
    /// Clip in force when the node was registered.
    /// 登记时生效的裁剪。
    pub mask: Rect,
    pub behavior: HitBehavior,
    /// Higher wins; `HitIndex::build` numbers targets in paint order, layers included.
    /// 值大者优先；`HitIndex::build` 按绘制顺序编号，层已经计入其中。
    pub z: u32,
}

/// Spatial index over hit targets.
/// 命中目标的空间索引。
#[derive(Debug, Default)]
pub struct HitIndex {
    entries: Vec<HitTarget>,
    /// 64pt cells over a rectangle of the plane; each lists the entries touching it.
    /// 平面上一个矩形范围内的 64pt 格子；每格列出触及它的条目。
    cells: Vec<Vec<u32>>,
    /// Cell at the grid's top-left corner.
    /// 网格左上角的格子。
    cell_min: (i32, i32),
    /// Grid size in cells; zero until the first insert.
    /// 网格的列数与行数；首次插入前为零。
    cols: i32,
    rows: i32,
    /// Targets too large to bucket; every query reads them, so no cell can miss one.
    /// 大到无法分桶的目标；每次查询都读它们，因此没有哪个格子会漏掉。
    wide: Vec<u32>,
}

const CELL: f32 = 64.0;

fn cell_of(p: Point) -> (i32, i32) {
    (
        (p.x / CELL).floor() as i32,
        (p.y / CELL).floor() as i32,
    )
}

impl HitIndex {
    pub fn new() -> Self {
        Self::default()
    }

    /// Empty the index, keeping the grid and its buckets allocated for the next frame.
    /// 清空索引，保留网格与其中各桶的分配，供下一帧复用。
    pub fn clear(&mut self) {
        self.entries.clear();
        self.wide.clear();
        for cell in &mut self.cells {
            cell.clear();
        }
    }

    pub fn len(&self) -> usize {
        self.entries.len()
    }

    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }

    pub fn insert(&mut self, target: HitTarget) {
        let index = self.entries.len() as u32;
        self.entries.push(target);
        // Register in every bucket the bounds touch, capped so a huge node does not
        // flood the grid.
        // 注册到覆盖到的每个桶；对超大节点设上限，避免淹没网格。
        let (c0, c1) = (
            cell_of(target.bounds.origin),
            cell_of(Point::new(target.bounds.max_x(), target.bounds.max_y())),
        );
        let cells = (c1.0 - c0.0 + 1).max(1) as i64 * (c1.1 - c0.1 + 1).max(1) as i64;
        if cells > 4096 {
            // A node this large would flood the grid; every query reads the wide list instead.
            // 这么大的节点会淹没网格；改为每次查询都读这份宽目标表。
            self.wide.push(index);
            return;
        }
        self.cover(c0, c1);
        for cy in c0.1..=c1.1 {
            for cx in c0.0..=c1.0 {
                if let Some(i) = self.cell_index((cx, cy)) {
                    self.cells[i].push(index);
                }
            }
        }
    }

    /// Index of `cell` in `cells`, or `None` when the grid does not reach it.
    /// `cell` 在 `cells` 中的下标；网格未覆盖它时返回 `None`。
    fn cell_index(&self, (cx, cy): (i32, i32)) -> Option<usize> {
        let (x, y) = (cx - self.cell_min.0, cy - self.cell_min.1);
        if x < 0 || y < 0 || x >= self.cols || y >= self.rows {
            return None;
        }
        Some((y * self.cols + x) as usize)
    }

    /// Grow the grid, if needed, so that it spans `c0..=c1`; existing buckets move with it.
    /// 必要时扩展网格以覆盖 `c0..=c1`；已有桶随同搬迁。
    fn cover(&mut self, c0: (i32, i32), c1: (i32, i32)) {
        let (old_min, old_cols, old_rows) = (self.cell_min, self.cols, self.rows);
        let have = old_cols > 0;
        let min = if have {
            (old_min.0.min(c0.0), old_min.1.min(c0.1))
        } else {
            c0
        };
        let max = if have {
            (
                (old_min.0 + old_cols - 1).max(c1.0),
                (old_min.1 + old_rows - 1).max(c1.1),
            )
        } else {
            c1
        };
        let (cols, rows) = (max.0 - min.0 + 1, max.1 - min.1 + 1);
        if have && min == old_min && (cols, rows) == (old_cols, old_rows) {
            return;
        }
        let mut cells = vec![Vec::new(); (cols * rows) as usize];
        for y in 0..old_rows {
            for x in 0..old_cols {
                let from = (y * old_cols + x) as usize;
                if self.cells[from].is_empty() {
                    continue;
                }
                let to_x = old_min.0 + x - min.0;
                let to_y = old_min.1 + y - min.1;
                cells[(to_y * cols + to_x) as usize] = std::mem::take(&mut self.cells[from]);
            }
        }
        self.cells = cells;
        self.cell_min = min;
        self.cols = cols;
        self.rows = rows;
    }

    /// Every target that can cover `p`: the point's own bucket plus the wide ones.
    /// 可能覆盖 `p` 的全部目标：该点所在的格子，加上那些大到无法分桶的。
    fn covering(&self, p: Point) -> impl Iterator<Item = &HitTarget> {
        self.cell_index(cell_of(p))
            .and_then(|i| self.cells.get(i))
            .into_iter()
            .flatten()
            .chain(self.wide.iter())
            .filter_map(|i| self.entries.get(*i as usize))
            .filter(move |t| t.bounds.contains(p) && t.mask.contains(p))
    }

    /// The highest of the covering targets for which `keep` holds; ties keep the first.
    /// 覆盖 `p` 且满足 `keep` 的最高目标；同高时保留先插入的那个。
    fn highest(&self, p: Point, keep: impl Fn(&HitTarget) -> bool) -> Option<NodeId> {
        let mut best: Option<&HitTarget> = None;
        for t in self.covering(p).filter(|t| keep(t)) {
            if best.map(|b| t.z > b.z).unwrap_or(true) {
                best = Some(t);
            }
        }
        best.map(|t| t.node)
    }

    /// Topmost target at `p`, honouring mask and `PassThrough`.
    /// `p` 处最上层的目标，考虑裁剪与 `PassThrough`。
    pub fn topmost(&self, p: Point) -> Option<NodeId> {
        self.highest(p, |_| true)
    }

    /// Highest target at `p` that consumes the event, so a pass-through node is skipped.
    /// `p` 处消费事件的最高目标，因此透传节点会被跳过。
    ///
    /// `topmost` answers "what is drawn here"; this answers "what takes the input".
    /// `topmost` 回答「这里画了什么」；本函数回答「谁接收输入」。
    pub fn topmost_consumer(&self, p: Point) -> Option<NodeId> {
        self.highest(p, |t| t.behavior == HitBehavior::Opaque)
    }

    /// All targets at `p` from top to bottom, stopping at the first opaque one.
    /// `p` 处自顶向下的全部目标，遇到第一个不透明者停止。
    pub fn stack_at(&self, p: Point) -> Vec<NodeId> {
        let mut hits: Vec<&HitTarget> = self.covering(p).collect();
        hits.sort_by_key(|t| std::cmp::Reverse(t.z));
        let mut out = Vec::new();
        for t in hits {
            out.push(t.node);
            if t.behavior == HitBehavior::Opaque {
                break;
            }
        }
        out
    }

    /// Build an index from the tree, using painted rects intersected with masks.
    /// 由树构建索引：取绘制矩形与裁剪的交集。
    pub fn build(tree: &Tree, behaviors: impl Fn(NodeId) -> HitBehavior) -> Self {
        let mut idx = Self::new();
        idx.rebuild(tree, behaviors);
        idx
    }

    /// Refill this index from the tree, reusing its buckets: a frame rebuilds the index
    /// with the same geometry, so only the contents need replacing.
    /// 用树重新填满该索引并复用其桶：一帧重建索引时几何不变，只需替换内容。
    pub fn rebuild(&mut self, tree: &Tree, behaviors: impl Fn(NodeId) -> HitBehavior) {
        self.clear();
        // A scaled subtree paints somewhere else, so its targets must move with it.
        // 被缩放的子树画在别处，命中目标因此必须跟着移动。
        let scaling = tree.presence_scaling();
        for (order, nid) in tree.walk().into_iter().enumerate() {
            let Some(node) = tree.get(nid) else {
                continue;
            };
            let behavior = behaviors(nid);
            if behavior == HitBehavior::Ignore {
                continue;
            }
            // Hit testing follows the pixels: an offset or scaled node is clickable where it
            // is drawn; the mask stays the viewport it was laid out against.
            // 命中跟随像素：带偏移或被缩放的节点在画出的位置可点；遮罩仍是布局时的视口。
            let visual = if scaling {
                tree.scaled_visual_rect(nid)
            } else {
                node.visual_rect()
            };
            let bounds = visual.intersection(node.mask).unwrap_or(Rect::ZERO);
            if bounds.is_empty() {
                continue;
            }
            self.insert(HitTarget {
                node: nid,
                bounds,
                mask: node.mask,
                behavior,
                z: order as u32,
            });
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::geom::{Insets, Size};
    use crate::id::Id;
    use crate::layout::{Constraints, LayoutEngine, SizeClass};
    use crate::layout_engine::{BuiltinLayout, MonospaceMeasure};
    use crate::tree::{Decl, NodeData, NodeKind};

    fn target(x: f32, y: f32, w: f32, h: f32, z: u32, behavior: HitBehavior) -> HitTarget {
        HitTarget {
            node: NodeId::from_raw(z, 0),
            bounds: Rect::new(x, y, w, h),
            mask: Rect::new(-1000.0, -1000.0, 5000.0, 5000.0),
            behavior,
            z: 1000 + z,
        }
    }

    /// A pass-through target stays in the index but never consumes the event.
    /// 透传目标仍在索引里，但永不消费事件。
    #[test]
    fn topmost_consumer_skips_a_pass_through_target() {
        let mut idx = HitIndex::new();
        idx.insert(target(0.0, 0.0, 100.0, 100.0, 0, HitBehavior::Opaque));
        idx.insert(target(0.0, 0.0, 100.0, 100.0, 5, HitBehavior::PassThrough));
        let p = Point::new(15.0, 15.0);
        assert_eq!(idx.topmost(p), Some(NodeId::from_raw(5, 0)), "drawing order unchanged");
        assert_eq!(
            idx.topmost_consumer(p),
            Some(NodeId::from_raw(0, 0)),
            "the opaque target behind must take the input"
        );
    }

    /// A target too large to bucket is still hit far from its origin.
    /// 大到无法分桶的目标，在远离其原点处仍然可命中。
    #[test]
    fn a_target_larger_than_the_bucket_cap_is_hit_across_its_whole_extent() {
        let mut idx = HitIndex::new();
        let mut huge = target(0.0, 0.0, 20_000.0, 20_000.0, 0, HitBehavior::Opaque);
        huge.mask = Rect::new(0.0, 0.0, 20_000.0, 20_000.0);
        idx.insert(huge);
        let far = Point::new(19_000.0, 19_000.0);
        assert_eq!(idx.topmost(far), Some(NodeId::from_raw(0, 0)));
        assert_eq!(idx.topmost_consumer(far), Some(NodeId::from_raw(0, 0)));
        assert_eq!(idx.stack_at(far), vec![NodeId::from_raw(0, 0)]);
    }

    #[test]
    fn topmost_returns_highest_z() {
        let mut idx = HitIndex::new();
        idx.insert(target(0.0, 0.0, 100.0, 100.0, 0, HitBehavior::Opaque));
        idx.insert(target(10.0, 10.0, 20.0, 20.0, 1, HitBehavior::Opaque));
        let hit = idx.topmost(Point::new(15.0, 15.0)).unwrap();
        assert_eq!(hit.index, 1);
        let outside = idx.topmost(Point::new(90.0, 90.0)).unwrap();
        assert_eq!(outside.index, 0);
    }

    #[test]
    fn mask_excludes_points_outside_the_clip() {
        let mut idx = HitIndex::new();
        let mut t = target(0.0, 0.0, 100.0, 100.0, 0, HitBehavior::Opaque);
        t.mask = Rect::new(0.0, 0.0, 50.0, 50.0);
        idx.insert(t);
        assert!(idx.topmost(Point::new(25.0, 25.0)).is_some());
        assert!(
            idx.topmost(Point::new(75.0, 75.0)).is_none(),
            "point inside bounds but outside mask must not hit"
        );
    }

    #[test]
    fn pass_through_lets_the_search_reach_lower_nodes() {
        let mut idx = HitIndex::new();
        idx.insert(target(0.0, 0.0, 100.0, 100.0, 0, HitBehavior::Opaque));
        idx.insert(target(0.0, 0.0, 100.0, 100.0, 1, HitBehavior::PassThrough));

        let stack = idx.stack_at(Point::new(50.0, 50.0));
        assert_eq!(stack.len(), 2, "pass-through must not stop the search");
        assert_eq!(stack[0].index, 1);

        let p = Point::new(50.0, 50.0);
        let opaque_stack = {
            let mut i = HitIndex::new();
            i.insert(target(0.0, 0.0, 100.0, 100.0, 0, HitBehavior::Opaque));
            i.insert(target(0.0, 0.0, 100.0, 100.0, 1, HitBehavior::Opaque));
            i.stack_at(p)
        };
        assert_eq!(opaque_stack.len(), 1, "opaque must stop the search");
    }

    /// Growing the cell grid keeps the buckets already filed in it.
    /// 扩展格子网格时，已经归档的桶必须跟着搬过去。
    #[test]
    fn growing_the_grid_keeps_the_targets_already_filed() {
        let mut idx = HitIndex::new();
        idx.insert(target(0.0, 0.0, 10.0, 10.0, 0, HitBehavior::Opaque));
        // Far enough to need a new grid on both axes, forcing the migration.
        // 足够远，两个方向都要换更大的网格，从而走到搬迁那一步。
        idx.insert(target(3980.0, 3980.0, 10.0, 10.0, 1, HitBehavior::Opaque));
        assert_eq!(
            idx.topmost(Point::new(5.0, 5.0)),
            Some(NodeId::from_raw(0, 0)),
            "the target filed before the grid grew must survive it"
        );
        assert_eq!(idx.topmost(Point::new(3985.0, 3985.0)), Some(NodeId::from_raw(1, 0)));
    }

    #[test]
    fn empty_space_hits_nothing() {
        let mut idx = HitIndex::new();
        idx.insert(target(0.0, 0.0, 10.0, 10.0, 0, HitBehavior::Opaque));
        assert!(idx.topmost(Point::new(500.0, 500.0)).is_none());
    }

    #[test]
    fn tree_build_skips_non_interactive_nodes() {
        let mut tree = Tree::new();
        let decl = Decl {
            id: Id::str("root"),
            kind: NodeKind::Box,
            shapes: Vec::new(),
            data: NodeData::Container(crate::tree::ContainerParams::default()),
            size_class: SizeClass::fixed(100.0, 100.0),
            ink_margin: Insets::ZERO,
            box_model: Default::default(),
            offset: crate::geom::Point::new(0.0, 0.0),
            cursor: None,
            sense: crate::Sense::NONE,
            disabled: false,
            grid: crate::tree::GridItem::default(),
            placement: crate::layout::Placement::default(),
            env: None,
            children: vec![std::rc::Rc::new(Decl {
                id: Id::str("child"),
                kind: NodeKind::Box,
                shapes: Vec::new(),
                data: NodeData::Container(crate::tree::ContainerParams::default()),
                size_class: SizeClass::fixed(20.0, 20.0),
                ink_margin: Insets::ZERO,
                box_model: Default::default(),
                offset: crate::geom::Point::new(0.0, 0.0),
                cursor: None,
            sense: crate::Sense::NONE,
            disabled: false,
            grid: crate::tree::GridItem::default(),
            placement: crate::layout::Placement::default(),
            env: None,
                children: Vec::new(),
            })],
        };
        tree.apply(&decl);
        let mut engine = BuiltinLayout::new(MonospaceMeasure::default());
        let root = tree.root().unwrap();
        engine.solve(&mut tree, root, Constraints::loose(Size::new(800.0, 600.0)));

        let idx = HitIndex::build(&tree, |_| HitBehavior::Ignore);
        assert!(idx.is_empty(), "ignore-everything must register no targets");
    }
}
