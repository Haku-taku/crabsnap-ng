//! Colour management: transfer functions, colour spaces, output description.
//! 色彩管理：传输函数、色彩空间、输出描述。
//!
//! Storage and working domain are separate concerns. SDR stays in 8-bit sRGB and
//! linearises through a LUT; only HDR needs a wide domain.
//! 存储域与运算域是两件事。SDR 就用 8-bit sRGB，线性化走 LUT；只有 HDR 需要宽域。

/// How encoded values map to linear light.
/// 编码值如何映射到线性光。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub enum TransferFunction {
    /// sRGB piecewise curve, the default for SDR.
    /// sRGB 分段曲线，SDR 的默认选择。
    Srgb,
    /// No curve; the buffer already holds linear light.
    /// 无曲线；缓冲区本身就是线性光。
    Linear,
    /// SMPTE ST 2084, absolute: 1.0 means 10000 nits.
    /// SMPTE ST 2084，绝对亮度：1.0 表示 10000 nit。
    Pq,
    /// BT.2100 HLG, scene-referred.
    /// BT.2100 HLG，场景参考。
    Hlg,
}

impl TransferFunction {
    /// Encoded value in `[0, 1]` to linear light in `[0, 1]`.
    /// 把 `[0, 1]` 的编码值转成 `[0, 1]` 的线性光。
    pub fn decode(self, encoded: f32) -> f32 {
        let e = encoded.clamp(0.0, 1.0);
        match self {
            Self::Srgb => {
                if e <= 0.040_449_237 {
                    e / 12.92
                } else {
                    ((e + 0.055) / 1.055).powf(2.4)
                }
            }
            Self::Linear => e,
            Self::Pq => {
                const M1: f32 = 2610.0 / 16384.0;
                const M2: f32 = 2523.0 / 32.0;
                const C1: f32 = 3424.0 / 4096.0;
                const C2: f32 = 2413.0 / 128.0;
                const C3: f32 = 2392.0 / 128.0;
                let p = e.powf(1.0 / M2);
                let num = (p - C1).max(0.0);
                let den = C2 - C3 * p;
                if den <= 0.0 {
                    return 1.0;
                }
                (num / den).powf(1.0 / M1)
            }
            Self::Hlg => {
                let a: f32 = 0.178_832_77;
                let b = 1.0 - 4.0 * a;
                let c = 0.5 - a * (4.0 * a).ln();
                if e <= 0.5 {
                    e * e / 3.0
                } else {
                    (((e - c) / a).exp() + b) / 12.0
                }
            }
        }
    }

    /// Linear light in `[0, 1]` to an encoded value in `[0, 1]`.
    /// 把 `[0, 1]` 的线性光转成 `[0, 1]` 的编码值。
    pub fn encode(self, linear: f32) -> f32 {
        let l = linear.clamp(0.0, 1.0);
        match self {
            Self::Srgb => {
                if l <= 0.003_130_8 {
                    l * 12.92
                } else {
                    1.055 * l.powf(1.0 / 2.4) - 0.055
                }
            }
            Self::Linear => l,
            Self::Pq => {
                const M1: f32 = 2610.0 / 16384.0;
                const M2: f32 = 2523.0 / 32.0;
                const C1: f32 = 3424.0 / 4096.0;
                const C2: f32 = 2413.0 / 128.0;
                const C3: f32 = 2392.0 / 128.0;
                let p = l.powf(M1);
                ((C1 + C2 * p) / (1.0 + C3 * p)).powf(M2)
            }
            Self::Hlg => {
                let a: f32 = 0.178_832_77;
                let b = 1.0 - 4.0 * a;
                let c = 0.5 - a * (4.0 * a).ln();
                if l <= 1.0 / 12.0 {
                    (3.0 * l).sqrt()
                } else {
                    a * (12.0 * l - b).ln() + c
                }
            }
        }
    }

    /// Whether this function can express more than SDR's ~100 nits.
    /// 该函数能否表达超出 SDR 约 100 nit 的亮度。
    pub fn is_hdr(self) -> bool {
        matches!(self, Self::Pq | Self::Hlg)
    }
}

/// What a buffer's bytes mean, as opposed to how they are laid out.
/// 缓冲区的字节是什么意思，区别于它们如何排布。
///
/// Premultiplication is not inferable from bytes, so it lives in the type.
/// 是否预乘无法从字节推断，因此放进类型里。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct Encoding {
    pub transfer: TransferFunction,
    pub premultiplied: bool,
}

impl Default for Encoding {
    /// SDR premultiplied: the only thing this crate produced before HDR existed.
    /// SDR 预乘：HDR 出现之前本 crate 唯一的产出形态。
    fn default() -> Self {
        Self::SDR_PREMULTIPLIED
    }
}

impl Encoding {
    /// What every SDR path in this crate produces today.
    /// 本 crate 目前所有 SDR 路径产出的东西。
    pub const SDR_PREMULTIPLIED: Self = Self {
        transfer: TransferFunction::Srgb,
        premultiplied: true,
    };

    /// The working domain an HDR pipeline blends in.
    /// HDR 管线进行混合的工作域。
    pub const LINEAR_PREMULTIPLIED: Self = Self {
        transfer: TransferFunction::Linear,
        premultiplied: true,
    };

    /// Whether blending in this encoding is physically meaningful.
    /// 在该编码下做混合是否有物理意义。
    pub fn is_linear(&self) -> bool {
        matches!(self.transfer, TransferFunction::Linear)
    }
}

/// Map linear light to the code a PQ output expects.
/// 把线性光映射到 PQ 输出期望的编码。
///
/// `reference_nits` is the display's SDR white and `min_nits` its black level; both come
/// from the compositor, never from a constant. The shader transcribes this function.
/// `reference_nits` 是屏幕的 SDR 白，`min_nits` 是黑电平；两者都来自 compositor，不是常量。
/// 着色器是此函数的转录。
/// Scale that puts the display's SDR white at the right place in PQ's range.
/// 把屏幕的 SDR 白放到 PQ 量程正确位置的缩放系数。
pub fn reference_scale(reference_nits: f32) -> f32 {
    reference_nits / 10_000.0
}

/// Offset contributed by the display's black level.
/// 屏幕黑电平贡献的偏移。
pub fn min_offset(min_nits: f32) -> f32 {
    min_nits / 10_000.0
}

pub fn encode_for_pq_output(linear: f32, reference_nits: f32, min_nits: f32) -> f32 {
    let scale = reference_scale(reference_nits);
    let offset = min_offset(min_nits);
    TransferFunction::Pq.encode((scale * linear + offset).clamp(0.0, 1.0))
}

/// Chromaticity coordinates of a set of primaries, as the protocol reports them.
/// 一组基色的色度坐标，按协议报告的形式。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Chromaticities {
    pub red: (f32, f32),
    pub green: (f32, f32),
    pub blue: (f32, f32),
    pub white: (f32, f32),
}

impl Chromaticities {
    /// BT.709 / sRGB, the space our own content is authored in.
    /// BT.709 / sRGB，我们自己的内容所在的色域。
    pub const SRGB: Self = Self {
        red: (0.64, 0.33),
        green: (0.30, 0.60),
        blue: (0.15, 0.06),
        white: (0.3127, 0.3290),
    };
    /// BT.2020, what an HDR output usually describes.
    /// BT.2020，HDR 输出通常声明的色域。
    pub const BT2020: Self = Self {
        red: (0.708, 0.292),
        green: (0.170, 0.797),
        blue: (0.131, 0.046),
        white: (0.3127, 0.3290),
    };
    /// Display P3.
    pub const DISPLAY_P3: Self = Self {
        red: (0.680, 0.320),
        green: (0.265, 0.690),
        blue: (0.150, 0.060),
        white: (0.3127, 0.3290),
    };

    fn xyz_of(self) -> [[f32; 3]; 3] {
        let col = |(x, y): (f32, f32)| [x / y, 1.0, (1.0 - x - y) / y];
        let r = col(self.red);
        let g = col(self.green);
        let b = col(self.blue);
        [[r[0], g[0], b[0]], [r[1], g[1], b[1]], [r[2], g[2], b[2]]]
    }

    /// Matrix taking linear RGB in this space to CIE XYZ.
    /// 把本空间线性 RGB 转到 CIE XYZ 的矩阵。
    fn to_xyz(self) -> [[f32; 3]; 3] {
        let m = self.xyz_of();
        let (x, y) = self.white;
        let w = [x / y, 1.0, (1.0 - x - y) / y];
        let inv = invert(m).expect("primaries matrix is invertible");
        let s = mul_vec(inv, w);
        [[m[0][0] * s[0], m[0][1] * s[1], m[0][2] * s[2]],
         [m[1][0] * s[0], m[1][1] * s[1], m[1][2] * s[2]],
         [m[2][0] * s[0], m[2][1] * s[1], m[2][2] * s[2]]]
    }
}

/// How the white points are reconciled when converting between gamuts.
/// 色域转换时如何协调两端的白点。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum WhiteAdaptation {
    /// Convert primaries only; a differing white point leaves a neutral cast.
    /// 只转换原色；白点不同会留下中性色偏。
    None,
    /// Bradford cone response; neutrals stay neutral across white points.
    /// Bradford 锥体响应；跨白点时中性色保持中性。
    Bradford,
}

/// Matrix converting linear RGB from `from` into `to`, both row-major.
/// 把线性 RGB 从 `from` 转到 `to` 的矩阵，行主序。
pub fn gamut_matrix(from: Chromaticities, to: Chromaticities) -> [[f32; 3]; 3] {
    gamut_matrix_adapted(from, to, WhiteAdaptation::None)
}

/// The same, with an explicit white point strategy.
/// 同上，但显式指定白点策略。
pub fn gamut_matrix_adapted(
    from: Chromaticities,
    to: Chromaticities,
    adaptation: WhiteAdaptation,
) -> [[f32; 3]; 3] {
    let inv = invert(to.to_xyz()).expect("primaries matrix is invertible");
    let src = from.to_xyz();
    match adaptation {
        WhiteAdaptation::None => mul(inv, src),
        WhiteAdaptation::Bradford => {
            // Adapt the source white to the destination white in cone space.
            // 在锥体空间把源白点适配到目标白点。
            let b = [
                [0.8951, 0.2664, -0.1614],
                [-0.7502, 1.7135, 0.0367],
                [0.0389, -0.0685, 1.0296],
            ];
            let binv = invert(b).expect("bradford matrix is invertible");
            let ws = mul_vec(b, white_xyz(from.white));
            let wd = mul_vec(b, white_xyz(to.white));
            let mut d = [[0.0f32; 3]; 3];
            for i in 0..3 {
                d[i][i] = wd[i] / ws[i];
            }
            let adapt = mul(binv, mul(d, b));
            mul(inv, mul(adapt, src))
        }
    }
}

fn white_xyz((x, y): (f32, f32)) -> [f32; 3] {
    [x / y, 1.0, (1.0 - x - y) / y]
}

fn mul_vec(m: [[f32; 3]; 3], v: [f32; 3]) -> [f32; 3] {
    let mut out = [0.0f32; 3];
    for (i, row) in m.iter().enumerate() {
        out[i] = row[0] * v[0] + row[1] * v[1] + row[2] * v[2];
    }
    out
}

fn mul(a: [[f32; 3]; 3], b: [[f32; 3]; 3]) -> [[f32; 3]; 3] {
    let mut out = [[0.0f32; 3]; 3];
    for i in 0..3 {
        for j in 0..3 {
            out[i][j] = (0..3).map(|k| a[i][k] * b[k][j]).sum();
        }
    }
    out
}

fn invert(m: [[f32; 3]; 3]) -> Option<[[f32; 3]; 3]> {
    let det = m[0][0] * (m[1][1] * m[2][2] - m[1][2] * m[2][1])
        - m[0][1] * (m[1][0] * m[2][2] - m[1][2] * m[2][0])
        + m[0][2] * (m[1][0] * m[2][1] - m[1][1] * m[2][0]);
    if det.abs() < 1e-12 {
        return None;
    }
    let inv = 1.0 / det;
    Some([
        [
            (m[1][1] * m[2][2] - m[1][2] * m[2][1]) * inv,
            (m[0][2] * m[2][1] - m[0][1] * m[2][2]) * inv,
            (m[0][1] * m[1][2] - m[0][2] * m[1][1]) * inv,
        ],
        [
            (m[1][2] * m[2][0] - m[1][0] * m[2][2]) * inv,
            (m[0][0] * m[2][2] - m[0][2] * m[2][0]) * inv,
            (m[0][2] * m[1][0] - m[0][0] * m[1][2]) * inv,
        ],
        [
            (m[1][0] * m[2][1] - m[1][1] * m[2][0]) * inv,
            (m[0][1] * m[2][0] - m[0][0] * m[2][1]) * inv,
            (m[0][0] * m[1][1] - m[0][1] * m[1][0]) * inv,
        ],
    ])
}

/// The primaries a buffer's values are relative to.
/// 缓冲区数值所参照的基色。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ColorSpace {
    /// sRGB / BT.709 primaries, the SDR default.
    /// sRGB / BT.709 基色，SDR 默认。
    Srgb,
    /// Display P3, wider gamut, same transfer options as sRGB.
    /// Display P3，更宽色域，传输函数选项与 sRGB 相同。
    DisplayP3,
    /// BT.2020, the HDR wide gamut.
    /// BT.2020，HDR 宽色域。
    Bt2020,
}

/// What an output says it wants. Everything here comes from the compositor.
/// 输出声明它想要什么。这里的每项都来自 compositor。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct OutputDescription {
    pub color_space: ColorSpace,
    pub transfer: TransferFunction,
    /// Peak luminance in nits; SDR is conventionally 80.
    /// 峰值亮度（nit）；SDR 惯例为 80。
    pub max_luminance: f32,
    /// Black level in nits; never assume exactly zero.
    /// 黑电平（nit）；绝不假设恰好为零。
    pub min_luminance: f32,
}

impl OutputDescription {
    /// The plain SDR description, used when the compositor says nothing.
    /// 纯 SDR 描述，compositor 什么都没说时使用。
    pub const SDR: Self = Self {
        color_space: ColorSpace::Srgb,
        transfer: TransferFunction::Srgb,
        max_luminance: 80.0,
        min_luminance: 0.0,
    };

    pub fn is_hdr(&self) -> bool {
        self.transfer.is_hdr() || self.max_luminance > 100.0
    }
}

/// A buffer layout the compositor can import.
/// compositor 可以导入的缓冲布局。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum BufferFormat {
    /// 8-bit sRGB, premultiplied BGRA. The only SDR format we present.
    /// 8-bit sRGB，预乘 BGRA。我们唯一的 SDR 呈现格式。
    Bgra8Srgb,
    /// 10-bit unsigned normalised, premultiplied. Minimum for HDR.
    /// 10-bit 无符号归一，预乘。HDR 的最低要求。
    Rgb10a2,
    /// 16-bit float, premultiplied. Needed above 10-bit precision.
    /// 16-bit 浮点，预乘。超过 10-bit 精度时需要。
    Rgba16Float,
}

impl BufferFormat {
    /// Bits per channel available for colour.
    /// 每个颜色通道可用的位数。
    pub fn bits_per_channel(self) -> u8 {
        match self {
            Self::Bgra8Srgb => 8,
            Self::Rgb10a2 => 10,
            Self::Rgba16Float => 16,
        }
    }

    /// Pick a format that can carry `out`, preferring the cheapest that suffices.
    /// 选一个能承载 `out` 的格式，优先最省的那个。
    ///
    /// 8-bit is not enough for HDR: banding appears in dark gradients before the
    /// peak is reached, so the rule is about the transfer function, not the peak.
    /// 8-bit 不足以承载 HDR：峰值还没到，暗部渐变就先出现色带，
    /// 所以判据是传输函数而不是峰值。
    pub fn choose(out: &OutputDescription) -> Self {
        if !out.transfer.is_hdr() {
            return Self::Bgra8Srgb;
        }
        if out.max_luminance <= 1000.0 {
            Self::Rgb10a2
        } else {
            Self::Rgba16Float
        }
    }
}

impl BufferFormat {
    /// DRM fourcc for a little-endian premultiplied buffer.
    /// 小端预乘缓冲的 DRM fourcc。
    ///
    /// Alpha matters: a compositor blends the result, so the 10-bit format is ABGR2101010,
    /// not XRGB2101010. The f16 one is ABGR16161616F.
    /// alpha 是必须的：compositor 会混合结果，因此 10-bit 用 ABGR2101010 而不是 XRGB2101010。
    pub fn drm_fourcc(self) -> u32 {
        match self {
            Self::Bgra8Srgb => 0x3432_5241,   // 'AR24'
            Self::Rgb10a2 => 0x3033_4241,     // 'AB30'
            Self::Rgba16Float => 0x4834_4241, // 'AB48'
        }
    }

    /// Bytes per pixel, used for stride and buffer sizing.
    /// 每像素字节数，用于 stride 与缓冲大小。
    pub fn bytes_per_pixel(self) -> u32 {
        match self {
            Self::Bgra8Srgb | Self::Rgb10a2 => 4,
            Self::Rgba16Float => 8,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn every_transfer_function_round_trips() {
        // Encode/decode must be inverses, or a colour drifts every time it is copied.
        // 编码/解码必须互逆，否则颜色每被复制一次就漂移一点。
        for tf in [
            TransferFunction::Srgb,
            TransferFunction::Linear,
            TransferFunction::Pq,
            TransferFunction::Hlg,
        ] {
            for i in 0..=20 {
                let v = i as f32 / 20.0;
                let back = tf.encode(tf.decode(v));
                assert!(
                    (back - v).abs() < 1e-4,
                    "{tf:?} at {v}: round trip gave {back}"
                );
            }
        }
    }

    #[test]
    fn srgb_mid_grey_is_about_a_fifth_of_white() {
        // 0.5 encoded sRGB is 0.2140 linear; a wrong curve shifts every blend.
        // 编码 0.5 的 sRGB 约等于 0.2140 线性；曲线错了每次混合都会偏。
        let lin = TransferFunction::Srgb.decode(0.5);
        assert!((lin - 0.2140).abs() < 1e-3, "got {lin}");
    }

    #[test]
    fn pq_one_means_ten_thousand_nits() {
        // PQ is absolute: the top of the range is a fixed luminance, not "white".
        // PQ 是绝对亮度：量程顶端对应固定亮度，而不是「白」。
        let lin = TransferFunction::Pq.decode(1.0);
        assert!((lin - 1.0).abs() < 1e-3, "got {lin}");
        assert!(TransferFunction::Pq.decode(0.5) < 0.01, "mid code is dim");
    }

    #[test]
    fn hlg_has_its_knee_at_half() {
        // The two halves of the HLG curve must meet at 0.5, or a gradient bands there.
        // HLG 两段必须在 0.5 处接上，否则渐变会在那里出现色带。
        let below = TransferFunction::Hlg.decode(0.5 - 1e-4);
        let above = TransferFunction::Hlg.decode(0.5 + 1e-4);
        assert!((below - above).abs() < 1e-3, "{below} vs {above}");
    }

    #[test]
    fn hdr_never_picks_eight_bit() {
        // The rule is about the transfer function, not the peak luminance.
        // 判据是传输函数，不是峰值亮度。
        let hdr = OutputDescription {
            transfer: TransferFunction::Pq,
            max_luminance: 200.0,
            ..OutputDescription::SDR
        };
        assert_ne!(BufferFormat::choose(&hdr), BufferFormat::Bgra8Srgb);
        assert_eq!(
            BufferFormat::choose(&OutputDescription::SDR),
            BufferFormat::Bgra8Srgb
        );
    }

    #[test]
    fn a_very_bright_output_needs_float() {
        // Above 1000 nits, 10-bit normalised loses the shadow detail.
        // 超过 1000 nit 时，10-bit 归一化会丢掉暗部细节。
        let bright = OutputDescription {
            transfer: TransferFunction::Pq,
            max_luminance: 4000.0,
            ..OutputDescription::SDR
        };
        assert_eq!(BufferFormat::choose(&bright), BufferFormat::Rgba16Float);
    }

    #[test]
    fn premultiplication_is_part_of_the_encoding_identity() {
        // Same transfer, different premultiplication: reinterpreting one as the other
        // is the bug this type exists to prevent.
        // 传输函数相同、预乘状态不同：把两者混为一谈正是这个类型要防的 bug。
        let straight = Encoding {
            transfer: TransferFunction::Srgb,
            premultiplied: false,
        };
        assert_ne!(straight, Encoding::SDR_PREMULTIPLIED);
    }

    #[test]
    fn only_linear_counts_as_a_blending_domain() {
        // PQ is a display encoding; blending there shifts hue, so it is not "linear".
        // PQ 是显示编码；在其中混合会偏移色相，因此不算线性域。
        assert!(Encoding::LINEAR_PREMULTIPLIED.is_linear());
        assert!(!Encoding::SDR_PREMULTIPLIED.is_linear());
        let pq = Encoding {
            transfer: TransferFunction::Pq,
            premultiplied: true,
        };
        assert!(!pq.is_linear());
    }

    #[test]
    fn fourcc_matches_the_little_endian_name() {
        // The fourcc is read as a little-endian u32, so 'AR24' is 0x34325241.
        // fourcc 按小端 u32 读，因此 'AR24' 是 0x34325241。
        assert_eq!(BufferFormat::Bgra8Srgb.drm_fourcc(), 0x3432_5241);
        assert_eq!(BufferFormat::Rgba16Float.drm_fourcc(), 0x4834_4241);
    }

    #[test]
    fn ten_bit_keeps_alpha_because_the_compositor_blends() {
        // XRGB2101010 would drop alpha and make every semi-transparent pixel opaque.
        // XRGB2101010 会丢掉 alpha，让每个半透明像素变成不透明。
        let f = BufferFormat::Rgb10a2.drm_fourcc();
        let name = [
            (f & 0xff) as u8,
            ((f >> 8) & 0xff) as u8,
            ((f >> 16) & 0xff) as u8,
            ((f >> 24) & 0xff) as u8,
        ];
        assert_eq!(&name, b"AB30");
    }

    #[test]
    fn bytes_per_pixel_agrees_with_the_channel_width() {
        // Stride is computed from this; a mismatch shifts every row.
        // stride 由它计算；不一致会让每一行错位。
        for f in [
            BufferFormat::Bgra8Srgb,
            BufferFormat::Rgb10a2,
            BufferFormat::Rgba16Float,
        ] {
            let expected = match f {
                BufferFormat::Bgra8Srgb | BufferFormat::Rgb10a2 => 4,
                BufferFormat::Rgba16Float => 8,
            };
            assert_eq!(f.bytes_per_pixel(), expected);
        }
    }

    /// Quantise an encoded value to `bits` bits and read it back.
    /// 把编码值量化到 `bits` 位再读回。
    fn quantise(tf: TransferFunction, linear: f32, bits: u8) -> f32 {
        let levels = ((1u32 << bits) - 1) as f32;
        let code = (tf.encode(linear) * levels).round();
        tf.decode(code / levels)
    }

    #[test]
    fn ten_bit_pq_separates_dark_steps_that_eight_bit_srgb_collapses() {
        // This is the whole reason HDR needs 10-bit: in the shadows, 8-bit sRGB runs out
        // of codes first. Counting distinct codes over a dark ramp measures exactly that.
        // 这就是 HDR 需要 10-bit 的全部理由：暗部里 8-bit sRGB 先耗尽编码。
        // 在暗部渐变上统计不同编码数量，量的正是这件事。
        let ramp: Vec<f32> = (0..64).map(|i| 0.0002 + i as f32 * 0.00002).collect();
        let count = |tf: TransferFunction, bits: u8| {
            let mut codes: Vec<u16> = ramp
                .iter()
                .map(|&l| {
                    let levels = ((1u32 << bits) - 1) as f32;
                    (tf.encode(l) * levels).round() as u16
                })
                .collect();
            codes.sort_unstable();
            codes.dedup();
            codes.len()
        };

        let srgb8 = count(TransferFunction::Srgb, 8);
        let pq10 = count(TransferFunction::Pq, 10);
        assert!(
            srgb8 < 24,
            "8-bit sRGB should collapse most of a dark ramp, got {srgb8} of 64"
        );
        assert!(
            pq10 > srgb8 * 2,
            "10-bit PQ should resolve far more dark steps: {pq10} vs {srgb8}"
        );
    }

    #[test]
    fn a_pq_round_trip_through_ten_bits_stays_within_one_step() {
        // Encode, quantise, decode: the error must be below one code, or a gradient bands.
        // 编码、量化、解码：误差必须小于一个编码，否则渐变会出现色带。
        let step = 1.0 / 1023.0;
        for i in 1..=50 {
            let linear = i as f32 / 50.0;
            let back = quantise(TransferFunction::Pq, linear, 10);
            let tol = (TransferFunction::Pq.decode(
                TransferFunction::Pq.encode(linear) + step,
            ) - linear)
                .abs()
                .max(step);
            assert!(
                (back - linear).abs() <= tol,
                "linear {linear} came back as {back}"
            );
        }
    }

    #[test]
    fn sd_white_lands_near_the_middle_of_the_pq_range() {
        // 80 nit reference white is 0.8% of PQ's 10000 nit range, which is ~0.486 code.
        // 80 nit 参考白是 PQ 10000 nit 量程的 0.8%，约对应编码 0.486。
        let code = encode_for_pq_output(1.0, 80.0, 0.0);
        assert!((code - 0.486).abs() < 0.01, "got {code}");
    }

    #[test]
    fn a_brighter_reference_white_shifts_every_code_up() {
        // The same linear value must code higher when the display's white is brighter.
        // 屏幕白更亮时，同一个线性值必须编到更高的码位。
        let dim = encode_for_pq_output(0.5, 80.0, 0.0);
        let bright = encode_for_pq_output(0.5, 203.0, 0.0);
        assert!(bright > dim, "{bright} should exceed {dim}");
    }

    #[test]
    fn black_stays_at_the_bottom_of_the_range() {
        // A non-zero black level offsets every code; with zero black, linear 0 codes 0.
        // 非零黑电平会给所有码位加偏移；黑电平为零时，线性 0 编到 0。
        assert!(encode_for_pq_output(0.0, 80.0, 0.0).abs() < 1e-4);
    }

    #[test]
    fn converting_a_gamut_to_itself_is_the_identity() {
        let m = gamut_matrix(Chromaticities::SRGB, Chromaticities::SRGB);
        for (i, row) in m.iter().enumerate() {
            for (j, v) in row.iter().enumerate() {
                let want = if i == j { 1.0 } else { 0.0 };
                assert!((v - want).abs() < 1e-5, "row {i} col {j} = {v}");
            }
        }
    }

    #[test]
    fn srgb_to_bt2020_matches_the_published_matrix() {
        // Rows sum to 1: a neutral grey must stay neutral in any gamut.
        // 行和为 1：中性灰在任何色域里都必须仍是中性灰。
        let m = gamut_matrix(Chromaticities::SRGB, Chromaticities::BT2020);
        for row in m {
            let sum: f32 = row.iter().sum();
            assert!((sum - 1.0).abs() < 1e-4, "row sums to {sum}");
        }
        assert!((m[0][0] - 0.6274).abs() < 0.01, "got {}", m[0][0]);
        assert!((m[2][2] - 0.8956).abs() < 0.01, "got {}", m[2][2]);
    }

    #[test]
    fn bradford_keeps_neutrals_neutral_across_white_points() {
        // A target whose white differs from D65: without adaptation a grey drifts,
        // with it the row sums return to 1.
        // 目标白点不同于 D65：不适配时灰色会漂移，适配后行和回到 1。
        let mut target = Chromaticities::BT2020;
        target.white = (0.3140, 0.3300);
        for (mode, expect_one) in [
            (WhiteAdaptation::None, false),
            (WhiteAdaptation::Bradford, true),
        ] {
            let m = gamut_matrix_adapted(Chromaticities::SRGB, target, mode);
            for row in m {
                let sum: f32 = row.iter().sum();
                if expect_one {
                    assert!((sum - 1.0).abs() < 1e-3, "{mode:?} row sums to {sum}");
                }
            }
        }
        let plain = gamut_matrix_adapted(Chromaticities::SRGB, target, WhiteAdaptation::None);
        let adapted =
            gamut_matrix_adapted(Chromaticities::SRGB, target, WhiteAdaptation::Bradford);
        let drift: f32 = plain[0].iter().sum::<f32>() - adapted[0].iter().sum::<f32>();
        assert!(drift.abs() > 1e-4, "adaptation changed nothing: {drift}");
    }
}
