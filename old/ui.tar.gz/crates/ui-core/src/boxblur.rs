//! Three-pass box blur: a Gaussian approximation whose cost does not grow with radius.
//! 三趟箱式模糊：代价不随半径增长的高斯近似。
//!
//! A direct convolution is O(taps) per pixel, so a large radius is both slow and bounded
//! by whatever the backend's kernel array holds. Three box passes average shifts of the
//! input instead, giving O(1) per pixel and an effective sigma that tracks the box width
//! linearly — the same construction the W3C filter spec and Skia's `SkBlurMask` use.
//! 直接卷积每像素是 O(taps)，半径一大既慢又受后端核数组长度限制。三趟箱式改为对输入做
//! 滑窗均值，每像素 O(1)，有效 sigma 与箱宽成线性关系——与 W3C 滤镜规范、Skia 的
//! `SkBlurMask` 用的是同一构造。

/// Box passes per axis; three make the average a Gaussian.
/// 每轴箱式趟数；三次即让平均成为高斯。
pub const BOX_PASSES: u32 = 3;

/// Widest box radius a pass can use; keeps the window sum inside f32 precision.
/// 单趟能使用的最大箱半径；保证窗口和在 f32 精度内。
pub const MAX_BOX_RADIUS: u32 = 4096;

/// Box radius whose three passes approximate a Gaussian of `sigma`.
/// 三趟之后近似 `sigma` 高斯的箱半径。
///
/// Three box averages of width `w` have variance `3(w²-1)/12`; solving for `w` gives the
/// relation below. The result is close to `sigma` itself, which is why this replaces the
/// radius cap a tap-limited backend needs.
/// 三次宽为 `w` 的箱式平均方差为 `3(w²-1)/12`；解出 `w` 即得下式。结果接近 `sigma`
/// 本身，这正是它能取代「按 tap 数限制半径」的原因。
pub fn radius_for_sigma(sigma: f32) -> u32 {
    if sigma <= 0.0 {
        return 0;
    }
    let w = (12.0 * sigma * sigma / 3.0 + 1.0).sqrt();
    // An odd width keeps the window symmetric around its centre pixel.
    // 奇数宽度保证窗口围绕中心像素对称。
    let mut w = w.round() as i32;
    if w % 2 == 0 {
        w += 1;
    }
    ((w - 1) / 2).clamp(0, MAX_BOX_RADIUS as i32) as u32
}

/// Effective sigma of three box passes with `radius`.
/// 半径为 `radius` 的三趟箱式模糊的有效 sigma。
pub fn sigma_for_radius(radius: u32) -> f32 {
    let w = (2 * radius + 1) as f32;
    (3.0 * (w * w - 1.0) / 12.0).sqrt()
}

/// One horizontal box pass over an interleaved RGBA8 image, clamped at the edges.
/// 对交错 RGBA8 图像做一趟水平箱式模糊，边缘按夹取处理。
pub fn box_h(rgba: &mut [u8], stride: usize, x0: usize, y0: usize, w: usize, rows: usize, radius: u32) {
    #[cfg(feature = "simd")]
    simd_pass::box_h(rgba, stride, x0, y0, w, rows, radius);
    #[cfg(not(feature = "simd"))]
    box_h_scalar(rgba, stride, x0, y0, w, rows, radius);
}

/// One vertical box pass; same contract as [`box_h`].
/// 一趟垂直箱式模糊；约定与 [`box_h`] 相同。
pub fn box_v(rgba: &mut [u8], stride: usize, x0: usize, y0: usize, w: usize, rows: usize, radius: u32) {
    #[cfg(feature = "simd")]
    simd_pass::box_v(rgba, stride, x0, y0, w, rows, radius);
    #[cfg(not(feature = "simd"))]
    box_v_scalar(rgba, stride, x0, y0, w, rows, radius);
}

/// One horizontal box pass over an interleaved RGBA8 image, clamped at the edges.
/// 对交错 RGBA8 图像做一趟水平箱式模糊，边缘按夹取处理。
///
/// `stride` is the row length in pixels, so this also works on a sub-rectangle of a
/// larger image without copying it out first.
/// `stride` 是整行的像素数，因此可以直接作用在大图的子矩形上，无需先拷贝出来。
#[cfg(any(not(feature = "simd"), test))]
fn box_h_scalar(rgba: &mut [u8], stride: usize, x0: usize, y0: usize, w: usize, rows: usize, radius: u32) {
    if radius == 0 || w == 0 || rows == 0 {
        return;
    }
    let r = radius as usize;
    let span = (2 * r + 1) as u32;
    let last = x0 + w - 1;
    // The window must subtract the *input* at the leaving position, but that byte has
    // already been overwritten by this pass; keeping the source row keeps the sum a true
    // box average instead of a recursion that drifts from the third pixel on.
    // 窗口必须减去离开位置的**输入**，而该字节已被本趟覆盖；保留源行才能让求和是
    // 真正的箱式平均，而不是从第三个像素起就偏离的递归。
    let mut src = vec![0u8; w * 4];
    for y in y0..y0 + rows {
        let row = y * stride;
        let base = (row + x0) * 4;
        src.copy_from_slice(&rgba[base..base + w * 4]);
        // Seed by summing the clamped window at x0, so an edge pixel contributes once per
        // tap that reaches it — the same weight a clamp sampler would give it.
        // 播种时按夹取规则求和 x0 处的完整窗口：边缘像素被每个触及它的 tap 各计一次，
        // 与夹取采样器给它的权重一致。
        let mut acc = [0u32; 4];
        for i in 0..=2 * r {
            let sx = (x0 + i).saturating_sub(r).clamp(x0, last) - x0;
            for c in 0..4 {
                acc[c] += src[sx * 4 + c] as u32;
            }
        }
        for x in x0..x0 + w {
            let sub = (x.saturating_sub(r).clamp(x0, last) - x0) * 4;
            let leaving = [src[sub], src[sub + 1], src[sub + 2], src[sub + 3]];
            let px = (row + x) * 4;
            for c in 0..4 {
                rgba[px + c] = (acc[c] / span) as u8;
            }
            let add = ((x + r + 1).clamp(x0, last) - x0) * 4;
            for c in 0..4 {
                let next = acc[c] as i64 + src[add + c] as i64 - leaving[c] as i64;
                acc[c] = next.max(0) as u32;
            }
        }
    }
}

/// One vertical box pass; same contract as [`box_h`].
/// 一趟垂直箱式模糊；约定与 [`box_h`] 相同。
#[cfg(any(not(feature = "simd"), test))]
fn box_v_scalar(rgba: &mut [u8], stride: usize, x0: usize, y0: usize, w: usize, rows: usize, radius: u32) {
    if radius == 0 || w == 0 || rows == 0 {
        return;
    }
    let r = radius as usize;
    let span = (2 * r + 1) as u32;
    let bottom = y0 + rows - 1;
    // Same reason as the horizontal pass: the leaving pixel has already been overwritten,
    // so the source column has to be kept for the sum to stay a true window average.
    // 与横向同理：离开的像素已被覆盖，必须保留源列，求和才是真正的窗口平均。
    let mut src = vec![0u8; rows * 4];
    for x in x0..x0 + w {
        for (i, y) in (y0..=bottom).enumerate() {
            let at = (y * stride + x) * 4;
            src[i * 4..i * 4 + 4].copy_from_slice(&rgba[at..at + 4]);
        }
        let mut acc = [0u32; 4];
        for i in 0..=2 * r {
            let sy = (y0 + i).saturating_sub(r).clamp(y0, bottom) - y0;
            for c in 0..4 {
                acc[c] += src[sy * 4 + c] as u32;
            }
        }
        for y in y0..=bottom {
            let sub = (y.saturating_sub(r).clamp(y0, bottom) - y0) * 4;
            let leaving = [src[sub], src[sub + 1], src[sub + 2], src[sub + 3]];
            let at = (y * stride + x) * 4;
            for c in 0..4 {
                rgba[at + c] = (acc[c] / span) as u8;
            }
            let add = ((y + r + 1).clamp(y0, bottom) - y0) * 4;
            for c in 0..4 {
                let next = acc[c] as i64 + src[add + c] as i64 - leaving[c] as i64;
                acc[c] = next.max(0) as u32;
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Three box passes must match the Gaussian they are meant to stand in for.
    /// 三趟箱式模糊必须接近它所要替代的高斯。
    #[test]
    fn the_box_radius_tracks_the_requested_sigma() {
        for sigma in [1.0_f32, 3.0, 6.0, 14.0, 30.0] {
            let r = radius_for_sigma(sigma);
            let back = sigma_for_radius(r);
            assert!(
                (back - sigma).abs() < sigma * 0.08 + 0.4,
                "sigma {sigma} came back as {back} through radius {r}"
            );
        }
        assert_eq!(radius_for_sigma(0.0), 0, "no sigma means no blur");
    }

    /// A flat field is a fixed point: any non-identity result means the window sum drifted.
    /// 平坦场是不动点：结果若偏离，说明窗口和算错了。
    #[test]
    fn a_flat_field_survives_every_pass_unchanged() {
        let (w, h) = (32, 16);
        let mut img = vec![80u8; w * h * 4];
        for radius in [1, 5, 20] {
            box_h(&mut img, w, 0, 0, w, h, radius);
            box_v(&mut img, w, 0, 0, w, h, radius);
            assert!(
                img.iter().all(|&b| b == 80),
                "radius {radius} shifted a flat field: {:?}",
                &img[..4]
            );
        }
    }

    /// A hard edge must become a ramp: that is what blurring means, and a lone bright
    /// pixel is the wrong probe because three divisions by the box width quantise it to
    /// zero at u8.
    /// 硬边必须变成斜坡——这才是模糊的定义；孤立的亮点不适合做探针，因为三次按箱宽
    /// 相除在 u8 下会把它量化成 0。
    #[test]
    fn a_hard_edge_becomes_a_ramp() {
        let (w, h) = (48, 8);
        let mut img = vec![0u8; w * h * 4];
        // Left half white, right half black.
        for y in 0..h {
            for x in 0..w {
                let v = if x < w / 2 { 240 } else { 20 };
                for c in 0..4 {
                    img[(y * w + x) * 4 + c] = v;
                }
            }
        }
        let radius = 6;
        for _ in 0..3 {
            box_h(&mut img, w, 0, 0, w, h, radius);
        }
        let row = 4 * w;
        let steps = (1..w)
            .filter(|&x| {
                let a = img[(row + x - 1) * 4] as i32;
                let b = img[(row + x) * 4] as i32;
                (a - b).abs() > 0
            })
            .count();
        assert!(
            steps >= (2 * radius) as usize,
            "the edge must spread over several pixels, got {steps}"
        );
        let mid = img[(row + w / 2) * 4] as i32;
        assert!(
            (60..200).contains(&mid),
            "the midpoint must land between the two sides, got {mid}"
        );
    }

    /// A gradient must stay a gradient: the window sum is preserved by construction, so
    /// every pixel must sit within one step of its neighbours, with no edge collapse.
    /// 渐变必须保持渐变：窗口和在构造上守恒，因此每个像素与邻居相差不超过一档，边缘不得塌陷。
    #[test]
    fn a_ramp_keeps_its_slope_right_out_to_the_edges() {
        let (w, h) = (64, 4);
        let mut img = vec![0u8; w * h * 4];
        for y in 0..h {
            for x in 0..w {
                let v = (x * 4) as u8;
                for c in 0..4 {
                    img[(y * w + x) * 4 + c] = v;
                }
            }
        }
        let radius = 9;
        // Start at a non-zero column: clamping against the sub-rectangle's own左 edge is
        // the case a plain `saturating_sub` cannot express.
        // 从非零列开始：相对子矩形自身左边界做夹取，恰恰是单纯 `saturating_sub`
        // 表达不出来的情形。
        let x0 = 12;
        let bw = 32;
        box_h(&mut img, w, x0, 0, bw, h, radius);
        let row = 2 * w;
        // First and last pixels must not fall back toward zero: a window that forgets to
        // replicate the edge pixel loses weight exactly there.
        // 首末像素不得回落到 0：忘记复制边缘像素的窗口恰好在那里丢权重。
        // The clamped window mean at each end is computable in closed form, so this
        // pins the seeding rule rather than merely checking the result looks reasonable.
        // 两端夹取窗口的均值可以闭式算出，因此这里钉的是播种规则本身，而不只是「看起来合理」。
        let first = img[(row + x0) * 4] as i32;
        let last = img[(row + x0 + bw - 1) * 4] as i32;
        assert_eq!(
            first, 57,
            "the sub-rectangle's first pixel must match its clamped window mean"
        );
        // 3088/19 = 162.5, so the clamped window mean truncates to 162; the previous 161
        // came from the recursion subtracting its own output, not from the seeding rule.
        // 3088/19 = 162.5，夹取窗口均值截断为 162；此前的 161 来自递归减掉了自身输出，
        // 与播种规则无关。
        assert_eq!(
            last, 162,
            "and its last must match its own clamped window mean"
        );
    }

    /// Clamping at the edge must not create a dark rim, which a zero-padded window would.
    /// 边缘夹取不得产生暗边——补零的窗口就会。
    #[test]
    fn the_edge_stays_bright_instead_of_darkening() {
        let (w, h) = (24, 8);
        let mut img = vec![120u8; w * h * 4];
        box_h(&mut img, w, 0, 0, w, h, 10);
        assert_eq!(
            img[0], 120,
            "the first pixel must keep the field's value, got {}",
            img[0]
        );
        assert_eq!(img[(w - 1) * 4], 120, "and so must the last");
    }

    /// Operating on a sub-rectangle must leave the rest of the image untouched.
    /// 只作用于子矩形时，图像其余部分必须保持不变。
    #[test]
    fn a_sub_rectangle_leaves_the_surroundings_alone() {
        let (w, h) = (20, 20);
        let mut img = vec![10u8; w * h * 4];
        // Mark a border ring we expect to survive.
        for x in 0..w {
            for c in 0..4 {
                img[x * 4 + c] = 200;
                img[((h - 1) * w + x) * 4 + c] = 200;
            }
        }
        let before = img.clone();
        let (x0, y0, bw, bh) = (5, 5, 8, 8);
        for c in 0..4 {
            img[(y0 * w + x0) * 4 + c] = 250;
        }
        box_h(&mut img, w, x0, y0, bw, bh, 3);
        box_v(&mut img, w, x0, y0, bw, bh, 3);
        for x in 0..w {
            for c in 0..4 {
                assert_eq!(img[x * 4 + c], before[x * 4 + c], "top row x={x} was touched");
                assert_eq!(
                    img[((h - 1) * w + x) * 4 + c],
                    before[((h - 1) * w + x) * 4 + c],
                    "bottom row x={x} was touched"
                );
            }
        }
    }

    /// A pass must equal a direct window average. Subtracting the pixel this pass already
    /// overwrote turns the running sum into a recursion and drifts from the third pixel on.
    /// 一趟必须等于直接窗口平均。减去本趟已覆盖的像素会把运行和变成递归，从第三个像素起就偏离。
    #[test]
    fn a_pass_matches_a_direct_window_average() {
        let n = 24usize;
        let src: Vec<u8> = (0..n).map(|i| (i * 53 % 251) as u8).collect();
        for radius in [1u32, 2, 3] {
            let r = radius as usize;
            let mut img = vec![0u8; n * 4];
            for (i, v) in src.iter().enumerate() {
                for c in 0..4 {
                    img[i * 4 + c] = *v;
                }
            }
            box_h(&mut img, n, 0, 0, n, 1, radius);
            let want: Vec<u8> = (0..n)
                .map(|i| {
                    let mut sum = 0u32;
                    for k in 0..=(2 * r) {
                        let idx = (i + k).saturating_sub(r).clamp(0, n - 1);
                        sum += src[idx] as u32;
                    }
                    (sum / (2 * r + 1) as u32) as u8
                })
                .collect();
            let got: Vec<u8> = (0..n).map(|i| img[i * 4]).collect();
            assert_eq!(got, want, "radius {radius} drifted from the window average");
        }
            }

    /// The vertical pass needs the same guarantee: it reads the column it just overwrote.
    /// 纵向趟需要同样的保证：它读的是自己刚覆盖过的那一列。
    #[test]
    fn a_vertical_pass_matches_a_direct_window_average() {
        let n = 24usize;
        let src: Vec<u8> = (0..n).map(|i| (i * 53 % 251) as u8).collect();
        for radius in [1u32, 2, 3] {
            let r = radius as usize;
            let mut img = vec![0u8; n * 4];
            for (i, v) in src.iter().enumerate() {
                for c in 0..4 {
                    img[i * 4 + c] = *v;
                }
            }
            box_v(&mut img, 1, 0, 0, 1, n, radius);
            let want: Vec<u8> = (0..n)
                .map(|i| {
                    let mut sum = 0u32;
                    for k in 0..=(2 * r) {
                        let idx = (i + k).saturating_sub(r).clamp(0, n - 1);
                        sum += src[idx] as u32;
                    }
                    (sum / (2 * r + 1) as u32) as u8
                })
                .collect();
            let got: Vec<u8> = (0..n).map(|i| img[i * 4]).collect();
            assert_eq!(got, want, "radius {radius} drifted from the window average");
        }
    }
}

#[cfg(all(feature = "simd", test))]
mod simd_agrees_with_scalar {
    use super::*;

    /// A deterministic ramp with a hard edge, so a wrong window shows up immediately.
    /// 一条确定性渐变加一条硬边，窗口算错会立刻暴露。
    fn image(w: usize, h: usize) -> Vec<u8> {
        let mut v = vec![0u8; w * h * 4];
        for y in 0..h {
            for x in 0..w {
                let i = (y * w + x) * 4;
                let t = if x < w / 2 { x * 3 } else { 200 } as u8;
                v[i..i + 4].copy_from_slice(&[t, (y * 7) as u8, (x * 11) as u8, 255]);
            }
        }
        v
    }

    #[test]
    fn the_simd_passes_agree_with_the_scalar_reference() {
        // The four-lane path is only worth having if it computes the same window average;
        // without this, a broken lane shuffle looks like a slightly softer blur.
        // 四通道路径只有算出同一个窗口平均才值得存在；没有这条，通道错位看起来只是「略软」。
        let (w, h) = (37, 11);
        for radius in [1u32, 3, 8] {
            for vertical in [false, true] {
                let mut fast = image(w, h);
                let mut slow = image(w, h);
                if vertical {
                    box_v(&mut fast, w, 0, 0, w, h, radius);
                    box_v_scalar(&mut slow, w, 0, 0, w, h, radius);
                } else {
                    box_h(&mut fast, w, 0, 0, w, h, radius);
                    box_h_scalar(&mut slow, w, 0, 0, w, h, radius);
                }
                assert_eq!(fast, slow, "radius {radius} vertical {vertical}");
            }
        }
    }
}

/// Four-lane versions of the passes: RGBA is exactly one vector, so the running sum, the
/// add and the subtract each become one instruction instead of four.
/// 各趟的四通道版本：RGBA 正好是一个向量，因此运行和、加入与减去都各用一条指令完成。
#[cfg(feature = "simd")]
mod simd_pass {
    use wide::u32x4;

    #[inline(always)]
    fn load(src: &[u8], at: usize) -> u32x4 {
        let b = &src[at..at + 4];
        u32x4::new([b[0] as u32, b[1] as u32, b[2] as u32, b[3] as u32])
    }

    #[inline(always)]
    fn store(dst: &mut [u8], at: usize, v: u32x4, span: u32) {
        let a = v.to_array();
        let out = &mut dst[at..at + 4];
        out[0] = (a[0] / span) as u8;
        out[1] = (a[1] / span) as u8;
        out[2] = (a[2] / span) as u8;
        out[3] = (a[3] / span) as u8;
    }

    pub(super) fn box_h(
        rgba: &mut [u8],
        stride: usize,
        x0: usize,
        y0: usize,
        w: usize,
        rows: usize,
        radius: u32,
    ) {
        if radius == 0 || w == 0 || rows == 0 {
            return;
        }
        let r = radius as usize;
        let span = 2 * r as u32 + 1;
        let last = x0 + w - 1;
        // The leaving pixel has already been overwritten by this pass, so the source row is
        // kept; subtracting the live value would make the sum a recursion.
        // 离开的像素已被本趟覆盖，因此保留源行；减实时值会让求和变成递归。
        let mut src = vec![0u8; w * 4];
        for y in y0..y0 + rows {
            let row = y * stride;
            let base = (row + x0) * 4;
            src.copy_from_slice(&rgba[base..base + w * 4]);
            let mut acc = u32x4::ZERO;
            for i in 0..=2 * r {
                let sx = (x0 + i).saturating_sub(r).clamp(x0, last) - x0;
                acc += load(&src, sx * 4);
            }
            for x in x0..x0 + w {
                let sub = (x.saturating_sub(r).clamp(x0, last) - x0) * 4;
                let leaving = load(&src, sub);
                let px = (row + x) * 4;
                store(rgba, px, acc, span);
                let add = ((x + r + 1).clamp(x0, last) - x0) * 4;
                acc = acc + load(&src, add) - leaving;
            }
        }
    }

    pub(super) fn box_v(
        rgba: &mut [u8],
        stride: usize,
        x0: usize,
        y0: usize,
        w: usize,
        rows: usize,
        radius: u32,
    ) {
        if radius == 0 || w == 0 || rows == 0 {
            return;
        }
        let r = radius as usize;
        let span = 2 * r as u32 + 1;
        let bottom = y0 + rows - 1;
        let mut src = vec![0u8; rows * 4];
        for x in x0..x0 + w {
            for (i, y) in (y0..=bottom).enumerate() {
                let at = (y * stride + x) * 4;
                src[i * 4..i * 4 + 4].copy_from_slice(&rgba[at..at + 4]);
            }
            let mut acc = u32x4::ZERO;
            for i in 0..=2 * r {
                let sy = (y0 + i).saturating_sub(r).clamp(y0, bottom) - y0;
                acc += load(&src, sy * 4);
            }
            for y in y0..=bottom {
                let sub = (y.saturating_sub(r).clamp(y0, bottom) - y0) * 4;
                let leaving = load(&src, sub);
                let at = (y * stride + x) * 4;
                store(rgba, at, acc, span);
                let add = ((y + r + 1).clamp(y0, bottom) - y0) * 4;
                acc = acc + load(&src, add) - leaving;
            }
        }
    }
}
