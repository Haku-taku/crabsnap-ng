//! Selection: where it is, and how a style draws it.
//! 选区：它在哪里，以及风格怎么画它。

use crate::draw::RectPrim;
use crate::geom::{Color, Rect};

/// A selection in a text buffer, as two byte offsets.
/// 文本缓冲中的选区，用两个字节偏移表示。
///
/// The anchor stays where the gesture began and the caret follows the pointer or keys;
/// which one is smaller is not the reader's business, so `range` normalises them.
/// 锚点停在手势开始处，插入符跟随指针或按键；谁更小与读者无关，`range` 会把它们归一。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct TextSelection {
    pub anchor: usize,
    pub caret: usize,
}

impl TextSelection {
    pub const fn new(anchor: usize, caret: usize) -> Self {
        Self { anchor, caret }
    }

    pub const fn collapsed(at: usize) -> Self {
        Self {
            anchor: at,
            caret: at,
        }
    }

    /// The selected bytes, start first.
    /// 被选中的字节区间，起点在前。
    pub fn range(&self) -> std::ops::Range<usize> {
        if self.anchor <= self.caret {
            self.anchor..self.caret
        } else {
            self.caret..self.anchor
        }
    }

    pub fn is_collapsed(&self) -> bool {
        self.anchor == self.caret
    }

    /// Whether a click at `index` belongs to this selection: inside it or on either edge.
    /// 在 `index` 处的点击是否属于本选区：区间之内或两端。
    pub fn covers(&self, index: usize) -> bool {
        let range = self.range();
        index >= range.start && index <= range.end
    }
}

/// One visual fragment of a selection: a run of selected glyphs on one line.
/// 选区的一个视觉片段：一行上连续的一段被选中字形。
///
/// A wrapped or bidirectional selection has one fragment per visual line piece, so a
/// painter never has to re-break the text to know where the highlight goes.
/// 换行或双向的选区每段视觉行各一个片段，绘制程序因此不必重新断行就知道高亮落在哪。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct SelectionFragment {
    /// Where it sits on the surface; one line box tall.
    /// 在表面上的位置；高度为一个行框。
    pub rect: Rect,
    /// Line index inside the block.
    /// 该片段在块内的行号。
    pub line: usize,
    /// The selection's first fragment.
    /// 选区的第一段。
    pub first: bool,
    /// The selection's last fragment.
    /// 选区的最后一段。
    pub last: bool,
    /// This fragment reads right to left.
    /// 该片段从右到左阅读。
    pub rtl: bool,
}

/// What a painter is given: geometry plus the colours in force.
/// 交给绘制程序的东西：几何，以及当前生效的颜色。
#[derive(Clone, Copy, Debug)]
pub struct SelectionGeometry<'a> {
    pub fragments: &'a [SelectionFragment],
    /// The selection colour the style resolved; a painter may use it or ignore it.
    /// 风格解析出的选区色；绘制程序可用可不用。
    pub fill: Color,
    /// The text's own ink.
    /// 文字自身的墨色。
    pub ink: Color,
}

/// What a painter returns: rects in surface coordinates, plus an ink override.
/// 绘制程序返回的东西：表面坐标下的矩形，以及可选的墨色覆盖。
#[derive(Clone, Debug, Default, PartialEq)]
pub struct SelectionPaint {
    /// Painted beneath the glyphs, in order.
    /// 按顺序画在字形之下。
    pub rects: Vec<RectPrim>,
    /// Draw the selected glyphs in this ink; `None` keeps the text's own.
    /// 用这个墨色画被选中的字形；`None` 保持文字自身墨色。
    pub ink: Option<Color>,
}

/// A selection's drawing policy, chosen by the style and carried by the declaration.
/// 选区的绘制策略，由风格选定、随声明携带。
///
/// The engine owns the geometry and the paint order; a system that wants a pill, a
/// hairline or inverted text supplies a painter and never touches the text pass.
/// 引擎负责几何与绘制顺序；想要胶囊、细线或反白文字的体系提供绘制程序，
/// 永远不必碰文本那一趟。
/// Painters travel inside `Style`, so they must cross threads with it.
/// 绘制程序随 `Style` 一起流动，因此必须与之一同跨线程。
pub trait SelectionPainter: std::fmt::Debug + Send + Sync {
    fn paint(&self, geometry: &SelectionGeometry<'_>) -> SelectionPaint;
}

/// A painter carried by a declaration, compared by identity.
/// 随声明携带的绘制程序，按身份比较。
///
/// `&'static` keeps the declaration copyable and the comparison honest: `ptr::eq` on a
/// trait object compares the vtable too, so two different zero-sized painters never
/// collapse into one.
/// `&'static` 让声明保持可 Copy，比较也诚实：trait object 上的 `ptr::eq` 连 vtable 一起比，
/// 因此两个不同的零尺寸绘制程序绝不会混成同一个。
#[derive(Clone, Copy)]
pub struct SelectionPainterRef(pub &'static dyn SelectionPainter);

impl PartialEq for SelectionPainterRef {
    fn eq(&self, other: &Self) -> bool {
        std::ptr::eq(self.0, other.0)
    }
}

impl std::fmt::Debug for SelectionPainterRef {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("SelectionPainter")
    }
}

/// A text node's selection: the byte range, the colour and who draws it.
/// 文本节点的选区：字节区间、颜色，以及由谁绘制。
#[derive(Clone, Debug, PartialEq)]
pub struct SelectionPrim {
    pub range: std::ops::Range<usize>,
    pub fill: Color,
    pub painter: Option<SelectionPainterRef>,
}

/// The engine's own look, for a style that names no painter: a plain rect in `fill`.
/// 体系不指定绘制程序时引擎自己的样子：用 `fill` 画一个平直矩形。
pub fn flat_selection(geometry: &SelectionGeometry<'_>) -> SelectionPaint {
    SelectionPaint {
        rects: geometry
            .fragments
            .iter()
            .map(|f| RectPrim {
                rect: f.rect,
                radius: crate::geom::Corners::ZERO,
                fill: geometry.fill,
                gradient: None,
                border: None,
                border_gradient: None,
                notch: None,
            })
            .collect(),
        ink: None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[derive(Debug)]
    struct A;
    #[derive(Debug)]
    struct B;

    impl SelectionPainter for A {
        fn paint(&self, _: &SelectionGeometry<'_>) -> SelectionPaint {
            SelectionPaint::default()
        }
    }
    impl SelectionPainter for B {
        fn paint(&self, _: &SelectionGeometry<'_>) -> SelectionPaint {
            SelectionPaint::default()
        }
    }

    static PAINTER_A: A = A;
    static PAINTER_B: B = B;

    #[test]
    fn two_zero_sized_painters_are_not_the_same_painter() {
        // Zero-sized types share a dangling data pointer, so a comparison that ignored
        // the vtable would call every painter equal and freeze the declaration cache.
        // 零尺寸类型共用悬垂数据指针；忽略 vtable 的比较会把所有绘制程序判等，
        // 声明缓存于是永远认为没变。
        let a = SelectionPainterRef(&PAINTER_A);
        let b = SelectionPainterRef(&PAINTER_B);
        let same = SelectionPainterRef(&PAINTER_A);
        assert_ne!(a, b);
        assert_eq!(a, same);
    }

    #[test]
    fn the_range_normalises_a_backwards_selection() {
        // Dragging right to left is normal; the range must still start first.
        // 从右往左拖是常态；区间仍必须起点在前。
        let sel = TextSelection::new(9, 3);
        assert_eq!(sel.range(), 3..9);
        assert_eq!(TextSelection::collapsed(4).range(), 4..4);
        assert!(TextSelection::collapsed(4).is_collapsed());
    }
}
