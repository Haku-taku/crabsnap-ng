//! Layout sizes and the pluggable layout engine trait.
//! 布局尺寸与可插拔的布局引擎 trait。

use crate::geom::{Insets, Rect};

/// An inset side that is not declared; the solver derives it.
/// 未声明的内边距一侧；由求解器推出。
pub const AUTO: f32 = f32::INFINITY;

/// An author-specified length along one axis.
/// 作者在单一轴上指定的长度。
///
/// `Pct` is relative to the containing block on the same axis; when that is unknown it
/// reads as `Auto`. Percentage heights against an indefinite parent are not errors.
/// `Pct` 相对包含块同轴尺寸；不确定时按 `Auto` 处理。父高不定时的百分比高度不算错误。
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Len {
    Auto,
    Px(f32),
    Pct(f32),
}

/// How an axis decides its size, independent of context.
/// 一个轴如何确定尺寸，与上下文无关。
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Sizing {
    /// An exact value (CSS `width`), stored as a length so `%` can be expressed.
    /// 精确值（CSS `width`），存为长度以便表达百分比。
    Definite(Len),
    /// Shrink to content: `clamp(min_content, avail, max_content)`, CSS fit-content / hug.
    /// 收缩到内容：`clamp(min_content, avail, max_content)`，即 CSS fit-content / hug。
    Fit,
    /// Take all the space the parent offers, CSS stretch / fill.
    /// 占满父给的可用空间，即 CSS stretch / fill。
    Stretch,
    /// Decided by the container algorithm (flex main axis, grid item, abspos auto axis).
    /// 由容器算法决定（flex 主轴、grid item、abspos 的 auto 轴）。
    Auto,
}

/// The context-free form of one axis: how it sizes, plus explicit bounds.
/// 单轴的上下文无关形式：定尺寸方式与显式上下界。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct AxisSizes {
    pub size: Sizing,
    /// Starts at 0, like CSS `min-width: 0`.
    /// 初始为 0，如同 CSS `min-width: 0`。
    pub min: Len,
    /// Starts unbounded, like CSS `max-width: none`.
    /// 初始无上界，如同 CSS `max-width: none`。
    pub max: Len,
}

/// A node's size preference along one axis, in the shape of Qt's
/// `(min, sizeHint, max, expanding)` tuple; `sizes()` translates it to [`AxisSizes`].
/// 节点在单一轴上的尺寸意愿，形如 Qt 的 `(min, hint, max, expanding)`；
/// `sizes()` 把它转成 [`AxisSizes`]。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct AxisSize {
    /// Below this the content breaks (e.g. text would be truncated).
    /// 低于此值内容就坏了（例如文字被截断）。
    pub min: f32,
    /// Comfortable size; "hug content" reports the measured extent here.
    /// 舒适尺寸；"适应内容"就把它报成测得的宽度。
    pub hint: f32,
    /// Above this a node gains nothing; "fixed" sets min == hint == max.
    /// 超过此值也无益；"固定"即 min == hint == max。
    pub max: f32,
    /// Which constructor made this value; the numbers alone cannot tell hug from fill.
    /// 由哪个构造器产生；单看数值无法区分 hug 与 fill。
    pub sizing: Sizing,
}

impl AxisSize {
    /// A fixed size: min == hint == max.
    /// 固定尺寸：min == hint == max。
    pub const fn fixed(v: f32) -> Self {
        Self {
            min: v,
            hint: v,
            max: v,
            sizing: Sizing::Definite(Len::Px(v)),
        }
    }

    /// Hug content: a lower bound plus the measured extent.
    /// 适应内容：下限加测得尺寸。
    pub const fn hug(min: f32, hint: f32) -> Self {
        Self {
            min,
            hint,
            max: f32::INFINITY,
            sizing: Sizing::Fit,
        }
    }

    /// Grow to fill: like `hug`, but the parent may hand over spare space.
    /// 跟随父宽：同 `hug`，但父容器可以把剩余空间给它。
    pub const fn fill(min: f32, hint: f32) -> Self {
        Self {
            min,
            hint,
            max: f32::INFINITY,
            sizing: Sizing::Stretch,
        }
    }

    /// Translate to the context-free vocabulary. `hint` is a comfort ceiling only where the
    /// author asked to fit content; a `fill` wants the space itself, so its hint stays a basis.
    /// 转成上下文无关词汇。只有「适应内容」才把 `hint` 当舒适上限；
    /// `fill` 要的是空间本身，它的 hint 只作基准，不是上限。
    pub fn sizes(self) -> AxisSizes {
        let capped = self.sizing == Sizing::Fit && self.hint.is_finite() && self.hint > self.min;
        let max = if capped {
            Len::Px(self.hint)
        } else if self.max.is_finite() {
            Len::Px(self.max)
        } else {
            Len::Auto
        };
        AxisSizes {
            size: self.sizing,
            min: Len::Px(self.min),
            max,
        }
    }

    pub fn clamp_to(self, lo: f32, hi: f32) -> Self {
        Self {
            min: self.min.clamp(lo, hi),
            hint: self.hint.clamp(lo, hi),
            max: self.max.clamp(lo, hi),
            sizing: self.sizing,
        }
    }
}

impl From<AxisSize> for AxisSizes {
    fn from(axis: AxisSize) -> Self {
        axis.sizes()
    }
}

/// How a node takes spare space on an axis. Covers "fill parent" and "flex weight".
/// 节点如何在轴上取得剩余空间。覆盖"跟随父宽"与"flex 权重"。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Grow {
    /// Never grows beyond `hint`, yet still shrinks like every item (a declared floor stops it).
    /// 永不超过 hint，但仍和所有项一样可压缩（声明的下限才拦住它）。
    #[default]
    No,
    /// Takes all spare space (when it is the only grower) or shares equally.
    /// 吃全部剩余空间（唯一者）或均分剩余空间。
    Yes,
    /// Takes spare space proportional to weight.
    /// 按权重分剩余空间。
    Flex(u16),
    /// Grows from a zero basis, so equal weights give equal sizes whatever the content is
    /// (CSS `flex: 1 1 0`); `Yes` and `Flex` grow *on top of* the content instead.
    /// 以零基准增长，等权重因而等大，与内容无关（CSS `flex: 1 1 0`）；
    /// `Yes` 与 `Flex` 是在内容之上再增长。
    Split(u16),
}

/// Per-axis layout demand of one node.
/// 单个节点在双轴上的布局需求。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct SizeClass {
    pub width: AxisSize,
    pub height: AxisSize,
    pub grow_x: Grow,
    pub grow_y: Grow,
}

impl SizeClass {
    pub const fn fixed(w: f32, h: f32) -> Self {
        Self {
            width: AxisSize::fixed(w),
            height: AxisSize::fixed(h),
            grow_x: Grow::No,
            grow_y: Grow::No,
        }
    }

    pub const fn hug(w: f32, h: f32) -> Self {
        Self {
            width: AxisSize::hug(0.0, w),
            height: AxisSize::hug(0.0, h),
            grow_x: Grow::No,
            grow_y: Grow::No,
        }
    }

    /// Both axes in the context-free vocabulary, leaving the declared fields untouched.
    /// 双轴的上下文无关形式，不改动声明字段。
    pub fn axes(self) -> (AxisSizes, AxisSizes) {
        (self.width.into(), self.height.into())
    }
}

/// How one grid item sits inside the cell it was given.
/// 网格项目在其单元格内的对齐方式。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Align {
    /// Fill the cell; a definite declared size still wins on that axis.
    /// 填满单元格；该轴上有确定声明尺寸时仍以声明为准。
    #[default]
    Stretch,
    Start,
    Center,
    End,
}

/// Positioning scheme; `Sticky` is not modelled yet.
/// 定位方案；暂不建模 `Sticky`。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Position {
    /// Takes its slot in the flow; insets are ignored.
    /// 在流内占位；内边距被忽略。
    #[default]
    Static,
    /// Keeps its slot, and shifts paint and hit by the insets.
    /// 保留原位置，仅按内边距平移绘制与命中。
    Relative,
    /// Leaves the flow; placed against its containing block.
    /// 脱离流；相对包含块定位。
    Absolute,
    /// Like `Absolute`, but the containing block is always the root box.
    /// 同 `Absolute`，但包含块固定为根盒子。
    Fixed,
}

/// Placement insets in author lengths, so `left: 50%` means half the containing block.
/// 以作者长度表达的定位内边距，`left: 50%` 即包含块的一半。
///
/// CSS resolves `left`/`right` against the containing block's width and `top`/`bottom`
/// against its height; [`resolve`](Self::resolve) does the same.
/// CSS 中 `left`/`right` 相对包含块宽度、`top`/`bottom` 相对其高度解析；
/// [`resolve`](Self::resolve) 采用同样的规则。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct LenInsets {
    pub left: Len,
    pub top: Len,
    pub right: Len,
    pub bottom: Len,
}

impl LenInsets {
    /// No side declared.
    /// 四边皆未声明。
    pub const AUTO: Self = Self {
        left: Len::Auto,
        top: Len::Auto,
        right: Len::Auto,
        bottom: Len::Auto,
    };

    pub const fn new(left: Len, top: Len, right: Len, bottom: Len) -> Self {
        Self {
            left,
            top,
            right,
            bottom,
        }
    }

    /// Resolve against a containing block size; an automatic or unresolvable edge is
    /// [`AUTO`]. 相对包含块尺寸解析；自动或无法解析的一侧取 [`AUTO`]。
    pub fn resolve(self, cb: crate::geom::Size) -> Insets {
        fn one(len: Len, avail: f32) -> f32 {
            match len {
                Len::Auto => AUTO,
                Len::Px(v) => v,
                Len::Pct(p) if avail.is_finite() => avail * p / 100.0,
                Len::Pct(_) => AUTO,
            }
        }
        Insets::new(
            one(self.left, cb.w),
            one(self.top, cb.h),
            one(self.right, cb.w),
            one(self.bottom, cb.h),
        )
    }
}

impl From<Insets> for LenInsets {
    /// A pixel inset keeps its numbers; an [`AUTO`] side stays undeclared.
    /// 像素内边距保留原值；[`AUTO`] 侧仍是未声明。
    fn from(inset: Insets) -> Self {
        fn one(v: f32) -> Len {
            if v.is_finite() {
                Len::Px(v)
            } else {
                Len::Auto
            }
        }
        Self::new(
            one(inset.left),
            one(inset.top),
            one(inset.right),
            one(inset.bottom),
        )
    }
}

/// Where a node sits: its scheme, insets and stacking order.
/// 节点的定位：方案、内边距与层叠顺序。
///
/// An inset side of [`Len::Auto`] is not declared, so the solver derives it from the
/// opposite side or from the static position.
/// 取 [`Len::Auto`] 的内边距一侧等于未声明，求解器由对侧或静态位置推出它。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Placement {
    pub position: Position,
    pub inset: LenInsets,
    /// Only a positioned node has an effective `z`; static children use 0.
    /// 只有定位节点有有效的 `z`；静态子节点按 0 计。
    pub z: i32,
    /// Set for an anchored overlay; the engine then places it from its anchor instead of
    /// from insets, and lets it escape every clipping ancestor.
    /// 锚定浮层在此声明；引擎据锚点而非内边距摆放它，并让它越过所有祖先裁剪。
    pub overlay: Option<OverlayPlacement>,
    /// Painted at the top layer and free of ancestor clips, but still holding its layout slot.
    /// 画在顶层且不受祖先裁剪，但仍占着自己的布局槽位。
    pub lift: bool,
}

impl Default for Placement {
    fn default() -> Self {
        Self {
            position: Position::Static,
            inset: LenInsets::AUTO,
            z: 0,
            overlay: None,
            lift: false,
        }
    }
}

/// When a row stops being a row: it stacks along its cross axis instead.
/// 一行何时不再是一行：改为沿交叉轴堆叠。
///
/// The decision is made while measuring, from the children's own sizes, so the container
/// still lays out in one pass. A stacked child reads its alternate margin, if it declared one.
/// 决定在测量时按子节点自身尺寸作出，容器因此仍是单趟布局。
/// 堆叠时子节点读它声明的替代外边距（若声明了）。
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct AxisSwitch {
    /// Stack once a child is taller than this, cross margin included: a line that already
    /// wrapped has broken the row, even if its wrapped width still fits.
    /// 子节点（含交叉轴外边距）高过此值即堆叠：已经换行的内容已经把行拆散，
    /// 哪怕换行后的宽度还放得下。
    pub max_cross: Option<f32>,
}

/// What an overlay hangs from: a node's box, or a point in the root's space.
/// 浮层挂在什么上：某个节点的盒子，或根空间里的一个点。
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum Anchor {
    Node(crate::Id),
    Point(crate::geom::Point),
}

/// Which edge of the anchor the panel unfolds from.
/// 面板从锚点的哪一边展开。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Side {
    Below,
    Above,
    Left,
    Right,
}

/// How the panel lines up with the anchor along the other axis.
/// 面板在另一条轴上与锚点如何对齐。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum OverlayAlign {
    Start,
    Center,
    End,
}

/// An anchored overlay: where it unfolds from, how far off, and what to do at an edge.
/// 锚定浮层：从何处展开、离开多远、到边缘时怎么办。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct OverlayPlacement {
    pub anchor: Anchor,
    pub side: Side,
    pub align: OverlayAlign,
    /// Gap between the anchor and the panel.
    /// 锚点与面板之间的间距。
    pub offset: f32,
    /// Flip to the opposite side when the panel would leave the viewport.
    /// 面板会越出视口时翻到对侧。
    pub flip: bool,
    /// Panel width follows the anchor's (menus, combo boxes).
    /// 面板宽度跟随锚点（菜单、下拉框）。
    pub match_anchor_width: bool,
    /// Panel height follows the anchor's (drawers, side panes that span their host).
    /// 面板高度跟随锚点（抽屉、与宿主同高的侧边窗格）。
    pub match_anchor_height: bool,
    /// The narrowest the panel may become when it matches the anchor (WinUI's
    /// `ComboBoxPopupThemeMinWidth`): a short trigger still gets a usable panel.
    /// 跟随锚点宽度时面板的最小宽度（WinUI 的 `ComboBoxPopupThemeMinWidth`）：
    /// 很窄的触发器仍能得到可用的面板。
    pub min_width: f32,
}

impl OverlayPlacement {
    /// A panel under `anchor`, left-aligned, no gap: the common menu shape.
    /// 锚点下方的面板，起点对齐、无间距：菜单最常见的形态。
    pub fn below(anchor: Anchor) -> Self {
        Self {
            anchor,
            side: Side::Below,
            align: OverlayAlign::Start,
            offset: 0.0,
            flip: true,
            match_anchor_width: false,
            match_anchor_height: false,
            min_width: 0.0,
        }
    }

    pub fn side(mut self, side: Side) -> Self {
        self.side = side;
        self
    }

    pub fn align(mut self, align: OverlayAlign) -> Self {
        self.align = align;
        self
    }

    pub fn offset(mut self, offset: f32) -> Self {
        self.offset = offset;
        self
    }

    pub fn match_anchor_width(mut self, on: bool) -> Self {
        self.match_anchor_width = on;
        self
    }

    pub fn flip(mut self, on: bool) -> Self {
        self.flip = on;
        self
    }

    pub fn match_anchor_height(mut self, on: bool) -> Self {
        self.match_anchor_height = on;
        self
    }

    pub fn min_width(mut self, width: f32) -> Self {
        self.min_width = width;
        self
    }
}

/// One grid track template.
/// 单条网格轨道模板。
#[derive(Clone, Debug, PartialEq)]
pub enum Track {
    /// Exact logical units.
    /// 精确逻辑单位。
    Fixed(f32),
    /// The largest max-content of the items on this track.
    /// 该轨道上项目的 max-content 最大值。
    Auto,
    /// Share of what fixed and auto tracks leave over.
    /// 固定与 auto 轨道剩下的空间里的一份。
    Fr(f32),
    /// Content contribution clamped into `[min, max]`; `Auto` defers to the content and
    /// an `Fr` upper bound takes a share of the space the other tracks leave over.
    /// 内容贡献被夹进 `[min, max]`；`Auto` 交给内容决定，`Fr` 上界分其它轨道剩下的空间。
    MinMax(TrackBound, TrackBound),
    /// The largest min-content of the items on this track.
    /// 该轨道上项目的 min-content 最大值。
    MinContent,
    /// The largest max-content of the items on this track.
    /// 该轨道上项目的 max-content 最大值。
    MaxContent,
    /// The inner track repeated; an auto repeat counts how many fit the space.
    /// 内层轨道重复；auto 重复按空间能容纳的条数计。
    Repeat(Repeat, Box<Track>),
}

/// One bound of a `minmax()` track: a length or a share of the free space.
/// `minmax()` 轨道的一侧边界：长度或剩余空间的一份。
///
/// A separate type because `Len` also sizes boxes and insets, where `fr` means nothing.
/// 单独一个类型：`Len` 也用于盒子尺寸与内边距，那里 `fr` 没有意义。
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum TrackBound {
    Len(Len),
    Fr(f32),
}

/// How many times a `Track::Repeat` repeats.
/// `Track::Repeat` 重复几次。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Repeat {
    /// A fixed count.
    /// 固定次数。
    Count(u16),
    /// As many as fit the space, keeping the empty ones.
    /// 空间能容纳多少就多少，空轨保留。
    AutoFill,
    /// Like `AutoFill`, then the tracks no item landed in collapse.
    /// 同 `AutoFill`，随后没有项目落入的轨道塌缩。
    AutoFit,
}

/// How items without a `grid_area` take free cells.
/// 没有 `grid_area` 的项目如何占用空格。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum AutoFlow {
    /// Fill row by row, left to right.
    /// 逐行铺，从左到右。
    #[default]
    Row,
    /// Fill column by column, top to bottom.
    /// 逐列铺，从上到下。
    Column,
    /// Row flow that backfills the first free cell instead of moving on.
    /// 按行铺，但回头填第一个空位而不是继续往后。
    RowDense,
    /// Column flow that backfills the first free cell instead of moving on.
    /// 按列铺，但回头填第一个空位而不是继续往后。
    ColumnDense,
}

impl AutoFlow {
    /// Whether the primary axis is the row axis.
    /// 主轴是否为行轴。
    pub fn rows_first(self) -> bool {
        matches!(self, AutoFlow::Row | AutoFlow::RowDense)
    }

    /// Whether an item scans from the grid origin instead of the cursor.
    /// 项目是否从网格原点重新扫描，而不是沿游标前进。
    pub fn dense(self) -> bool {
        matches!(self, AutoFlow::RowDense | AutoFlow::ColumnDense)
    }
}

/// A grid container's track template.
/// 网格容器的轨道模板。
#[derive(Clone, Debug, PartialEq)]
pub struct TrackList {
    pub cols: Vec<Track>,
    pub rows: Vec<Track>,
    pub auto_flow: AutoFlow,
}

/// Where an item sits in its parent grid: 0-based row and column plus spans.
/// 项目在父网格里的位置：0 起的行列与跨度。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct GridArea {
    pub row: u32,
    pub col: u32,
    pub row_span: u32,
    pub col_span: u32,
}

/// Box edges a node reserves around its content.
/// 节点在内容周围保留的盒边距。
///
/// A declared size is a border box, unlike CSS's default `content-box`; a border paints inside
/// that box as a stroke, so it takes no layout space. There is no border or box-sizing field.
/// 声明尺寸是边框盒，不同于 CSS 默认的 `content-box`；边框以描边画在盒内，不占布局空间。
/// 因此没有 border 与 box-sizing 字段。
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct BoxModel {
    /// Outside the border box; may be negative. Only shifts placement.
    /// 边框盒之外；可为负。只影响摆放。
    pub margin: crate::geom::Insets,
    /// The margin a flow parent uses when it stacked along its cross axis instead.
    /// 流父容器改为沿交叉轴堆叠时使用的边距。
    pub margin_alt: Option<crate::geom::Insets>,
    pub padding: crate::geom::Insets,
}

/// What one container does with content that does not fit its box.
/// 一个容器如何对待装不下的内容。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum Overflow {
    /// Content paints outside the box; this container contributes no clip.
    /// 内容画到盒子之外；本容器不贡献裁剪。
    #[default]
    Visible,
    /// Content is cut at the box.
    /// 内容在盒子处被切掉。
    Hidden,
    /// Like `Hidden`, and the wheel may move the content inside the box.
    /// 同 `Hidden`，且滚轮可以在盒子内移动内容。
    Scroll,
}

/// Per-axis overflow policy of one container; clipping is opt-in.
/// 单个容器逐轴的溢出策略；裁剪需显式声明。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct Clip {
    pub x: Overflow,
    pub y: Overflow,
}

impl Clip {
    pub const VISIBLE: Self = Self {
        x: Overflow::Visible,
        y: Overflow::Visible,
    };

    /// Whether either axis cuts content.
    /// 是否至少有一个轴会裁切内容。
    pub fn clips(self) -> bool {
        self.x != Overflow::Visible || self.y != Overflow::Visible
    }

    /// Whether the wheel may move this container's content.
    /// 滚轮是否可以移动本容器的内容。
    pub fn scrolls(self) -> bool {
        self.x == Overflow::Scroll || self.y == Overflow::Scroll
    }
}

/// Constraints handed down by a parent: `min` is a hard lower bound and `max` is the
/// offered space; content larger than `max` overflows instead of shrinking below `min`.
/// 父容器向下传递的约束：`min` 是硬下限，`max` 是给出的空间；内容大于 `max` 时溢出，
/// 而不会压到 `min` 以下。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Constraints {
    pub min: crate::geom::Size,
    pub max: crate::geom::Size,
}

impl Constraints {
    /// Exactly `size`: `min == max == size`.
    /// 精确尺寸：`min == max == size`。
    pub const fn tight(size: crate::geom::Size) -> Self {
        Self {
            min: size,
            max: size,
        }
    }

    /// At most `max`: the floor is zero, so any smaller size is allowed.
    /// 至多 `max`：下限为零，因此任何更小的尺寸都允许。
    pub const fn loose(max: crate::geom::Size) -> Self {
        Self {
            min: crate::geom::Size::ZERO,
            max,
        }
    }
}

/// What one measurement call reports: the used size plus its intrinsic contributions.
/// 一次测量调用报告的内容：实际尺寸与内在贡献。
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct MeasureResult {
    pub size: crate::geom::Size,
    /// The narrowest the node can get without breaking its content.
    /// 内容不被破坏时节点能取到的最小尺寸。
    pub min_content: crate::geom::Size,
    /// The size the node takes when nothing constrains it.
    /// 不受约束时节点会取的尺寸。
    pub max_content: crate::geom::Size,
    /// First baseline; 0 until the inline pass reports one (P4).
    /// 首基线；行内那一趟（P4）报告之前为 0。
    pub baseline: f32,
}

/// A node's cached measurement, valid only while its constraints and subtree stay put.
/// 节点的测量缓存，仅在约束与子树都不变时有效。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct LastMeasure {
    pub constraints: Constraints,
    pub result: MeasureResult,
}

/// Statistics returned by a layout pass, used by tests and diagnostics.
/// 布局一趟返回的统计，供测试与诊断。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct LayoutStats {
    /// How many nodes were measured this pass.
    /// 本趟 measure 的节点数。
    pub measured: usize,
    /// How many of them were actually measured instead of served from the cache.
    /// 其中真正做了测量、而非取自缓存的节点数。
    pub remeasured: usize,
}

/// Pluggable layout engine.
/// 可插拔的布局引擎。
///
/// The built-in engine is a single deterministic measure pass (no second pass,
/// no `request_discard`-style retry). A taffy-backed engine can be added later
/// behind a feature flag.
/// 内置引擎是单趟确定性 measure（无第二趟、无 `request_discard` 式重跑）。
/// 将来可在 feature 后面加一个 taffy 后端。
pub trait LayoutEngine {
    /// Solve the tree's layout, writing each node's rect.
    /// 解算整棵树的布局，写入每个节点的矩形。
    fn solve(&mut self, tree: &mut crate::tree::Tree, root: NodeIdLocal, constraints: Constraints)
        -> LayoutStats;

    /// Whether this engine can solve only dirty subtrees.
    /// 是否只解算脏子树。
    fn supports_incremental(&self) -> bool {
        false
    }
}

// Local alias so this module does not force a tree import in doc examples.
// 本地别名，避免文档示例里强行导入 tree。
pub use crate::id::NodeId as NodeIdLocal;

/// Helper: the rect a child gets inside a parent's content box.
/// 辅助：子节点在父内容盒内得到的矩形。
pub fn place(parent_content: Rect, size: crate::geom::Size) -> Rect {
    Rect::from_origin_size(parent_content.origin, size)
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Hug and fill must no longer be byte-identical: one fits content, one stretches.
    /// 「适应内容」与「跟随父」不能再字节相同：一个贴合内容，一个撑满父给出的空间。
    #[test]
    fn hug_and_fill_choose_different_sizing() {
        let hug: AxisSizes = AxisSize::hug(0.0, 0.0).into();
        let fill: AxisSizes = AxisSize::fill(0.0, 0.0).into();
        assert_eq!(hug.size, Sizing::Fit);
        assert_eq!(fill.size, Sizing::Stretch);
        assert_ne!(hug, fill);
    }
}
