//! Target-driven animation. Time is fed in from outside, never read from a clock.
//! 目标驱动的动画。时间由外部喂入，从不读时钟。

use crate::collections::FastMap;

use crate::id::Id;

/// How a value travels between two ends.
/// 值在两端之间如何行进。
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub enum Easing {
    /// Constant speed.
    /// 匀速。
    Linear,
    /// Fast start, slow finish; the default when entering a state.
    /// 快起慢收；进入某状态的默认。
    #[default]
    EaseOut,
    /// Slow start, fast finish.
    /// 慢起快收。
    EaseIn,
    /// Slow at both ends.
    /// 两端都慢。
    EaseInOut,
    /// CSS-style cubic bezier with the two implied endpoints (0,0) and (1,1).
    /// CSS 风格的三次贝塞尔，隐含两端 (0,0) 与 (1,1)。
    Cubic(f32, f32, f32, f32),
    /// Two cubics sharing one midpoint; a single cubic cannot express Material's
    /// emphasized family, which is piecewise by spec.
    /// 两段共享中点的三次曲线；单条 cubic 表达不了规范里分段的 emphasized 家族。
    Piece(&'static PieceCubic),
}

/// Two cubic segments joined at `mid`; tangents are the control lines at each end.
/// 两段三次曲线在 `mid` 相接；两端切线即各自的控制线。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct PieceCubic {
    pub a1: (f32, f32),
    pub b1: (f32, f32),
    pub mid: (f32, f32),
    pub a2: (f32, f32),
    pub b2: (f32, f32),
}

impl Easing {
    /// Map progress `t` in `0..=1` to eased progress.
    /// 把 0..=1 的进度映射为缓动后的进度。
    pub fn apply(self, t: f32) -> f32 {
        let t = t.clamp(0.0, 1.0);
        match self {
            Easing::Linear => t,
            Easing::EaseOut => 1.0 - (1.0 - t).powi(3),
            Easing::EaseIn => t.powi(3),
            Easing::EaseInOut => {
                if t < 0.5 {
                    4.0 * t.powi(3)
                } else {
                    1.0 - (-2.0 * t + 2.0).powi(3) / 2.0
                }
            }
            Easing::Cubic(a, b, c, d) => solve_cubic(t, a, b, c, d),
            Easing::Piece(p) => p.apply(t),
        }
    }

    /// The curve to use when the value turns around mid-flight.
    /// 值中途掉头时应使用的曲线。
    ///
    /// Same curve after a reversal starts at near-zero speed and looks stuck.
    /// 掉头后沿用同一曲线会以近乎零速起步，看起来像卡住了。
    pub fn mirrored(self) -> Self {
        match self {
            Easing::EaseOut => Easing::EaseIn,
            Easing::EaseIn => Easing::EaseOut,
            Easing::Cubic(a, b, c, d) => Easing::Cubic(1.0 - c, 1.0 - d, 1.0 - a, 1.0 - b),
            other => other,
        }
    }
}

impl PieceCubic {
    /// Evaluate: pick the segment by `x`, rescale it to the unit square, ease, scale back.
    /// 按 `x` 选段，把该段归一到单位正方形求值，再缩放回去。
    pub fn apply(&self, t: f32) -> f32 {
        if t <= 0.0 {
            return 0.0;
        }
        if t >= 1.0 {
            return 1.0;
        }
        let (first, sx, sy, base) = if t < self.mid.0 {
            (true, self.mid.0, self.mid.1, 0.0)
        } else {
            (false, 1.0 - self.mid.0, 1.0 - self.mid.1, self.mid.1)
        };
        let local = (t - if first { 0.0 } else { self.mid.0 }) / sx;
        let (p1, p2) = if first {
            ((self.a1.0 / sx, self.a1.1 / sy), (self.b1.0 / sx, self.b1.1 / sy))
        } else {
            (
                ((self.a2.0 - self.mid.0) / sx, (self.a2.1 - self.mid.1) / sy),
                ((self.b2.0 - self.mid.0) / sx, (self.b2.1 - self.mid.1) / sy),
            )
        };
        solve_cubic(local, p1.0, p1.1, p2.0, p2.1) * sy + base
    }
}

/// CSS cubic-bezier evaluation: bisect the parameter for `x`, then read `y`.
/// CSS cubic-bezier 求值：二分求参数使 x 命中，再读 y。
fn solve_cubic(t: f32, a: f32, b: f32, c: f32, d: f32) -> f32 {
    if t <= 0.0 {
        return 0.0;
    }
    if t >= 1.0 {
        return 1.0;
    }
    let eval = |u: f32, v: f32, m: f32| 3.0 * u * (1.0 - m) * (1.0 - m) * m + 3.0 * v * (1.0 - m) * m * m + m * m * m;
    // 40 halvings take the 1.0 interval under any 0.001 bound; the reference loops forever.
    // 40 次对半已把 1.0 区间压到任意 0.001 界以下；参考实现是无限循环。
    let (mut start, mut stop) = (0.0f32, 1.0f32);
    for _ in 0..40 {
        let midpoint = (start + stop) / 2.0;
        let estimate = eval(a, c, midpoint);
        if (t - estimate).abs() < 0.001 {
            return eval(b, d, midpoint);
        }
        if estimate < t {
            start = midpoint;
        } else {
            stop = midpoint;
        }
    }
    eval(b, d, (start + stop) / 2.0)
}

/// How long and along which curve a value travels.
/// 值行进的时长与曲线。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct AnimSpec {
    pub duration: f32,
    pub easing: Easing,
    /// Held at the leg's start for this long before the curve begins.
    /// 曲线开始前，值在段起点停留的时长。
    pub delay: f32,
    /// The leg used when the value travels *down*; `None` reuses this one.
    /// 值**下行**时使用的一段；为 `None` 则沿用本段。
    pub down: Option<Reverse>,
    /// The value range this instance spans, so a partial retarget takes a proportional
    /// slice of the duration. `None` keeps the previous leg's distance as the unit, which
    /// is what a per-frame drag follow wants.
    /// 本实例覆盖的值域，使部分重定向只走按比例的一段时长。`None` 仍以上一段的距离为
    /// 单位，这是逐帧拖拽跟随所需的。
    pub span: Option<f32>,
}

/// A downward leg: a shorter, differently-curved trip back.
/// 下行的一段：回程更短，曲线也可以不同。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Reverse {
    pub duration: f32,
    pub easing: Easing,
}

impl AnimSpec {
    pub const fn new(duration: f32, easing: Easing) -> Self {
        Self {
            duration,
            easing,
            delay: 0.0,
            down: None,
            span: None,
        }
    }

    /// Declare the value range this instance spans; a retarget then takes a proportional
    /// slice of the duration instead of a slice of the previous leg.
    /// 声明本实例覆盖的值域；重定向因此取时长的一段，而不是上一段距离的一段。
    pub const fn span(mut self, span: f32) -> Self {
        self.span = Some(span);
        self
    }

    /// Travel down with its own duration and curve, instead of mirroring this leg.
    /// 下行时使用自己的时长与曲线，而不是镜像本段。
    pub const fn down(self, duration: f32, easing: Easing) -> Self {
        Self {
            down: Some(Reverse { duration, easing }),
            ..self
        }
    }

    /// The same leg, starting `delay` seconds later; the engine holds the value meanwhile.
    /// 同一段行程，延后 `delay` 秒开始；期间引擎把值停在起点。
    pub const fn delayed(self, delay: f32) -> Self {
        Self { delay, ..self }
    }

    /// A short, snappy default: 150 ms ease-out.
    /// 短促的默认值：150 毫秒 ease-out。
    pub const fn quick() -> Self {
        Self::new(0.15, Easing::EaseOut)
    }

    /// The same travel back: mirror the curve so reversal starts at the end's slope.
    /// 回程走同样的时长：曲线取镜像，反向才能从终点斜率起步。
    pub fn mirrored(&self) -> Self {
        Self {
            easing: self.easing.mirrored(),
            ..*self
        }
    }
}

impl Default for AnimSpec {
    fn default() -> Self {
        Self::quick()
    }
}

/// One keyframe: a value reached at `at` (a fraction of the leg's duration), with the curve
/// that carries the value into it.
/// 一个关键帧：在段时长的 `at` 比例处到达 `value`，`easing` 是把值带进它的曲线。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Stop {
    pub at: f32,
    pub value: f32,
    pub easing: Easing,
}

impl Stop {
    pub const fn new(at: f32, value: f32, easing: Easing) -> Self {
        Self { at, value, easing }
    }
}

/// Keyframes an instance can hold; enough for a squash phase plus a settle.
/// 一个实例能持有的关键帧数；足够「形变 + 落定」两段使用。
pub const MAX_STOPS: usize = 4;

fn colour_of(lanes: [f32; 4]) -> crate::geom::Color {
    crate::geom::Color {
        r: lanes[0],
        g: lanes[1],
        b: lanes[2],
        a: lanes[3],
    }
}

/// One value in flight.
/// 一个在途的值。
#[derive(Clone, Copy, Debug, PartialEq)]
struct Entry {
    /// Channel values; only the first `lanes` are meaningful.
    /// 各通道的值；只有前 `lanes` 个有意义。
    from: [f32; 4],
    to: [f32; 4],
    /// 1 for a scalar, 4 for a colour. Every lane shares one clock, so the channels of a
    /// colour never desync.
    /// 标量为 1，颜色为 4。所有通道共用一个时钟，因此颜色的各通道不会脱节。
    lanes: u8,
    /// When this leg's target was committed, in the engine's seconds. Progress is
    /// `now - committed_at`, so nothing accumulates and no clock is read here.
    /// 本段目标被提交的时刻，引擎秒。进度即 `now - committed_at`，
    /// 因此不累加，这里也不读时钟。
    committed_at: f64,
    duration: f32,
    easing: Easing,
    delay: f32,
    /// Keyframes for this leg; empty means a plain tween from `from` to `to`.
    /// 本段的关键帧；为空表示从 `from` 到 `to` 的普通补间。
    stops: [Stop; MAX_STOPS],
    stop_count: u8,
    /// Goal before the last turn; `None` if it never turned.
    /// 上次掉头前的目标；从未掉头则为 `None`。
    previous_target: Option<f32>,
}

impl Entry {
    fn progress(&self, now: f64) -> f32 {
        let start = self.committed_at + self.delay.max(0.0) as f64;
        if self.duration <= 0.0 {
            // A zero-duration leg is a write: it lands as soon as its delay is over.
            // 零时长的一段就是一次写入：延迟一过就落地。
            return if now < start { 0.0 } else { 1.0 };
        }
        // A retarget samples its own start; that frame shows the value it left, not a jump.
        // 重定向采样的就是起点；那一帧显示的是离开时的值，而不是一次跳变。
        if now <= start {
            return 0.0;
        }
        let elapsed = now - start;
        if !elapsed.is_finite() {
            // A non-finite timestamp must not poison every value it touches.
            // 非有限的时间戳不得污染它碰到的每个值。
            return self.progress_at_rest();
        }
        // A clock that stepped backwards holds the value rather than rewinding it.
        // 时钟倒退时保持当前值，而不是倒带。
        (elapsed.max(0.0) as f32 / self.duration).clamp(0.0, 1.0)
    }

    /// All lanes at `now`; every lane shares this leg's clock.
    /// `now` 时刻的全部通道；所有通道共用本段的时钟。
    fn lanes_at(&self, now: f64) -> [f32; 4] {
        let t = self.progress(now);
        let mut out = self.from;
        if self.stop_count == 0 {
            let eased = self.easing.apply(t);
            for i in 0..self.lanes as usize {
                out[i] = self.from[i] + (self.to[i] - self.from[i]) * eased;
            }
            return out;
        }
        // Keyframes describe one channel; a colour never carries them.
        // 关键帧只描述一个通道；颜色不会带关键帧。
        let mut prev_at = 0.0;
        let mut prev = self.from[0];
        for stop in &self.stops[..self.stop_count as usize] {
            if t <= stop.at {
                let span = (stop.at - prev_at).max(1e-6);
                let k = stop.easing.apply((t - prev_at) / span);
                out[0] = prev + (stop.value - prev) * k;
                return out;
            }
            prev_at = stop.at;
            prev = stop.value;
        }
        out[0] = prev;
        out
    }

    fn value(&self, now: f64) -> f32 {
        self.lanes_at(now)[0]
    }

    /// Progress with no usable clock: the leg is treated as finished.
    /// 没有可用时钟时的进度：本段视为已完成。
    fn progress_at_rest(&self) -> f32 {
        1.0
    }

    fn settled(&self, now: f64) -> bool {
        self.progress(now) >= 1.0
    }
}

/// Which way one instance is travelling.
/// 一个实例正在往哪边走。
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum Travel {
    /// The value is heading up.
    /// 值在上升。
    #[default]
    Forward,
    /// The value is heading down.
    /// 值在下降。
    Reverse,
}

/// One instance's state, read-only.
/// 单个实例的状态，只读。
///
/// `leg_start` is the value the last retarget sampled, which is what a family needs to
/// freeze a derived quantity for the duration of one leg.
/// `leg_start` 是上次重定向采样到的值，家族据此在本段行程内冻结派生量。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Status {
    pub value: f32,
    pub target: f32,
    pub leg_start: f32,
    pub travel: Travel,
    pub settled: bool,
}

impl Default for Status {
    fn default() -> Self {
        Self {
            value: 0.0,
            target: 0.0,
            leg_start: 0.0,
            travel: Travel::Forward,
            settled: true,
        }
    }
}

/// One spring's state at this frame, in the engine's own units.
/// 一个弹簧在本帧的状态，使用引擎自己的单位。
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct SpringState {
    /// Position, in the target's units.
    /// 位置，单位与目标相同。
    pub x: f32,
    /// Velocity in units per second.
    /// 速度，单位/秒。
    pub v: f32,
}

/// A spring integrated in engine seconds, so a dropped frame covers the same time as four
/// on-time ones instead of slowing the motion down.
/// 按引擎秒积分的弹簧：掉一帧与准时的四帧走过的时间相同，动作不会因此变慢。
#[derive(Clone, Copy, Debug)]
struct SpringEntry {
    /// Simulated in f64: at a page-scale coordinate one f32 ulp is 1.2e-4, wider than the
    /// settle tolerance, so an f32 integrator parks there for ever.
    /// 以 f64 仿真：页面尺度的坐标上一个 f32 ulp 就有 1.2e-4，比落定容差还宽，
    /// f32 积分器会永远停在那里。
    x: f64,
    v: f64,
    target: f64,
    stiffness: f64,
    damping: f64,
    last: f64,
    /// When this entry was created; a tiny age means something re-creates it every frame.
    /// 这条记录诞生的时刻；年龄极小说明有人每帧都在重建它。
    born: f64,
    /// A target set since the last integration: it has something to do, even at zero dt.
    /// 自上次积分以来被改过目标：即使 dt 为零，它也有事可做。
    pending: bool,
    /// Distance covered in the frame being reported, so "live" never outlives real motion.
    /// 本次上报的这一帧里走过的距离，"运动中"因此不会比真实位移活得更久。
    moved: f32,
    /// Per-frame tallies: who drove it, whether it integrated, and with what step.
    /// 每帧计数：谁驱动了它、是否真的积分、步长多少。
    drives: u32,
    steps: u32,
    adv: u32,
    dt: f32,
}

/// How close counts as arrived: Flutter's `Tolerance.defaultTolerance`, both axes.
/// 多近算到位：两个分量都取 Flutter 的 `Tolerance.defaultTolerance`。
///
/// One pair of numbers for the whole engine: a second, looser threshold anywhere would end
/// a motion while its spring still reports movement.
/// 全引擎只此一对数字：别处再用一个更松的阈值，就会在弹簧仍报运动时结束运动。
const SPRING_SETTLED_DISTANCE: f32 = 1e-3;
const SPRING_SETTLED_SPEED: f32 = 1e-3;
/// Substep bound: semi-implicit Euler is stable here for any stiffness a control uses.
/// 子步上限：任何控件会用的刚度下，半隐式欧拉在此步长都稳定。
const SPRING_MAX_STEP: f32 = 1.0 / 240.0;
/// A long stall integrates one bounded slice, so the spring cannot explode.
/// 长时间停顿时只积分一个有界片段，弹簧因此不会爆炸。
const SPRING_MAX_DT: f32 = 0.1;

impl SpringEntry {
    fn live(&self) -> bool {
        (self.x - self.target).abs() > SPRING_SETTLED_DISTANCE as f64
            || self.v.abs() > SPRING_SETTLED_SPEED as f64
    }

    /// Integrate one slice with semi-implicit Euler, substepped so any stiffness is stable.
    /// 用半隐式欧拉积分一段，并分步执行，任何刚度都稳定。
    fn step(&mut self, dt: f32) {
        let before = self.x;
        let steps = (dt / SPRING_MAX_STEP).ceil().max(1.0) as u32;
        let h = (dt / steps as f32) as f64;
        for _ in 0..steps {
            let a = self.stiffness * (self.target - self.x) - self.damping * self.v;
            self.v += a * h;
            self.x += self.v * h;
        }
        // Rest is exact, not merely small: `is_animating` must stop the frame loop.
        // 静止是精确的，而不只是"很小"：`is_animating` 要能停下帧循环。
        if !self.live() {
            self.x = self.target;
            self.v = 0.0;
        }
        self.moved += (self.x - before).abs() as f32;
        self.steps += 1;
        self.pending = false;
    }
}

/// One animation still in flight, as a diagnostic reads it.
/// 仍在进行的一次动画，供诊断读取。
#[derive(Clone, Copy, Debug)]
pub enum Moving {
    /// A tween: `progress` below 1 is what keeps the loop awake.
    /// 一段补间：`progress` 未到 1 才会让循环继续。
    Tween {
        id: Id,
        progress: f32,
        duration: f32,
        delay: f32,
    },
    /// A spring: it is live while it is away from `target` or still fast.
    /// 一条弹簧：偏离 `target` 或仍有速度即为运动中。
    Spring {
        id: Id,
        x: f32,
        v: f32,
        target: f32,
        /// Seconds since anything last advanced it; zero means it is being touched every frame.
        /// 距上次被推进的秒数；为零说明每帧都有人碰它。
        idle: f32,
        /// Seconds since this entry was created; near zero means it is rebuilt every frame.
        /// 这条记录诞生至今的秒数；接近零说明它每帧都在被重建。
        age: f32,
        /// Distance covered in the last frame: zero while "live" means nothing advanced it.
        /// 上一帧走过的距离：仍是"运动中"却为零，说明没人推进它。
        moved: f32,
        /// Whether it still keeps the frame loop awake.
        /// 它是否仍在唤醒帧循环。
        awake: bool,
        /// This frame's tallies: driver calls, integrations, scheduler visits, last step.
        /// 本帧计数：驱动次数、积分次数、调度器访问次数、最后的步长。
        drives: u32,
        steps: u32,
        adv: u32,
        dt: f32,
    },
}

impl Moving {
    pub fn id(&self) -> Id {
        match self {
            Moving::Tween { id, .. } | Moving::Spring { id, .. } => *id,
        }
    }
}

impl std::fmt::Display for Moving {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Moving::Tween {
                id,
                progress,
                duration,
                delay,
            } => write!(f, "tween {id:?} progress={progress:.4} duration={duration} delay={delay}"),
            Moving::Spring {
                id,
                x,
                v,
                target,
                idle,
                age,
                moved,
                awake,
                drives,
                steps,
                adv,
                dt,
            } => write!(
                f,
                "spring {id:?} x={x:.4} v={v:.4} target={target} idle={idle:.4} age={age:.3} moved={moved:.1e} awake={awake} drive={drives} step={steps} adv={adv} dt={dt:.1e}"
            ),
        }
    }
}

/// Every animation the current frame is running.
/// 当前帧正在运行的动画。
#[derive(Debug, Default)]
pub struct AnimStore {
    entries: FastMap<Id, Entry>,
    springs: FastMap<Id, SpringEntry>,
    /// When each time-driven id was first seen, so a loop can start at phase zero.
    /// 每个时间驱动 id 首次出现的时间，使循环从相位零起步。
    births: FastMap<Id, f64>,
}

impl AnimStore {
    pub fn new() -> Self {
        Self::default()
    }

    /// Drive the value at `id` toward `target`; returns what to draw this frame.
    /// 把 `id` 处的值推向 `target`；返回本帧应绘制的值。
    ///
    /// First call settles at `target`: a value never animated has nowhere to travel from.
    /// 首次调用直接落在 `target`：从未动画过的值没有可出发的地方。
    pub fn animate(&mut self, id: Id, target: f32, spec: AnimSpec, now: f64) -> f32 {
        let Some(entry) = self.entries.get_mut(&id) else {
            self.entries.insert(
                id,
                Entry {
                    from: [target; 4],
                    to: [target; 4],
                    lanes: 1,
                    // Back-dated by one full duration: a value with nowhere to travel from
                    // is already there, so it must not animate.
                    // 往回拨整个时长：没有可出发之处的值本来就在终点，不该再有动画。
                    committed_at: now - spec.duration.max(0.0) as f64,
                    duration: spec.duration.max(0.0),
                    easing: spec.easing,
                    delay: spec.delay,
                    stops: [Stop::new(0.0, target, Easing::Linear); MAX_STOPS],
                    stop_count: 0,
                    previous_target: None,
                },
            );
            return target;
        };

        if entry.to[0] == target {
            if entry.stop_count > 0 {
                // A plain tween was asked for while keyframes were still running: re-anchor
                // from the current value, or the old trajectory would keep driving the value
                // (it can travel away from the target before coming back).
                // 关键帧还在跑时要求普通补间：从当前值重新起一段，否则旧轨迹会继续驱动这个值
                //（它可能先远离目标再回来）。
                let current = entry.value(now);
                entry.from = [current; 4];
                entry.committed_at = now;
                entry.duration = spec.duration.max(0.0);
                entry.easing = spec.easing;
                entry.delay = spec.delay;
                entry.stop_count = 0;
            }
            return entry.value(now);
        }

        // Retarget from the current value; starting from `entry.to` would jump.
        // 从当前值重定向；从 `entry.to` 开始会跳变。
        let current = entry.value(now);
        let turning_around = match entry.previous_target {
            Some(before) => (target - before).abs() < f32::EPSILON,
            None => (target - entry.from[0]).abs() < (target - entry.to[0]).abs(),
        };
        let easing = if turning_around && entry.previous_target.is_none() {
            entry.easing.mirrored()
        } else {
            entry.easing
        };
        // A shorter remaining distance takes proportionally less time. The unit is the
        // declared span when there is one; otherwise it is the previous leg, which is what
        // keeps a per-frame drag follow at a constant lag. A settled instance is not being
        // interrupted, so its next leg takes the declared time whatever the last one spanned.
        // 剩余距离更短就用更短的时间。单位是声明的值域（若有）；否则是上一段，这正是
        // 逐帧拖拽跟随保持恒定滞后的原因。已落定的实例不算被打断，下一段仍用声明时长。
        let total = (entry.to[0] - entry.from[0]).abs();
        let remaining = (target - current).abs();
        let fraction = match spec.span {
            Some(span) if span > 0.0 => (remaining / span).clamp(0.05, 1.0),
            _ if total > f32::EPSILON && !entry.settled(now) => (remaining / total).clamp(0.05, 1.0),
            _ => 1.0,
        };

        // A downward leg may carry its own duration and curve, so a control never has to
        // pick a spec by direction itself.
        // 下行的一段可以自带时长与曲线，控件因此不必按方向自己挑 spec。
        let (leg_duration, leg_easing) = match spec.down {
            Some(down) if target < current => (down.duration, down.easing),
            _ => (spec.duration, easing),
        };
        entry.previous_target = Some(entry.to[0]);
        entry.from = [current; 4];
        entry.to = [target; 4];
        entry.committed_at = now;
        entry.duration = (leg_duration * fraction).max(0.0);
        entry.easing = leg_easing;
        entry.delay = spec.delay;
        // A retarget abandons the old keyframes: the new leg is a plain tween.
        // 重定向放弃旧的关键帧：新的一段是普通补间。
        entry.stop_count = 0;
        entry.value(now)
    }

    /// Drive an instance along keyframes; the last stop is the target.
    /// 沿关键帧推进一个实例；最后一个关键帧就是目标。
    ///
    /// A fresh instance starts already settled at the last stop, so the first frame shows
    /// the state it is in rather than animating from nowhere.
    /// 新实例一开始就停在最后一个关键帧上，因此第一帧显示的是当前状态，而不是从虚空里动。
    pub fn animate_stops(
        &mut self,
        id: Id,
        stops: &[Stop],
        spec: AnimSpec,
        now: f64,
    ) -> f32 {
        let n = stops.len().min(MAX_STOPS);
        let Some(last) = stops.get(n.wrapping_sub(1)) else {
            return self.animate(id, 0.0, spec, now);
        };
        let target = last.value;
        let mut buf = [Stop::new(0.0, target, Easing::Linear); MAX_STOPS];
        buf[..n].copy_from_slice(&stops[..n]);
        let Some(entry) = self.entries.get_mut(&id) else {
            self.entries.insert(
                id,
                Entry {
                    from: [target; 4],
                    to: [target; 4],
                    lanes: 1,
                    committed_at: now
                        - spec.duration.max(0.0) as f64
                        - spec.delay.max(0.0) as f64,
                    duration: spec.duration.max(0.0),
                    easing: spec.easing,
                    delay: spec.delay,
                    stops: buf,
                    stop_count: n as u8,
                    previous_target: None,
                },
            );
            return target;
        };
        if entry.to[0] == target {
            // Same destination: keep the value continuous but refresh the shape, because
            // the stops may carry state-resolved values (a latched end, say).
            // 目标相同：值保持连续，但形状要刷新，因为关键帧里可能有随状态解析的值（如锁存端）。
            entry.stops = buf;
            entry.stop_count = n as u8;
            entry.delay = spec.delay;
            return entry.value(now);
        }
        let current = entry.value(now);
        entry.previous_target = Some(entry.to[0]);
        entry.from = [current; 4];
        entry.to = [target; 4];
        entry.committed_at = now;
        entry.duration = spec.duration.max(0.0);
        entry.easing = spec.easing;
        entry.delay = spec.delay;
        entry.stops = buf;
        entry.stop_count = n as u8;
        entry.value(now)
    }

    /// Drive a colour; all four channels share one clock, so they never desync.
    /// 推进一个颜色；四条通道共用一个时钟，因此不会脱节。
    ///
    /// The control resolves the colour its state calls for; the engine carries the blend.
    /// 控件只解析状态对应的颜色，过渡由引擎负责。
    pub fn animate_colour(
        &mut self,
        id: Id,
        target: crate::geom::Color,
        spec: AnimSpec,
        now: f64,
    ) -> crate::geom::Color {
        let to = [target.r, target.g, target.b, target.a];
        let Some(entry) = self.entries.get_mut(&id) else {
            self.entries.insert(
                id,
                Entry {
                    from: to,
                    to,
                    lanes: 4,
                    committed_at: now
                        - spec.duration.max(0.0) as f64
                        - spec.delay.max(0.0) as f64,
                    duration: spec.duration.max(0.0),
                    easing: spec.easing,
                    delay: spec.delay,
                    stops: [Stop::new(0.0, 0.0, Easing::Linear); MAX_STOPS],
                    stop_count: 0,
                    previous_target: None,
                },
            );
            return target;
        };
        if entry.to == to && entry.lanes == 4 {
            return colour_of(entry.lanes_at(now));
        }
        let current = entry.lanes_at(now);
        // The clock is set by the channel that has the furthest to go.
        // 时钟由行程最远的那个通道决定。
        let interrupted = !entry.settled(now);
        let mut remaining_max = 0.0f32;
        let mut ratio_max = 0.0f32;
        for i in 0..4 {
            let total = (entry.to[i] - entry.from[i]).abs();
            let remaining = (to[i] - current[i]).abs();
            remaining_max = remaining_max.max(remaining);
            if total > f32::EPSILON && interrupted {
                ratio_max = ratio_max.max((remaining / total).clamp(0.05, 1.0));
            }
        }
        // A declared span scales by the furthest channel's distance; without one the
        // previous leg stays the unit. A settled instance is not interrupted, so it takes
        // the full leg whatever the last one spanned.
        // 声明了值域就按最远通道的距离缩放；否则仍以上一段为单位。
        // 已落定的实例不算被打断，无论上一段跨度多大都走整段。
        let fraction = match spec.span {
            Some(span) if span > 0.0 => (remaining_max / span).clamp(0.05, 1.0),
            _ if ratio_max > 0.0 => ratio_max,
            _ => 1.0,
        };
        entry.previous_target = Some(entry.to[0]);
        entry.from = current;
        entry.to = to;
        entry.lanes = 4;
        entry.committed_at = now;
        entry.duration = (spec.duration * fraction).max(0.0);
        entry.easing = spec.easing;
        entry.delay = spec.delay;
        entry.stop_count = 0;
        colour_of(entry.lanes_at(now))
    }

    /// Current colour, or `None` if this id was never animated as one.
    /// 当前颜色；该 id 从未作为颜色动画过则为 `None`。
    pub fn colour(&self, id: Id, now: f64) -> Option<crate::geom::Color> {
        let e = self.entries.get(&id)?;
        (e.lanes == 4).then(|| colour_of(e.lanes_at(now)))
    }

    /// Current value, or `None` if this id has never been animated.
    /// 当前值；该 id 从未动画过则为 `None`。
    pub fn value(&self, id: Id, now: f64) -> Option<f32> {
        self.entries.get(&id).map(|e| e.value(now))
    }

    /// Start a value at `from` and drive it to `target`; a value already tracked just moves.
    /// 让一个值从 `from` 出发驶向 `target`；已被跟踪的值只做重定向。
    ///
    /// Unlike [`animate`](Self::animate) the first call has somewhere to come from, which is
    /// what an entering node needs: CSS calls the same idea `@starting-style`.
    /// 与 [`animate`](Self::animate) 不同，首次调用就有出发之处，这正是入场节点需要的：
    /// CSS 把同一件事叫作 `@starting-style`。
    pub fn travel(&mut self, id: Id, from: f32, target: f32, spec: AnimSpec, now: f64) -> f32 {
        if let std::collections::hash_map::Entry::Vacant(slot) = self.entries.entry(id) {
            slot.insert(Entry {
                from: [from; 4],
                to: [target; 4],
                lanes: 1,
                committed_at: now,
                duration: spec.duration.max(0.0),
                easing: spec.easing,
                delay: spec.delay,
                stops: [Stop::new(0.0, target, Easing::Linear); MAX_STOPS],
                stop_count: 0,
                previous_target: None,
            });
        }
        self.animate(id, target, spec, now)
    }

    /// Drop the instance at `id`, so a node that reappears travels from its start again.
    /// 丢弃 `id` 处的实例，使再次出现的节点重新从起点出发。
    pub fn forget(&mut self, id: Id) {
        self.entries.remove(&id);
    }

    /// Seconds since `id` was first asked for: a loop's own clock, starting at zero.
    /// `id` 首次被询问至今的秒数：循环自己的时钟，从零开始。
    ///
    /// Unlike an animation this never settles; the caller is expected to keep asking.
    /// 与动画不同，它永不落定；调用方应当持续读取。
    pub fn age(&mut self, id: Id, now: f64) -> f64 {
        let born = *self.births.entry(id).or_insert(now);
        (now - born).max(0.0)
    }

    /// The age a previous [`age`](Self::age) call established, or `None` before the first.
    /// 之前 [`age`](Self::age) 建立的年龄；首次之前为 `None`。
    pub fn age_of(&self, id: Id, now: f64) -> Option<f64> {
        self.births.get(&id).map(|born| (now - born).max(0.0))
    }

    /// One instance's state, or `None` if it was never animated.
    /// 单个实例的状态；从未动画过则为 `None`。
    ///
    /// Read it after retargeting, so it describes this frame's leg.
    /// 在重定向之后读取，它描述的才是本帧这一段。
    pub fn status(&self, id: Id, now: f64) -> Option<Status> {
        self.entries.get(&id).map(|e| Status {
            value: e.value(now),
            target: e.to[0],
            leg_start: e.from[0],
            travel: if e.to[0] >= e.from[0] {
                Travel::Forward
            } else {
                Travel::Reverse
            },
            settled: e.settled(now),
        })
    }

    /// Drive a spring at `id` toward `target`; returns position and velocity this frame.
    /// 把 `id` 处的弹簧推向 `target`；返回本帧的位置与速度。
    ///
    /// The first call settles at `target`: a spring never pushed has nowhere to travel from.
    /// 首次调用直接落在 `target`：从未被推动过的弹簧没有可出发的地方。
    pub fn spring(
        &mut self,
        id: Id,
        target: f32,
        stiffness: f32,
        damping: f32,
        now: f64,
    ) -> SpringState {
        self.spring_hinted(id, target, stiffness, damping, 0.0, now)
    }

    /// Where `id`'s spring is now, without advancing it; `None` before the first drive.
    /// `id` 处弹簧此刻的位置（不推进）；首次驱动之前为 `None`。
    pub fn spring_value(&self, id: Id) -> Option<SpringState> {
        self.springs.get(&id).map(|e| SpringState {
            x: e.x as f32,
            v: e.v as f32,
        })
    }

    /// Forget one spring, so the next drive starts at its target instead of the old
    /// trajectory; a leftover position would make the first frame of a new bounce jump.
    /// 忘掉一个弹簧，下次驱动从目标起步而不是延续旧轨迹；
    /// 残留的位置会让新回弹的第一帧跳一下。
    pub fn forget_spring(&mut self, id: Id) {
        self.springs.remove(&id);
    }

    /// Forget one id's birth, so its next [`age`](Self::age) read starts again at zero.
    /// 忘掉一个 id 的诞生时刻，它下一次 [`age`](Self::age) 读取便从零重新开始。
    pub fn forget_age(&mut self, id: Id) {
        self.births.remove(&id);
    }

    /// Same as [`spring`](Self::spring), but a target that changed this call starts at
    /// `hint` units/s: Flutter's `animateWith(SpringSimulation(..., velocity: hint))`.
    /// 同 [`spring`](Self::spring)，但本次调用换了目标时以 `hint` 单位/秒出发：
    /// 即 Flutter 的 `animateWith(SpringSimulation(..., velocity: hint))`。
    pub fn spring_hinted(
        &mut self,
        id: Id,
        target: f32,
        stiffness: f32,
        damping: f32,
        hint: f32,
        now: f64,
    ) -> SpringState {
        let entry = self.springs.entry(id).or_insert(SpringEntry {
            x: target as f64,
            v: 0.0,
            target: target as f64,
            stiffness: stiffness as f64,
            damping: damping as f64,
            last: now,
            born: now,
            pending: true,
            moved: 0.0,
            drives: 0,
            steps: 0,
            adv: 0,
            dt: 0.0,
        });
        // Retuning in place keeps the motion continuous when a style swaps the spring.
        // 原地改参数让动作保持连续：风格换了弹簧也不会跳。
        if entry.target != target as f64 {
            entry.pending = true;
            if hint != 0.0 {
                entry.v = hint as f64;
            }
        }
        entry.target = target as f64;
        entry.stiffness = stiffness as f64;
        entry.damping = damping as f64;
        let dt = (now - entry.last).clamp(0.0, SPRING_MAX_DT as f64) as f32;
        entry.last = now;
        entry.drives += 1;
        entry.dt = dt;
        if dt > 0.0 && entry.live() {
            entry.step(dt);
        } else if !entry.live() {
            entry.x = entry.target;
            entry.v = 0.0;
        }
        SpringState {
            x: entry.x as f32,
            v: entry.v as f32,
        }
    }

    /// Step every spring to `now`, leaving each one at rest once it lands.
    /// 把所有弹簧推进到 `now`，落定后停在静止值。
    ///
    /// A spring moves only when advanced; abandoned, it would claim motion for ever and keep
    /// the loop awake. A landed one stays as the value its next animation departs from.
    /// 弹簧只在被推进时才会动；被丢下就会永远声称在动、让循环空转。落定的一条留在表里，
    /// 因为它正是下一次动画的出发点。
    pub fn advance(&mut self, now: f64) {
        for entry in self.springs.values_mut() {
            let dt = (now - entry.last).clamp(0.0, SPRING_MAX_DT as f64) as f32;
            entry.last = now;
            if dt > 0.0 && entry.live() {
                entry.adv += 1;
                entry.dt = dt;
                entry.step(dt);
            }
        }
    }

    /// Zero the per-frame tallies before anything drives a spring this frame.
    /// 在帧内任何东西驱动弹簧之前，把每帧计数清零。
    pub fn begin_frame(&mut self) {
        for entry in self.springs.values_mut() {
            entry.moved = 0.0;
            entry.drives = 0;
            entry.steps = 0;
            entry.adv = 0;
        }
    }

    /// Whether anything is still moving.
    /// 是否还有东西在动。
    ///
    /// A spring keeps the loop awake only while it has a fresh target or actually moved:
    /// one left live but never advanced would otherwise spin the loop with nothing to draw.
    /// 弹簧只有在有了新目标或真的走动时才唤醒循环：只被留在"运动中"却没人推进的那条，
    /// 否则会让循环空转而无物可画。
    pub fn is_animating(&self, now: f64) -> bool {
        self.entries.values().any(|e| !e.settled(now))
            || self
                .springs
                .values()
                .any(|s| s.live() && (s.pending || s.moved > 0.0))
    }

    /// Whether one spring is still travelling; only its owner's calls advance it.
    /// 某条弹簧是否仍在运动；只有它的主人在调用时才会推进它。
    pub fn spring_live(&self, id: Id) -> bool {
        self.springs.get(&id).is_some_and(|s| s.live())
    }

    /// How many springs are tracked, and how many of those still claim motion.
    /// 跟踪的弹簧数，以及其中仍声称在动的条数。
    pub fn spring_counts(&self) -> (usize, usize) {
        (self.springs.len(), self.springs.values().filter(|s| s.live()).count())
    }

    /// Everything still moving, with the numbers that say *why* it never lands.
    /// 仍在运动的一切，连同说明它为何落不下来的数字。
    pub fn moving(&self, now: f64) -> Vec<Moving> {
        let mut out: Vec<Moving> = self
            .entries
            .iter()
            .filter(|(_, e)| !e.settled(now))
            .map(|(id, e)| Moving::Tween {
                id: *id,
                progress: e.progress(now),
                duration: e.duration,
                delay: e.delay,
            })
            .collect();
        out.extend(self.springs.iter().filter(|(_, s)| s.live()).map(|(id, s)| {
            Moving::Spring {
                id: *id,
                x: s.x as f32,
                v: s.v as f32,
                target: s.target as f32,
                idle: (now - s.last) as f32,
                age: (now - s.born) as f32,
                moved: s.moved,
                awake: s.pending || s.moved > 0.0,
                drives: s.drives,
                steps: s.steps,
                adv: s.adv,
                dt: s.dt,
            }
        }));
        out
    }

    /// Forget every animation, e.g. when the tree is rebuilt from scratch.
    /// 忘掉所有动画，例如整棵树重建时。
    pub fn clear(&mut self) {
        self.entries.clear();
        self.springs.clear();
        self.births.clear();
    }

    /// How many ids are tracked, settled or not.
    /// 跟踪的 id 数量（含已落定）。
    pub fn len(&self) -> usize {
        self.entries.len()
    }

    pub fn is_empty(&self) -> bool {
        self.entries.is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn id(n: u64) -> Id {
        Id::from_u64(n)
    }

    /// A bounce that arrives at a page-scale coordinate must still land: integrated in f32
    /// its last steps are below one ulp, so it parks there with `live` true for ever.
    /// 页面尺度坐标上的回弹必须能落定：以 f32 积分时最后几步小于一个 ulp，会永远停在那里。
    #[test]
    fn a_spring_parked_below_one_ulp_still_lands() {
        // The numbers are one stalled bounce as the engine's own report gave it.
        // 这些数字取自一次真实停滞的回弹，直接来自引擎自己的报告。
        let mut e = SpringEntry {
            x: 1286.9996,
            v: 0.0034,
            target: 1287.0,
            stiffness: 280.0,
            damping: 30.0,
            last: 0.0,
            born: 0.0,
            pending: false,
            moved: 0.0,
            drives: 0,
            steps: 0,
            adv: 0,
            dt: 0.0,
        };
        for _ in 0..275 {
            e.step(1.0 / 275.0);
        }
        assert!(!e.live(), "one second must carry it past the last f32 ulp");
        assert_eq!((e.x, e.v), (1287.0, 0.0), "rest is exact, not merely near");
    }

    /// Tests drive the engine's clock by hand: a timestamp is the only time input.
    /// 测试手动驱动引擎时钟：时间戳是唯一的时间输入。
    struct Clock(f64);

    impl Clock {
        fn new() -> Self {
            Self(0.0)
        }
        fn now(&self) -> f64 {
            self.0
        }
        /// Move forward by `dt` seconds, as one frame would.
        /// 前进 `dt` 秒，如一帧那样。
        fn step(&mut self, dt: f64) {
            self.0 += dt;
        }
        fn set(&mut self, t: f64) {
            self.0 = t;
        }
    }

    #[test]
    fn mirroring_a_cubic_equals_the_reverse_playback_of_the_curve() {
        // The identity g(t) = 1 - f(1 - t) defines a mirrored curve; CSS names it too:
        // ease-in (0.42,0,1,1) mirrors to ease-out (0,0,0.58,1).
        // 镜像定义为 g(t) = 1 - f(1 - t)；CSS 也有此名：ease-in 镜像成 ease-out。
        let f = Easing::Cubic(0.42, 0.0, 1.0, 1.0);
        let g = f.mirrored();
        if let Easing::Cubic(a, b, c, d) = g {
            // CSS names the pair; the arithmetic is 1 - x of the swapped control points.
            // CSS 里这对有名字；算式就是交换控制点后取 1 - x。
            for (v, want) in [(a, 0.0), (b, 0.0), (c, 0.58), (d, 1.0)] {
                assert!((v - want).abs() < 1e-5, "control {v} vs {want}");
            }
        } else {
            panic!("mirroring a cubic must stay a cubic, got {g:?}");
        }
        for k in 1..10 {
            let t = k as f32 / 10.0;
            let left = g.apply(t);
            let right = 1.0 - f.apply(1.0 - t);
            assert!(
                (left - right).abs() < 0.02,
                "at t={t}: mirrored {left} vs reversed {right}"
            );
        }
    }

    #[test]
    fn a_cubic_with_collinear_controls_is_linear_within_the_solver_bound() {
        let v = Easing::Cubic(1.0 / 3.0, 1.0 / 3.0, 2.0 / 3.0, 2.0 / 3.0).apply(0.37);
        assert!((v - 0.37).abs() < 0.005, "got {v}");
    }


    #[test]
    fn a_value_that_was_never_animated_settles_immediately() {
        let clock = Clock::new();
        let mut store = AnimStore::new();
        let v = store.animate(id(1), 1.0, AnimSpec::new(0.2, Easing::EaseOut), clock.now());
        assert_eq!(v, 1.0);
        assert!(!store.is_animating(clock.now()));
    }

    #[test]
    fn a_retarget_travels_from_the_current_value_without_jumping() {
        let mut clock = Clock::new();
        let mut store = AnimStore::new();
        store.animate(id(1), 0.0, AnimSpec::new(0.1, Easing::Linear), clock.now());
        store.animate(id(1), 1.0, AnimSpec::new(0.1, Easing::Linear), clock.now());
        clock.step(0.05);
        let mid = store.value(id(1), clock.now()).expect("tracked");
        assert!(mid > 0.0 && mid < 1.0, "mid-flight value is {mid}");

        let after = store.animate(id(1), 0.0, AnimSpec::new(0.1, Easing::Linear), clock.now());
        assert!(
            (after - mid).abs() < 1e-6,
            "retarget must continue from {mid}, got {after}"
        );
    }

    #[test]
    fn a_delay_holds_the_value_at_the_legs_start() {
        // The engine owns the phase, so a family never schedules delays itself.
        // 相位由引擎负责，家族因此不必自己安排延迟。
        let mut s = AnimStore::new();
        let id = Id::str("v");
        // A fresh instance is already at its target, so the delay shows on a retarget.
        // 全新实例本就在终点，因此延迟体现在重定向上。
        s.animate(id, 0.0, AnimSpec::new(1.0, Easing::Linear), 0.0);
        let spec = AnimSpec::new(1.0, Easing::Linear).delayed(0.5);
        s.animate(id, 1.0, spec, 0.0);
        assert_eq!(s.value(id, 0.25), Some(0.0), "still waiting");
        assert_eq!(s.value(id, 0.5), Some(0.0), "the delay ends here");
        assert!((s.value(id, 1.0).unwrap() - 0.5).abs() < 1e-5, "half way after");
        assert_eq!(s.value(id, 1.5), Some(1.0), "landed");
    }

    #[test]
    fn a_zero_duration_leg_lands_when_its_delay_is_over() {
        // `IMMEDIATE` is a write; with a delay it is a scheduled write.
        // `IMMEDIATE` 是一次写入；带延迟时就是一次定时写入。
        let mut s = AnimStore::new();
        let id = Id::str("v");
        s.animate(id, 0.0, AnimSpec::new(1.0, Easing::Linear), 0.0);
        s.animate(id, 1.0, AnimSpec::new(0.0, Easing::Linear).delayed(0.2), 0.0);
        assert_eq!(s.value(id, 0.1), Some(0.0));
        assert_eq!(s.value(id, 0.3), Some(1.0));
    }

    #[test]
    fn keyframes_land_on_every_stop_and_end_at_the_last() {
        // Three stops with the curves the reference uses for the thumb's squash.
        // 三个关键帧，曲线取自参考的滑块形变。
        let mut s = AnimStore::new();
        let id = Id::str("v");
        let stops = [
            Stop::new(0.25, 34.0, Easing::Linear),
            Stop::new(0.83, 24.0, Easing::Linear),
            Stop::new(1.0, 24.0, Easing::Linear),
        ];
        s.animate_stops(id, &stops, AnimSpec::new(1.0, Easing::Linear), 0.0);
        assert_eq!(s.value(id, 0.0), Some(24.0), "a fresh instance starts settled");
        // Retarget the other way so the sequence actually runs.
        let down = [
            Stop::new(0.17, 16.0, Easing::Linear),
            Stop::new(0.75, 34.0, Easing::Linear),
            Stop::new(1.0, 16.0, Easing::Linear),
        ];
        s.animate_stops(id, &down, AnimSpec::new(1.0, Easing::Linear), 1.0);
        assert_eq!(s.value(id, 1.0), Some(24.0), "starts where it was");
        assert!((s.value(id, 1.17).unwrap() - 16.0).abs() < 0.01, "first stop");
        assert!((s.value(id, 1.75).unwrap() - 34.0).abs() < 0.01, "the pill");
        assert!((s.value(id, 2.0).unwrap() - 16.0).abs() < 0.01, "the far end");
    }

    #[test]
    fn a_colour_travels_on_one_clock_whatever_its_channels_do() {
        // Four channels with wildly different distances must still arrive together: they
        // share a leg, so the clock is set by the furthest channel.
        // 四条通道的行程相差很大，但必须同时到达：它们共用一段，时钟由行程最远的通道决定。
        let mut s = AnimStore::new();
        let id = Id::str("c");
        let red = crate::geom::Color::rgba(1.0, 0.0, 0.0, 1.0);
        let pale = crate::geom::Color::rgba(1.0, 1.0, 1.0, 0.2);
        s.animate_colour(id, red, AnimSpec::new(1.0, Easing::Linear), 0.0);
        let mid = s.animate_colour(id, pale, AnimSpec::new(1.0, Easing::Linear), 0.0);
        assert!((mid.r - 1.0).abs() < 1e-5, "no distance, no movement: {}", mid.r);
        let half = s.colour(id, 0.5).expect("colour");
        assert!((half.g - 0.5).abs() < 1e-4, "green is half way: {}", half.g);
        assert!((half.a - 0.6).abs() < 1e-4, "alpha too: {}", half.a);
        let done = s.colour(id, 1.0).expect("colour");
        assert!((done.g - 1.0).abs() < 1e-5 && (done.a - 0.2).abs() < 1e-5);
    }

    #[test]
    fn a_downward_leg_uses_its_own_duration_and_curve() {
        // Flutter's `reverseCurve` in one field: no control has to pick a spec by direction.
        // 一个字段承载 Flutter 的 `reverseCurve`：控件不必再按方向挑 spec。
        let mut s = AnimStore::new();
        let id = Id::str("v");
        let spec = AnimSpec::new(1.0, Easing::Linear).down(0.25, Easing::Linear);
        s.animate(id, 1.0, spec, 0.0);
        assert_eq!(s.value(id, 1.0), Some(1.0));
        s.animate(id, 0.0, spec, 1.0);
        assert_eq!(s.value(id, 1.25), Some(0.0), "down took a quarter of the time");
    }

    #[test]
    fn a_declared_span_scales_a_partial_retarget_by_the_value_range() {
        // A drag leaves the value at 0.4; releasing it must take 40% of the toggle duration.
        // Without a span the previous leg is a zero-length drag step, so the full duration runs.
        // 拖拽把值留在 0.4；松手只应走开关时长的 40%。没有值域时上一段是零长拖拽步，
        // 于是会走完整段时长。
        let clock = Clock::new();
        let mut store = AnimStore::new();
        let spec = AnimSpec::new(1.0, Easing::Linear).span(1.0);
        store.animate(id(1), 0.0, spec, clock.now());
        store.animate(id(1), 0.4, AnimSpec::new(0.0, Easing::Linear), clock.now());
        store.animate(id(1), 1.0, spec, clock.now());
        assert!((store.value(id(1), 0.3).unwrap() - 0.7).abs() < 1e-4, "half of 60%");
        assert_eq!(store.value(id(1), 0.6), Some(1.0), "lands at 60% of the duration");
    }

    #[test]
    fn retargeting_every_frame_follows_without_jumping_and_lands_exactly() {
        // A drag sets a new target every frame on a very short follow. Each retarget must
        // hand back the current value (that is the "sync first" half), trail the finger,
        // never overshoot, and land exactly once the finger stops.
        // 拖拽每帧在一个极短跟随上设新目标。每次重定向必须交回当前值（这就是「先同步」那一半），
        // 落后于手指、不越过，并在手指停下后精确落定。
        let spec = AnimSpec::new(0.024, Easing::Linear);
        let mut clock = Clock::new();
        let mut store = AnimStore::new();
        store.animate(id(1), 0.0, spec, clock.now());
        let mut target = 0.0f32;
        for _ in 0..20 {
            target = (target + 0.05).min(1.0);
            let before = store.value(id(1), clock.now()).expect("tracked");
            let returned = store.animate(id(1), target, spec, clock.now());
            assert!(
                (returned - before).abs() < 1e-6,
                "a retarget must sync to the current value: {before} -> {returned}"
            );
            clock.step(0.016);
            let v = store.value(id(1), clock.now()).expect("tracked");
            assert!(v <= target + 1e-6, "the value must not overshoot: {v} > {target}");
            assert!(v >= before - 1e-6, "and must not go backwards: {before} -> {v}");
        }
        for _ in 0..40 {
            store.animate(id(1), target, spec, clock.now());
            clock.step(0.016);
        }
        let end = store.value(id(1), clock.now()).expect("tracked");
        assert!((end - target).abs() < 1e-3, "must land on {target}, got {end}");
        assert!(!store.is_animating(clock.now()), "and must stop animating");
    }

    #[test]
    fn a_settled_instance_takes_the_declared_time_whatever_the_last_leg_spanned() {
        // The tab underline travels in tab units, so the last leg's span varies. A settled
        // instance is not being interrupted: its next leg must last the declared time, or a
        // long tab jump makes the following short one race (250ms scaled to 125ms).
        // 页签下划线以页签为单位行进，上一段的跨度因此不定。已落定的实例不算被打断：
        // 下一段必须走满声明时长，否则一次远跳会让随后的一次近移抢跑（250ms 缩成 125ms）。
        let spec = AnimSpec::new(0.25, Easing::Linear);
        let mut clock = Clock::new();
        let mut store = AnimStore::new();
        store.animate(id(1), 0.0, spec, clock.now());
        store.animate(id(1), 2.0, spec, clock.now());
        clock.step(0.3);
        store.animate(id(1), 2.0, spec, clock.now());
        assert!(
            !store.is_animating(clock.now()),
            "the long leg must have settled before the short one starts"
        );

        store.animate(id(1), 1.0, spec, clock.now());
        clock.step(0.125);
        let half = store.value(id(1), clock.now()).expect("tracked");
        assert!(
            (half - 1.5).abs() < 1e-3,
            "half the declared time must be half the travel, got {half}"
        );
        clock.step(0.125);
        let end = store.value(id(1), clock.now()).expect("tracked");
        assert!((end - 1.0).abs() < 1e-3, "and must land on 1.0, got {end}");
    }

    #[test]
    fn a_settled_colour_takes_the_declared_time_whatever_the_last_leg_spanned() {
        // The colour path scales its clock the same way, so it needs the same guard.
        // 颜色通道用同样的方式缩放时钟，因此需要同样的守卫。
        use crate::geom::Color;
        let spec = AnimSpec::new(0.25, Easing::Linear);
        let mut clock = Clock::new();
        let mut store = AnimStore::new();
        let black = Color::from_rgba8(0, 0, 0, 255);
        let white = Color::from_rgba8(255, 255, 255, 255);
        store.animate_colour(id(1), black, spec, clock.now());
        store.animate_colour(id(1), white, spec, clock.now());
        clock.step(0.3);
        store.animate_colour(id(1), white, spec, clock.now());
        assert!(!store.is_animating(clock.now()), "the long leg must have settled");

        let mid = Color::from_rgba8(128, 128, 128, 255);
        store.animate_colour(id(1), mid, spec, clock.now());
        clock.step(0.125);
        let half = store.animate_colour(id(1), mid, spec, clock.now());
        assert!(
            (half.r - 0.751).abs() < 0.01,
            "half the declared time must be half the travel, got {}",
            half.r
        );
    }

    #[test]
    fn a_retarget_reports_the_value_it_sampled_and_which_way_it_now_travels() {
        // A family that needs to freeze a derived quantity for one leg reads `leg_start`;
        // it must be the value the retarget sampled, not the leg's old target.
        // 需要在本段行程内冻结派生量的家族读 `leg_start`；它必须是重定向采样到的值，
        // 而不是上一段的目标。
        let mut clock = Clock::new();
        let mut store = AnimStore::new();
        let spec = AnimSpec::new(0.1, Easing::Linear);
        store.animate(id(1), 0.0, spec, clock.now()); // settle at the near end first
        store.animate(id(1), 1.0, spec, clock.now());
        clock.step(0.04);
        let before = store.value(id(1), clock.now()).expect("tracked");
        assert!(before > 0.0 && before < 1.0, "mid-flight is {before}");

        store.animate(id(1), 0.0, spec, clock.now());
        let s = store.status(id(1), clock.now()).expect("tracked");
        assert_eq!(s.travel, Travel::Reverse, "it now heads down");
        assert!(
            (s.leg_start - before).abs() < 1e-6,
            "the leg starts where the value was: {} vs {before}",
            s.leg_start
        );
        assert!(!s.settled, "and it is still in flight");
    }

    #[test]
    fn a_settled_instance_keeps_the_direction_of_the_leg_it_arrived_on() {
        // `settled` is what stops a freeze from lasting forever: a reverse leg that has
        // landed still reports `Reverse`, so `Reverse && !settled` is the right predicate.
        // 结束冻结靠 `settled`：已经落地的反向段仍报 `Reverse`，所以
        // 「Reverse 且未落定」才是正确的判据。
        let mut clock = Clock::new();
        let mut store = AnimStore::new();
        let spec = AnimSpec::new(0.05, Easing::Linear);
        store.animate(id(1), 1.0, spec, clock.now());
        clock.step(0.06);
        assert!(store.status(id(1), clock.now()).expect("tracked").settled, "up leg done");

        store.animate(id(1), 0.0, spec, clock.now());
        clock.step(0.06);
        let s = store.status(id(1), clock.now()).expect("tracked");
        assert!(s.settled, "down leg done");
        assert_eq!(s.travel, Travel::Reverse, "but it arrived from above");
        assert_eq!(s.value, 0.0);
    }

    #[test]
    fn an_instance_that_was_never_animated_has_no_status() {
        let clock = Clock::new();
        let store = AnimStore::new();
        assert!(store.status(id(9), clock.now()).is_none());
    }

    #[test]
    fn a_reversal_mirrors_the_curve() {
        assert_eq!(Easing::EaseOut.mirrored(), Easing::EaseIn);
        assert_eq!(Easing::EaseIn.mirrored(), Easing::EaseOut);
        assert_eq!(Easing::Linear.mirrored(), Easing::Linear);
        assert_eq!(Easing::EaseInOut.mirrored(), Easing::EaseInOut);

        let mut clock = Clock::new();
        let mut store = AnimStore::new();
        store.animate(id(1), 0.0, AnimSpec::new(0.2, Easing::EaseOut), clock.now());
        store.animate(id(1), 1.0, AnimSpec::new(0.2, Easing::EaseOut), clock.now());
        clock.step(0.05);
        store.animate(id(1), 0.0, AnimSpec::new(0.2, Easing::EaseOut), clock.now());
        let before = store.value(id(1), clock.now()).expect("tracked");
        clock.step(0.01);
        let after = store.value(id(1), clock.now()).expect("tracked");
        assert!(
            (before - after).abs() > 1e-3,
            "a mirrored reversal must move at once: {before} -> {after}"
        );
    }

    #[test]
    fn a_second_reversal_restores_the_original_curve() {
        let mut clock = Clock::new();
        let mut store = AnimStore::new();
        let spec = AnimSpec::new(0.2, Easing::EaseOut);
        store.animate(id(1), 0.0, spec, clock.now());
        store.animate(id(1), 1.0, spec, clock.now());
        clock.step(0.05);
        store.animate(id(1), 0.0, spec, clock.now());
        clock.step(0.05);
        store.animate(id(1), 1.0, spec, clock.now());
        clock.step(0.05);
        store.animate(id(1), 0.0, spec, clock.now());
        let entry = store.entries.get(&id(1)).expect("tracked");
        assert_eq!(entry.easing, Easing::EaseOut);
    }

    #[test]
    fn a_broken_clock_timestamp_cannot_rewind_or_poison_a_value() {
        let mut clock = Clock::new();
        let mut store = AnimStore::new();
        store.animate(id(1), 0.0, AnimSpec::new(0.1, Easing::Linear), clock.now());
        store.animate(id(1), 1.0, AnimSpec::new(0.1, Easing::Linear), clock.now());
        clock.step(0.05);
        let mid = store.value(id(1), clock.now()).expect("tracked");

        // The engine clock only moves forward; these are the timestamps a broken host
        // could still hand in, and none of them may rewind or poison a value.
        // 引擎时钟只往前走；这些是坏宿主仍可能递进来的时间戳，任何一个都不得倒带或污染。
        clock.set(clock.now() - 1.0);
        assert!(store.value(id(1), clock.now()).is_some_and(|v| v <= mid + 1e-6), "stepping back must not advance");
        clock.set(f64::NAN);
        let nan = store.value(id(1), clock.now()).expect("tracked");
        assert!(nan.is_finite(), "a NaN timestamp must not poison the value, got {nan}");
        clock.set(f64::INFINITY);
        let inf = store.value(id(1), clock.now()).expect("tracked");
        assert!(inf.is_finite(), "an infinite timestamp must not poison the value, got {inf}");
    }

    #[test]
    fn the_same_input_sequence_produces_the_same_frames() {
        let run = || {
            let mut clock = Clock::new();
        let mut store = AnimStore::new();
            let spec = AnimSpec::new(0.24, Easing::EaseInOut);
            store.animate(id(7), 0.0, spec, clock.now());
            store.animate(id(7), 1.0, spec, clock.now());
            let mut out = Vec::new();
            for _ in 0..8 {
                clock.step(0.033);
                out.push(store.value(id(7), clock.now()).expect("tracked"));
            }
            out
        };
        assert_eq!(run(), run());
    }

    #[test]
    fn a_nudge_near_the_goal_takes_less_than_the_full_duration() {
        // Already 90% of the way there: the last 10% must not cost the full 1s.
        // 已经走了 90%：最后 10% 不该再花掉完整的 1 秒。
        let mut clock = Clock::new();
        let mut store = AnimStore::new();
        let spec = AnimSpec::new(1.0, Easing::Linear);
        store.animate(id(1), 0.0, spec, clock.now());
        store.animate(id(1), 1.0, spec, clock.now());
        clock.step(0.9);
        let at = store.value(id(1), clock.now()).expect("tracked");
        assert!((at - 0.9).abs() < 1e-3, "expected to be at 0.9, got {at}");

        // Retarget to the same goal the animation was already heading to is a no-op;
        // push slightly past it so a new leg starts from 0.9.
        // 重定向到原目标是无操作；略微推过去，使新的一段从 0.9 出发。
        store.animate(id(1), 1.05, spec, clock.now());
        let entry = store.entries.get(&id(1)).expect("tracked");
        assert!(
            entry.duration < 0.3,
            "a short hop must not take the full 1s, got {}",
            entry.duration
        );
    }

    /// The same elapsed time must produce the same spring position at 60 Hz and at 120 Hz;
    /// a per-frame integrator would make a slow display also slow the motion.
    /// 同样的时间在 60Hz 与 120Hz 下必须得到同样的弹簧位置；按帧积分会让慢屏也拖慢动作。
    #[test]
    fn a_spring_travels_the_same_distance_at_any_frame_rate() {
        let run = |fps: u32| {
            let mut clock = Clock::new();
            let mut store = AnimStore::new();
            store.spring(id(1), 0.0, 322.29, 30.51, clock.now());
            let step = 1.0 / fps as f64;
            let mut x = 0.0;
            for _ in 0..fps {
                clock.step(step);
                x = store.spring(id(1), 1.0, 322.29, 30.51, clock.now()).x;
            }
            x
        };
        let (slow, fast) = (run(60), run(120));
        assert!(
            (slow - fast).abs() < 5e-3,
            "60 Hz reads {slow}, 120 Hz reads {fast}"
        );
        assert!(slow > 0.9, "a settling spring must have travelled, got {slow}");
    }

    /// A spring in flight is motion: the frame loop must stay awake, and must stop once it
    /// rests, or a control would freeze mid-ring or spin forever.
    /// 在途弹簧就是动作：帧循环必须保持唤醒，落定后必须停下，否则控件会冻在振铃中途或永转。
    #[test]
    fn a_spring_keeps_the_frame_loop_awake_until_it_rests() {
        let mut clock = Clock::new();
        let mut store = AnimStore::new();
        store.spring(id(1), 0.0, 322.29, 30.51, clock.now());
        clock.step(1.0 / 60.0);
        store.spring(id(1), 1.0, 322.29, 30.51, clock.now());
        assert!(store.is_animating(clock.now()), "the spring just started");
        for _ in 0..120 {
            clock.step(1.0 / 60.0);
            store.spring(id(1), 1.0, 322.29, 30.51, clock.now());
        }
        assert!(!store.is_animating(clock.now()), "two seconds is enough to rest");
        let at = store.spring(id(1), 1.0, 322.29, 30.51, clock.now());
        assert_eq!((at.x, at.v), (1.0, 0.0), "rest is exact, not merely small");
    }

    /// A velocity hint is the launch of a retarget, not a per-frame kick: re-injecting it
    /// while the target holds would keep the spring pushed away from where it is heading.
    /// 初速度提示只是换目标那一下的发射，不是每帧的推力：目标不变时反复注入会把弹簧一直推开。
    #[test]
    fn a_spring_hint_fires_once_per_retarget() {
        // A hint on an unchanged target is a no-op...
        // 目标未变时给初速度提示不应有任何效果……
        let run = |hint: f32| {
            let mut clock = Clock::new();
            let mut store = AnimStore::new();
            store.spring(id(1), 0.0, 120.0, 16.0, clock.now());
            let mut x = 0.0;
            for k in 0..10 {
                clock.step(1.0 / 60.0);
                let hint = if k == 0 { 4.0 } else { hint };
                x = store.spring_hinted(id(1), 1.0, 120.0, 16.0, hint, clock.now()).x;
            }
            x
        };
        assert_eq!(run(4.0), run(0.0), "a stable target swallowed the hint");
        // ...while a retarget launches with it.
        // ……换目标时它才发射。
        let retarget = |hint: f32| {
            let mut clock = Clock::new();
            let mut store = AnimStore::new();
            store.spring(id(1), 1.0, 200.0, 21.0, clock.now());
            clock.step(1.0 / 60.0);
            store.spring_hinted(id(1), 0.0, 200.0, 21.0, hint, clock.now()).x
        };
        assert!(retarget(-3.2) < retarget(0.0), "the close hint must pull it home");
    }
}

