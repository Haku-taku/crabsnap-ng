//! The retained tree: persistent structure, immediate declarations.
//! 保留树：结构持久，声明即时。

use crate::collections::FastMap;
use std::rc::Rc;
use std::sync::Arc;

use crate::geom::{Corners, Insets, Rect, Size};
use crate::id::{Id, NodeId};
use crate::layout::{BoxModel, Constraints, SizeClass};

/// What a node is.
/// 节点类型。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum NodeKind {
    /// Horizontal flow.
    /// 水平流。
    Row,
    /// Vertical flow.
    /// 垂直流。
    Column,
    /// Children stacked on top of each other.
    /// 子节点互相叠放。
    Stack,
    /// Absolutely positioned relative to the parent.
    /// 相对父节点绝对定位。
    Overlay,
    /// Leaf that paints a filled, possibly rounded box.
    /// 画一个填充（可圆角）盒子的叶子。
    Box,
    /// Leaf that paints text.
    /// 画文字的叶子。
    Text,
    /// Two-dimensional track layout, see [`crate::layout::TrackList`].
    /// 二维轨道布局，见 [`crate::layout::TrackList`]。
    Grid,
}

/// Grid placement and alignment a child declares for its grid parent.
/// 子节点为其网格父容器声明的摆放与对齐。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct GridItem {
    /// `None` auto-flows into the next free cell.
    /// `None` 自动流入下一个空格。
    pub area: Option<crate::layout::GridArea>,
    /// Vertical alignment in the cell; `None` stretches.
    /// 单元格内的纵向对齐；`None` 为拉伸。
    pub align: Option<crate::layout::Align>,
    /// Horizontal alignment in the cell; `None` stretches.
    /// 单元格内的横向对齐；`None` 为拉伸。
    pub justify: Option<crate::layout::Align>,
    /// Cells an auto-flowed item occupies; explicit areas carry their own spans.
    /// 自动流入项目占用的格数；显式区域自带跨度。
    pub span: (u32, u32),
}

impl Default for GridItem {
    fn default() -> Self {
        Self {
            area: None,
            align: None,
            justify: None,
            span: (1, 1),
        }
    }
}

/// Backdrop blur parameters: kernel radius in pixels and its Gaussian sigma.
/// 背景模糊参数：核半径（像素）与其高斯 sigma。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct BackdropBlur {
    pub radius: u32,
    pub sigma: f32,
    /// How the blurred result is shaded; `Plain` keeps it untouched.
    /// 模糊结果如何着色；`Plain` 表示原样写回。
    pub material: crate::draw::BackdropMaterial,
}

impl BackdropBlur {
    /// Radius derived from a CSS-style `blur(Npx)` value, as `⌈3σ⌉`.
    /// 由 CSS 风格的 `blur(Npx)` 推算半径，即 `⌈3σ⌉`。
    pub fn css(sigma: f32) -> Self {
        Self {
            radius: (3.0 * sigma).ceil().max(1.0) as u32,
            sigma,
            material: crate::draw::BackdropMaterial::PLAIN,
        }
    }

    /// Shade the blur with a named material instead of writing it back untouched.
    /// 用指定材质给模糊结果着色，而不是原样写回。
    pub fn with_material(mut self, material: crate::draw::BackdropMaterial) -> Self {
        self.material = material;
        self
    }
}

/// How a texture is fitted into a node's box.
/// 纹理如何适配节点盒子。
///
/// There is deliberately no `Repeat`: a source smaller than the box is cropped or
/// letterboxed, never tiled.
/// 刻意没有 `Repeat`：源小于盒子时裁剪或留边，绝不平铺。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ImageFit {
    /// Scale to cover the box, cropping the overflow.
    /// 缩放到覆盖盒子，裁掉溢出。
    Cover,
    /// Scale to fit inside the box, leaving the fill visible around it.
    /// 缩放到装进盒子，四周露出填充色。
    Contain,
    /// Stretch, ignoring the aspect ratio.
    /// 拉伸，忽略宽高比。
    Fill,
}

impl ImageFit {
    /// Destination rect and source rect (in texture pixels) for one box.
    /// 一个盒子对应的目标矩形与源矩形（纹理像素）。
    ///
    /// The source never leaves the texture: `Cover` crops, `Contain` letterboxes, `Fill`
    /// stretches. Tiling would need a source outside it, so it cannot happen by accident.
    /// 源矩形绝不越出纹理：`Cover` 裁剪、`Contain` 留边、`Fill` 拉伸。
    /// 平铺需要越界的源，因此不可能被意外引入。
    pub fn place(self, box_: Rect, texture: (u32, u32)) -> (Rect, Rect) {
        let (tw, th) = (texture.0.max(1) as f32, texture.1.max(1) as f32);
        let whole = Rect::new(0.0, 0.0, tw, th);
        if box_.size.w <= 0.0 || box_.size.h <= 0.0 {
            return (box_, whole);
        }
        match self {
            ImageFit::Fill => (box_, whole),
            ImageFit::Cover => {
                let s = (box_.size.w / tw).max(box_.size.h / th);
                let (sw, sh) = (box_.size.w / s, box_.size.h / s);
                let src = Rect::new((tw - sw) * 0.5, (th - sh) * 0.5, sw, sh);
                (box_, src)
            }
            ImageFit::Contain => {
                let s = (box_.size.w / tw).min(box_.size.h / th);
                let (dw, dh) = (tw * s, th * s);
                let dest = Rect::new(
                    box_.origin.x + (box_.size.w - dw) * 0.5,
                    box_.origin.y + (box_.size.h - dh) * 0.5,
                    dw,
                    dh,
                );
                (dest, whole)
            }
        }
    }
}

/// A soft shadow: what colour it casts, how far it fades and how deep it sits.
/// 柔和阴影：投什么颜色、淡出多宽、下沉多深。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ShadowSpec {
    /// The cast colour; its alpha is the peak alpha at the shape's edge.
    /// 投射的颜色；其 alpha 即形状边缘处的峰值 alpha。
    pub colour: crate::geom::Color,
    /// Falloff width in logical units.
    /// 衰减宽度，逻辑单位。
    pub blur: f32,
    /// How far the cast shape grows before blurring, as CSS `box-shadow` spread.
    /// 投射形状在模糊前向外扩出的距离，同 CSS `box-shadow` 的 spread。
    pub spread: f32,
    /// Vertical offset in logical units.
    /// 垂直偏移，逻辑单位。
    pub dy: f32,
}

impl ShadowSpec {
    /// A black shadow at peak `alpha`: the elevation every WinUI and MD surface casts.
    /// 峰值 `alpha` 的黑色阴影：WinUI 与 MD 的每种立面都投它。
    pub const fn black(blur: f32, alpha: f32, dy: f32) -> Self {
        Self {
            colour: crate::geom::Color::rgba(0.0, 0.0, 0.0, alpha),
            blur,
            spread: 0.0,
            dy,
        }
    }

    /// A coloured halo that grows `spread` beyond the shape, centred on it.
    /// 带颜色的辉光：在形状之外扩出 `spread`，且居中不偏移。
    pub const fn glow(colour: crate::geom::Color, blur: f32, spread: f32) -> Self {
        Self {
            colour,
            blur,
            spread,
            dy: 0.0,
        }
    }

    /// WinUI's elevation ramp (`ThemeShadow`): deeper panels fade wider and sit lower.
    /// WinUI 的立面梯度（`ThemeShadow`）：越深的平面淡出越宽、下沉越多。
    pub const fn elevation(level: u8) -> Self {
        // Two linear ramps keep the table honest: no hand-tuned per-level magic.
        // 两条线性坡度让这张表保持诚实：没有逐级手调的魔数。
        let blur = 2.0 + 4.0 * level as f32;
        let dy = 1.0 + 2.0 * level as f32;
        Self::black(blur, 0.18, dy)
    }
}

/// A texture drawn into a node's box.
/// 画进节点盒子的纹理。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ImageSpec {
    /// Stable texture identity, registered on the loop.
    /// 稳定的纹理标识，在循环上登记。
    pub id: u64,
    pub fit: ImageFit,
}

/// What a modal surface covers, and therefore what it dims and blocks.
/// 模态表面覆盖什么，因而也压暗并挡住什么。
///
/// The two choices are the ones every declarative toolkit converges on: Flutter's
/// `OverlayChildLocation { rootOverlay, nearestOverlay }` and UIKit's `currentContext`
/// against the window.
/// 这两个选项正是各家声明式工具包收敛到的：Flutter 的
/// `OverlayChildLocation { rootOverlay, nearestOverlay }`，以及 UIKit 的 `currentContext`
/// 对窗口。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ModalTarget {
    /// The whole window: what `showDialog` does by default.
    /// 整个窗口：`showDialog` 的默认行为。
    Global,
    /// The nearest ancestor declared [`ContainerParams::modal_host`], falling back to the
    /// window when there is none.
    /// 最近一个声明了 [`ContainerParams::modal_host`] 的祖先；没有时回退到窗口。
    Proximate,
}

/// Values a node is painted from at the far end of an `enter` or `exit` transition.
/// 节点在入场或退场另一端时的绘制值。
///
/// The values are stated, never inferred: a node that did not exist last frame has no
/// previous state to travel from (CSS says the same with `@starting-style`).
/// 这些值必须写明，绝不推断：上一帧不存在的节点没有可出发的旧状态
///（CSS 用 `@starting-style` 说的是同一件事）。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Presence {
    pub spec: crate::anim::AnimSpec,
    /// The scale runs on its own clock when the two differ, as WinUI's dialog does: its
    /// opacity lands in 83 ms while its scale travels for 250.
    /// 缩放走自己的时钟（两者不同时），WinUI 的对话框正是如此：
    /// 不透明度 83 毫秒到位，缩放却要走 250 毫秒。
    pub scale_spec: Option<crate::anim::AnimSpec>,
    pub opacity: f32,
    /// Visual displacement at that end, in logical units; layout ignores it.
    /// 该端点的视觉位移，逻辑单位；布局不计。
    pub offset: crate::geom::Point,
    /// Scale at that end about the node's own centre; 1 is its laid-out size.
    /// 该端点处绕节点自身中心的缩放；1 表示布局尺寸。
    pub scale: f32,
}

impl Presence {
    /// Fade from/to `opacity`, in place.
    /// 原地淡入或淡出到 `opacity`。
    pub fn fade(spec: crate::anim::AnimSpec, opacity: f32) -> Self {
        Self {
            spec,
            scale_spec: None,
            opacity,
            offset: crate::geom::Point::ZERO,
            scale: 1.0,
        }
    }

    /// Fade while displaced: `offset` is where that end sits relative to the final one.
    /// 边淡边位移：`offset` 是该端点相对最终位置的偏移。
    pub fn slide(spec: crate::anim::AnimSpec, opacity: f32, offset: crate::geom::Point) -> Self {
        Self {
            spec,
            scale_spec: None,
            opacity,
            offset,
            scale: 1.0,
        }
    }

    /// The same transition at `scale` instead of full size.
    /// 同一段过渡，但从 `scale` 而不是原尺寸开始。
    pub const fn scaled(mut self, scale: f32) -> Self {
        self.scale = scale;
        self
    }

    /// The same end scale, travelled on `spec` instead of the presence's own clock.
    /// 同一个端点缩放，但按 `spec` 而非在场过渡自己的时钟行进。
    pub fn scaled_over(mut self, scale: f32, spec: crate::anim::AnimSpec) -> Self {
        self.scale = scale;
        self.scale_spec = Some(spec);
        self
    }
}

/// Spacing and alignment parameters carried by container nodes.
/// 容器节点携带的间距与对齐参数。
#[derive(Clone, Debug, PartialEq)]
pub struct ContainerParams {
    pub gap: f32,
    /// For a `Row`: stack along the column axis when the children no longer fit side by side.
    /// 对 `Row` 而言：子节点并排放不下时改为沿列轴堆叠。
    pub switch_axis: Option<crate::layout::AxisSwitch>,
    /// Share of the spare cross-axis space a child takes: 0 hugs, 1 stretches.
    /// 子节点占用的交叉剩余空间比例：0 紧贴，1 撑满。
    pub cross_align: f32,
    /// Where a child sits in the cross-axis space it did not take: 0 = start, 0.5 = centre.
    /// 子节点在它未占用的交叉空间里的位置：0 起点，0.5 居中。
    pub cross_pos: f32,
    /// Where a `Stack`'s children sit in its content box, per axis. A stack has no main
    /// axis, so this replaces `cross_align`/`cross_pos` for it; the default is the origin.
    /// `Stack` 子节点在内容盒里的位置，逐轴给出。叠放容器没有主轴，因此这一对取代
    /// `cross_align`/`cross_pos`；默认贴着内容原点。
    pub stack_align: (crate::layout::OverlayAlign, crate::layout::OverlayAlign),
    /// Group opacity for this subtree, 0..=1. Below 1 it composites as one unit.
    /// 该子树的组不透明度，0..=1。小于 1 时作为整体合成。
    pub opacity: f32,
    /// Effect chain applied to the whole subtree, in order.
    /// 作用于整个子树的效果链，按顺序应用。
    pub effects: Vec<crate::effect::Effect>,
    /// Travel for this node's *fixed* size when the declared value changes; `None` jumps.
    /// 声明尺寸变化时本节点**固定**尺寸的行程；`None` 直接跳变。
    pub size_transition: Option<crate::anim::AnimSpec>,
    /// Start values this node is painted from when it first appears; `None` appears settled.
    /// 本节点首次出现时的绘制起始值；`None` 直接以终态出现。
    pub enter: Option<Presence>,
    /// Values this node is painted toward when it leaves; `None` disappears at once.
    /// 本节点离开时绘制所趋向的值；`None` 立即消失。
    ///
    /// Leaving means the declaration stopped mentioning it, so the engine keeps the node
    /// alive and out of layout until it lands — the app never holds a dead subtree.
    /// 离开指声明不再提到它；引擎因此把它保活并移出布局直到落定，应用不必自己持有死子树。
    pub exit: Option<Presence>,
    /// Paint this subtree into its own target that survives frames, so an unchanged
    /// subtree is neither rebuilt into vertices nor drawn again.
    /// 把本子树画进跨帧保留的自有目标，未变化的子树因此既不重建顶点也不再绘制。
    pub offscreen: bool,
    /// Blurs what is painted behind this node. Unlike `effects`, filters the backdrop.
    /// 模糊本节点身后的内容；与 `effects` 不同，它过滤的是背景。
    pub backdrop_blur: Option<BackdropBlur>,
    /// Track template when this node is a `Grid`; `None` lays the items out in one column.
    /// 本节点是 `Grid` 时的轨道模板；`None` 时按单列摆放。
    pub tracks: Option<Box<crate::layout::TrackList>>,
    /// What happens to content that does not fit the box, per axis.
    /// 装不下的内容按轴如何处理。
    ///
    /// A `Scroll` main axis also stops the line from squeezing its children.
    /// 主轴为 `Scroll` 时，一行也不再压缩其子节点。
    pub clip: crate::layout::Clip,
    /// How far the content is scrolled left, in logical units.
    /// 内容向左滚动的距离，逻辑单位。
    ///
    /// Same contract as [`Self::scroll_y`], for a horizontal strip.
    /// 与 [`Self::scroll_y`] 同一契约，用于横向条带。
    pub scroll_x: f32,
    /// How far the content is scrolled up, in logical units.
    /// 内容向上滚动的距离，逻辑单位。
    ///
    /// A view value, not state: the offset belongs to the app, which passes it in each
    /// frame; layout shifts the children, never the viewport.
    /// 这是视图值而非状态：偏移属于 app，每帧传入；布局移动子节点，从不移动视口。
    pub scroll_y: f32,
    /// The engine is stretching this scroller past its ends right now (a pan's rubber
    /// band or the spring returning it), so layout must not clamp the offset back.
    /// 引擎此刻正把这个容器拉过两端（拖拽的橡皮筋或回弹弹簧），布局因此不得把偏移夹回。
    pub scroll_elastic: bool,
    /// Press ink the engine splats where a press lands on this node or its descendants.
    /// 按在本节点或其子孙上时，引擎在落点泼出的按压墨迹。
    pub press_ink: Option<crate::draw::PressInk>,
    /// The focus adorner to draw around this node while it holds visible focus.
    /// 本节点持有可见焦点时，围绕它绘制的焦点装饰。
    ///
    /// Drawn after the subtree, so it is never hidden by children, and outside the box,
    /// which is why it lives here rather than among the shapes.
    /// 在子树之后绘制，故不会被子节点遮住；画在盒子之外，因此在这里而不在形状列表里。
    pub focus_visual: Option<crate::draw::FocusVisual>,
    /// Whether this node is a Tab stop even though it paints no ink of its own.
    /// 本节点自身不画任何墨迹，是否仍是 Tab 停靠点。
    ///
    /// A control that draws its ring on a child still has to say it takes focus.
    /// 把焦点环画在子节点上的控件，仍须声明自己接收焦点。
    pub focus_stop: bool,
    /// The node a popup opens onto, when it should not be the first focusable one.
    /// 浮层打开时接住焦点的节点，用于不该落到第一个可聚焦节点上的场合。
    ///
    /// Read once, when the popup takes the keyboard; a hint outside the popup is ignored.
    /// 浮层接管键盘时读一次；指向浮层之外的提示会被忽略。
    pub focus_initial: Option<crate::Id>,
    /// What this node is modal *over*, when it is a modal surface; the layout places it on
    /// that rect instead of where the tree put it.
    /// 本节点作为模态表面时**盖在什么之上**；布局把它放到那个矩形上，而不是树给它的位置。
    ///
    /// A modal declared inside the panel it dims still covers the whole panel: the target
    /// is resolved after layout, so no rect has to be passed in from outside.
    /// 声明在它所压暗的面板内部的模态，仍然盖住整个面板：目标在布局之后解析，
    /// 因此不需要从外部传入矩形。
    pub modal: Option<ModalTarget>,
    /// Whether this container can be the target of a `Proximate` modal.
    /// 本容器能否作为 `Proximate` 模态的目标。
    pub modal_host: bool,
    /// The node's own curve when the frame does not paint one: a text button is a pill for
    /// its ripple and for its clip, yet has no container at rest.
    /// 本节点自身的曲线，用于本帧没有画出曲线的场合：文本按钮是胶囊——
    /// 涟漪与裁剪都按它——但静息态没有容器。
    ///
    /// It outranks the first box shape wherever the engine infers a curve, since a shape
    /// that comes and goes (a hover layer) cannot decide a curve that must not move.
    /// 在引擎任何推断曲线的地方，它都优先于首个盒子形状：时有时无的形状（悬停层）
    /// 决定不了本就不该变的曲线。
    pub corners: Option<crate::geom::Corners>,
    /// The buffer this node edits, when it accepts text; the engine reports edits as
    /// `Change::Text` and remembers the caret. The app still owns the value.
    /// 本节点接受文本时编辑的缓冲；引擎把编辑作为 `Change::Text` 上报并记住插入符，
    /// 值本身仍归应用所有。
    pub text_input: Option<String>,
    /// Whether this input takes hard line breaks: `Shift+Enter` inserts `\n` instead of
    /// activating. A single-line field never sees a `\n` in its buffer.
    /// 本输入是否接受强制换行：`Shift+Enter` 插入 `\n` 而非激活。单行字段的缓冲里绝不出现 `\n`。
    pub text_input_multiline: bool,
    /// Shortcuts this node answers while it or a descendant holds focus.
    /// 当本节点或其子孙持有焦点时，本节点应答的快捷键。
    ///
    /// The engine resolves the chord and reports `Change::Shortcut`; the node never sees a key.
    /// 引擎解析组合键并上报 `Change::Shortcut`；节点永远看不到按键。
    pub shortcuts: Vec<(crate::shortcut::KeyChord, crate::shortcut::ShortcutId)>,
    /// Rows a secondary click on this node opens, most specific node first.
    /// 在本节点上右键弹出的行；越具体的节点越优先。
    pub menu: Vec<crate::menu::MenuItem>,
    /// Where the scrollbar sits in this node's own space, when it draws one; the engine
    /// turns a press there into a thumb drag instead of a content press.
    /// 本节点画滚动条时它在自身坐标中的位置；引擎把那里的按下变成 thumb 拖拽，
    /// 而不是内容按下。
    pub scrollbar: Option<ScrollbarHit>,
}

/// A scrollbar's painted geometry in its container's own space.
/// 滚动条在其容器自身坐标中的绘制几何。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ScrollbarHit {
    /// The thumb's rect, which a press may grab.
    /// thumb 的矩形，按下可抓住它。
    pub thumb: crate::geom::Rect,
    /// The whole track; a press outside the thumb jumps the thumb there.
    /// 整条轨道；按在 thumb 之外会把 thumb 跳到那里。
    pub track: crate::geom::Rect,
}

impl Default for ContainerParams {
    fn default() -> Self {
        Self {
            gap: 0.0,
            switch_axis: None,
            cross_align: 1.0,
            cross_pos: 0.0,
            stack_align: (
                crate::layout::OverlayAlign::Start,
                crate::layout::OverlayAlign::Start,
            ),
            opacity: 1.0,
            effects: Vec::new(),
            size_transition: None,
            enter: None,
            exit: None,
            offscreen: false,
            backdrop_blur: None,
            tracks: None,
            clip: crate::layout::Clip::VISIBLE,
            scroll_x: 0.0,
            scroll_y: 0.0,
            scroll_elastic: false,
            press_ink: None,
            focus_visual: None,
            focus_stop: false,
            focus_initial: None,
            corners: None,
            modal: None,
            modal_host: false,
            text_input: None,
            text_input_multiline: false,
            shortcuts: Vec::new(),
            menu: Vec::new(),
            scrollbar: None,
        }
    }
}

/// Per-kind payload.
/// 每种节点类型的负载。
#[derive(Clone, Debug, PartialEq)]
pub enum NodeData {
    Container(ContainerParams),
    /// Styled runs; rich text grows by adding runs, not fields.
    /// 带样式的 run；富文本靠增加 run 扩展，而不是加字段。
    /// Text carries its ink because the component chose the role, not the type ramp.
    /// 文本携带墨色，因为是控件选的角色，不是字阶。
    Text {
        block: crate::text::TextBlock,
        ink: crate::geom::Color,
        /// Insertion caret at a byte offset, drawn by the text pass.
        /// 按字节偏移绘制的插入符，由文本那一趟负责。
        caret: Option<crate::draw::Caret>,
        /// Selected bytes and how this style draws them, when the node is selectable.
        /// 被选中的字节以及本风格如何绘制它；节点可选时存在。
        selection: Option<crate::selection::SelectionPrim>,
        /// Bytes the input method is composing; drawn with an underline.
        /// 输入法正在组合的字节；带下划线绘制。
        composing: Option<std::ops::Range<usize>>,
        /// Lay this text out on one line however narrow the box is; a single-line editor
        /// scrolls it instead of wrapping.
        /// 无论盒子多窄都排成一行；单行编辑器靠滚动而不是换行。
        nowrap: bool,
    },
}

impl NodeData {
    pub fn is_container(&self) -> bool {
        matches!(self, NodeData::Container(_))
    }

    /// Container parameters, if this node lays out children.
    /// 若是会布局子节点的容器，返回其参数。
    pub fn params(&self) -> Option<&ContainerParams> {
        match self {
            NodeData::Container(p) => Some(p),
            _ => None,
        }
    }

    /// Mutable container parameters.
    /// 可变的容器参数。
    pub fn params_mut(&mut self) -> Option<&mut ContainerParams> {
        match self {
            NodeData::Container(p) => Some(p),
            _ => None,
        }
    }

}

/// One node in the retained tree.
/// 保留树中的一个节点。
#[derive(Debug)]
pub struct Node {
    pub id: Id,
    pub parent: Option<NodeId>,
    pub kind: NodeKind,
    pub data: NodeData,
    /// Layout demand, recomputed when props change.
    /// 布局需求，属性变化时重算。
    pub size_class: SizeClass,
    /// Size this frame's declaration asked for; a size transition overwrites `size_class`
    /// with the interpolated value, so the target has to live somewhere else.
    /// 本帧声明要求的尺寸；尺寸过渡会用插值覆盖 `size_class`，目标因此得另存一处。
    pub declared_size: SizeClass,
    /// Declared box edges, owned by the node rather than buried in container params.
    /// 声明的盒边距，归节点所有，而不是埋在容器参数里。
    pub box_model: BoxModel,
    /// Narrowest size the content allows, from the last measure pass.
    /// 内容允许的最小尺寸，来自上一趟测量。
    pub min_content: Size,
    /// Size the content wants when nothing constrains it.
    /// 不受约束时内容想要的尺寸。
    pub max_content: Size,
    /// Size of the content inside a scroll container, for its scrollbars.
    /// 滚动容器内内容的尺寸，供滚动条使用。
    pub scroll_extent: Size,
    /// Result of the last layout pass.
    /// 上一次布局结果。
    pub rect: Rect,
    /// Whether the last measure stacked this flow container along its cross axis.
    /// 上一次测量是否把这个流容器改成了沿交叉轴堆叠。
    pub flow_vertical: bool,
    /// Visual-only displacement; layout and `rect` ignore it.
    /// 仅视觉的位移；布局与 `rect` 都不受它影响。
    ///
    /// Dragging must not reflow: a per-frame relayout puts the hit box one frame behind
    /// the pixels, which reads as jitter at speed.
    /// 拖拽不得重排：每帧重排会让命中盒落后像素一帧，高速拖动时表现为抖动。
    pub offset: crate::geom::Point,
    /// How far this node has arrived, 0 at its `enter` start and 1 once settled.
    /// 本节点已到达的程度：`enter` 起点为 0，落定为 1。
    pub presence: f32,
    /// Group opacity factor of a node still entering, 1 once settled.
    /// 仍在入场的节点的组不透明度因子，落定为 1。
    pub presence_alpha: f32,
    /// Painted displacement of a node still entering; folded into [`Node::visual_rect`].
    /// 仍在入场的节点的绘制位移；计入 [`Node::visual_rect`]。
    pub presence_shift: crate::geom::Point,
    /// Painted scale about this node's centre; 1 when settled.
    /// 绕本节点中心的绘制缩放；落定时为 1。
    pub presence_scale: f32,
    /// This node's own declared cursor shape; the resolved one walks up the ancestors.
    /// 本节点声明的光标形状；解析后的形状沿祖先链上找。
    pub cursor: Option<crate::cursor::CursorShape>,
    /// What interactions this node subscribes to, as declared this frame.
    /// 本节点订阅的交互类别，取自本帧声明。
    pub sense: crate::sense::Sense,
    /// Inert, folded from this declaration and every ancestor's.
    /// 惰性，由本声明与所有祖先折入。
    pub disabled: bool,
    /// Grid placement and cell alignment declared by this node.
    /// 本节点声明的网格位置与单元格对齐。
    pub grid: GridItem,
    /// Positioning scheme, insets and stacking order.
    /// 定位方案、内边距与层叠顺序。
    pub placement: crate::layout::Placement,
    /// Environment in force at this node: the nearest declared one on the path from root.
    /// 本节点生效的环境：从根到此处最近的一层声明。
    pub env: Option<Arc<dyn std::any::Any + Send + Sync>>,
    /// Clip inherited from the clipping ancestors; a visible container adds nothing.
    /// 从声明了裁剪的祖先继承的裁剪；可见容器不参与。
    pub mask: Rect,
    /// The same clip with scroll viewports left out: they translate content, not hide it.
    /// 同一份裁剪，但不计滚动视口：视口平移内容，并未把内容藏起来。
    pub focus_mask: Rect,
    /// How far this node may paint outside `rect` (halo/shadow/grips).
    /// 本节点可画到 `rect` 之外的距离（光晕/阴影/控制柄）。
    pub ink_margin: Insets,
    /// Wrap width layout measured text with; the painter must reuse it.
    /// 布局测量文本所用的换行宽度；绘制端必须复用。
    pub wrap_width: f32,
    /// Lines layout wrapped this text node into; paint draws exactly these.
    /// 布局为该文本节点断出的行；绘制端照它落笔。
    pub inline: Option<Rc<crate::text::InlineLayout>>,
    /// First baseline from the node's top edge; 0 for anything without text on its first line.
    /// 首基线，从节点顶边量起；首行没有文字时为 0。
    pub baseline: f32,
    /// True when layout must be redone for this subtree.
    /// 该子树需要重做布局。
    pub dirty: bool,
    /// The last measurement, reused while `dirty` is false and the constraints repeat.
    /// 上一次的测量；`dirty` 为假且约束重复时复用。
    pub last_measure: Option<crate::layout::LastMeasure>,
    /// Paint-only shapes, in this node's own space.
    /// 纯绘制形状，位于本节点自身坐标系。
    pub shapes: Vec<crate::draw::Shape>,
    /// Position among its siblings in the declaration, which is also the paint order.
    /// 在声明中的同层次序，同时也是绘制顺序。
    pub order: u32,
    /// True when the node existed last frame too.
    /// 上一帧也存在。
    pub reused: bool,
    /// Kept alive only to leave: out of layout, out of the live tree, painted above it.
    /// 仅为离开而保活：不在布局里，不在活动树里，绘制在其上。
    pub held: bool,
    /// The declaration this node was last applied from, kept to detect a cached subtree.
    /// 上次应用到本节点的声明，用来识别复用的缓存子树。
    pub src: Option<Rc<Decl>>,
}

impl Node {
    /// Rect grown by `ink_margin`: the area this node can actually affect.
    /// 按 `ink_margin` 外扩后的矩形：本节点实际能影响的区域。
    pub fn ink_rect(&self) -> Rect {
        let base = self.ink_margin.expand(self.rect).translate(self.paint_offset());
        // A shape may paint outside the node's own box; damage must cover it too.
        // 形状可能画到节点盒子之外，脏区也必须覆盖到。
        let box_rect = self.visual_rect();
        self.shapes.iter().fold(base, |acc, s| acc.union(s.bounds(box_rect)))
    }

    /// Displacement applied at paint and hit time only, never to layout.
    /// 只在绘制与命中时施加的位移，绝不进入布局。
    pub fn paint_offset(&self) -> crate::geom::Point {
        self.offset + self.presence_shift
    }

    /// The rect as drawn and hit tested, i.e. with the visual offset applied.
    /// 实际绘制与命中所用的矩形，即已应用视觉偏移。
    pub fn visual_rect(&self) -> Rect {
        self.rect.translate(self.paint_offset())
    }
}

/// A declaration produced by user code each frame.
/// 用户代码每帧产出的声明。
///
/// Equality is by identity, not by address: two declarations that carry the same env are
/// equal even though `dyn Any` has no `PartialEq` of its own.
/// 相等按同一性而非地址：携带同一个 env 的两份声明相等，尽管 `dyn Any` 本身没有
/// `PartialEq`。
#[derive(Clone, Debug)]
pub struct Decl {
    pub id: Id,
    pub kind: NodeKind,
    pub data: NodeData,
    /// Box edges of any node, leaf included: a text run takes a margin like a container does.
    /// 任何节点的盒边距，叶子也不例外：一段文本也能像容器那样带外边距。
    pub box_model: crate::layout::BoxModel,
    pub size_class: SizeClass,
    /// Visible extent beyond `rect`. Non-zero for shadows, focus rings, halos.
    /// 超出 `rect` 的可见范围。阴影/焦点环/光晕需要非零。
    pub ink_margin: Insets,
    /// Visual-only displacement applied at paint and hit time; layout ignores it.
    /// 仅视觉的位移，在绘制与命中时应用；布局忽略它。
    pub offset: crate::geom::Point,
    /// Shape shown while hovered; `None` defers to an ancestor. Explicit `Arrow` means "stop here".
    /// 悬停时显示的形状；`None` 交给祖先。显式 `Arrow` 表示「到此为止」。
    pub cursor: Option<crate::cursor::CursorShape>,
    /// What interactions this node subscribes to; the router reads only this.
    /// 本节点订阅的交互类别；路由只读它。
    pub sense: crate::sense::Sense,
    /// Inert: neither this node nor its subtree takes input, focus or hover.
    /// 惰性：本节点及其子树都不接受输入、焦点或悬停。
    ///
    /// Inherited downward, like a disabled fieldset: a child cannot re-enable itself.
    /// 向下继承，如同被禁用的 fieldset：子节点无法自行恢复。
    pub disabled: bool,
    /// Where this item sits in a grid parent, and how it aligns inside its cell.
    /// 本项在网格父容器里的位置，以及在单元格内的对齐。
    pub grid: GridItem,
    /// Positioning scheme, insets and stacking order; `static` by default.
    /// 定位方案、内边距与层叠顺序；默认为 `static`。
    pub placement: crate::layout::Placement,
    /// Opaque environment for this subtree; a `scoped` node replaces it, children inherit.
    /// 本子树的不透明环境；`scoped` 节点替换它，子节点继承。
    ///
    /// `ui-core` never interprets it: only the style layer knows what is inside. It lives on
    /// the declaration so the engine can hand it to every control without the app threading
    /// it by hand.
    /// `ui-core` 从不解释它，只有风格层知道里面是什么。它放在声明上，使引擎能把它交给
    /// 每个控件，而不必由 app 手工逐层传递。
    pub env: Option<Arc<dyn std::any::Any + Send + Sync>>,
    /// Paint-only shapes, in this node's own space; see [`crate::draw::Shape`].
    /// 纯绘制形状，位于本节点自身坐标系；见 [`crate::draw::Shape`]。
    pub shapes: Vec<crate::draw::Shape>,
    /// Shared so a cached subtree can be spliced into a new parent without copying it.
    /// 共享存放：缓存的子树可以拼进新父节点而不必拷贝。
    pub children: Vec<Rc<Decl>>,
}

impl Decl {
    /// Everything this declaration says about itself, leaving the children out: the shell a
    /// container builds from app input, which the engine has no fact to replay against.
    /// 本声明关于自身的一切，不含子节点：容器据 app 输入构建的外壳，
    /// 引擎没有可重放的事实能校验它。
    ///
    /// Stricter than [`PartialEq`], which skips `disabled`: for reuse a false "same" is
    /// a stale subtree, so every field that can move a pixel has to match.
    /// 比 [`PartialEq`] 更严：后者不比 `disabled`。复用上了错的「相同」会留下陈旧子树，
    /// 因此每个能改变像素的字段都要对上。
    pub fn own_eq(&self, other: &Self) -> bool {
        let same_env = match (&self.env, &other.env) {
            (None, None) => true,
            (Some(a), Some(b)) => Arc::ptr_eq(a, b),
            _ => false,
        };
        same_env
            && self.id == other.id
            && self.kind == other.kind
            && self.data == other.data
            && self.box_model == other.box_model
            && self.size_class == other.size_class
            && self.ink_margin == other.ink_margin
            && self.offset == other.offset
            && self.cursor == other.cursor
            && self.sense == other.sense
            && self.disabled == other.disabled
            && self.grid == other.grid
            && self.placement == other.placement
            && self.shapes == other.shapes
    }
}

impl PartialEq for Decl {
    fn eq(&self, other: &Self) -> bool {
        let same_env = match (&self.env, &other.env) {
            (None, None) => true,
            (Some(a), Some(b)) => Arc::ptr_eq(a, b),
            _ => false,
        };
        same_env
            && self.id == other.id
            && self.kind == other.kind
            && self.data == other.data
            && self.box_model == other.box_model
            && self.size_class == other.size_class
            && self.ink_margin == other.ink_margin
            && self.offset == other.offset
            && self.cursor == other.cursor
            && self.sense == other.sense
            && self.grid == other.grid
            && self.placement == other.placement
            && self.shapes == other.shapes
            && self.children.len() == other.children.len()
            // Pointer equality short-circuits the deep compare for cached subtrees.
            // 指针相等时短路，缓存的子树不必逐层深比较。
            && self
                .children
                .iter()
                .zip(other.children.iter())
                .all(|(a, b)| Rc::ptr_eq(a, b) || a == b)
    }
}

impl Decl {
    pub fn container(id: Id, kind: NodeKind) -> Self {
        Self {
            id,
            kind,
            data: NodeData::Container(ContainerParams::default()),
            box_model: crate::layout::BoxModel::default(),
            shapes: Vec::new(),
            size_class: SizeClass::hug(0.0, 0.0),
            ink_margin: Insets::ZERO,
            offset: crate::geom::Point::new(0.0, 0.0),
            cursor: None,
            sense: crate::sense::Sense::NONE,
            disabled: false,
            grid: GridItem::default(),
            placement: crate::layout::Placement::default(),
            env: None,
            children: Vec::new(),
        }
    }

    /// Take this node out of the flow and place it against its containing block.
    /// 把本节点移出流，相对其包含块定位。
    pub fn absolute(mut self) -> Self {
        self.placement.position = crate::layout::Position::Absolute;
        self
    }

    /// Keep this node's slot and shift only its paint and hit by the insets.
    /// 保留本节点的位置，仅按内边距平移绘制与命中。
    pub fn relative(mut self) -> Self {
        self.placement.position = crate::layout::Position::Relative;
        self
    }

    /// Like `absolute`, but the containing block is always the root box.
    /// 同 `absolute`，但包含块固定为根盒子。
    pub fn fixed(mut self) -> Self {
        self.placement.position = crate::layout::Position::Fixed;
        self
    }

    /// Declare the inset sides; an [`Insets::AUTO`] side is left to the solver.
    /// 声明内边距各边；取 [`Insets::AUTO`] 的一侧交给求解器。
    ///
    /// Pixel insets convert; a [`LenInsets`](crate::layout::LenInsets) may also carry
    /// percentages, resolved against the containing block.
    /// 像素内边距会转换；[`LenInsets`](crate::layout::LenInsets) 还可带百分比，
    /// 相对包含块解析。
    pub fn inset(mut self, inset: impl Into<crate::layout::LenInsets>) -> Self {
        self.placement.inset = inset.into();
        self
    }

    /// Stacking order among positioned siblings; higher paints later and hits first.
    /// 定位兄弟之间的层叠顺序；值大者后绘制、先命中。
    pub fn z(mut self, z: i32) -> Self {
        self.placement.z = z;
        self
    }

    /// Anchor this node as an overlay: the engine places it from `placement`, paints it above
    /// the tree and lets it escape every clipping ancestor. Insets are ignored.
    /// 把本节点锚定为浮层：引擎按 `placement` 摆放、画在整棵树之上，并让它越过所有祖先裁剪；
    /// 内边距被忽略。
    pub fn overlay(mut self, placement: crate::layout::OverlayPlacement) -> Self {
        self.placement.position = crate::layout::Position::Absolute;
        self.placement.overlay = Some(placement);
        self
    }

    /// Lift this node: it keeps its layout slot but paints at the top layer, unclipped.
    /// 抬起本节点：保留布局槽位，但改在顶层绘制且不受祖先裁剪。
    pub fn lifted(mut self) -> Self {
        self.placement.lift = true;
        self
    }

    /// Place this item in its grid parent; spans default to one cell.
    /// 把本项放到网格父容器的指定位置；跨度默认为一格。
    pub fn grid_area(mut self, row: u32, col: u32, row_span: u32, col_span: u32) -> Self {
        self.grid.area = Some(crate::layout::GridArea {
            row,
            col,
            row_span: row_span.max(1),
            col_span: col_span.max(1),
        });
        self
    }

    /// Cells an auto-flowed item takes; the default is one.
    /// 自动流入项目占用的格数；默认一格。
    pub fn grid_span(mut self, row_span: u32, col_span: u32) -> Self {
        self.grid.span = (row_span.max(1), col_span.max(1));
        self
    }

    /// Vertical alignment inside a grid cell; the default stretches.
    /// 网格单元格内的纵向对齐；默认拉伸。
    pub fn align_self(mut self, align: crate::layout::Align) -> Self {
        self.grid.align = Some(align);
        self
    }

    /// Horizontal alignment inside a grid cell; the default stretches.
    /// 网格单元格内的横向对齐；默认拉伸。
    pub fn justify_self(mut self, align: crate::layout::Align) -> Self {
        self.grid.justify = Some(align);
        self
    }

    /// Give a grid container its track template.
    /// 给网格容器设置轨道模板。
    pub fn tracks(mut self, tracks: crate::layout::TrackList) -> Self {
        if let Some(p) = self.data.params_mut() {
            p.tracks = Some(Box::new(tracks));
        }
        self
    }

    /// Displace this node visually without reflowing layout.
    /// 在不重排布局的情况下视觉位移本节点。
    pub fn offset(mut self, x: f32, y: f32) -> Self {
        self.offset = crate::geom::Point::new(x, y);
        self
    }

    /// Shape the pointer takes while this node is hovered.
    /// 本节点被悬停时指针的形状。
    pub fn cursor(mut self, shape: crate::cursor::CursorShape) -> Self {
        self.cursor = Some(shape);
        self
    }

    /// Put this declaration's subtree inside an opaque environment.
    /// 把本声明的子树放入一个不透明环境。
    ///
    /// Children inherit it because the engine folds the nearest one down the tree.
    /// 子节点继承它，因为引擎会把最近的一层沿树折下去。
    pub fn env(mut self, env: Arc<dyn std::any::Any + Send + Sync>) -> Self {
        self.env = Some(env);
        self
    }

    /// Subscribe to interactions; compile the set with `|` where the node is declared.
    /// 订阅若干交互；在声明处用 `|` 组合这个集合。
    pub fn sense(mut self, sense: crate::sense::Sense) -> Self {
        self.sense = sense;
        self
    }

    /// Make this node and its whole subtree inert.
    /// 使本节点及其整个子树变为惰性。
    pub fn disabled(mut self, yes: bool) -> Self {
        self.disabled = yes;
        self
    }

    pub fn padding(mut self, p: Insets) -> Self {
        self.box_model.padding = p;
        self
    }

    /// Outside the border box; a non-finite side is `auto`, meaningful only out of flow.
    /// 边框盒之外；非有限的一侧表示 `auto`，只在流外有意义。
    pub fn margin(mut self, m: Insets) -> Self {
        self.box_model.margin = m;
        self
    }

    /// The margin a flow parent uses when it stacked this child instead of lining it up.
    /// 流父容器改为堆叠本子节点时使用的边距。
    pub fn margin_alt(mut self, m: Insets) -> Self {
        self.box_model.margin_alt = Some(m);
        self
    }

    /// Make this `Row` stack along the column axis when its children no longer fit.
    /// 让这个 `Row` 在子节点并排放不下时改为沿列轴堆叠。
    pub fn switch_axis(mut self, switch: crate::layout::AxisSwitch) -> Self {
        if let Some(c) = self.data.params_mut() {
            c.switch_axis = Some(switch);
        }
        self
    }

    /// Cut the content at the box on both axes, and let the wheel scroll the main one.
    /// 两轴都在盒子处裁切内容，并允许滚轮沿主轴滚动。
    ///
    /// Sugar for main-axis [`Overflow::Scroll`] plus cross-axis `Hidden`: `Row` scrolls `x`,
    /// anything else `y`. Like CSS, the cross axis still clips.
    /// 主轴 [`Overflow::Scroll`] 加交叉轴 `Hidden` 的糖：`Row` 滚 `x`，其余滚 `y`。
    /// 与 CSS 一样，交叉轴仍然裁切。
    pub fn scrollable(mut self) -> Self {
        let horizontal = self.kind == NodeKind::Row;
        if let NodeData::Container(p) = &mut self.data {
            if horizontal {
                p.clip.x = crate::layout::Overflow::Scroll;
                p.clip.y = crate::layout::Overflow::Hidden;
            } else {
                p.clip.y = crate::layout::Overflow::Scroll;
                p.clip.x = crate::layout::Overflow::Hidden;
            }
        }
        self
    }

    /// Declare per-axis overflow policy; clipping is opt-in.
    /// 逐轴声明溢出策略；裁剪需显式选择。
    pub fn clip(mut self, clip: crate::layout::Clip) -> Self {
        if let NodeData::Container(p) = &mut self.data {
            p.clip = clip;
        }
        self
    }

    /// Scroll the content left by `x` logical units; negative scrolls right.
    /// 把内容向左滚动 `x` 逻辑单位；负值向右。
    pub fn scroll_x(mut self, x: f32) -> Self {
        if let NodeData::Container(p) = &mut self.data {
            p.scroll_x = if x.is_finite() { x } else { 0.0 };
        }
        self
    }

    /// Scroll the content up by `y` logical units; negative scrolls down.
    /// 把内容向上滚动 `y` 逻辑单位；负值向下。
    pub fn scroll_y(mut self, y: f32) -> Self {
        if let NodeData::Container(p) = &mut self.data {
            p.scroll_y = if y.is_finite() { y } else { 0.0 };
        }
        self
    }

    /// Group opacity for the subtree, clamped to 0..=1.
    /// 子树的组不透明度，钳制到 0..=1。
    pub fn opacity(mut self, o: f32) -> Self {
        if let NodeData::Container(p) = &mut self.data {
            p.opacity = if o.is_finite() { o.clamp(0.0, 1.0) } else { 1.0 };
        }
        self
    }

    /// Travel to a new *fixed* size instead of jumping; the engine interpolates before layout.
    /// 固定尺寸变化时走过去而不是跳过去；引擎在布局前插值。
    pub fn transition_size(mut self, spec: crate::anim::AnimSpec) -> Self {
        if let NodeData::Container(p) = &mut self.data {
            p.size_transition = Some(spec);
        }
        self
    }

    /// Paint this node from `enter`'s values up to its declared ones when it first appears.
    /// 本节点首次出现时，从 `enter` 的起始值补到声明值。
    pub fn enter(mut self, enter: Presence) -> Self {
        if let NodeData::Container(p) = &mut self.data {
            p.enter = Some(enter);
        }
        self
    }

    /// Keep this node alive and painted while it travels to `exit` after it is undeclared.
    /// 声明不再提到它之后，本节点保活并绘制，直到走到 `exit`。
    pub fn exit(mut self, exit: Presence) -> Self {
        if let NodeData::Container(p) = &mut self.data {
            p.exit = Some(exit);
        }
        self
    }

    /// Keep this subtree's pixels in a target of its own across frames; it repaints only
    /// when a change lands inside it.
    /// 把本子树的像素跨帧保留在自有目标里；只有变化落在其中时才重绘。
    pub fn offscreen(mut self) -> Self {
        if let NodeData::Container(p) = &mut self.data {
            p.offscreen = true;
        }
        self
    }

    /// Splat press ink where a press lands on this node or its descendants.
    /// 按在本节点或其子孙上时，在落点泼出的按压墨迹。
    pub fn press_ink(mut self, ink: Option<crate::draw::PressInk>) -> Self {
        if let Some(p) = self.data.params_mut() {
            p.press_ink = ink;
        }
        self
    }

    /// Ask the engine to draw a focus adorner around this node while it holds visible focus.
    /// 要求引擎在本节点持有可见焦点时，围绕它绘制焦点装饰。
    pub fn focus_visual(mut self, visual: Option<crate::draw::FocusVisual>) -> Self {
        if let Some(p) = self.data.params_mut() {
            p.focus_visual = visual;
        }
        self
    }

    /// Declare this node a Tab stop although its ring is painted by a child.
    /// 声明本节点是 Tab 停靠点，尽管焦点环由子节点绘制。
    pub fn focus_stop(mut self, stop: bool) -> Self {
        if let Some(p) = self.data.params_mut() {
            p.focus_stop = stop;
        }
        self
    }

    /// Name the descendant a popup should focus when it opens, instead of its first stop.
    /// 指定浮层打开时聚焦的后代，而不是它的第一个停靠点。
    pub fn focus_initial(mut self, id: crate::Id) -> Self {
        if let Some(p) = self.data.params_mut() {
            p.focus_initial = Some(id);
        }
        self
    }

    /// State this node's own curve, which then outranks whatever it paints this frame.
    /// 声明本节点自身的曲线，它此后优先于本帧画出的任何形状。
    pub fn corners(mut self, corners: crate::geom::Corners) -> Self {
        if let Some(p) = self.data.params_mut() {
            p.corners = Some(corners);
        }
        self
    }

    /// Lay this text out on one line, overflowing its box instead of wrapping.
    /// 让本节点的文本排成一行，溢出盒子而不换行。
    pub fn nowrap(mut self) -> Self {
        if let NodeData::Text { nowrap, .. } = &mut self.data {
            *nowrap = true;
        }
        self
    }

    /// Make this node a modal surface over `target`, whatever position the tree gives it.
    /// 让本节点成为盖在 `target` 之上的模态表面，无论树给它什么位置。
    pub fn modal(mut self, target: ModalTarget) -> Self {
        if let Some(p) = self.data.params_mut() {
            p.modal = Some(target);
        }
        self
    }

    /// Let a `Proximate` modal resolve to this container.
    /// 允许 `Proximate` 模态解析到本容器。
    pub fn modal_host(mut self) -> Self {
        if let Some(p) = self.data.params_mut() {
            p.modal_host = true;
        }
        self
    }

    /// Bind a chord on this node; the engine reports `Change::Shortcut` when it fires.
    /// 在本节点上绑定一个组合键；触发时引擎上报 `Change::Shortcut`。
    pub fn shortcut(
        mut self,
        chord: crate::shortcut::KeyChord,
        id: crate::shortcut::ShortcutId,
    ) -> Self {
        if let Some(p) = self.data.params_mut() {
            p.shortcuts.push((chord, id));
        }
        self
    }

    /// Rows this node offers on a secondary click; the engine shows them and reports the pick.
    /// 本节点在右键时提供的行；引擎显示它们并上报选中的那一行。
    pub fn menu(mut self, items: Vec<crate::menu::MenuItem>) -> Self {
        if let Some(p) = self.data.params_mut() {
            p.menu = items;
        }
        self
    }

    /// Make this node a text input holding `value`; the engine reports edits, the app keeps
    /// the value and passes the new one back next frame.
    /// 使本节点成为持有 `value` 的文本输入；引擎上报编辑，应用保留值并在下一帧传回新值。
    pub fn text_input(mut self, value: impl Into<String>) -> Self {
        if let Some(p) = self.data.params_mut() {
            p.text_input = Some(value.into());
        }
        self
    }

    /// Declare this input's `Shift+Enter` as a hard line break; without it the chord
    /// activates, like Enter does. Only an input with a buffer is affected.
    /// 声明本输入的 `Shift+Enter` 为强制换行；不声明时该组合键与 Enter 一样走激活。
    /// 只影响已持有缓冲的输入。
    pub fn text_input_multiline(mut self, multiline: bool) -> Self {
        if let Some(p) = self.data.params_mut() {
            p.text_input_multiline = multiline;
        }
        self
    }

    /// Effect chain for the whole subtree; any effect forces an offscreen layer.
    /// 作用于整个子树的效果链；任一效果都会强制走离屏层。
    /// Fill colour of the node's own box shape, if it has one.
    /// 节点自身盒子形状的填充色，若有。
    pub fn fill(&self) -> Option<crate::geom::Color> {
        self.shapes.iter().find_map(|s| match s {
            crate::draw::Shape::Box { fill, .. } => Some(*fill),
            _ => None,
        })
    }

    /// The node's own box shape, created on first use and always painted first.
    /// 节点自身的盒子形状，首次使用时创建，且总是最先绘制。
    fn box_shape(&mut self) -> &mut crate::draw::Shape {
        let at = self
            .shapes
            .iter()
            .position(|s| matches!(s, crate::draw::Shape::Box { .. }));
        let at = at.unwrap_or_else(|| {
            self.shapes.insert(
                0,
                crate::draw::Shape::Box {
                    corners: Corners::ZERO,
                    fill: crate::geom::Color::TRANSPARENT,
                    gradient: None,
                    border: None,
                    shadow: None,
                    image: None,
                },
            );
            0
        });
        &mut self.shapes[at]
    }

    /// Attach paint-only shapes, appended in paint order; the box shape always stays first.
    /// 附加纯绘制形状，按绘制顺序追加；盒子形状始终排在最前。
    pub fn shapes(mut self, shapes: Vec<crate::draw::Shape>) -> Self {
        self.shapes.extend(shapes);
        self
    }

    pub fn effects(mut self, chain: Vec<crate::effect::Effect>) -> Self {
        if let NodeData::Container(p) = &mut self.data {
            p.effects = chain;
        }
        self
    }

    pub fn blur(self, radius: u32, sigma: f32) -> Self {
        self.effects(vec![crate::effect::Effect::blur(radius, sigma)])
    }

    /// Blur what lies behind this node, so its translucent fill reads as frosted glass.
    /// 模糊本节点身后的内容，使其半透明填充看起来像磨砂玻璃。
    pub fn backdrop_blur(mut self, sigma: f32) -> Self {
        if let NodeData::Container(p) = &mut self.data {
            p.backdrop_blur = Some(BackdropBlur::css(sigma));
        }
        self
    }

    /// Cast a soft shadow; `level` follows WinUI's elevation ramp.
    /// 投下柔和阴影；`level` 沿用 WinUI 的立面梯度。
    pub fn elevation(mut self, level: u8) -> Self {
        if let crate::draw::Shape::Box { shadow, .. } = self.box_shape() {
            *shadow = Some(ShadowSpec::elevation(level));
        }
        self
    }

    /// Draw a registered texture into this node's box, under its children.
    /// 把已登记的纹理画进本节点盒子，位于子节点之下。
    pub fn background_image(mut self, id: u64, fit: ImageFit) -> Self {
        if let crate::draw::Shape::Box { image, .. } = self.box_shape() {
            *image = Some(ImageSpec { id, fit });
        }
        self
    }

    /// Name the material that shades this node's blurred backdrop.
    /// 指定给本节点模糊背景着色的材质。
    pub fn backdrop_material(mut self, material: crate::draw::BackdropMaterial) -> Self {
        if let NodeData::Container(p) = &mut self.data
            && let Some(blur) = p.backdrop_blur.as_mut() {
                blur.material = material;
            }
        self
    }

    pub fn gap(mut self, g: f32) -> Self {
        if let Some(c) = self.data.params_mut() {
            c.gap = g;
        }
        self
    }

    /// How much cross-axis space this container hands each child: 0 hugs, 1 stretches.
    /// 本容器给每个子节点多少交叉空间：0 紧贴，1 撑满。
    pub fn cross_align(mut self, a: f32) -> Self {
        if let Some(c) = self.data.params_mut() {
            c.cross_align = a;
        }
        self
    }

    /// Where this container parks the children in their cross-axis slack; 0.5 centres.
    /// 本容器把子节点放在交叉剩余空间的哪里；0.5 居中。
    pub fn cross_pos(mut self, a: f32) -> Self {
        if let Some(c) = self.data.params_mut() {
            c.cross_pos = a;
        }
        self
    }

    /// Centre a `Stack`'s children in its content box on both axes: how an icon sits in a
    /// slot larger than itself, without padding arithmetic.
    /// 把 `Stack` 的子节点在内容盒里两轴居中：图标落在比自身大的槽位里时就这样摆，
    /// 不必用内衬做算术。
    pub fn stack_align(mut self, align: crate::layout::OverlayAlign) -> Self {
        if let Some(c) = self.data.params_mut() {
            c.stack_align = (align, align);
        }
        self
    }

    /// The same per axis: a bar sits at the bottom centre without offset arithmetic.
    /// 同上，逐轴给出：条在底部居中，不必用偏移做算术。
    pub fn stack_align_axes(
        mut self,
        x: crate::layout::OverlayAlign,
        y: crate::layout::OverlayAlign,
    ) -> Self {
        if let Some(c) = self.data.params_mut() {
            c.stack_align = (x, y);
        }
        self
    }

    /// Give a container a background box.
    /// 给容器加一个背景盒。
    /// Attach a gradient to this box; the solid fill stays as the fallback.
    /// 给这个盒子附加渐变；实色填充仍作为回落。
    pub fn gradient(
        mut self,
        from: crate::geom::Color,
        to: crate::geom::Color,
        axis: crate::draw::GradientAxis,
    ) -> Self {
        if let crate::draw::Shape::Box { gradient, .. } = self.box_shape() {
            *gradient = Some(crate::draw::Gradient::new(from, to, axis));
        }
        self
    }

    pub fn background(mut self, fill: crate::geom::Color, radius: Corners) -> Self {
        if let crate::draw::Shape::Box {
            fill: f, corners: c, ..
        } = self.box_shape()
        {
            *f = fill;
            *c = radius;
        }
        self
    }

    /// Draw the stroke as a gradient across the box; the near stop is also its fallback.
    /// 把描边画成横跨盒子的渐变；近端色同时作为回落色。
    pub fn border_gradient(mut self, gradient: crate::draw::Gradient, width: f32) -> Self {
        let corners = match self.box_shape() {
            crate::draw::Shape::Box { corners, .. } => *corners,
            _ => Corners::ZERO,
        };
        self.shapes.push(crate::draw::Shape::Outline {
            corners,
            colour: gradient.from,
            gradient: Some(gradient),
            width,
            gap: None,
        });
        self
    }

    /// Add a border to the background box.
    /// 给背景盒加边框。
    pub fn border(mut self, color: crate::geom::Color, width: f32) -> Self {
        if let crate::draw::Shape::Box { border, .. } = self.box_shape() {
            *border = Some((color, width));
        }
        self
    }

    pub fn ink(mut self, m: Insets) -> Self {
        self.ink_margin = m;
        self
    }

    pub fn size(mut self, sc: SizeClass) -> Self {
        self.size_class = sc;
        self
    }

    pub fn child(mut self, c: impl Into<Rc<Decl>>) -> Self {
        self.children.push(c.into());
        self
    }

    pub fn children(mut self, cs: impl IntoIterator<Item = impl Into<Rc<Decl>>>) -> Self {
        self.children.extend(cs.into_iter().map(Into::into));
        self
    }

    /// The node id a named slot takes under this container.
    /// 命名槽在本容器下占用的节点 id。
    pub fn slot_id(&self, name: crate::slot::SlotName) -> Id {
        crate::slot::slot_id(self.id, name)
    }

    /// Fill one named slot with a bare node; a second fill of the same name replaces it.
    /// 用一个裸节点填充命名槽；同名再填会替换它。
    pub fn slot(
        self,
        name: crate::slot::SlotName,
        content: impl Into<Rc<Decl>>,
    ) -> Self {
        self.slot_with(name, Decl::container(Id::default(), NodeKind::Stack), content)
    }

    /// Fill one named slot inside `frame`, the container's own wrapper.
    /// 用容器自己的外壳 `frame` 填充命名槽。
    ///
    /// The frame's id is replaced by the derived slot id, so a slot's identity never follows
    /// its content; the content is appended inside the frame's own children.
    /// 外壳 id 被换成派生的槽 id，因此槽的身份绝不随内容变化；内容追加在外壳自己的子节点之后。
    pub fn slot_with(
        mut self,
        name: crate::slot::SlotName,
        mut frame: Decl,
        content: impl Into<Rc<Decl>>,
    ) -> Self {
        frame.id = self.slot_id(name);
        frame.children.push(content.into());
        let at = self.children.iter().position(|c| c.id == frame.id);
        let frame = Rc::new(frame);
        match at {
            Some(i) => self.children[i] = frame,
            None => self.children.push(frame),
        }
        self
    }
}

/// Difference produced by applying a declaration tree.
/// 应用声明树产生的差分。
#[derive(Debug, Default, PartialEq, Eq)]
pub struct ApplyStats {
    pub created: usize,
    pub reused: usize,
    pub retired: usize,
}

/// One parent's children: declaration order for painting, and a map for sibling lookup.
/// 一个父节点的子节点：绘制用的声明顺序，以及供同层查找的映射。
#[derive(Debug, Default)]
struct Siblings {
    /// Sorted by each node's declaration position at the end of every apply.
    /// 每次 apply 结束时按各节点的声明位置排好序。
    order: Vec<NodeId>,
    /// The same children by `(z, declaration order)`, sorted once per apply so the walks,
    /// hit rebuild and paint can borrow the answer instead of sorting a copy each.
    /// 同一批子节点按 `(z, 声明序)` 排好，每次 apply 排一次，遍历/命中/绘制直接借用。
    paint: Vec<NodeId>,
    by_id: FastMap<Id, NodeId>,
}

/// Effective stacking order among siblings: only a positioned node carries its `z`.
/// 同层间的有效层叠顺序：只有定位节点携带自己的 `z`。
fn z_of(nodes: &[Option<Node>], nid: NodeId) -> i32 {
    nodes
        .get(nid.index())
        .and_then(|slot| slot.as_ref())
        .map(|n| {
            if n.placement.position == crate::layout::Position::Static {
                0
            } else {
                n.placement.z
            }
        })
        .unwrap_or(0)
}

/// The retained tree.
/// 保留树。
#[derive(Debug, Default)]
pub struct Tree {
    nodes: Vec<Option<Node>>,
    /// Generation per slot; bumped on retire so stale handles read as absent.
    /// 每个槽位的代次；回收时递增，使过期句柄读出"不存在"。
    generations: Vec<u32>,
    free: Vec<u32>,
    live: Vec<NodeId>,
    /// `Id` -> node, scoped per parent to keep sibling lookups cheap.
    /// `Id` -> 节点，按父节点分域，便于同层查找。
    by_parent: FastMap<Option<NodeId>, Siblings>,
    /// `Id` -> node over the whole tree, rebuilt once per apply: the general lookup runs
    /// for every element every frame, so it must not scan the sibling maps.
    /// 全树的 `Id` -> 节点，每次 apply 重建一次：通用查找每帧对每个元素都会跑，
    /// 不能去扫各层的同层映射。
    by_id: FastMap<Id, NodeId>,
    root: Option<NodeId>,
    /// Marks the whole tree as needing layout.
    /// 整棵树需要布局。
    layout_dirty: bool,
    /// Nodes whose values the engine interpolates this frame, in apply order.
    /// 本帧由引擎插值的节点，按应用顺序。
    animated: Vec<NodeId>,
    /// Nodes that appeared this frame declaring `enter`, in apply order.
    /// 本帧带着 `enter` 出现的节点，按应用顺序。
    appeared: Vec<NodeId>,
    /// Roots of subtrees kept alive past their declaration so they can leave visibly.
    /// 声明结束后仍保活、以便看得见地离开的子树根。
    held: Vec<NodeId>,
}

impl Tree {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn root(&self) -> Option<NodeId> {
        self.root
    }

    /// Nodes whose time-dependent values the engine drives this frame.
    /// 本帧由引擎驱动其时间相关值的节点。
    pub fn animated(&self) -> &[NodeId] {
        &self.animated
    }

    /// Nodes that appeared this frame with an `enter` declaration.
    /// 本帧带着 `enter` 声明出现的节点。
    pub fn appeared(&self) -> &[NodeId] {
        &self.appeared
    }

    /// Subtrees the engine is keeping alive while they leave, painted above the content.
    /// 引擎为看得见的离开而保活的子树，绘制在内容之上。
    pub fn held(&self) -> &[NodeId] {
        &self.held
    }

    /// Whether anything is painting at a presence scale right now.
    /// 此刻是否有节点正按 presence 缩放绘制。
    pub fn presence_scaling(&self) -> bool {
        self.live.iter().any(|nid| {
            self.slot(*nid)
                .is_some_and(|n| (n.presence_scale - 1.0).abs() > 1e-6)
        })
    }

    /// The rect this node is painted in, after the presence scales above it.
    /// 本节点实际绘制所在的矩形，已计入其上各层的 presence 缩放。
    pub fn scaled_visual_rect(&self, nid: NodeId) -> Rect {
        let Some(node) = self.get(nid) else {
            return Rect::ZERO;
        };
        let mut scales = Vec::new();
        // The node's own scale wraps its own box as well as what it contains.
        // 节点自身的缩放同时作用于它自己的盒子与其中的内容。
        if (node.presence_scale - 1.0).abs() > 1e-6 {
            scales.push((node.visual_rect().center(), node.presence_scale));
        }
        let mut cur = node.parent;
        while let Some(p) = cur {
            let Some(parent) = self.slot(p) else {
                break;
            };
            if (parent.presence_scale - 1.0).abs() > 1e-6 {
                scales.push((parent.visual_rect().center(), parent.presence_scale));
            }
            cur = parent.parent;
        }
        let mut visual = node.visual_rect();
        // Outermost first: paint composes the same way, so hits land on the pixels.
        // 由外向内：绘制按同一顺序复合，命中因此落在像素上。
        for (centre, scale) in scales.into_iter().rev() {
            visual = crate::draw::Transform::about(centre, scale).apply_rect(visual);
        }
        visual
    }

    /// Drop a held subtree; the exit has landed and nothing of it should remain.
    /// 丢弃一棵被持有的子树；退场已落定，它不应再留下任何东西。
    pub fn release(&mut self, nid: NodeId) {
        self.held.retain(|n| *n != nid);
        let parent = self.get(nid).and_then(|n| n.parent);
        self.retire_subtree(nid);
        if let Some(p) = parent {
            self.mark_dirty_up(p);
        }
        self.layout_dirty = true;
    }

    pub fn len(&self) -> usize {
        self.live.len()
    }

    pub fn is_empty(&self) -> bool {
        self.live.is_empty()
    }

    /// Fetch a node, or `None` for a stale handle.
    /// 取节点；过期句柄返回 `None`。
    pub fn get(&self, id: NodeId) -> Option<&Node> {
        self.nodes
            .get(id.index())
            .and_then(|s| s.as_ref())
            .filter(|n| n.id != Id::default() || id.generation() == 0)
            .or_else(|| self.slot(id))
    }

    fn slot(&self, id: NodeId) -> Option<&Node> {
        self.nodes.get(id.index()).and_then(|s| s.as_ref())
    }

    pub fn get_mut(&mut self, id: NodeId) -> Option<&mut Node> {
        self.nodes.get_mut(id.index()).and_then(|s| s.as_mut())
    }

    pub fn find_by_id(&self, id: Id) -> Option<NodeId> {
        self.by_id.get(&id).copied()
    }

    pub fn children_of(&self, parent: Option<NodeId>) -> &[NodeId] {
        // Already in declaration order: `rebuild_index` sorts it once per apply. A child added
        // later would otherwise take a later arena slot and paint above its earlier siblings.
        // 已按声明顺序排好：`rebuild_index` 每次 apply 排一次。否则后加入的子节点会因 arena
        // 槽位更大而画在早先的兄弟之上。
        self.by_parent
            .get(&parent)
            .map(|s| s.order.as_slice())
            .unwrap_or(&[])
    }

    /// One child by position, for callers that must mutate the tree while walking it.
    /// 按位置取一个子节点，供遍历时需要改动树的调用方使用。
    pub fn child_at(&self, parent: Option<NodeId>, index: usize) -> Option<NodeId> {
        self.by_parent
            .get(&parent)
            .and_then(|s| s.order.get(index).copied())
    }

    pub fn mark_dirty(&mut self, id: NodeId) {
        self.mark_dirty_up(id);
    }

    /// Mark `id` and every ancestor dirty: a cached measurement only holds while its whole
    /// subtree is unchanged, so a leaf edit invalidates the chain above it.
    /// 标记 `id` 与所有祖先为脏：缓存的测量只在整棵子树未变时成立，叶子改动会让整条链失效。
    pub fn mark_dirty_up(&mut self, id: NodeId) {
        self.layout_dirty = true;
        let mut cur = Some(id);
        while let Some(nid) = cur {
            cur = match self.get_mut(nid) {
                Some(n) => {
                    n.dirty = true;
                    n.parent
                }
                None => None,
            };
        }
    }

    /// Replace the tree contents with `decl`, reusing nodes whose `Id` matches.
    /// 用 `decl` 重建树内容，`Id` 相同的节点复用。
    pub fn apply(&mut self, decl: &Decl) -> ApplyStats {
        let mut stats = ApplyStats::default();
        self.animated.clear();
        self.appeared.clear();
        // Mark everything as "not seen yet"; anything left unseen is retired.
        // 先标记"未见"，遍历结束时仍未见的就是要回收的。
        let live_snapshot = self.live.clone();
        for nid in live_snapshot {
            if let Some(n) = self.get_mut(nid) {
                n.reused = false;
            }
        }
        let root = self.apply_decl(decl, None, None, 0, &mut stats);
        self.root = Some(root);
        // Everything built while applying this tree was built under exactly one scope, the
        // one the caller handed to its build context. A declaration that opened a narrower
        // scope did so after its contents were already resolved, so the two cannot disagree.
        // 应用这棵树时构建的一切都处在同一个作用域下，也就是调用方交给构建上下文的那一个。
        // 开启更窄作用域的声明是在其内容已被解析之后才做的，因此两者不可能不一致。
        // Retire unseen nodes (their ids disappeared from the declaration).
        // 回收未见节点（其 id 已从声明中消失）。
        let unseen: Vec<NodeId> = self
            .live
            .iter()
            .cloned()
            .filter(|nid| {
                self.slot(*nid)
                    .map(|n| !n.reused && !n.held)
                    .unwrap_or(false)
            })
            .collect();
        for nid in unseen {
            // An ancestor that is already leaving holds this node too; retiring it would
            // tear a hole in the subtree that is still being painted.
            // 已在离开的祖先也持有本节点；回收它会在仍在绘制的子树里撕出一个洞。
            if self.slot(nid).is_some_and(|n| n.held) {
                continue;
            }
            // A removed child changes what its parent measures, so read the parent first.
            // 去掉子节点会改变父节点测得的尺寸，因此先取出父节点。
            let parent = self.get(nid).and_then(|n| n.parent);
            // A node that declares an exit is kept alive and painted until it lands.
            // 声明了退场的节点保活并绘制，直到落定。
            if self.hold(nid) {
                if let Some(p) = parent {
                    self.mark_dirty_up(p);
                }
                self.layout_dirty = true;
                continue;
            }
            stats.retired += self.retire_subtree(nid);
            if let Some(p) = parent {
                self.mark_dirty_up(p);
            }
        }

        // Normalise the sibling map to only live nodes.
        // 把同层映射规整为仅存活节点。
        self.rebuild_index();
        self.detach_held();

        if stats.created > 0 || stats.retired > 0 {
            self.layout_dirty = true;
        }
        stats
    }

    fn apply_decl(
        &mut self,
        decl: &Decl,
        src: Option<&Rc<Decl>>,
        parent: Option<NodeId>,
        order: u32,
        stats: &mut ApplyStats,
    ) -> NodeId {
        let existing = self
            .by_parent
            .get(&parent)
            .and_then(|s| s.by_id.get(&decl.id))
            .copied();
        // Same `Rc` as last frame means the payload cannot have changed.
        // 与上帧同一个 `Rc`，说明内容不可能变化。
        let same_src = existing.is_some_and(|nid| {
            src.is_some_and(|rc| {
                self.slot(nid)
                    .and_then(|n| n.src.as_ref())
                    .is_some_and(|s| Rc::ptr_eq(s, rc))
            })
        });
        // The scope in force here: this declaration's own, else the parent's. Folding it
        // during apply keeps it available before layout, and parents are visited first.
        // 此处生效的作用域：本声明自带的，否则父节点的。在 apply 期间折入可在布局前就绪，
        // 而父节点总是先被访问。
        let inherited_env = parent
            .and_then(|p| self.get(p))
            .and_then(|n| n.env.clone());

        // Set when this node's own payload changed, so the ancestors' caches go with it.
        // 本节点自身内容变了时置位，祖先的缓存随之失效。
        let mut changed_here = false;
        let nid = match existing {
            Some(nid) => {
                let kind_changed = self.slot(nid).map(|n| n.kind != decl.kind).unwrap_or(true);
                if kind_changed {
                    // Kind change discards the subtree; identity no longer means anything.
                    // 类型变化丢弃整棵子树；身份已无意义。
                    self.retire_subtree(nid);
                    stats.created += 1;
                    let spawned = self.spawn(decl, parent);
                    if let Some(env) = decl.env.clone().or_else(|| inherited_env.clone())
                        && let Some(n) = self.get_mut(spawned) {
                            n.env = Some(env);
                        }
                    spawned
                } else {
                    // Read the inherited flag before taking the mutable borrow of the node.
                    // 在取得节点的可变借用之前先读出继承来的标志。
                    let inherited_disabled = parent
                        .and_then(|p| self.get(p))
                        .map(|p| p.disabled)
                        .unwrap_or(false);
                    let n = self.get_mut(nid).expect("live node");
                    n.reused = true;
                    n.parent = parent;
                    n.ink_margin = decl.ink_margin;
                    // Reset from the declaration: `accumulate_offsets` folds ancestors in,
                    // so keeping last frame's value would compound the offset every frame.
                    // 从声明重置：`accumulate_offsets` 会把祖先折进来，
                    // 保留上帧的值会让偏移每帧累积。
                    n.offset = decl.offset;
                    n.cursor = decl.cursor;
                    // A node property, copied every frame like `cursor`: it follows the
                    // declaration instead of sticking to whatever it was first set to.
                    // 节点属性，像 `cursor` 一样每帧复制：它跟随声明，而不是黏在首次设的值上。
                    n.sense = decl.sense;
                    // Same folding on the reuse path: inherited disabled wins over own false.
                    // 复用路径同样折入：继承来的禁用压过自身声明的 false。
                    n.disabled = decl.disabled || inherited_disabled;
                    // `None` means "inherit": the folded value is only replaced when this
                    // declaration actually opens a scope.
                    // `None` 表示「继承」：只有本声明真的开启作用域时才替换折入的值。
                    n.env = decl.env.clone().or_else(|| inherited_env.clone());
                    // The declared size is always the target, whatever a transition left in
                    // `size_class`; a cached subtree keeps the one it was applied with.
                    // 声明尺寸永远是目标，不论过渡在 `size_class` 里留下什么；
                    // 被整体复用的子树保持应用它时的值。
                    n.declared_size = decl.size_class;
                    if !same_src {
                        let changed = n.data != decl.data
                            || n.size_class != decl.size_class
                            || n.grid != decl.grid
                            || n.placement != decl.placement;
                        n.data = decl.data.clone();
                        n.size_class = decl.size_class;
                        n.grid = decl.grid;
                        n.placement = decl.placement;
                        n.box_model = decl.box_model;
                        if changed {
                            n.dirty = true;
                            self.layout_dirty = true;
                            changed_here = true;
                        }
                    }
                    stats.reused += 1;
                    nid
                }
            }
            None => {
                stats.created += 1;
                let spawned = self.spawn(decl, parent);
                if let Some(env) = decl.env.clone().or_else(|| inherited_env.clone())
                    && let Some(n) = self.get_mut(spawned) {
                        n.env = Some(env);
                    }
                spawned
            }
        };

        // Time-dependent nodes are collected even when the declaration is cached: a subtree
        // that is skipped whole would otherwise stop driving its own transition.
        // 与时间相关的节点即使声明被缓存也要收集：整棵跳过的子树否则会停止驱动自己的过渡。
        let entering = self.slot(nid).is_some_and(|n| n.presence < 1.0);
        if decl.data.params().is_some_and(|p| {
            p.size_transition.is_some() || (p.enter.is_some() && entering)
        }) {
            self.animated.push(nid);
        }

        // The same declaration object in the same place: nothing under it can have changed,
        // so the whole subtree is seen and the walk stops here.
        // 同一个声明对象、同一个位置：其下不可能有变化，因此整棵子树视为已见，遍历就此停下。
        if same_src
            && self
                .slot(nid)
                .is_some_and(|n| n.parent == parent && n.order == order)
        {
            self.mark_reused_subtree(nid);
            return nid;
        }

        // Siblings are keyed by `Id`, so a duplicate silently overwrites its twin: the
        // second declaration reuses the first node and the first one's content is lost.
        // 同层按 `Id` 索引，重复的会静默覆盖：第二个声明复用第一个节点，第一个的内容丢失。
        #[cfg(debug_assertions)]
        {
            use crate::collections::FastSet;
            let mut seen = FastSet::with_capacity_and_hasher(
                decl.children.len(),
                Default::default(),
            );
            for child in decl.children.iter() {
                assert!(
                    seen.insert(child.id),
                    "duplicate sibling Id {:?} under {:?}: the tree keys by Id, so one node \
                     silently replaces the other; give repeated items derived ids (Id::with / Id::of)",
                    child.id,
                    decl.id
                );
                assert!(
                    child.id != decl.id,
                    "a child reuses its parent's Id {:?}: the tree keys by Id, so the child's \
                     declaration collapses into the wrapper's; give the wrapper its own id",
                    decl.id
                );
            }
        }

        // Paint-only shapes and the sibling position come straight from the declaration.
        // 纯绘制形状与同层次序都直接来自声明。
        if let Some(n) = self.get_mut(nid) {
            // A sibling that moved takes a different slot in the flow, so it is a change.
            // 换了位置的兄弟会占不同的流内槽位，因此也算改动。
            if n.order != order {
                n.order = order;
                changed_here = true;
            }
            n.src = src.cloned();
            if !same_src && n.shapes != decl.shapes {
                n.shapes = decl.shapes.clone();
            }
        }
        if changed_here {
            self.mark_dirty_up(nid);
        }
        for (i, child) in decl.children.iter().enumerate() {
            self.apply_decl(child, Some(child), Some(nid), i as u32, stats);
        }
        nid
    }

    /// Mark a subtree as still present this frame, without rebuilding any of it.
    /// 把一棵子树标记为本帧仍在，而不重建其中任何东西。
    ///
    /// Recursion depth is the tree's depth; no allocation, and the nodes' content is
    /// already correct because the declaration they came from is the same object.
    /// 递归深度即树的深度；不分配，节点的内容本来就已经正确——它们来自同一个声明对象。
    fn mark_reused_subtree(&mut self, nid: NodeId) {
        let mut animated = false;
        if let Some(n) = self.get_mut(nid) {
            n.reused = true;
            let settled = n.presence >= 1.0;
            animated = n.data.params().is_some_and(|p| {
                p.size_transition.is_some() || (p.enter.is_some() && !settled)
            });
        }
        if animated {
            self.animated.push(nid);
        }
        let count = self.children_of(Some(nid)).len();
        for i in 0..count {
            if let Some(kid) = self.child_at(Some(nid), i) {
                self.mark_reused_subtree(kid);
            }
        }
    }

    fn spawn(&mut self, decl: &Decl, parent: Option<NodeId>) -> NodeId {
        let index = match self.free.pop() {
            Some(i) => i,
            None => {
                self.nodes.push(None);
                self.generations.push(0);
                (self.nodes.len() - 1) as u32
            }
        };
        let generation = *self.generations.get(index as usize).unwrap_or(&0);
        // A slot handed out while still occupied would overwrite a live node, and the tree
        // would silently lose it; `free` must never hold an index twice.
        // 交给出去时槽位仍被占用会覆盖活节点，树会静默丢掉它；`free` 绝不能重复持有索引。
        debug_assert!(
            self.nodes.get(index as usize).map(Option::is_none).unwrap_or(true),
            "free list handed out a live slot"
        );
        let nid = NodeId { index, generation };
        let entering = decl.data.params().is_some_and(|p| p.enter.is_some());
        self.nodes[index as usize] = Some(Node {
            id: decl.id,
            parent,
            kind: decl.kind,
            data: decl.data.clone(),
            shapes: decl.shapes.clone(),
            order: 0,
            size_class: decl.size_class,
            declared_size: decl.size_class,
            box_model: decl.box_model,
            min_content: Size::ZERO,
            max_content: Size::ZERO,
            scroll_extent: Size::ZERO,
            rect: Rect::ZERO,
            flow_vertical: false,
            offset: decl.offset,
            // A node declaring `enter` is born at its start point, not at its final look.
            // 声明了 `enter` 的节点出生在起点，而不是终态。
            presence: if entering { 0.0 } else { 1.0 },
            presence_alpha: 1.0,
            presence_shift: crate::geom::Point::ZERO,
            presence_scale: 1.0,
            cursor: decl.cursor,
            sense: decl.sense,
            // A disabled ancestor disables everything below it, so the flag is folded here.
            // 被禁用的祖先会禁用其下一切，因此在此折入该标志。
            disabled: decl.disabled
                || parent.and_then(|p| self.get(p)).map(|p| p.disabled).unwrap_or(false),
            grid: decl.grid,
            placement: decl.placement,
            // The node starts with its own declaration; `apply` folds the inherited one in.
            // 节点先带自己的声明；继承的那一层由 `apply` 折入。
            env: decl.env.clone(),
            mask: Rect::ZERO,
            focus_mask: Rect::ZERO,
            ink_margin: decl.ink_margin,
            wrap_width: f32::INFINITY,
            inline: None,
            baseline: 0.0,
            dirty: true,
            last_measure: None,
            reused: true,
            held: false,
            src: None,
        });
        self.live.push(nid);
        if entering {
            self.appeared.push(nid);
        }
        let sibs = self.by_parent.entry(parent).or_default();
        sibs.by_id.insert(decl.id, nid);
        sibs.order.push(nid);
        self.layout_dirty = true;
        // A new child changes what its ancestors measure, so their caches are stale too.
        // 新子节点会改变祖先测得的尺寸，因此它们的缓存同样过期。
        if let Some(p) = parent {
            self.mark_dirty_up(p);
        }
        nid
    }

    /// Retire `nid` and everything below it; returns how many nodes were still alive.
    /// 回收 `nid` 及其下全部节点；返回其中仍存活的个数。
    fn retire_subtree(&mut self, nid: NodeId) -> usize {
        let mut retired = 0;
        let mut stack = vec![nid];
        while let Some(cur) = stack.pop() {
            // A subtree removal also lists the descendants an ancestor already freed, and a
            // stale handle may name a slot that has since been handed out again. Freeing
            // either would put one index in `free` twice, and two nodes would share it.
            // 子树回收也会列出祖先已释放的后代，过期句柄还可能指向已重新分配的槽位；
            // 释放它们会让同一索引在 `free` 里出现两次，两个节点共用一个槽位。
            if self.generations.get(cur.index()).copied() != Some(cur.generation()) {
                continue;
            }
            stack.extend_from_slice(self.children_of(Some(cur)));
            self.by_parent.remove(&Some(cur));
            let Some(node) = self.nodes.get_mut(cur.index()).and_then(|s| s.take()) else {
                continue;
            };
            if let Some(sibs) = self.by_parent.get_mut(&node.parent) {
                sibs.by_id.remove(&node.id);
                sibs.order.retain(|n| *n != cur);
            }
            self.live.retain(|n| *n != cur);
            self.free.push(cur.index() as u32);
            if let Some(g) = self.generations.get_mut(cur.index()) {
                *g = g.wrapping_add(1);
            }
            retired += 1;
        }
        retired
    }

    /// Keep an undeclared subtree alive for its exit; false when it has none.
    /// 为退场保活一棵已不在声明中的子树；没有退场声明时返回 false。
    fn hold(&mut self, nid: NodeId) -> bool {
        let declared = self
            .slot(nid)
            .and_then(|n| Some((n.held, n.data.params()?.exit.is_some())));
        let Some((already_held, has_exit)) = declared else {
            return false;
        };
        if already_held || !has_exit {
            return false;
        }
        let mut stack = vec![nid];
        while let Some(cur) = stack.pop() {
            stack.extend_from_slice(self.children_of(Some(cur)));
            if let Some(n) = self.get_mut(cur) {
                n.held = true;
                // Leaving starts from fully present; the first exit leg rewrites these.
                // 离开从「完全在场」起步；第一段退场再改写它们。
                n.presence = 1.0;
                n.presence_alpha = 1.0;
                n.presence_shift = crate::geom::Point::ZERO;
                n.presence_scale = 1.0;
            }
        }
        self.held.push(nid);
        true
    }

    /// Take held subtrees out of every sibling list and the id map `rebuild_index` refilled.
    /// 把被持有的子树移出父节点的每一份同级列表，以及 `rebuild_index` 重填的 id 表。
    fn detach_held(&mut self) {
        if self.held.is_empty() {
            return;
        }
        let roots = self.held.clone();
        let mut ghosts: Vec<(Id, NodeId)> = Vec::new();
        for root in roots {
            let Some((parent, id)) = self.slot(root).map(|n| (n.parent, n.id)) else {
                continue;
            };
            if let Some(sibs) = self.by_parent.get_mut(&parent) {
                sibs.order.retain(|n| *n != root);
                // Paint reads its own sorted copy; leaving the root there paints it twice,
                // once from the parent and once from `held()`, doubling a translucent alpha.
                // 绘制读的是另一份排好序的副本；根留在里面会画两次——父节点一次、`held()` 一次，
                // 半透明节点的 alpha 因此叠了两遍。
                sibs.paint.retain(|n| *n != root);
                if sibs.by_id.get(&id) == Some(&root) {
                    sibs.by_id.remove(&id);
                }
            }
            let mut stack = vec![root];
            while let Some(cur) = stack.pop() {
                stack.extend_from_slice(self.children_of(Some(cur)));
                if let Some(n) = self.slot(cur) {
                    ghosts.push((n.id, cur));
                }
            }
        }
        // A reopened surface must find the live node, never the one that is leaving.
        // 重新打开的表面必须找到活着的那个节点，而不是正在离开的那个。
        for (id, nid) in ghosts {
            if self.by_id.get(&id) == Some(&nid) {
                self.by_id.remove(&id);
            }
        }
    }

    fn rebuild_index(&mut self) {
        for sibs in self.by_parent.values_mut() {
            sibs.order.clear();
            sibs.by_id.clear();
        }
        self.by_id.clear();
        let live = self.live.clone();
        self.by_id.reserve(live.len());
        for nid in live {
            if let Some(n) = self.slot(nid) {
                let (parent, id) = (n.parent, n.id);
                let sibs = self.by_parent.entry(parent).or_default();
                sibs.by_id.insert(id, nid);
                sibs.order.push(nid);
                self.by_id.insert(id, nid);
            }
        }
        let nodes = &self.nodes;
        for sibs in self.by_parent.values_mut() {
            sibs.order.sort_by_key(|n| {
                let order = nodes[n.index()].as_ref().map(|x| x.order).unwrap_or(0);
                (order, n.index())
            });
            // Paint order is a second view of the same children, sorted here once per apply:
            // walks, hit rebuild and paint then borrow it instead of copying and sorting it.
            // 绘制序是同一批子节点的第二个视图，每次 apply 排一次：之后遍历/命中/绘制都借用它，
            // 不再各自复制并排序。
            let mut paint = std::mem::take(&mut sibs.paint);
            paint.clear();
            paint.extend_from_slice(&sibs.order);
            paint.sort_by_key(|k| {
                (z_of(nodes, *k), nodes[k.index()].as_ref().map(|x| x.order).unwrap_or(0))
            });
            sibs.paint = paint;
        }
    }

    /// Walk the tree depth-first, parents before children.
    /// 深度优先遍历，父先于子。
    pub fn walk(&self) -> Vec<NodeId> {
        let mut out = Vec::with_capacity(self.live.len());
        let Some(root) = self.root else {
            return out;
        };
        // A modal, overlay or lifted subtree comes last: it floats above what it covers,
        // and paint order is walk order. Later ones land after earlier ones.
        // 模态、浮层与被抬起的子树排在最后：它们浮在所覆盖的一切之上，而绘制顺序即遍历顺序。
        // 后出现的排在先出现的之后，因此最新的在最上面。
        let mut deferred: Vec<NodeId> = Vec::new();
        let mut stack = vec![root];
        while let Some(nid) = stack.pop() {
            if self.is_modal(nid) || self.is_overlay(nid) || self.is_lifted(nid) {
                deferred.push(nid);
                continue;
            }
            out.push(nid);
            // Positioned siblings paint by `z`; ties keep declaration order.
            // 定位兄弟按 `z` 绘制；相同则保持声明顺序。
            stack.extend(self.children_in_paint_order(nid).iter().rev().copied());
        }
        for node in deferred {
            self.walk_subtree(node, &mut out);
        }
        out
    }

    /// Whether `nid` is a modal surface root, which the walk defers.
    /// `nid` 是否为模态表面的根——遍历会把它推后。
    pub fn is_modal(&self, nid: NodeId) -> bool {
        self.get(nid)
            .and_then(|n| n.data.params())
            .is_some_and(|p| p.modal.is_some())
    }

    /// Whether `nid` is an anchored overlay, which paints above everything else too.
    /// `nid` 是否为锚定浮层——它同样画在其余一切之上。
    pub fn is_overlay(&self, nid: NodeId) -> bool {
        self.get(nid).is_some_and(|n| n.placement.overlay.is_some())
    }

    /// Whether `nid` is lifted: painted above the tree while keeping its layout slot.
    /// `nid` 是否被抬起：保留布局槽位，同时画在整棵树之上。
    pub fn is_lifted(&self, nid: NodeId) -> bool {
        self.get(nid).is_some_and(|n| n.placement.lift)
    }

    /// Whether `nid` floats: no slot in its parent's flow, and it paints above it.
    /// `nid` 是否浮起：不占父节点的位置，并绘制在其之上。
    pub fn floats(&self, nid: NodeId) -> bool {
        self.get(nid)
            .is_some_and(|n| n.kind == NodeKind::Overlay || self.is_modal(nid))
    }

    /// Whether `nid` is taken out of the flow by its positioning scheme.
    /// `nid` 是否因定位方案脱离流。
    pub fn out_of_flow(&self, nid: NodeId) -> bool {
        self.get(nid).is_some_and(|n| {
            matches!(
                n.placement.position,
                crate::layout::Position::Absolute | crate::layout::Position::Fixed
            )
        })
    }

    /// Effective stacking order among siblings: only a positioned node carries its `z`.
    /// 同层间的有效层叠顺序：只有定位节点携带自己的 `z`。
    pub fn effective_z(&self, nid: NodeId) -> i32 {
        z_of(&self.nodes, nid)
    }

    /// Children in paint order: `(z, declaration order)`, stable. Paint and hit both use it.
    /// 按绘制顺序排列子节点：`(z, 声明顺序)`，稳定排序。绘制与命中都用它。
    pub fn children_in_paint_order(&self, nid: NodeId) -> &[NodeId] {
        // Sorted once per apply: a stable sort keeps declaration order wherever `z` ties.
        // 每次 apply 排一次：稳定排序在 `z` 相同时保持声明顺序。
        self.by_parent
            .get(&Some(nid))
            .map(|s| s.paint.as_slice())
            .unwrap_or(&[])
    }

    /// One paint-ordered child by position, for callers that must mutate while walking.
    /// 按位置取一个绘制序子节点，供遍历时需要改动树的调用方使用。
    pub fn paint_child_at(&self, nid: NodeId, index: usize) -> Option<NodeId> {
        self.by_parent
            .get(&Some(nid))
            .and_then(|s| s.paint.get(index).copied())
    }

    /// The modal that owns the keyboard: the one painted last, which is the one on top.
    /// 拥有键盘的模态：最后绘制的那个，也就是最上面的。
    pub fn modal_root(&self) -> Option<NodeId> {
        self.walk().into_iter().rev().find(|nid| self.is_modal(*nid))
    }

    /// The topmost overlay that takes the keyboard — a menu or a picker panel, not a tooltip.
    /// 最上层、要键盘的浮层——菜单或选择面板，而不是提示框。
    ///
    /// Asking for focus is the overlay's own declaration (`Sense::FOCUSABLE`), so a panel
    /// that is only read aloud stays out of the keyboard's way without a second flag.
    /// 「要不要键盘」由浮层自己声明（`Sense::FOCUSABLE`），只供朗读的面板因此无需第二个标志
    /// 就不挡键盘的路。
    pub fn popup_root(&self) -> Option<NodeId> {
        self.walk().into_iter().rev().find(|nid| {
            self.is_overlay(*nid)
                && self
                    .get(*nid)
                    .is_some_and(|n| n.sense.contains(crate::Sense::FOCUSABLE))
        })
    }

    /// Whether `nid` is `root` or one of its descendants.
    /// `nid` 是否为 `root` 或它的后代。
    pub fn within(&self, nid: NodeId, root: NodeId) -> bool {
        self.path_to(nid).contains(&root)
    }

    /// Append one subtree in pre-order, deferring any modal nested inside it.
    /// 按前序追加一棵子树，其中的嵌套模态同样推后。
    fn walk_subtree(&self, nid: NodeId, out: &mut Vec<NodeId>) {
        let mut stack = vec![nid];
        while let Some(cur) = stack.pop() {
            out.push(cur);
            stack.extend(self.children_in_paint_order(cur).iter().rev().copied());
        }
    }

    /// Ancestor chain from root down to `nid`, inclusive.
    /// 从根到 `nid` 的祖先链（含两端）。
    pub fn path_to(&self, nid: NodeId) -> Vec<NodeId> {
        let mut path = Vec::new();
        let mut cur = Some(nid);
        while let Some(c) = cur {
            path.push(c);
            cur = self.slot(c).and_then(|n| n.parent);
        }
        path.reverse();
        path
    }

    pub fn constraints_for_root(&self, size: Size) -> Constraints {
        Constraints::loose(size)
    }

    pub fn set_layout_clean(&mut self) {
        self.layout_dirty = false;
        for nid in self.live.clone() {
            if let Some(n) = self.get_mut(nid) {
                n.dirty = false;
            }
        }
    }

    pub fn layout_is_dirty(&self) -> bool {
        self.layout_dirty
    }
}

#[cfg(test)]
mod image_fit_tests {
    use super::*;
    use crate::geom::Rect;

    const TEX: (u32, u32) = (400, 300);

    #[test]
    fn cover_crops_the_source_instead_of_tiling_it() {
        // A 200x400 box over a 400x300 photo must crop, not repeat: the source stays
        // inside the texture and keeps the photo's aspect ratio.
        // 200x400 的盒子套 400x300 的照片必须裁剪而非重复：源留在纹理内且保持宽高比。
        let box_ = Rect::new(10.0, 20.0, 200.0, 400.0);
        let (dest, src) = ImageFit::Cover.place(box_, TEX);
        assert_eq!(dest, box_, "cover fills the box");
        assert!((src.size.w - 150.0).abs() < 1e-3, "src w {}", src.size.w);
        assert!((src.size.h - 300.0).abs() < 1e-3, "src h {}", src.size.h);
        assert!((src.origin.x - 125.0).abs() < 1e-3, "centred horizontally");
        assert!(src.min_x() >= 0.0 && src.max_x() <= 400.0);
        assert!(src.min_y() >= 0.0 && src.max_y() <= 300.0);
    }

    #[test]
    fn contain_letterboxes_inside_the_box() {
        // A wide box over a 4:3 photo leaves the fill visible above and below.
        // 宽盒子套 4:3 照片会在上下露出填充色。
        let box_ = Rect::new(0.0, 0.0, 400.0, 400.0);
        let (dest, src) = ImageFit::Contain.place(box_, TEX);
        assert_eq!(src, Rect::new(0.0, 0.0, 400.0, 300.0), "the whole photo");
        assert!((dest.size.w - 400.0).abs() < 1e-3);
        assert!((dest.size.h - 300.0).abs() < 1e-3);
        assert!((dest.origin.y - 50.0).abs() < 1e-3, "centred vertically");
    }

    #[test]
    fn no_fit_ever_samples_outside_the_texture() {
        // The invariant behind "never repeat": every source rect stays within the texture.
        // 「绝不重复」背后的不变量：任何源矩形都留在纹理之内。
        let boxes = [
            Rect::new(0.0, 0.0, 10.0, 1000.0),
            Rect::new(0.0, 0.0, 1000.0, 10.0),
            Rect::new(-5.0, 7.0, 1.0, 1.0),
            Rect::new(0.0, 0.0, 400.0, 300.0),
        ];
        for fit in [ImageFit::Cover, ImageFit::Contain, ImageFit::Fill] {
            for b in boxes {
                let (_, src) = fit.place(b, TEX);
                assert!(
                    src.min_x() >= -1e-3
                        && src.min_y() >= -1e-3
                        && src.max_x() <= 400.0 + 1e-3
                        && src.max_y() <= 300.0 + 1e-3,
                    "{fit:?} on {b:?} gave {src:?}"
                );
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn box_node(id: &'static str, w: f32, h: f32) -> Decl {
        Decl {
            id: Id::str(id),
            kind: NodeKind::Box,
            shapes: Vec::new(),
            data: NodeData::Container(ContainerParams::default()),
            box_model: BoxModel::default(),
            size_class: SizeClass::fixed(w, h),
            ink_margin: Insets::ZERO,
            offset: crate::geom::Point::new(0.0, 0.0),
            cursor: None,
            sense: crate::sense::Sense::NONE,
            disabled: false,
            grid: GridItem::default(),
            placement: crate::layout::Placement::default(),
            env: None,
            children: Vec::new(),
        }
    }

    // The check itself is `#[cfg(debug_assertions)]`, so release builds have nothing to panic.
    // 检查本身是 `#[cfg(debug_assertions)]`，因此 release 构建里没有可 panic 的东西。
    #[cfg(debug_assertions)]
    #[test]
    #[should_panic(expected = "duplicate sibling Id")]
    fn duplicate_sibling_ids_are_rejected_in_debug() {
        // Without this check the second declaration silently reuses the first node and
        // the first one's content disappears — six rows rendering as one, in practice.
        // 没有这条检查时，第二个声明会静默复用第一个节点，第一个的内容消失——
        // 实际发生过的是「六行只画出一行」。
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column)
                .child(box_node("row", 10.0, 10.0))
                .child(box_node("row", 10.0, 10.0)),
        );
    }

    #[cfg(debug_assertions)]
    #[test]
    #[should_panic(expected = "reuses its parent's Id")]
    fn a_child_sharing_its_parents_id_is_rejected_in_debug() {
        // A wrapper sized around a widget that carries the same id loses its own size:
        // the two declarations become one node, so the widget fills the grandparent.
        // 套在控件外、与控件同 id 的包装层会丢掉自己的尺寸：两份声明并成一个节点，
        // 控件于是撑满祖父节点。
        let mut tree = Tree::new();
        tree.apply(
            &Decl::container(Id::str("root"), NodeKind::Column).child(
                Decl::container(Id::str("slot"), NodeKind::Column)
                    .child(box_node("slot", 10.0, 10.0)),
            ),
        );
    }

    #[test]
    fn same_id_across_frames_reuses_the_node() {
        let mut tree = Tree::new();
        let decl = Decl::container(Id::str("root"), NodeKind::Column)
            .child(box_node("a", 10.0, 10.0));
        let first = tree.apply(&decl);
        let root_before = tree.root();
        let child_before = tree.find_by_id(Id::str("a"));

        let second = tree.apply(&decl);

        assert_eq!(first.created, 2);
        assert_eq!(second.reused, 2);
        assert_eq!(second.created, 0);
        assert_eq!(tree.root(), root_before);
        assert_eq!(tree.find_by_id(Id::str("a")), child_before);
    }

    #[test]
    fn vanished_child_is_retired_and_tree_shrinks() {
        let mut tree = Tree::new();
        let both = Decl::container(Id::str("root"), NodeKind::Column)
            .child(box_node("a", 10.0, 10.0))
            .child(box_node("b", 10.0, 10.0));
        tree.apply(&both);
        assert_eq!(tree.len(), 3);

        let only_a = Decl::container(Id::str("root"), NodeKind::Column)
            .child(box_node("a", 10.0, 10.0));
        let stats = tree.apply(&only_a);

        assert_eq!(stats.retired, 1);
        assert_eq!(tree.len(), 2);
        assert!(tree.find_by_id(Id::str("b")).is_none());
    }

    #[test]
    fn changing_kind_discards_the_subtree() {
        let mut tree = Tree::new();
        let as_box = Decl::container(Id::str("root"), NodeKind::Box);
        tree.apply(&as_box);
        let before = tree.find_by_id(Id::str("root")).unwrap();

        let as_row = Decl::container(Id::str("root"), NodeKind::Row);
        tree.apply(&as_row);
        let after = tree.find_by_id(Id::str("root")).unwrap();

        assert_ne!(
            before.generation(),
            after.generation(),
            "kind change must allocate a fresh slot, not reuse the old node"
        );
    }

    #[test]
    fn a_subtree_that_comes_back_keeps_every_child_it_declares() {
        // A modal is added, removed and added again; if the middle child is dropped the
        // dialog paints a scrim with nothing in it.
        // 模态先加、再删、再加；若中间那个子节点被丢掉，对话框就只剩一层空遮罩。
        let frame = |open: bool| {
            let mut root = Decl::container(Id::str("root"), NodeKind::Column)
                .child(box_node("a", 10.0, 10.0));
            if open {
                root = root.child(
                    Decl::container(Id::str("overlay"), NodeKind::Overlay)
                        .size(SizeClass::fixed(100.0, 100.0))
                        .child(
                            Decl::container(Id::str("scrim"), NodeKind::Column)
                                .child(box_node("pad-top", 0.0, 10.0))
                                .child(
                                    Decl::container(Id::str("surface"), NodeKind::Column)
                                        .child(box_node("body", 10.0, 10.0)),
                                )
                                .child(box_node("pad-bottom", 0.0, 10.0)),
                        ),
                );
            }
            root
        };
        let mut tree = Tree::new();
        tree.apply(&frame(true));
        tree.apply(&frame(false));
        let stats = tree.apply(&frame(true));
        assert_eq!(stats.created, 6, "every node of the subtree is new again");
        assert_eq!(tree.len(), 8, "and every one of them is live");
        assert!(
            tree.find_by_id(Id::str("surface")).is_some(),
            "the surface vanished when the subtree came back"
        );
    }

    #[test]
    fn a_draggable_declaration_survives_apply_and_follows_the_declaration() {
        // A node property must follow the declaration every frame, not stick to whatever it
        // was first set to — the same rule that `cursor` and `offset` follow.
        // 节点属性必须每帧跟随声明，而不是黏在首次设的值上——与 `cursor`、`offset` 同一条规则。
        let mut tree = Tree::new();
        let make = |yes: bool| {
            Decl::container(Id::str("root"), NodeKind::Box)
                .child(Decl::container(Id::str("panel"), NodeKind::Box).sense(if yes {
                    crate::Sense::DRAG
                } else {
                    crate::Sense::NONE
                }))
        };
        tree.apply(&make(true));
        let nid = tree.find_by_id(Id::str("panel")).expect("panel");
        assert!(tree.get(nid).expect("node").sense.contains(crate::Sense::DRAG), "declared true");

        tree.apply(&make(true));
        assert!(
            tree.get(nid).expect("node").sense.contains(crate::Sense::DRAG),
            "a second frame keeps it"
        );

        tree.apply(&make(false));
        assert!(
            !tree.get(nid).expect("node").sense.contains(crate::Sense::DRAG),
            "withdrawing the declaration must withdraw the property"
        );
    }

    #[test]
    fn a_child_added_later_paints_in_declaration_order() {
        // Arena slots are handed out on first sight, so a child introduced on a later frame
        // outranks its earlier siblings; paint order must follow the declaration instead.
        // arena 槽位在首次出现时分配，因此后加入的子节点槽位更大；绘制顺序必须跟随声明。
        let frame = |kids: &[&'static str]| {
            let mut decl = Decl::container(Id::str("root"), NodeKind::Row);
            for k in kids {
                decl = decl.child(box_node(k, 1.0, 1.0));
            }
            decl
        };
        let mut tree = Tree::new();
        tree.apply(&frame(&["a", "c"]));
        tree.apply(&frame(&["a", "b", "c"]));
        let root = tree.find_by_id(Id::str("root")).expect("root");
        let order: Vec<Id> = tree
            .children_of(Some(root))
            .iter()
            .copied()
            .filter_map(|n| tree.get(n).map(|n| n.id))
            .collect();
        assert_eq!(order, vec![Id::str("a"), Id::str("b"), Id::str("c")]);
    }

    #[test]
    fn a_shape_inside_a_node_inks_in_absolute_space() {
        // Shapes are declared in the node's own space; damage must lift them into absolute
        // coordinates or a repaint clears the wrong region and leaves stale pixels.
        // 形状声明在节点自身坐标系；脏区必须抬到绝对坐标，否则重绘会清错区域并留下残影。
        let mut decl = box_node("x", 40.0, 40.0)
            .shapes(vec![crate::draw::Shape::Rect {
                rect: Rect::new(2.0, 2.0, 10.0, 10.0),
                corners: Corners::ZERO,
                fill: crate::geom::Color::WHITE,
                gradient: None,
                border: None,
            }]);
        decl.offset = crate::geom::Point::new(100.0, 50.0);
        let mut tree = Tree::new();
        tree.apply(&decl);
        let root = tree.find_by_id(Id::str("x")).expect("x");
        let node = tree.get(root).expect("node");
        let ink = node.ink_rect();
        assert_eq!(ink.origin.x, 102.0, "the shape sits 2 px inside the node");
        assert_eq!(ink.origin.y, 52.0);
    }

    #[test]
    fn ink_rect_grows_beyond_the_layout_rect() {
        let node = Node {
            id: Id::str("x"),
            parent: None,
            kind: NodeKind::Box,
            data: NodeData::Container(ContainerParams::default()),
            shapes: Vec::new(),
            order: 0,
            size_class: SizeClass::fixed(10.0, 10.0),
            declared_size: SizeClass::fixed(10.0, 10.0),
            box_model: BoxModel::default(),
            min_content: Size::ZERO,
            max_content: Size::ZERO,
            scroll_extent: Size::ZERO,
            rect: Rect::new(5.0, 5.0, 10.0, 10.0),
            flow_vertical: false,
            offset: crate::geom::Point::new(0.0, 0.0),
            presence: 1.0,
            presence_alpha: 1.0,
            presence_shift: crate::geom::Point::ZERO,
            presence_scale: 1.0,
            cursor: None,
            sense: crate::sense::Sense::NONE,
            disabled: false,
            grid: GridItem::default(),
            placement: crate::layout::Placement::default(),
            env: None,
            mask: Rect::ZERO,
            focus_mask: Rect::ZERO,
            ink_margin: Insets::all(4.0),
            wrap_width: f32::INFINITY,
            inline: None,
            baseline: 0.0,
            dirty: false,
            last_measure: None,
            reused: true,
            held: false,
            src: None,
        };
        let ink = node.ink_rect();
        assert_eq!(ink.origin.x, 1.0);
        assert_eq!(ink.origin.y, 1.0);
        assert_eq!(ink.size.w, 18.0);
        assert_eq!(ink.size.h, 18.0);
    }

    #[test]
    fn path_to_returns_root_first_ancestors() {
        let mut tree = Tree::new();
        let decl = Decl::container(Id::str("root"), NodeKind::Column)
            .child(Decl::container(Id::str("mid"), NodeKind::Row).child(box_node("leaf", 4.0, 4.0)));
        tree.apply(&decl);
        let leaf = tree.find_by_id(Id::str("leaf")).unwrap();
        let path = tree.path_to(leaf);
        assert_eq!(path.len(), 3);
        assert_eq!(path[0], tree.root().unwrap());
        assert_eq!(*path.last().unwrap(), leaf);
    }
}
