//! Pack lookups the controls share: a role, an alpha and the accent ramp.
//! 控件共用的包查询：角色、透明度与强调色斜坡。

use ui_core::draw::{Gradient, GradientAxis};
use ui_core::geom::Color;
use ui_design::{GradientBrush, Paint};
use ui_style::Style;

pub(crate) fn role_of(pack: &Style, name: &'static str) -> Color {
    // Curated role first, then the live native palette; a miss is a bug, shown as magenta.
    // 先查手工角色，再问活的原生调色板；两处都无是缺陷，用品红显形。
    let c = pack.ink(name);
    debug_assert!(c.is_some(), "neither the pack nor its palette knows {name}");
    c.unwrap_or(Color::from_rgba8(255, 0, 255, 255))
}

/// A border brush as the decl takes it: one flat colour, or the run XAML draws.
/// 声明可接受的描边画刷：一个纯色，或 XAML 实际绘制的渐变。
#[derive(Clone, Copy, Debug, PartialEq)]
pub(crate) enum Stroke {
    Solid(Color),
    Gradient(Gradient),
}

impl Stroke {
    /// Paint this stroke on `decl` at `width`, whichever kind it is.
    /// 以 `width` 把本描边画到 `decl` 上，不论它是哪一种。
    pub(crate) fn on(self, decl: ui_core::Decl, width: f32) -> ui_core::Decl {
        match self {
            Stroke::Solid(c) => decl.border(c, width),
            Stroke::Gradient(g) => decl.border_gradient(g, width),
        }
    }
}

/// The brush `name` names; a gradient brush keeps its XAML geometry and stops.
/// `name` 指名的画刷；渐变画刷保留 XAML 的几何与停点。
pub(crate) fn stroke_of(pack: &Style, name: &'static str) -> Stroke {
    match pack.brush(name) {
        Some(Paint::Gradient(b)) => Stroke::Gradient(gradient_of(&b)),
        _ => Stroke::Solid(role_of(pack, name)),
    }
}

fn gradient_of(b: &GradientBrush) -> Gradient {
    let dx = b.end.0 - b.start.0;
    let dy = b.end.1 - b.start.1;
    // WinUI's elevation borders are vertical; a horizontal brush still maps exactly.
    let (axis, len) = if dx.abs() >= dy.abs() {
        (GradientAxis::Horizontal, dx.abs())
    } else {
        (GradientAxis::Vertical, dy.abs())
    };
    let near = b.stops.first().copied().unwrap_or((0.0, ui_design::Rgba(0)));
    let far = b.stops.last().copied().unwrap_or((1.0, ui_design::Rgba(0)));
    let mut g = Gradient::new(colour(near.1), colour(far.1), axis)
        .with_stops(near.0, far.0);
    // Absolute mapping runs the brush over its own length, not the box's.
    // 绝对映射让画刷跑在自己的长度上，而不是盒子的长度。
    if !b.relative {
        g = g.over(len);
    }
    if b.flip {
        g = g.flipped();
    }
    g
}

fn colour(c: ui_design::Rgba) -> Color {
    let argb = c.argb();
    Color::from_rgba8(
        (argb >> 16) as u8,
        (argb >> 8) as u8,
        argb as u8,
        (argb >> 24) as u8,
    )
}

/// Fluent's selection: the accent wash, with the selected glyphs inverted to white.
/// Fluent 的选区：强调色洗色，被选中的字形反白。
#[derive(Debug)]
pub struct FluentSelection;

impl ui_core::SelectionPainter for FluentSelection {
    fn paint(&self, geometry: &ui_core::SelectionGeometry<'_>) -> ui_core::SelectionPaint {
        ui_core::SelectionPaint {
            ink: Some(Color::WHITE),
            ..ui_core::flat_selection(geometry)
        }
    }
}

/// The single instance a pack hands to every text node it styles.
/// 包交给每个它所样式化的文本节点的唯一实例。
pub static FLUENT_SELECTION: FluentSelection = FluentSelection;

