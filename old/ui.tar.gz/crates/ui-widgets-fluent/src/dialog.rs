//! The Fluent content dialog: a modal surface with a title, content and up to three actions.
//! Fluent 内容对话框：带标题、内容与至多三个动作的模态表面。

use ui_core::anim::{AnimSpec, Easing};
use ui_core::geom::{Color, Corners, Insets, Rect};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::shortcut::{KeyChord, ShortcutId};
use ui_core::tree::{ModalTarget, Presence};
use ui_core::{Change, Decl, Id, Key, Modifiers, NodeKind, Sense, Weight};
use ui_style::Style;
use ui_widgets::text::Text;
use ui_widgets::{Cx, Widget, WidgetState};

use crate::button::{ButtonParams, ButtonVariant, FluentButton};
use crate::paint::role_of;

/// `ContentDialogMinWidth` / `ContentDialogMaxWidth`.
/// `ContentDialogMinWidth` / `ContentDialogMaxWidth`。
pub const DIALOG_MIN_WIDTH: f32 = 320.0;
pub const DIALOG_MAX_WIDTH: f32 = 548.0;
/// `ContentDialogMinHeight` / `ContentDialogMaxHeight`.
/// `ContentDialogMinHeight` / `ContentDialogMaxHeight`。
pub const DIALOG_MIN_HEIGHT: f32 = 184.0;
pub const DIALOG_MAX_HEIGHT: f32 = 756.0;
/// `ContentDialogPadding`, `ContentDialogTitleMargin` and `ContentDialogButtonSpacing`.
/// `ContentDialogPadding`、`ContentDialogTitleMargin` 与 `ContentDialogButtonSpacing`。
pub const DIALOG_PAD: f32 = 24.0;
pub const DIALOG_TITLE_GAP: f32 = 12.0;
pub const DIALOG_BUTTON_SPACING: f32 = 8.0;
/// `ContentDialogSeparatorThickness` 0,0,0,1 and `ContentDialogBorderWidth` 1.
/// `ContentDialogSeparatorThickness` 0,0,0,1 与 `ContentDialogBorderWidth` 1。
pub const DIALOG_SEPARATOR: f32 = 1.0;
pub const DIALOG_BORDER: f32 = 1.0;
/// `OverlayCornerRadius`.
/// `OverlayCornerRadius`。
pub const DIALOG_RADIUS: f32 = 8.0;
/// The template's `FontSize="20" FontWeight="SemiBold"`, and `ControlContentThemeFontSize`.
/// 模板的 `FontSize="20" FontWeight="SemiBold"`，以及 `ControlContentThemeFontSize`。
pub const DIALOG_TITLE_FONT: f32 = 20.0;
pub const DIALOG_CONTENT_FONT: f32 = 14.0;
/// The title's `MaxLines="2"`.
/// 标题的 `MaxLines="2"`。
pub const DIALOG_TITLE_LINES: u32 = 2;
/// `DialogShowingStates`: opacity 0→1 on show and 1→0 on hide, at
/// `ControlFasterAnimationDuration` with a linear key frame.
/// `DialogShowingStates`：显示 0→1、隐藏 1→0，取 `ControlFasterAnimationDuration`，线性关键帧。
pub const DIALOG_FADE: AnimSpec = AnimSpec::new(0.083, Easing::Linear);
/// `ControlNormalAnimationDuration` on `ControlFastOutSlowInKeySpline`, which is what makes
/// the dialog read as opening: the fade alone lands before the eye registers it.
/// `ControlNormalAnimationDuration` 配 `ControlFastOutSlowInKeySpline`，对话框的"打开"感来自它：
/// 只有淡变时，眼睛还没反应过来它就到位了。
pub const DIALOG_SCALE_IN: AnimSpec = AnimSpec::new(0.25, Easing::Cubic(0.0, 0.0, 0.0, 1.0));
/// `ControlFastAnimationDuration`, the same curve: the scale leaves in 167 ms, behind the
/// 83 ms fade that has already made it invisible.
/// `ControlFastAnimationDuration`，同一条曲线：缩放在 167 毫秒内离开，
/// 而 83 毫秒的淡出早已让它看不见了。
pub const DIALOG_SCALE_OUT: AnimSpec = AnimSpec::new(0.167, Easing::Cubic(0.0, 0.0, 0.0, 1.0));
/// `ScaleTransform` at the hidden end, both directions.
/// 隐藏端的 `ScaleTransform`，两个方向都用它。
pub const DIALOG_SCALE_FROM: f32 = 1.05;

/// Which action the dialog treats as its default, i.e. the accent one.
/// 对话框把哪个动作当作默认，也就是那个强调色按钮。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum ContentDialogButton {
    /// `ContentDialogButton.None`: no accent, which is the property's own default.
    /// `ContentDialogButton.None`：无强调色，这也是该属性的默认值。
    #[default]
    None,
    Primary,
    Secondary,
    Close,
}

impl ContentDialogButton {
    fn accent(self) -> Option<ActionSlot> {
        match self {
            Self::None => None,
            Self::Primary => Some(ActionSlot::Primary),
            Self::Secondary => Some(ActionSlot::Secondary),
            Self::Close => Some(ActionSlot::Close),
        }
    }
}

/// The three columns the command area can fill, in the order the template lists them.
/// 命令区可以填的三列，顺序与模板一致。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
enum ActionSlot {
    Primary,
    Secondary,
    Close,
}

impl ActionSlot {
    /// The slot's id suffix and the template's `x:Name` for its button.
    /// 槽位的 id 后缀与模板里对应按钮的 `x:Name`。
    const fn tag(self) -> &'static str {
        match self {
            Self::Primary => "primary",
            Self::Secondary => "secondary",
            Self::Close => "close",
        }
    }
}

/// Everything a dialog is built with, named after the properties the reference exposes.
/// 构建对话框所需的一切，按参考实现暴露的属性命名。
pub struct ContentDialogParams<'a> {
    pub id: Id,
    pub title: &'a str,
    /// `Content`: the body text; app blocks go in `content`, below it.
    /// `Content`：正文文本；应用自有的块放在 `content` 里，位于其下。
    pub body: &'a str,
    pub content: Vec<Decl>,
    /// `PrimaryButtonText` / `SecondaryButtonText` / `CloseButtonText`; empty hides a button.
    /// `PrimaryButtonText` / `SecondaryButtonText` / `CloseButtonText`；为空则隐藏该按钮。
    pub primary: &'a str,
    pub secondary: &'a str,
    pub close: &'a str,
    pub default_button: ContentDialogButton,
    /// `IsPrimaryButtonEnabled` / `IsSecondaryButtonEnabled`.
    /// `IsPrimaryButtonEnabled` / `IsSecondaryButtonEnabled`。
    pub primary_enabled: bool,
    pub secondary_enabled: bool,
    /// The region the smoke layer dims and blocks.
    /// 烟雾层压暗并挡住的区域。
    pub target: ModalTarget,
    /// Whether the dialog dims and blocks what is behind it. Off draws the surface alone,
    /// which is what a gallery preview needs.
    /// 是否压暗并挡住身后内容。关闭时只画表面，供展厅预览使用。
    pub barrier: bool,
}

impl<'a> ContentDialogParams<'a> {
    pub fn new(id: Id, title: &'a str, body: &'a str) -> Self {
        Self {
            id,
            title,
            body,
            content: Vec::new(),
            primary: "",
            secondary: "",
            close: "",
            default_button: ContentDialogButton::None,
            primary_enabled: true,
            secondary_enabled: true,
            target: ModalTarget::Global,
            barrier: true,
        }
    }

    pub fn primary(mut self, text: &'a str) -> Self {
        self.primary = text;
        self
    }

    pub fn secondary(mut self, text: &'a str) -> Self {
        self.secondary = text;
        self
    }

    pub fn close(mut self, text: &'a str) -> Self {
        self.close = text;
        self
    }

    pub fn default_button(mut self, button: ContentDialogButton) -> Self {
        self.default_button = button;
        self
    }

    pub fn primary_enabled(mut self, on: bool) -> Self {
        self.primary_enabled = on;
        self
    }

    pub fn secondary_enabled(mut self, on: bool) -> Self {
        self.secondary_enabled = on;
        self
    }

    pub fn content(mut self, blocks: Vec<Decl>) -> Self {
        self.content = blocks;
        self
    }

    pub fn target(mut self, target: ModalTarget) -> Self {
        self.target = target;
        self
    }

    pub fn barrier(mut self, barrier: bool) -> Self {
        self.barrier = barrier;
        self
    }
}

/// One resolved action: the button that draws it, and the id it reports under.
/// 一个解析后的动作：绘制它的按钮，以及它上报时用的 id。
struct Action {
    /// Read only by the tests that pin which button took the accent.
    /// 只有钉住「哪个按钮拿到强调色」的测试会读它。
    #[cfg_attr(not(test), allow(dead_code))]
    slot: ActionSlot,
    id: Id,
    button: FluentButton,
}

/// A content dialog, resolved against the pack in force where it was built.
/// 内容对话框，按构建时生效的包解析。
pub struct FluentContentDialog {
    id: Id,
    title: Option<String>,
    body: Option<String>,
    content: Vec<Decl>,
    actions: Vec<Action>,
    target: ModalTarget,
    barrier: bool,
    surface: Color,
    stroke: Color,
    overlay: Color,
    separator: Color,
    smoke: Color,
    ink: Color,
    /// The action whose button took this frame's click.
    /// 本帧点击落在其按钮上的那个动作。
    fired: Option<Id>,
    /// `DefaultButton`, which Enter presses whatever holds focus.
    /// `DefaultButton`：无论焦点在哪，Enter 都按下它。
    default: ContentDialogButton,
}

/// Enter presses the default button; Escape presses the close button, as WinUI binds them.
/// Enter 按下默认按钮；Escape 按下关闭按钮，与 WinUI 的绑定一致。
pub const DIALOG_DEFAULT_SHORTCUT: ShortcutId = ShortcutId("dialog.default");
pub const DIALOG_CLOSE_SHORTCUT: ShortcutId = ShortcutId("dialog.close");

impl FluentContentDialog {
    pub fn new(params: ContentDialogParams<'_>, cx: &mut Cx<'_, '_>, pack: &Style) -> Self {
        let ContentDialogParams {
            id,
            title,
            body,
            content,
            primary,
            secondary,
            close,
            default_button,
            primary_enabled,
            secondary_enabled,
            target,
            barrier,
        } = params;
        let accent = default_button.accent();
        let mut actions = Vec::new();
        for (slot, text, enabled) in [
            (ActionSlot::Primary, primary, primary_enabled),
            (ActionSlot::Secondary, secondary, secondary_enabled),
            (ActionSlot::Close, close, true),
        ] {
            if text.is_empty() {
                continue;
            }
            let bid = id.with(slot.tag());
            let variant = if accent == Some(slot) {
                ButtonVariant::Accent
            } else {
                ButtonVariant::Default
            };
            // `HorizontalAlignment="Stretch"` on all three: each fills its grid column.
            // 三个按钮都是 `HorizontalAlignment="Stretch"`：各自填满所在的网格列。
            let mut params = ButtonParams::new(bid, text).variant(variant).fill_width();
            if !enabled {
                params = params.disabled();
            }
            let mut node = cx.at(bid);
            actions.push(Action {
                slot,
                id: bid,
                button: FluentButton::new(params, &mut node, pack),
            });
        }
        let fired = actions.iter().find(|a| cx.state(a.id).clicked).map(|a| a.id);
        Self {
            id,
            title: (!title.is_empty()).then(|| title.to_string()),
            body: (!body.is_empty()).then(|| body.to_string()),
            content,
            actions,
            target,
            barrier,
            surface: role_of(pack, "ContentDialogBackground"),
            stroke: role_of(pack, "ContentDialogBorderBrush"),
            overlay: role_of(pack, "ContentDialogTopOverlay"),
            separator: role_of(pack, "ContentDialogSeparatorBorderBrush"),
            smoke: role_of(pack, "ContentDialogSmokeFill"),
            ink: role_of(pack, "ContentDialogForeground"),
            fired,
            default: default_button,
        }
    }

    /// Each action's fill, keyed by its slot tag, for the tests that pin the accent.
    /// 每个动作的填充色，按槽位标签索引，供钉住强调色的测试读取。
    #[cfg(test)]
    pub(crate) fn action_fills(&self) -> Vec<(&'static str, Color)> {
        self.actions
            .iter()
            .map(|a| (a.slot.tag(), a.button.fill()))
            .collect()
    }

    /// The width the content may wrap in: the surface minus its border and padding.
    /// 内容可换行的宽度：表面宽度减去描边与内衬。
    fn wrap(&self) -> f32 {
        DIALOG_MAX_WIDTH - 2.0 * (DIALOG_BORDER + DIALOG_PAD)
    }

    /// One text band: the title or the body, wrapping inside the surface.
    /// 一条文字带：标题或正文，在表面内换行。
    fn text(
        &self,
        which: &'static str,
        body: &str,
        size: f32,
        weight: Weight,
        max_lines: Option<u32>,
    ) -> Decl {
        let mut text = Text::new(self.id.with(which), body.to_string(), size, self.ink)
            .weight(weight)
            .max_width(self.wrap());
        if let Some(lines) = max_lines {
            text = text.max_lines(lines);
        }
        text.resolve()
    }

    /// The `*` row: title and content on the `ContentDialogTopOverlay` tint, over a bottom
    /// separator. It grows, so the command area stays at the surface's bottom edge.
    /// `*` 行：标题与内容叠在 `ContentDialogTopOverlay` 洗色上，底部一条分隔线。
    /// 它负责增长，命令区因此留在表面下缘。
    fn content_decl(&self) -> Decl {
        // The grid is clipped by `DialogSpace`'s `CornerRadius`, so its tint takes the
        // surface's own top corners instead of squaring them off.
        // 该网格被 `DialogSpace` 的 `CornerRadius` 裁剪，因此洗色取表面自身的顶角，
        // 而不是把圆角切成方角。
        let top = Corners {
            tl: DIALOG_RADIUS,
            tr: DIALOG_RADIUS,
            br: 0.0,
            bl: 0.0,
            shape: ui_core::geom::CornerShape::ROUND,
        };
        let mut area = Decl::container(self.id.with("content"), NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::hug(0.0, 0.0),
                grow_x: Grow::No,
                grow_y: Grow::Yes,
            })
            .padding(Insets::all(DIALOG_PAD))
            .cross_align(1.0)
            .background(self.overlay, top)
            .relative();
        if let Some(title) = &self.title {
            area = area.child(
                self.text(
                    "title",
                    title,
                    DIALOG_TITLE_FONT,
                    Weight::SEMIBOLD,
                    Some(DIALOG_TITLE_LINES),
                )
                // `ContentDialogTitleMargin` 0,0,0,12.
                // `ContentDialogTitleMargin`：0,0,0,12。
                .margin(Insets {
                    left: 0.0,
                    top: 0.0,
                    right: 0.0,
                    bottom: DIALOG_TITLE_GAP,
                }),
            );
        }
        if let Some(body) = &self.body {
            area = area.child(self.text(
                "body",
                body,
                DIALOG_CONTENT_FONT,
                Weight::REGULAR,
                None,
            ));
        }
        for block in &self.content {
            area = area.child(block.clone());
        }
        // `ContentDialogSeparatorThickness` 0,0,0,1 sits on the grid's outer bottom edge.
        // `ContentDialogSeparatorThickness` 0,0,0,1 画在网格的外下缘。
        area = area.child(
            Decl::container(self.id.with("separator"), NodeKind::Box)
                .absolute()
                .inset(ui_core::layout::LenInsets::new(
                    ui_core::layout::Len::Px(0.0),
                    ui_core::layout::Len::Auto,
                    ui_core::layout::Len::Px(0.0),
                    ui_core::layout::Len::Px(0.0),
                ))
                .size(SizeClass {
                    width: AxisSize::hug(0.0, 0.0),
                    height: AxisSize::fixed(DIALOG_SEPARATOR),
                    grow_x: Grow::No,
                    grow_y: Grow::No,
                })
                .background(self.separator, Corners::ZERO),
        );
        area
    }

    /// `CommandSpace`: equal `*` columns with an 8 pt gap. One lone action still sits in
    /// the right half, because the empty primary column keeps its share.
    /// `CommandSpace`：等宽的 `*` 列，列间 8pt。唯一的动作仍落在右半，
    /// 因为空的主列照样占自己那一份。
    fn commands_decl(&self, cx: &Cx<'_, '_>) -> Decl {
        let mut row = Decl::container(self.id.with("commands"), NodeKind::Row)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::hug(0.0, 0.0),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets::all(DIALOG_PAD))
            .gap(DIALOG_BUTTON_SPACING)
            .cross_align(0.0)
            .cross_pos(0.5);
        if self.actions.len() == 1 {
            row = row.child(
                Decl::container(self.id.with("commands-lead"), NodeKind::Column).size(SizeClass {
                    width: AxisSize::fill(0.0, 0.0),
                    height: AxisSize::hug(0.0, 0.0),
                    grow_x: Grow::Split(1),
                    grow_y: Grow::No,
                }),
            );
        }
        for action in &self.actions {
            row = row.child(action.button.decl(cx));
        }
        row
    }

    /// `BackgroundElement`: the surface itself, sized to its content between 320×184 and
    /// 548×756, with the border outside the content.
    /// `BackgroundElement`：表面本身，尺寸贴合内容并夹在 320×184 与 548×756 之间，
    /// 描边在内容之外。
    fn surface_decl(&self, cx: &Cx<'_, '_>) -> Decl {
        let corners = Corners::all(DIALOG_RADIUS);
        let mut column = Decl::container(self.id.with("surface"), NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::hug(DIALOG_MIN_WIDTH, DIALOG_MAX_WIDTH),
                height: AxisSize::hug(DIALOG_MIN_HEIGHT, DIALOG_MAX_HEIGHT),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            // `BackgroundSizing="InnerBorderEdge"`: the border takes its point out of the
            // 320 pt box, which is why the 320 pt dialog's command area is 318 wide.
            // `BackgroundSizing="InnerBorderEdge"`：描边从 320pt 盒子里取走一点，
            // 320pt 对话框的命令区因此只有 318 宽。
            .padding(Insets::all(DIALOG_BORDER))
            .cross_align(1.0)
            .corners(corners)
            .background(self.surface, corners)
            .border(self.stroke, DIALOG_BORDER)
            .child(self.content_decl());
        if !self.actions.is_empty() {
            column = column.child(self.commands_decl(cx));
        }
        column
    }
}

/// A zero-basis grower: it takes a share of the spare height and draws nothing.
/// 零基准增长者：分走一份剩余高度，自身不画任何东西。
fn spacer(id: Id) -> Decl {
    Decl::container(id, NodeKind::Column).size(SizeClass {
        width: AxisSize::hug(0.0, 0.0),
        height: AxisSize::hug(0.0, 0.0),
        grow_x: Grow::No,
        grow_y: Grow::Yes,
    })
}

impl Widget for FluentContentDialog {
    fn change(&self, state: &WidgetState, _bounds: Rect) -> Option<Change> {
        if let Some(id) = self.fired {
            return Some(Change::Selected(Some(id)));
        }
        // Enter presses the default button and Escape the close one, wherever focus sits.
        // 无论焦点在哪，Enter 按默认按钮，Escape 按关闭按钮。
        let slot = match state.shortcut? {
            DIALOG_CLOSE_SHORTCUT => ActionSlot::Close,
            DIALOG_DEFAULT_SHORTCUT => self.default.accent()?,
            _ => return None,
        };
        let action = self.actions.iter().find(|a| a.slot == slot)?;
        Some(Change::Selected(Some(action.id)))
    }

    fn decl(&self, cx: &Cx<'_, '_>) -> Decl {
        let id = self.id;
        // The app declares the dialog only while it is open; the engine holds the subtree
        // for the way out, so `DialogShowingStates` is a pair of declarations, not a state
        // the app has to keep alive across frames.
        // 应用只在对话框打开时声明它；离场由引擎保活，因此 `DialogShowingStates`
        // 是一对声明，而不是应用要跨帧维持的状态。
        if !self.barrier {
            return enter_and_leave(self.surface_decl(cx));
        }
        // `LayoutRoot`: the smoke layer, and the surface centred on both axes. A modal root
        // is placed on its target's rect, so the declared size never reaches the screen.
        // `LayoutRoot`：烟雾层，以及两轴居中的表面。模态根会被放到目标的矩形上，
        // 因此声明的尺寸到不了屏幕。
        let mut root = Decl::container(id, NodeKind::Column)
            .size(SizeClass::hug(0.0, 0.0))
            .modal(self.target)
            // The smoke layer takes the pointer so nothing behind the dialog does.
            // 烟雾层接收指针，对话框身后的东西因此接不到。
            .sense(Sense::HOVER)
            .cross_align(0.0)
            .cross_pos(0.5)
            .background(self.smoke, Corners::ZERO);
        // Only the modal owns keys: an inline sample would otherwise claim Enter whenever
        // the pointer crossed it, and Enter belongs to whoever holds the keyboard.
        // 只有模态拥有按键：行内样本否则会在指针经过时抢走 Enter，而 Enter 属于键盘的持有者。
        if self.barrier && !self.actions.is_empty() {
            root = root
                .shortcut(KeyChord::new(Key::Enter, Modifiers::NONE), DIALOG_DEFAULT_SHORTCUT)
                .shortcut(KeyChord::new(Key::Escape, Modifiers::NONE), DIALOG_CLOSE_SHORTCUT);
        }
        // Two equal growers centre the surface: the engine has no main-axis position.
        // 两个等量增长者把表面居中：引擎没有主轴定位。
        root = root
            .child(spacer(id.with("pad-top")))
            // The surface carries the scale channel alone: WinUI scales `BackgroundElement`
            // while the smoke layer stays put and only fades.
            // 缩放通道只由表面承载：WinUI 缩放的是 `BackgroundElement`，烟雾层原地不动、只淡。
            .child(
                self.surface_decl(cx)
                    .enter(
                        Presence::fade(DIALOG_SCALE_IN, 1.0)
                            .scaled(DIALOG_SCALE_FROM),
                    ),
            )
            .child(spacer(id.with("pad-bottom")));
        // The root owns the opacity channel: the smoke comes and goes with the surface, and
        // a held subtree drives only its own root's exit.
        // 不透明度归根：烟雾随表面一同来去；而被保活的子树只驱动它自己的根的退场。
        root.enter(Presence::fade(DIALOG_FADE, 0.0))
            .exit(Presence::fade(DIALOG_FADE, 0.0))
    }
}

/// Both channels on the one node a barrier-less dialog is.
/// 没有屏障时对话框就是这一个节点，两条通道都落在它身上。
fn enter_and_leave(surface: Decl) -> Decl {
    surface
        .enter(
            Presence::fade(DIALOG_FADE, 0.0)
                .scaled_over(DIALOG_SCALE_FROM, DIALOG_SCALE_IN),
        )
        .exit(
            Presence::fade(DIALOG_FADE, 0.0)
                .scaled_over(DIALOG_SCALE_FROM, DIALOG_SCALE_OUT),
        )
}
