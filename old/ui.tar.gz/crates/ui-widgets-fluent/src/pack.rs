//! The Fluent token pack, with every value traceable to the reference source.
//! Fluent 令牌包，每个数值都可追溯到参考源码。

use ui_core::Weight;
use ui_style::{Style, TextStyleToken, TypeTable};

#[cfg(test)]
fn c(v: [u8; 4]) -> ui_core::geom::Color {
    ui_core::geom::Color::from_rgba8(v[0], v[1], v[2], v[3])
}

fn t(size: f32, weight: Weight) -> TextStyleToken {
    TextStyleToken { size, weight, line_gap: 0.0, indent: 0.0 }
}

/// Fluent light theme, resolved by `ui-design` from the published token table.
/// Fluent 浅色主题；由 `ui-design` 从公开令牌表解析而来。
pub fn pack() -> &'static Style {
    pack_of(ui_design::Appearance::Light)
}

/// The Fluent pack for a given appearance, resolved from WinUI 3's own `ThemeResource` graph.
/// 给定外观下的 Fluent 包，由 WinUI 3 自己的 `ThemeResource` 图解析。
///
/// The Web token names survive only as aliases; a control asks for the brush its XAML asks for.
/// Web 令牌名只作为别名存在；控件索取的是它 XAML 里索取的那支画刷。
/// The Fluent pack for an appearance. Only two packs exist, so each is built at most once:
/// a pack resolves every colour role through HCT, and a page asks for it on every frame.
/// 某个外观的 Fluent 包。只有两个包，因此各自至多建一次：一个包要通过 HCT 解析每个颜色角色，
/// 而页面每帧都会来取。
pub fn pack_of(appearance: ui_design::Appearance) -> &'static Style {
    static LIGHT: std::sync::OnceLock<Style> = std::sync::OnceLock::new();
    static DARK: std::sync::OnceLock<Style> = std::sync::OnceLock::new();
    match appearance {
        ui_design::Appearance::Light => LIGHT.get_or_init(|| build(appearance)),
        ui_design::Appearance::Dark => DARK.get_or_init(|| build(appearance)),
    }
}

/// `pack_of` as an owned `Style`, for the `fn(Appearance) -> Style` slots. The style cache
/// calls it only when it has to build something new, never once per frame.
/// 以自有 `Style` 返回的 `pack_of`，供 `fn(Appearance) -> Style` 的位置使用。
/// 样式缓存只在真要新建时调用它，不是每帧。
pub fn pack_owned(appearance: ui_design::Appearance) -> Style {
    pack_of(appearance).clone()
}

fn build(appearance: ui_design::Appearance) -> Style {
    let ctx = ui_design::Context::new(appearance, ui_design::Platform::Desktop);
    let system = std::sync::Arc::new(ui_design::WinUISystem::new(ctx));
    let mut builder = ui_style::StyleBuilder::new(system).metrics_from_scale("medium");
    builder = builder
        .role_common("textSelection", ui_design::CommonColor::TextSelection)
        // WinUI inverts the glyphs to white over the accent wash.
        // WinUI 在强调色洗色上把字形反白。
        .selection_painter(ui_core::SelectionPainterRef(&crate::paint::FLUENT_SELECTION));


    // Fluent 2 type ramp: Base300 (14) for body, Base400 (16) for titles; ink comes from roles.
    // Fluent 2 字阶：正文 Base300（14），标题 Base400（16）；墨色取自角色。
    let type_table = TypeTable::new([
        t(20.0, Weight::SEMIBOLD),
        t(16.0, Weight::SEMIBOLD),
        t(14.0, Weight::REGULAR),
        t(12.0, Weight::REGULAR),
        t(12.0, Weight::REGULAR),
    ]);

    builder
        .type_table(type_table)
        .controls(crate::spec::winui_controls())
        .motion(ui_style::MotionTable::winui())
        .build()
}

#[cfg(test)]
mod tests {

    // Fluent rounds its corners; the pack must say so from the scale, not a literal.
    // Fluent 用圆弧；包必须从刻度得到它，而不是写死。
    #[test]
    fn the_control_corner_follows_the_fluent_scale() {
        let p = pack();
        let scale = ui_design::dimensions_of(
            ui_design::SystemId::Fluent,
            ui_design::Context::new(ui_design::Appearance::Light, ui_design::Platform::Web),
        )
        .radius;
        assert_eq!(p.metrics.control.corner, ui_design::CornerShape::ROUND);
        assert_eq!(p.metrics.control.corner, scale.curvature.corner_shape());
    }
    use super::*;

    #[test]
    fn the_unchecked_track_ladder_is_monotonic_in_weight() {
        // Secondary < Tertiary < Quarternary: hover and press darken the same wash.
        // Secondary < Tertiary < Quarternary：悬停与按下加深同一层洗色。
        let p = pack();
        let get = |k: &'static str| p.ink(k).expect("winui token").a;
        assert!(get("ControlAltFillColorSecondary") < get("ControlAltFillColorTertiary"));
        assert!(get("ControlAltFillColorTertiary") < get("ControlAltFillColorQuarternary"));
    }

    #[test]
    fn each_theme_block_is_not_a_channel_inversion_of_the_other() {
        // The dark `Default` block keeps Secondary black while the two above it turn white:
        // a single inverted base cannot reproduce it. Values are WinUI's own.
        // 暗色 `Default` 块的 Secondary 仍是黑、其上两档变白：翻一次通道得不出这个组合。
        const DARK: [(&str, [u8; 4]); 3] = [
            ("ControlAltFillColorSecondary", [0x00, 0x00, 0x00, 0x19]),
            ("ControlAltFillColorTertiary", [0xFF, 0xFF, 0xFF, 0x0B]),
            ("ControlAltFillColorQuarternary", [0xFF, 0xFF, 0xFF, 0x12]),
        ];
        let p = pack_of(ui_design::Appearance::Dark);
        for (role, rgba) in DARK {
            let got = p.ink(role).expect("winui token");
            assert_eq!(got, c(rgba), "{role} in the dark theme");
        }
    }

    #[test]
    fn the_pack_answers_in_winui_names_not_web_aliases() {
        // A control asks for the brush its XAML asks for; a Web name has no answer at all.
        // 控件索取的是它 XAML 里的画刷；Web 名一律无解。
        let p = pack();
        assert!(p.ink("ButtonBackground").is_some());
        assert_eq!(p.ink("colorNeutralBackground1"), None);
    }
}
