//! The Fluent progress ring: a 32 dp Lottie ring, determinate or spinning.
//! Fluent 进度环：32dp 的 Lottie 圆环，确定态或旋转态。

use ui_core::draw::Shape;
use ui_core::geom::{Color, Point};
use ui_core::layout::{AxisSize, Grow, SizeClass};
use ui_core::{Decl, Easing, Id, NodeKind};
use ui_style::Style;
use ui_widgets::{NodeCx, Widget};

use crate::paint::role_of;

/// The style's `Width` / `Height`, and its `MinWidth` / `MinHeight`.
/// 样式的 `Width` / `Height`，以及 `MinWidth` / `MinHeight`。
pub const RING_SIZE: f32 = 32.0;
pub const RING_MIN: f32 = 16.0;
/// Both Lottie visuals run on a two-second clock.
/// 两个 Lottie 视觉都以两秒为一个周期。
pub const RING_CYCLE: f32 = 2.0;
/// `ProgressRingDeterminate`: a 32 canvas, radius 8, sprite scale 1.77.
/// `ProgressRingDeterminate`：32 画布，半径 8，精灵缩放 1.77。
const DETERMINATE_CANVAS: f32 = 32.0;
const DETERMINATE_RADIUS: f32 = 8.0;
const DETERMINATE_SPRITE: f32 = 1.77;
/// `ProgressRingIndeterminate`: an 80 canvas, radius 7, sprite scale 5.
/// `ProgressRingIndeterminate`：80 画布，半径 7，精灵缩放 5。
const INDETERMINATE_CANVAS: f32 = 80.0;
const INDETERMINATE_RADIUS: f32 = 7.0;
const INDETERMINATE_SPRITE: f32 = 5.0;
/// `StrokeThickness` in both Lottie files, in path units.
/// 两个 Lottie 文件里的 `StrokeThickness`，按路径单位计。
const LOTTIE_STROKE: f32 = 1.5;
/// The spline both files share: `{0.167,0.167}` to `{0.833,0.833}`.
/// 两个文件共用的曲线：`{0.167,0.167}` 到 `{0.833,0.833}`。
const EASE: Easing = Easing::Cubic(0.167, 0.167, 0.833, 0.833);
/// Lottie never trims to exactly zero; the determinate file starts at 1e-4.
/// Lottie 不会裁剪到恰好为零；确定态文件从 1e-4 起步。
const TRIM_FLOOR: f32 = 0.0001;
/// Lottie's trim zero sits at twelve o'clock, a quarter turn before the sector's three.
/// Lottie 的裁剪零点在十二点钟方向，比弧图元的三点钟早四分之一圈。
const TWELVE_O_CLOCK: f32 = 0.25;

/// The determinate `TrimEnd` keyframes: progress, trim (`ProgressRingDeterminate.cpp`).
/// 确定态的 `TrimEnd` 关键帧：进度与裁剪量（`ProgressRingDeterminate.cpp`）。
///
/// The arc is drawn through this table rather than straight from the value, because the
/// reference animates the trim over the same 2 s player progress.
/// 弧是经这张表画出的，而不是直接取自数值，因为参考实现用同一个 2 秒进度驱动裁剪。
const DETERMINATE_TRIM: [(f32, f32); 7] = [
    (0.0, TRIM_FLOOR),
    (0.008_333_334, TRIM_FLOOR),
    (0.25, 0.25),
    (0.5, 0.5),
    (0.75, 0.75),
    (0.983_333_35, 0.966_666_64),
    (0.991_666_7, 1.0),
];

/// Everything a progress ring is built with.
/// 构建进度环所需的一切。
#[derive(Clone, Copy, Debug)]
pub struct ProgressRingParams {
    pub id: Id,
    /// `0.0..=1.0`; the caller clamps, the ring paints what it is handed.
    /// `0.0..=1.0`；调用方夹取，本控件按收到的值绘制。
    pub value: f32,
    pub indeterminate: bool,
    /// WinUI's `IsActive`; inactive hides the ring but keeps its slot.
    /// WinUI 的 `IsActive`；非活跃时隐藏圆环但保留槽位。
    pub active: bool,
    pub size: f32,
}

impl ProgressRingParams {
    pub fn new(id: Id, value: f32) -> Self {
        Self {
            id,
            value: value.clamp(0.0, 1.0),
            indeterminate: false,
            active: true,
            size: RING_SIZE,
        }
    }

    pub fn indeterminate(mut self, on: bool) -> Self {
        self.indeterminate = on;
        self
    }

    pub fn active(mut self, on: bool) -> Self {
        self.active = on;
        self
    }

    pub fn size(mut self, size: f32) -> Self {
        self.size = size;
        self
    }
}

/// One Fluent progress ring; the spinning phase is read here so `decl()` stays pure.
/// 一个 Fluent 进度环；旋转相位在此读取，`decl()` 保持纯函数。
pub struct FluentProgressRing {
    id: Id,
    value: f32,
    indeterminate: bool,
    active: bool,
    size: f32,
    foreground: Color,
    background: Color,
    /// The spinning visual's phase in turns of its two-second clock.
    /// 旋转视觉在自身两秒时钟上的相位（圈）。
    phase: f32,
}

impl FluentProgressRing {
    pub fn new(params: ProgressRingParams, ctx: &mut NodeCx<'_>, pack: &Style) -> Self {
        let ProgressRingParams {
            id,
            value,
            indeterminate,
            active,
            size,
        } = params;
        // Only the spinning ring owns a clock; a determinate one must let the frame loop rest.
        // 只有旋转态拥有时钟；确定态必须让帧循环歇下来。
        let phase = if indeterminate && active {
            turns(ctx.age(id.with("phase")))
        } else {
            0.0
        };
        Self {
            id,
            value,
            indeterminate,
            active,
            size: size.max(RING_MIN),
            foreground: role_of(pack, "ProgressRingForegroundThemeBrush"),
            background: role_of(pack, "ProgressRingBackgroundThemeBrush"),
            phase,
        }
    }

    /// The Lottie sprite's centreline radius and stroke width, in this ring's pixels.
    /// 该环像素下的 Lottie 精灵中线半径与描边宽度。
    fn stroke(&self) -> (Point, f32, f32) {
        let (canvas, radius, sprite) = if self.indeterminate {
            (INDETERMINATE_CANVAS, INDETERMINATE_RADIUS, INDETERMINATE_SPRITE)
        } else {
            (DETERMINATE_CANVAS, DETERMINATE_RADIUS, DETERMINATE_SPRITE)
        };
        let k = self.size / canvas;
        let path = radius * sprite * k;
        let width = LOTTIE_STROKE * sprite * k;
        let centre = Point::new(self.size * 0.5, self.size * 0.5);
        (centre, path, width)
    }
}

impl Widget for FluentProgressRing {
    fn handles_disabled(&self) -> bool {
        // The template has no disabled state, so nothing else may fade the ring either.
        // 模板没有禁用态，别处也不得再淡化圆环。
        true
    }

    fn decl(&self, _cx: &ui_widgets::Cx<'_, '_>) -> Decl {
        let id = self.id;
        let root = Decl::container(id, NodeKind::Box).size(SizeClass {
            width: AxisSize::fixed(self.size),
            height: AxisSize::fixed(self.size),
            grow_x: Grow::No,
            grow_y: Grow::No,
        });
        if !self.active {
            return root;
        }
        let (centre, path, width) = self.stroke();
        // The sector measures its radius at the stroke's outer edge, which is where the
        // Lottie stroke, centred on the path, reaches.
        // 弧图元以描边外缘为半径，而 Lottie 的描边以路径为中线向两侧展开。
        let radius = path + width * 0.5;
        let mut shapes = Vec::with_capacity(2);
        // The default `ProgressRingBackgroundThemeBrush` is transparent, so this track is
        // usually invisible; it still travels, as it does in the reference.
        // 默认的 `ProgressRingBackgroundThemeBrush` 是透明的，轨道通常看不见；
        // 但它仍随声明一起传递，与参考实现一致。
        shapes.push(arc(centre, radius, width, 0.0, 1.0, self.background, false));
        if self.indeterminate {
            let (start, end) = spinning_trim(self.phase);
            let turn = spinning_rotation(self.phase);
            shapes.push(arc(
                centre,
                radius,
                width,
                start + turn,
                end + turn,
                self.foreground,
                true,
            ));
        } else {
            let trim = determinate_trim(self.value);
            shapes.push(arc(centre, radius, width, 0.0, trim, self.foreground, true));
        }
        root.shapes(shapes)
    }
}

/// One stroked arc, stated in Lottie turns (zero at twelve o'clock, clockwise).
/// 一段描边弧，按 Lottie 的圈数表达（零点在十二点钟，顺时针）。
fn arc(
    centre: Point,
    radius: f32,
    thickness: f32,
    start: f32,
    end: f32,
    colour: Color,
    round_caps: bool,
) -> Shape {
    Shape::Sector {
        centre,
        radius,
        thickness,
        trim: (start - TWELVE_O_CLOCK, end - TWELVE_O_CLOCK),
        round_caps,
        colour,
    }
}

/// The phase of the two-second loop, in turns.
/// 两秒循环的相位，以圈计。
pub fn turns(age: f32) -> f32 {
    if age.is_finite() {
        (age.max(0.0) / RING_CYCLE).fract()
    } else {
        0.0
    }
}

/// The determinate arc's end, through the reference's own trim keyframes.
/// 确定态弧的末端，经参考实现自己的裁剪关键帧求得。
pub fn determinate_trim(value: f32) -> f32 {
    let p = value.clamp(0.0, 1.0);
    for pair in DETERMINATE_TRIM.windows(2) {
        let (p0, v0) = pair[0];
        let (p1, v1) = pair[1];
        if p <= p1 {
            let u = if p1 > p0 { (p - p0) / (p1 - p0) } else { 1.0 };
            return v0 + (v1 - v0) * EASE.apply(u.clamp(0.0, 1.0));
        }
    }
    1.0
}

/// The spinning container's turn count: 450° per half cycle, each half eased from rest.
/// 旋转容器的圈数：每半周期 450°，两半都从静止缓入缓出。
pub fn spinning_rotation(phase: f32) -> f32 {
    let half = 450.0 / 360.0;
    if phase < 0.5 {
        half * EASE.apply(phase / 0.5)
    } else {
        half + half * EASE.apply((phase - 0.5) / 0.5)
    }
}

/// The visible arc before rotation: the head grows to a half ring, then the tail catches up.
/// 旋转前的可见弧：头部先长到半环，随后尾部追赶。
pub fn spinning_trim(phase: f32) -> (f32, f32) {
    if phase < 0.5 {
        // The second sprite: `TrimEnd` 1e-4 → 0.5 while opacity holds at 1.
        // 第二个精灵：`TrimEnd` 从 1e-4 到 0.5，期间不透明度保持 1。
        (0.0, LOTTIE_HALF_END * EASE.apply(phase / 0.5) + TRIM_FLOOR)
    } else {
        // The first sprite: `TrimEnd` pinned at 0.5, `TrimStart` 0 → 0.5.
        // 第一个精灵：`TrimEnd` 钉在 0.5，`TrimStart` 从 0 到 0.5。
        (0.5 * EASE.apply((phase - 0.5) / 0.5), 0.5)
    }
}

/// `0.5 - 1e-4`, the second sprite's `TrimEnd` keyframe's destination.
/// 第二个精灵 `TrimEnd` 关键帧的终点值 `0.5 - 1e-4`。
const LOTTIE_HALF_END: f32 = 0.5 - TRIM_FLOOR;
