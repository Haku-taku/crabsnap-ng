//! WinUI 3 control geometry, transcribed from the theme resources.
//! 从主题资源抄录的 WinUI 3 控件几何。
//!
//! Authority: `microsoft-ui-xaml` @ `868fef9a`, `*_themeresources.xaml`; the resource key
//! each number came from is named in the row's comment.
//! 权威：`microsoft-ui-xaml` @ `868fef9a` 的 `*_themeresources.xaml`；每行注释给出数值的键名。

use ui_core::geom::Insets;
use ui_style::{ControlKind, ControlMetrics, ControlMetricsTable, TextRole};

const fn m(
    min_width: f32,
    min_height: f32,
    padding: Insets,
    border: f32,
    radius: f32,
    focus: Insets,
    icon: f32,
    font: TextRole,
) -> ControlMetrics {
    ControlMetrics {
        min_width,
        min_height,
        padding,
        border,
        radius,
        focus_margin: focus,
        icon_size: icon,
        font,
    }
}

/// The WinUI controls sized so far; every other row stays `EMPTY` until its control lands.
/// 已定尺寸的 WinUI 控件；其余行在各自控件落地前保持 `EMPTY`。
pub fn winui_controls() -> ControlMetricsTable {
    let mut rows = [ControlMetrics::EMPTY; ControlKind::COUNT];
    // ButtonPadding / ControlCornerRadius / ButtonBorderThemeThickness / FocusVisualMargin -3.
    // 按钮：内衬 11,5,11,6；圆角 4；描边 1；焦点外扩 -3；行高 32（WinUI 设计规格）。
    rows[ControlKind::Button as usize] = m(
        0.0,
        32.0,
        Insets::new(11.0, 5.0, 11.0, 6.0),
        1.0,
        4.0,
        Insets::all(-3.0),
        0.0,
        TextRole::Body,
    );
    // CheckBoxSize 20 / CheckBoxGlyphSize 12 / CheckBoxHeight 32 / CheckBoxMinWidth 120.
    // 勾选框：20 方框；12 字形；行高 32；最小宽 120；内衬 8,5,0,0；焦点外扩 -7,-3。
    rows[ControlKind::CheckBox as usize] = m(
        120.0,
        32.0,
        Insets::new(8.0, 5.0, 0.0, 0.0),
        1.0,
        4.0,
        Insets::new(-7.0, -3.0, -7.0, -3.0),
        12.0,
        TextRole::Body,
    );
    // RadioButton MinWidth 120 / glyph 12 / 20 pt ellipses / padding 8,6,0,0.
    // 单选钮：最小宽 120；外圈 20；字形 12；内衬 8,6,0,0；焦点外扩 -7,-3。
    rows[ControlKind::RadioButton as usize] = m(
        120.0,
        32.0,
        Insets::new(8.0, 6.0, 0.0, 0.0),
        1.0,
        4.0,
        Insets::new(-7.0, -3.0, -7.0, -3.0),
        12.0,
        TextRole::Body,
    );
    // ToggleSwitchThemeMinWidth 154; the switch column is 10 + 20 + 10 tall.
    // 开关：最小宽 154；开关列高 10 + 20 + 10；焦点外扩 -7,-3。
    rows[ControlKind::ToggleSwitch as usize] = m(
        154.0,
        40.0,
        Insets::ZERO,
        0.0,
        4.0,
        Insets::new(-7.0, -3.0, -7.0, -3.0),
        0.0,
        TextRole::Body,
    );
    // SliderHorizontalHeight 32 / SliderTrackCornerRadius 2 / FocusVisualMargin -7,0,-7,0.
    // 滑块：行高 32；轨道圆角 2；焦点外扩 -7,0。
    rows[ControlKind::Slider as usize] = m(
        0.0,
        32.0,
        Insets::ZERO,
        0.0,
        2.0,
        Insets::new(-7.0, 0.0, -7.0, 0.0),
        0.0,
        TextRole::Body,
    );
    // ComboBoxThemeMinWidth 64 / ComboBoxMinHeight 32 / ComboBoxPadding 12,5,0,7 /
    // ComboBoxBorderThemeThickness 1 / ControlCornerRadius 4 / glyph 12 / FocusVisualMargin -4.
    // 下拉框：最小 64×32；内衬 12,5,0,7；描边 1；圆角 4；字形 12；焦点外扩 -4。
    rows[ControlKind::ComboBox as usize] = m(
        64.0,
        32.0,
        Insets::new(12.0, 5.0, 0.0, 7.0),
        1.0,
        4.0,
        Insets::all(-4.0),
        12.0,
        TextRole::Body,
    );
    // NavigationViewItemOnLeftMinHeight 36 / OverlayCornerRadius 8 / NavigationViewItemBorderThickness 1.
    // 导航条目：行高 36；圆角取 `OverlayCornerRadius` 8；描边 1；图标 16；4,2 的边距归控件自己。
    rows[ControlKind::NavigationViewItem as usize] = m(
        0.0,
        36.0,
        Insets::ZERO,
        1.0,
        8.0,
        Insets::ZERO,
        16.0,
        TextRole::Body,
    );
    // MenuFlyoutItemThemePadding 11,8,11,9 / ControlCornerRadius 4 / IconRoot 16.
    // 菜单条目：内衬 11,8,11,9；圆角 4；图标 16；焦点框贴边。
    rows[ControlKind::MenuFlyoutItem as usize] = m(
        0.0,
        0.0,
        Insets::new(11.0, 8.0, 11.0, 9.0),
        0.0,
        4.0,
        Insets::ZERO,
        16.0,
        TextRole::Body,
    );
    ControlMetricsTable::from_standard(rows)
}

#[cfg(test)]
mod tests {
    use super::*;
    use ui_style::Density;

    #[test]
    fn the_controls_the_fluent_pack_ships_all_have_a_sized_row() {
        let rows = winui_controls();
        for kind in [
            ControlKind::Button,
            ControlKind::CheckBox,
            ControlKind::RadioButton,
            ControlKind::ToggleSwitch,
            ControlKind::Slider,
            ControlKind::ComboBox,
        ] {
            let row = rows.get(kind, Density::Standard);
            assert!(row.min_height > 0.0, "{kind:?} has no height floor");
        }
    }
}
