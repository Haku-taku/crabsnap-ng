//! The Fluent progress bar: a 3 dp slot, a 1 dp track and a rounded indicator.
//! Fluent 进度条：3dp 槽、1dp 轨道与圆角指示条。

use ui_core::geom::{Color, Corners};
use ui_core::layout::{AxisSize, Clip, Grow, Len, LenInsets, Overflow, SizeClass};
use ui_core::{Decl, Easing, Id, NodeKind};
use ui_style::Style;
use ui_widgets::{NodeCx, Widget};

use crate::paint::role_of;

/// `ProgressBarMinHeight`: the slot is 3 dp tall.
/// `ProgressBarMinHeight`：槽高 3dp。
pub const BAR_HEIGHT: f32 = 3.0;
/// `ProgressBarTrackHeight`: the empty track is one hairline.
/// `ProgressBarTrackHeight`：空轨道只有一条细线。
pub const TRACK_HEIGHT: f32 = 1.0;
/// `ProgressBarCornerRadius` / `ProgressBarTrackCornerRadius`.
/// `ProgressBarCornerRadius` / `ProgressBarTrackCornerRadius`。
pub const BAR_RADIUS: f32 = 1.5;
pub const TRACK_RADIUS: f32 = 0.5;
/// The indeterminate storyboard runs on a two-second clock.
/// 不确定态的动画以两秒为一个周期。
pub const CYCLE: f32 = 2.0;
/// The first bar is 40% of the width; the second 60% (`ProgressBar.cpp`).
/// 第一条占宽度 40%，第二条 60%（`ProgressBar.cpp`）。
pub const FIRST_WIDTH: f32 = 40.0;
pub const SECOND_WIDTH: f32 = 60.0;
/// `0.4,0.0,0.6,1.0` is the key spline both sweeps use.
/// 两条扫动都用 `0.4,0.0,0.6,1.0` 这条关键曲线。
pub const SWEEP: Easing = Easing::Cubic(0.4, 0.0, 0.6, 1.0);

/// WinUI's `ShowError` / `ShowPaused`, or neither.
/// WinUI 的 `ShowError` / `ShowPaused`，或两者皆无。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum ProgressStatus {
    #[default]
    Normal,
    Error,
    Paused,
}

/// One progress bar's inputs; the value is the caller's, the bar reports nothing.
/// 一个进度条的输入；数值归调用方，进度条不上报任何东西。
#[derive(Clone, Copy, Debug)]
pub struct ProgressBarParams {
    pub id: Id,
    /// `0.0..=1.0`; the caller clamps, the bar paints what it is handed.
    /// `0.0..=1.0`；调用方夹取，本控件按收到的值绘制。
    pub value: f32,
    pub indeterminate: bool,
    pub status: ProgressStatus,
}

impl ProgressBarParams {
    pub fn new(id: Id, value: f32) -> Self {
        Self {
            id,
            value: value.clamp(0.0, 1.0),
            indeterminate: false,
            status: ProgressStatus::Normal,
        }
    }

    pub fn indeterminate(mut self, on: bool) -> Self {
        self.indeterminate = on;
        self
    }

    pub fn status(mut self, status: ProgressStatus) -> Self {
        self.status = status;
        self
    }
}

/// One Fluent progress bar; the sweep phase is read here so `decl()` stays pure.
/// 一个 Fluent 进度条；扫动相位在此读取，`decl()` 保持纯函数。
pub struct FluentProgressBar {
    id: Id,
    value: f32,
    indeterminate: bool,
    fill: Color,
    track: Color,
    /// Left edges as percentages of the width, in the reference's own units.
    /// 两条指示条的左边缘，以宽度的百分比计，单位与参考实现一致。
    first_x: f32,
    second_x: f32,
}

impl FluentProgressBar {
    pub fn new(params: ProgressBarParams, ctx: &mut NodeCx<'_>, pack: &Style) -> Self {
        let ProgressBarParams {
            id,
            value,
            indeterminate,
            status,
        } = params;
        // An indeterminate bar is the only case that owns a clock; a determinate one must
        // let the frame loop rest, so it never asks for the time.
        // 只有不确定态拥有自己的时钟；确定态必须让帧循环歇下来，因此从不读取时间。
        let age = if indeterminate {
            ctx.age(id.with("phase"))
        } else {
            0.0
        };
        let fill = match status {
            ProgressStatus::Normal => role_of(pack, "ProgressBarForeground"),
            ProgressStatus::Error => role_of(pack, "ProgressBarErrorForegroundColor"),
            ProgressStatus::Paused => role_of(pack, "ProgressBarPausedForegroundColor"),
        };
        Self {
            id,
            value,
            indeterminate,
            fill,
            track: role_of(pack, "ProgressBarBackground"),
            first_x: first_sweep(age),
            second_x: second_sweep(age),
        }
    }
}

impl Widget for FluentProgressBar {
    fn handles_disabled(&self) -> bool {
        // WinUI's template has no disabled state; nothing else may fade the bar either.
        // WinUI 模板没有禁用态；别处也不得再淡化它。
        true
    }

    fn decl(&self, _cx: &ui_widgets::Cx<'_, '_>) -> Decl {
        let id = self.id;
        let slot = SizeClass {
            width: AxisSize::fill(0.0, 0.0),
            height: AxisSize::fixed(BAR_HEIGHT),
            grow_x: Grow::Yes,
            grow_y: Grow::No,
        };
        // The root clips to its own rect, exactly as `TemplateSettings.ClipRect` does.
        // 根节点裁到自身矩形，与 `TemplateSettings.ClipRect` 一致。
        let root = Decl::container(id, NodeKind::Box)
            // The root is the containing block the percentages resolve against.
            // 根节点就是百分比所相对的包含块。
            .relative()
            .size(slot)
            .corners(Corners::all(BAR_RADIUS))
            .clip(Clip {
                x: Overflow::Hidden,
                y: Overflow::Hidden,
            });
        if self.indeterminate {
            return root
                .child(bar(id.with("first"), self.fill, self.first_x, FIRST_WIDTH))
                .child(bar(id.with("second"), self.fill, self.second_x, SECOND_WIDTH));
        }
        // The track is a hairline centred in the slot; the indicator fills its height.
        // 轨道是槽中居中的细线；指示条占满槽高。
        let centre = (BAR_HEIGHT - TRACK_HEIGHT) * 0.5;
        let track = Decl::container(id.with("track"), NodeKind::Box)
            .absolute()
            .inset(LenInsets::new(
                Len::Px(0.0),
                Len::Px(centre),
                Len::Px(0.0),
                Len::Auto,
            ))
            .size(SizeClass {
                width: AxisSize::hug(0.0, 0.0),
                height: AxisSize::fixed(TRACK_HEIGHT),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .background(self.track, Corners::all(TRACK_RADIUS));
        root.child(track)
            .child(bar(id.with("value"), self.fill, 0.0, self.value * 100.0))
    }
}

/// One rounded bar: left edge at `x_pct` of the slot, `width_pct` wide, full height.
/// 一条圆角指示条：左边缘在槽宽的 `x_pct`，宽 `width_pct`，占满槽高。
///
/// Both edges are percentages, so the bar stretches between them without the layout ever
/// needing to know the slot's pixel width — the CSS way to place by fraction.
/// 两端都用百分比，指示条在两者之间拉伸，布局无需知道槽的像素宽——按比例定位的 CSS 做法。
fn bar(id: Id, fill: Color, x_pct: f32, width_pct: f32) -> Decl {
    Decl::container(id, NodeKind::Box)
        .absolute()
        .inset(LenInsets::new(
            Len::Pct(x_pct),
            Len::Px(0.0),
            Len::Pct(100.0 - x_pct - width_pct),
            Len::Px(0.0),
        ))
        .size(SizeClass {
            width: AxisSize::hug(0.0, 0.0),
            height: AxisSize::hug(0.0, 0.0),
            grow_x: Grow::No,
            grow_y: Grow::No,
        })
        .background(fill, Corners::all(BAR_RADIUS))
}

/// Phase of the two-second loop.
/// 两秒循环内的相位。
pub fn phase(age: f32) -> f32 {
    if age.is_finite() {
        age.max(0.0) % CYCLE
    } else {
        0.0
    }
}

/// First bar's left edge: -40% to 120% over 1.5 s, then held until the cycle ends.
/// 第一条的左边缘：1.5 秒内从 -40% 走到 120%，然后保持到周期结束。
pub fn first_sweep(age: f32) -> f32 {
    let t = (phase(age) / 1.5).clamp(0.0, 1.0);
    FIRST_WIDTH * (-1.0 + 4.0 * SWEEP.apply(t))
}

/// Second bar: holds at -90% for 0.75 s, then reaches 99.6% at the cycle's end.
/// 第二条：前 0.75 秒停在 -90%，随后在周期末尾到达 99.6%。
pub fn second_sweep(age: f32) -> f32 {
    let t = phase(age);
    if t < 0.75 {
        -1.5 * SECOND_WIDTH
    } else {
        let p = ((t - 0.75) / 1.25).clamp(0.0, 1.0);
        SECOND_WIDTH * (-1.5 + 3.16 * SWEEP.apply(p))
    }
}
