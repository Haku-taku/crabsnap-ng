//! One test module for the pack: geometry, slider, toggle, scaffold and scope together.
//! 本包唯一的测试模块：几何、滑块、开关、骨架与作用域合在一处。

use crate::*;


    #[test]
    fn the_knob_grows_to_the_reference_sizes_and_only_the_checked_one_passes_14_when_pressed() {
        // `SwitchKnobOn`/`SwitchKnobOff`: 12 rest, 14 hovered, 17 (on) / 14 (off) pressed.
        // `SwitchKnobOn`/`SwitchKnobOff`：静息 12，悬停 14，按下 17（选中）/ 14（未选中）。
        assert_eq!(knob_size(true, false, false), 12.0);
        assert_eq!(knob_size(true, true, false), 14.0);
        assert_eq!(knob_size(true, true, true), 17.0);
        assert_eq!(knob_size(false, true, true), 14.0);
    }

    #[test]
    fn the_knob_cell_travels_the_track_and_the_knob_stays_centred_in_it() {
        // The 20 pt cell moves 0 → 20, so the knob's centre runs 10 → 30 in the 40 track.
        // 20 点格子从 0 移到 20，滑块中心因此在 40 点轨道里从 10 走到 30。
        assert_eq!(knob_x(0.0, 12.0), 4.0);
        assert_eq!(knob_x(1.0, 12.0), 24.0);
        let size = knob_size(true, true, true);
        assert_eq!(knob_x(1.0, size), 21.5);
        assert_eq!(knob_x(1.0, size) + size * 0.5, 30.0, "centre stays at the cell's middle");
    }

    #[test]
    fn a_quick_drag_to_the_far_end_commits_on_before_the_knob_has_glided_there() {
        // One drag frame, then a release: the knob is still on the off side because the
        // 83 ms follow has barely started, but the finger is not, and the finger decides.
        // 只拖一帧就松手：83 毫秒的跟随刚开始，滑块仍停在关闭一侧，但手指不在那里——
        // 判定归手指。
        let pack = pack();
        let id = ui_core::Id::str("sw-quick");
        let mut anim = ui_core::AnimStore::new();
        let mut build = |state: ui_widgets::WidgetState, now: f64| {
            let mut node = ui_widgets::NodeCx::new(id, state, 1.0, now, &mut anim);
            FluentToggleSwitch::new(id, false, "On", &mut node, &pack)
        };
        let at = |x: f32| Some(ui_core::geom::Point { x, y: 10.0 });
        build(
            ui_widgets::WidgetState {
                pressed: true,
                local: at(2.0),
                ..Default::default()
            },
            0.0,
        );
        build(
            ui_widgets::WidgetState {
                pressed: true,
                dragging: true,
                drag_started: true,
                local: at(30.0),
                ..Default::default()
            },
            0.017,
        );
        let release = ui_widgets::WidgetState {
            dropped: true,
            local: at(30.0),
            ..Default::default()
        };
        let switch = build(release, 0.034);
        assert!(
            matches!(
                ui_widgets::Widget::change(&switch, &release, ui_core::geom::Rect::ZERO),
                Some(ui_core::Change::Toggled { on: Some(true) })
            ),
            "a flick to the far end after one frame must still commit on"
        );
    }

    #[test]
    fn a_held_scroll_button_steps_on_the_template_cadence() {
        // `RepeatButton Delay="50" Interval="100"`: the press clicks once, then 50 ms,
        // 150 ms, 250 ms… — the strip must not slide a whole tab per repeat.
        // `RepeatButton Delay="50" Interval="100"`：按下响一次，随后 50ms、150ms、
        // 250ms……——页签带不该每次连发就滑过一整页。
        assert_eq!(scroll_repeat_steps(0.0), 1.0);
        assert_eq!(scroll_repeat_steps(0.049), 1.0);
        assert_eq!(scroll_repeat_steps(0.050), 2.0);
        assert_eq!(scroll_repeat_steps(0.149), 2.0);
        assert_eq!(scroll_repeat_steps(0.150), 3.0);
        assert_eq!(scroll_repeat_steps(0.360), 5.0);
    }

    #[test]
    fn a_switch_hangs_its_focus_ring_at_the_template_margin() {
        // WinUI's `FocusVisualMargin` for ToggleSwitch is -7,-3: the ring is pulled 7 out
        // on the sides and 3 top and bottom. Attached, not merely computed.
        // WinUI 给 ToggleSwitch 的 `FocusVisualMargin` 是 -7,-3：环在左右外扩 7、上下 3。
        // 这里验证的是「接上去了」，不只是算出来了。
        let pack = pack();
        let id = ui_core::Id::str("sw-ring");
        let mut anim = ui_core::AnimStore::new();
        let mut node =
            ui_widgets::NodeCx::new(id, ui_widgets::WidgetState::default(), 1.0, 0.0, &mut anim);
        let switch = FluentToggleSwitch::new(id, false, "On", &mut node, &pack);
        let decl = ui_widgets::Cx::for_test(|cx| ui_widgets::Widget::decl(&switch, cx));
        let ring = decl
            .data
            .params()
            .and_then(|p| p.focus_visual)
            .expect("the switch carries a focus ring");
        assert_eq!(ring.margin, ui_core::geom::Insets::new(-7.0, -3.0, -7.0, -3.0));
        assert_eq!((ring.outer_width, ring.inner_width), (2.0, 1.0));
    }

    #[test]
    fn a_three_state_box_reaches_indeterminate_only_when_it_is_asked_to() {
        // `ToggleButton.OnToggle`: checked steps to indeterminate, and only then to off.
        // `ToggleButton.OnToggle`：选中先走到不确定，之后才回到未选。
        let pack = pack();
        let click = ui_widgets::WidgetState {
            clicked: true,
            ..Default::default()
        };
        let next = |state: CheckState, three: bool| {
            let id = ui_core::Id::str("cb-tri");
            let mut anim = ui_core::AnimStore::new();
            let mut node = ui_widgets::NodeCx::new(id, click, 1.0, 0.0, &mut anim);
            let mut params = CheckBoxParams::new(id, "All", state);
            if three {
                params = params.three_state();
            }
            let boxed = FluentCheckBox::new(params, &mut node, &pack);
            match ui_widgets::Widget::change(&boxed, &click, ui_core::geom::Rect::ZERO) {
                Some(ui_core::Change::Toggled { on }) => on,
                other => panic!("unexpected change {other:?}"),
            }
        };
        assert_eq!(next(CheckState::Unchecked, true), Some(true));
        assert_eq!(next(CheckState::Checked, true), None);
        assert_eq!(next(CheckState::Indeterminate, true), Some(false));
        // A two-state box never reports the third value; a mixed one settles to checked.
        // 两态方框从不报第三个值；不确定态落定为选中。
        assert_eq!(next(CheckState::Checked, false), Some(false));
        assert_eq!(next(CheckState::Indeterminate, false), Some(true));
    }

    #[test]
    fn the_slider_track_is_inset_by_half_the_thumb() {
        // The 18 pt thumb keeps its centre inside: 9..231 for a 240 pt slider.
        // 18 点滑块让中心留在盒内：240 点滑块对应 9..231。
        assert_eq!(SLIDER_INSET, SLIDER_THUMB * 0.5);
        assert_eq!(slider_thumb_x(0.0), SLIDER_INSET);
        assert_eq!(slider_thumb_x(1.0), SLIDER_WIDTH - SLIDER_INSET);
        assert_eq!(slider_value_at(SLIDER_INSET), 0.0);
        assert_eq!(slider_value_at(SLIDER_WIDTH - SLIDER_INSET), 1.0);
        assert!((slider_value_at(SLIDER_WIDTH * 0.5) - 0.5).abs() < 1e-6);
    }

    /// The drawn x of a node with this id, found by walking the declaration.
    /// 按 id 在声明里找到某个节点，读出它绘制时的 x。
    fn drawn_x(decl: &ui_core::Decl, id: ui_core::Id) -> Option<f32> {
        if decl.id == id {
            return Some(decl.offset.x);
        }
        decl.children.iter().find_map(|c| drawn_x(c, id))
    }

    #[test]
    fn a_slider_release_leaves_the_thumb_where_the_finger_left_it() {
        // The release frame arrives before the app has applied the new value, so gliding to
        // `value` there sends the thumb back to the drag's start and only then across.
        // 松手那一帧先于应用落值，此时滑向 `value` 会把滑块送回拖拽起点，再慢慢移过去。
        let pack = pack();
        let id = ui_core::Id::str("sl-release");
        let mut anim = ui_core::AnimStore::new();
        let mut build = |state: ui_widgets::WidgetState, now: f64| {
            let mut node = ui_widgets::NodeCx::new(id, state, 1.0, now, &mut anim);
            FluentSlider::new(id, 0.0, "Volume", &mut node, &pack)
        };
        let at = |x: f32| Some(ui_core::geom::Point { x, y: 16.0 });
        let thumb = |slider: &FluentSlider| {
            let decl = ui_widgets::Cx::for_test(|cx| ui_widgets::Widget::decl(slider, cx));
            drawn_x(&decl, id.with("thumb")).expect("the thumb is in the declaration")
        };
        build(
            ui_widgets::WidgetState {
                pressed: true,
                local: at(40.0),
                ..Default::default()
            },
            0.0,
        );
        build(
            ui_widgets::WidgetState {
                pressed: true,
                dragging: true,
                drag_started: true,
                local: at(200.0),
                ..Default::default()
            },
            0.017,
        );
        let dragged = build(
            ui_widgets::WidgetState {
                pressed: true,
                dragging: true,
                drag_started: true,
                local: at(200.0),
                ..Default::default()
            },
            0.034,
        );
        let far = thumb(&dragged);
        let released = build(
            ui_widgets::WidgetState {
                dropped: true,
                local: at(200.0),
                ..Default::default()
            },
            0.051,
        );
        assert!(
            (thumb(&released) - far).abs() < 0.5,
            "the release keeps the thumb at {far}, got {}",
            thumb(&released)
        );
    }

    /// Build one button from a state, with its own animation id so states cannot mix.
    /// 按某一状态构建一个按钮，各自用独立的动画 id，状态之间不会串。
    fn button(
        name: &'static str,
        variant: ButtonVariant,
        state: ui_widgets::WidgetState,
        pack: &ui_style::Style,
    ) -> FluentButton {
        let id = ui_core::Id::str(name);
        let mut anim = ui_core::AnimStore::new();
        let mut node = ui_widgets::NodeCx::new(id, state, 1.0, 0.0, &mut anim);
        FluentButton::new(ButtonParams::new(id, "Save").variant(variant), &mut node, pack)
    }

    #[test]
    fn each_button_variant_reads_its_own_brush_family() {
        // The three styles name `Button*`, `AccentButton*` and `SubtleButton*`; reading one
        // family for all three paints a white accent button on a dark theme.
        // 三种样式分别用 `Button*`、`AccentButton*` 与 `SubtleButton*`；三者共读一族会把
        // 暗色主题下的强调按钮画成白色。
        let pack = pack();
        let rest = ui_widgets::WidgetState::default();
        let accent = pack.ink("AccentButtonBackground").unwrap();
        let plain = pack.ink("ButtonBackground").unwrap();
        let subtle = pack.ink("SubtleButtonBackground").unwrap();
        assert_ne!(accent, plain, "the theme must tell the two apart");
        assert_eq!(button("a", ButtonVariant::Accent, rest, &pack).fill(), accent);
        assert_eq!(button("b", ButtonVariant::Default, rest, &pack).fill(), plain);
        assert_eq!(button("c", ButtonVariant::Subtle, rest, &pack).fill(), subtle);
    }

    #[test]
    fn a_text_link_is_accent_ink_over_no_fill_until_pointed_at() {
        // `HyperlinkButton_themeresources.xaml` maps its rest brushes to accent text over a
        // transparent fill; reading `SubtleButton*` instead would paint plain grey text.
        // `HyperlinkButton_themeresources.xaml` 的静止画刷是强调文字色配透明填充；误读
        // `SubtleButton*` 会把它画成普通灰字。
        let pack = pack();
        let rest = ui_widgets::WidgetState::default();
        let link = button("a", ButtonVariant::TextLink, rest, &pack);
        let accent_text = pack.ink("AccentTextFillColorPrimaryBrush").unwrap();
        // `SubtleFillColorTransparent` is white at alpha zero, so only alpha carries meaning.
        // `SubtleFillColorTransparent` 是零透明的白，只有 alpha 有意义。
        assert_eq!(link.fill().a, 0.0);
        assert_eq!(link.ink(), Some(accent_text));
        assert_ne!(button("b", ButtonVariant::Default, rest, &pack).ink(), Some(accent_text));
    }

    #[test]
    fn a_selected_destination_reads_the_selected_brush_family() {
        // The wash comes from `NavigationViewItemBackgroundSelected*` when picked and from
        // `NavigationViewItemBackground*` otherwise; one family for both loses the highlight.
        // 洗色在选中时取自 `NavigationViewItemBackgroundSelected*`，否则取自
        // `NavigationViewItemBackground*`；两者共用一族就失去了选中高亮。
        let pack = pack();
        let items = [
            NavigationItem::new(ui_core::Id::str("a"), "Home", "folder_open_16_regular"),
            NavigationItem::new(ui_core::Id::str("b"), "Print", "print_16_regular"),
            NavigationItem::new(ui_core::Id::str("c"), "Save", "save_16_regular").disabled(),
        ];
        let view = ui_widgets::Cx::for_test_mut(|cx| {
            FluentNavigationView::new(
                NavigationViewParams::new(ui_core::Id::str("nav"), &items).selected(1),
                cx,
                &pack,
            )
        });
        let plain = pack.ink("NavigationViewItemBackground").unwrap();
        let selected = pack.ink("NavigationViewItemBackgroundSelected").unwrap();
        assert_ne!(plain, selected, "the theme must tell the two apart");
        assert_eq!(view.item_fill(0), plain);
        assert_eq!(view.item_fill(1), selected);
        assert_eq!(
            view.item_fill(2),
            pack.ink("NavigationViewItemBackgroundDisabled").unwrap()
        );
    }

    #[test]
    fn a_disabled_button_wins_over_a_pressed_one_and_press_over_hover() {
        // `CommonStates` is one group: Disabled replaces Pressed, not blends with it.
        // `CommonStates` 是同一组状态：禁用取代按下，而不是与之混合。
        let pack = pack();
        let pressed = ui_widgets::WidgetState {
            pressed: true,
            hovered: true,
            ..Default::default()
        };
        let disabled = ui_widgets::WidgetState {
            disabled: true,
            ..pressed
        };
        assert_eq!(
            button("a", ButtonVariant::Default, pressed, &pack).fill(),
            pack.ink("ButtonBackgroundPressed").unwrap()
        );
        assert_eq!(
            button("b", ButtonVariant::Default, disabled, &pack).fill(),
            pack.ink("ButtonBackgroundDisabled").unwrap()
        );
    }

    #[test]
    fn the_indeterminate_bars_follow_the_two_second_storyboard() {
        // `ProgressBar.cpp`: bar one runs -40% → 120% over 1.5 s and holds; bar two waits
        // 0.75 s at -90% and lands at 99.6%. Both loop on the two-second clock.
        // `ProgressBar.cpp`：第一条 1.5 秒从 -40% 走到 120% 后保持；第二条在 -90% 等
        // 0.75 秒，最后到达 99.6%。两者都以两秒为周期循环。
        assert_eq!(first_sweep(0.0), -40.0);
        assert!((first_sweep(1.5) - 120.0).abs() < 1e-3, "first reaches 120%");
        assert!((first_sweep(1.9) - 120.0).abs() < 1e-3, "and holds there");
        assert_eq!(first_sweep(2.0), -40.0, "the cycle restarts");

        assert_eq!(second_sweep(0.0), -90.0);
        assert_eq!(second_sweep(0.74), -90.0, "bar two waits while bar one crosses");
        assert!(
            (second_sweep(1.999) - 99.6).abs() < 0.1,
            "second lands at 99.6%, got {}",
            second_sweep(1.999)
        );
    }

    #[test]
    fn the_spinning_ring_hands_its_head_to_its_tail_without_a_jump() {
        // `ProgressRingIndeterminate`: one sprite grows to a half ring, then the other keeps
        // that head and lets its tail catch up. The loop must close at both ends.
        // `ProgressRingIndeterminate`：一个精灵长到半环后，另一个守住这一头、让尾部追上。
        // 循环必须在两端闭合。
        let (start, end) = spinning_trim(0.0);
        assert!(end - start < 1e-3, "the loop starts nearly closed");
        assert_eq!(spinning_trim(0.5), (0.0, 0.5), "hand-over keeps the same half ring");
        let (start, end) = spinning_trim(1.0 - 1e-6);
        assert!(end - start < 1e-3, "and ends nearly closed");
        // Each half cycle turns 450°, so the ring covers 2.5 turns per two seconds.
        // 每半周期转 450°，因此两秒内共转 2.5 圈。
        assert!(spinning_rotation(0.0).abs() < 1e-6);
        assert!((spinning_rotation(0.5) - 1.25).abs() < 1e-6);
        assert!((spinning_rotation(1.0) - 2.5).abs() < 1e-6);
    }

    #[test]
    fn the_determinate_ring_draws_through_the_reference_trim_keyframes() {
        // The determinate Lottie eases `TrimEnd` between keyframes at 25, 50 and 75 %; its
        // spline is symmetric, so the arc equals the value except over the last 2 %.
        // 确定态 Lottie 在 25/50/75% 关键帧之间缓动 `TrimEnd`；曲线对称，故除最后 2%
        // 外弧长即数值。
        assert!(determinate_trim(0.0) < 1e-3);
        for v in [0.25, 0.5, 0.75] {
            assert!((determinate_trim(v) - v).abs() < 1e-6, "{v} lands on its keyframe");
        }
        assert!(
            (determinate_trim(0.99) - 0.9933).abs() < 1e-3,
            "the last keyframe pushes the arc past the value, got {}",
            determinate_trim(0.99)
        );
        assert_eq!(determinate_trim(1.0), 1.0, "a full ring must not fold to zero");
    }

    #[test]
    fn a_negative_sweep_position_is_allowed_and_bounded_by_the_clip() {
        // The first bar starts wholly outside the slot (CSS `left: -40%`); clamping it at
        // zero would make it appear out of nowhere instead of sliding in.
        // 第一条起点完全在槽外（CSS `left: -40%`）；夹到零会让它凭空出现而不是滑入。
        assert!(first_sweep(0.0) < 0.0);
        assert!(first_sweep(0.1) > first_sweep(0.0), "and it moves rightwards");
    }

    /// A tooltip panel's decl from one appearance; the anchor is irrelevant to the look.
    /// 某一外观下提示面板的声明；锚点与外观无关。
    fn tooltip_decl(appearance: ui_design::Appearance) -> ui_core::Decl {
        use ui_widgets::Widget;
        let params = ToolTipParams::new(
            ui_core::Id::str("tip"),
            "Save the file",
            ui_core::layout::Anchor::Node(ui_core::Id::str("save")),
        );
        ui_widgets::Cx::for_test_mut(|cx| {
            let tip = {
                let mut node = cx.at(ui_core::Id::str("tip"));
                FluentToolTip::new(params, &mut node, &pack_of(appearance))
            };
            tip.decl(cx)
        })
    }

    #[test]
    fn a_tooltip_fades_over_167_ms_and_paints_nothing_while_closed() {
        // `OpenStates` runs `FadeInThemeAnimation`/`FadeOutThemeAnimation` at the 167 ms
        // `ControlFastAnimationDuration`; a closed panel returns no content at all.
        // `OpenStates` 按 167ms 的 `ControlFastAnimationDuration` 跑淡入/淡出；
        // 关闭的面板不返回任何内容。
        let id = ui_core::Id::str("tip");
        let mut anim = ui_core::AnimStore::new();
        let alpha = |anim: &mut ui_core::AnimStore, now: f64, open: bool| {
            let params = ToolTipParams::new(
                id,
                "Save the file",
                ui_core::layout::Anchor::Node(ui_core::Id::str("save")),
            )
            .open(open);
            let mut node = ui_widgets::NodeCx::new(id, Default::default(), 1.0, now, anim);
            FluentToolTip::new(params, &mut node, &pack()).alpha()
        };
        assert_eq!(alpha(&mut anim, 0.0, false), 0.0, "mounted closed");
        assert_eq!(alpha(&mut anim, 0.1, true), 0.0, "opening starts from nothing");
        assert!(
            (alpha(&mut anim, 0.1835, true) - 0.5).abs() < 0.02,
            "halfway at 83.5 ms"
        );
        assert_eq!(alpha(&mut anim, 0.4, true), 1.0, "and settles after 167 ms");
        assert_eq!(alpha(&mut anim, 0.45, false), 1.0, "closing starts from full");
        assert!((alpha(&mut anim, 0.5335, false) - 0.5).abs() < 0.02, "closing mirrors it");
        assert_eq!(alpha(&mut anim, 0.7, false), 0.0, "and is gone after 167 ms");
    }

    #[test]
    fn a_closed_tooltip_takes_no_slot_in_the_flow_it_floats_over() {
        // The app keeps the panel mounted through the fade, so a closed one must still be
        // out of flow: an in-flow stand-in would add a gap and shift the page under it.
        // 应用会让面板在淡出期间留在树里，关闭的那个因此仍须在流外：
        // 留在流里的替身会多出一个间隙，把它所浮于其上的页面顶动。
        use ui_widgets::Widget;
        let decl = ui_widgets::Cx::for_test_mut(|cx| {
            let params = ToolTipParams::new(
                ui_core::Id::str("tip"),
                "Save the file",
                ui_core::layout::Anchor::Node(ui_core::Id::str("save")),
            )
            .open(false);
            let tip = {
                let mut node = cx.at(ui_core::Id::str("tip"));
                FluentToolTip::new(params, &mut node, &pack())
            };
            tip.decl(cx)
        });
        assert_eq!(
            decl.placement.position,
            ui_core::layout::Position::Absolute,
            "a closed tooltip is out of flow"
        );
        assert!(decl.placement.overlay.is_some(), "and is still an overlay");
    }

    #[test]
    fn a_tooltip_is_a_320_capped_panel_above_its_anchor() {
        // `ToolTipMaxWidth` caps the panel, `ToolTipBorderPadding` insets the text, and the
        // default placement is `Top` with the panel centred on the anchor.
        // `ToolTipMaxWidth` 封顶面板，`ToolTipBorderPadding` 内衬文本，默认摆在 `Top`，
        // 面板在锚点上居中。
        let decl = tooltip_decl(ui_design::Appearance::Dark);
        assert_eq!(decl.size_class.width.hint, 320.0, "the comfort hint is the cap");
        assert_eq!(decl.size_class.width.sizing, ui_core::layout::Sizing::Fit);
        let overlay = decl.placement.overlay.expect("a tooltip is an anchored overlay");
        assert_eq!(overlay.side, ui_core::layout::Side::Above);
        assert_eq!(overlay.align, ui_core::layout::OverlayAlign::Center);
        assert!(overlay.flip, "it flips below when there is no room above");
        assert_eq!(
            decl.box_model.padding,
            ui_core::geom::Insets {
                left: 9.0,
                top: 6.0,
                right: 9.0,
                bottom: 8.0,
            }
        );
        let params = decl.data.params().expect("the panel is a container");
        assert_eq!(params.corners, Some(ui_core::geom::Corners::all(4.0)));
        let text = decl.children.first().expect("the panel holds its text");
        let ui_core::tree::NodeData::Text { block, .. } = &text.data else {
            panic!("the tooltip's child is its text");
        };
        assert_eq!(block.runs[0].style.size, 12.0);
    }

    #[test]
    fn the_tooltip_acrylic_follows_the_theme_column_of_the_reference() {
        // `AcrylicBrush_themeresources.xaml`: dark `#2C2C2C` at `TintOpacity 0.15` plus a
        // 0.96 luminosity wash; light leaves the tint stage off at 0.85.
        // `AcrylicBrush_themeresources.xaml`：暗色 `#2C2C2C`、`TintOpacity 0.15`，再加
        // 0.96 的明度洗色；浅色的着色阶段为 0，明度 0.85。
        let material = |appearance| {
            let decl = tooltip_decl(appearance);
            let blur = decl
                .data
                .params()
                .and_then(|p| p.backdrop_blur)
                .expect("the panel frosts what is behind it");
            match blur.material {
                ui_core::draw::BackdropMaterial::Acrylic(a) => (a, blur.sigma),
                other => panic!("a tooltip is acrylic, got {other:?}"),
            }
        };
        let (dark, sigma) = material(ui_design::Appearance::Dark);
        assert!((dark.tint.r - 0x2C as f32 / 255.0).abs() < 1e-3, "dark tint");
        assert!((dark.tint.a - 0.15).abs() < 1e-3, "dark tint opacity");
        assert!((dark.luminosity.a - 0.96).abs() < 1e-3, "dark luminosity");
        assert_eq!(sigma, crate::material::BLUR_SIGMA);

        let (light, _) = material(ui_design::Appearance::Light);
        assert_eq!(light.tint.a, 0.0, "the light theme leaves the tint stage off");
        assert!((light.luminosity.a - 0.85).abs() < 1e-3, "light luminosity");
    }

    #[test]
    fn the_slider_dot_grows_on_hover_and_sinks_under_the_finger() {
        // `SliderInnerThumb` key frames: 12 rest, 14 hovered, 10 pressed, 14 disabled, and
        // the states are exclusive — a disabled slider never shrinks under the finger.
        // `SliderInnerThumb` 关键帧：12/14/10/14，且状态互斥——禁用滑块不会在指下收缩。
        assert_eq!(dot_size(false, false, false), 12.0);
        assert_eq!(dot_size(true, false, false), 14.0);
        assert_eq!(dot_size(true, true, false), 10.0);
        assert_eq!(dot_size(true, true, true), 14.0);
    }

    /// Build one info bar from a severity, with its own id so no two share a slot.
    /// 按某一级别构建一条信息栏，各自用独立 id，槽位不会串。
    fn infobar(name: &'static str, severity: InfoBarSeverity, open: bool) -> FluentInfoBar {
        let id = ui_core::Id::str(name);
        let mut anim = ui_core::AnimStore::new();
        let mut node = ui_widgets::NodeCx::new(id, Default::default(), 1.0, 0.0, &mut anim);
        FluentInfoBar::new(
            InfoBarParams::new(id, "Update available.", "Restart to apply.")
                .severity(severity)
                .open(open),
            &mut node,
            Default::default(),
            &pack(),
        )
    }

    #[test]
    fn each_severity_reads_its_own_background_and_icon_brushes() {
        // WinUI's dictionary keys three brushes per severity; one shared family paints
        // all four bars the informational tint.
        // WinUI 每个级别索引三支画刷；共用一族会把四条都画成 informational 色。
        let pack = pack();
        let cases = [
            (
                InfoBarSeverity::Informational,
                "InfoBarInformationalSeverityBackgroundBrush",
                "InfoBarInformationalSeverityIconBackground",
                "InfoBarInformationalSeverityIconForeground",
            ),
            (
                InfoBarSeverity::Success,
                "InfoBarSuccessSeverityBackgroundBrush",
                "InfoBarSuccessSeverityIconBackground",
                "InfoBarSuccessSeverityIconForeground",
            ),
            (
                InfoBarSeverity::Warning,
                "InfoBarWarningSeverityBackgroundBrush",
                "InfoBarWarningSeverityIconBackground",
                "InfoBarWarningSeverityIconForeground",
            ),
            (
                InfoBarSeverity::Error,
                "InfoBarErrorSeverityBackgroundBrush",
                "InfoBarErrorSeverityIconBackground",
                "InfoBarErrorSeverityIconForeground",
            ),
        ];
        for (severity, fill_key, disc_key, ink_key) in cases {
            let (fill, icon_fill, icon_ink) = infobar("bar", severity, true).severity_colours();
            assert_eq!(fill, pack.ink(fill_key).unwrap(), "{fill_key}");
            assert_eq!(icon_fill, pack.ink(disc_key).unwrap(), "{disc_key}");
            assert_eq!(icon_ink, pack.ink(ink_key).unwrap(), "{ink_key}");
        }
    }

    #[test]
    fn a_closed_info_bar_takes_no_space_and_paints_nothing() {
        // `IsOpen=false` collapses the bar; an in-flow stand-in would keep a gap and the
        // rounded fill would still paint.
        // `IsOpen=false` 收起条带；留在流里的替身会占掉一个间隙，圆角底色也照旧绘制。
        use ui_widgets::Widget;
        let decl = ui_widgets::Cx::for_test_mut(|cx| {
            infobar("bar", InfoBarSeverity::Success, false).decl(cx)
        });
        assert_eq!(
            decl.placement.position,
            ui_core::layout::Position::Absolute,
            "a closed bar is out of flow"
        );
        assert_eq!(decl.size_class.width.max, 0.0, "and takes no width");
        assert_eq!(decl.size_class.height.max, 0.0, "nor height");
    }

    /// Lay one info bar out at `width`, in a column as tall as it needs.
    /// 在 `width` 宽的列里摆出一条信息栏。
    fn infobar_tree(width: f32, title: &str, message: &str) -> ui_core::Tree {
        use ui_core::layout::LayoutEngine;
        use ui_widgets::Widget;
        let id = ui_core::Id::str("bar");
        let p = pack();
        let decl = ui_widgets::Cx::for_test_mut(|cx| {
            let close = cx.at(id.with("close")).state();
            let mut node = cx.at(id);
            FluentInfoBar::new(InfoBarParams::new(id, title, message), &mut node, close, &p)
                .decl(cx)
        });
        let window = ui_core::Decl::container(ui_core::Id::str("window"), ui_core::NodeKind::Column)
            .size(ui_core::layout::SizeClass::fixed(width, 400.0))
            .child(decl);
        let mut tree = ui_core::Tree::new();
        tree.apply(&window);
        let mut engine = ui_core::layout_engine::BuiltinLayout::new(
            ui_core::layout_engine::MonospaceMeasure::default(),
        );
        let root = tree.root().expect("root");
        engine.solve(
            &mut tree,
            root,
            ui_core::layout::Constraints::loose(ui_core::geom::Size::new(width, 400.0)),
        );
        tree
    }

    #[test]
    fn a_stacked_panel_keeps_14_above_its_first_label_and_18_below_its_last() {
        // `InfoBarPanel` drops the first child's leading margin and adds
        // `InfoBarPanelVerticalOrientationPadding` 0,14,0,18 around the stack.
        // `InfoBarPanel` 丢掉首个子节点的前边距，并在堆叠上下补
        // `InfoBarPanelVerticalOrientationPadding` 0,14,0,18。
        let id = ui_core::Id::str("bar");
        let tree = infobar_tree(
            320.0,
            "Backup complete",
            "All documents were uploaded successfully, and this bar is narrow enough \
             that the message can no longer sit beside its title.",
        );
        let bar = box_of(&tree, id);
        let title = box_of(&tree, id.with("title"));
        let message = box_of(&tree, id.with("message"));
        assert_eq!(title.origin.y, PANEL_PAD_TOP, "the panel's top padding, not a margin");
        assert_eq!(
            bar.origin.y + bar.size.h - (message.origin.y + message.size.h),
            PANEL_PAD_BOTTOM,
            "the panel's bottom padding reaches the bar's edge"
        );
    }

    /// Lay a dialog out in an 800×600 window, with the measurer the engine ships.
    /// 在 800×600 的窗口里摆出一个对话框，用引擎自带的测量器。
    fn dialog_tree(params: ContentDialogParams<'_>) -> ui_core::Tree {
        use ui_core::layout::LayoutEngine;
        use ui_widgets::Widget;
        let decl = ui_widgets::Cx::for_test_mut(|cx| {
            FluentContentDialog::new(params, cx, &pack()).decl(cx)
        });
        let window =
            ui_core::Decl::container(ui_core::Id::str("window"), ui_core::NodeKind::Column)
                .size(ui_core::layout::SizeClass::fixed(800.0, 600.0))
                .child(decl);
        let mut tree = ui_core::Tree::new();
        tree.apply(&window);
        let mut engine = ui_core::layout_engine::BuiltinLayout::new(
            ui_core::layout_engine::MonospaceMeasure::default(),
        );
        let root = tree.root().expect("root");
        engine.solve(
            &mut tree,
            root,
            ui_core::layout::Constraints::loose(ui_core::geom::Size::new(800.0, 600.0)),
        );
        tree
    }

    /// The box the node `id` landed on.
    /// 节点 `id` 最终得到的盒子。
    fn box_of(tree: &ui_core::Tree, id: ui_core::Id) -> ui_core::geom::Rect {
        tree.get(tree.find_by_id(id).expect("node")).expect("node").rect
    }

    /// The check glyph's 12 pt em box takes half of the 20 pt box's slack on both axes.
    /// 勾选字形的 12pt em 盒在 20pt 方块里，两个轴各取一半余量。
    #[test]
    fn the_check_glyph_sits_centred_in_its_box() {
        use ui_core::layout::LayoutEngine;
        use ui_widgets::Widget;
        let id = ui_core::Id::str("cb");
        let p = pack();
        let decl = ui_widgets::Cx::for_test_mut(|cx| {
            let mut node = cx.at(id);
            FluentCheckBox::new(
                CheckBoxParams::new(id, "x", CheckState::Checked),
                &mut node,
                &p,
            )
            .decl(cx)
        });
        let window =
            ui_core::Decl::container(ui_core::Id::str("window"), ui_core::NodeKind::Column)
                .size(ui_core::layout::SizeClass::fixed(200.0, 100.0))
                .child(decl);
        let mut tree = ui_core::Tree::new();
        tree.apply(&window);
        let mut engine = ui_core::layout_engine::BuiltinLayout::new(
            ui_core::layout_engine::MonospaceMeasure::default(),
        );
        let root = tree.root().expect("root");
        engine.solve(
            &mut tree,
            root,
            ui_core::layout::Constraints::loose(ui_core::geom::Size::new(200.0, 100.0)),
        );

        let square = box_of(&tree, id.with("box"));
        let glyph = box_of(&tree, id.with("glyph"));
        assert_eq!(
            (
                glyph.origin.x - square.origin.x,
                glyph.origin.y - square.origin.y
            ),
            (4.0, 4.0),
            "centred, not parked at the box's corner"
        );
    }

    #[test]
    fn the_command_area_is_the_318_by_80_grid_with_two_equal_columns() {
        // `ContentDialogIntegrationTests` expects 318×80 for a 320 pt dialog: 24 pt padding,
        // a 32 pt button row, and the 1 pt border on each side.
        // `ContentDialogIntegrationTests` 对 320pt 对话框期望 318×80：
        // 24pt 内衬、32pt 按钮行，以及两侧各 1pt 的描边。
        let id = ui_core::Id::str("dlg");
        let tree = dialog_tree(
            ContentDialogParams::new(id, "Save changes?", "This cannot be undone.")
                .primary("Save")
                .secondary("Cancel"),
        );
        let surface = box_of(&tree, id.with("surface"));
        assert_eq!(surface.size.w, DIALOG_MIN_WIDTH, "the 320 pt floor holds");
        let commands = box_of(&tree, id.with("commands"));
        assert_eq!(commands.size.w, 318.0, "the border takes its point out of the box");
        assert_eq!(commands.size.h, 80.0, "24 + 32 + 24");
        let primary = box_of(&tree, id.with("primary"));
        let secondary = box_of(&tree, id.with("secondary"));
        assert_eq!(primary.size.w, secondary.size.w, "the `*` columns share equally");
        assert_eq!(
            primary.size.w,
            (318.0 - 2.0 * DIALOG_PAD - DIALOG_BUTTON_SPACING) * 0.5
        );
        assert_eq!(
            secondary.origin.x - (primary.origin.x + primary.size.w),
            DIALOG_BUTTON_SPACING,
            "the two columns are 8 pt apart"
        );
    }

    #[test]
    fn three_actions_split_the_command_area_into_three_equal_columns() {
        // `AllVisible` gives `SecondaryColumn` a `*` and moves the secondary into it, so all
        // three buttons fill equal shares with an 8 pt gap between each pair.
        // `AllVisible` 给 `SecondaryColumn` 一个 `*` 并把次按钮移进去，于是三个按钮
        // 等分命令区，每两者之间留 8pt。
        let id = ui_core::Id::str("dlg");
        let tree = dialog_tree(
            ContentDialogParams::new(id, "Title", "Body")
                .primary("Reset")
                .secondary("Later")
                .close("Cancel"),
        );
        let commands = box_of(&tree, id.with("commands"));
        let each = (commands.size.w - 2.0 * DIALOG_PAD - 2.0 * DIALOG_BUTTON_SPACING) / 3.0;
        let mut left = commands.origin.x + DIALOG_PAD;
        for slot in ["primary", "secondary", "close"] {
            let b = box_of(&tree, id.with(slot));
            assert_eq!(b.size.w, each, "{slot} takes a third");
            assert_eq!(b.origin.x, left, "{slot} sits in its own column");
            left += each + DIALOG_BUTTON_SPACING;
        }
    }

    #[test]
    fn a_lone_action_still_sits_in_the_right_half() {
        // `PrimaryVisible` moves the button to the last `*` column and collapses the rest;
        // the empty primary column keeps its share, so the button is not centred.
        // `PrimaryVisible` 把按钮移到最后一个 `*` 列并收起其余两列；
        // 空着的主列照样占自己那一份，按钮因此不居中。
        let id = ui_core::Id::str("dlg");
        let tree = dialog_tree(ContentDialogParams::new(id, "Title", "Body").close("OK"));
        let commands = box_of(&tree, id.with("commands"));
        let close = box_of(&tree, id.with("close"));
        let half = (commands.size.w - 2.0 * DIALOG_PAD - DIALOG_BUTTON_SPACING) * 0.5;
        assert_eq!(close.size.w, half);
        assert_eq!(
            close.origin.x,
            commands.origin.x + DIALOG_PAD + half + DIALOG_BUTTON_SPACING
        );
    }

    #[test]
    fn the_surface_stops_at_548_however_long_the_body_is() {
        // `ContentDialogMaxWidth` caps the surface; the body wraps inside it instead of
        // widening the dialog past the reference's ceiling.
        // `ContentDialogMaxWidth` 封住表面；正文在其中换行，而不是把对话框撑过参考的上限。
        let id = ui_core::Id::str("dlg");
        let body = "word ".repeat(200);
        let tree = dialog_tree(ContentDialogParams::new(id, "Title", &body).primary("OK"));
        let width = box_of(&tree, id.with("surface")).size.w;
        assert!(width <= DIALOG_MAX_WIDTH, "the cap holds: {width}");
        assert!(
            width > DIALOG_MAX_WIDTH - 2.0 * DIALOG_PAD,
            "and the wrapped body did fill it: {width}"
        );
    }

    /// The fills a dialog resolves for its actions under one default-button choice.
    /// 某一种默认按钮选择下，对话框为各动作解析出的填充色。
    fn dialog_fills(button: ContentDialogButton) -> Vec<(&'static str, ui_core::geom::Color)> {
        let pack = pack();
        let id = ui_core::Id::str("dlg");
        ui_widgets::Cx::for_test_mut(|cx| {
            FluentContentDialog::new(
                ContentDialogParams::new(id, "T", "B")
                    .primary("Save")
                    .secondary("Cancel")
                    .default_button(button),
                cx,
                &pack,
            )
            .action_fills()
        })
    }

    #[test]
    fn only_the_default_button_takes_the_accent_fill() {
        // `DefaultButtonStates` swaps in `AccentButtonStyle` for the chosen button alone,
        // and `ContentDialogButton.None` is the property's own default.
        // `DefaultButtonStates` 只给被选中的按钮换成 `AccentButtonStyle`，
        // 而 `ContentDialogButton.None` 正是该属性自身的默认值。
        let pack = pack();
        let accent = pack.ink("AccentButtonBackground").unwrap();
        let plain = pack.ink("ButtonBackground").unwrap();
        for (button, accented) in [
            (ContentDialogButton::None, None),
            (ContentDialogButton::Primary, Some("primary")),
            (ContentDialogButton::Secondary, Some("secondary")),
        ] {
            let fills = dialog_fills(button);
            assert_eq!(fills.len(), 2, "both actions are there");
            for (slot, fill) in fills {
                let want = if Some(slot) == accented { accent } else { plain };
                assert_eq!(fill, want, "{button:?} / {slot}");
            }
        }
    }

    /// What one dialog reports when the engine says this chord fired on it.
    /// 引擎说本组合键在对话框上触发时，它上报什么。
    fn dialog_shortcut_reports(button: ContentDialogButton, chord: ui_core::ShortcutId) -> Option<ui_core::Id> {
        let pack = pack();
        let id = ui_core::Id::str("dlg");
        ui_widgets::Cx::for_test_mut(|cx| {
            let dialog = FluentContentDialog::new(
                ContentDialogParams::new(id, "T", "B")
                    .primary("Save")
                    .secondary("Later")
                    .close("Cancel")
                    .default_button(button),
                cx,
                &pack,
            );
            use ui_widgets::Widget;
            let state = ui_widgets::WidgetState {
                shortcut: Some(chord),
                ..Default::default()
            };
            match dialog.change(&state, ui_core::geom::Rect::ZERO) {
                Some(ui_core::Change::Selected(Some(picked))) => Some(picked),
                _ => None,
            }
        })
    }

    #[test]
    fn enter_presses_the_default_button_and_escape_the_close_one() {
        // WinUI's `ContentDialog` binds Enter to `DefaultButton` and Escape to the close
        // button, wherever focus sits; with no default, Enter reports nothing.
        // WinUI 的 `ContentDialog` 把 Enter 绑到 `DefaultButton`、Escape 绑到关闭按钮，
        // 无论焦点在哪；没有默认按钮时 Enter 什么都不上报。
        use ui_core::ShortcutId;
        let base = ui_core::Id::str("dlg");
        assert_eq!(
            dialog_shortcut_reports(ContentDialogButton::Primary, DIALOG_DEFAULT_SHORTCUT),
            Some(base.with("primary"))
        );
        assert_eq!(
            dialog_shortcut_reports(ContentDialogButton::Primary, DIALOG_CLOSE_SHORTCUT),
            Some(base.with("close"))
        );
        assert_eq!(
            dialog_shortcut_reports(ContentDialogButton::None, DIALOG_DEFAULT_SHORTCUT),
            None,
            "no default button, no Enter action"
        );
        assert_eq!(
            dialog_shortcut_reports(ContentDialogButton::Primary, ShortcutId("other")),
            None,
            "a chord it did not bind is not its business"
        );
    }

    #[test]
    fn a_dialog_declares_its_way_in_and_out_instead_of_arriving_at_rest() {
        // A widget-side tween on a node that did not exist last frame has no start value,
        // so the dialog used to appear at full opacity; the entrance is declared instead,
        // with the fade and the scale on the two clocks `DialogShowingStates` gives them.
        // 上一帧不存在的节点上没有起点，控件侧的补间因此让对话框直接满不透明地出现；
        // 改为声明入场，淡与缩放按 `DialogShowingStates` 各走各的时钟。
        let id = ui_core::Id::str("dlg");
        let tree = dialog_tree(ContentDialogParams::new(id, "Title", "Body").close("OK"));
        let root = tree
            .get(tree.find_by_id(id).expect("the dialog root"))
            .expect("the dialog root");
        let enter = root
            .data
            .params()
            .and_then(|p| p.enter)
            .expect("the smoke layer declares its way in");
        assert_eq!(enter.opacity, 0.0, "it must start invisible");
        assert_eq!(enter.spec, DIALOG_FADE, "the 83 ms linear fade");
        let exit = root
            .data
            .params()
            .and_then(|p| p.exit)
            .expect("and its way out, so the engine holds it");
        assert_eq!(exit.spec, DIALOG_FADE);
        let surface = tree
            .get(tree.find_by_id(id.with("surface")).expect("the surface"))
            .expect("the surface");
        let scale = surface
            .data
            .params()
            .and_then(|p| p.enter)
            .expect("the surface scales");
        assert_eq!(
            scale.scale, DIALOG_SCALE_FROM,
            "the surface starts at ScaleTransform 1.05, got {scale:?}"
        );
        assert_eq!(
            scale.spec, DIALOG_SCALE_IN,
            "its scale takes 250 ms, not the 83 the fade gets"
        );
        assert_eq!(scale.opacity, 1.0, "the surface does not fade on its own");
    }

    /// A row without an icon still starts where the icons do, and a divider runs edge to edge.
    /// 没有图标的行仍从图标列起笔，分隔线则一直跑到呈现器的两端。
    #[test]
    fn the_placeholder_aligns_every_label_and_the_divider_crosses_the_panel() {
        use ui_core::layout::{Anchor, LayoutEngine};
        use ui_core::Decl;
        use ui_widgets::Widget;
        let id = ui_core::Id::str("menu");
        let with_icon = id.with(("item", 0usize));
        let without = id.with(("item", 1usize));
        let entries = [
            MenuFlyoutEntry::Item(
                MenuFlyoutItem::new(with_icon, "Open")
                    .icon(glyphs::icon("folder_open_16_regular").expect("glyph")),
            ),
            MenuFlyoutEntry::Separator,
            MenuFlyoutEntry::Item(MenuFlyoutItem::new(without, "Print")),
        ];
        let decl = ui_widgets::Cx::for_test_mut(|cx| {
            FluentMenuFlyout::new(
                MenuFlyoutParams::new(id, Anchor::Node(ui_core::Id::str("anchor")), &entries),
                cx,
                &pack(),
            )
            .decl(cx)
        });
        let window = Decl::container(ui_core::Id::str("window"), ui_core::NodeKind::Column)
            .size(ui_core::layout::SizeClass::fixed(400.0, 400.0))
            .child(
                Decl::container(ui_core::Id::str("anchor"), ui_core::NodeKind::Box)
                    .size(ui_core::layout::SizeClass::fixed(120.0, 32.0)),
            )
            .child(decl);
        let mut tree = ui_core::Tree::new();
        tree.apply(&window);
        let mut engine = ui_core::layout_engine::BuiltinLayout::new(
            ui_core::layout_engine::MonospaceMeasure::default(),
        );
        let root = tree.root().expect("root");
        engine.solve(
            &mut tree,
            root,
            ui_core::layout::Constraints::loose(ui_core::geom::Size::new(400.0, 400.0)),
        );

        let icon_label = box_of(&tree, with_icon.with("label"));
        let plain_label = box_of(&tree, without.with("label"));
        assert_eq!(
            plain_label.origin.x, icon_label.origin.x,
            "the placeholder keeps the labels on one column"
        );
        // The template puts the icon and the text in one column: the text's 28 pt margin is
        // what the icon and the gap after it add up to.
        // 模板把图标与文本放在同一列：文本那 28pt 外边距正是图标加其后空隙的合计。
        assert_eq!(
            icon_label.origin.x - box_of(&tree, with_icon).origin.x,
            ITEM_PAD.left + PLACEHOLDER
        );
        let panel = box_of(&tree, id);
        let divider = box_of(&tree, id.with(("separator", 1usize)));
        assert_eq!(divider.origin.x, panel.origin.x + MENU_SEPARATOR_PAD.left);
        assert_eq!(
            divider.size.w,
            panel.size.w - MENU_SEPARATOR_PAD.left - MENU_SEPARATOR_PAD.right
        );
    }


    /// Lay one combo box out in a 400×400 window, with the measurer the engine ships.
    /// 在 400×400 的窗口里摆出一个下拉框，用引擎自带的测量器。
    fn combo_tree(params: ComboBoxParams<'_>) -> ui_core::Tree {
        use ui_core::layout::LayoutEngine;
        use ui_widgets::Widget;
        let decl =
            ui_widgets::Cx::for_test_mut(|cx| FluentComboBox::new(params, cx, &pack()).decl(cx));
        let window =
            ui_core::Decl::container(ui_core::Id::str("window"), ui_core::NodeKind::Column)
                .size(ui_core::layout::SizeClass::fixed(400.0, 400.0))
                .child(decl);
        let mut tree = ui_core::Tree::new();
        tree.apply(&window);
        let mut engine = ui_core::layout_engine::BuiltinLayout::new(
            ui_core::layout_engine::MonospaceMeasure::default(),
        );
        let root = tree.root().expect("root");
        engine.solve(
            &mut tree,
            root,
            ui_core::layout::Constraints::loose(ui_core::geom::Size::new(400.0, 400.0)),
        );
        tree
    }

    fn combo_items() -> [ComboBoxItem; 3] {
        [
            ComboBoxItem::new(ui_core::Id::str("one"), "One"),
            ComboBoxItem::new(ui_core::Id::str("two"), "Two"),
            ComboBoxItem::new(ui_core::Id::str("three"), "Three"),
        ]
    }

    #[test]
    fn the_field_is_the_reference_32_dp_with_its_chevron_14_from_the_right_edge() {
        // `ComboBoxMinHeight` 32 and the glyph's `Margin 0,0,14,0` at 12 square: the column
        // is `*` + 38, and the chevron sits in it without any hand-tuned offset.
        // `ComboBoxMinHeight` 32，字形 12 见方、`Margin 0,0,14,0`：列是 `*` + 38，
        // 箭头靠列自身的对齐落位，没有手工微调。
        let id = ui_core::Id::str("combo");
        let items = combo_items();
        let tree = combo_tree(ComboBoxParams::new(id, &items).selected(Some(0)).width(240.0));
        let field = box_of(&tree, id.with("box"));
        assert_eq!(field.size.w, 240.0);
        assert!((field.size.h - 32.0).abs() < 0.5, "field height {}", field.size.h);
        let glyph = box_of(&tree, id.with("chevron-glyph"));
        assert_eq!(field.max_x() - glyph.max_x(), CHEVRON_MARGIN);
        assert!((glyph.size.w - CHEVRON_SIZE).abs() < 0.5);
        assert!(
            (glyph.origin.y + glyph.size.h * 0.5 - (field.origin.y + field.size.h * 0.5)).abs()
                < 0.01,
            "the chevron is centred in the field"
        );
        let value = box_of(&tree, id.with("value"));
        let p = pack();
        let m = p
            .controls
            .get(ui_style::ControlKind::ComboBox, ui_style::Density::Standard);
        assert_eq!(value.origin.x - field.origin.x, m.padding.left);
    }

    #[test]
    fn the_open_panel_matches_the_field_width_and_the_pill_keeps_the_labels_on_one_column() {
        // The popup takes the field's width (`match_anchor_width`) and each row spends its
        // 11 dp lead-in on the pill, so a selected label lines up with an unselected one.
        // 面板跟随选择框宽度（`match_anchor_width`），每行把 11dp 前导花在药丸上，
        // 选中的标签因此与未选中的对齐。
        let id = ui_core::Id::str("combo");
        let items = combo_items();
        let tree = combo_tree(
            ComboBoxParams::new(id, &items)
                .selected(Some(1))
                .open(true)
                .width(240.0),
        );
        let field = box_of(&tree, id.with("box"));
        let panel = box_of(&tree, id.with("dropdown"));
        assert_eq!(panel.size.w, field.size.w, "the panel follows the field");
        assert!((panel.origin.y - field.max_y()).abs() <= 0.5, "hung under the field");
        let mut rows = Vec::new();
        for item in &items {
            let row = box_of(&tree, item.id);
            assert!(
                (row.size.h - 32.0).abs() < 1.0,
                "row height {}",
                row.size.h
            );
            let label = box_of(&tree, item.id.with("label"));
            assert_eq!(
                label.origin.x - row.origin.x,
                COMBO_ITEM_PAD.left,
                "every label starts at the same x"
            );
            rows.push(row);
        }
        assert_eq!(rows[0].origin.x, panel.origin.x + COMBO_ITEM_MARGIN.left);
        let pill = box_of(&tree, items[1].id.with("pill-bar"));
        assert_eq!(pill.size.w, PILL_W);
        assert_eq!(pill.size.h, PILL_H);
        assert_eq!(pill.origin.x, rows[1].origin.x, "the pill starts at the row's edge");
        assert!(
            (pill.origin.y + pill.size.h * 0.5 - (rows[1].origin.y + rows[1].size.h * 0.5)).abs()
                < 0.01,
            "the pill is centred in its row"
        );
    }

    #[test]
    fn the_arrow_walk_skips_disabled_rows_and_wraps_both_ways() {
        // `ComboBox` moves the selection with Up/Down and wraps at either end; a disabled
        // row is stepped over rather than selected.
        // `ComboBox` 用上下键移动选择并在两端回绕；禁用的行会被跳过，而不是被选中。
        let items = [
            ComboBoxItem::new(ui_core::Id::str("a"), "A"),
            ComboBoxItem::new(ui_core::Id::str("b"), "B").disabled(),
            ComboBoxItem::new(ui_core::Id::str("c"), "C"),
        ];
        assert_eq!(neighbour(&items, None, true), Some(0), "nothing selected goes to the first");
        assert_eq!(neighbour(&items, Some(0), true), Some(2), "b is disabled");
        assert_eq!(neighbour(&items, Some(2), true), Some(0), "forward wraps");
        assert_eq!(neighbour(&items, Some(0), false), Some(2), "backward wraps");
        let all_off = [ComboBoxItem::new(ui_core::Id::str("x"), "X").disabled()];
        assert_eq!(neighbour(&all_off, None, true), None, "nothing to step onto");
    }

    /// A shell that opens a menu under its anchor, with the flags the test drives.
    /// 在锚点下打开菜单的外壳，打开标志与锚点上方的留白由测试驱动。
    struct OpeningMenu {
        open: bool,
        /// Room above the anchor, which pushes the menu toward the bottom edge.
        /// 锚点上方的留白，用来把菜单推到窗口底缘。
        pad: f32,
    }

    impl ui_platform::App for OpeningMenu {
        fn view(&mut self, cx: &mut ui_core::cx::Cx<'_>) -> Box<dyn ui_platform::Element> {
            let items = [
                MenuFlyoutEntry::Item(MenuFlyoutItem::new(ui_core::Id::str("one"), "One")),
                MenuFlyoutEntry::Item(MenuFlyoutItem::new(ui_core::Id::str("two"), "Two")),
            ];
            let params = MenuFlyoutParams::new(
                ui_core::Id::str("menu"),
                ui_core::layout::Anchor::Node(ui_core::Id::str("anchor")),
                &items,
            )
            .open(self.open);
            let menu = {
                let mut wx = ui_widgets::Cx::new(cx, ui_style::Env::root());
                let menu = FluentMenuFlyout::new(params, &mut wx, &pack());
                wx.element(Box::new(menu))
            };
            let root = ui_platform::Container::new(
                ui_core::Id::str("root"),
                ui_core::NodeKind::Column,
            )
            .size(ui_core::layout::SizeClass::fixed(240.0, 240.0))
            .child(ui_platform::from_decl(
                ui_core::Decl::container(ui_core::Id::str("pad"), ui_core::NodeKind::Box)
                    .size(ui_core::layout::SizeClass::fixed(240.0, self.pad)),
            ))
            .child(ui_platform::from_decl(
                ui_core::Decl::container(ui_core::Id::str("anchor"), ui_core::NodeKind::Box)
                    .size(ui_core::layout::SizeClass::fixed(120.0, 32.0)),
            ))
            .child(menu);
            Box::new(root)
        }
    }

    /// A node's drawn rect and the rect it is clipped to.
    /// 节点的绘制矩形，以及裁住它的矩形。
    fn node_rects(
        app: &ui_platform::AppLoop<OpeningMenu>,
        id: ui_core::Id,
    ) -> (ui_core::geom::Rect, ui_core::geom::Rect) {
        let tree = app.tree();
        let node = tree.get(tree.find_by_id(id).expect("node")).expect("data");
        (node.visual_rect(), node.mask)
    }

    #[test]
    fn an_opening_menu_travels_inside_a_window_that_never_moves() {
        // `MenuPopupThemeTransition` moves the whole surface half its height toward the
        // trigger while the popup window stays put and clips it.
        // `MenuPopupThemeTransition` 把整块表面朝锚点移动半个自身高度，浮出窗口不动并裁住它。
        let mut target = ui_platform::present::OffscreenTarget::new(240, 240);
        let mut app = ui_platform::AppLoop::new(OpeningMenu {
            open: false,
            pad: 0.0,
        });
        app.frame_with_dt(&mut target, None, 0.0);
        app.app_mut().open = true;
        app.frame_with_dt(&mut target, None, 0.0);
        let window = ui_core::Id::str("menu");
        let panel_id = window.with("panel");
        let (panel, mask) = node_rects(&app, panel_id);
        let (home, _) = node_rects(&app, window);
        assert!(
            (home.origin.y - panel.origin.y - home.size.h * POPUP_TRAVEL / 100.0).abs() < 0.5,
            "the surface starts half its height toward the trigger: {:?} in {:?}",
            panel.origin,
            home.origin
        );
        assert_eq!(mask, home, "the window, not the travelling panel, is the clip");
        app.frame_with_dt(&mut target, None, 0.30);
        let (settled, mask) = node_rects(&app, panel_id);
        assert_eq!(settled.origin.y, home.origin.y, "it comes to rest on its window");
        assert_eq!(mask, home, "and the clip never followed it");
    }

    #[test]
    fn a_menu_flipped_above_its_anchor_unfolds_from_the_bottom() {
        // Near the bottom edge the menu sits above the trigger, so the travel points down:
        // the surface's bottom shows first and the rest unfolds upward out of it.
        // 靠近底缘时菜单位于锚点之上，行程因而朝下：先露出表面底部，其余部分再向上展开。
        let mut target = ui_platform::present::OffscreenTarget::new(240, 240);
        let mut app = ui_platform::AppLoop::new(OpeningMenu {
            open: false,
            pad: 200.0,
        });
        app.frame_with_dt(&mut target, None, 0.0);
        app.app_mut().open = true;
        app.frame_with_dt(&mut target, None, 0.0);
        // The flip is only known once the window has been laid out, and the surface is still
        // fully transparent on that first frame, so the direction is read from the next one.
        // 翻边只有窗口布局过才知道，而首帧表面仍是全透明，因此方向从下一帧读。
        app.frame_with_dt(&mut target, None, 0.0);
        let window = ui_core::Id::str("menu");
        let panel_id = window.with("panel");
        let (panel, mask) = node_rects(&app, panel_id);
        let (home, _) = node_rects(&app, window);
        let (anchor, _) = node_rects(&app, ui_core::Id::str("anchor"));
        assert!(
            home.origin.y + home.size.h <= anchor.origin.y,
            "the menu is placed above its trigger: {:?} over {:?}",
            home,
            anchor
        );
        assert!(
            (panel.origin.y - home.origin.y - home.size.h * POPUP_TRAVEL / 100.0).abs() < 0.5,
            "the surface starts half its height below its window: {:?} in {:?}",
            panel.origin,
            home.origin
        );
        assert_eq!(mask, home, "the window, not the travelling panel, is the clip");
        app.frame_with_dt(&mut target, None, 0.30);
        let (settled, _) = node_rects(&app, panel_id);
        assert_eq!(settled.origin.y, home.origin.y, "it comes to rest on its window");
    }

    #[test]
    fn a_closing_menu_stays_on_stage_until_its_fade_is_spent() {
        // The fade-out is a state of the widget, not of the app: the app has already said
        // "closed", and the surface must still be there for the frames that spend it.
        // 淡出是控件自己的状态而非应用的：应用已经说「关」，表面仍须在耗完它的那些帧里存在。
        let mut target = ui_platform::present::OffscreenTarget::new(240, 240);
        let mut app = ui_platform::AppLoop::new(OpeningMenu {
            open: true,
            pad: 0.0,
        });
        app.frame_with_dt(&mut target, None, 0.0);
        app.frame_with_dt(&mut target, None, 0.30);
        // The window stays as a 0x0 placeholder once closed; the surface is the panel.
        // 关闭后窗口留作 0x0 占位；表面是面板。
        let menu = ui_core::Id::str("menu").with("panel");
        assert!(app.tree().find_by_id(menu).is_some(), "open and settled");
        app.app_mut().open = false;
        let out = app.frame_with_dt(&mut target, None, 0.05);
        assert!(out.animating, "the fade keeps the loop awake");
        assert!(app.tree().find_by_id(menu).is_some(), "still on stage");
        app.frame_with_dt(&mut target, None, 0.30);
        assert!(
            app.tree().find_by_id(menu).is_none(),
            "once the fade is spent the surface is gone"
        );
    }

