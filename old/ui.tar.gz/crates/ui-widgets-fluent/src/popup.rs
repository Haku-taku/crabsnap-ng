//! The WinUI popup entrance: the surface fades while travelling toward its trigger, clipped
//! to its own footprint, so it unfolds from that edge.
//! WinUI 浮出开场：表面淡入的同时朝锚点方向平移，并被裁在自身轮廓内，因而从那一侧展开。

use ui_core::anim::{AnimSpec, Easing};
use ui_core::layout::{Anchor, Len, LenInsets, Side};
use ui_core::{Decl, Id, NodeKind};
use ui_widgets::build::IMMEDIATE;
use ui_widgets::Cx;

/// WinUI's `ControlFastAnimationDuration` to open, `ControlFasterAnimationDuration` to close.
/// 开场取 WinUI 的 `ControlFastAnimationDuration`，收起取 `ControlFasterAnimationDuration`。
pub const POPUP_OPEN: AnimSpec = AnimSpec::new(0.167, Easing::Cubic(0.0, 0.0, 0.0, 1.0));
pub const POPUP_CLOSE: AnimSpec = AnimSpec::new(0.083, Easing::Cubic(0.0, 0.0, 0.0, 1.0));
/// The surface starts half its own height toward the trigger, then travels back to rest.
/// 表面起始于朝锚点方向半个自身高度处，再走回原位。
pub const POPUP_TRAVEL: f32 = 50.0;

/// This frame's entrance: how present the popup is, and whether it is still on stage.
/// 本帧的开场：浮出的在场程度，以及它是否仍在台上。
#[derive(Clone, Copy, Debug)]
pub struct PopupMotion {
    /// Group opacity, `0..=1`.
    /// 整组透明度，`0..=1`。
    pub presence: f32,
    /// Whether the node must be built: opening, or still fading out.
    /// 是否必须构建本节点：正在打开，或仍在淡出。
    pub alive: bool,
    /// Signed travel in percent of the panel's own height, toward the trigger.
    /// 以面板自身高度百分比表示的带符号行程，朝向锚点为正向。
    pub travel: f32,
}

impl PopupMotion {
    /// Put the surface inside its window: shift it toward the trigger and fade the group.
    /// 把表面放进它的窗口：朝锚点平移，并淡化整组。
    ///
    /// The travel is a percentage of the containing block, which is the window the panel
    /// hugs, so the height it needs is the one layout is about to give it.
    /// 行程是包含块高度的百分比，而包含块正是面板紧贴的窗口，所需的高度就是布局即将给它的。
    pub fn apply(&self, panel: Decl) -> Decl {
        panel
            .relative()
            .inset(LenInsets::new(
                Len::Auto,
                Len::Pct(self.travel),
                Len::Auto,
                Len::Auto,
            ))
            .opacity(self.presence)
    }
}

/// The window an animated surface sits in: an overlay is masked to its own box, so this
/// final rect is what clips — and reveals — the panel travelling inside it.
/// 会动的表面所在的窗口：浮层被遮罩在自己的盒子上，因此这个最终矩形就是裁住
/// 也即揭示里面平移面板的那一刀。
pub fn popup_window(id: Id) -> Decl {
    Decl::container(id, NodeKind::Box)
}

/// Drive the entrance of the panel sitting in `window`; ask once per frame, before building it.
/// 推进坐在 `window` 里的面板的开场；每帧构建它之前询问一次。
pub fn popup_motion(
    cx: &mut Cx<'_, '_>,
    window: Id,
    anchor: Anchor,
    side: Side,
    open: bool,
) -> PopupMotion {
    let key = window.with("presence");
    // A value with no history lands on its target, so a first opening seeds zero first.
    // 没有历史的值会直接落在终点，因此第一次打开之前先写入零。
    if cx.at(key).status(key).is_none() {
        cx.at(key).animate(key, 0.0, IMMEDIATE);
    }
    let spec = match open {
        true => POPUP_OPEN,
        false => POPUP_CLOSE,
    };
    let presence = cx.at(key).animate(key, f32::from(open), spec);
    // The engine flips a panel that would leave the viewport, so the drawn side wins over
    // the declared one; the window's rect is the one that stays put while the panel moves.
    // 引擎会把越出视口的面板翻到对侧，因此以画出来的那一侧为准；面板移动时不动的是窗口的矩形。
    let drawn = cx.rect_of(window).filter(|r| r.size.h > 0.0);
    let upward = match (drawn, anchor) {
        (Some(window), Anchor::Node(node)) => cx
            .rect_of(node)
            .is_some_and(|anchor| window.center().y < anchor.center().y),
        (Some(window), Anchor::Point(point)) => window.center().y < point.y,
        _ => side == Side::Above,
    };
    let travel = POPUP_TRAVEL * (1.0 - presence) * if upward { 1.0 } else { -1.0 };
    PopupMotion {
        presence,
        alive: open || presence > 0.0,
        travel,
    }
}
