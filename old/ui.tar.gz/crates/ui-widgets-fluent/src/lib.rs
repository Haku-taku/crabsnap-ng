//! Fluent (WinUI 3) controls, reproduced from the reference's own tokens.
//! Fluent（WinUI 3）控件，按参考实现自己的令牌复刻。
//!
//! One file per control; sizes, paint helpers and the label shape live beside them.
//! 每个控件一个文件；尺寸、绘制辅助与标签形状放在旁边。

pub mod material;
pub mod pack;
pub use pack::{pack, pack_of};

mod button;
mod checkbox;
mod combo;
mod dialog;
mod infobar;
mod menu_flyout;
mod navigation;
pub mod fluent_codepoints;
pub mod glyphs;
mod paint;
mod popup;
mod progress;
mod progress_ring;
mod radio;
mod scaffold;
pub mod spec;
mod slider;
mod style;
mod text;
mod tab_view;
mod textbox;
mod toggle;
mod tooltip;

pub use button::{ButtonParams, ButtonVariant, FluentButton};
pub use checkbox::{CheckBoxParams, CheckState, FluentCheckBox};
pub use combo::*;
pub use dialog::*;
pub use infobar::*;
pub use menu_flyout::*;
pub use navigation::*;
pub use popup::*;
pub use progress::*;
pub use progress_ring::*;
pub use radio::{FluentRadio, RadioParams};
pub use scaffold::*;
pub use slider::*;
pub use style::*;
pub use tab_view::*;
pub use textbox::*;
pub use toggle::*;
pub use tooltip::*;

#[cfg(test)]
mod tests;
