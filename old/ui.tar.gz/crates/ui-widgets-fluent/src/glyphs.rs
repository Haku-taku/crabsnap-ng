//! The icon face WinUI draws its own glyphs from, and the names these controls ask for.
//! WinUI 自绘字形所用的图标字面，以及这些控件索取的名字。

use ui_core::Family;
use ui_widgets::IconSource;

use crate::fluent_codepoints as table;

/// The family the host registers `FluentSystemIcons-Regular.ttf` under.
/// 宿主把 `FluentSystemIcons-Regular.ttf` 注册到的族名。
pub const ICON_FAMILY: &str = "Fluent System Icons";

/// The codepoint for a glyph name; `None` when the vendored font does not carry it.
/// 字形名对应的码点；自带的字体没有该字形时为 `None`。
pub fn codepoint(name: &str) -> Option<char> {
    table::FLUENT_ICONS
        .binary_search_by(|(n, _)| (*n).cmp(name))
        .ok()
        .map(|i| table::FLUENT_ICONS[i].1)
}

/// An icon in the Fluent face; `None` rather than a blank box when the name is unknown.
/// Fluent 字面里的一个图标；名字未知时返回 `None`，而不是一个空白方块。
pub fn icon(name: &str) -> Option<IconSource> {
    Some(IconSource::from_parts(
        Family::Named(ICON_FAMILY),
        codepoint(name)?,
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn the_table_is_sorted_so_the_lookup_can_bisect() {
        // `codepoint` binary-searches; an unsorted table would miss real glyphs silently.
        // `codepoint` 用二分查找；表未排序会静默漏掉真实存在的字形。
        assert!(table::FLUENT_ICONS.windows(2).all(|w| w[0].0 < w[1].0));
    }

    #[test]
    fn a_glyph_the_checkbox_asks_for_resolves_and_an_invented_name_does_not() {
        assert!(codepoint("checkmark_12_regular").is_some());
        assert!(codepoint("checkmark_999_regular").is_none());
    }
}
