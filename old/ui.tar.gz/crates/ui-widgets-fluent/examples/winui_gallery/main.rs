//! The WinUI 3 Gallery, rebuilt on this engine's Fluent controls.
//! 用本引擎的 Fluent 控件重建的 WinUI 3 Gallery。
//!
//! Navigation, page titles and sample captions follow Microsoft's own gallery; the samples
//! are the controls this crate actually draws.
//! 导航、页面标题与样本说明沿用微软自己的 Gallery；样本是本 crate 真正画得出的那些控件。

mod app;
mod pages;

use app::WinUiGallery;
use ui_demo::Demo;

/// Faces in the order a glyph is looked up: Latin first, then the Chinese face behind it.
/// 字形查找顺序：先拉丁，再其后的中文面。
const STACK: &[&str] = &[
    "SF Pro Text",
    "SF Pro Display",
    "Inter",
    "PingFang SC",
    "Noto Sans SC",
    "Noto Sans CJK SC",
    "MiSans VF",
    "HarmonyOS Sans SC",
];

fn main() {
    Demo::new(
        "crabsnap-ui   WinUI Gallery",
        "dev.crabsnap.ui.winui_gallery",
        1440,
        960,
    )
    .stack(STACK)
    .font("Inter", ui_demo::INTER)
    .font(ui_widgets_fluent::glyphs::ICON_FAMILY, ui_demo::FLUENT_ICONS)
    .run(WinUiGallery::new());
}
