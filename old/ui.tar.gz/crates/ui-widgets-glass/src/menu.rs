//! The glass menu: a frosted panel of rows hung from its anchor.
//! 玻璃菜单：一块磨砂面板，若干行文字，从锚点挂出。

use ui_core::geom::{Color, Corners, Insets};
use ui_core::layout::{Anchor, AxisSize, Grow, OverlayAlign, Side, SizeClass};
use ui_core::shortcut::ShortcutId;
use ui_core::{CursorShape, Decl, Id, NodeKind, Sense, Weight};
use ui_style::{Style, TextRole};
use ui_widgets::{Cx, IconSource, Widget};

use crate::material::Control;
use crate::overlay::{panel_dismissed, Panel, PanelParams};
use crate::paint::*;
use crate::shared::focus_ring;
use crate::text::LabelText;
use crate::HigOptions;

/// One row of a glass menu, or a divider between rows.
/// 玻璃菜单的一行，或行与行之间的分隔线。
#[derive(Clone, Debug)]
pub struct GlassMenuEntry<'a> {
    pub id: Id,
    pub label: &'a str,
    pub icon: Option<IconSource>,
    pub disabled: bool,
    pub destructive: bool,
    /// A divider instead of a row; `label` is then ignored.
    /// 分隔线而非行；此时 `label` 被忽略。
    pub divider: bool,
}

impl<'a> GlassMenuEntry<'a> {
    pub fn item(id: Id, label: &'a str) -> Self {
        Self {
            id,
            label,
            icon: None,
            disabled: false,
            destructive: false,
            divider: false,
        }
    }

    pub fn divider(id: Id) -> Self {
        Self {
            id,
            label: "",
            icon: None,
            disabled: false,
            destructive: false,
            divider: true,
        }
    }

    pub fn icon(mut self, icon: IconSource) -> Self {
        self.icon = Some(icon);
        self
    }

    pub fn disabled(mut self) -> Self {
        self.disabled = true;
        self
    }

    pub fn destructive(mut self) -> Self {
        self.destructive = true;
        self
    }
}

/// Everything a menu is built with, named after the reference's properties.
/// 构建菜单所需的一切，按参考实现的属性命名。
pub struct GlassMenuParams<'a> {
    pub id: Id,
    /// The node the panel unfolds from.
    /// 面板展开所依附的节点。
    pub anchor: Anchor,
    pub side: Side,
    pub entries: &'a [GlassMenuEntry<'a>],
    /// `IsOpen`; a closed menu paints nothing and takes no keyboard.
    /// `IsOpen`；关闭的菜单不画任何东西，也不占键盘。
    pub open: bool,
}

impl<'a> GlassMenuParams<'a> {
    pub fn new(id: Id, anchor: Anchor, entries: &'a [GlassMenuEntry<'a>]) -> Self {
        Self {
            id,
            anchor,
            side: Side::Below,
            entries,
            open: true,
        }
    }

    pub fn side(mut self, side: Side) -> Self {
        self.side = side;
        self
    }

    pub fn open(mut self, open: bool) -> Self {
        self.open = open;
        self
    }
}

/// A resolved row: the facts `decl` needs, with the pack and this frame's state read.
/// 一个解析后的行：`decl` 需要的事实，包与本帧状态已读取。
struct Row {
    id: Id,
    label: Option<LabelText>,
    icon: Option<IconSource>,
    ink: Color,
    /// The hover/press fill for this frame.
    /// 本帧的悬停/按下填充。
    fill: Color,
    disabled: bool,
    divider: bool,
}

/// A glass menu, resolved against the pack in force where it was built.
/// 玻璃菜单，按构建时生效的包解析。
pub struct GlassMenu {
    panel: Panel,
    rows: Vec<Row>,
    /// The row activated this frame, if any.
    /// 本帧被激活的行（若有）。
    fired: Option<Id>,
    divider: Color,
    /// The ring a row paints while the keyboard is on it; also what makes it a Tab stop.
    /// 键盘落在行上时它画的环；也是这一行成为 Tab 停靠点的依据。
    focus: ui_core::draw::FocusVisual,
}

impl GlassMenu {
    /// Takes the build `Cx`, not a `NodeCx`: every row reports from its own node, so the
    /// menu reads its children's state as well as advancing its own springs.
    /// 取构建用的 `Cx` 而非 `NodeCx`：每行从自己的节点上报，菜单既要读子节点的状态，
    /// 也要推进自己的弹簧。
    pub fn new(params: GlassMenuParams<'_>, cx: &mut Cx<'_, '_>, pack: &Style) -> Self {
        Self::new_with(HigOptions::default(), params, cx, pack)
    }

    pub fn new_with(
        _params: HigOptions,
        params: GlassMenuParams<'_>,
        cx: &mut Cx<'_, '_>,
        pack: &Style,
    ) -> Self {
        let GlassMenuParams {
            id,
            anchor,
            side,
            entries,
            open,
        } = params;
        let ink = role_of(pack, "textFillColorPrimary");
        let destructive = role_of(pack, "systemRed");
        let hover = Color { a: 0.10, ..Color::WHITE };
        let press = Color { a: 0.15, ..Color::WHITE };
        let rows: Vec<Row> = entries
            .iter()
            .map(|entry| {
                let st = cx.state(entry.id);
                let row_ink = if entry.destructive { destructive } else { ink };
                Row {
                    id: entry.id,
                    label: (!entry.divider)
                        .then(|| {
                            let text_ink = if entry.destructive {
                                row_ink
                            } else {
                                // A row's title sits at 90 % of the label ink (`:257-262`).
                                // 行的标题用标签墨色的 90%（`:257-262`）。
                                Color { a: row_ink.a * 0.9, ..row_ink }
                            };
                            LabelText::new(pack, TextRole::Body, entry.label, text_ink, f32::INFINITY)
                                .map(|l| l.restyled(MENU_FONT, Weight::REGULAR))
                        })
                        .flatten(),
                    icon: entry.icon,
                    ink: row_ink,
                    fill: menu_row_fill(st.hovered, st.pressed, hover, press),
                    disabled: entry.disabled,
                    divider: entry.divider,
                }
            })
            .collect();
        // The row that was activated reports from its own node.
        // 被激活的行从它自己的节点上报。
        let fired = rows
            .iter()
            .find(|row| {
                let st = cx.state(row.id);
                !row.divider && !row.disabled && st.activation()
            })
            .map(|row| row.id);

        let panel = Panel::new(
            PanelParams {
                id,
                anchor,
                side,
                open,
                width: MENU_W,
                height: None,
                radius: MENU_RADIUS,
                padding: MENU_PAD,
                gap: MENU_ROW_GAP,
                control: Control::Menu,
                dismiss: MENU_DISMISS_SHORTCUT,
            },
            cx,
            pack,
        );
        Self {
            panel,
            rows,
            fired,
            divider: Color { a: 0.12, ..ink },
            focus: focus_ring(pack),
        }
    }
}

impl Widget for GlassMenu {
    fn handles_disabled(&self) -> bool {
        true
    }

    fn change(
        &self,
        state: &ui_widgets::WidgetState,
        _bounds: ui_core::geom::Rect,
    ) -> Option<ui_core::Change> {
        if let Some(id) = self.fired {
            return Some(ui_core::Change::Selected(Some(id)));
        }
        // Escape is bound on the panel, so it reaches here only while the menu holds keys.
        // Escape 绑定在面板上，因此只有菜单持有键盘时才会到这里。
        panel_dismissed(state, MENU_DISMISS_SHORTCUT).then_some(ui_core::Change::Dismissed)
    }

    fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
        self.panel
            .decl(self.rows.iter().map(|row| self.row_decl(row)).collect())
    }
}

impl GlassMenu {
    /// One row: a 44 dp capsule with an optional icon, or the divider band.
    /// 一行：44dp 胶囊，可选图标；或那条分隔带。
    fn row_decl(&self, row: &Row) -> Decl {
        if row.divider {
            // `GlassMenuDivider`: a 12 dp band with a hairline down its middle.
            // `GlassMenuDivider`：12dp 的带，中间一道发丝线。
            let line_w = MENU_W - MENU_PAD.left - MENU_PAD.right - MENU_ROW_PAD_X * 2.0;
            return Decl::container(row.id, NodeKind::Stack)
                .size(SizeClass {
                    width: AxisSize::fill(0.0, 0.0),
                    height: AxisSize::fixed(MENU_DIVIDER_H),
                    grow_x: Grow::No,
                    grow_y: Grow::No,
                })
                .stack_align(OverlayAlign::Center)
                .child(
                    Decl::container(row.id.with("line"), NodeKind::Box)
                        .size(SizeClass::fixed(line_w, 0.5))
                        .background(self.divider, Corners::ZERO),
                );
        }
        // A row is a plain row: the title fills what the icon leaves, so it starts at the
        // leading edge as the reference's `Expanded` does.
        // 行就是一行：标题占满图标之外的宽度，因此贴着前缘，与参考实现的 `Expanded` 一致。
        let mut node = Decl::container(row.id, NodeKind::Row)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::hug(MENU_ROW_H, 0.0),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets {
                left: MENU_ROW_PAD_X,
                top: MENU_ROW_PAD_Y,
                right: MENU_ROW_PAD_X,
                bottom: MENU_ROW_PAD_Y,
            })
            .corners(Corners::all(MENU_ITEM_RADIUS))
            .background(row.fill, Corners::all(MENU_ITEM_RADIUS))
            .gap(MENU_ICON_GAP)
            .cross_align(0.0)
            .cross_pos(0.5)
            .sense(Sense::HOVER | Sense::CLICK | Sense::FOCUSABLE)
            .focus_visual(Some(self.focus))
            .cursor(CursorShape::PointingHand);
        if let Some(icon) = row.icon {
            node = node.child(
                ui_widgets::Icon {
                    id: row.id.with("icon"),
                    source: icon,
                    size: MENU_ICON,
                    ink: row.ink,
                }
                .resolve(),
            );
        }
        if let Some(label) = &row.label {
            let mut label = label.decl(row.id.with("label"));
            label.size_class.grow_x = Grow::Yes;
            node = node.child(label);
        }
        if row.disabled {
            node = node.opacity(0.4);
        }
        node
    }
}

/// A row's fill for this frame: press over hover, none at rest (`:276-284`).
/// 本帧行上的填充：按下压过悬停，静止无填充（`:276-284`）。
pub fn menu_row_fill(hovered: bool, pressed: bool, hover: Color, press: Color) -> Color {
    if pressed {
        press
    } else if hovered {
        hover
    } else {
        Color::TRANSPARENT
    }
}

/// The panel's width, `GlassMenu.menuWidth`.
/// 面板宽度，即 `GlassMenu.menuWidth`。
pub const MENU_W: f32 = 200.0;
/// `menuBorderRadius` and `itemBorderRadius`.
/// `menuBorderRadius` 与 `itemBorderRadius`。
pub const MENU_RADIUS: f32 = 32.0;
pub const MENU_ITEM_RADIUS: f32 = 24.0;
/// `_kBodyVerticalPadding` and the horizontal inset the rows sit in.
/// `_kBodyVerticalPadding` 与行所在的左右内缩。
pub const MENU_PAD: Insets = Insets {
    left: 12.0,
    top: 12.0,
    right: 12.0,
    bottom: 12.0,
};
pub const MENU_ROW_GAP: f32 = 2.0;
/// `GlassMenuItem.height`, its padding, icon size and the gap after the icon.
/// `GlassMenuItem.height`、它的内衬、图标尺寸与图标后的间距。
pub const MENU_ROW_H: f32 = 44.0;
pub const MENU_ROW_PAD_X: f32 = 16.0;
pub const MENU_ROW_PAD_Y: f32 = 8.0;
pub const MENU_ICON: f32 = 20.0;
pub const MENU_ICON_GAP: f32 = 12.0;
/// A row's title is 17 pt at w400.
/// 行的标题是 17pt、w400。
pub const MENU_FONT: f32 = 17.0;
/// `GlassMenuDivider.height`.
/// `GlassMenuDivider.height`。
pub const MENU_DIVIDER_H: f32 = 12.0;

/// The id the panel binds Escape to.
/// 面板把 Escape 绑到的 id。
pub const MENU_DISMISS_SHORTCUT: ShortcutId = ShortcutId("glass.menu.dismiss");
