//! The glass segmented control: equal cells in a translucent track under a glass lens.
//! 玻璃分段控件：半透明轨道里等分的格子，其上一枚玻璃透镜。

use ui_core::geom::{Color, Corners, Insets};
use ui_core::layout::{AxisSize, Grow, OverlayAlign, SizeClass};
use ui_core::{AnimSpec, CursorShape, Decl, Easing, Id, NodeKind, Sense, Weight};
use ui_style::Style;
use ui_widgets::{IconSource, Widget};

use crate::paint::*;
use crate::shared::*;
use crate::text::LabelText;
use crate::HigOptions;

/// One segment: the id it reports, and a label, an icon, or both.
/// 一个分段：它上报的 id，以及文字、图标或两者。
#[derive(Clone, Debug)]
pub struct GlassSegment {
    pub id: Id,
    pub label: Option<String>,
    pub icon: Option<IconSource>,
    pub enabled: bool,
}

impl GlassSegment {
    pub fn label(id: Id, label: impl Into<String>) -> Self {
        Self {
            id,
            label: Some(label.into()),
            icon: None,
            enabled: true,
        }
    }

    pub fn icon(id: Id, icon: IconSource) -> Self {
        Self {
            id,
            label: None,
            icon: Some(icon),
            enabled: true,
        }
    }

    pub fn with_label(mut self, label: impl Into<String>) -> Self {
        self.label = Some(label.into());
        self
    }

    pub fn disabled(mut self) -> Self {
        self.enabled = false;
        self
    }
}

/// One segmented control; every spring advances in `new`, `decl()` is pure.
/// 一个分段控件；所有弹簧在 `new` 里推进，`decl()` 是纯函数。
pub struct GlassSegmentedControl {
    id: Id,
    segments: Vec<GlassSegment>,
    labels: Vec<Option<LabelText>>,
    selected: usize,
    /// Width in dp; the reference reads it from constraints.
    /// 宽度（dp）；参考从布局约束里取。
    width: f32,
    align: f32,
    thickness: f32,
    jelly: (f32, f32),
    /// Per-segment selection crossfade, 0..=1.
    /// 每个分段的选中过渡，0..=1。
    sel: Vec<f32>,
    ink: Color,
    /// The selection's accent: a wash over the whole indicator.
    /// 选中态的强调色：覆盖整枚指示片的一层。
    accent: Color,
    track: Color,
    rest: Color,
    lens_backdrop: Option<ui_core::BackdropBlur>,
}

impl GlassSegmentedControl {
    pub fn new(
        id: Id,
        segments: Vec<GlassSegment>,
        selected: usize,
        width: f32,
        cx: &mut ui_widgets::NodeCx<'_>,
        pack: &Style,
    ) -> Self {
        Self::new_with(HigOptions::default(), id, segments, selected, width, cx, pack)
    }

    pub fn new_with(
        _params: HigOptions,
        id: Id,
        segments: Vec<GlassSegment>,
        selected: usize,
        width: f32,
        cx: &mut ui_widgets::NodeCx<'_>,
        pack: &Style,
    ) -> Self {
        let n = segments.len().max(1);
        let selected = selected.min(n - 1);
        let ink = role_of(pack, "textFillColorPrimary");
        let accent = role_of(pack, "glassSelectionAccent");
        let motion = lens_motion(id, selected, n, width, &cx.state(), cx, LENS_SPRINGS);

        // ── Labels: 13 pt, w500 at 60 % unselected and w600 full ink selected
        // (`segmented_control_internal.dart:281-291`), the change tweened over 200 ms.
        // ── 文字：13pt，未选中 w500、60% 墨色，选中 w600 全墨色
        // （`segmented_control_internal.dart:281-291`），切换用 200ms 过渡。
        let cell_w = (width - SEGMENT_INSET * 2.0) / n as f32;
        let labels: Vec<Option<LabelText>> = segments
            .iter()
            .map(|seg| {
                let text = seg.label.as_deref()?;
                LabelText::new(pack, ui_style::TextRole::Caption, text, ink, cell_w)
                    .map(|l| l.restyled(SEGMENT_FONT, Weight::MEDIUM))
            })
            .collect();
        let sel = segments
            .iter()
            .enumerate()
            .map(|(k, seg)| {
                cx.animate(
                    seg.id.with("selected"),
                    f32::from(k == selected),
                    SELECTION_TWEEN,
                )
            })
            .collect();

        Self {
            id,
            segments,
            labels,
            selected,
            width,
            align: motion.align,
            thickness: motion.thickness,
            jelly: motion.jelly,
            sel,
            ink,
            accent,
            track: role_of(pack, "glassSegmentTrack"),
            rest: role_of(pack, "glassSegmentRest"),
            lens_backdrop: glass_backdrop(
                &{
                    // The accent belongs to the resting pill: the lens carries it only while
                    // that pill is still there, and fades to clear as the glass blooms.
                    // 强调色属于静止指示片：透镜只在静止片还在时带着它，玻璃鼓起时淡到没有。
                    let mut glass = crate::material::glass_recipe(
                        pack,
                        crate::material::Control::SegmentLens,
                    );
                    glass.tint = Color {
                        a: SEGMENT_LENS_TINT * rest_fade(motion.thickness),
                        ..accent
                    };
                    glass
                },
                motion.thickness.clamp(0.0, 1.0),
            ),
        }
    }

}

impl Widget for GlassSegmentedControl {
    fn handles_disabled(&self) -> bool {
        // Per-segment fades are painted here; the adapter must not fade the whole strip.
        // 每个分段的淡出在此绘制；适配器不得淡化整条。
        true
    }

    fn change(
        &self,
        state: &ui_widgets::WidgetState,
        _bounds: ui_core::geom::Rect,
    ) -> Option<ui_core::Change> {
        if state.disabled {
            return None;
        }
        let n = self.segments.len().max(1);
        // Released: the drag lands on the segment it came to rest over.
        // 松手：拖拽落在它停下的那一格。
        let index = if state.dropped {
            let rel = (self.align + 1.0) * 0.5;
            (rel * (n - 1) as f32).round().clamp(0.0, (n - 1) as f32) as usize
        } else if state.dragging || state.pressed || state.clicked {
            // The reference commits on press-down, so the lens starts moving immediately.
            // 参考在按下时就提交，透镜因此立刻开始移动。
            let x = state.local.map_or(self.width * 0.5, |p| p.x);
            index_at_x(x, self.width, n)
        } else {
            return None;
        };
        let segment = self.segments.get(index)?;
        // A disabled segment never takes the selection, by tap or by drag.
        // 禁用的分段不接受选中，点击与拖拽都不行。
        if index == self.selected || !segment.enabled {
            return None;
        }
        Some(ui_core::Change::Selected(Some(segment.id)))
    }

    fn decl(&self, _cx: &ui_widgets::Cx<'_, '_>) -> Decl {
        let n = self.segments.len().max(1);
        let inner_w = self.width - SEGMENT_INSET * 2.0;
        let cell_w = inner_w / n as f32;
        let cell_h = SEGMENT_H - SEGMENT_INSET * 2.0;

        // ── The track: the reference's 8 % black in light, 12 % white in dark.
        // ── 轨道：参考的浅色 8% 黑、深色 12% 白。
        let track = Decl::container(self.id.with("track"), NodeKind::Box)
            .size(SizeClass::fixed(self.width, SEGMENT_H))
            .background(self.track, Corners::all(SEGMENT_H * 0.5));

        // ── The resting pill, faded out as the glass lens takes over.
        // ── 静止指示片，随玻璃透镜接管而淡出。
        let rest_a = rest_fade(self.thickness);
        let geo = lens_geometry(
            self.align,
            self.thickness,
            self.jelly,
            inner_w,
            cell_w,
            SEGMENT_INSET,
            SEGMENT_H,
            (SEGMENT_EXPAND_H, SEGMENT_EXPAND_V),
        );
        let rest = Decl::container(self.id.with("rest"), NodeKind::Box)
            .size(SizeClass::fixed(geo.rest.size.w, geo.rest.size.h))
            .offset(geo.rest.origin.x, geo.rest.origin.y)
            .background(
                Color { a: self.rest.a * rest_a, ..self.rest },
                Corners::all(geo.rest.size.h * 0.5),
            );
        // The whole indicator wears the accent, not its label: a wash over the resting pill,
        // fading with it as the glass lens takes over.
        // 整枚指示片穿强调色，而不是它的文字：一层盖在静止片上的洗色，随静止片一起淡出。
        let accent = Decl::container(self.id.with("rest-accent"), NodeKind::Box)
            .size(SizeClass::fixed(geo.rest.size.w, geo.rest.size.h))
            .offset(geo.rest.origin.x, geo.rest.origin.y)
            .background(
                Color { a: SEGMENT_ACCENT * rest_a, ..self.accent },
                Corners::all(geo.rest.size.h * 0.5),
            );

        // ── Cells: equal shares, each centring its content in a Stack.
        // ── 格子：等分，每格用 Stack 把内容居中。
        let mut cells = Decl::container(self.id.with("cells"), NodeKind::Row)
            .size(SizeClass::fixed(self.width, SEGMENT_H))
            .padding(Insets {
                left: SEGMENT_INSET,
                top: SEGMENT_INSET,
                right: SEGMENT_INSET,
                bottom: SEGMENT_INSET,
            });
        for (k, segment) in self.segments.iter().enumerate() {
            let mut content = Decl::container(segment.id.with("content"), NodeKind::Column)
                .gap(SEGMENT_ICON_GAP)
                .cross_align(0.0)
                .cross_pos(0.5);
            let ink = self.label_ink(k);
            if let Some(icon) = segment.icon {
                let size = if segment.label.is_some() {
                    SEGMENT_ICON_WITH_LABEL
                } else {
                    SEGMENT_ICON
                };
                content = content.child(
                    ui_widgets::Icon {
                        id: segment.id.with("icon"),
                        source: icon,
                        size,
                        ink,
                    }
                    .resolve(),
                );
            }
            if let Some(label) = self.labels.get(k).and_then(|l| l.as_ref()) {
                content = content.child(self.styled_label(label, k).decl(segment.id.with("label")));
            }
            // The cell carries the segment's own id: that is what a click reports and what
            // a caller measures.
            // 格子带分段自己的 id：点击上报的就是它，调用方量的也是它。
            let mut cell = Decl::container(segment.id, NodeKind::Stack)
                .size(SizeClass {
                    width: AxisSize::fill(0.0, 0.0),
                    height: AxisSize::fixed(cell_h),
                    grow_x: Grow::Split(1),
                    grow_y: Grow::No,
                })
                .stack_align(OverlayAlign::Center)
                .child(content);
            if !segment.enabled {
                cell = cell.opacity(SEGMENT_DISABLED);
            }
            cells = cells.child(cell);
        }

        // ── The lens: 12 dp per side and 8 dp up and down at full bloom.
        // ── 透镜：完全鼓起时每侧 12dp，上下各 8dp。
        let mut lens = Decl::container(self.id.with("lens"), NodeKind::Box)
            .size(SizeClass::fixed(geo.lens.size.w, geo.lens.size.h))
            .offset(geo.lens.origin.x, geo.lens.origin.y)
            .background(Color::TRANSPARENT, Corners::all(geo.lens.size.h * 0.5));
        if let Some(backdrop) = self.lens_backdrop
            && let Some(p) = lens.data.params_mut() {
                p.backdrop_blur = Some(backdrop);
            }

        let stack = Decl::container(self.id.with("stack"), NodeKind::Stack)
            .size(SizeClass::fixed(self.width, SEGMENT_H))
            .child(track)
            .child(rest)
            .child(accent)
            .child(cells)
            .child(lens);

        Decl::container(self.id, NodeKind::Box)
            .size(SizeClass::fixed(self.width, SEGMENT_H))
            .sense(Sense::HOVER | Sense::CLICK | Sense::DRAG | Sense::FOCUSABLE)
            .cursor(CursorShape::PointingHand)
            .child(stack)
    }
}

impl GlassSegmentedControl {
    /// The label ink at segment `k`: 60 % unselected fading to full selected.
    /// 第 `k` 段的文字墨色：未选中 60%，选中为全值，两者之间过渡。
    fn label_ink(&self, k: usize) -> Color {
        let sel = self.sel.get(k).copied().unwrap_or(0.0).clamp(0.0, 1.0);
        Color {
            a: self.ink.a * (0.6 + 0.4 * sel),
            ..self.ink
        }
    }

    /// The label at segment `k`, with the selected weight once the tween passes halfway.
    /// 第 `k` 段的文字，过渡过半后换成选中的字重。
    fn styled_label(&self, label: &LabelText, k: usize) -> LabelText {
        let sel = self.sel.get(k).copied().unwrap_or(0.0);
        let weight = if sel > 0.5 {
            Weight::SEMIBOLD
        } else {
            Weight::MEDIUM
        };
        label
            .restyled(SEGMENT_FONT, weight)
            .inked(self.label_ink(k))
    }
}

/// The control's height, the reference's `GlassDefaults.heightControl`.
/// 控件高度，即参考的 `GlassDefaults.heightControl`。
pub const SEGMENT_H: f32 = 32.0;
/// The track's padding, `EdgeInsets.all(2)`.
/// 轨道内衬，即 `EdgeInsets.all(2)`。
pub const SEGMENT_INSET: f32 = 2.0;
/// `indicatorExpansion`: the lens reaches 12 dp per side and 8 dp up and down at full bloom.
/// `indicatorExpansion`：完全鼓起时透镜每侧 12dp、上下各 8dp。
pub const SEGMENT_EXPAND_H: f32 = 12.0;
pub const SEGMENT_EXPAND_V: f32 = 8.0;
/// Both label styles are 13 pt; only the weight and the ink's alpha change.
/// 两种标签都是 13pt，只有字重与墨色不透明度不同。
pub const SEGMENT_FONT: f32 = 13.0;
/// `iconSize` 20 for an icon alone, 16 beside a label, 2 dp apart.
/// 纯图标用 `iconSize` 20，与文字并排时 16，间距 2dp。
pub const SEGMENT_ICON: f32 = 20.0;
pub const SEGMENT_ICON_WITH_LABEL: f32 = 16.0;
pub const SEGMENT_ICON_GAP: f32 = 2.0;
/// A disabled segment's content, the reference's `Opacity(0.38)`.
/// 禁用分段的内容，即参考的 `Opacity(0.38)`。
pub const SEGMENT_DISABLED: f32 = 0.38;
/// How strongly the accent washes the resting indicator, as a straight-alpha mix.
/// 强调色洗过静止指示片的强度（直通 alpha）。
pub const SEGMENT_ACCENT: f32 = 0.28;
/// The same wash on the glass lens, which carries it as the material's tint.
/// 同一层洗色落在玻璃透镜上，由材质的 tint 承担。
pub const SEGMENT_LENS_TINT: f32 = 0.22;

/// `AnimatedDefaultTextStyle(duration: 200ms)`: the label style tween.
/// `AnimatedDefaultTextStyle(duration: 200ms)`：标签样式的过渡。
const SELECTION_TWEEN: AnimSpec = AnimSpec::new(0.200, Easing::Linear);
