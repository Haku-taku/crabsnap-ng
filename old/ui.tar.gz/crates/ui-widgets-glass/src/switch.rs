//! The glass switch: a 63×28 track under a 37×24 white pill that melts into a 58×38.33 lens.
//! 玻璃开关：63×28 轨道，其上的 37×24 白色胶囊在按下时化开成 58×38.33 的透镜。

use ui_core::geom::{Color, Corners, Insets};
use ui_core::{AnimSpec, Decl, Easing, Id, NodeKind, SizeClass};
use ui_style::{Style, TextRole};
use ui_widgets::build::IMMEDIATE;
use ui_widgets::Widget;

use crate::paint::*;
use crate::shared::*;
use crate::text::LabelText;
use crate::HigOptions;

/// One glass switch; every curve advances in `new`, `decl()` is pure.
/// 一个玻璃开关；所有曲线在 `new` 里推进，`decl()` 是纯函数。
pub struct GlassSwitch {
    id: Id,
    /// The thumb's centre as progress 0..=1, rubber-banded past either end while dragging.
    /// 滑块中心的位置进度 0..=1，拖拽越过端点时按橡皮筋外延。
    pos: f32,
    /// How far the pill has melted into the lens, 0..=1 — a spring, so it overshoots.
    /// 胶囊化开成透镜的程度 0..=1——由弹簧驱动，因此会过冲。
    expand: f32,
    /// The track colour, cross-faded on its own 0.25 s clock.
    /// 轨道颜色，由它自己的 0.25s 时钟交叉淡入。
    track: Color,
    /// The thumb's box and the white pill it draws, which are the same capsule.
    /// 滑块的盒子与它绘制的白色胶囊，两者是同一个形状。
    thumb: SwitchThumb,
    /// The pill's colour before the melt fades it.
    /// 白色胶囊在化开淡出前的颜色。
    white: Color,
    backdrop: Option<ui_core::BackdropBlur>,
    /// Which end the drag has reached, if any: the reference toggles as the thumb hits it.
    /// 拖拽已到达的端点（若有）：参考在滑块触边时翻转。
    edge: Option<bool>,
    semantic_on: bool,
    label: Option<LabelText>,
}

impl GlassSwitch {
    pub fn new(id: Id, on: bool, label: &str, ctx: &mut ui_widgets::NodeCx<'_>, pack: &Style) -> Self {
        Self::new_with(HigOptions::default(), id, on, label, ctx, pack)
    }

    pub fn new_with(
        _params: HigOptions,
        id: Id,
        on: bool,
        label: &str,
        ctx: &mut ui_widgets::NodeCx<'_>,
        pack: &Style,
    ) -> Self {
        let semantic_on = on;
        let state = ctx.state();
        let value = u8::from(on) as f32;

        // ── Position: a drag carries the thumb by the finger's own travel, and the pull past
        // either end is square-rooted; a tap springs it to the value.
        // ── 位置：拖拽按手指自身的行程搬动滑块，越过端点的拉扯经开方压缩；点击则弹到值上。
        let pos_id = id.with("pos");
        let shown_id = id.with("shown");
        let last_x = id.with("last-x");
        if let Some(l) = state.local {
            ctx.animate(last_x, l.x, IMMEDIATE);
        }
        let pos = if state.pressed || state.drag_started {
            if ctx.value(id.with("bank")) <= 0.5 {
                ctx.animate(id.with("bank"), 1.0, IMMEDIATE);
                ctx.animate(id.with("from-pos"), ctx.value(shown_id), IMMEDIATE);
                ctx.animate(id.with("from-x"), ctx.value(last_x), IMMEDIATE);
            }
            let pulled = ctx.value(last_x) - ctx.value(id.with("from-x"));
            let progress = ctx.value(id.with("from-pos")) + pulled / travel();
            rubber_band_at(progress, travel())
        } else {
            ctx.animate(id.with("bank"), 0.0, IMMEDIATE);
            if state.dropped {
                // The release frame still shows where the finger left it, and the spring is
                // re-seeded there: its stored state is pre-drag, so letting it run from that
                // would snap the thumb back before it sprang. The app has not applied the
                // value yet, so the overshoot must survive one frame.
                // 松手帧仍显示手指离开的位置，弹簧也就地重新起步：它存的是拖拽前的状态，
                // 从那里跑会把滑块先瞬移回去再弹。应用尚未落值，因此过冲要多留一帧。
                let shown = ctx.value(shown_id);
                ctx.forget_spring(pos_id);
                ctx.spring(pos_id, shown, POSITION.0, POSITION.1).x
            } else {
                ctx.spring(pos_id, value, POSITION.0, POSITION.1).x
            }
        };
        // What the thumb showed this frame, so the release frame and the next drag start from it.
        // 本帧滑块显示的位置，松手帧与下一次拖拽都从它起算。
        ctx.animate(shown_id, pos, IMMEDIATE);

        // ── Expand: the pill grows into the lens on a 0.4 s spring, and back on a 0.6 s one.
        // ── 展开：胶囊以 0.4s 弹簧长成透镜，收束则用 0.6s 的那条。
        // The hold is an animation, not a timestamp: reading the clock every frame keeps the
        // loop awake for good, while a decaying animation lets it rest the moment it ends.
        // 保持是一条动画而不是时间戳：每帧读时钟会让帧循环永不歇下，
        // 衰减动画则在它结束时让循环立刻休息。
        let hold = id.with("tap-hold");
        if state.activation() {
            ctx.animate(hold, 1.0, IMMEDIATE);
        }
        let tapped = ctx.animate(hold, 0.0, TAP_HOLD_SPEC) > 0.0;
        let target = f32::from(state.pressed || state.drag_started || tapped);
        let (k, c) = if target > 0.5 { EXPAND } else { CONTRACT };
        let expand = ctx.spring(id.with("expand"), target, k, c).x;

        // ── Track: systemGreen on, tertiaryLabel off, cross-faded in 0.25 s (`:281-291`).
        // ── 轨道：开为 systemGreen、关为 tertiaryLabel，在 0.25s 内交叉淡入（`:281-291`）。
        let colour = role_of(
            pack,
            if semantic_on { "glassTrackActive" } else { "glassTrackInactive" },
        );
        let track = ctx.animate_colour(id.with("track"), colour, TRACK_COLOUR);

        // ── Jelly: the same velocity the slider reads, so the pill squashes along its travel
        // and stretches across it instead of only inflating.
        // ── 果冻：与滑块同一条速度，胶囊因此沿行程压扁、垂直方向拉长，而不是只鼓起来。
        let velocity = ctx.spring(
            id.with("jelly"),
            pos,
            THUMB_JELLY_SPRING.0,
            THUMB_JELLY_SPRING.1,
        )
        .v;
        let thumb = switch_thumb(pos, expand, thumb_jelly(id, velocity, ctx));
        let centre = thumb.x + thumb.w * 0.5;
        let (lo, hi) = (INSET + THUMB_W * 0.5, WIDTH - INSET - THUMB_W * 0.5);
        let edge = if centre <= lo + EDGE_TOGGLE && semantic_on {
            Some(false)
        } else if centre >= hi - EDGE_TOGGLE && !semantic_on {
            Some(true)
        } else {
            None
        };

        Self {
            id,
            pos,
            expand,
            track,
            thumb,
            white: role_of(pack, "glassThumb"),
            backdrop: glass_backdrop(
                &crate::material::glass_recipe(pack, crate::material::Control::Switch),
                expand.clamp(0.0, 1.0),
            ),
            edge,
            semantic_on,
            label: LabelText::new(
                pack,
                TextRole::Body,
                label,
                role_of(pack, "textFillColorPrimary"),
                f32::INFINITY,
            ),
        }
    }
}

impl Widget for GlassSwitch {
    fn handles_disabled(&self) -> bool {
        // The 0.5 fade is painted here; the adapter must not fade again.
        // 0.5 的淡出在此绘制；适配器不得再淡化一次。
        true
    }

    fn change(
        &self,
        state: &ui_widgets::WidgetState,
        _bounds: ui_core::geom::Rect,
    ) -> Option<ui_core::Change> {
        if state.disabled {
            return None;
        }
        // A tap flips the switch; the drag path owns everything else.
        // 点击翻转开关；其余情况由拖拽路径决定。
        if state.clicked && !state.dragging {
            return Some(ui_core::Change::Toggled {
                on: Some(!self.semantic_on),
            });
        }
        // Reaching the far end flips it mid-drag, as the reference does (`:527-541`).
        // 拖到远端时中途翻转，与参考一致（`:527-541`）。
        if let Some(want_on) = self.edge
            && state.dragging && want_on != self.semantic_on {
                return Some(ui_core::Change::Toggled {
                    on: Some(want_on),
                });
            }
        // On release, commit by the side the thumb came to rest on. The reference toggles
        // unconditionally here instead (`:544-553`), so dragging away from the current side
        // still flips it; that is a defect we do not copy.
        // 松手按滑块落定的一侧提交。参考此处无条件翻转（`:544-553`），因此从当前一侧拖开
        // 仍会翻转；这个缺陷我们不照搬。
        if state.dropped {
            let want_on = self.pos > 0.5;
            return (want_on != self.semantic_on).then_some(ui_core::Change::Toggled {
                on: Some(want_on),
            });
        }
        None
    }

    fn decl(&self, cx: &ui_widgets::Cx<'_, '_>) -> Decl {
        let disabled = cx.state(self.id).disabled;
        let t = self.thumb;

        // Track: one flat colour, fixed to the 63×28 box.
        // 轨道：单一纯色，固定在 63×28 盒内。
        let track = Decl::container(self.id.with("track"), NodeKind::Box)
            .background(self.track, Corners::all(HEIGHT * 0.5))
            .size(SizeClass::fixed(WIDTH, HEIGHT));

        // Thumb: a clear glass capsule carrying the white pill, which fades as the glass
        // arrives — one shape from solid to lens, exactly as the reference's cross-fade.
        // 滑块：一枚透明玻璃胶囊，其中的白色胶囊随玻璃到位而淡出——从实心到透镜是同一个形状，
        // 与参考的交叉淡入一致。
        let pill = Color {
            a: self.white.a * (1.0 - self.expand).clamp(0.0, 1.0),
            ..self.white
        };
        let mut thumb = Decl::container(self.id.with("thumb"), NodeKind::Box)
            .background(Color::TRANSPARENT, Corners::all(t.h * 0.5))
            .size(SizeClass::fixed(t.w, t.h))
            .offset(t.x, t.y)
            .shapes(glass_face(
                ui_core::geom::Rect::new(0.0, 0.0, t.w, t.h),
                Corners::all(t.h * 0.5),
                pill,
                self.expand,
            ));
        if let Some(backdrop) = self.backdrop
            && let Some(p) = thumb.data.params_mut() {
                p.backdrop_blur = Some(backdrop);
            }

        // The lens drops the reference's rim shadow; at rest the pill casts nothing.
        // 透镜投下参考的边缘阴影；静止时胶囊不投影。
        let shadow = Decl::container(self.id.with("shadow"), NodeKind::Box)
            .offset(t.x, t.y)
            .size(SizeClass::fixed(t.w, t.h))
            .shapes(vec![rim_shadow(0.0, 0.0, t.w, t.h, self.expand)]);

        let stack = Decl::container(self.id.with("stack"), NodeKind::Stack)
            .size(SizeClass::fixed(WIDTH, HEIGHT))
            .child(track)
            .child(shadow)
            .child(thumb);
        let mut row = Decl::container(self.id, NodeKind::Row)
            .sense(
                ui_core::Sense::HOVER
                    | ui_core::Sense::CLICK
                    | ui_core::Sense::DRAG
                    | ui_core::Sense::FOCUSABLE,
            )
            .cursor(ui_core::CursorShape::PointingHand)
            .gap(8.0)
            .padding(Insets {
                left: 0.0,
                top: 6.0,
                right: 0.0,
                bottom: 6.0,
            })
            .child(stack);
        if let Some(label) = &self.label {
            row = row.child(label.decl(self.id.with("label")));
        }
        if disabled {
            row = row.opacity(0.5);
        }
        row
    }
}

/// LiquidGlassKit's switch geometry (`LiquidGlassSwitch.swift:107-124`).
/// LiquidGlassKit 的开关几何（`LiquidGlassSwitch.swift:107-124`）。
pub const WIDTH: f32 = 63.0;
pub const HEIGHT: f32 = 28.0;
/// `thumbPadding = 2`, which is `(HEIGHT - THUMB_H) / 2`.
/// `thumbPadding = 2`，即 `(HEIGHT - THUMB_H) / 2`。
pub const INSET: f32 = 2.0;
pub const THUMB_W: f32 = 37.0;
pub const THUMB_H: f32 = 24.0;
/// The lens the pill grows into: 58×38.333, which overflows the 28 dp track.
/// 胶囊长成的透镜：58×38.333，溢出 28dp 的轨道。
pub const EXPANDED_W: f32 = 58.0;
pub const EXPANDED_H: f32 = 38.333;
/// How close to an end the thumb must come to flip the switch mid-drag (`:527-541`).
/// 滑块距端点多近就在拖拽中翻转开关（`:527-541`）。
pub const EDGE_TOGGLE: f32 = 5.0;
/// How long a tap holds the lens open before it contracts (`:424-430`).
/// 点击后透镜张开多久才收束（`:424-430`）。
pub const TAP_HOLD: f32 = 0.2;
/// The hold itself: an animation decaying from one to zero over `TAP_HOLD`.
/// 保持本身：一条在 `TAP_HOLD` 内由 1 衰减到 0 的动画。
pub const TAP_HOLD_SPEC: AnimSpec = AnimSpec::new(TAP_HOLD, Easing::Linear);

/// Apple's `(duration, dampingRatio)` springs, mapped by `k = (2π/T)²`, `c = 4πζ/T` — a
/// convention, since UIKit's own conversion is not published.
/// 苹果的 `(时长, 阻尼比)` 弹簧，按 `k = (2π/T)²`、`c = 4πζ/T` 换算——UIKit 未公开其换算，
/// 这是约定。
const EXPAND: (f32, f32) = (246.74, 18.85);
const CONTRACT: (f32, f32) = (109.66, 14.66);
const POSITION: (f32, f32) = (157.91, 25.13);
/// `UIView.animate(withDuration: 0.25)` uses the ease-in-out curve.
/// `UIView.animate(withDuration: 0.25)` 走 ease-in-out 曲线。
const TRACK_COLOUR: AnimSpec = AnimSpec::new(0.250, Easing::Cubic(0.42, 0.0, 0.58, 1.0));

/// The thumb's travel between the inset edges.
/// 滑块在两端内缩之间的行程。
pub fn travel() -> f32 {
    WIDTH - THUMB_W - 4.0
}

/// The thumb box at progress `pos`, melted into the lens by `t` — one capsule, no material
/// inside it: the pill and the glass are the same shape at every point of the morph.
/// `pos` 处、化开 `t` 的滑块盒子——只有一枚胶囊，内部不再有物质：整个形变过程中白色胶囊与
/// 玻璃都是同一个形状。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct SwitchThumb {
    pub x: f32,
    pub y: f32,
    pub w: f32,
    pub h: f32,
    /// The corner radius, always half the height: a pill at every size.
    /// 圆角半径，恒为高度的一半：任何尺寸都是胶囊。
    pub corner: f32,
}

/// The thumb at `pos` and melt `t`, squashed by `jelly`. `t` is a spring value, so it may leave
/// 0..=1 — that overshoot is the reference's own damping, and it makes the growth elastic.
/// `pos` 与化开程度 `t` 处的滑块，按 `jelly` 形变。`t` 是弹簧值，可以越出 0..=1——
/// 这段过冲正是参考自己的阻尼，也正是让展开读起来有弹性的原因。
pub fn switch_thumb(pos: f32, t: f32, jelly: (f32, f32)) -> SwitchThumb {
    let w = THUMB_W + (EXPANDED_W - THUMB_W) * t;
    let h = THUMB_H + (EXPANDED_H - THUMB_H) * t;
    let centre_x = INSET + THUMB_W * 0.5 + travel() * pos;
    let centre_y = INSET + THUMB_H * 0.5;
    let r = jelly_capsule(
        ui_core::geom::Rect::new(centre_x - w * 0.5, centre_y - h * 0.5, w, h),
        jelly,
    );
    SwitchThumb {
        x: r.origin.x,
        y: r.origin.y,
        w: r.size.w,
        h: r.size.h,
        corner: r.size.h * 0.5,
    }
}
