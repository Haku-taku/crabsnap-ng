//! The kit: options resolved from the scope, controls built here.
//! 风格包：从作用域解析选项，并在此构建控件。

use ui_style::Style;
use ui_widgets::ScaffoldSpec;
use ui_widgets::{Widget, StyleKit};


use crate::{GlassScaffold, GlassSlider, GlassSwitch};

/// Glass-specific knobs the semantic specs cannot express; scopes override the instance default.
/// 语义规格表达不了的 Glass 专属旋钮；作用域覆盖实例默认值。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct HigOptions {
    /// Rim stroke width in dp; the reference rim is a hairline specular edge.
    /// 描边宽度（dp）；参考里的棱边是一条发丝高光。
    pub rim_width: f32,
}

impl Default for HigOptions {
    fn default() -> Self {
        Self { rim_width: 1.0 }
    }
}

/// HIG's kit; its controls are composed from primitives, not drawn by a framework.
/// HIG 风格包；控件由基元组合而成，而非框架绘制。
pub struct HigKit {
    /// This kit's own pack constructor, so a scope-driven theme switch needs no rebuild.
    /// 本包自己的建包函数，使作用域驱动的主题切换无需重建。
    resolver: fn(ui_design::Appearance) -> Style,
    /// Every control in a frame shares one resolved pack per context.
    /// 同一帧内所有控件按上下文共用一份解析好的包。
    cache: ui_style::StyleCache,
    options: HigOptions,
    /// The context used when no `StyleScope` is on the chain.
    /// 链上没有 `StyleScope` 时使用的上下文。
    home: ui_style::StyleScope,
}

impl HigKit {
    /// A kit whose home context is the standard light one.
    /// 回落上下文为标准浅色上下文的风格包。
    pub fn new() -> Self {
        Self::with_scope(ui_style::StyleScope::default(), HigOptions::default())
    }

    /// An instance whose home context and unprefixed defaults are the given ones.
    /// 以给定上下文与默认值作为无作用域时回落的实例。
    pub fn with_scope(scope: ui_style::StyleScope, options: HigOptions) -> Self {
        Self {
            resolver: crate::pack::pack_owned,
            cache: ui_style::StyleCache::new(),
            options,
            home: scope,
        }
    }

    fn options_in(&self, env: &ui_style::Env) -> HigOptions {
        env.find::<HigOptions>().copied().unwrap_or(self.options)
    }

    /// The pack for the scope in force, with any running theme transition applied.
    /// 当前作用域下的包，并应用正在进行的主题过渡。
    fn pack_in(&self, cx: &ui_widgets::Cx<'_, '_>) -> Style {
        let scope = cx.env().scope().unwrap_or(self.home);
        self.cache.get(scope, self.resolver)
    }
}

impl Default for HigKit {
    fn default() -> Self {
        Self::new()
    }
}

impl StyleKit for HigKit {
    fn slider(
        &self,
        spec: &ui_style::SliderSpec<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        let node = cx.at(spec.id);
        let mut ctx = node;
        Box::new(GlassSlider::new_with(
            p,
            spec.id,
            spec.value,
            spec.label,
            &mut ctx,
            &pack,
        ))
    }

    fn toggle(
        &self,
        spec: &ui_style::ToggleSpec<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        let p = self.options_in(cx.env());
        let pack = self.pack_in(cx);
        let node = cx.at(spec.id);
        let mut ctx = node;
        Box::new(GlassSwitch::new_with(
            p,
            spec.id,
            spec.on,
            spec.label,
            &mut ctx,
            &pack,
        ))
    }

    fn scaffold(
        &self,
        spec: &ScaffoldSpec<'_>,
        cx: &mut ui_widgets::Cx<'_, '_>,
    ) -> Box<dyn Widget> {
        Box::new(cx.with_cx(|cx| GlassScaffold::new(spec, cx)))
    }
}

