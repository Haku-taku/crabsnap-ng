//! The one label shape every control in this pack draws.
//! 本包每个控件都用的同一种标签形状。

use ui_core::geom::Color;
use ui_core::{Decl, Id};
use ui_style::{Style, TextRole};

/// A label resolved to scalars, so `decl()` needs no style pack.
/// 标签已解析成标量，因此 `decl()` 不再需要风格包。
#[derive(Clone)]
pub(crate) struct LabelText {
    text: String,
    size: f32,
    color: Color,
    weight: ui_core::Weight,
    max_width: f32,
    line_gap: f32,
    indent: f32,
}

impl LabelText {
    pub(crate) fn new(pack: &Style, role: TextRole, text: &str, color: Color, max_width: f32) -> Option<Self> {
        if text.is_empty() {
            return None;
        }
        let t = pack.type_table.get(role);
        Some(Self {
            text: text.to_string(),
            size: t.size,
            color,
            weight: t.weight,
            max_width,
            line_gap: t.line_gap,
            indent: t.indent,
        })
    }

    /// The same label scaled about its own type size, for the magnified tab.
    /// 同一个标签按自身字号缩放，供被放大的标签使用。
    pub(crate) fn scaled(&self, k: f32) -> Self {
        Self {
            size: self.size * k,
            ..self.clone()
        }
    }

    /// The same label at an explicit size and weight, for a control the type ramp lacks.
    /// 同一个标签改用指定字号与字重，供字阶里没有对应档位的控件使用。
    pub(crate) fn restyled(&self, size: f32, weight: ui_core::Weight) -> Self {
        Self {
            size,
            weight,
            ..self.clone()
        }
    }

    /// The same label in another ink, for a selected/unselected crossfade.
    /// 同一个标签换一种墨色，用于选中与未选中的过渡。
    pub(crate) fn inked(&self, color: Color) -> Self {
        Self {
            color,
            ..self.clone()
        }
    }

    pub(crate) fn size(&self) -> f32 {
        self.size
    }

    pub(crate) fn weight(&self) -> ui_core::Weight {
        self.weight
    }

    /// The box this label needs, so a caller can centre a label beside an icon.
    /// 该标签所需的盒子，调用方因此能把文字与图标一起居中。
    pub(crate) fn height(&self) -> f32 {
        self.size * ui_widgets::LINE_HINT
    }

    /// The width this label takes on one line, measured as layout will measure it.
    /// 该标签单行占用的宽度，与布局所用的同一次测量。
    pub(crate) fn width_in(&self, cx: &ui_widgets::Cx<'_, '_>) -> Option<f32> {
        ui_widgets::Text::new(Id::str("glass/measure"), self.text.clone(), self.size, self.color)
            .weight(self.weight)
            .width_in(cx)
    }

    pub(crate) fn decl(&self, id: Id) -> Decl {
        ui_widgets::text::leaf(
            id,
            self.text.clone(),
            self.size,
            self.color,
            self.weight,
            self.max_width,
            self.line_gap,
            self.indent,
        )
    }
}

