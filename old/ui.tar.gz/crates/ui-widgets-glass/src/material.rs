//! The glass presets: optics from LiquidGlassKit, body from a measurement of Apple's glass.
//! 玻璃预设：光学取自 LiquidGlassKit，本体取自对 Apple 玻璃的实测。
//!
//! LiquidGlassKit ships one shader and three presets: the thumb (`LiquidGlassView.swift:56-78`),
//! the tab-bar lens (`:81-104`), and the regular panel (`:106-124`). Its regular panel stands
//! in for Apple's luminance lift with a pale-blue wash; Theseus measured the real transfer.
//! LiquidGlassKit 只有一个着色器和三套预设：滑块（`LiquidGlassView.swift:56-78`）、
//! 标签栏透镜（`:81-104`）与常规面板（`:106-124`）。它的常规面板用淡蓝洗色冒充 Apple 的亮度
//! 抬升；Theseus 量到了真正的变换。

use ui_core::draw::{BlendShape, GlassBody, LiquidGlass, BLEND_SHAPES};
use ui_core::geom::Color;
use ui_design::Appearance;
use ui_style::Style;

/// Which control the material is for.
/// 材质属于哪个控件。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Control {
    Switch,
    Slider,
    /// The bar's own capsule: a wide panel behind the moving lens.
    /// 标签栏自身的胶囊：移动透镜身后的一块宽面板。
    TabBar,
    /// The capsule's moving lens.
    /// 胶囊上移动的透镜。
    TabLens,
    Button,
    ButtonProminent,
    /// The segmented control's moving lens.
    /// 分段控件上移动的透镜。
    SegmentLens,
    Menu,
    /// A card or plain container.
    /// 卡片或普通容器。
    Container,
}

/// The material a control wears.
/// 控件穿的材质。
pub fn glass_recipe(pack: &Style, control: Control) -> LiquidGlass {
    match control {
        Control::Switch => thumb(0.75),
        Control::Slider => thumb(1.0),
        Control::TabLens | Control::SegmentLens => lens(),
        // `.glassProminent` is the same body at higher strength, not a brand tint: thicker,
        // more opaque, brighter (`glass_button.dart:893-901`).
        // `.glassProminent` 是同一本体的加强档，不是品牌色：更厚、更不透明、更亮
        // （`glass_button.dart:893-901`）。
        Control::ButtonProminent => {
            let mut glass = regular(pack);
            glass.thickness = (glass.thickness * 2.5).clamp(30.0, 100.0);
            glass.tint = Color {
                a: 0.18,
                ..Color::WHITE
            };
            glass.glare_intensity = (glass.glare_intensity * 1.5).clamp(0.3, 1.0);
            glass
        }
        _ => regular(pack),
    }
}

/// The pressed knob: a 10 dp rim at index 1.11, and a 10 % lift with no hue of its own.
/// 按下态的旋钮：10dp 边缘、折射率 1.11，抬升 10% 且不带自己的色相。
fn thumb(magnification: f32) -> LiquidGlass {
    LiquidGlass {
        body: GlassBody {
            mix: 0.10,
            ..GlassBody::CLEAR
        },
        tint: Color::TRANSPARENT,
        refractive_index: 1.11,
        thickness: 10.0,
        capture_size: 1.0 / magnification,
        capture_scale: magnification,
        magnification,
        frost: 0.0,
        dispersion: 5.0,
        fresnel_intensity: 0.0,
        fresnel_distance: 70.0,
        fresnel_sharpness: 0.0,
        glare_intensity: 0.01,
        glare_distance: 30.0,
        glare_sharpness: -0.2,
        glare_convergence: 0.0,
        glare_bias: 0.0,
        glare_offset: std::f32::consts::PI * 0.9,
        blend: [BlendShape::NONE; BLEND_SHAPES],
        blend_count: 0,
        blend_k: 0.0,
    }
}

/// `LiquidGlass.lens` (`LiquidGlassView.swift:81-104`): a clear 6 dp lens that shows what lies
/// under it 1:1, sampled at native density so nothing under it is downsampled.
/// `LiquidGlass.lens`（`LiquidGlassView.swift:81-104`）：通透的 6dp 透镜，把身下的内容按 1:1
/// 显示，按原生密度取样，透镜下的内容因此不被降采样。
fn lens() -> LiquidGlass {
    LiquidGlass {
        body: GlassBody::CLEAR,
        tint: Color::TRANSPARENT,
        refractive_index: 1.1,
        thickness: 6.0,
        capture_size: 1.0,
        capture_scale: 1.0,
        magnification: 1.0,
        frost: 0.0,
        dispersion: 15.0,
        fresnel_intensity: 0.0,
        fresnel_distance: 70.0,
        fresnel_sharpness: 0.0,
        glare_intensity: 0.1,
        glare_distance: 30.0,
        glare_sharpness: -0.1,
        glare_convergence: 0.1,
        glare_bias: 1.0,
        glare_offset: -std::f32::consts::FRAC_PI_4,
        blend: [BlendShape::NONE; BLEND_SHAPES],
        blend_count: 0,
        blend_k: 0.0,
    }
}

/// Apple's regular glass (`TheseusMaterialModel.swift:8-22`): light lifts luminance 53 % toward
/// white and takes 6 % of the chroma; dark lifts shadows through a tone curve instead.
/// Apple 的 regular 玻璃（`TheseusMaterialModel.swift:8-22`）：亮色把亮度朝白抬 53%、取走 6% 的
/// 色度；暗色改走一条抬升暗部的色调曲线。
fn regular(pack: &Style) -> LiquidGlass {
    let dark = pack.appearance() == Some(Appearance::Dark);
    LiquidGlass {
        body: if dark {
            GlassBody {
                mix: 0.0,
                pole: 0.1125,
                chroma: 1.043,
                tone: 1.0,
            }
        } else {
            GlassBody {
                mix: 0.53,
                pole: 0.99,
                chroma: 0.937,
                tone: 0.0,
            }
        },
        tint: Color::TRANSPARENT,
        refractive_index: 1.5,
        thickness: 10.0,
        capture_size: 1.0,
        // A full-density capture, frosted by a real blur: a coarse capture upscaled with
        // bilinear is what made the backdrop look blocky.
        // 全密度捕获 + 真正的模糊：此前用粗捕获再双线性放大，背景因此有明显的块状锯齿。
        capture_scale: 1.0,
        magnification: 1.0,
        frost: 10.0,
        dispersion: 5.0,
        fresnel_intensity: 0.0,
        fresnel_distance: 70.0,
        fresnel_sharpness: 0.0,
        glare_intensity: 0.1,
        glare_distance: 30.0,
        glare_sharpness: -0.15,
        glare_convergence: 0.1,
        glare_bias: 1.0,
        glare_offset: -std::f32::consts::FRAC_PI_4,
        blend: [BlendShape::NONE; BLEND_SHAPES],
        blend_count: 0,
        blend_k: 0.0,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The switch and the slider are one preset: only the capture density differs, because
    /// only the switch's expanded thumb shrinks its face (`LiquidGlassSwitch.swift:70`).
    /// 开关与滑块是同一套预设：只有捕获密度不同，因为只有开关展开态的滑块会缩小自己的面
    /// （`LiquidGlassSwitch.swift:70`）。
    #[test]
    fn the_two_thumbs_differ_only_in_capture_density() {
        let switch = glass_recipe(&crate::pack(), Control::Switch);
        let slider = glass_recipe(&crate::pack(), Control::Slider);
        let stripped = |g: &LiquidGlass| LiquidGlass {
            capture_size: 1.0,
            capture_scale: 1.0,
            magnification: 1.0,
            ..*g
        };
        assert_eq!(stripped(&switch), stripped(&slider));
        assert!(switch.capture_scale < slider.capture_scale);
    }
}
