//! Geometry invariants of the two interactive glass controls.
//! 两个交互玻璃控件的几何不变量。

use crate::*;

#[test]
fn the_switch_is_the_reference_capsule_on_its_inset_edges() {
    // 63 track, 37×24 thumb, 2 dp inset on both ends: travel is 22.
    // 63 轨道、37×24 滑块、两端各内缩 2dp：行程 22。
    assert!((travel() - 22.0).abs() < 1e-4, "travel {}", travel());
    let off = switch_thumb(0.0, 0.0, NO_JELLY);
    assert_eq!((off.x, off.y, off.w, off.h), (2.0, 2.0, 37.0, 24.0));
    let on = switch_thumb(1.0, 0.0, NO_JELLY);
    assert!((on.x - 24.0).abs() < 1e-4, "x {}", on.x);
    // Fully melted is the reference's expanded thumb, 58×38.333 (`:107-124`).
    // 完全化开是参考的展开滑块 58×38.333（`:107-124`）。
    let lens = switch_thumb(0.0, 1.0, NO_JELLY);
    assert!((lens.w - 58.0).abs() < 1e-3, "w {}", lens.w);
    assert!((lens.h - 38.333).abs() < 1e-3, "h {}", lens.h);
}

#[test]
fn the_melt_grows_the_pill_about_a_pinned_centre_and_stays_a_pill() {
    // The reference cross-fades two views about one centre, so the melt must never shift the
    // knob — not even where the spring overshoots past either end of 0..=1.
    // 参考让两个视图绕同一个中心交叉淡入，因此化开绝不挪动滑块——即便弹簧越出 0..=1 两端。
    let centre = |b: SwitchThumb| (b.x + b.w * 0.5, b.y + b.h * 0.5);
    for pos in [0.0f32, 0.5, 1.0] {
        let want = INSET + THUMB_W * 0.5 + travel() * pos;
        for t in [-0.05f32, 0.0, 0.25, 0.5, 1.0, 1.1] {
            let b = switch_thumb(pos, t, NO_JELLY);
            let (cx, cy) = centre(b);
            assert!((cx - want).abs() < 1e-3, "centre {cx} at pos {pos} t {t}");
            assert!((cy - (INSET + THUMB_H * 0.5)).abs() < 1e-3, "centre y {cy}");
            assert!((b.corner - b.h * 0.5).abs() < 1e-3, "still a pill at t {t}");
            // Both axes interpolate between the two reference sizes, so the melt only ever
            // passes between them (and the overshoot only just past the far one).
            // 两轴都在参考的两个尺寸之间插值，化开因此只在这两者之间经过（过冲也只略过远端）。
            let w = THUMB_W + (EXPANDED_W - THUMB_W) * t;
            let h = THUMB_H + (EXPANDED_H - THUMB_H) * t;
            assert!((b.w - w).abs() < 1e-3 && (b.h - h).abs() < 1e-3, "{}x{}", b.w, b.h);
        }
    }
    // Sweeping the melt must never step the centre: a state-flipped anchor did exactly that.
    // 扫过整个化开过程时中心不得跳步：按状态翻转锚点干过的事正是这个。
    let mut last = centre(switch_thumb(0.7, 0.0, NO_JELLY));
    for k in 1..=100 {
        let now = centre(switch_thumb(0.7, k as f32 / 100.0, NO_JELLY));
        assert!((now.0 - last.0).abs() < 0.05 && (now.1 - last.1).abs() < 0.05, "step {k}");
        last = now;
    }
}

#[test]
fn a_drag_past_the_ends_rubber_bands_the_switch_too() {
    // The switch uses the slider's own rubber band over its 22 dp travel (`:511-518`).
    // 开关在它 22dp 的行程上用的正是滑块那条橡皮筋（`:511-518`）。
    let pull = 16.0;
    let v = rubber_band_at(1.0 + pull / travel(), travel());
    let offset = (v - 1.0) * travel();
    assert!((offset - pull.sqrt()).abs() < 1e-3, "offset {offset}");
    assert!(rubber_band_at(0.4, travel()) == 0.4, "inside the ends it is untouched");
}

#[test]
fn a_held_slider_lens_reaches_the_reference_expanded_size() {
    // LiquidGlassKit: 37×24 at rest, 58×38.333 held, both pills, centre pinned.
    // LiquidGlassKit：静止 37×24，按住 58×38.333，都是胶囊，中心不动。
    let rest = slider_thumb(0.0, 0.0, NO_JELLY);
    let held = slider_thumb(0.0, 1.0, NO_JELLY);
    assert!((rest.w - SLIDER_THUMB_W).abs() < 1e-4);
    assert!((rest.h - SLIDER_THUMB_H).abs() < 1e-4);
    assert!((held.w - SLIDER_EXPANDED_W).abs() < 1e-3, "w {}", held.w);
    assert!((held.h - SLIDER_EXPANDED_H).abs() < 1e-3, "h {}", held.h);
    assert!(held.h < held.w, "the held lens stays wider than tall: {}x{}", held.w, held.h);
    let centre = |b: SliderThumb| b.x + b.w * 0.5;
    assert!((centre(held) - centre(rest)).abs() < 1e-4, "the centre is pinned");
    assert!((rest.corner - rest.h * 0.5).abs() < 1e-4, "a pill at rest");
    assert!((held.corner - held.h * 0.5).abs() < 1e-4, "still a pill when held");
}

#[test]
fn the_slider_melt_pins_the_lens_centre_at_every_size() {
    // The reference cross-fades the white pill into the lens about one centre, so the melt
    // must never move what the value points at — not even where the spring overshoots.
    // 参考让白色胶囊绕同一个中心化入透镜，因此化开绝不移动值所指的位置——弹簧过冲时也不。
    let centre = |b: SliderThumb| b.x + b.w * 0.5;
    for v in [0.0f32, 0.5, 1.0] {
        let want = thumb_centre(v);
        let mut last = slider_thumb(v, 0.0, NO_JELLY);
        for t in [-0.05f32, 0.0, 0.25, 0.5, 1.0, 1.1] {
            let b = slider_thumb(v, t, NO_JELLY);
            assert!((centre(b) - want).abs() < 1e-3, "centre at v {v} t {t}");
            assert!((b.corner - b.h * 0.5).abs() < 1e-3, "still a pill at t {t}");
        }
        for k in 1..=100 {
            let now = slider_thumb(v, k as f32 / 100.0, NO_JELLY);
            assert!((centre(now) - centre(last)).abs() < 0.05, "step {k} at v {v}");
            last = now;
        }
    }
}

#[test]
fn the_slider_pins_the_lens_left_edge_to_the_travel_and_centres_the_pointer() {
    // Left edge runs 0 → travel; the pointer selects the value under the lens centre.
    // 左缘由 0 走到行程；指针按滑块中心选中值。
    assert_eq!(slider_thumb_x(0.0), SLIDER_THUMB_W * 0.5);
    assert_eq!(slider_thumb_x(1.0), SLIDER_WIDTH - SLIDER_THUMB_W * 0.5);
    assert_eq!(slider_value_at(SLIDER_THUMB_W * 0.5), 0.0);
    assert_eq!(slider_value_at(SLIDER_WIDTH - SLIDER_THUMB_W * 0.5), 1.0);
}

#[test]
fn a_pull_past_the_end_is_square_rooted_and_drags_the_track_along() {
    // 20.3 dp past the maximum reads as sqrt(20.3) = 4.506 dp of overshoot (`:771-778`), and
    // the track's far edge follows that overshoot exactly (`:371-386`).
    // 越过最大值 20.3dp 读作 sqrt(20.3)=4.506dp 的超出（`:771-778`），轨道远端正好跟着这段超出走
    // （`:371-386`）。
    let pull = 20.3;
    let v = rubber_band(1.0 + pull / slider_travel());
    let offset = rubber_band_offset(v);
    assert!((offset - pull.sqrt()).abs() < 1e-3, "offset {offset}");
    assert!(v > 1.0, "the thumb leaves the rest range");
    let rest = slider_thumb(1.0, 0.0, NO_JELLY);
    let pulled = slider_thumb(v, 0.0, NO_JELLY);
    assert!((pulled.x - rest.x - offset).abs() < 1e-3, "the lens rides the overshoot");
    let track = track_rect(offset);
    assert!((track.size.h - (SLIDER_TRACK_H - offset / 3.0)).abs() < 1e-4, "it thins");
    assert!(
        (track.origin.x + track.size.w - (SLIDER_WIDTH + offset)).abs() < 1e-4,
        "far edge {} vs {}",
        track.origin.x + track.size.w,
        SLIDER_WIDTH + offset
    );
    // The pull is elastic but bounded: ten times the pull is well under ten times the travel.
    // 拉扯有弹性但有界：十倍拉扯远小于十倍行程。
    let far = rubber_band_offset(rubber_band(1.0 + pull * 10.0 / slider_travel()));
    assert!(far < pull.sqrt() * 3.2, "far {far}");
    // The 2 dp floor holds however hard it is pulled.
    // 无论拉多狠，2dp 的下限都成立。
    let thin = track_rect(rubber_band_offset(rubber_band(1.0 + 1000.0 / slider_travel())));
    assert!((thin.size.h - 2.0).abs() < 1e-4, "h {}", thin.size.h);
}

#[test]
fn the_fill_vanishes_at_the_minimum_and_swallows_the_track_at_the_maximum() {
    // The reference fades the fill over 10 dp at the minimum end and lets it take the whole
    // track within 10 dp of the maximum (`:511-529`); the middle half fills to the lens.
    // 参考在最小端 10dp 内淡出填充、在最大端 10dp 内让它吃满整条轨道（`:511-529`）；
    // 中段则填到透镜处。
    let at = |v: f32| fill_rect(0.0, thumb_centre(v));
    assert!(at(0.0).size.w.abs() < 1e-4, "w {}", at(0.0).size.w);
    assert!((at(1.0).size.w - SLIDER_WIDTH).abs() < 1e-4, "w {}", at(1.0).size.w);
    assert!((at(0.5).size.w - thumb_centre(0.5)).abs() < 1e-4);
    // Halfway through each fade the fill is half weighted, never a step.
    // 两端淡出区的中点处填充权重各半，绝不是阶跃。
    let min_half = at(0.5 * 10.0 / slider_travel()).size.w;
    assert!(min_half > 0.0 && min_half < at(0.5 * 10.0 / slider_travel() + 0.01).size.w);
}

#[test]
fn the_tab_alignment_lands_each_index_on_its_cell_centre() {
    // Alignment -1..=1 must name the cell centres, or the pill sits between tabs.
    // 对齐值 -1..=1 必须指向各格中心，否则指示片会停在标签之间。
    let n = 3;
    let width = 375.0;
    let cell = (width - INSET * 2.0) / n as f32;
    for k in 0..n {
        let centre = INSET + cell * (k as f32 + 0.5);
        assert_eq!(index_at_x(centre, width, n), k, "cell {k}");
        let a = (tab_alignment(k, n) + 1.0) * 0.5;
        let pill_centre = INSET + a * (width - INSET * 2.0 - cell) + cell * 0.5;
        assert!((pill_centre - centre).abs() < 1e-4, "cell {k}");
    }
}

#[test]
fn a_drag_past_the_ends_rubber_bands_instead_of_stopping() {
    // The reference lets the alignment overshoot by 10% so the drag reads as elastic.
    // 参考允许对齐值越界 10%，拖拽因此有弹性。
    let (w, n) = (375.0, 3);
    assert!(alignment_at_x(0.0, w, n) < -1.0);
    assert!(alignment_at_x(w, w, n) > 1.0);
    assert!((alignment_at_x(0.0, w, n) - -1.2).abs() < 1e-4);
}

#[test]
fn the_morph_neck_peaks_where_the_travel_and_size_curves_part() {
    // The metaball bridge is the gap between the two curves: zero at both ends.
    // metaball 液桥由两条曲线的分差给出：两端都为零。
    let at = |raw| morph::compute(raw, 160.0, 0.0, 1.0, false);
    assert!(at(0.0).blend.abs() < 1e-4);
    assert!(at(1.0).blend.abs() < 1e-4);
    let mid = at(0.5);
    assert!(mid.blend > 1.0, "blend {} at half flight", mid.blend);
    assert!(mid.path_t > mid.size_t, "travel must lead size");
}

#[test]
fn the_morph_trigger_is_gone_by_forty_percent() {
    // Blob A has to vanish early, or the droplet never detaches.
    // Blob A 必须早早消失，否则液滴永远脱不开。
    let at = |raw| morph::compute(raw, 160.0, 0.0, 1.0, false);
    assert_eq!(at(0.0).anchor_scale, 1.0);
    assert_eq!(at(0.4).anchor_scale, 0.0);
    assert_eq!(at(1.0).anchor_scale, 0.0);
}

#[test]
fn the_morph_droplet_lands_on_target_and_stays_rooted_while_it_grows() {
    // The frame rides `sizeT`, and the two curves' drift is clamped to 8 dp: the blob grows
    // out of the trigger instead of flying off it, then lands exactly on the destination.
    // 矩形由 `sizeT` 驱动，两条曲线的偏差被夹在 8dp 内：blob 从触发物长出来而不是飞出去，
    // 最后精确落在目标上。
    let from = ui_core::geom::Rect::new(0.0, 0.0, 40.0, 40.0);
    let to = ui_core::geom::Rect::new(120.0, 0.0, 80.0, 40.0);
    let land = morph::compute(1.0, 140.0, 0.0, 1.0, false);
    let landed = morph::blob_rect(from, to, land);
    assert!((landed.origin.x - to.origin.x).abs() < 1e-3, "x {}", landed.origin.x);
    assert!((landed.size.w - to.size.w).abs() < 1e-3);
    let s = morph::compute(0.75, 140.0, 0.0, 1.0, false);
    let blob = morph::blob_rect(from, to, s);
    let rooted = 20.0 + 140.0 * s.size_t;
    assert!((blob.center().x - rooted).abs() <= 8.0 + 1e-3, "drift {}", blob.center().x);
}

#[test]
fn closing_ramps_the_neck_back_up_as_the_droplet_returns() {
    // On close the bridge is not the curve gap: it fires by proximity, so the droplet
    // re-merges with the regrown trigger instead of landing as a separate shape.
    // 关闭时液桥不看曲线分差，而按接近程度拉起，液滴因此与重新长出的触发物再融合。
    let at = |raw| morph::compute(raw, 160.0, 0.0, 1.0, true);
    assert!(at(1.0).blend.abs() < 1e-4);
    assert!(at(0.3).blend > 10.0, "blend {} on return", at(0.3).blend);
    assert!(at(0.3).anchor_scale > 0.5, "the trigger must be back to catch it");
}

#[test]
fn jelly_squashes_along_the_motion_and_stretches_across_it() {
    // At the thumbs' tuning 4 units/s is already full distortion (0.6): 0.7 across, 1.18 along.
    // 在两个滑块的参数下，4 单位/秒已到满形变（0.6）：横向 0.7、纵向 1.18。
    assert_eq!(jelly_scale((0.0, 0.0), 2.0, 0.6), NO_JELLY);
    let (sx, sy) = jelly_scale((4.0, 0.0), 2.0, 0.6);
    assert!((sx - 0.7).abs() < 1e-6 && (sy - 1.18).abs() < 1e-6, "{sx} {sy}");
    // Straight down swaps the axes; a diagonal is symmetric between them.
    // 竖直向下交换两轴；斜向则在两轴之间对称。
    let (dx, dy) = jelly_scale((0.0, -4.0), 2.0, 0.6);
    assert!((dx - 1.18).abs() < 1e-6 && (dy - 0.7).abs() < 1e-6, "{dx} {dy}");
    let (qx, qy) = jelly_scale((4.0, 4.0), 2.0, 0.6);
    let axis = 0.6 / 2f32.sqrt();
    assert!((qx - (1.0 - axis * 0.5) * (1.0 + axis * 0.3)).abs() < 1e-6, "{qx}");
    assert!((qy - qx).abs() < 1e-6, "{qx} {qy}");
    // Past full distortion the clamp holds, and a broken velocity reads as rest.
    // 超过满形变后由钳制兜住；坏掉的速度读作静止。
    assert_eq!(jelly_scale((99.0, 0.0), 2.0, 0.6), jelly_scale((4.0, 0.0), 2.0, 0.6));
    assert_eq!(jelly_scale((f32::NAN, 0.0), 2.0, 0.6), NO_JELLY);
}

#[test]
fn the_jelly_scales_a_thumb_about_the_point_its_value_names() {
    // The melt and the jelly share one pivot: a distortion must never move the thumb off it.
    // 化开与果冻共用一个轴心：形变绝不能把滑块挪离它。
    let rest = slider_thumb(0.4, 0.5, NO_JELLY);
    let squashed = slider_thumb(0.4, 0.5, (0.6, 1.24));
    assert!((squashed.x + squashed.w * 0.5 - thumb_centre(0.4)).abs() < 1e-4);
    assert!((squashed.y + squashed.h * 0.5 - (rest.y + rest.h * 0.5)).abs() < 1e-4);
    assert!(squashed.w < rest.w && squashed.h > rest.h, "{}x{}", squashed.w, squashed.h);
    assert!((squashed.corner - squashed.h * 0.5).abs() < 1e-4, "still a pill");
    let knob = switch_thumb(0.3, 0.5, (0.6, 1.24));
    let plain = switch_thumb(0.3, 0.5, NO_JELLY);
    assert!((knob.x + knob.w * 0.5 - (plain.x + plain.w * 0.5)).abs() < 1e-4);
    assert!((knob.y + knob.h * 0.5 - (plain.y + plain.h * 0.5)).abs() < 1e-4);
    assert!((knob.corner - knob.h * 0.5).abs() < 1e-4, "still a pill");
}
