//! The glass popover: the menu's frosted sheet, holding the app's own blocks.
//! 玻璃浮出层：菜单那块磨砂片，装的是应用自己的内容块。

use ui_core::geom::{Insets, Rect};
use ui_core::layout::{Anchor, Side};
use ui_core::shortcut::ShortcutId;
use ui_core::{Change, Decl, Id};
use ui_style::Style;
use ui_widgets::{Cx, Widget, WidgetState};

use crate::material::Control;
use crate::overlay::{Panel, PanelParams};

/// `GlassPopover.popoverWidth` and `popoverBorderRadius`.
/// `GlassPopover.popoverWidth` 与 `popoverBorderRadius`。
pub const POPOVER_W: f32 = 280.0;
pub const POPOVER_RADIUS: f32 = 24.0;
/// The reference leaves padding to the content builder; 16 dp is its own example.
/// 参考把内衬交给内容构建器；16dp 是它自己示例里的取值。
pub const POPOVER_PAD: f32 = 16.0;

/// The id the sheet binds Escape to.
/// 片把 Escape 绑到的 id。
pub const POPOVER_DISMISS_SHORTCUT: ShortcutId = ShortcutId("glass.popover.dismiss");

/// Everything a popover is built with; the app owns what the content says and what a
/// press inside it means.
/// 构建浮出层所需的全部输入；内容说什么、其中的按下意味着什么，都归应用所有。
pub struct GlassPopoverParams {
    pub id: Id,
    /// The node the sheet unfolds from.
    /// 片展开所依附的节点。
    pub anchor: Anchor,
    pub side: Side,
    /// `IsOpen`; a closed popover paints nothing and takes no keyboard.
    /// `IsOpen`；关闭的浮出层不画任何东西，也不占键盘。
    pub open: bool,
    pub width: f32,
    /// `popoverHeight`: a fixed height for content that scrolls itself.
    /// `popoverHeight`：供自行滚动的内容使用的固定高度。
    pub height: Option<f32>,
    pub radius: f32,
    pub padding: Insets,
    pub content: Vec<Decl>,
    /// Ids inside `content` whose press the sheet reports; their widgets are the app's.
    /// `content` 中按下要上报的 id；这些控件归应用所有。
    pub presses: Vec<Id>,
    /// `barrierDismissible`: whether a press outside the sheet closes it.
    /// `barrierDismissible`：片之外的按下是否关闭它。
    pub dismissible: bool,
    pub disabled: bool,
}

impl GlassPopoverParams {
    pub fn new(id: Id, anchor: Anchor) -> Self {
        Self {
            id,
            anchor,
            side: Side::Below,
            open: true,
            width: POPOVER_W,
            height: None,
            radius: POPOVER_RADIUS,
            padding: Insets::all(POPOVER_PAD),
            content: Vec::new(),
            presses: Vec::new(),
            dismissible: true,
            disabled: false,
        }
    }

    pub fn content(mut self, content: Vec<Decl>) -> Self {
        self.content = content;
        self
    }

    pub fn presses(mut self, presses: Vec<Id>) -> Self {
        self.presses = presses;
        self
    }

    pub fn side(mut self, side: Side) -> Self {
        self.side = side;
        self
    }

    pub fn open(mut self, open: bool) -> Self {
        self.open = open;
        self
    }

    pub fn width(mut self, width: f32) -> Self {
        self.width = width;
        self
    }

    pub fn height(mut self, height: f32) -> Self {
        self.height = Some(height);
        self
    }

    pub fn radius(mut self, radius: f32) -> Self {
        self.radius = radius;
        self
    }

    pub fn padding(mut self, padding: Insets) -> Self {
        self.padding = padding;
        self
    }

    pub fn dismissible(mut self, dismissible: bool) -> Self {
        self.dismissible = dismissible;
        self
    }

    pub fn disabled(mut self, disabled: bool) -> Self {
        self.disabled = disabled;
        self
    }
}

/// A glass popover: the sheet, and the blocks the app put in it.
/// 玻璃浮出层：那块片，以及应用放进去的内容块。
pub struct GlassPopover {
    panel: Panel,
    content: Vec<Decl>,
    /// The content id pressed this frame, read from its own state.
    /// 本帧按下的内容 id，读自它自己的状态。
    fired: Option<Id>,
    dismissible: bool,
    disabled: bool,
}

impl GlassPopover {
    pub fn new(params: GlassPopoverParams, cx: &mut Cx<'_, '_>, pack: &Style) -> Self {
        let GlassPopoverParams {
            id,
            anchor,
            side,
            open,
            width,
            height,
            radius,
            padding,
            content,
            presses,
            dismissible,
            disabled,
        } = params;
        let fired = presses
            .into_iter()
            .find(|id| cx.state(*id).clicked);
        Self {
            panel: Panel::new(
                PanelParams {
                    id,
                    anchor,
                    side,
                    open,
                    width,
                    height,
                    radius,
                    padding,
                    // Content blocks bring their own spacing; the sheet adds none.
                    // 内容块自带间距；片不再另加。
                    gap: 0.0,
                    control: Control::Container,
                    dismiss: POPOVER_DISMISS_SHORTCUT,
                },
                cx,
                pack,
            ),
            content,
            fired,
            dismissible,
            disabled,
        }
    }
}

impl Widget for GlassPopover {
    fn handles_disabled(&self) -> bool {
        // The app's own blocks carry their own disabled look; the adapter must not add one.
        // 应用自己的内容块自带禁用外观；适配器不得再加一层。
        true
    }

    fn change(&self, state: &WidgetState, _bounds: Rect) -> Option<Change> {
        if self.disabled {
            return None;
        }
        if let Some(id) = self.fired {
            return Some(Change::Selected(Some(id)));
        }
        // Escape is bound on the sheet, so it reaches here only while the popover holds keys.
        // Escape 绑定在片上，因此只有浮出层持有键盘时才会到这里。
        let escape = state.shortcut == Some(POPOVER_DISMISS_SHORTCUT);
        (escape || (self.dismissible && state.dismissed)).then_some(Change::Dismissed)
    }

    fn decl(&self, _cx: &Cx<'_, '_>) -> Decl {
        self.panel.decl(self.content.clone())
    }
}
