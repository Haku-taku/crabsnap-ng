//! The overlay sheet the glass menu and popover share: a frosted panel hung from its anchor.
//! 玻璃菜单与浮出层共用的浮出片：从锚点挂出的磨砂面板。

use ui_core::geom::{Color, Corners, Insets};
use ui_core::layout::{Anchor, AxisSize, Grow, OverlayAlign, OverlayPlacement, Side, SizeClass};
use ui_core::shortcut::{KeyChord, ShortcutId};
use ui_core::{Decl, Id, Key, Modifiers, NodeKind, Sense};
use ui_style::Style;
use ui_widgets::{Cx, WidgetState};

use crate::material::{glass_recipe, Control};
use crate::shared::glass_backdrop;

/// snappy(320 ms, bounce 0.15): the sheet's arrival, shared by every overlay.
/// snappy(320ms, bounce 0.15)：片的到位，所有浮层共用。
const REVEAL_K: f32 = 385.14;
const REVEAL_C: f32 = 33.38;

/// Everything an overlay sheet is built with.
/// 构建一块浮出片所需的全部输入。
pub(crate) struct PanelParams {
    pub id: Id,
    /// The node the panel unfolds from.
    /// 面板展开所依附的节点。
    pub anchor: Anchor,
    pub side: Side,
    /// `IsOpen`; a closed panel paints nothing and takes no keyboard.
    /// `IsOpen`；关闭的面板不画任何东西，也不占键盘。
    pub open: bool,
    pub width: f32,
    /// A fixed height for scrollable content; `None` hugs the children.
    /// 可滚动内容的固定高度；`None` 时贴合子节点。
    pub height: Option<f32>,
    pub radius: f32,
    pub padding: Insets,
    pub gap: f32,
    pub control: Control,
    /// The id Escape is bound to; each overlay owns one so two can be up at once.
    /// Escape 绑定的 id；每个浮层各有一个，好让两个能同时在场。
    pub dismiss: ShortcutId,
}

/// A resolved sheet: the facts `decl` needs, with the pack and this frame's springs read.
/// 一块解出的片：`decl` 需要的事实，包与本帧的弹簧已读取。
pub(crate) struct Panel {
    id: Id,
    anchor: Anchor,
    side: Side,
    open: bool,
    width: f32,
    height: Option<f32>,
    radius: f32,
    padding: Insets,
    gap: f32,
    dismiss: ShortcutId,
    /// Open progress 0..=1: the panel fades in as it arrives.
    /// 展开进度 0..=1：面板到位时淡入。
    reveal: f32,
    backdrop: Option<ui_core::BackdropBlur>,
}

impl Panel {
    pub(crate) fn new(params: PanelParams, cx: &mut Cx<'_, '_>, pack: &Style) -> Self {
        let PanelParams {
            id,
            anchor,
            side,
            open,
            width,
            height,
            radius,
            padding,
            gap,
            control,
            dismiss,
        } = params;
        let reveal = {
            let mut node = cx.at(id);
            node.spring(id.with("reveal"), f32::from(open), REVEAL_K, REVEAL_C)
                .x
        };
        Self {
            id,
            anchor,
            side,
            open,
            width,
            height,
            radius,
            padding,
            gap,
            dismiss,
            reveal,
            backdrop: glass_backdrop(&glass_recipe(pack, control), 1.0),
        }
    }

    /// The sheet with its children: a column at its own insets, hung from the anchor.
    /// 装着子节点的片：按自身内衬排成列，挂在锚点上。
    pub(crate) fn decl(&self, children: Vec<Decl>) -> Decl {
        let id = self.id;
        // A closed panel is not an overlay at all: leaving one would make it the keyboard
        // scope and light-dismiss target of a sheet nobody can see.
        // 关闭的面板根本不是浮层：留着它会成为一块无人看得见的片的键盘作用域与轻关闭目标。
        if !self.open {
            return Decl::container(id, NodeKind::Box)
                .absolute()
                .size(SizeClass::fixed(0.0, 0.0));
        }
        let placement = OverlayPlacement {
            anchor: self.anchor,
            side: self.side,
            align: OverlayAlign::Start,
            offset: 0.0,
            flip: true,
            match_anchor_width: false,
            match_anchor_height: false,
            min_width: 0.0,
        };
        let corners = Corners::all(self.radius);
        let mut panel = Decl::container(id, NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fixed(self.width),
                height: self
                    .height
                    .map_or(AxisSize::hug(0.0, 0.0), AxisSize::fixed),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(self.padding)
            .gap(self.gap)
            .corners(corners)
            .background(Color::TRANSPARENT, corners)
            .opacity(self.reveal.clamp(0.0, 1.0))
            .overlay(placement)
            // Asking for focus is what makes this the keyboard scope while it is open.
            // 索取焦点正是它打开期间成为键盘作用域的原因。
            .sense(Sense::FOCUSABLE | Sense::HOVER)
            .shortcut(KeyChord::new(Key::Escape, Modifiers::NONE), self.dismiss);
        if let Some(backdrop) = self.backdrop
            && let Some(p) = panel.data.params_mut() {
                p.backdrop_blur = Some(backdrop);
            }
        for child in children {
            panel = panel.child(child);
        }
        panel
    }
}

/// Whether this frame asks the sheet to close: a press outside it, or Escape.
/// 本帧是否要求片关闭：在它之外按下，或按了 Escape。
pub(crate) fn panel_dismissed(state: &WidgetState, dismiss: ShortcutId) -> bool {
    state.dismissed || state.shortcut == Some(dismiss)
}
