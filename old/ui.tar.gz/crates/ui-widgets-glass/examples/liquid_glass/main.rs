//! The Liquid Glass showcase: the demo app the Flutter reference ships, rebuilt on this
//! engine's glass controls.
//! 液态玻璃展示：Flutter 参考实现自带的演示 app，用本引擎的玻璃控件重建。
//!
//! Four bottom tabs, as the reference has: Explore, Widgets, Demos and Examples.
//! 底部四个页签，与参考一致：探索、控件、演示与示例。

mod app;
mod pages;

use app::LiquidGlassApp;
use ui_demo::Demo;

/// Faces in the order a glyph is looked up: Latin first, then the Chinese face behind it.
/// 字形查找顺序：先拉丁，再其后的中文面。
const STACK: &[&str] = &[
    "SF Pro Text",
    "SF Pro Display",
    "Inter",
    "PingFang SC",
    "Noto Sans SC",
    "Noto Sans CJK SC",
    "MiSans VF",
    "HarmonyOS Sans SC",
];

fn main() {
    Demo::new(
        "crabsnap-ui   Liquid Glass",
        "dev.crabsnap.ui.liquid_glass",
        1280,
        900,
    )
    .stack(STACK)
    .font("Inter", ui_demo::INTER)
    .font(ui_widgets::SF_SYMBOLS_FAMILY, ui_demo::SF_SYMBOLS)
    .wallpaper("/home/ollie/Pictures/Wallpapers/140959926_p0.png")
    .run(LiquidGlassApp::new());
}
