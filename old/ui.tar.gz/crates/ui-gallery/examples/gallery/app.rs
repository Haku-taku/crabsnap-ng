// The gallery's app state and its App implementation.
// 画廊应用状态及其 App 实现。

use crate::pages::*;
use crate::shell::*;
use ui_widgets_glass::{detent_id_of, GlassSheetDetent};

pub(crate) struct Gallery {
    pub(crate) page: Page,
    pub(crate) on: bool,
    pub(crate) value: f32,
    /// Whether the whole gallery renders in the light or the dark appearance. The toolbar's
    /// toggle flips it; nothing else in the demo changes.
    /// 整个 gallery 以浅色还是深色外观渲染。工具条的按钮切换它；demo 其它部分不变。
    pub(crate) dark: bool,
    /// Each MD3 variant's own on-value, seeded to the requested defaults: icon switches start
    /// off, plain ones on. A click flips just that variant.
    /// 每个 MD3 变体各自的 on 值，按要求的默认播种：有图标初始关、无图标初始开。点击只翻转该变体。
    pub(crate) variant_on: [bool; 4],
    /// Each MD3 checkbox's live value; `error` and `disabled` live on the instance.
    /// 每个 MD3 复选框的实时值；`error` 与 `disabled` 在实例上。
    pub(crate) checked: [ui_widgets_md3::CheckState; CHECKBOXES],
    /// The Fluent column's three boxes; one value each, the app owns them.
    /// Fluent 列的三个方框；各有自己的值，归应用所有。
    pub(crate) fchecked: [ui_widgets_fluent::CheckState; 3],
    /// The `IsThreeState` box: a click walks it through all three values.
    /// `IsThreeState` 方框：一次点击把它走过三个值。
    pub(crate) ftri: ui_widgets_fluent::CheckState,
    /// Which option of the demo radio group is selected; the group lives in the app.
    /// 演示单选组中选中的选项；整组归应用所有。
    pub(crate) radio_sel: usize,
    /// The Fluent column's selection; the control reports, the app decides.
    /// Fluent 列的选中项；控件上报，应用决定。
    pub(crate) fradio_sel: usize,
    /// Each tab bar's selected index; a bar never holds its own selection.
    /// 每条页签栏选中的下标；栏自身从不持有选择。
    pub(crate) tab_sel: [usize; TAB_BARS],
    /// The Fluent strip's open tabs, as slots of `TAB_MANY`, and which one is picked.
    /// Fluent 页签带打开的页签（`TAB_MANY` 的槽位），以及选中的那一个。
    pub(crate) fluent_tabs: Vec<usize>,
    pub(crate) fluent_tab_sel: usize,
    /// Tooltip demo: the target under the pointer, the hover episode's clock and how long
    /// it has run, and which panel is mounted (open or fading out).
    /// 提示框演示：指针下的目标、本次悬停的时钟与已走时长，以及已挂载（展开或正在淡出）的面板。
    pub(crate) tip_hover: Option<usize>,
    pub(crate) tip_gen: u32,
    pub(crate) tip_delay: f32,
    pub(crate) tip_shown: Option<usize>,
    pub(crate) tip_close_at: Option<f64>,
    /// Each Fluent info bar's `IsOpen`; a close button reports, the app collapses the bar.
    /// 每条 Fluent 信息栏的 `IsOpen`；关闭按钮只上报，收起由应用决定。
    pub(crate) info_open: [bool; INFO_BARS],
    /// Each toggle button's selection; a button never holds its own.
    /// 每个切换按钮的选中态；按钮自身从不持有它。
    pub(crate) btn_sel: [bool; BTN_TOGGLES],
    /// Each FAB menu's own open state; the app owns it, a click on an item or the anchor moves it.
    /// 每个 FAB 菜单各自的展开状态，归应用所有；点击菜单项或锚点改变它。
    pub(crate) fab_open: [bool; FAB_MENUS],
    /// Each filter chip's own selection; the app owns it.
    /// 每颗筛选芯片各自的选中态，归应用所有。
    pub(crate) chip_sel: [bool; CHIP_FILTERS],
    /// The glass chips' selections, and whether the removable one has been deleted.
    /// 玻璃芯片的选中态，以及那颗可删除的芯片是否已被删除。
    pub(crate) chip_glass: [bool; CHIP_GLASS_FILTERS],
    pub(crate) chip_glass_gone: bool,
    /// The segmented page's single and multi selections; the app owns both.
    /// 分段按钮页的单选与多选；两者都归应用所有。
    pub(crate) seg_single: usize,
    pub(crate) seg_multi: [bool; SEGMENTS],
    /// The glass segmented control's own selection, kept apart from MD3's.
    /// 玻璃分段控件自己的选择，与 MD3 的分开。
    pub(crate) seg_glass: usize,
    /// How many glass buttons have been activated.
    /// 玻璃按钮被激活的次数。
    pub(crate) glass_press: u32,
    /// The destination the bar and rail samples share, and the drawer's own choice.
    /// 栏与轨道样本共用的目标，以及抽屉自己的选择。
    pub(crate) nav_sel: usize,
    pub(crate) drawer_sel: usize,
    /// The toolbar member toggled on, and how often a snackbar action was clicked.
    /// 工具条中选中的成员，以及提示条动作被点击的次数。
    pub(crate) toolbar_sel: Option<usize>,
    pub(crate) snack_hits: u32,
    /// Whether the floating snackbar sample is showing; the app owns it.
    /// 浮动提示条样本是否显示；归应用所有。
    pub(crate) snack_overlay_visible: bool,
    /// How many times each card variant was activated; a card only reports the event.
    /// 每种卡片变体被激活的次数；卡片只上报事件。
    pub(crate) card_hits: [u32; CARD_CLICKS],
    /// Each selectable list row's own selection; the app owns it.
    /// 每个可选列表行各自的选中态，归应用所有。
    pub(crate) list_sel: [bool; LIST_SELECT],
    /// How many glass list rows have been activated.
    /// 玻璃列表行被激活的次数。
    pub(crate) glass_list_hits: u32,
    /// Whether the big sample icon is filled; its `FILL` axis animates toward it.
    /// 大号样本图标是否实心；它的 `FILL` 轴向它动画。
    pub(crate) icon_filled: bool,
    /// The app bar page's two app-owned facts, and the slot it last reported.
    /// 应用栏页由应用持有的两个事实，以及它最近上报的槽位。
    pub(crate) app_bar_scrolled: bool,
    pub(crate) app_bar_collapsed: bool,
    pub(crate) app_bar_fired: Option<&'static str>,
    /// Whether the rail page's Expressive sample is in its expanded half.
    /// 轨道页的 Expressive 样例是否在展开的那一半。
    pub(crate) rail_expanded: bool,
    /// The carousel item the page last reported; each strip scrolls on its own.
    /// 轮播页最近上报的条目；每条条带各自滚动。
    pub(crate) carousel_fired: Option<(usize, usize)>,
    /// Each picker's chosen day, the month it shows and which body it shows.
    /// 每块选择器选中的日期、显示的月份，以及它显示哪个主体。
    pub(crate) dp_value: [Option<ui_widgets_md3::Date>; DATE_PICKERS],
    pub(crate) dp_shown: [ui_widgets_md3::Date; DATE_PICKERS],
    pub(crate) dp_view: [ui_widgets_md3::DatePickerView; DATE_PICKERS],
    /// The text-mode input's buffer, and the action it last reported.
    /// 文本输入的缓冲，以及它最近上报的动作。
    pub(crate) di_text: String,
    pub(crate) di_action: Option<ui_widgets_md3::DateInputAction>,
    /// Each time input's two buffers and its period; the engine edits, the app keeps them.
    /// 每个时间输入的两个缓冲与周期；引擎编辑，应用保存。
    pub(crate) tp_hour: [String; TIME_PICKERS],
    pub(crate) tp_minute: [String; TIME_PICKERS],
    pub(crate) tp_period: [ui_widgets_md3::Period; TIME_PICKERS],
    /// The text field page's two live buffers; the engine edits them, the app keeps them.
    /// 文本字段页的两个活缓冲；引擎编辑它们，应用保存它们。
    pub(crate) tf_value: [String; TF_LIVE],
    /// The Fluent column's one live buffer.
    /// Fluent 列的唯一活缓冲。
    pub(crate) tf_fluent: String,
    /// The glass column's live buffer.
    /// 玻璃列的活缓冲。
    pub(crate) tf_glass: String,
    /// The search page's live query, and the last action the bar reported.
    /// 搜索页的活查询，以及栏上次上报的动作。
    pub(crate) search_value: String,
    pub(crate) search_acted: Option<String>,
    /// Whether the search view on that page is open, and the query it holds.
    /// 该页的搜索视图是否展开，以及它持有的查询。
    pub(crate) search_open: bool,
    pub(crate) search_view_value: String,
    /// The glass search bar's query, and the part it last reported.
    /// 玻璃搜索栏的查询，以及它上次上报的部件。
    pub(crate) glass_search: String,
    pub(crate) glass_search_acted: Option<String>,
    /// The chord the shortcut field captured; the app owns it, the field only reports.
    /// 快捷键字段捕获到的组合键；归应用所有，字段只负责上报。
    pub(crate) shortcut: Option<ui_core::KeyChord>,
    /// The dialog action the app was last told about, by its title key; a dialog only reports.
    /// 应用最后被告知的对话框动作（按标题 key）；对话框只负责上报。
    pub(crate) dialog_picked: Option<Msg>,
    /// How many times a click on a modal's scrim cancelled it.
    /// 模态遮罩上的点击取消它的次数。
    pub(crate) dialog_dismissed: u32,
    /// Whether the modal is showing. The app owns it, as it owns every dialog's lifetime.
    /// 模态是否显示。归应用所有，正如每个对话框的生命周期都归应用所有。
    pub(crate) dialog_open: bool,
    /// What the showing modal covers: the window, or the panel that hosts it.
    /// 正在显示的模态覆盖什么：窗口，或承载它的嵌板。
    pub(crate) dialog_target: ModalTarget,
    /// Whether the glass action sheet is up, what it last reported, and how often it was dismissed.
    /// 玻璃动作面板是否挂起、它上次上报了什么，以及被取消了多少次。
    pub(crate) sheet_open: bool,
    pub(crate) sheet_picked: Option<Msg>,
    pub(crate) sheet_dismissed: u32,
    /// Which toast is up, how often its action was pressed, and how often it was swiped away.
    /// 哪个提示条挂着、它的动作被按了多少次，以及被划走多少次。
    pub(crate) toast_shown: Option<ToastShown>,
    pub(crate) toast_picked: u32,
    pub(crate) toast_dismissed: u32,
    /// Whether the glass modal sheet is up, the detent it rests at, and how often it closed.
    /// 玻璃模态面板是否挂起、它停在哪一档，以及被关闭了多少次。
    pub(crate) modal_open: bool,
    pub(crate) modal_detent: Option<Msg>,
    pub(crate) modal_dismissed: u32,
    /// The two glass steppers' values, and how many times they reported a step.
    /// 两个玻璃步进器的值，以及它们上报过多少次步进。
    pub(crate) stepper_value: f64,
    pub(crate) stepper_wrap: f64,
    pub(crate) stepper_presses: u32,
    /// Whether the Fluent content dialog is open; the engine holds the closing one itself.
    /// Fluent 内容对话框是否打开；正在关闭的那个由引擎保活。
    pub(crate) fdlg_open: bool,
    /// The last item picked on the FAB menu page, as (menu, item).
    /// FAB 菜单页最后选中的项，记作（菜单，项）。
    pub(crate) fab_picked: Option<(usize, usize)>,
    /// The Fluent menu's `IsOpen`, and the command it last reported.
    /// Fluent 菜单的 `IsOpen`，以及它最近上报的命令。
    pub(crate) menu_open: bool,
    pub(crate) menu_picked: Option<usize>,
    /// The glass menu's own open flag and the command it last ran.
    /// 玻璃菜单自己的展开标志，以及它最后执行的命令。
    pub(crate) gmenu_open: bool,
    pub(crate) gmenu_picked: Option<usize>,
    /// The glass popover's open flag and how often its own "Done" was pressed.
    /// 玻璃浮出层自己的展开标志，以及它自己的「完成」被按下的次数。
    pub(crate) gpop_open: bool,
    pub(crate) gpop_done: u32,
    /// The Fluent combo box's `IsOpen` and the row it last selected.
    /// Fluent 下拉框的 `IsOpen`，以及它最近选中的行。
    pub(crate) combo_open: bool,
    pub(crate) combo_sel: Option<usize>,
    /// The Fluent navigation view's `IsPaneOpen` and its selected destination.
    /// Fluent 导航视图的 `IsPaneOpen` 与选中的目标。
    pub(crate) nav_open: bool,
    pub(crate) nav_view_sel: usize,
    /// `PaneDisplayMode`: whether an open pane widens in place or covers the content.
    /// `PaneDisplayMode`：展开的窗格是就地撑宽还是盖住内容。
    pub(crate) nav_mode: ui_widgets_fluent::PaneDisplayMode,
    pub(crate) md3: Md3Kit,
    /// The context menu's look, resolved through the kit each frame so a running theme
    /// transition blends it like every other surface.
    /// 右键菜单的外观，每帧经 kit 解析，使正在进行的主题过渡像其他表面一样混色。
    pub(crate) menu_style: ui_widgets::MenuStyle,
    pub(crate) fluent: FluentKit,
    pub(crate) glass: HigKit,
    pub(crate) dragging: Option<usize>,
    /// The materials page: each block's knobs and where the finger left it.
    /// 材质页：每块的旋钮，以及手指把它留在哪儿。
    pub(crate) materials: MaterialState,
    /// The stepped slider's value and the range slider's pair; both are the app's.
    /// 离散滑块的值与范围滑块的两个值；都归应用所有。
    pub(crate) step_value: f32,
    pub(crate) range: (f32, f32),
    pub(crate) frames: u32,
    /// Appearance being blended from during a theme switch; `None` when settled.
    /// 主题切换中正在从哪个外观混起；落定时为 `None`。
    pub(crate) theme_from: Option<bool>,
    /// Force the transition to restart from 0 on the next frame.
    /// 下一帧强制从 0 重新开始过渡。
    pub(crate) theme_snap: bool,
    /// Host light/dark watcher (XDG portal on Wayland).
    /// 宿主明/暗监视器（Wayland 上的 XDG 门户）。
    pub(crate) theme_watch: Option<ui_platform_wayland::PortalThemeWatcher>,
}

/// The Windows hover time before a tooltip opens: `SPI_GETMOUSEHOVERTIME`, 400 ms by default.
/// 提示框展开前的 Windows 悬停时间：`SPI_GETMOUSEHOVERTIME`，默认 400ms。
pub(crate) const TIP_HOVER_DELAY: f32 = 0.4;

/// Seconds this hover episode has run; the id is fresh per episode, so it starts at zero.
/// 本次悬停已走的秒数；id 每次悬停都换新，因此从零开始。
fn tip_age(cx: &mut Cx<'_, '_>, episode: u32) -> f32 {
    let timer = Id::of(("tip-timer", episode));
    cx.at(timer).age(timer)
}

impl Gallery {
    /// Mount a closed panel on hover, open it after the delay, and keep it until its fade ends.
    /// 悬停时挂一块关闭的面板，延时后展开，淡出走完前不卸载。
    fn tick_tips(&mut self, cx: &mut Cx<'_, '_>) {
        let hover = (0..TIPS).find(|k| cx.core().hovered_within(tip_target_id(*k)));
        if hover != self.tip_hover {
            self.tip_hover = hover;
            self.tip_gen = self.tip_gen.wrapping_add(1);
            self.tip_delay = 0.0;
        }
        if let Some(shown) = self.tip_shown {
            if self.tip_hover == Some(shown) {
                if self.tip_delay < TIP_HOVER_DELAY {
                    self.tip_delay = tip_age(cx, self.tip_gen);
                }
                return;
            }
            let now = cx.now();
            let since = *self.tip_close_at.get_or_insert(now);
            if now >= since + ui_widgets_fluent::TOOLTIP_FADE.duration as f64 {
                self.tip_shown = None;
                self.tip_close_at = None;
            }
            return;
        }
        let Some(k) = self.tip_hover else { return };
        // Mount closed at once so the fade has a zero to start from; reading the clock here
        // is what keeps frames coming through the hover delay.
        // 立刻以关闭态挂上，淡入才有零可出发；这里读时钟，延迟期间靠它继续出帧。
        self.tip_shown = Some(k);
        self.tip_delay = tip_age(cx, self.tip_gen);
    }

    /// Whether target `k`'s panel is mounted, and whether it is open or fading out.
    /// 目标 `k` 的面板是否挂载，以及它是展开还是正在淡出。
    pub(crate) fn tip_state(&self, k: usize) -> Option<bool> {
        (self.tip_shown == Some(k))
            .then(|| self.tip_hover == Some(k) && self.tip_delay >= TIP_HOVER_DELAY)
    }

    /// Whether `id` is a nav row, and if so, go there.
    /// `id` 是否是导航行；是则切过去。
    fn navigation(&mut self, id: Id) -> bool {
        if let Some(page) = PAGES
            .iter()
            .copied()
            .find(|p| p.nav_id() == id || p.nav_id().with("label") == id)
        {
            self.page = page;
            return true;
        }
        false
    }

    /// Whether `id` is one of the three switches.
    /// `id` 是否是三个开关之一。
    fn toggle_hit(&self, id: Id) -> bool {
        // The three style columns' toggles plus the four MD3 variant switches on the Switch page.
        // 三个风格列的开关，加上 Switch 页的四个 MD3 变体开关。
        (0..4).any(|k| md3_variant_id(k) == id)
            || PAGES
                .iter()
                .any(|page| STYLES.iter().any(|(tag, _)| switch_id(*page, tag) == id))
    }
    pub(crate) fn new() -> Self {
        use ui_platform::ThemeWatcher as _;
        // Publish the catalog scope before the first frame builds any page.
        // 在第一帧构建任何页面之前，先发布 catalog 作用域。
        init_locale();
        let theme_watch = ui_platform_wayland::PortalThemeWatcher::new();
        // `GALLERY_DARK=0|1` seeds the appearance, so a light-theme screenshot needs no click.
        // `GALLERY_DARK=0|1` 预置外观，浅色截图因此不必先点一下。
        let dark = match std::env::var("GALLERY_DARK").ok().as_deref() {
            Some("0") => false,
            Some("1") => true,
            _ => theme_watch.preference().is_dark(false),
        };
        Self {
            // `GALLERY_PAGE=slider` opens straight on a page, for screenshots of one section.
            // `GALLERY_PAGE=slider` 直接打开某一页，便于截取单节画面。
            page: std::env::var("GALLERY_PAGE")
                .ok()
                .and_then(|want| PAGES.into_iter().find(|p| p.tag() == want))
                .unwrap_or(Page::Switch),
            on: false,
            value: 0.35,
            dark,
            variant_on: [false, true, false, true],
            checked: [
                ui_widgets_md3::CheckState::Off,
                ui_widgets_md3::CheckState::Mixed,
                ui_widgets_md3::CheckState::Off,
                ui_widgets_md3::CheckState::On,
                ui_widgets_md3::CheckState::Off,
                ui_widgets_md3::CheckState::On,
            ],
            fchecked: [
                ui_widgets_fluent::CheckState::Unchecked,
                ui_widgets_fluent::CheckState::Checked,
                ui_widgets_fluent::CheckState::Indeterminate,
            ],
            ftri: ui_widgets_fluent::CheckState::Indeterminate,
            radio_sel: 0,
            fradio_sel: 0,
            tab_sel: [0, 1, 2, 0],
            fluent_tabs: vec![0, 1, 2, 3],
            fluent_tab_sel: 1,
            tip_hover: None,
            tip_gen: 0,
            tip_delay: 0.0,
            tip_shown: None,
            tip_close_at: None,
            info_open: [true; INFO_BARS],
            btn_sel: [true, false],
            fab_open: [true, true, true, false, true],
            fab_picked: None,
            // Open on arrival: the panel is the page's subject, not something to hunt for.
            // 一进来就展开：面板是本页的主角，不该让人去找。
            menu_open: true,
            menu_picked: None,
            // Closed on arrival: two overlays open at once leave only the last with the keys.
            // 一进来收起：同时开两个浮层，只有最后那个拿到键盘。
            gmenu_open: false,
            gmenu_picked: None,
            // Closed on arrival: unlike the menu, the popover's blocks are the point, so the
            // reader opens it and sees them appear.
            // 一进来是收起的：与菜单不同，浮出层的重点就是它的内容块，
            // 由读者展开、看它出现。
            gpop_open: false,
            gpop_done: 0,
            // The open panel is this page's subject too.
            // 展开的面板同样是本页的主角。
            combo_open: true,
            combo_sel: Some(1),
            // Open on arrival: the pane and its labels are the page's subject.
            // 一进来就展开：窗格与标签正是本页的主角。
            nav_open: true,
            nav_view_sel: 0,
            nav_mode: ui_widgets_fluent::PaneDisplayMode::Expanded,
            chip_sel: [true, false],
            chip_glass: [true, false],
            chip_glass_gone: false,
            seg_single: 0,
            seg_multi: [true, false, false],
            seg_glass: 0,
            glass_press: 0,
            nav_sel: 0,
            drawer_sel: 0,
            toolbar_sel: Some(0),
            snack_hits: 0,
            snack_overlay_visible: false,
            card_hits: [0; CARD_CLICKS],
            list_sel: [true, false],
            glass_list_hits: 0,
            icon_filled: true,
            app_bar_scrolled: false,
            app_bar_collapsed: false,
            app_bar_fired: None,
            rail_expanded: false,
            carousel_fired: None,
            dp_value: [None, ui_widgets_md3::Date::new(2026, 10, 20)],
            dp_shown: [date_picker_today(), date_picker_today()],
            dp_view: [ui_widgets_md3::DatePickerView::Days; DATE_PICKERS],
            di_text: String::new(),
            di_action: None,
            tp_hour: ["09".to_string(), "07".to_string()],
            tp_minute: ["30".to_string(), "05".to_string()],
            tp_period: [ui_widgets_md3::Period::Am, ui_widgets_md3::Period::Pm],
            tf_value: Default::default(),
            tf_fluent: String::new(),
            tf_glass: String::new(),
            search_value: String::new(),
            search_acted: None,
            search_open: false,
            search_view_value: String::new(),
            glass_search: String::new(),
            glass_search_acted: None,
            shortcut: None,
            dialog_picked: None,
            dialog_dismissed: 0,
            dialog_open: false,
            dialog_target: ModalTarget::Global,
            sheet_open: false,
            sheet_picked: None,
            sheet_dismissed: 0,
            toast_shown: None,
            toast_picked: 0,
            toast_dismissed: 0,
            modal_open: false,
            modal_detent: None,
            modal_dismissed: 0,
            stepper_value: 3.0,
            stepper_wrap: 4.0,
            stepper_presses: 0,
            fdlg_open: false,
            md3: Md3Kit::new(),
            menu_style: ui_widgets_md3::menu_style(&ui_widgets_md3::pack_of(
                ui_design::Appearance::Light,
            )),
            fluent: FluentKit::new(),
            glass: HigKit::new(),
            dragging: None,
            materials: MaterialState::default(),
            step_value: 0.25,
            range: (0.2, 0.7),
            frames: 0,
            theme_from: None,
            theme_snap: false,
            theme_watch: Some(theme_watch),
        }
    }

    /// Pull any host colour-scheme change into the gallery's own dark flag.
    /// 把宿主的配色变化拉进 gallery 自己的 dark 标志。
    fn sync_system_theme(&mut self) {
        use ui_platform::ThemeWatcher;
        if let Some(watch) = self.theme_watch.as_mut()
            && watch.poll().is_some() {
                let want = watch.preference().is_dark(false);
                if want != self.dark {
                    self.theme_from = Some(self.dark);
                    self.theme_snap = true;
                    self.dark = want;
                }
            }
    }

    /// Advance the transition progress and publish it for `style_env`.
    /// 推进过渡进度，并发布给 `style_env`。
    fn advance_theme(&mut self, info: &mut ui_core::cx::Cx<'_>) -> f32 {
        match self.theme_from {
            None => 1.0,
            Some(_) => {
                let id = Id::str("gallery/theme/t");
                if self.theme_snap {
                    let _ = info.animate(id, 0.0, ui_core::AnimSpec::new(0.0, ui_core::Easing::Linear));
                    self.theme_snap = false;
                }
                let t = info.animate(id, 1.0, ui_core::AnimSpec::new(0.2, ui_core::Easing::EaseOut));
                if t >= 0.999 {
                    self.theme_from = None;
                }
                t
            }
        }
    }
}

impl App for Gallery {
    /// The menu look `view` resolved this frame; the engine copies it before painting.
    /// 本帧 `view` 解析出的菜单外观；引擎在绘制前取走。
    fn menu_style(&self) -> Option<ui_widgets::MenuStyle> {
        Some(self.menu_style.clone())
    }

    fn view(&mut self, info: &mut ui_core::cx::Cx<'_>) -> Box<dyn Element> {
        self.frames += 1;
        // Sync the host appearance, then advance the theme tween before any `style_env` read.
        // 先同步宿主外观，再在读取任何 style_env 前推进主题过渡。
        self.sync_system_theme();
        let theme_t = self.advance_theme(info);
        THEME_FROM.with(|c| c.set(self.theme_from));
        THEME_T.with(|c| c.set(theme_t));
        // The scope is published through thread-locals, so the engine cannot see it move.
        // 作用域经由线程局部变量发布，引擎看不到它变化。
        if self.theme_from.is_some() {
            info.invalidate_decls();
        }
        // The theme env is the outermost layer: everything below inherits its appearance.
        // 主题环境是最外层：其下的一切都继承它的外观。
        set_root_env(theme_env(self.dark));
        // The app no longer owns a store: it builds straight through the context it was
        // handed, which carries the engine's store, clock and routing.
        // app 不再拥有存储：它直接通过被交来的上下文构建，其中带着引擎的存储、时钟与路由。
        let mut cx = Cx::new(info, root_env());
        if self.page == Page::ToolTip {
            self.tick_tips(&mut cx);
        }
        let title = tr(&cx, self.page.title());
        let nav = sidebar(self.page, self.value, &mut cx);
        let mut content = Container::new(Id::str("content"), NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fill(0.0, 0.0),
                grow_x: Grow::Yes,
                grow_y: Grow::Yes,
            })
            .gap(12.0)
            .child(toolbar(&title, &mut cx));
        // Only the visible page is built: constructing a page resolves its styles and
        // widgets eagerly, which costs more than every other phase of the frame together.
        // 只构建可见页：构建一页会即时解析样式与控件，其代价超过一帧里其余阶段的总和。
        let body = timed!("page_body", page_body(self.page, self, &mut cx));
        let wrapper = Container::new(self.page.body_id(), NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fill(0.0, 0.0),
                grow_x: Grow::Yes,
                grow_y: Grow::Yes,
            })
            .child(body);
        content = content.child(Box::new(wrapper));
        // A modal floats over the window, so the root is a box: the shell is its flow child
        // and the modal is an overlay sibling. Nesting it inside the page column would dim
        // that column only and cover the samples it is meant to float above.
        // 模态浮在窗口之上，因此根是盒子：外壳是流内子节点，模态是悬浮兄弟。
        // 放进页面的列里只能压暗那一列，还会盖住它本该浮于其上的样例。
        // The drawer sits flush against the window's left edge; the content area keeps its
        // own inset. Both backgrounds come from the MD3 scheme, so the whole window reads
        // as one surface instead of a hand-picked dark grey.
        // 抽屉贴窗左缘；内容区保留自己的内衬。两处背景都取自 MD3 方案，
        // 整个窗口因此读作同一块表面，而不是手工挑的深灰。
        // The kit's resolution blends through a running theme transition, so the window
        // surface fades instead of snapping between schemes.
        // 经 kit 解析会在主题过渡中混色，窗口表面因此平滑渐变而非在两套方案间硬切。
        let pack = self.md3.pack_for(&cx);
        // The menu is not part of the tree, so it takes the same pack the shell resolved.
        // 菜单不在树里，因此它取外壳解析出的同一个包。
        self.menu_style = ui_widgets_md3::menu_style(&pack);
        let surface = pack.roles.get(ui_style::RoleName("surface")).unwrap_or(Color::from_rgba8(16, 18, 24, 255));
        let shell = Container::new(Id::str("shell"), NodeKind::Row)
            .gap(16.0)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fill(0.0, 0.0),
                grow_x: Grow::Yes,
                grow_y: Grow::Yes,
            })
            .padding(Insets { left: 0.0, right: 16.0, top: 16.0, bottom: 16.0 })
            .child(nav)
            .child(Box::new(content));
        let mut root = Container::new(Id::str("root"), NodeKind::Box)
            .background(surface, Corners::ZERO)
            // The photo sits under the shell; the surface above stays as the letterbox and
            // the fallback when the file is missing.
            // 照片在外壳之下；上面的表面仍是留边色，也是文件缺失时的退路。
            .background_image(crate::wallpaper::WALLPAPER, ImageFit::Cover)
            .size(SizeClass {
                width: AxisSize::fill(0.0, 0.0),
                height: AxisSize::fill(0.0, 0.0),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .child(Box::new(shell));
        if self.dialog_open && self.page == Page::Dialogs && self.dialog_target == ModalTarget::Global {
            root = root.child(dialogs_modal(ModalTarget::Global, &mut cx));
        }
        // The sheet is a modal too, so it lives at the root beside the shell, never inside a column.
        // 面板也是模态，因此与外壳并列放在根上，而不是塞进某一列。
        if self.sheet_open && self.page == Page::ActionSheet {
            root = root.child(sheet_modal(&mut cx));
        }
        if self.modal_open && self.page == Page::ModalSheet {
            root = root.child(modal_sheet_modal(&mut cx));
        }
        // The toast is not modal: it sits above the shell but lets every press through.
        // 提示条不是模态：它盖在外壳之上，但让每次按下都穿过去。
        if let Some(shown) = self.toast_shown
            && self.page == Page::Toast {
                root = root.child(toast_layer(shown, &mut cx));
            }
        // The dialog is declared only while it is open: its entrance and its way out are
        // the control's own declarations, so the app needs no warm-up frame and no clock.
        // 对话框只在打开时被声明：入场与退场都是控件自己的声明，
        // 应用因此不必预热一帧，也不必读时钟。
        if self.page == Page::Dialogs && self.fdlg_open {
            root = root.child(dialogs_fluent::fluent_dialog_modal(&mut cx));
        }
        Box::new(root)
    }



    fn changed(&mut self, on: Id, mut change: ui_widgets::Change) -> bool {
        use ui_widgets::Change as C;
        // Each control reports its own meaning: a row says "activated", a switch says
        // which state it settled on, a slider reports the value under the finger.
        // The nav drawer's offset is engine-owned now: the wheel lands directly in the
        // scroller, and the app no longer accumulates or clamps it.
        // 导航抽屉的偏移现在归引擎管理：滚轮直接落在滚动容器里，
        // 应用不再累计或钳位它。
        // A dialog names the action that was hit, or says its scrim was pressed. Both close
        // it here: the control reports, the app decides what closing means.
        // 对话框上报被点中的动作，或说它的遮罩被按下。两者都在这里关闭它：
        // 控件只上报，关闭意味着什么由应用决定。
        if dialog_is_ours(on) {
            match change {
                C::Selected(Some(picked)) => {
                    self.dialog_picked = dialog_label_of(picked);
                    self.dialog_open = false;
                    return true;
                }
                C::Cancelled => {
                    self.dialog_dismissed += 1;
                    self.dialog_open = false;
                    return true;
                }
                _ => {}
            }
        }
        if on == dialog_open_id() && matches!(change, C::Activated) {
            self.dialog_target = ModalTarget::Global;
            self.dialog_open = true;
            return true;
        }
        // The action sheet reports the action that was hit, or says it was dismissed — the
        // cancel card and a scrim press both arrive as `Cancelled`.
        // 动作面板上报被点中的动作，或说它被关闭——取消卡与遮罩按下都以 `Cancelled` 到达。
        if self.sheet_open && on == sheet_id() {
            match change {
                C::Selected(Some(picked)) => {
                    self.sheet_picked = sheet_label_of(picked);
                    self.sheet_open = false;
                    return true;
                }
                C::Cancelled => {
                    self.sheet_dismissed += 1;
                    self.sheet_open = false;
                    return true;
                }
                _ => {}
            }
        }
        if on == sheet_open_id() && matches!(change, C::Activated) {
            self.sheet_open = true;
            return true;
        }
        // The modal sheet reports the content it pressed, the detent a drag settled on, or
        // its own dismissal — a scrim press, Escape or a drag below the lowest detent.
        // 模态面板上报被按下的内容、拖拽落定的档位，或它自身的关闭——遮罩按下、Escape，
        // 或拖到最低档之下。
        if self.modal_open && on == modal_sheet_id() {
            match change {
                C::Selected(Some(picked)) if picked == modal_sheet_done_id() => {
                    self.modal_open = false;
                    return true;
                }
                C::Selected(Some(picked)) if picked == detent_id_of(modal_sheet_id(), GlassSheetDetent::Half) => {
                    self.modal_detent = Some(Msg::GALLERY_MODAL_SHEET_HALF);
                    return true;
                }
                C::Selected(Some(picked)) if picked == detent_id_of(modal_sheet_id(), GlassSheetDetent::Full) => {
                    self.modal_detent = Some(Msg::GALLERY_MODAL_SHEET_FULL);
                    return true;
                }
                C::Dismissed => {
                    self.modal_dismissed += 1;
                    self.modal_open = false;
                    return true;
                }
                _ => {}
            }
        }
        // A stepper reports the value it stepped to; where it stops is the app's call.
        // 步进器上报它走到的值；停在哪里由应用决定。
        if on == stepper_id() || on == stepper_wrap_id() {
            if let C::Value(v) = change {
                if on == stepper_id() {
                    self.stepper_value = v;
                } else {
                    self.stepper_wrap = v;
                }
                self.stepper_presses += 1;
                return true;
            }
            return false;
        }
        if on == modal_sheet_open_id() && matches!(change, C::Activated) {
            self.modal_open = true;
            self.modal_detent = Some(Msg::GALLERY_MODAL_SHEET_HALF);
            return true;
        }
        // A toast reports the action it offered, or says it was swiped away. The app owns
        // how long it lives; the control never closes itself.
        // 提示条上报它提供的动作，或说它被划走。存活多久归应用；控件从不自行关闭。
        if on == toast_show_id() && matches!(change, C::Activated) {
            self.toast_shown = Some(ToastShown::Success);
            return true;
        }
        if on == toast_error_id() && matches!(change, C::Activated) {
            self.toast_shown = Some(ToastShown::ErrorTop);
            return true;
        }
        if self.toast_shown.is_some() && on == toast_id() {
            match change {
                C::Selected(Some(picked)) if picked == toast_action_id() => {
                    self.toast_picked += 1;
                    self.toast_shown = None;
                    return true;
                }
                C::Cancelled => {
                    self.toast_dismissed += 1;
                    self.toast_shown = None;
                    return true;
                }
                _ => {}
            }
        }
        // The Fluent dialog reports the action that was hit; a preview reports too, and only
        // the modal closes. The control never decides its own lifetime.
        // Fluent 对话框上报被点中的动作；预览也上报，但只有模态会关闭。生命周期由应用决定。
        if dialogs_fluent::fluent_dialog_is_ours(on)
            && let C::Selected(Some(picked)) = change {
                self.dialog_picked = dialogs_fluent::fluent_dialog_label_of(picked);
                if on == dialogs_fluent::fluent_dialog_id() {
                    self.fdlg_open = false;
                }
                return true;
            }
        // The glass alerts are previews: they report their action and the app records it.
        // 玻璃警告框都是预览：它们上报动作，由应用记下来。
        if dialogs::glass_dialog_is_ours(on)
            && let C::Selected(Some(picked)) = change {
                self.dialog_picked = dialogs::glass_dialog_label_of(picked);
                return true;
            }
        if on == dialogs_fluent::fluent_dialog_open_id() && matches!(change, C::Activated) {
            self.fdlg_open = true;
            return true;
        }
        // The Fluent strip: a header names itself when picked, its close button sends a
        // payload, and the add button is a plain activation.
        // Fluent 页签带：页头被选中时上报自己，关闭按钮带载荷，新建按钮是普通激活。
        if let Some(k) = self
            .fluent_tabs
            .iter()
            .position(|slot| fluent_tab_id(*slot) == on)
        {
            if matches!(&change, C::Selected(Some(_))) {
                self.fluent_tab_sel = self.fluent_tabs[k];
                return true;
            }
            // A dragged header takes the slot it was released into; the app owns the order.
            // 被拖拽的页头占据松手时的槽位；顺序归应用所有。
            if let C::Data(payload) = &change
                && let Some(ui_widgets_fluent::TabViewChange::Dropped { from, to }) =
                    payload.downcast_ref::<ui_widgets_fluent::TabViewChange>()
                    && *from < self.fluent_tabs.len() && *to < self.fluent_tabs.len() {
                        let moved = self.fluent_tabs.remove(*from);
                        self.fluent_tabs.insert(*to, moved);
                        return true;
                    }
            if matches!(
                &change,
                C::Data(payload)
                    if payload.downcast_ref::<ui_widgets_fluent::TabViewChange>()
                        == Some(&ui_widgets_fluent::TabViewChange::Closed)
            ) {
                let closed = self.fluent_tabs.remove(k);
                if self.fluent_tab_sel == closed {
                    self.fluent_tab_sel = self
                        .fluent_tabs
                        .get(k)
                        .or_else(|| self.fluent_tabs.last())
                        .copied()
                        .unwrap_or(0);
                }
                return true;
            }
        }
        if on == fluent_tab_add_id() && matches!(change, C::Activated) {
            if let Some(slot) = (0..TAB_MANY.len()).find(|s| !self.fluent_tabs.contains(s)) {
                self.fluent_tabs.push(slot);
                self.fluent_tab_sel = slot;
            }
            return true;
        }
        if on == dialog_open_panel_id() && matches!(change, C::Activated) {
            self.dialog_target = ModalTarget::Proximate;
            self.dialog_open = true;
            return true;
        }
        // An info bar reports a close; collapsing it is the app's decision, and the reset
        // button is the way back.
        // 信息栏只上报关闭；收起由应用决定，恢复靠重置按钮。
        if let Some(k) = (0..INFO_BARS).position(|k| info_bar_id(k) == on)
            && matches!(change, C::Activated) {
                self.info_open[k] = false;
                return true;
            }
        if on == info_bar_reset_id() && matches!(change, C::Activated) {
            self.info_open = [true; INFO_BARS];
            return true;
        }
        // A date picker reports one fact per click: a day chosen, a month moved, a view
        // switched. What each means for the page is the app's call.
        // 日期选择器每次点击上报一个事实：选中的日期、移动的月份、切换的视图。
        // 它们对页面意味着什么由应用决定。
        if let Some(k) = (0..DATE_PICKERS).find(|k| date_picker_id(*k) == on) {
            // A mismatched payload comes back unchanged, so the branches below still see it.
            // 类型不符时原样退回，下面的分支仍能看到它。
            change = match change.data::<ui_widgets_md3::DatePickerChange>() {
                Ok(fact) => {
                    match fact {
                        ui_widgets_md3::DatePickerChange::Picked(date) => self.dp_value[k] = Some(date),
                        ui_widgets_md3::DatePickerChange::Shown { date, view } => {
                            self.dp_shown[k] = date;
                            self.dp_view[k] = view;
                        }
                        ui_widgets_md3::DatePickerChange::View(view) => self.dp_view[k] = view,
                    }
                    return true;
                }
                Err(other) => other,
            };
        }
        // The text-mode date input reports one action per click; its buffer is an engine text
        // input on the field's own id, so edits arrive as `Change::Text` beside it.
        // 文本模式的日期输入每次点击上报一个动作；它的缓冲是字段自身 id 上的引擎文本输入，
        // 因此编辑以 `Change::Text` 另行送达。
        if on == date_input_id() {
            change = match change.data::<ui_widgets_md3::DateInputChange>() {
                Ok(fact) => {
                    self.di_action = Some(fact.0);
                    return true;
                }
                Err(other) => other,
            };
        }
        if on == ui_widgets_md3::date_input_field_id(date_input_id())
            && let C::Text(next) = &change
        {
            self.di_text = next.clone();
            return true;
        }
        // A time input's fields are the engine's text inputs: edits arrive as `Change::Text`
        // on the field's own id, and the widget reports only what the engine cannot.
        // 时间输入的格子就是引擎的文本输入：编辑以 `Change::Text` 落在格子自己的 id 上，
        // 控件只上报引擎做不到的那些。
        if let Some(k) = (0..TIME_PICKERS).find(|k| {
            let picker = time_picker_id(*k);
            on == picker || on == picker.with("hour") || on == picker.with("minute")
        }) {
            if let C::Text(next) = &change {
                if on == time_picker_id(k).with("hour") {
                    self.tp_hour[k] = next.clone();
                } else {
                    self.tp_minute[k] = next.clone();
                }
                return true;
            }
            change = match change.data::<ui_widgets_md3::TimePickerChange>() {
                Ok(fact) => {
                    match fact {
                        ui_widgets_md3::TimePickerChange::Hour(text) => {
                            self.tp_hour[k] = text;
                        }
                        ui_widgets_md3::TimePickerChange::Minute(text) => {
                            self.tp_minute[k] = text;
                        }
                        ui_widgets_md3::TimePickerChange::Period(period) => {
                            self.tp_period[k] = period;
                        }
                    }
                    return true;
                }
                Err(other) => other,
            };
        }
        // An app bar reports the slot that was pressed; what that means is the app's call.
        // 应用栏上报被按下的槽位；它意味着什么由应用决定。
        if app_bar_is_ours(on)
            && let C::Selected(Some(slot)) = change
                && let Some(name) = app_bar_slot_name(slot) {
                    self.app_bar_fired = Some(name);
                    return true;
                }
        if on == app_bar_scroll_id() && matches!(change, C::Activated) {
            self.app_bar_scrolled = !self.app_bar_scrolled;
            return true;
        }
        if on == app_bar_collapse_id() && matches!(change, C::Activated) {
            self.app_bar_collapsed = !self.app_bar_collapsed;
            return true;
        }
        if on == rail_expand_id() && matches!(change, C::Activated) {
            self.rail_expanded = !self.rail_expanded;
            return true;
        }
        // A text field reports the whole buffer after an edit; the app keeps it and
        // re-declares it next frame.
        // 文本字段在编辑后上报完整缓冲；应用保存它，并在下一帧重新声明。
        if let C::Text(next) = &change {
            if let Some(k) = (0..TF_LIVE).find(|k| text_field_id(*k) == on) {
                self.tf_value[k] = next.clone();
                return true;
            }
            if on == fluent_text_field_id() {
                self.tf_fluent = next.clone();
                return true;
            }
            if on == glass_text_field_id() {
                self.tf_glass = next.clone();
                return true;
            }
        }
        // The WinUI text box names its clear button by that button's own id.
        // WinUI 文本框用它自己的 id 指认清除按钮。
        if on == fluent_text_field_id()
            && matches!(change, C::Selected(Some(id)) if id == on.with("clear"))
        {
            self.tf_fluent.clear();
            return true;
        }
        if on == text_field_clear_id() && matches!(change, C::Activated) {
            self.tf_value = Default::default();
            return true;
        }
        // A search bar edits its query through the engine and reports its own actions.
        // 搜索栏经引擎编辑查询，并上报它自己的动作。
        if on == search_id() {
            if let C::Text(next) = &change {
                self.search_value = next.clone();
                return true;
            }
            change = match change.data::<ui_widgets_md3::SearchBarChange>() {
                Ok(ui_widgets_md3::SearchBarChange::Action(id)) => {
                    self.search_acted = Some(if id == search_action_id() {
                        "mic".to_string()
                    } else {
                        format!("{id:?}")
                    });
                    return true;
                }
                Err(other) => other,
            };
        }
        // The search view opens on its own request and closes on its back action; the app
        // owns both ends, so neither happens without this branch.
        // 搜索视图自行请求展开、由返回动作收起；两端都归应用所有，缺了这一支就都不会发生。
        if on == search_view_id() {
            if let C::Text(next) = &change {
                self.search_view_value = next.clone();
                return true;
            }
            match change.data::<ui_widgets_md3::SearchViewChange>() {
                Ok(ui_widgets_md3::SearchViewChange::Activated) => {
                    self.search_open = true;
                    return true;
                }
                Ok(ui_widgets_md3::SearchViewChange::Action(_)) => {
                    self.search_open = false;
                    return true;
                }
                Err(other) => change = other,
            }
        }
        // The glass bar edits through its field and names the button that was pressed.
        // 玻璃栏经它的字段编辑，并指认被按下的按钮。
        if on == glass_search_id().with("field")
            && let C::Text(next) = &change {
                self.glass_search = next.clone();
                return true;
            }
        if on == glass_search_id()
            && let C::Selected(Some(id)) = &change {
                if *id == glass_search_id().with("field").with("trailing") {
                    self.glass_search.clear();
                    self.glass_search_acted = Some("clear".to_string());
                    return true;
                }
                if *id == glass_search_id().with("cancel") {
                    self.glass_search.clear();
                    self.glass_search_acted = Some("cancel".to_string());
                    return true;
                }
            }
        // A capturing node reports the chord it saw; the app decides what to bind.
        // 捕获按键的节点上报它看到的组合键；绑定什么由应用决定。
        if let C::KeyChord(chord) = &change
            && on == shortcut_field_id() {
                self.shortcut = Some(*chord);
                return true;
            }
        // A context-menu row the app declared reports its own id.
        // 应用声明的上下文菜单行上报它自己的 id。
        if let C::MenuItem(item) = &change
            && *item == Id::str("tf/menu/clear") {
                self.tf_value[0].clear();
                return true;
            }
        // The materials page owns each block's knobs and each block's place on the stage.
        // 材质页拥有每块的旋钮，以及每块在舞台上的位置。
        if let Some(knob) = glass_knob_of(on) {
            if let C::Value(v) = change {
                self.materials.set_glass(knob, v as f32);
                return true;
            }
            return false;
        }
        if let Some((k, param)) = material_param_of(on) {
            if let C::Value(v) = change {
                self.materials.set(k, param, v as f32);
                return true;
            }
            return false;
        }
        if let Some(k) = material_block_of(on) {
            match change {
                C::DragStarted => {
                    drag_block(&mut self.materials, k, true, 0.0, 0.0);
                    return true;
                }
                C::Moved { dx, dy } => {
                    drag_block(&mut self.materials, k, false, dx as f32, dy as f32);
                    return true;
                }
                C::Dropped(_) | C::Cancelled => {
                    end_drag(&mut self.materials, k);
                    return true;
                }
                _ => {}
            }
        }
        // A carousel reports the item that was pressed; its strip scrolls itself.
        // 轮播上报被按下的条目；条带自己滚动。
        if let C::Selected(Some(item)) = change
            && let Some((k, j)) = carousel_item_of(item) {
                self.carousel_fired = Some((k, j));
                return true;
            }
        match change {
            C::Activated if self.navigation(on) => return true,
            // A button says only that it was activated; a toggle's state is the app's.
            // 按钮只报告「被激活」；切换态归应用所有。
            C::Activated => {
                // The snackbar reports from its root; only its action carries a click sense.
                // 提示条以根节点上报；只有它的动作带点击语义。
                if snack_pick(on).is_some() {
                    self.snack_hits += 1;
                    return true;
                }
                // The mode buttons pick how much of the pane stays on screen; the pane
                // itself starts in the state that mode is about.
                // 模式按钮选择窗格常驻多少；窗格本身从该模式所讲的状态开始。
                if let Some(k) = (0..NAV_MODES.len()).find(|k| nav_mode_id(*k) == on) {
                    self.nav_mode = NAV_MODES[k];
                    self.nav_open = self.nav_mode == ui_widgets_fluent::PaneDisplayMode::Expanded;
                    return true;
                }
                if on == snack_overlay_show_id() {
                    self.snack_overlay_visible = !self.snack_overlay_visible;
                    return true;
                }
                // The group buttons write the whole column, which is how a mixed box is
                // reached at all: clicking one only ever settles it to checked.
                // 组按钮整列写入，这是抵达不确定态的唯一途径：点击单个方框只会落定为选中。
                for (tag, _) in CHECKBOX_GROUP {
                    if on == checkbox_group_id(tag) {
                        let value = match tag {
                            "off" => ui_widgets_md3::CheckState::Off,
                            "mixed" => ui_widgets_md3::CheckState::Mixed,
                            _ => ui_widgets_md3::CheckState::On,
                        };
                        self.checked = [value; CHECKBOXES];
                        return true;
                    }
                }
                if let Some(k) = (0..BTN_TOGGLES).find(|k| btn_toggle_id(*k) == on) {
                    self.btn_sel[k] = !self.btn_sel[k];
                    return true;
                }
                // A glass filter chip toggles itself; the app stores the new state.
                // 玻璃筛选芯片自己翻转；应用保存新状态。
                if let Some(k) = (0..CHIP_GLASS_FILTERS).find(|k| chip_glass_id(*k) == on) {
                    self.chip_glass[k] = !self.chip_glass[k];
                    return true;
                }
                // A glass button reports only that it was pressed; the count is the app's.
                // 玻璃按钮只报告被按下；计数归应用所有。
                let glass = (0..GLASS_ICON_BTNS)
                    .find(|k| glass_btn_id(*k) == on)
                    .or_else(|| (0..GLASS_LABEL_BTNS).find(|k| glass_label_btn_id(*k) == on));
                if glass.is_some() {
                    self.glass_press += 1;
                    return true;
                }
                // A FAB menu's anchor opens and closes it. The control reports from its root,
                // so the root is what to match; the close button's id never arrives here.
                // FAB 菜单的锚点开合菜单。控件以根节点上报，因此要匹配根；
                // 关闭按钮的 id 不会送到这里。
                if let Some(k) = (0..FAB_MENUS).find(|k| fab_menu_id(*k) == on) {
                    self.fab_open[k] = !self.fab_open[k];
                    return true;
                }
                // The Fluent menu's anchor opens and closes it, as `MenuFlyout.ShowAt` does.
                // Fluent 菜单的锚点开合它，与 `MenuFlyout.ShowAt` 一致。
                if on == menu_anchor_id() {
                    self.menu_open = !self.menu_open;
                    return true;
                }
                if on == glass_menu_anchor_id() {
                    self.gmenu_open = !self.gmenu_open;
                    return true;
                }
                if on == glass_popover_anchor_id() {
                    self.gpop_open = !self.gpop_open;
                    return true;
                }
                // A combo box's field says only that it was pressed; opening is the app's call.
                // 下拉框的字段只报告被按下；是否展开由应用决定。
                if on == combo_id() {
                    self.combo_open = !self.combo_open;
                    return true;
                }
                // A card says only that it was activated; the count is the app's.
                // 卡片只报告「被激活」；计数归应用所有。
                if let Some(k) = (0..CARD_CLICKS).find(|k| card_id(CARD_VARIANTS[*k]) == on) {
                    self.card_hits[k] += 1;
                    return true;
                }
                // A list row says only that it was activated; whether that selects it is the app's.
                // 列表行只报告「被激活」；是否因此选中由应用决定。
                if let Some(k) = (0..LIST_SELECT).find(|k| list_id("selection", k + 1) == on) {
                    self.list_sel[k] = !self.list_sel[k];
                    return true;
                }
                // A glass row says only that it was activated; the count is the app's.
                // 玻璃行只报告被激活；计数归应用所有。
                if ["wifi", "airplane", "dnd", "standalone"]
                    .iter()
                    .any(|tag| glass_tile_id(tag) == on)
                {
                    self.glass_list_hits += 1;
                    return true;
                }
                // The animated icon says only that it was activated; the target is the app's.
                // 动画图标只报告「被激活」；目标值归应用所有。
                if on == icon_toggle_id() {
                    self.icon_filled = !self.icon_filled;
                    return true;
                }
            }
            // A variant toggle carries its own on-value; the shared page toggle carries `on`.
            // 变体开关自带其 on 值；共享的页面开关用 `on`。
            // A radio only ever says "this one"; the group stores the choice.
            // 单选框只会说「这一个」；由整组保存选择。
            C::Selected(Some(picked)) => {
                // A popover reports the content id it saw pressed; the app owns what follows.
                // 浮出层上报它看到被按下的内容 id；随后做什么归应用所有。
                if on == glass_popover_id() && picked == glass_popover_done_id() {
                    self.gpop_done += 1;
                    self.gpop_open = false;
                    return true;
                }
                // A glass chip's delete glyph names itself; the app drops the chip.
                // 玻璃芯片的删除字形点名自己；应用据此移除该芯片。
                if picked == chip_glass_removable_id().with("delete") {
                    self.chip_glass_gone = true;
                    return true;
                }
                // The app bar's trailing action flips the whole gallery's appearance.
                // 应用栏的尾部动作翻转整个 gallery 的外观。
                if picked == Id::str("toolbar/appearance") {
                    self.dark = !self.dark;
                    self.theme_from = Some(!self.dark);
                    self.theme_snap = true;
                    return true;
                }
                // A nav drawer names the destination it was pressed on; a bare container
                // would not report which row the press landed in.
                // 导航抽屉上报被按到的目标；裸容器不会告诉应用按下落在哪一行。
                if self.navigation(picked) {
                    return true;
                }
                // A segment reports only itself; single-select replaces, multi-select flips.
                // 分段只上报自己；单选替换、多选翻转。
                if let Some(k) = (0..SEGMENTS).find(|k| seg_single_id(*k) == picked) {
                    self.seg_single = k;
                    return true;
                }
                if let Some(k) = (0..SEGMENTS).find(|k| seg_multi_id(*k) == picked) {
                    self.seg_multi[k] = !self.seg_multi[k];
                    return true;
                }
                if let Some(k) = (0..SEGMENTS).find(|k| seg_glass_id(*k) == picked) {
                    self.seg_glass = k;
                    return true;
                }
                if let Some(k) = (0..SEGMENTS).find(|k| seg_glass_icon_id(*k) == picked) {
                    self.seg_glass = k;
                    return true;
                }
                if let Some(k) = nav_pick(picked) {
                    self.nav_sel = k;
                    return true;
                }
                if let Some(k) = drawer_pick(picked) {
                    self.drawer_sel = k;
                    return true;
                }
                if let Some(k) = toolbar_pick(picked) {
                    self.toolbar_sel = Some(k);
                    return true;
                }
                if let Some(k) = (0..RADIOS).find(|k| radio_id(*k) == picked) {
                    self.radio_sel = k;
                    return true;
                }
                if let Some(k) = (0..RADIOS).find(|k| fluent_radio_id(*k) == picked) {
                    self.fradio_sel = k;
                    return true;
                }
                // The Fluent menu names the command it ran; a menu always closes on a pick.
                // Fluent 菜单上报它执行的命令；选中即收起，与参考实现一致。
                if let Some(j) = (0..MENU_COMMANDS).find(|j| menu_item_id(*j) == picked) {
                    self.menu_picked = Some(j);
                    self.menu_open = false;
                    return true;
                }
                if let Some(j) = (0..MENU_COMMANDS).find(|j| glass_menu_item_id(*j) == picked) {
                    self.gmenu_picked = Some(j);
                    self.gmenu_open = false;
                    return true;
                }
                // A combo box names the row it took; selecting it closes the panel.
                // 下拉框上报它选中的行；选中即收起面板。
                if let Some(j) = (0..COMBO_ITEMS).find(|j| combo_item_id(*j) == picked) {
                    self.combo_sel = Some(j);
                    self.combo_open = false;
                    return true;
                }
                // A navigation view names the destination it took; the app owns the page.
                // 导航视图上报它选中的目标；页面归应用所有。
                if let Some(k) = (0..NAV_VIEW_ITEMS).find(|k| nav_view_item_id(*k) == picked) {
                    self.nav_view_sel = k;
                    // An overlay pane has served its purpose once it navigated somewhere.
                    // 浮层窗格导航完成即功成身退。
                    if self.nav_mode != ui_widgets_fluent::PaneDisplayMode::Expanded {
                        self.nav_open = false;
                    }
                    return true;
                }
                // A FAB menu names the item it picked and closes itself.
                // FAB 菜单上报它选中的项，并自行收起。
                for k in 0..FAB_MENUS {
                    if let Some(j) = (0..FAB_ITEMS).find(|j| fab_item_id(k, *j) == picked) {
                        self.fab_picked = Some((k, j));
                        self.fab_open[k] = false;
                        return true;
                    }
                }
                // A tab bar names the tab it picked; the app keeps the choice.
                // 页签栏上报它选中的页签；选择由应用保存。
                for bar in 0..TAB_BARS {
                    if let Some(k) = (0..TAB_COUNT[bar]).find(|k| tab_item_id(bar, *k) == picked) {
                        self.tab_sel[bar] = k;
                        return true;
                    }
                }
            }
            C::Toggled { on: settled } => {
                // A filter chip toggles itself; the app stores the new state.
                // 筛选芯片自己翻转；应用保存新状态。
                if let Some(k) = (0..CHIP_FILTERS).find(|k| chip_filter_id(*k) == on) {
                    self.chip_sel[k] = settled == Some(true);
                    return true;
                }
                // The navigation view's toggle reports the state the pane would settle into.
                // 导航视图的开关上报窗格将落定的状态。
                if on == nav_view_id() {
                    self.nav_open = settled == Some(true);
                    return true;
                }
                if let Some(k) = (0..3).find(|k| fluent_checkbox_id(*k) == on) {
                    self.fchecked[k] = match settled {
                        Some(true) => ui_widgets_fluent::CheckState::Checked,
                        Some(false) => ui_widgets_fluent::CheckState::Unchecked,
                        None => ui_widgets_fluent::CheckState::Indeterminate,
                    };
                    return true;
                }
                if on == fluent_checkbox_id(4) {
                    self.ftri = match settled {
                        Some(true) => ui_widgets_fluent::CheckState::Checked,
                        Some(false) => ui_widgets_fluent::CheckState::Unchecked,
                        None => ui_widgets_fluent::CheckState::Indeterminate,
                    };
                    return true;
                }
                if let Some(k) = (0..CHECKBOXES).find(|k| checkbox_id(*k) == on) {
                    // The control names the value it should take, indeterminate included.
                    // 控件报出它应取的值，不确定态也在内。
                    self.checked[k] = match settled {
                        Some(true) => ui_widgets_md3::CheckState::On,
                        Some(false) => ui_widgets_md3::CheckState::Off,
                        None => ui_widgets_md3::CheckState::Mixed,
                    };
                    return true;
                }
                if let Some(k) = (0..4).find(|k| md3_variant_id(*k) == on) {
                    self.variant_on[k] = settled == Some(true);
                    return true;
                }
                if self.toggle_hit(on) {
                    self.on = settled == Some(true);
                    return true;
                }
            }
            // A press outside the panel or Escape reached it; the app owns what closing means.
            // 面板外的按下或 Escape 传到了面板；关闭意味着什么由应用决定。
            C::Dismissed => {
                if on == menu_flyout_id() {
                    self.menu_open = false;
                    return true;
                }
                if on == glass_menu_id() {
                    self.gmenu_open = false;
                    return true;
                }
                if on == glass_popover_id() {
                    self.gpop_open = false;
                    return true;
                }
                if on == combo_id() {
                    self.combo_open = false;
                    return true;
                }
                // An overlay pane closes on a press outside it, or on Escape.
                // 浮层窗格在外部按下或 Escape 时收起。
                if on == nav_view_id() {
                    self.nav_open = false;
                    return true;
                }
            }
            _ => {}
        }
        // A range slider reports both values in one compound change; the single slider
        // reports the number it settled on.
        // 范围滑块用一次复合变更上报两个值；单手柄滑块上报它落定的那个数。
        if on == slider_step_id() {
            if let C::Value(v) = change {
                self.step_value = (v as f32).clamp(0.0, 1.0);
                return true;
            }
            return false;
        }
        if on == slider_range_id() || on == slider_range_step_id() {
            return match change.data::<ui_widgets_md3::Md3Range>() {
                Ok(r) => {
                    self.range = (r.start, r.end);
                    true
                }
                Err(_) => false,
            };
        }
        let Some(index) = slider_column_of(on) else {
            return false;
        };
        match change {
            // The control mapped the press point to a value itself; nothing to compute here.
            // 控件已自行把按下点映射成值，这里无需任何计算。
            C::Value(v) => {
                self.value = (v as f32).clamp(0.0, 1.0);
                self.dragging = Some(index);
            }
            C::DragStarted => self.dragging = Some(index),
            C::Selected(_) | C::Cancelled => self.dragging = None,
            _ => return false,
        }
        true
    }
}
