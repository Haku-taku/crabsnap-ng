//! The window's wallpaper: one photo behind the shell, so the cards and the glass have
//! something to sit on instead of a flat surface.
//! 窗口的壁纸：外壳背后的一张照片，卡片与玻璃因此有东西可坐，而不是一块平涂。

use ui_core::draw::ImageEntry;
use ui_platform::view::AppLoop;

use crate::app::Gallery;

/// The texture id the root refers to; stable for the run, so the renderer caches one upload.
/// 根节点引用的纹理标识；整次运行不变，渲染器因此只上传一次。
pub const WALLPAPER: u64 = 0x7761_6c6c_7061_7065;

/// The file this machine's gallery is tuned against; `GALLERY_WALLPAPER` overrides it.
/// 本机画廊所用的那张图；`GALLERY_WALLPAPER` 可以覆盖它。
const DEFAULT_PATH: &str = "/home/ollie/Pictures/Wallpapers/140959926_p0.png";

/// Register the wallpaper. A missing or undecodable file leaves the window's flat surface,
/// because the gallery must still run on a machine that does not have this photo.
/// 登记壁纸。文件缺失或解不开时窗口保留平涂表面，因为换一台没有这张照片的机器，画廊仍要能跑。
pub fn install(lp: &mut AppLoop<Gallery>) {
    let path = std::env::var("GALLERY_WALLPAPER").unwrap_or_else(|_| DEFAULT_PATH.to_string());
    match decode(&path) {
        Some(entry) => lp.register_image(entry),
        None => eprintln!("wallpaper: {path} could not be read; the window keeps its flat surface"),
    }
}

/// Straight-alpha RGBA8, which is what `ImageEntry` carries and what the shader samples.
/// 直通 alpha 的 RGBA8，正是 `ImageEntry` 携带、着色器采样的格式。
fn decode(path: &str) -> Option<ImageEntry> {
    let image = image::open(path).ok()?.to_rgba8();
    let (width, height) = image.dimensions();
    Some(ImageEntry {
        id: WALLPAPER,
        width,
        height,
        data: std::sync::Arc::new(image.into_raw()),
    })
}
