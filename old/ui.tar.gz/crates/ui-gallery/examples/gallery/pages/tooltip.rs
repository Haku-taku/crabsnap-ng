// The tooltip page.
// 提示框页。

use ui_core::layout::Anchor;

use crate::app::Gallery;
use crate::shell::*;

/// Hover targets on this page; the k-th names its button and its tooltip text below.
/// 本页的悬停目标；第 k 个的按钮文字与提示文本见下表。
pub(crate) const TIPS: usize = 3;

pub(crate) const TIP_LABEL: [Msg; TIPS] = [
    Msg::GALLERY_TOOLTIP_BTN_SAVE,
    Msg::GALLERY_TOOLTIP_BTN_DELETE,
    Msg::GALLERY_TOOLTIP_BTN_LONG,
];

pub(crate) const TIP_TEXT: [Msg; TIPS] = [
    Msg::GALLERY_TOOLTIP_SAVE,
    Msg::GALLERY_TOOLTIP_DELETE,
    Msg::GALLERY_TOOLTIP_LONG,
];

pub(crate) fn tip_target_id(k: usize) -> Id {
    Id::of(("tip-target", k))
}

pub(crate) fn tip_panel_id(k: usize) -> Id {
    Id::of(("tip-panel", k))
}

/// Fluent tooltips on three buttons: the panel opens above each one after the hover delay.
/// 三个按钮上的 Fluent 提示框：悬停延时后，面板在每个按钮上方展开。
pub(crate) fn tooltip_page(g: &Gallery, cx: &mut Cx<'_, '_>) -> Box<dyn Element> {
    let mut body = Container::new(Id::of(("body", "fluent")), NodeKind::Column).gap(12.0);
    body = body.child_decl(label(
        Id::of(("tips", "caption")),
        tr(cx, Msg::GALLERY_TOOLTIP_CAPTION),
        12.0,
        muted(),
        700.0,
    ));
    body = body.child_decl(label(
        Id::of(("tips", "delay")),
        tr(cx, Msg::GALLERY_TOOLTIP_DELAY),
        12.0,
        muted(),
        700.0,
    ));
    let mut line = Container::new(Id::of(("tips", "row")), NodeKind::Row).gap(8.0);
    for k in 0..TIPS {
        let mut scoped = cx.at_scope(style_env("fluent"));
        let label = tr(&scoped, TIP_LABEL[k]);
        let params = ui_widgets_fluent::ButtonParams::new(tip_target_id(k), label);
        let control = g.fluent.button(params, &mut scoped);
        line = line.child(scoped.element(control));
        // The panel lives beside the buttons, not inside them: an overlay is deferred and
        // anchored, so it escapes the card instead of being clipped by it.
        // 面板放在按钮旁边而非按钮内部：悬浮节点会被延后并按锚点摆放，
        // 因此它逃出卡片而不是被卡片裁掉。
        if let Some(open) = g.tip_state(k) {
            let text = tr(&scoped, TIP_TEXT[k]);
            let params = ui_widgets_fluent::ToolTipParams::new(
                tip_panel_id(k),
                &text,
                Anchor::Node(tip_target_id(k)),
            )
            .open(open);
            let control = g.fluent.tool_tip(params, &mut scoped);
            body = body.child(scoped.element(control));
        }
    }
    // A coloured stage behind the buttons: acrylic over a flat card shows only its tint,
    // and the blur it adds needs something with structure underneath.
    // 按钮后面放一块有色台面：在纯色卡片上，丙烯酸只剩着色可看，模糊需要下方有结构。
    let stage = Container::from_decl(
        Decl::container(Id::of(("tips", "stage")), NodeKind::Box)
            .size(SizeClass::fixed(700.0, 120.0))
            .corners(Corners::all(12.0))
            .background(Color::from_rgba8(24, 54, 110, 255), Corners::all(12.0))
            .gradient(
                Color::from_rgba8(24, 54, 110, 255),
                Color::from_rgba8(16, 22, 46, 255),
                GradientAxis::Vertical,
            )
            .padding(Insets::all(20.0)),
    )
    .child(Box::new(line));
    body = body.child(Box::new(stage));
    let mut row = Container::new(Id::of(("bodyrow", Page::ToolTip.tag())), NodeKind::Row)
        .size(SizeClass {
            width: AxisSize::fill(0.0, 0.0),
            height: AxisSize::fill(0.0, 0.0),
            grow_x: Grow::Yes,
            grow_y: Grow::Yes,
        })
        .gap(20.0);
    row = row.child(column_w(
        Page::ToolTip,
        "fluent",
        Msg::GALLERY_STYLE_FLUENT,
        Box::new(body),
        760.0,
        COL_CTRL_H,
        cx,
    ));
    Box::new(row)
}
