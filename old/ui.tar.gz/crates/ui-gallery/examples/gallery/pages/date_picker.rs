// The date picker page.
// 日期选择页。

use crate::shell::*;

/// How many pickers the page drives; each keeps its own app-owned facts.
/// 本页驱动几块选择器；各存各的、归应用所有的事实。
pub(crate) const DATE_PICKERS: usize = 2;

pub(crate) fn date_picker_id(k: usize) -> Id {
    Id::of(("date-picker", k))
}

/// The text-mode sample: one input, one buffer, one action per click.
/// 文本模式的样本：一个输入、一个缓冲、每次点击一个动作。
pub(crate) fn date_input_id() -> Id {
    Id::str("date-input/sample")
}

/// The demo's "today": a calendar must be told which day it is, and the gallery has no clock.
/// 演示用的「今天」：日历必须被告知今天是哪一天，而画廊没有时钟。
pub(crate) fn date_picker_today() -> ui_widgets_md3::Date {
    ui_widgets_md3::Date::new(2026, 10, 30).expect("a real date")
}

/// A date written out for the readout, in the labels the calendar itself uses.
/// 供读数使用的日期写法，用的就是日历自己的月份名。
pub(crate) fn date_text(cx: &Cx<'_, '_>, date: Option<ui_widgets_md3::Date>) -> String {
    match date {
        Some(d) => format!(
            "{} {} {}",
            d.day,
            ui_widgets_md3::month_label(cx, d.month),
            d.year
        ),
        None => "—".to_string(),
    }
}

/// MD3 date pickers: one live calendar, and one build-time variant (Sunday first, a range).
/// MD3 日期选择器：一块活的日历，以及一个构建期变体（周日开头、限定可选范围）。
pub(crate) fn date_picker_page(
    values: [Option<ui_widgets_md3::Date>; DATE_PICKERS],
    shown: [ui_widgets_md3::Date; DATE_PICKERS],
    views: [ui_widgets_md3::DatePickerView; DATE_PICKERS],
    input: &DateInputState<'_>,
    cx: &mut Cx<'_, '_>,
) -> Box<dyn Element> {
    let mut row = Container::new(
        Id::of(("bodyrow", Page::DatePicker.tag())),
        NodeKind::Row,
    )
    .size(SizeClass {
        width: AxisSize::fill(0.0, 0.0),
        height: AxisSize::fill(0.0, 0.0),
        grow_x: Grow::Yes,
        grow_y: Grow::Yes,
    })
    .gap(20.0);
    let appearance = ui_style::StyleScope::of(cx.env()).appearance;
    let pack = ui_widgets_md3::pack_of(appearance);
    let mut scoped = cx.at_scope(style_env("md3"));
    let mut col = Container::new(Id::of(("body", "md3")), NodeKind::Column).gap(8.0);

    let view = match views[0] {
        ui_widgets_md3::DatePickerView::Days => Msg::GALLERY_DATE_VIEW_DAYS,
        ui_widgets_md3::DatePickerView::Months => Msg::GALLERY_DATE_VIEW_MONTHS,
        ui_widgets_md3::DatePickerView::Years => Msg::GALLERY_DATE_VIEW_YEARS,
    };
    let readout = tf(
        &scoped,
        Msg::GALLERY_DATE_READOUT,
        &[
            ("today", arg(date_text(&scoped, Some(date_picker_today())))),
            ("picked", arg(date_text(&scoped, values[0]))),
            ("month", arg(ui_widgets_md3::month_label(&scoped, shown[0].month).to_string())),
            ("year", arg(shown[0].year.to_string())),
            ("view", arg(tr(&scoped, view))),
        ],
    );
    col = col.child_decl(label(
        Id::str("date-picker/readout"),
        readout,
        12.0,
        muted(),
        740.0,
    ));

    let mut samples = Container::new(Id::str("date-picker/samples"), NodeKind::Row).gap(16.0);
    for k in 0..DATE_PICKERS {
        let mut params = ui_widgets_md3::DatePickerParams::new(date_picker_id(k), date_picker_today());
        params.value = values[k];
        params.shown = shown[k];
        params.view = views[k];
        if k == 1 {
            // Fixed when the sample is built: neither knob is a running state.
            // 在样本构建时固定：两个旋钮都不是运行中的状态。
            params.week_start = ui_widgets_md3::Weekday::Sun;
            params.min = ui_widgets_md3::Date::new(2026, 10, 10);
            params.max = ui_widgets_md3::Date::new(2026, 10, 24);
        }
        let caption = if k == 0 {
            Msg::GALLERY_DATE_CAPTION_MON
        } else {
            Msg::GALLERY_DATE_CAPTION_SUN
        };
        let text = tr(&scoped, caption);
        let picker = ui_widgets_md3::Md3DatePicker::from_pack(&pack, &mut scoped, params);
        samples = samples.child(Box::new(
            Container::new(Id::of(("date-picker/block", k)), NodeKind::Column)
                .gap(4.0)
                .child_decl(label(
                    Id::of(("date-picker/cap", k)),
                    text,
                    11.0,
                    muted(),
                    360.0,
                ))
                .child(scoped.element(Box::new(picker))),
        ));
    }
    col = col.child(Box::new(samples));

    row = row.child(column_w(
        Page::DatePicker,
        "md3",
        Msg::GALLERY_STYLE_MD3,
        Box::new(col),
        800.0,
        560.0,
        &scoped,
    ));
    // The input replaces the two placeholder columns: at 328 wide it does not fit beside
    // them, and what they said — no date picker in the other packs — is one line here.
    // 文本输入取代了两条占位列：328 宽的它挤不进那两列旁边，而它们要说的话——另两套都没有
    // 日期选择器——在这里只占一行。
    let input_body = date_input_sample(input, &mut scoped);
    row = row.child(column_w(
        Page::DatePicker,
        "md3-input",
        Msg::GALLERY_DATE_INPUT_TITLE,
        input_body,
        COL_W,
        680.0,
        &scoped,
    ));
    Box::new(row)
}

/// The facts the text-mode sample draws: the buffer the engine edits, and the last action.
/// 文本模式样本绘制的事实：引擎编辑的缓冲，与最近的一个动作。
pub(crate) struct DateInputState<'a> {
    pub(crate) text: &'a str,
    pub(crate) action: Option<ui_widgets_md3::DateInputAction>,
}

/// The text-mode sample: a readout over the 328×512 input surface.
/// 文本模式样本：读数在上，下面是 328×512 的输入表面。
fn date_input_sample(state: &DateInputState<'_>, cx: &mut Cx<'_, '_>) -> Box<dyn Element> {
    use ui_widgets_md3::DateInputAction;
    let action = match state.action {
        Some(DateInputAction::Calendar) => Msg::GALLERY_DATE_INPUT_CALENDAR,
        Some(DateInputAction::Cancel) => Msg::GALLERY_DATE_INPUT_CANCEL,
        Some(DateInputAction::Confirm) => Msg::GALLERY_DATE_INPUT_CONFIRM,
        None => Msg::GALLERY_DATE_INPUT_NONE,
    };
    let text = if state.text.is_empty() { "—" } else { state.text };
    let readout = tf(
        cx,
        Msg::GALLERY_DATE_INPUT_READOUT,
        &[
            ("text", arg(text.to_string())),
            ("action", arg(tr(cx, action))),
        ],
    );
    let supporting = tr(cx, Msg::GALLERY_DATE_INPUT_SUPPORTING);
    let headline = tr(cx, Msg::GALLERY_DATE_INPUT_HEADLINE);
    let label_text = tr(cx, Msg::GALLERY_DATE_INPUT_LABEL);
    let placeholder = tr(cx, Msg::GALLERY_DATE_INPUT_PLACEHOLDER);
    let hint = tr(cx, Msg::GALLERY_DATE_INPUT_HINT);
    let cancel = tr(cx, Msg::GALLERY_DATE_INPUT_CANCEL_LABEL);
    let confirm = tr(cx, Msg::GALLERY_DATE_INPUT_CONFIRM_LABEL);
    let mut params = ui_widgets_md3::DateInputParams::new(date_input_id());
    params.text = state.text;
    params.supporting = &supporting;
    params.headline = &headline;
    params.label = &label_text;
    params.placeholder = &placeholder;
    params.supporting_field = &hint;
    params.cancel = &cancel;
    params.confirm = &confirm;
    let appearance = ui_style::StyleScope::of(cx.env()).appearance;
    let pack = ui_widgets_md3::pack_of(appearance);
    let input = ui_widgets_md3::Md3DateInput::from_pack(&pack, cx, params);
    let note = tr(cx, Msg::GALLERY_DATE_INPUT_PENDING);
    let mut body = Container::new(Id::str("date-input/body"), NodeKind::Column).gap(8.0);
    body = body
        .child_decl(label(
            Id::str("date-input/readout"),
            readout,
            12.0,
            muted(),
            COL_W - 24.0,
        ))
        .child(cx.element(Box::new(input)))
        .child_decl(label(
            Id::str("date-input/note"),
            note,
            11.0,
            muted(),
            COL_W - 24.0,
        ));
    Box::new(body)
}
