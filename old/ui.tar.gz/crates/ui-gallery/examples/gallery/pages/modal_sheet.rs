// The modal sheet page.
// 模态面板页。

use ui_widgets_glass::{
    GlassButton, GlassButtonParams, GlassModalSheet, GlassModalSheetParams, GlassSheetDetent,
    HigOptions,
};

use crate::shell::*;

/// The app's own ids: the trigger, the sheet root and the button inside it.
/// 应用自己的 id：触发器、面板根，以及面板里的按钮。
pub(crate) fn modal_sheet_open_id() -> Id {
    Id::of(("modal-sheet", Page::ModalSheet.tag(), "open"))
}

pub(crate) fn modal_sheet_id() -> Id {
    Id::of(("modal-sheet", Page::ModalSheet.tag()))
}

pub(crate) fn modal_sheet_done_id() -> Id {
    modal_sheet_id().with("done")
}

/// The surface itself, below the modal root: what a drag moves.
/// 面板本体，位于模态根之下：拖拽搬动的就是它。
pub(crate) fn modal_sheet_body_id() -> Id {
    modal_sheet_id().with("sheet")
}

/// The live sheet, declared at the window root: the engine resolves the modal region.
/// 实时面板，声明在窗口根上：模态区域由引擎解析。
pub(crate) fn modal_sheet_modal(cx: &mut Cx<'_, '_>) -> Box<dyn Element> {
    let pack = ui_widgets_glass::pack_of(ui_style::StyleScope::of(&root_env()).appearance);
    let mut scoped = cx.at_scope(style_env("glass"));
    let ink = pack
        .ink("textFillColorPrimary")
        .unwrap_or(ui_core::geom::Color::BLACK);
    let title = label(
        modal_sheet_id().with("title"),
        tr(&scoped, Msg::GALLERY_MODAL_SHEET_TITLE),
        17.0,
        ink,
        COL_W - 48.0,
    );
    let body = label(
        modal_sheet_id().with("body"),
        tr(&scoped, Msg::GALLERY_MODAL_SHEET_BODY),
        13.0,
        muted(),
        COL_W - 48.0,
    );
    let done_label = tr(&scoped, Msg::GALLERY_MODAL_SHEET_DONE);
    let done = {
        let params = GlassButtonParams::labelled(modal_sheet_done_id(), None, &done_label);
        let mut node = scoped.at(modal_sheet_done_id());
        GlassButton::new_with(HigOptions::default(), params, &mut node, &pack)
    };
    let params = GlassModalSheetParams::new(
        modal_sheet_id(),
        vec![title, body, done.decl(&scoped)],
    )
    .padding(Insets {
        left: 24.0,
        right: 24.0,
        top: 8.0,
        bottom: 24.0,
    })
    .initial(GlassSheetDetent::Half)
    .presses(vec![modal_sheet_done_id()]);
    let sheet = GlassModalSheet::new(params, &mut scoped, &pack);
    scoped.element(Box::new(sheet))
}

/// The page: a trigger that opens the sheet, and the app's record of what it reported.
/// 页面：打开面板的触发器，以及应用对上报结果的记录。
pub(crate) fn modal_sheet_page(
    detent: Option<Msg>,
    dismissed: u32,
    cx: &mut Cx<'_, '_>,
) -> Box<dyn Element> {
    let mut row = Container::new(Id::of(("bodyrow", Page::ModalSheet.tag())), NodeKind::Row)
        .size(SizeClass {
            width: AxisSize::fill(0.0, 0.0),
            height: AxisSize::fill(0.0, 0.0),
            grow_x: Grow::Yes,
            grow_y: Grow::Yes,
        })
        .gap(20.0);

    // MD3 and Fluent have no modal sheet in this repository yet.
    // MD3 与 Fluent 在本仓库里还没有模态面板。
    for tag in ["md3", "fluent"] {
        row = row.child(pending_column(Page::ModalSheet, tag, COL_W, COL_TALL_H, cx));
    }

    let pack = ui_widgets_glass::pack_of(ui_style::StyleScope::of(&root_env()).appearance);
    let mut scoped = cx.at_scope(style_env("glass"));
    let trigger_label = tr(&scoped, Msg::GALLERY_MODAL_SHEET_SHOW);
    let trigger = {
        let params = GlassButtonParams::labelled(modal_sheet_open_id(), None, &trigger_label);
        let mut node = scoped.at(modal_sheet_open_id());
        GlassButton::new_with(HigOptions::default(), params, &mut node, &pack)
    };
    let mut col = Container::new(Id::of(("body", "glass")), NodeKind::Column).gap(14.0);
    col = col.child(Box::new(captioned_row(
        modal_sheet_open_id(),
        scoped.element(Box::new(trigger)),
        tr(&scoped, Msg::GALLERY_MODAL_SHEET_CAPTION),
    )));
    let detent = detent
        .map(|msg| tr(&scoped, msg))
        .unwrap_or_else(|| tr(&scoped, Msg::GALLERY_MODAL_SHEET_NONE));
    col = col.child_decl(label(
        Id::str("modal-sheet/readout"),
        tf(
            &scoped,
            Msg::GALLERY_MODAL_SHEET_READOUT,
            &[("detent", arg(detent)), ("count", arg(dismissed as i64))],
        ),
        12.0,
        muted(),
        COL_W - 24.0,
    ));
    row = row.child(column(
        Page::ModalSheet,
        "glass",
        Msg::GALLERY_STYLE_GLASS,
        Box::new(col),
        COL_TALL_H,
        cx,
    ));
    Box::new(row)
}
