// The generic pack-driven page.
// 包驱动的通用控件页。

use crate::shell::*;

/// The pack-driven widgets: no style of their own, everything read from one pack.
/// 由包驱动的控件：自身不带外观，全部从一个包读取。
pub(crate) fn generic_page(cx: &mut Cx<'_, '_>) -> Box<dyn Element> {
    let pack = ui_style::legacy_pack();
    let mut row = Container::new(Id::of(("bodyrow", Page::Generic.tag())), NodeKind::Row)
        .size(SizeClass {
            width: AxisSize::fill(0.0, 0.0),
            height: AxisSize::fill(0.0, 0.0),
            grow_x: Grow::Yes,
            grow_y: Grow::Yes,
        })
        .gap(20.0);

    // The button's fade is advanced through the node context, using the pack's own token.
    // 按钮的淡入经节点上下文推进，用的是包自己的时长令牌。
    let button_id = Id::str("generic/button");
    let state = cx.state(button_id);
    let spec = pack.motion.get(ui_style::MotionName::StateChange).spec;
    let hover = {
        let mut node = cx.at(button_id);
        node.animate(
            button_id.with("hover"),
            if state.hovered { 1.0 } else { 0.0 },
            spec,
        )
    };
    let button = ui_widgets::Button::new(button_id, tr(cx, Msg::GALLERY_GENERIC_BUTTON)).resolve(state, &pack, hover);
    let card = ui_widgets::Card {
        id: Id::str("generic/card"),
        title: Some(tr(cx, Msg::GALLERY_GENERIC_CARD_TITLE)),
        title_ink: None,
        pack: &pack,
    }
    .resolve(vec![button]);
    row = row.child(column(
        Page::Generic,
        "card",
        Msg::GALLERY_GENERIC_COLUMN_CARD,
        from_decl(card),
        COL_CTRL_H,
        cx,
    ));

    let list = ui_widgets::List {
        id: Id::str("generic/list"),
        width: 300.0,
        height: 180.0,
        row_height: 22.0,
        rows: (0..12)
            .map(|i| tf(cx, Msg::GALLERY_GENERIC_ROW, &[("index", arg(i as i64))]))
            .collect(),
        pack: &pack,
    }
    .resolve_in(cx);
    row = row.child(column(
        Page::Generic,
        "list",
        Msg::GALLERY_GENERIC_COLUMN_LIST,
        from_decl(list),
        COL_CTRL_H,
        cx,
    ));

    let panel = ui_widgets::Panel {
        id: Id::str("generic/panel"),
        size: (260.0, 140.0),
        offset: (0.0, 0.0),
        dragging: false,
        title: tr(cx, Msg::GALLERY_GENERIC_PANEL_TITLE),
        hint: tr(cx, Msg::GALLERY_GENERIC_PANEL_HINT),
        title_ink: None,
        hint_ink: None,
        pack: &pack,
    }
    .resolve();
    row = row.child(column(
        Page::Generic,
        "panel",
        Msg::GALLERY_GENERIC_COLUMN_PANEL,
        from_decl(panel),
        COL_CTRL_H,
        cx,
    ));

    Box::new(row)
}
