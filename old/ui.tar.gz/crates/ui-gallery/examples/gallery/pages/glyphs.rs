// Glyph sources shared by the navigation and toolbar pages.
// 导航与工具条页共用的字形源。

use ui_widgets::IconSource;
use ui_widgets::IconSet;

fn glyph(name: &str) -> IconSource {
    IconSource::glyph(name, IconSet::Outlined)
}

/// The iOS glyph for the same destination, from the vendored SF Symbols font.
/// 同一目标的 iOS 字形，取自随仓库分发的 SF Symbols 字体。
pub(crate) fn sf_glyph(name: &str) -> IconSource {
    IconSource::sf(name)
}

pub(crate) fn home_glyph() -> IconSource {
    glyph("home")
}

pub(crate) fn search_glyph() -> IconSource {
    glyph("search")
}

pub(crate) fn profile_glyph() -> IconSource {
    glyph("person")
}

pub(crate) fn inbox_glyph() -> IconSource {
    glyph("inbox")
}

pub(crate) fn sent_glyph() -> IconSource {
    glyph("send")
}

pub(crate) fn drafts_glyph() -> IconSource {
    glyph("drafts")
}

pub(crate) fn favorite_glyph() -> IconSource {
    glyph("favorite")
}

pub(crate) fn share_glyph() -> IconSource {
    glyph("share")
}

pub(crate) fn tune_glyph() -> IconSource {
    glyph("tune")
}

pub(crate) fn more_glyph() -> IconSource {
    glyph("more_vert")
}
