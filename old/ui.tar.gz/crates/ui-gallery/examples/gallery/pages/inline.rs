// The inline page: atoms and vertical alignment inside a paragraph.
// 行内页：段落里的原子与纵向对齐。

use crate::shell::*;
use ui_core::geom::Size;
use ui_core::text::{AtomBox, TextBlock, TextStyle, VerticalAlign, OBJECT};

/// tag and the block width its paragraph is measured at.
/// 标识与段落测量所用的块宽。
pub(crate) const INLINE_SAMPLES: [(&str, f32); 3] =
    [("baseline", 300.0), ("mixed", 300.0), ("narrow", 110.0)];

pub(crate) fn inline_text_id(tag: &'static str) -> Id {
    Id::of(("inline-text", Page::Inline.tag(), tag))
}

/// Builds a paragraph by interleaving text with atoms, tracking byte offsets.
/// 通过交替追加文字与原子来构造段落，并跟踪字节偏移。
struct Run {
    text: String,
    atoms: Vec<AtomBox>,
}

impl Run {
    fn new() -> Self {
        Self {
            text: String::new(),
            atoms: Vec::new(),
        }
    }

    fn word(mut self, text: &str) -> Self {
        self.text.push_str(text);
        self
    }

    fn atom(mut self, size: Size, align: VerticalAlign) -> Self {
        self.atoms
            .push(AtomBox::new(self.text.len(), size).align(align));
        self.text.push(OBJECT);
        self
    }

    fn build(self) -> TextBlock {
        let mut block = TextBlock::plain(self.text, TextStyle::new(14.0));
        block.atoms = self.atoms;
        block
    }
}

fn text_node(tag: &'static str, block: TextBlock, width: f32) -> Decl {
    let id = inline_text_id(tag);
    let mut decl = Decl::container(id, NodeKind::Text);
    decl.data = ui_core::NodeData::Text {
        ink: Color::from_rgba8(228, 232, 240, 255),
        block,
        caret: None,
        selection: None,
        composing: None,
        nowrap: false,
    };
    decl.size_class = SizeClass {
        width: AxisSize::fixed(width),
        height: AxisSize::hug(0.0, 0.0),
        grow_x: Grow::No,
        grow_y: Grow::No,
    };
    decl
}

fn sample(tag: &'static str, block: TextBlock, width: f32) -> Decl {
    let mut col = Decl::container(
        Id::of(("inline-sample", Page::Inline.tag(), tag)),
        NodeKind::Column,
    )
    .size(SizeClass::hug(0.0, 0.0))
    .gap(8.0);
    col = col.child(text_node(tag, block, width));
    col
}

pub(crate) fn inline_page(cx: &mut Cx<'_, '_>) -> Box<dyn Element> {
    let mut row = Container::new(Id::of(("bodyrow", Page::Inline.tag())), NodeKind::Row)
        .size(SizeClass {
            width: AxisSize::fill(0.0, 0.0),
            height: AxisSize::fill(0.0, 0.0),
            grow_x: Grow::Yes,
            grow_y: Grow::Yes,
        })
        .gap(20.0);

    // Two icons on the text baseline: the classic inline-image row.
    // 两个坐在文字基线上的图标：经典的行内图片行。
    let baseline = Run::new()
        .word(&tr(cx, Msg::GALLERY_INLINE_SYNC_1))
        .atom(Size::new(16.0, 16.0), VerticalAlign::Baseline)
        .word(&tr(cx, Msg::GALLERY_INLINE_SYNC_2))
        .atom(Size::new(24.0, 20.0), VerticalAlign::Baseline)
        .word(&tr(cx, Msg::GALLERY_INLINE_SYNC_3))
        .build();
    row = row.child(column_text(
        Page::Inline,
        "baseline",
        tr(cx, Msg::GALLERY_INLINE_COLUMN_BASELINE),
        from_decl(sample("baseline", baseline, 300.0)),
        COL_W,
        COL_CTRL_H,
    ));

    // One atom per alignment: each hangs from a different edge of the line box.
    // 每种对齐一个原子：各自挂在行盒的不同边上。
    let mixed = Run::new()
        .word(&tr(cx, Msg::GALLERY_INLINE_TALL_1))
        .atom(Size::new(14.0, 34.0), VerticalAlign::Top)
        .word(&tr(cx, Msg::GALLERY_INLINE_TALL_2))
        .atom(Size::new(22.0, 22.0), VerticalAlign::Middle)
        .word(&tr(cx, Msg::GALLERY_INLINE_TALL_3))
        .atom(Size::new(12.0, 18.0), VerticalAlign::Bottom)
        .word(&tr(cx, Msg::GALLERY_INLINE_TALL_4))
        .build();
    row = row.child(column_text(
        Page::Inline,
        "mixed",
        tr(cx, Msg::GALLERY_INLINE_COLUMN_MIXED),
        from_decl(sample("mixed", mixed, 300.0)),
        COL_W,
        COL_CTRL_H,
    ));

    // An 80-wide atom in a 110-wide block cannot share its line: it starts one.
    // 110 宽的块里放不下 80 宽的原子与文字同行：它自起一行。
    let narrow = Run::new()
        .word(&tr(cx, Msg::GALLERY_INLINE_NARROW_1))
        .atom(Size::new(80.0, 36.0), VerticalAlign::Bottom)
        .word(&tr(cx, Msg::GALLERY_INLINE_NARROW_2))
        .build();
    row = row.child(column_text(
        Page::Inline,
        "narrow",
        tr(cx, Msg::GALLERY_INLINE_COLUMN_NARROW),
        from_decl(sample("narrow", narrow, 110.0)),
        COL_W,
        COL_CTRL_H,
    ));

    Box::new(row)
}
