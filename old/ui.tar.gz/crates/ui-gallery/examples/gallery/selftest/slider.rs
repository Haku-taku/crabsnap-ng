// Self-test checks for the slider page.
// 滑块页的自检。

use crate::selftest::*;

pub(crate) fn slider(lp: &mut AppLoop<Gallery>, size: (u32, u32)) -> (bool, f32, bool) {
    let mut pass = true;
    let button = ui_core::PointerButton::Primary;
    // Drag the MD3 slider, then leave and come back: the value must be the same.
    // 拖动 MD3 滑块，然后离开再回来：值必须不变。
    goto(lp, size, Page::Slider);
    // The five size variants must reach layout as five different heights.
    // 五个尺寸变体必须以五种不同高度落到布局上。
    let mut heights = Vec::new();
    for k in 0..SLIDER_SIZES.len() {
        let id = if k == 0 { slider_id(Page::Slider, "md3") } else { slider_size_id(k) };
        let want = ui_widgets_md3::spec::slider_spec(true, false, false, false, false, SLIDER_SIZES[k])
            .handle
            .height
            .max(ui_widgets_md3::SLIDER_TOUCH);
        let got = rect_of(lp, id).map(|r| r.size.h).unwrap_or(-1.0);
        heights.push((got, want));
    }
    let sizes_ok = heights.iter().all(|(got, want)| (got - want).abs() < 0.5);
    println!("selftest: md3 slider sizes {:?} {}", heights, if sizes_ok { "✓" } else { "✗" });
    if !sizes_ok {
        pass = false;
    }

    // A press commits nothing: only a tap's release or a real drag sets the value. Committing
    // on the press would send the thumb off the moment it is touched.
    // 按下不提交值：只有点击松手或真正的拖拽才设值；按下即设值会让拇指一碰就跳。
    for (tag, bar_tag, map) in [
        (
            "glass",
            "stack",
            ui_widgets_glass::slider_value_at as fn(f32) -> f32,
        ),
        ("fluent", "bar", ui_widgets_fluent::slider_value_at),
    ] {
        let id = slider_id(Page::Slider, tag);
        let bar = rect_of(lp, id.with(bar_tag)).expect("slider bar");
        let at = Point::new(bar.origin.x + 200.0, bar.origin.y + bar.size.h * 0.5);
        let before = lp.app_mut().value;
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        frame(lp, size, Some(at));
        lp.dispatch(ui_core::Event::PointerPressed { pos: at, button });
        frame(lp, size, Some(at));
        let held = lp.app_mut().value;
        lp.dispatch(ui_core::Event::PointerReleased { pos: at, button });
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        frame(lp, size, Some(at));
        let tapped = lp.app_mut().value;
        let want = map(200.0);
        let ok = held == before && (tapped - want).abs() < 1e-3;
        println!(
            "selftest: {tag} slider press holds {held:.3} (was {before:.3}), tap {tapped:.3} (want {want:.3}) {}",
            if ok { "✓" } else { "✗" }
        );
        if !ok {
            pass = false;
        }

        // A drag must move the value while the finger is still down, not only when it lifts.
        // 拖拽必须在手指仍按下时就改值，而不是抬手才动。
        if tag == "fluent" {
            // The thumb rides the track's centre line; a Box would flow it a track below.
            // 滑块走轨道的中心线；用 Box 会把它排低一条轨道。
            let mid = |id: ui_core::Id| rect_of(lp, id).map(|r| r.origin.y + r.size.h * 0.5);
            let track_mid = mid(id.with("track")).unwrap_or(f32::NAN);
            let thumb_mid = mid(id.with("thumb")).unwrap_or(f32::NAN);
            let centred = (thumb_mid - track_mid).abs() < 0.01;
            println!(
                "selftest: fluent slider thumb centre {thumb_mid:.2} on track centre {track_mid:.2} {}",
                if centred { "✓" } else { "✗" }
            );
            if !centred {
                pass = false;
            }
        }
        let from = Point::new(bar.origin.x + 100.0, bar.origin.y + bar.size.h * 0.5);
        // Let the tap's own glide land first: a press banks where the thumb stands.
        // 先让点击的滑行落定：按下会把滑块就地记账。
        lp.dispatch(ui_core::Event::PointerMoved { pos: from });
        for _ in 0..20 {
            let _ = lp.build_with_dt(size, Some(from), 0.016);
        }
        let settled = lp.app_mut().value;
        lp.dispatch(ui_core::Event::PointerPressed { pos: from, button });
        frame(lp, size, Some(from));
        let mut to = from;
        for step in [20.0f32, 40.0, 60.0] {
            to = Point::new(from.x + step, from.y);
            lp.dispatch(ui_core::Event::PointerMoved { pos: to });
            frame(lp, size, Some(to));
        }
        // The app applies a reported change on the frame after it is reported.
        // 应用在上报之后的下一帧才落值。
        frame(lp, size, Some(to));
        let mid = lp.app_mut().value;
        let follows = (mid - settled).abs() > 0.01;
        println!(
            "selftest: {tag} slider drag moved the value {settled:.3}->{mid:.3} before release {}",
            if follows { "✓" } else { "✗" }
        );
        if !follows {
            pass = false;
        }
        // Letting go must keep the thumb where the finger left it: that frame arrives before
        // the app has applied the value, so a thumb that reads it rewinds to the drag's start.
        // 松手必须让滑块留在手指离开的地方：那一帧早于应用落值，读它会退回拖拽起点。
        let centre = |lp: &AppLoop<Gallery>| {
            rect_of(lp, id.with("thumb")).map(|r| r.origin.x + r.size.w * 0.5)
        };
        let under_finger = centre(lp).unwrap_or(f32::NAN);
        lp.dispatch(ui_core::Event::PointerReleased { pos: to, button });
        frame(lp, size, Some(to));
        let after_release = centre(lp).unwrap_or(f32::NAN);
        let stays = (after_release - under_finger).abs() < 1.0;
        println!(
            "selftest: {tag} slider release keeps the thumb at {under_finger:.2}, now {after_release:.2} {}",
            if stays { "✓" } else { "✗" }
        );
        if tag == "fluent" && !stays {
            pass = false;
        }
    }

    // A press must melt the glass thumb into the reference's 58×38.333 lens about the value's
    // centre, and the release must bring it back to 37×24. The ids differ from the switch's,
    // so its own check does not cover this wiring.
    // 按住必须把玻璃滑块化开成参考的 58×38.333 透镜、中心落在值上，松手再回到 37×24。
    // 这里的 id 与开关不同，开关的检查覆盖不到这条接线。
    let gid = slider_id(Page::Slider, "glass");
    let stack = rect_of(lp, gid.with("stack")).expect("glass slider");
    let thumb = |lp: &AppLoop<Gallery>| rect_of(lp, gid.with("thumb"));
    let at = Point::new(stack.origin.x + 200.0, stack.origin.y + stack.size.h * 0.5);
    lp.dispatch(ui_core::Event::PointerMoved { pos: at });
    // Let the tap's own spring land before pressing: a press banks the thumb where it stands,
    // so an unfinished flight would be measured as if the press had moved it.
    // 先让点击自己的弹簧落定再按下：按下会把滑块就地记账，尚在途中的行程会被误算成按下挪动的。
    // 0.64 s covers the 0.2 s tap hold plus the 0.6 s contraction.
    // 0.64s 覆盖 0.2s 的点击保持加 0.6s 的收束。
    for _ in 0..40 {
        let _ = lp.build_with_dt(size, Some(at), 0.016);
    }
    let rest = thumb(lp).expect("glass thumb");
    lp.dispatch(ui_core::Event::PointerPressed { pos: at, button });
    let mut peak = 0.0f32;
    for _ in 0..20 {
        let _ = lp.build_with_dt(size, Some(at), 0.016);
        peak = peak.max(thumb(lp).map(|r| r.size.h).unwrap_or(0.0));
    }
    let held = thumb(lp).expect("glass thumb");
    // The press holds the thumb where the value put it: the shared value belongs to the other
    // sliders on the page too, so the pointer is not where the thumb stands.
    // 按住把滑块留在值所在处：页面上的其他滑块共用这个值，因此指针处并不是滑块所在处。
    let rest_centre = rest.origin.x + rest.size.w * 0.5;
    let held_centre = held.origin.x + held.size.w * 0.5;
    let centre = held_centre - rest_centre;
    let swells = (ui_widgets_glass::SLIDER_EXPANDED_H * 0.98..ui_widgets_glass::SLIDER_EXPANDED_H * 1.2).contains(&peak)
        && centre.abs() < 0.2;
    lp.dispatch(ui_core::Event::PointerReleased { pos: at, button });
    for _ in 0..60 {
        let _ = lp.build_with_dt(size, Some(at), 0.016);
    }
    let back = thumb(lp).expect("glass thumb");
    let rounds_down = (back.size.h - rest.size.h).abs() < 0.5 && (back.size.w - rest.size.w).abs() < 0.5;
    println!(
        "selftest: glass slider press peaked {peak:.1}px tall (expanded {:.1}, rest {:.1}), centre moved {centre:.2}px, released to {:.1}x{:.1} {}",
        ui_widgets_glass::SLIDER_EXPANDED_H,
        rest.size.h,
        back.size.w,
        back.size.h,
        if swells && rounds_down { "✓" } else { "✗" }
    );
    if !(swells && rounds_down) {
        pass = false;
    }

    let slider = rect_of(lp, slider_id(Page::Slider, "md3")).expect("md3 slider");
    let inset = ui_widgets_md3::spec::slider_spec(
        true,
        false,
        false,
        false,
        false,
        ui_widgets_md3::spec::SliderSize::XSmall,
    )
    .track_shape
    .leading;
    let travel = slider.size.w - 2.0 * inset;
    let start = Point::new(
        slider.origin.x + inset + travel * 0.5,
        slider.origin.y + slider.size.h * 0.5,
    );
    lp.dispatch(ui_core::Event::PointerMoved { pos: start });
    frame(lp, size, Some(start));
    lp.dispatch(ui_core::Event::PointerPressed {
        pos: start,
        button,
    });
    frame(lp, size, Some(start));
    let mut last = start;
    for step in [20.0f32, 40.0] {
        last = Point::new(start.x + step, start.y);
        lp.dispatch(ui_core::Event::PointerMoved { pos: last });
        frame(lp, size, Some(last));
    }
    lp.dispatch(ui_core::Event::PointerReleased { pos: last, button });
    frame(lp, size, Some(last));
    let dragged = lp.app_mut().value;
    let want = (0.5 + 40.0 / travel).min(1.0);
    let drag_ok = (dragged - want).abs() < 0.02;
    println!(
        "selftest: slider drag value {dragged:.3} (want {want:.3}) {}",
        if drag_ok { "✓" } else { "✗" }
    );
    if !drag_ok {
        pass = false;
    }

    // A stepped slider snaps to its stops: 0.62 along is nearer 0.5 than 0.75.
    // 离散滑块吸附到刻度：走到 0.62 处离 0.5 比 0.75 更近。
    let stepped = rect_of(lp, slider_step_id()).expect("stepped slider");
    let step_inset = ui_widgets_md3::spec::slider_spec(
        true,
        false,
        false,
        false,
        false,
        ui_widgets_md3::spec::SliderSize::Small,
    )
    .track_shape
    .leading;
    let step_travel = stepped.size.w - 2.0 * step_inset;
    click(
        lp,
        size,
        Point::new(
            stepped.origin.x + step_inset + step_travel * 0.62,
            stepped.origin.y + stepped.size.h * 0.5,
        ),
    );
    let snapped = lp.app_mut().step_value;
    let snap_ok = (snapped - 0.5).abs() < 1e-3;
    println!("selftest: stepped slider snapped to {snapped:.3} (want 0.500) {}", if snap_ok { "✓" } else { "✗" });
    if !snap_ok {
        pass = false;
    }

    // A range slider moves the nearer handle only: a click near the trailing one at 0.9
    // leaves the leading one at 0.2.
    // 范围滑块只移动较近的手柄：点尾手柄附近的 0.9 处，前手柄仍停在 0.2。
    let ranged = rect_of(lp, slider_range_id()).expect("range slider");
    let range_inset = step_inset;
    let range_travel = ranged.size.w - 2.0 * range_inset;
    click(
        lp,
        size,
        Point::new(
            ranged.origin.x + range_inset + range_travel * 0.9,
            ranged.origin.y + ranged.size.h * 0.5,
        ),
    );
    let (rs, re) = lp.app_mut().range;
    let range_ok = (rs - 0.2).abs() < 0.02 && (re - 0.9).abs() < 0.02;
    println!("selftest: range slider {rs:.3}..{re:.3} (want 0.200..0.900) {}", if range_ok { "✓" } else { "✗" });
    if !range_ok {
        pass = false;
    }
    (pass, dragged, drag_ok)
}
