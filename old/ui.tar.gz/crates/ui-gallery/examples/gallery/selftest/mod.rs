// Synthetic input checks against the real tree, and their shared helpers.
// 对真实树的合成输入检查及其共享辅助。

pub(crate) use crate::app::Gallery;
pub(crate) use crate::pages::*;
pub(crate) use crate::shell::*;
use self::app_bar::app_bar;
use self::buttons::{buttons, cursor};
use self::cards::cards;
use self::carousel::carousel;
use self::checkbox::checkbox;
use self::chips::chips;
use self::date_picker::date_picker;
use self::action_sheet::action_sheet;
use self::toast::toast;
use self::modal_sheet::modal_sheet;
use self::stepper::stepper;
use self::dialogs::dialogs;
use self::fab::{fab_menu, fab_page};
use self::combo::combo;
use self::nav_view::nav_view;
use self::menu_flyout::menu_flyout;
use self::grid::grid;
use self::icons::icons;
use self::inline::inline;
use self::positioning::positioning;
use self::progress::progress;
use self::segmented::segmented;
use self::nav_bar::nav_bar;
use self::nav_rail::nav_rail;
use self::nav_drawer::nav_drawer;
use self::toolbar::toolbar;
use self::snackbar::snackbar;
use self::lists::lists;
use self::radio::radio;
use self::search::search;
use self::selection::selection;
use self::slider::slider;
use self::switch::switch_state;
use self::tabs::tabs;
use self::text_field::{
    glass_search_bar, glass_text_field, text_field, text_field_caret, text_field_ime,
};
use self::time_picker::time_picker;

mod slider;
mod tabs;
mod buttons;
mod fab;
mod menu_flyout;
mod combo;
mod nav_view;
mod grid;
mod inline;
mod positioning;
mod chips;
mod cards;
mod lists;
mod switch;
mod checkbox;
mod radio;
mod action_sheet;
mod toast;
mod modal_sheet;
mod stepper;
mod dialogs;
mod date_picker;
mod time_picker;
mod search;
mod app_bar;
mod carousel;
mod text_field;
mod icons;
mod selection;
mod progress;
mod segmented;
mod nav_bar;
mod nav_rail;
mod nav_drawer;
mod toolbar;
mod snackbar;

pub(crate) fn want_dump() -> bool {
    std::env::var("GALLERY_DUMP").is_ok()
}

/// `GALLERY_DUMP_FRAMES=n` dumps on frame `n` instead of the first, so a screenshot can
/// catch an animation in flight without the compositor's screencopy.
/// `GALLERY_DUMP_FRAMES=n` 在第 n 帧导出，而不是第一帧，截图因此能拍到动画中途，且不依赖合成器截屏。
pub(crate) fn dump_frame() -> u32 {
    std::env::var("GALLERY_DUMP_FRAMES")
        .ok()
        .and_then(|v| v.trim().parse().ok())
        .unwrap_or(0)
}

/// Advance `frames` scripted frames of 16ms, so fades run without sleeping.
/// 推进 `frames` 帧脚本时间、每帧 16ms，淡出无需真的等待。
pub(crate) fn step(lp: &mut AppLoop<Gallery>, size: (u32, u32), pointer: Point, frames: u32) {
    for _ in 0..frames {
        let _ = lp.build_with_dt(size, Some(pointer), 0.016);
    }
}

pub(crate) fn rect_of(lp: &AppLoop<Gallery>, id: Id) -> Option<Rect> {
    let nid = lp.tree().find_by_id(id)?;
    lp.tree().get(nid).map(|n| n.visual_rect())
}

/// The layout rect, before the visual offset is applied.
/// 布局矩形，未应用视觉偏移。
pub(crate) fn layout_rect(lp: &AppLoop<Gallery>, id: Id) -> Option<Rect> {
    let nid = lp.tree().find_by_id(id)?;
    lp.tree().get(nid).map(|n| n.rect)
}

/// The rect a control paints for its `index`-th shape, in paint order.
/// 控件第 `index` 个形状绘制的矩形，按绘制顺序。
pub(crate) fn shape_rect(lp: &AppLoop<Gallery>, id: Id, index: usize) -> Option<Rect> {
    let nid = lp.tree().find_by_id(id)?;
    let list = lp.draw_list();
    let mut seen = 0;
    for i in 0..list.prims.rects.len() {
        if list.owners.rects.get(i) != Some(&nid) {
            continue;
        }
        if seen == index {
            return Some(list.prims.rects[i].rect);
        }
        seen += 1;
    }
    None
}

/// The fill a control paints for its `index`-th shape, in paint order.
/// 控件第 `index` 个形状的填充色，按绘制顺序。
pub(crate) fn shape_fill(lp: &AppLoop<Gallery>, id: Id, index: usize) -> Option<ui_core::geom::Color> {
    let nid = lp.tree().find_by_id(id)?;
    let list = lp.draw_list();
    let mut seen = 0;
    for i in 0..list.prims.rects.len() {
        if list.owners.rects.get(i) != Some(&nid) {
            continue;
        }
        if seen == index {
            return Some(list.prims.rects[i].fill);
        }
        seen += 1;
    }
    None
}

/// The `index`-th arc a control paints, in paint order.
/// 控件第 `index` 段弧，按绘制顺序。
pub(crate) fn shape_sector(
    lp: &AppLoop<Gallery>,
    id: Id,
    index: usize,
) -> Option<ui_core::draw::SectorPrim> {
    let nid = lp.tree().find_by_id(id)?;
    let list = lp.draw_list();
    let mut seen = 0;
    for i in 0..list.prims.sectors.len() {
        if list.owners.sectors.get(i) != Some(&nid) {
            continue;
        }
        if seen == index {
            return Some(list.prims.sectors[i]);
        }
        seen += 1;
    }
    None
}

/// The effective ink of a node's first glyph: its colour times its coverage multiplier.
/// 节点第一个字形的有效墨色：颜色乘上覆盖率系数。
pub(crate) fn glyph_ink(lp: &AppLoop<Gallery>, id: Id) -> Option<ui_core::geom::Color> {
    let nid = lp.tree().find_by_id(id)?;
    let list = lp.draw_list();
    let glyph = list
        .prims
        .glyphs
        .iter()
        .zip(&list.owners.glyphs)
        .find(|(_, owner)| **owner == nid)
        .map(|(glyph, _)| glyph)?;
    Some(ui_core::geom::Color { a: glyph.color.a * glyph.alpha, ..glyph.color })
}

/// The ink a text node asks for, before shaping: its declared colour and alpha.
/// 文本节点请求的墨色，早于整形：它声明的颜色与透明度。
pub(crate) fn text_ink(lp: &AppLoop<Gallery>, id: Id) -> Option<ui_core::geom::Color> {
    let nid = lp.tree().find_by_id(id)?;
    match &lp.tree().get(nid)?.data {
        ui_core::NodeData::Text { ink, .. } => Some(*ink),
        _ => None,
    }
}

/// Press and release at `at` without settling, then run `frames` 16ms frames: the caller
/// decides how far into the 500ms selection animation it is looking.
/// 在 `at` 处按下并松开但不等落定，再推进 `frames` 个 16ms 帧：由调用方决定看动画的哪一段。
pub(crate) fn tap(lp: &mut AppLoop<Gallery>, size: (u32, u32), at: Point, frames: u32) {
    let button = ui_core::PointerButton::Primary;
    lp.dispatch(ui_core::Event::PointerMoved { pos: at });
    step(lp, size, at, 1);
    lp.dispatch(ui_core::Event::PointerPressed { pos: at, button });
    step(lp, size, at, 1);
    lp.dispatch(ui_core::Event::PointerReleased { pos: at, button });
    lp.dispatch(ui_core::Event::PointerMoved { pos: at });
    step(lp, size, at, frames);
}

/// The last shape a control paints: for a switch that is the thumb.
/// 控件绘制的最后一个形状：对开关而言就是滑块。
pub(crate) fn last_shape_rect(lp: &AppLoop<Gallery>, id: Id) -> Option<Rect> {
    let nid = lp.tree().find_by_id(id)?;
    let list = lp.draw_list();
    let mut last = None;
    for i in 0..list.prims.rects.len() {
        if list.owners.rects.get(i) == Some(&nid) {
            last = Some(list.prims.rects[i].rect);
        }
    }
    last
}

/// The largest-area shape a node paints — the handle, ignoring the icon bars that now follow it.
/// 节点绘制的面积最大的形状——滑块，忽略其后新增的图标条。
pub(crate) fn biggest_shape_rect(lp: &AppLoop<Gallery>, id: Id) -> Option<Rect> {
    let nid = lp.tree().find_by_id(id)?;
    let list = lp.draw_list();
    let mut best: Option<Rect> = None;
    for i in 0..list.prims.rects.len() {
        if list.owners.rects.get(i) == Some(&nid) {
            let r = list.prims.rects[i].rect;
            // The handle is a square (rest states) or the 34x22 pill (mid-transition); a square
            // wider than 34 is the track or a focus ring, both fixed. The splash is a circle,
            // so requiring a square excludes it.
            // 滑块在静止态是正方形、过渡中是 34×22 胶囊；边长超过 34 的正方形是轨道或焦点环，均固定。
            // 涟漪是正圆，要求正方形即可排除它。
            let square = (r.size.w - r.size.h).abs() < 0.5;
            // A handle never exceeds 34; the splash is 40 and the track 52, both excluded.
            // 滑块不超过 34；涟漪 40、轨道 52，都被排除。
            if !square || r.size.w > 34.5 {
                continue;
            }
            let area = r.size.w * r.size.h;
            if best.map(|b| area > b.size.w * b.size.h).unwrap_or(true) {
                best = Some(r);
            }
        }
    }
    best
}

/// Whether two rects agree to within half a pixel on every edge.
/// 两个矩形在每条边上相差不超过半像素。
pub(crate) fn close_rect(a: Rect, b: Rect) -> bool {
    (a.origin.x - b.origin.x).abs() <= 0.5
        && (a.origin.y - b.origin.y).abs() <= 0.5
        && (a.size.w - b.size.w).abs() <= 0.5
        && (a.size.h - b.size.h).abs() <= 0.5
}

pub(crate) fn center(r: Rect) -> Point {
    Point::new(
        r.origin.x + r.size.w * 0.5,
        r.origin.y + r.size.h * 0.5,
    )
}

pub(crate) fn frame(lp: &mut AppLoop<Gallery>, size: (u32, u32), pointer: Option<Point>) {
    // A full second settles every retargeted instance, so geometry is comparable.
    // 一整秒让所有重定向实例落定，几何才可比。
    let _ = timed!("build_scripted", lp.build_with_dt(size, pointer, 1.0));
}

pub(crate) fn click(lp: &mut AppLoop<Gallery>, size: (u32, u32), at: Point) {
    let button = ui_core::PointerButton::Primary;
    lp.dispatch(ui_core::Event::PointerMoved { pos: at });
    frame(lp, size, Some(at));
    lp.dispatch(ui_core::Event::PointerPressed { pos: at, button });
    frame(lp, size, Some(at));
    lp.dispatch(ui_core::Event::PointerReleased { pos: at, button });
    // The real loop dispatches a whole burst before one frame (`run`'s `take_events` loop);
    // a motion right behind the release must not erase the click.
    // 真实循环在一帧之前派发整批事件（`run` 的 `take_events` 循环）；
    // 松手之后紧跟的移动不得抹掉这次点击。
    lp.dispatch(ui_core::Event::PointerMoved { pos: at });
    frame(lp, size, Some(at));
    // A page swap converges over a few `Tree::apply` frames; settle before reading geometry.
    // 换页要几帧 `Tree::apply` 才收敛；读几何前先让帧稳定。
    for _ in 0..4 {
        frame(lp, size, Some(at));
    }
}

/// Press at `from`, travel to `to` in steps, release: a swipe the tree can follow.
/// 在 `from` 按下、分步移到 `to`、松手：树能跟得上的滑动。
pub(crate) fn drag(lp: &mut AppLoop<Gallery>, size: (u32, u32), from: Point, to: Point) {
    let button = ui_core::PointerButton::Primary;
    lp.dispatch(ui_core::Event::PointerMoved { pos: from });
    frame(lp, size, Some(from));
    lp.dispatch(ui_core::Event::PointerPressed { pos: from, button });
    frame(lp, size, Some(from));
    // Past the engine's drag threshold first, then on to the destination.
    // 先越过引擎的拖拽阈值，再走到目的地。
    const STEPS: u32 = 6;
    for k in 1..=STEPS {
        let t = k as f32 / STEPS as f32;
        let at = Point::new(from.x + (to.x - from.x) * t, from.y + (to.y - from.y) * t);
        lp.dispatch(ui_core::Event::PointerMoved { pos: at });
        frame(lp, size, Some(at));
    }
    lp.dispatch(ui_core::Event::PointerReleased { pos: to, button });
    for _ in 0..4 {
        frame(lp, size, Some(to));
    }
}

/// Wheel the nav to `target` through the real input path, which also invalidates the
/// declaration cache; writing the app field directly would leave the old decl in place.
/// 用真实输入路径把导航滚到 `target`；直接写应用字段会留下旧的声明缓存。
pub(crate) fn scroll_nav_to(lp: &mut AppLoop<Gallery>, size: (u32, u32), target: f32) {
    let Some(view) = rect_of(lp, NAV_SCROLL) else {
        return;
    };
    let over = center(view);
    let cur = lp.scroll_of(NAV_SCROLL).unwrap_or(0.0);
    let delta = target - cur;
    lp.dispatch(ui_core::Event::PointerMoved { pos: over });
    lp.dispatch(ui_core::Event::wheel(over, delta));
    frame(lp, size, Some(over));
}

/// Wheel the nav until `id`'s centre is inside the scroller, so it can be clicked.
/// 用滚轮滚动导航，直到 `id` 的中心落在滚动容器内，于是它可以被点到。
pub(crate) fn scroll_into_view(lp: &mut AppLoop<Gallery>, size: (u32, u32), id: Id) {
    let item_opt = rect_of(lp, id);
    let view_opt = rect_of(lp, NAV_SCROLL);
    let (Some(item), Some(view)) = (item_opt, view_opt) else {
        return;
    };
    let target = center(item);
    let top = view.origin.y;
    let bottom = view.origin.y + view.size.h;
    if target.y >= top && target.y <= bottom {
        return;
    }
    // The item's visual centre is `content_y - scroll`; the scroll that puts it inside
    // the viewport is solved directly, so a deep item lands in one wheel event.
    // item 的视觉中心是 `content_y - scroll`；能把它放进视口的滚动值直接解出，
    // 深层条目一次滚轮事件即到位。
    let cur = lp.scroll_of(NAV_SCROLL).unwrap_or(0.0);
    // Above the viewport the content must move down, i.e. `scroll` shrinks: the delta is
    // `target.y - top - 32`, not the mirrored `top - target.y + 32`, which scrolls the
    // wrong way and leaves the item further out of reach.
    // item 在视口上方时内容要下移、即 `scroll` 减小：delta 是 `target.y - top - 32`，
    // 镜像的 `top - target.y + 32` 会把滚动方向搞反、让 item 更够不着。
    let want = if target.y > bottom {
        target.y - bottom + 32.0
    } else {
        target.y - top - 32.0
    };
    scroll_nav_to(lp, size, cur + want);
}

/// Scroll a page's nav row into the scroller, then click it.
/// 把某页在导航里的行滚进滚动容器，再点击它。
pub(crate) fn goto(lp: &mut AppLoop<Gallery>, size: (u32, u32), page: Page) {
    scroll_into_view(lp, size, page.nav_id());
    nav_click(lp, size, page);
}

/// Click a nav row; each open popup eats one tap, and the menu page opens two.
/// 点击导航行；每个打开着的浮层吃掉一次点击，而菜单页同时开了两个。
pub(crate) fn nav_click(lp: &mut AppLoop<Gallery>, size: (u32, u32), page: Page) {
    for _ in 0..3 {
        let nav = rect_of(lp, page.nav_id()).expect("nav item");
        click(lp, size, center(nav));
        if lp.app_mut().page == page {
            return;
        }
    }
}

/// The column tags a page draws, in render order: one where the page shows a single style.
/// 页面绘制的列标签，按渲染顺序：只演示一种风格的页面只有一列。
pub(crate) fn page_tags(page: Page) -> &'static [&'static str] {
    match page {
        // The pack-driven page shows one widget kind per column, not one style per column.
        // 包驱动页每列展示一类控件，而不是每种风格一列。
        Page::Generic => &["card", "list", "panel"],
        // One column per aspect of the system: colours, dimensions, provenance.
        // 每个方面一列：颜色、尺寸、来源。
        Page::Md3System | Page::FluentSystem | Page::HigSystem => {
            &["colours", "dimensions", "source"]
        }
        // One column per icon set: the set is the axis, not the style.
        // 每套字族一列：轴是字族，不是风格。
        Page::Icons => &["outlined", "rounded", "sharp"],
        // One column per inline case: baseline pair, mixed alignments, narrow block.
        // 每种行内情形一列：基线成对、混合对齐、窄块。
        Page::Inline => &["baseline", "mixed", "narrow"],
        // One column per positioning case: relative, absolute, fixed + z.
        // 每种定位情形一列：相对、绝对、固定 + z。
        Page::Positioning => &["relative", "absolute", "fixed"],
        // A dialog needs a host column of its own; the Fluent column cannot be the narrow one.
        // 对话框需要自己的宿主列；Fluent 列不能是别处那种窄列。
        Page::Dialogs => &["md3", "host", "fluent", "glass"],
        // WinUI controls the other packs do not have yet: one Fluent column.
        // 其余包还没有的 WinUI 控件：只有一列 Fluent。
        // The menu page pairs WinUI's flyout with the glass panel it has no counterpart for.
        // 菜单页把 WinUI 的浮出与它没有对应物的玻璃面板并排。
        Page::MenuFlyout => &["fluent", "glass"],
        // The text-mode date input takes the place of this page's two placeholder columns.
        // 文本模式的日期输入占用了本页两条占位列的位置。
        Page::DatePicker => &["md3", "md3-input"],
        Page::ToolTip | Page::InfoBar | Page::Combo | Page::NavView => &["fluent"],
        _ => &[STYLES[0].0, STYLES[1].0, STYLES[2].0],
    }
}

/// Report a page's columns and whether they are disjoint.
/// 报告某页的列，并检查它们互不重叠。
pub(crate) fn columns_ok(lp: &AppLoop<Gallery>, page: Page) -> Option<Vec<Rect>> {
    let tags = page_tags(page);
    let mut rects = vec![Rect::ZERO; tags.len()];
    for (i, tag) in tags.iter().enumerate() {
        let r = rect_of(lp, col_id(page, tag))?;
        if r.size.w <= 0.0 || r.size.h <= 0.0 {
            return None;
        }
        rects[i] = r;
    }
    for i in 0..tags.len() {
        for j in (i + 1)..tags.len() {
            let a = rects[i];
            let b = rects[j];
            let overlap_x = a.origin.x < b.origin.x + b.size.w && b.origin.x < a.origin.x + a.size.w;
            let overlap_y = a.origin.y < b.origin.y + b.size.h && b.origin.y < a.origin.y + a.size.h;
            if overlap_x && overlap_y {
                println!("selftest: columns overlap on {page:?}");
                return None;
            }
        }
    }
    Some(rects)
}

/// Hand the engine's clipboard requests to the seat: the platform half of the split.
/// 把引擎的剪贴板请求交给座位：这层分工的平台半边。
pub(crate) fn route_clipboard(session: &mut Session<Gallery>) {
    use ui_platform::clipboard::{ClipboardCommand, ClipboardKind};
    let (lp, win, _) = session.split();
    for cmd in lp.take_clipboard_commands() {
        match cmd {
            ClipboardCommand::Copy { text, kind } => {
                if kind == ClipboardKind::Selection {
                    win.write_clipboard(&text);
                }
            }
            ClipboardCommand::RequestPaste { kind } => {
                if kind == ClipboardKind::Selection {
                    win.request_paste();
                }
            }
        }
    }
}

pub(crate) fn nav_and_columns(lp: &mut AppLoop<Gallery>, size: (u32, u32)) -> bool {
    let mut pass = true;
    let mut nav_ok = 0;
    let mut cols_ok = 0;

    for page in PAGES {
        scroll_into_view(lp, size, page.nav_id());
        if rect_of(lp, page.nav_id()).is_none() {
            println!("selftest: nav item {:?} is missing", page);
            std::process::exit(1);
        }
        nav_click(lp, size, page);
        if lp.app_mut().page == page {
            nav_ok += 1;
        } else {
            println!("selftest: click did not switch to {:?}", page);
            pass = false;
        }
        // The materials page is a settings pane beside a stage, so it has no three columns
        // to be disjoint: asking it for the other pages' layout would only ever fail.
        // 材质页是设置栏加舞台，没有三列可分：按别的页的布局去要求它只会永远失败。
        if page == Page::Materials {
            cols_ok += 1;
            continue;
        }
        match columns_ok(lp, page) {
            Some(rects) => {
                cols_ok += 1;
                let sizes: Vec<String> = page_tags(page)
                    .iter()
                    .zip(rects)
                    .map(|(_, r)| format!("[{:.0}x{:.0}]", r.size.w, r.size.h))
                    .collect();
                println!(
                    "selftest: {:?} columns {} disjoint ✓",
                    page,
                    sizes.join(", ")
                );
            }
            None => {
                println!("selftest: {:?} columns are missing or overlap", page);
                pass = false;
            }
        }
    }
    println!("selftest: nav click {nav_ok}/{} pages ✓", PAGES.len());
    println!("selftest: three columns {cols_ok}/{} pages ✓", PAGES.len());

    // The three design-system pages must actually render their columns and content.
    // 三个设计体系页必须真的渲染出各列与内容。
    // The nav loop above already clicked each page in order, so the last page visited was
    // HigSystem; visit the three system pages again through the same click path.
    // 上面的导航循环已按顺序点过每页，最后停在 HigSystem；用同一条点击路径再走三页。
    let mut sys_ok = 0;
    scroll_nav_to(lp, size, 0.0);
    for page in [Page::Md3System, Page::FluentSystem, Page::HigSystem] {
        scroll_into_view(lp, size, page.nav_id());
        let nav = rect_of(lp, page.nav_id()).expect("system nav item");
        click(lp, size, center(nav));
        let cols = columns_ok(lp, page);
        // Ids are hashes; holding them is the only reliable way to look them up, so the
        // page helper publishes them through a registry the selftest can read.
        // id 是哈希值，只能靠持有；页面把生成的 id 注册进表供自检读取。
        // Count rows we both emitted and can still find in the tree.
        // 统计既已发射、又能在树里找到的行。
        let has_common = SYSTEM_ROWS.with(|r| {
            r.common.borrow().iter().filter(|id| rect_of(lp, **id).is_some()).count()
        }) > 0;
        let has_dim = SYSTEM_ROWS.with(|r| {
            r.dims.borrow().iter().filter(|id| rect_of(lp, **id).is_some()).count()
        }) > 0;
        let has_src = SYSTEM_ROWS.with(|r| {
            r.source.borrow().iter().filter(|id| rect_of(lp, **id).is_some()).count()
        }) > 0;
        if cols.is_some() && has_common && has_dim && has_src {
            sys_ok += 1;
        } else {
            println!(
                "selftest: {:?} system page incomplete (cols={} common={has_common} dims={has_dim} src={has_src})",
                page,
                cols.is_some()
            );
        }
    }
    println!("selftest: system pages {sys_ok}/3 complete ✓");
    // Leave the nav where every later test expects it: scrolled to the top.
    // 让导航回到后续测试期望的位置：滚到顶端。
    scroll_nav_to(lp, size, 0.0);
    pass
}

/// Synthetic input against the real tree: nav, columns, and the kept semantic value.
/// 对真实树发合成输入：导航、三列，以及被保留的语义值。
pub(crate) fn selftest(lp: &mut AppLoop<Gallery>, size: (u32, u32)) {
    frame(lp, size, None);

    let mut pass = true;
    if !nav_and_columns(lp, size) {
        pass = false;
    }
    let (slider_ok, dragged, drag_ok) = slider(lp, size);
    if !slider_ok {
        pass = false;
    }
    if !tabs(lp, size) {
        pass = false;
    }
    if !buttons(lp, size) {
        pass = false;
    }
    if !fab_menu(lp, size) {
        pass = false;
    }
    if !chips(lp, size) {
        pass = false;
    }
    if !cards(lp, size) {
        pass = false;
    }
    if !lists(lp, size) {
        pass = false;
    }
    if !switch_state(lp, size, dragged, drag_ok) {
        pass = false;
    }
    if !checkbox(lp, size) {
        pass = false;
    }
    if !radio(lp, size) {
        pass = false;
    }
    if !dialogs(lp, size) {
        pass = false;
    }
    if !action_sheet(lp, size) {
        pass = false;
    }
    if !toast(lp, size) {
        pass = false;
    }
    if !modal_sheet(lp, size) {
        pass = false;
    }
    if !stepper(lp, size) {
        pass = false;
    }
    if !date_picker(lp, size) {
        pass = false;
    }
    if !time_picker(lp, size) {
        pass = false;
    }
    if !progress(lp, size) {
        pass = false;
    }
    if !segmented(lp, size) {
        pass = false;
    }
    if !nav_bar(lp, size) {
        pass = false;
    }
    if !nav_rail(lp, size) {
        pass = false;
    }
    if !nav_drawer(lp, size) {
        pass = false;
    }
    if !toolbar(lp, size) {
        pass = false;
    }
    if !snackbar(lp, size) {
        pass = false;
    }
    if !search(lp, size) {
        pass = false;
    }
    if !app_bar(lp, size) {
        pass = false;
    }
    if !carousel(lp, size) {
        pass = false;
    }
    if !text_field(lp, size) {
        pass = false;
    }
    if !text_field_caret(lp, size) {
        pass = false;
    }
    if !fab_page(lp, size) {
        pass = false;
    }
    if !menu_flyout(lp, size) {
        pass = false;
    }
    if !combo(lp, size) {
        pass = false;
    }
    if !nav_view(lp, size) {
        pass = false;
    }
    if !grid(lp, size) {
        pass = false;
    }
    if !inline(lp, size) {
        pass = false;
    }
    if !positioning(lp, size) {
        pass = false;
    }
    if !cursor(lp, size) {
        pass = false;
    }
    if !icons(lp, size) {
        pass = false;
    }
    if !selection(lp, size) {
        pass = false;
    }
    if !text_field_ime(lp, size) {
        pass = false;
    }
    if !glass_text_field(lp, size) {
        pass = false;
    }
    if !glass_search_bar(lp, size) {
        pass = false;
    }

    println!("selftest: {}", if pass { "PASS" } else { "FAIL" });
    if !pass {
        std::process::exit(1);
    }
}
