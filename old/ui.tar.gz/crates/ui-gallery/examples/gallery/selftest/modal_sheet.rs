// Self-test checks for the modal sheet page.
// 模态面板页的自检。

use ui_widgets_glass::{SHEET_BOTTOM, SHEET_FULL_TOP, SHEET_HALF, SHEET_MARGIN};

use crate::selftest::*;

pub(crate) fn modal_sheet(lp: &mut AppLoop<Gallery>, size: (u32, u32)) -> bool {
    let mut pass = true;
    let mark = |ok: bool| if ok { "✓" } else { "✗" };
    let w = size.0 as f32;
    let h = size.1 as f32;
    let half_top = h * (1.0 - SHEET_HALF);
    let full_top = SHEET_FULL_TOP;
    let segment = (half_top - full_top).max(1.0);

    let open = |lp: &mut AppLoop<Gallery>| {
        let trigger = rect_of(lp, modal_sheet_open_id()).expect("modal sheet trigger");
        click(lp, size, center(trigger));
    };
    // The settle spring caps its step at 0.1 s per frame, so a release needs several frames.
    // 落定弹簧每帧最多推进 0.1s，因此松手后要多走几帧。
    let settle = |lp: &mut AppLoop<Gallery>| {
        for _ in 0..8 {
            frame(lp, size, None);
        }
    };

    goto(lp, size, Page::ModalSheet);
    open(lp);

    // ── At half: 45 % of the window less the 6 dp bottom margin, 5 dp in from each side.
    // ── 半高：窗口的 45% 减去 6dp 底边距，两侧各内缩 5dp。
    let sheet = rect_of(lp, modal_sheet_body_id());
    let half = sheet.is_some_and(|r| {
        (r.origin.y - half_top).abs() < 0.5
            && (r.origin.x - SHEET_MARGIN).abs() < 0.5
            && (r.origin.x + r.size.w - (w - SHEET_MARGIN)).abs() < 0.5
            && (r.origin.y + r.size.h - (h - SHEET_BOTTOM)).abs() < 0.5
    });
    println!(
        "selftest: modal sheet half {:?} (want top {half_top}, bottom {}) {}",
        sheet.map(|r| (r.origin.x, r.origin.y, r.size.w, r.size.h)),
        h - SHEET_BOTTOM,
        mark(half)
    );
    pass &= half;

    // ── Dragging past 40 % of the half→full segment settles on full: 90 dp from the top,
    // ── edge to edge, and the app hears which detent it landed on.
    // ── 拖过半高→全高段落的 40% 即落定到全高：距顶端 90dp、两侧贴边，应用收到落定的档位。
    let handle = rect_of(lp, modal_sheet_body_id().with("handle")).expect("drag handle");
    let from = center(handle);
    drag(lp, size, from, Point::new(from.x, from.y - segment * 0.6));
    settle(lp);
    let sheet = rect_of(lp, modal_sheet_body_id());
    let full = sheet.is_some_and(|r| {
        (r.origin.y - full_top).abs() < 0.5
            && r.origin.x.abs() < 0.5
            && (r.origin.x + r.size.w - w).abs() < 0.5
            && (r.origin.y + r.size.h - h).abs() < 0.5
    });
    let heard = lp.app_mut().modal_detent == Some(Msg::GALLERY_MODAL_SHEET_FULL);
    println!(
        "selftest: modal sheet full {:?} (want top {full_top}) heard={heard} {}",
        sheet.map(|r| (r.origin.x, r.origin.y, r.size.w, r.size.h)),
        mark(full && heard)
    );
    pass &= full && heard;

    // ── Dragging back down past 40 % of the same segment returns it to half.
    // ── 再向下拖过同一段落的 40%，回到半高。
    let handle = rect_of(lp, modal_sheet_body_id().with("handle")).expect("drag handle");
    let from = center(handle);
    drag(lp, size, from, Point::new(from.x, from.y + segment * 0.6));
    settle(lp);
    let back = rect_of(lp, modal_sheet_body_id())
        .is_some_and(|r| (r.origin.y - half_top).abs() < 0.5);
    let heard = lp.app_mut().modal_detent == Some(Msg::GALLERY_MODAL_SHEET_HALF);
    println!(
        "selftest: modal sheet back to half {back} heard={heard} {}",
        mark(back && heard)
    );
    pass &= back && heard;

    // ── A drag down past the snap threshold closes it, and the app counts the dismissal.
    // ── 向下拖过阈值即关闭，应用计一次关闭。
    let before = lp.app_mut().modal_dismissed;
    let handle = rect_of(lp, modal_sheet_body_id().with("handle")).expect("drag handle");
    let from = center(handle);
    drag(lp, size, from, Point::new(from.x, from.y + half_top * 0.6));
    let gone = rect_of(lp, modal_sheet_body_id()).is_none();
    let counted = lp.app_mut().modal_dismissed == before + 1;
    println!(
        "selftest: modal sheet swipe closed={gone} counted={counted} {}",
        mark(gone && counted)
    );
    pass &= gone && counted;

    // ── A press on the scrim above the sheet dismisses it too.
    // ── 在面板上方的遮罩上按下同样关闭它。
    open(lp);
    let before = lp.app_mut().modal_dismissed;
    click(lp, size, Point::new(w * 0.5, half_top * 0.5));
    let gone = rect_of(lp, modal_sheet_body_id()).is_none();
    let counted = lp.app_mut().modal_dismissed == before + 1;
    println!(
        "selftest: modal sheet scrim closed={gone} counted={counted} {}",
        mark(gone && counted)
    );
    pass &= gone && counted;

    // ── Escape closes it while it holds the keyboard.
    // ── 面板持有键盘时，Escape 关闭它。
    open(lp);
    let before = lp.app_mut().modal_dismissed;
    lp.dispatch(ui_core::Event::KeyPressed {
        key: ui_core::Key::Escape,
    });
    // The change reaches the app after that frame's build, so the sheet leaves on the next.
    // 变化在那一帧构建之后才到应用，面板因此到下一帧才消失。
    frame(lp, size, None);
    frame(lp, size, None);
    let gone = rect_of(lp, modal_sheet_body_id()).is_none();
    let counted = lp.app_mut().modal_dismissed == before + 1;
    println!(
        "selftest: modal sheet escape closed={gone} counted={counted} {}",
        mark(gone && counted)
    );
    pass &= gone && counted;

    // ── A press on the app's own button inside the sheet reaches the app, which closes it.
    // ── 面板内应用自己的按钮上的按下会到达应用，由应用关闭面板。
    open(lp);
    let done = rect_of(lp, modal_sheet_done_id()).expect("done button");
    click(lp, size, center(done));
    let closed = rect_of(lp, modal_sheet_body_id()).is_none() && !lp.app_mut().modal_open;
    println!("selftest: modal sheet content press closed={closed} {}", mark(closed));
    pass &= closed;
    pass
}
