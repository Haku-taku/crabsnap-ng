// Self-test checks for the buttons page and cursor.
// 按钮页与光标的自检。

use crate::selftest::*;

pub(crate) fn buttons(lp: &mut AppLoop<Gallery>, size: (u32, u32)) -> bool {
    let mut pass = true;
    // Buttons: the five size heights, and a toggle whose state the app owns.
    // 按钮：五档尺寸的高度，以及一个状态归应用所有的切换按钮。
    click(
        lp,
        size,
        center(rect_of(lp, Page::Buttons.nav_id()).expect("buttons nav")),
    );
    let want_h: [f32; 5] = [32.0, 40.0, 56.0, 96.0, 136.0];
    let tags = ["xs", "sm", "md", "lg", "xl"];
    let got_h: Vec<f32> = tags
        .iter()
        .map(|tag| {
            rect_of(lp, Id::of(("btn", Page::Buttons.tag(), *tag)))
                .map(|r| r.size.h)
                .unwrap_or(-1.0)
        })
        .collect();
    let sizes_ok = got_h.iter().zip(&want_h).all(|(got, want)| (got - want).abs() < 0.5);
    println!(
        "selftest: md3 button heights {got_h:?} (want {want_h:?}) {}",
        if sizes_ok { "✓" } else { "✗" }
    );
    let before = lp.app_mut().btn_sel[0];
    click(
        lp,
        size,
        center(rect_of(lp, btn_toggle_id(0)).expect("toggle button")),
    );
    let after = lp.app_mut().btn_sel[0];
    println!(
        "selftest: md3 button toggle {before}->{after} {}",
        if after != before { "✓" } else { "✗" }
    );
    if !(sizes_ok && after != before) {
        pass = false;
    }

    // The glass capsules: 56dp squares, and a labelled one that grows past its height.
    // 玻璃胶囊：56dp 方形，以及一个比高度更宽的带文字胶囊。
    let icon = rect_of(lp, glass_btn_id(0));
    let labelled = rect_of(lp, glass_label_btn_id(0));
    let shapes_ok = icon.is_some_and(|r| (r.size.w - 56.0).abs() < 0.5 && (r.size.h - 56.0).abs() < 0.5)
        && labelled.is_some_and(|r| r.size.w > r.size.h && (r.size.h - 44.0).abs() < 0.5);
    println!(
        "selftest: glass buttons icon {:?}, labelled {:?} {}",
        icon.map(|r| (r.size.w, r.size.h)),
        labelled.map(|r| (r.size.w, r.size.h)),
        if shapes_ok { "✓" } else { "✗" }
    );
    if !shapes_ok {
        pass = false;
    }

    // A press on a glass capsule reaches the app; a disabled one stays silent.
    // 按下玻璃胶囊会抵达应用；禁用的那一个保持沉默。
    let before = lp.app_mut().glass_press;
    click(lp, size, center(rect_of(lp, glass_btn_id(0)).expect("glass icon button")));
    let pressed = lp.app_mut().glass_press;
    let disabled = Id::of(("btn", Page::Buttons.tag(), "glass", "disabled"));
    click(lp, size, center(rect_of(lp, disabled).expect("disabled glass button")));
    let after = lp.app_mut().glass_press;
    let press_ok = pressed == before + 1 && after == pressed;
    println!(
        "selftest: glass button presses {before}->{pressed}, disabled stays {after} {}",
        if press_ok { "✓" } else { "✗" }
    );
    if !press_ok {
        pass = false;
    }

    // Held down, the face inflates by a fixed 17 dp on its longest side and comes back.
    // 按住时面在最长边上固定长出 17dp，松手后复原。
    let face = glass_btn_id(0).with("face");
    let rest_w = rect_of(lp, face).map_or(0.0, |r| r.size.w);
    let at = center(rect_of(lp, glass_btn_id(0)).expect("glass icon button"));
    lp.dispatch(ui_core::Event::PointerMoved { pos: at });
    step(lp, size, at, 1);
    lp.dispatch(ui_core::Event::PointerPressed {
        pos: at,
        button: ui_core::PointerButton::Primary,
    });
    step(lp, size, at, 30);
    let pressed_w = rect_of(lp, face).map_or(0.0, |r| r.size.w);
    lp.dispatch(ui_core::Event::PointerReleased {
        pos: at,
        button: ui_core::PointerButton::Primary,
    });
    step(lp, size, at, 60);
    let back_w = rect_of(lp, face).map_or(0.0, |r| r.size.w);
    let inflate_ok = (rest_w - 56.0).abs() < 0.5
        && pressed_w > rest_w + 12.0
        && (back_w - rest_w).abs() < 0.5;
    println!(
        "selftest: glass button face {rest_w:.1} -> {pressed_w:.1} held -> {back_w:.1} released {}",
        if inflate_ok { "✓" } else { "✗" }
    );
    if !inflate_ok {
        pass = false;
    }
    pass
}

pub(crate) fn cursor(lp: &mut AppLoop<Gallery>, size: (u32, u32)) -> bool {
    let mut pass = true;
    // The cursor is a per-frame output resolved from the hover path: a control that declares a
    // hand must yield one, and bare ground must fall back to the arrow. No pixel carries this,
    // so nothing else can catch a shape that is produced but never applied.
    // 光标是从悬停路径逐帧解析的输出：声明了手形的控件必须给出它，空白处回落箭头。
    // 没有任何像素携带这个信息，因此「算出来但没应用」只有这里能抓到。
    goto(lp, size, Page::Buttons);
    let over = center(rect_of(lp, btn_toggle_id(0)).expect("toggle button"));
    lp.dispatch(ui_core::Event::PointerMoved { pos: over });
    let on_control = lp.build_with_dt(size, Some(over), 1.0).cursor;
    let ground = Point::new(size.0 as f32 - 4.0, size.1 as f32 - 4.0);
    lp.dispatch(ui_core::Event::PointerMoved { pos: ground });
    let on_ground = lp.build_with_dt(size, Some(ground), 1.0).cursor;
    let cursor_ok = on_control == ui_core::CursorShape::PointingHand
        && on_ground == ui_core::CursorShape::Arrow;
    println!(
        "selftest: cursor over a button {on_control:?}, over bare ground {on_ground:?} {}",
        if cursor_ok { "✓" } else { "✗" }
    );
    if !cursor_ok {
        pass = false;
    }
    pass
}
