// Self-test checks for the navigation drawer page.
// 导航抽屉页的自检。

use crate::selftest::*;

pub(crate) fn nav_drawer(lp: &mut AppLoop<Gallery>, size: (u32, u32)) -> bool {
    let mut pass = true;
    goto(lp, size, Page::NavDrawer);

    // The drawer is the export's 360dp wide and fills the height its parent gives it.
    // 抽屉是导出的 360dp 宽，并撑满父容器给它的高度。
    let width_ok = rect_of(lp, drawer_id())
        .map(|r| (r.size.w - 360.0).abs() < 0.5 && (r.size.h - 280.0).abs() < 0.5)
        .unwrap_or(false);
    println!("selftest: drawer 360 wide and 280 tall {}", if width_ok { "✓" } else { "✗" });
    if !width_ok {
        pass = false;
    }

    click(lp, size, center(rect_of(lp, drawer_item_id(1)).expect("drawer item 1")));
    let picked = lp.app_mut().drawer_sel;
    println!("selftest: drawer picked {picked} {}", if picked == 1 { "✓" } else { "✗" });
    if picked != 1 {
        pass = false;
    }
    pass
}
