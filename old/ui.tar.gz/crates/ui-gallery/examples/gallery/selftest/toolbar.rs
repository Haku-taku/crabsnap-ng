// Self-test checks for the toolbar page.
// 工具条页的自检。

use crate::selftest::*;

pub(crate) fn toolbar(lp: &mut AppLoop<Gallery>, size: (u32, u32)) -> bool {
    let mut pass = true;
    goto(lp, size, Page::Toolbar);

    // Docked fills its parent; floating hugs its four slots, so it must be narrower.
    // 停靠式撑满父容器；浮动式贴合四个槽位，因此必然更窄。
    let docked = rect_of(lp, toolbar_id("docked-standard")).map(|r| r.size.w);
    let floating = rect_of(lp, toolbar_id("floating-standard")).map(|r| r.size.w);
    let widths_ok = matches!((docked, floating), (Some(d), Some(f)) if f < d);
    println!(
        "selftest: toolbar docked {docked:?} wider than floating {floating:?} {}",
        if widths_ok { "✓" } else { "✗" }
    );
    if !widths_ok {
        pass = false;
    }

    // All four bars share one selection.
    // 四条栏共用一个选中项。
    click(
        lp,
        size,
        center(rect_of(lp, toolbar_action_id("docked-standard", 2)).expect("toolbar action 2")),
    );
    let picked = lp.app_mut().toolbar_sel;
    println!("selftest: toolbar picked {picked:?} {}", if picked == Some(2) { "✓" } else { "✗" });
    if picked != Some(2) {
        pass = false;
    }
    pass
}
