// Self-test checks for the inline page: atoms sit inside their line, never under glyphs.
// 行内页的自检：原子落在自己的行盒内，绝不压在字形下面。

use crate::selftest::*;

const EPS: f32 = 0.51;

pub(crate) fn inline(lp: &mut AppLoop<Gallery>, size: (u32, u32)) -> bool {
    // The nav may have been scrolled away by an earlier check, so bring the row back first.
    // 先前的检查可能把导航滚走了，因此先把这一行滚回来。
    goto(lp, size, Page::Inline);
    let mut pass = true;
    let mut good = 0usize;
    for (tag, width) in INLINE_SAMPLES {
        let mut bad = Vec::new();
        let id = inline_text_id(tag);
        let Some(nid) = lp.tree().find_by_id(id) else {
            println!("selftest: inline {tag} missing");
            pass = false;
            continue;
        };
        let Some(node) = lp.tree().get(nid) else {
            println!("selftest: inline {tag} has no node");
            pass = false;
            continue;
        };
        let Some(layout) = node.inline.clone() else {
            println!("selftest: inline {tag} has no layout");
            pass = false;
            continue;
        };
        let origin = node.visual_rect().origin;
        let mut atoms = 0usize;
        let mut own_row = false;
        for (index, line) in layout.lines.iter().enumerate() {
            for atom in &line.atoms {
                atoms += 1;
                // Inside its line box, on both axes.
                // 两个轴都落在自己的行盒内。
                if atom.x < -EPS
                    || atom.x + atom.size.w > line.width + EPS
                    || atom.y < -EPS
                    || atom.y + atom.size.h > line.height + EPS
                {
                    bad.push(format!(
                        "atom at {} sticks out of line {index} ({:.1}x{:.1})",
                        atom.at, line.width, line.height
                    ));
                }
                if index > 0 && atom.x.abs() < EPS {
                    own_row = true;
                }
                // No glyph of this block may paint over the atom's box.
                // 本块的任何字形都不得画到原子盒上。
                let rect = atom.rect(ui_core::geom::Point::new(origin.x, origin.y + line.y));
                let list = lp.draw_list();
                for (g, owner) in list.prims.glyphs.iter().zip(&list.owners.glyphs) {
                    if *owner != nid {
                        continue;
                    }
                    let hit_x = rect.origin.x + 1.0 < g.rect.origin.x + g.rect.size.w
                        && g.rect.origin.x + 1.0 < rect.origin.x + rect.size.w;
                    let hit_y = rect.origin.y + 1.0 < g.rect.origin.y + g.rect.size.h
                        && g.rect.origin.y + 1.0 < rect.origin.y + rect.size.h;
                    if hit_x && hit_y {
                        bad.push(format!(
                            "a glyph at ({:.1},{:.1}) paints into the atom at {}",
                            g.rect.origin.x, g.rect.origin.y, atom.at
                        ));
                    }
                }
            }
        }
        if atoms == 0 {
            bad.push("no atom on any line".to_string());
        }
        // The narrow sample must push its atom onto a line of its own.
        // 窄样本必须把它的原子推到单独一行。
        if tag == "narrow" && !own_row {
            bad.push("the wide atom shares a line instead of starting one".to_string());
        }
        if layout.width > width + EPS {
            bad.push(format!(
                "the block is {:.1} wide, over its {width:.1} box",
                layout.width
            ));
        }
        for line in &bad {
            println!("selftest: inline {tag}: {line}");
        }
        if bad.is_empty() {
            good += 1;
            let xs: Vec<String> = layout
                .lines
                .iter()
                .flat_map(|l| {
                    l.atoms
                        .iter()
                        .map(|a| format!("{:.1}@{:.1}/{:.1}", a.x, a.y, a.size.h))
                })
                .collect();
            let rows = layout
                .lines
                .iter()
                .enumerate()
                .map(|(i, l)| format!("[{i}] w{:.0} y{:.0} h{:.0}", l.width, l.y, l.height))
                .collect::<Vec<_>>()
                .join(" ");
            println!(
                "selftest: inline {tag} atoms={atoms} {} | rows {rows}",
                xs.join(" ")
            );
        } else {
            pass = false;
        }
    }
    println!(
        "selftest: inline samples {good}/{} keep atoms in their lines {}",
        INLINE_SAMPLES.len(),
        if good == INLINE_SAMPLES.len() { "✓" } else { "✗" }
    );
    pass
}
