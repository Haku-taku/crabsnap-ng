// Self-test checks for the search page.
// 搜索页的自检。

use crate::selftest::*;

pub(crate) fn search(lp: &mut AppLoop<Gallery>, size: (u32, u32)) -> bool {
    let mut pass = true;
    // Search bar: the query the engine edits lands on the app's buffer, and the bar's own
    // action names itself when clicked.
    goto(lp, size, Page::Search);
    let mut query_ok = false;    let mut acted_ok = false;
    if let Some(bar) = rect_of(lp, search_id()) {
        click(lp, size, center(bar));
        for c in "hel".chars() {
            lp.dispatch(ui_core::Event::Text(c.to_string()));
        }
        step(lp, size, center(bar), 2);
        query_ok = lp.app_mut().search_value == "hel";
        if let Some(action) = rect_of(lp, search_action_id()) {
            click(lp, size, center(action));
            acted_ok = lp.app_mut().search_acted.as_deref() == Some("mic");
        }
    }
    let query = lp.app_mut().search_value.clone();
    let acted = lp.app_mut().search_acted.clone();
    println!(
        "selftest: md3 search query \"{query}\" action={acted:?} {}",
        if query_ok && acted_ok { "✓" } else { "✗" }
    );
    if !(query_ok && acted_ok) {
        pass = false;
    }
    pass
}
