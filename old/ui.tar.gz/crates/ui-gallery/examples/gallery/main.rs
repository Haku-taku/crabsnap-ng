//! Acceptance gallery: one window, a nav tree on the left, three styles per section.
//! 验收 gallery：单窗口，左侧导航树，每节并列三种风格。

/// Times a block with hotpath under the `profile` feature, and is the block itself otherwise.
/// 开启 `profile` 特性时用 hotpath 给该块计时，否则就是该块本身。
macro_rules! timed {
    ($label:literal, $body:expr) => {{
        #[cfg(feature = "profile")]
        {
            hotpath::measure_block!($label, $body)
        }
        #[cfg(not(feature = "profile"))]
        {
            $body
        }
    }};
}

/// Heap traffic per frame: `GALLERY_ALLOC=1` for the `[hb]` counters, `GALLERY_ALLOC_SIZES=1`
/// for the size histogram, `GALLERY_ALLOC_SITES=1` for the top caller chains (1 in 64 sampled).
/// 每帧堆流量：`GALLERY_ALLOC=1` 出 `[hb]` 计数，`GALLERY_ALLOC_SIZES=1` 出大小直方图，
/// `GALLERY_ALLOC_SITES=1` 出调用链排行（每 64 次取一条）。关闭时只多一次分支。
struct Counting;

static ALLOC_ON: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
static SIZES_ON: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
static ALLOCS: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
static BYTES: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
static SIZES: [std::sync::atomic::AtomicU64; 15] =
    [const { std::sync::atomic::AtomicU64::new(0) }; 15];

fn size_class(n: usize) -> usize {
    match n {
        0..=8 => 0,
        9..=16 => 1,
        17..=24 => 2,
        25..=32 => 3,
        33..=48 => 4,
        49..=64 => 5,
        65..=96 => 6,
        97..=128 => 7,
        129..=256 => 8,
        257..=512 => 9,
        513..=1024 => 10,
        1025..=2048 => 11,
        2049..=4096 => 12,
        4097..=16384 => 13,
        _ => 14,
    }
}

/// Sampling switch and per-site tally: the caller chain of one allocation in 64.
/// 采样开关与调用点计票：每 64 次分配取一条调用链。
static SITES_ON: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
static SITES: std::sync::Mutex<Option<std::collections::HashMap<String, u64>>> =
    std::sync::Mutex::new(None);
thread_local! {
    static IN_PROBE: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}

/// The three innermost frames that are not the allocator plumbing itself.
/// 最内侧、且不属于分配器自身的那三帧。
#[inline(never)]
fn note_site() {
    let bt = std::backtrace::Backtrace::force_capture();
    let text = bt.to_string();
    let mut frames = Vec::with_capacity(3);
    for line in text.lines().skip(1) {
        let name = line.trim();
        if name.is_empty() || name.contains("backtrace") || name.contains("Counting") {
            continue;
        }
        frames.push(name.to_string());
        if frames.len() == 3 {
            break;
        }
    }
    let key = frames.join(" <- ");
    // Never block here: a lock held by the reporting path would wait on this very allocation.
    // 这里绝不阻塞：报告路径持锁时，它等的正是这次分配。
    if let Ok(mut slot) = SITES.try_lock()
        && let Some(map) = slot.as_mut()
    {
        *map.entry(key).or_insert(0) += 1;
    }
}

/// Count one allocation; sampling a caller chain every 64th when the site probe is on.
/// 记一次分配；调用点探针开启时每第 64 次采一条调用链。
unsafe fn count(size: usize) {
    use std::sync::atomic::Ordering::Relaxed;
    if !ALLOC_ON.load(Relaxed) {
        return;
    }
    let n = ALLOCS.fetch_add(1, Relaxed);
    BYTES.fetch_add(size as u64, Relaxed);
    if SIZES_ON.load(Relaxed) {
        SIZES[size_class(size)].fetch_add(1, Relaxed);
    }
    if SITES_ON.load(Relaxed) && !IN_PROBE.with(|p| p.get()) && n % 64 == 0 {
        IN_PROBE.with(|p| p.set(true));
        note_site();
        IN_PROBE.with(|p| p.set(false));
    }
}

unsafe impl std::alloc::GlobalAlloc for Counting {
    unsafe fn alloc(&self, l: std::alloc::Layout) -> *mut u8 {
        unsafe { count(l.size()) };
        unsafe { std::alloc::System.alloc(l) }
    }
    unsafe fn dealloc(&self, p: *mut u8, l: std::alloc::Layout) {
        unsafe { std::alloc::System.dealloc(p, l) }
    }
    unsafe fn realloc(&self, p: *mut u8, l: std::alloc::Layout, n: usize) -> *mut u8 {
        unsafe { count(n) };
        unsafe { std::alloc::System.realloc(p, l, n) }
    }
}

#[global_allocator]
static ALLOC: Counting = Counting;

mod app;
mod pages;
mod selftest;
mod shell;
mod wallpaper;

use crate::app::Gallery;
use crate::selftest::{dump_frame, frame, route_clipboard, selftest, step, want_dump};
use crate::shell::*;

/// Hand the loop the app's words for the engine's built-in text rows. Neither the locale
/// nor the bindings change during a run, so once is enough.
/// 把引擎内建文本行在应用里的措辞交给循环。一次运行中 locale 与绑定都不变，交一次即可。
fn sync_text_menu_labels(lp: &mut AppLoop<Gallery>) {
    let env = base_env();
    let Some(catalog) = env.find::<std::sync::Arc<ui_i18n::Catalog>>().cloned() else {
        return;
    };
    let row = |msg: Msg, id: ui_core::ShortcutId| ui_widgets::MenuRowText {
        label: catalog.text(msg).to_string(),
        shortcut: lp
            .shortcut(id)
            .map(|chord| ui_widgets::shortcut_label_in(&catalog, &chord)),
    };
    lp.set_text_menu_labels(Some(ui_widgets::TextMenuLabels {
        select_all: row(Msg::WIDGETS_MENU_SELECT_ALL, ui_core::ShortcutId::SELECT_ALL),
        copy: row(Msg::WIDGETS_MENU_COPY, ui_core::ShortcutId::COPY),
        cut: row(Msg::WIDGETS_MENU_CUT, ui_core::ShortcutId::CUT),
        paste: row(Msg::WIDGETS_MENU_PASTE, ui_core::ShortcutId::PASTE),
    }));
}

fn lifetime() -> f32 {
    std::env::var("GALLERY_SECONDS")
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(300.0)
}

/// `GALLERY_CAPTURE_SCALE=v` pins every glass capture's density: 1.0 shows the backdrop
/// without downsampling, where the frost normally pays for its blur with a coarse capture.
/// `GALLERY_CAPTURE_SCALE=v` 为每块玻璃钉住捕获密度：1.0 不降采样地显示背景，
/// 而磨砂通常正靠粗捕获换来模糊。
fn capture_scale() -> Option<f32> {
    std::env::var("GALLERY_CAPTURE_SCALE")
        .ok()
        .and_then(|s| s.trim().parse().ok())
        .filter(|v: &f32| v.is_finite() && *v > 0.0)
}

/// `GALLERY_SS=n` renders the scene at n× and box-averages down on present.
/// `GALLERY_SS=n` 以 n 倍分辨率渲染场景，呈现时箱式平均下来。
fn supersample() -> u32 {
    std::env::var("GALLERY_SS")
        .ok()
        .and_then(|s| s.parse().ok())
        .unwrap_or(1)
        .clamp(1, 4)
}

/// Milliseconds since the epoch, for correlating two processes' logs.
/// 自 epoch 起的毫秒数，用于对齐两个进程的日志。
fn epoch_ms() -> u128 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map_or(0, |d| d.as_millis())
}

/// This process's CPU time so far, in seconds: user plus system, from `/proc/self/stat`.
/// 本进程到目前为止的 CPU 时间（秒）：用户态加内核态，取自 `/proc/self/stat`。
fn cpu_seconds() -> f64 {
    let stat = std::fs::read_to_string("/proc/self/stat").unwrap_or_default();
    let fields: Vec<&str> = stat.split_whitespace().collect();
    let ticks: f64 = fields
        .get(13)
        .and_then(|s| s.parse().ok())
        .unwrap_or(0.0)
        + fields.get(14).and_then(|s| s.parse().ok()).unwrap_or(0.0);
    ticks / 100.0
}

/// `GALLERY_CLOSE_AFTER=n` closes the window itself after n seconds.
/// `GALLERY_CLOSE_AFTER=n` 在 n 秒后自己关闭窗口。
fn close_after() -> Option<f32> {
    std::env::var("GALLERY_CLOSE_AFTER")
        .ok()
        .and_then(|s| s.parse().ok())
}

/// `GALLERY_PRESS=x,y` holds one synthetic press there, so a screenshot can catch press-only
/// paint (ink, state layers) that a pointer sitting still never produces.
/// `GALLERY_PRESS=x,y` 在该处按住一次合成按下，使截图能拍到只在按压时出现的绘制
/// （墨迹、状态层），而停在原地的指针永远不会产生这些。
fn held_press() -> Option<Point> {
    let raw = std::env::var("GALLERY_PRESS").ok()?;
    let (x, y) = raw.split_once(',')?;
    Some(Point::new(x.trim().parse().ok()?, y.trim().parse().ok()?))
}

/// `GALLERY_CLICK=x,y` presses there, drags the pointer 300px away and releases.
/// `GALLERY_CLICK=x,y` 在那里按下，把指针拖到 300px 外再松手。
fn clicked_once() -> Option<Point> {
    let raw = std::env::var("GALLERY_CLICK").ok()?;
    let (x, y) = raw.split_once(',')?;
    Some(Point::new(x.trim().parse().ok()?, y.trim().parse().ok()?))
}

/// `GALLERY_HOLD=x,y,dx,dy` presses at `x,y`, moves the pointer by `dx,dy` and never
/// releases: the held-ink-after-leave shape a screenshot can read.
/// `GALLERY_HOLD=x,y,dx,dy` 在 `x,y` 按下、把指针移开 `dx,dy` 且不松手：
/// 这正是截图能读出的「移出后仍按着」形态。
fn held_and_left() -> Option<(Point, Point)> {
    let raw = std::env::var("GALLERY_HOLD").ok()?;
    let v: Vec<f32> = raw
        .split(',')
        .map(|s| s.trim().parse().ok())
        .collect::<Option<_>>()?;
    (v.len() == 4).then(|| (Point::new(v[0], v[1]), Point::new(v[0] + v[2], v[1] + v[3])))
}

/// `GALLERY_SWAY=x,y,dx,ms` presses there and sweeps to `x + dx` every `ms`, never releasing:
/// a wobble is a motion, so only a repeating sweep can be caught.
/// `GALLERY_SWAY=x,y,dx,ms` 在该处按下，每 `ms` 扫到 `x + dx` 且不松手：
/// 颤动是运动，只有循环扫动才拍得到。
fn sway_once() -> Option<(Point, Point, u64)> {
    let raw = std::env::var("GALLERY_SWAY").ok()?;
    let mut parts = raw.split(',');
    let x: f32 = parts.next()?.trim().parse().ok()?;
    let y: f32 = parts.next()?.trim().parse().ok()?;
    let dx: f32 = parts.next()?.trim().parse().ok()?;
    let ms: u64 = parts.next()?.trim().parse().ok()?;
    Some((Point::new(x, y), Point::new(x + dx, y), ms.max(16)))
}

/// `GALLERY_FOCUS=x,y` clicks there without dragging: the plain-click path, for focus.
/// `GALLERY_FOCUS=x,y` 在那里点一下而不拖拽：走普通点击路径，用于建立焦点。
fn focus_once() -> Option<Point> {
    let raw = std::env::var("GALLERY_FOCUS").ok()?;
    let (x, y) = raw.split_once(',')?;
    Some(Point::new(x.trim().parse().ok()?, y.trim().parse().ok()?))
}

/// `GALLERY_RIGHT=x,y` opens the context menu a right click would.
/// `GALLERY_RIGHT=x,y` 打开右键本会打开的上下文菜单。
fn right_once() -> Option<Point> {
    let raw = std::env::var("GALLERY_RIGHT").ok()?;
    let (x, y) = raw.split_once(',')?;
    Some(Point::new(x.trim().parse().ok()?, y.trim().parse().ok()?))
}

/// `GALLERY_CLIPBOARD=copy:<text>` puts text on the clipboard; `paste` asks for it.
/// `GALLERY_CLIPBOARD=copy:<text>` 把文本放上剪贴板；`paste` 向剪贴板索取。
fn clipboard_once() -> Option<String> {
    std::env::var("GALLERY_CLIPBOARD").ok()
}

/// `GALLERY_KEY=ctrl+a,ctrl+c` presses chords in order; the last part of each names the key.
/// `GALLERY_KEY=ctrl+a,ctrl+c` 依次按下多条组合键；每段最后一部分是键名。
fn key_once() -> Option<Vec<(ui_core::Modifiers, ui_core::Key)>> {
    let raw = std::env::var("GALLERY_KEY").ok()?;
    let mut out = Vec::new();
    for chord in raw.split(',') {
        let mut mods = ui_core::Modifiers::default();
        let mut key = None;
        for part in chord.split('+').map(str::trim) {
            key = Some(match part.to_ascii_lowercase().as_str() {
                "ctrl" => {
                    mods.ctrl = true;
                    continue;
                }
                "alt" => {
                    mods.alt = true;
                    continue;
                }
                "shift" => {
                    mods.shift = true;
                    continue;
                }
                "super" | "logo" => {
                    mods.logo = true;
                    continue;
                }
                "left" => ui_core::Key::Left,
                "right" => ui_core::Key::Right,
                "up" => ui_core::Key::Up,
                "down" => ui_core::Key::Down,
                "home" => ui_core::Key::Home,
                "end" => ui_core::Key::End,
                "enter" => ui_core::Key::Enter,
                "tab" => ui_core::Key::Tab,
                "space" => ui_core::Key::Space,
                "esc" => ui_core::Key::Escape,
                "backspace" => ui_core::Key::Backspace,
                "delete" => ui_core::Key::Delete,
                other => ui_core::Key::Char(other.chars().next()?),
            });
        }
        out.push((mods, key?));
    }
    Some(out)
}

/// `GALLERY_WHEEL=x,y,delta` sends one wheel notch at that point.
/// `GALLERY_WHEEL=x,y,delta` 在该点送入一格滚轮。
fn wheel_once() -> Option<(Point, f32)> {
    let raw = std::env::var("GALLERY_WHEEL").ok()?;
    let v: Vec<f32> = raw
        .split(',')
        .map(|s| s.trim().parse().ok())
        .collect::<Option<_>>()?;
    (v.len() == 3).then(|| (Point::new(v[0], v[1]), v[2]))
}

/// `GALLERY_DRAG=x1,y1,x2,y2` presses at the first point, drags to the second, releases.
/// `GALLERY_DRAG=x1,y1,x2,y2` 在第一点按下、拖到第二点、松手。
fn drag_once() -> Option<(Point, Point)> {
    let raw = std::env::var("GALLERY_DRAG").ok()?;
    let v: Vec<f32> = raw
        .split(',')
        .map(|s| s.trim().parse().ok())
        .collect::<Option<_>>()?;
    (v.len() == 4).then(|| (Point::new(v[0], v[1]), Point::new(v[2], v[3])))
}

/// `GALLERY_DRAGS=x1,y1,x2,y2;...` performs several drags in a row, a few frames apart.
/// `GALLERY_DRAGS=x1,y1,x2,y2;...` 连续做多次拖拽，每次之间隔几帧。
///
/// One drag per process cannot reach a state that only a second gesture on a still-moving
/// control creates; that is where a stuck gesture shows itself.
/// 一个进程只拖一次到不了「控件还在动时又按下一次」的状态，而卡住的手势正出在那里。
fn drags() -> Vec<(Point, Point)> {
    let Ok(raw) = std::env::var("GALLERY_DRAGS") else {
        return Vec::new();
    };
    raw.split(';')
        .filter_map(|one| {
            let v: Vec<f32> = one
                .split(',')
                .map(|s| s.trim().parse().ok())
                .collect::<Option<_>>()?;
            (v.len() == 4).then(|| (Point::new(v[0], v[1]), Point::new(v[2], v[3])))
        })
        .collect()
}

/// The part of an animation report that must change while something moves.
/// 动画报告中「只要还在动就必须变化」的那部分。
fn anim_key(report: &str) -> String {
    report
        .split(';')
        .map(|part| match part.find(" idle=") {
            Some(at) => part[..at].to_string(),
            None => part.to_string(),
        })
        .collect::<Vec<_>>()
        .join(";")
}

/// One tick per loop turn, so a watchdog can tell a hung process from a quiet one.
/// 每转一圈加一，看门狗据此分辨「卡死」与「没事干」。
static BEAT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);

/// Set by `GALLERY_PERF` once its reports are printed: the loop then leaves through its own
/// teardown instead of `exit`, which would kill the render threads mid-call.
/// `GALLERY_PERF` 打完报告后置位：循环照正常拆卸路径退出，而不是 `exit`——那会在渲染线程
/// 调用中途杀掉它们。
static STOP: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);

/// `GALLERY_STALL=secs`: if the loop stops turning for that long, capture stacks and exit.
/// `GALLERY_STALL=secs`：循环停转这么久就抓栈并退出。
///
/// A freeze is reported by whoever saw it, in the act: `perf` samples the hung threads while
/// they are still hung, so the report names the call that never returns.
/// 卡死由目击者当场取证：`perf` 在线程仍卡着时采样，报告因此点出那个不返回的调用。
fn watch_for_stalls() {
    let Ok(raw) = std::env::var("GALLERY_STALL") else {
        return;
    };
    let limit = raw.parse::<u64>().unwrap_or(5).max(2);
    std::thread::spawn(move || {
        let mut last = BEAT.load(std::sync::atomic::Ordering::Relaxed);
        let mut still = 0u64;
        loop {
            std::thread::sleep(std::time::Duration::from_secs(1));
            let now = BEAT.load(std::sync::atomic::Ordering::Relaxed);
            still = if now == last { still + 1 } else { 0 };
            last = now;
            if still >= limit {
                break;
            }
        }
        let pid = std::process::id();
        eprintln!("[stall] no loop turn for {limit}s in pid {pid}");
        for entry in std::fs::read_dir("/proc/self/task").into_iter().flatten().flatten() {
            let comm = std::fs::read_to_string(entry.path().join("comm")).unwrap_or_default();
            let stat = std::fs::read_to_string(entry.path().join("stat")).unwrap_or_default();
            let fields: Vec<&str> = stat.split_whitespace().collect();
            eprintln!(
                "[stall]   tid={} comm={} cpu={}",
                entry.file_name().to_string_lossy(),
                comm.trim(),
                fields.get(13).zip(fields.get(14)).map(|(a, b)| format!("{a}+{b}")).unwrap_or_default()
            );
        }
        let sample = std::process::Command::new("perf")
            .args(["record", "-g", "-o", "/tmp/stall.perf", "-p", &pid.to_string(), "--", "sleep", "2"])
            .status();
        eprintln!("[stall] perf record: {sample:?}");
        if let Ok(out) = std::process::Command::new("perf")
            .args(["report", "--stdio", "--no-children", "-g", "none", "-i", "/tmp/stall.perf"])
            .output()
        {
            let text = String::from_utf8_lossy(&out.stdout);
            for line in text.lines().take(60) {
                eprintln!("[stall] {line}");
            }
        }
        std::process::exit(3);
    });
}

/// `GALLERY_PERF=<wait>:<sample>`: sample this process with `perf` after `wait` seconds.
/// `GALLERY_PERF=<wait>:<sample>`：等待 wait 秒后用 `perf` 采样本进程 sample 秒。
///
/// Sampling runs while the app is live, so the profile covers what the user is doing then:
/// the flat list names the hot symbols, the caller tree names who called them.
/// 采样在应用运转时进行，因此画像正对用户当时的操作：平面表给热点符号，调用者树给调用来源。
fn watch_for_perf() {
    let Ok(raw) = std::env::var("GALLERY_PERF") else {
        return;
    };
    let mut parts = raw.split(':').map(|s| s.trim().parse::<u64>().unwrap_or(0));
    let wait = parts.next().unwrap_or(0).max(1);
    let sample = parts.next().unwrap_or(5).max(1);
    std::thread::spawn(move || {
        for left in (1..=wait).rev() {
            eprintln!("[perf] sampling in {left}s — interact with the window now");
            std::thread::sleep(std::time::Duration::from_secs(1));
        }
        let pid = std::process::id().to_string();
        eprintln!("[perf] sampling {sample}s of pid {pid}");
        let started = std::process::Command::new("perf")
            .args([
                "record",
                "-g",
                "-F",
                "999",
                "-o",
                "/tmp/hot.perf",
                "-p",
                &pid,
                "--",
                "sleep",
                &sample.to_string(),
            ])
            .status();
        eprintln!("[perf] record: {started:?}");
        for graph in ["none", "caller"] {
            eprintln!("[perf] ---- -g {graph} ----");
            let out = std::process::Command::new("perf")
                .args([
                    "report",
                    "--stdio",
                    "--no-children",
                    "-g",
                    graph,
                    "-i",
                    "/tmp/hot.perf",
                    "--percent-limit",
                    "0.3",
                ])
                .output();
            if let Ok(out) = out {
                for line in String::from_utf8_lossy(&out.stdout).lines().take(90) {
                    eprintln!("[perf] {line}");
                }
            }
        }
        eprintln!("[perf] done — closing the window");
        STOP.store(true, std::sync::atomic::Ordering::Relaxed);
    });
}

// Run: `WAYLAND_DISPLAY=wayland-2 cargo run -q -p ui-gallery --example gallery`
// 运行旋钮：GALLERY_CPU=1、GALLERY_SECONDS=n、GALLERY_SELFTEST=1、GALLERY_DUMP=1、GALLERY_SS=n、GALLERY_CAPTURE_SCALE=v、GALLERY_PRESS=x,y、GALLERY_CLICK=x,y、GALLERY_HOLD=x,y,dx,dy、GALLERY_FOCUS=x,y、GALLERY_TYPE=text、GALLERY_DRAG=x1,y1,x2,y2、GALLERY_DRAGS=a;b;…、GALLERY_STALL=secs、GALLERY_ANIM=1、GALLERY_SWAY=x,y,dx,ms、GALLERY_WHEEL=x,y,delta、GALLERY_CLIPBOARD=copy:text|paste、GALLERY_KEY=ctrl+shift+k、GALLERY_RIGHT=x,y、GALLERY_CLOSE_AFTER=n、GALLERY_WALLPAPER=path、GALLERY_SWITCH=帧:tag、GALLERY_HEARTBEAT=1、GALLERY_UNCAPPED=1、GALLERY_PERF=等待:采样、EXITDBG=1。
/// Let an outside debugger attach to this process; `yama.ptrace_scope=1` otherwise refuses.
/// 允许外部调试器附加；否则 `yama.ptrace_scope=1` 会拒绝。
fn allow_ptrace() {
    unsafe extern "C" {
        fn prctl(option: i32, ...) -> i32;
    }
    const PR_SET_PTRACER: i32 = 0x5961_6d61;
    const PR_SET_PTRACER_ANY: usize = usize::MAX;
    unsafe {
        prctl(PR_SET_PTRACER, PR_SET_PTRACER_ANY);
    }
}

#[cfg_attr(feature = "profile", hotpath::main)]
fn main() {
    if std::env::var_os("EXITDBG").is_some() {
        allow_ptrace();
    }
    let want_sizes = std::env::var_os("GALLERY_ALLOC_SIZES").is_some();
    let want_allocs = want_sizes
        || std::env::var_os("GALLERY_ALLOC").is_some()
        || std::env::var_os("GALLERY_ALLOC_SITES").is_some();
    ALLOC_ON.store(want_allocs, std::sync::atomic::Ordering::Relaxed);
    SIZES_ON.store(want_sizes, std::sync::atomic::Ordering::Relaxed);
    // Layout must measure with the same faces the painter rasterises: the monospace
    // estimate calls an icon 1 em wide at 0.6 em and its box no longer holds the glyph.
    // 布局必须用绘制所用的同一批字面来测量：固定字宽估算把 1 em 宽的图标算成 0.6 em，
    // 它的盒子就装不下字形了。
    let mut lp = AppLoop::with_stack(Gallery::new(), TEXT_STACK);
    // The engine ships no fonts: the host supplies the SF Symbols file the iOS controls use.
    // 引擎不自带字体：宿主提供 iOS 控件所用的 SF Symbols 文件。
    lp.register_font(
        ui_widgets::SF_SYMBOLS_FAMILY,
        include_bytes!("../../../assets/fonts/SFSymbols.ttf").as_slice().into(),
    );
    // Latin text: Inter is the closest open face to SF Pro, so the stack does not fall to
    // whichever sans the host happens to default to.
    // 拉丁文字：Inter 是离 SF Pro 最近的开源字面，字体栈因此不会落到宿主碰巧默认的那款无衬线。
    lp.register_font(
        TEXT_FAMILY,
        include_bytes!("../../../assets/fonts/InterVariable.ttf").as_slice().into(),
    );
    // WinUI draws its control glyphs from an icon face of its own; the Fluent controls
    // ask for it by the family they registered here.
    // WinUI 用一套自己的图标字面绘制控件字形；Fluent 控件按此处注册的族名索取。
    lp.register_font(
        ui_widgets_fluent::glyphs::ICON_FAMILY,
        include_bytes!("../../../assets/fonts/FluentSystemIcons-Regular.ttf")
            .as_slice()
            .into(),
    );
    let uncapped = std::env::var_os("GALLERY_UNCAPPED").is_some();
    if uncapped {
        eprintln!("[uncapped] frame pacing disabled: fps is throughput, not refresh");
    }
    let opts = SessionOptions {
        title: "crabsnap-ui   gallery".into(),
        app_id: "dev.crabsnap.ui.gallery".into(),
        width: WIN_W,
        height: WIN_H,
        uncapped,
        cpu_presenter: std::env::var("GALLERY_CPU").is_ok(),
    };
    let session = match Session::open(lp, opts) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("{e}");
            std::process::exit(1);
        }
    };
    if let Some(name) = session.presenter_name() {
        println!("gpu presenter: {name}");
    }
    run(session);
}

fn run(mut session: Session<Gallery>) {
    watch_for_stalls();
    watch_for_perf();
    // `GALLERY_PRESS` taps twice a second for the whole run, so it is read before setup.
    // `GALLERY_PRESS` 整次运行中每秒点两次，因此在初始化之前读出。
    let tap = held_press();
    // The photo the whole shell sits on; the root names it, so it must be in before frame one.
    // 整个外壳所坐的那张照片；根节点按名字引用它，因此第一帧之前就得登记好。
    wallpaper::install(session.lp_mut());
    // The text rows' words and chords are fixed for the run, so they go in once.
    // 文本行的措辞与组合键在整次运行中不变，故只设置一次。
    sync_text_menu_labels(session.lp_mut());
    if std::env::var("GALLERY_SELFTEST").is_ok() {
        let (lw, lh) = session.window().logical_size();
        selftest(session.lp_mut(), (lw.max(WIN_W), lh.max(WIN_H)));
    }
    // One laid-out frame first: the splat starts from hit testing, and before layout a
    // press hits nothing.
    // 先走一帧布局：墨迹由命中测试决定，布局之前按下什么也命不中。
    if let Some(at) = tap {
        let (lw, lh) = session.window().logical_size();
        session.lp_mut().dispatch(ui_core::Event::PointerMoved { pos: at });
        frame(session.lp_mut(), (lw.max(WIN_W), lh.max(WIN_H)), Some(at));
    }
    // Press, drag out, release: the control keeps pointer focus with the pointer elsewhere.
    // A screenshot after it settles shows whether any state layer outlived the press.
    // 按下、拖出、松手：控件留着指针焦点而指针已在别处。等它落定后截图，
    // 就能看出有没有状态层活过了按压。
    if let Some(at) = clicked_once() {
        let (lw, lh) = session.window().logical_size();
        let size = (lw.max(WIN_W), lh.max(WIN_H));
        let button = ui_core::PointerButton::Primary;
        let out = Point::new(at.x + 300.0, at.y);
        session.lp_mut().dispatch(ui_core::Event::PointerMoved { pos: at });
        step(session.lp_mut(), size, at, 1);
        session.lp_mut().dispatch(ui_core::Event::PointerPressed { pos: at, button });
        step(session.lp_mut(), size, at, 8);
        session.lp_mut().dispatch(ui_core::Event::PointerMoved { pos: out });
        step(session.lp_mut(), size, out, 1);
        session.lp_mut().dispatch(ui_core::Event::PointerReleased { pos: out, button });
        step(session.lp_mut(), size, out, 40);
    }
    // Press, leave, keep holding: the ink is still alive while the state layer has gone,
    // which is when a clip that followed the painted box used to lose its curve.
    // 按下、移出、不松手：墨迹还活着而状态层已经退去，正是那个跟着绘制盒走的裁剪
    // 过去会丢掉圆角的时刻。
    if let Some((at, out)) = held_and_left() {
        let (lw, lh) = session.window().logical_size();
        let size = (lw.max(WIN_W), lh.max(WIN_H));
        let button = ui_core::PointerButton::Primary;
        session.lp_mut().dispatch(ui_core::Event::PointerMoved { pos: at });
        step(session.lp_mut(), size, at, 1);
        session.lp_mut().dispatch(ui_core::Event::PointerPressed { pos: at, button });
        step(session.lp_mut(), size, at, 2);
        session.lp_mut().dispatch(ui_core::Event::PointerMoved { pos: out });
        // Past the hover reaction, inside the ripple's own life: the pill must still be round.
        // 越过悬停反应、落在涟漪的寿命之内：胶囊此刻仍应是圆的。
        step(session.lp_mut(), size, out, 12);
    }
    // A plain click: focus and caret placement without the drag `GALLERY_CLICK` performs.
    // 普通点击：建立焦点并放置插入符，不做 `GALLERY_CLICK` 的拖拽。
    if let Some(at) = focus_once() {
        let (lw, lh) = session.window().logical_size();
        let size = (lw.max(WIN_W), lh.max(WIN_H));
        let button = ui_core::PointerButton::Primary;
        session.lp_mut().dispatch(ui_core::Event::PointerMoved { pos: at });
        step(session.lp_mut(), size, at, 1);
        session.lp_mut().dispatch(ui_core::Event::PointerPressed { pos: at, button });
        step(session.lp_mut(), size, at, 1);
        session.lp_mut().dispatch(ui_core::Event::PointerReleased { pos: at, button });
        step(session.lp_mut(), size, at, 4);
        // `GALLERY_TYPE=text` then types it into whatever holds the caret.
        // `GALLERY_TYPE=text` 接着把该文本打给持有插入符的控件。
        if let Ok(text) = std::env::var("GALLERY_TYPE") {
            for c in text.chars() {
                session.lp_mut().dispatch(ui_core::Event::Text(c.to_string()));
            }
            step(session.lp_mut(), size, at, 4);
        }
    }
    // A scripted wheel notch: the one gesture a screenshot cannot produce by hand. It runs
    // before the drag so a drag can target content the wheel scrolled into view.
    // 脚本化的一格滚轮：截图无法用手做出来的那个手势。它先于拖拽执行，
    // 拖拽因此能对准滚轮刚滚进视野的内容。
    if let Some((at, delta)) = wheel_once() {
        let (lw, lh) = session.window().logical_size();
        let size = (lw.max(WIN_W), lh.max(WIN_H));
        session.lp_mut().dispatch(ui_core::Event::PointerMoved { pos: at });
        step(session.lp_mut(), size, at, 1);
        session.lp_mut().dispatch(ui_core::Event::wheel(at, delta));
        step(session.lp_mut(), size, at, 20);
    }
    // Scripted drags: selection across lines, and many pointer gestures in a row.
    // 脚本化拖拽：跨行选区，以及连续多次指针手势。
    let mut sequence: Vec<(Point, Point)> = drag_once().into_iter().collect();
    sequence.extend(drags());
    for (from, to) in sequence {
        let (lw, lh) = session.window().logical_size();
        let size = (lw.max(WIN_W), lh.max(WIN_H));
        let button = ui_core::PointerButton::Primary;
        session.lp_mut().dispatch(ui_core::Event::PointerMoved { pos: from });
        step(session.lp_mut(), size, from, 1);
        session.lp_mut().dispatch(ui_core::Event::PointerPressed { pos: from, button });
        step(session.lp_mut(), size, from, 1);
        for k in 1..=8 {
            let t = k as f32 / 8.0;
            let p = Point::new(
                from.x + (to.x - from.x) * t,
                from.y + (to.y - from.y) * t,
            );
            session.lp_mut().dispatch(ui_core::Event::PointerMoved { pos: p });
            step(session.lp_mut(), size, p, 1);
        }
        session.lp_mut().dispatch(ui_core::Event::PointerReleased { pos: to, button });
        step(session.lp_mut(), size, to, 4);
    }
    // A scripted right click: the engine's own menu is drawn from its own state.
    // 脚本化的一次右键：引擎自带的菜单由它自己的状态绘制。
    if let Some(at) = right_once() {
        let (lw, lh) = session.window().logical_size();
        let size = (lw.max(WIN_W), lh.max(WIN_H));
        session.lp_mut().dispatch(ui_core::Event::PointerMoved { pos: at });
        step(session.lp_mut(), size, at, 1);
        session.lp_mut().dispatch(ui_core::Event::PointerPressed {
            pos: at,
            button: ui_core::PointerButton::Secondary,
        });
        step(session.lp_mut(), size, at, 4);
    }
    // `GALLERY_ANIM=1` reports, once a second, what is still moving and where it lives.
    // `GALLERY_ANIM=1` 每秒报告一次还有什么在动、它属于哪个节点。
    let watch_anim = std::env::var_os("GALLERY_ANIM").is_some();
    let mut anim_at = Instant::now();
    let mut anim_frames = 0u32;
    let mut last_anim = String::new();
    let mut anim_stuck = 0u32;
    let mut holding = false;
    let sway = sway_once();
    let mut sway_pressed = false;
    // The held press must win over the seat pointer every frame, or a drag reads the real
    // cursor and the control ends up rubber-banded away from rest.
    // 按住的合成按压必须逐帧压过真实指针，否则拖拽读的是真实光标，控件会被橡皮筋拉离静止位。
    let hold = held_and_left().map(|(at, _)| at);
    // Injected input is this frame's platform pointer, or `build` would snap back to the seat.
    // 注入的输入就是本帧的平台指针，否则 `build` 会把它拉回座位上的真实指针。
    let mut synthetic: Option<Point> = None;
    // One setting with two halves: the renderer draws on the finer grid and the text pass
    // rasterizes on it, or glyphs would only be magnified from a 1× atlas.
    // 一个设置的两半：渲染器在更细的网格上绘制，文本 pass 也在其上光栅，
    // 否则字形只是从 1× 图集里被放大。
    let ss = supersample();
    session.lp_mut().set_supersample(ss);
    if let Some(gpu) = session.gpu_mut() {
        gpu.renderer_mut().set_supersample(ss);
    }
    // A pinned capture density reaches every glass material through the tuning table.
    // 钉住的捕获密度经调参表抵达每一份玻璃材质。
    if let Some(v) = capture_scale() {
        ui_widgets_glass::tuning::set(ui_widgets_glass::tuning::Knob::CaptureScale, Some(v));
    }
    let started = Instant::now();
    let mut dumped = false;
    let mut frames = 0u32;
    // Intake, demand and pacing live in the driver; the loop only draws when it says so.
    // `GALLERY_HEARTBEAT=1` stamps the loop once a second: a stalled output stops the stamps,
    // which is how a frozen screen becomes measurable without a camera.
    // `GALLERY_HEARTBEAT=1` 每秒给循环盖一次时间戳：输出停住，戳也就停，屏幕冻结因此可测。
    let heartbeat = std::env::var_os("GALLERY_HEARTBEAT").is_some();
    // `GALLERY_FRAMELOG=1` prints each frame's CPU time and page; a switch's first frame stands out.
    // `GALLERY_FRAMELOG=1` 打印每帧的 CPU 耗时与所在页；换页的第一帧会格外突出。
    let framelog = std::env::var_os("GALLERY_FRAMELOG").is_some();
    // `GALLERY_SWITCH=<frame>:<tag>[,<frame>:<tag>]` jumps pages mid-run, so one run can
    // time a cold switch and a warm one to the same page.
    // 运行中按帧切页，一次运行就能量到同一页的冷切与热切。
    let switch_at: Vec<(u32, Page)> = std::env::var("GALLERY_SWITCH")
        .map(|s| {
            s.split(',')
                .filter_map(|one| {
                    let (n, tag) = one.split_once(':')?;
                    Some((n.parse::<u32>().ok()?, PAGES.into_iter().find(|p| p.tag() == tag)?))
                })
                .collect()
        })
        .unwrap_or_default();
    let mut beat_at = Instant::now();
    let mut beat_cpu = cpu_seconds();
    // Kept for the exit line: frame rate follows the compositor, so CPU per frame is the
    // only number two builds can be compared on.
    // 留给退出那一行：帧率跟着 compositor 走，两个构建只能按每帧 CPU 相比。
    let cpu_start = beat_cpu;
    let mut beat_frames = 0u32;
    let mut beat_turns = 0u32;
    let mut turns = 0u32;
    // Why each frame commits in the last second: the loop is only as cheap as its gate.
    // 上一秒每帧提交的理由：循环有多便宜，取决于这道门。
    let mut beat_commit = 0u32;
    let mut beat_anim = 0u32;
    let mut beat_damage = 0u32;
    let mut beat_idle = 0u32;
    let mut beat_draws = 0u32;
    // Redrawn area as a share of the surface, averaged over the second: a band that is
    // always the whole window means damage tracking is not paying for itself.
    // 一秒内重画面积占整面的比例：带始终是整面，说明脏区跟踪没有回报。
    let mut beat_band = 0f64;
    let mut beat_band_n = 0u32;
    let mut beat_allocs = ALLOCS.load(std::sync::atomic::Ordering::Relaxed);
    let mut beat_bytes = BYTES.load(std::sync::atomic::Ordering::Relaxed);
    let clipboard = clipboard_once();
    let mut clipboard_done = false;
    let key = key_once();
    let mut key_done = false;
    // The presenter never changes mid-run; the report below reads it once per turn.
    // 呈现器在一轮运行中不变；下面的报告每轮只读它一次。
    let gpu_present = session.gpu_mut().is_some();

    while !session.finished()
        && !STOP.load(std::sync::atomic::Ordering::Relaxed)
        && started.elapsed().as_secs_f32() < lifetime()
    {
        let frame_at = Instant::now();
        turns += 1;
        BEAT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        // Reports come first: a loop turn that skips the build leaves through `continue`, and
        // a report at the end would then vanish exactly when the loop is doing the least.
        // 报告放在最前：跳过构建的那一轮走 `continue` 离开，放在末尾的报告会在循环最闲时消失。
        if watch_anim && anim_at.elapsed().as_millis() >= 1000 {
            anim_at = Instant::now();
            // A second of the same answer means nothing moved: that is the defect, caught live.
            // 连续一秒答案不变说明什么都没动：那正是缺陷本身，当场抓到。
            // Compare the motion itself: the diagnostics beside it change every second even
            // when nothing moves, and would hide exactly the freeze they exist to expose.
            // 只比运动本身：旁边的诊断数字每秒都在变，哪怕什么都没动，那会掩盖它们要暴露的冻结。
            let report = session.lp().anim_report();
            let key = anim_key(&report);
            if key == last_anim && !key.starts_with("still") {
                anim_stuck += 1;
            } else {
                anim_stuck = 0;
            }
            last_anim = key;
            eprintln!(
                "[anim] builds={} {} {report}",
                frames - anim_frames,
                if anim_stuck >= 2 { "STUCK" } else { "ok" }
            );
            anim_frames = frames;
        }
        if heartbeat && beat_at.elapsed().as_millis() >= 1000 {
            // CPU share of one core over the last second: idle and busy runs differ here.
            // 上一秒占单核的比例：空闲与活跃的区别就落在这个数上。
            let wall = beat_at.elapsed().as_secs_f64();
            let cpu = cpu_seconds();
            let share = (cpu - beat_cpu) / wall.max(1e-3) * 100.0;
            beat_at = Instant::now();
            beat_cpu = cpu;
            // `cbs` is what the compositor offered: builds below it means the loop dropped
            // frames, builds equal to it means the compositor itself paced us there.
            // `cbs` 是 compositor 给出的份额：builds 低于它就是循环丢了帧，
            // 相等就是 compositor 自己把节奏定在那里。
            let allocs = ALLOCS.load(std::sync::atomic::Ordering::Relaxed);
            let bytes = BYTES.load(std::sync::atomic::Ordering::Relaxed);
            let built = (frames - beat_frames).max(1) as u64;
            let heap = if ALLOC_ON.load(std::sync::atomic::Ordering::Relaxed) {
                format!(
                    " alloc={} {}kB",
                    (allocs - beat_allocs) / built,
                    (bytes - beat_bytes) / built / 1024
                )
            } else {
                String::new()
            };
            let cbs = session.window_mut().take_frame_callbacks();
            let hz = session.window().refresh_hz();
            eprintln!(
                "[hb] t={} turns={} builds={} cbs={} cpu={share:.0}% commit={beat_commit} (dirty={beat_damage} anim={beat_anim} draws={beat_draws} band={band:.1}%{heap}) idle={beat_idle} refresh={:?}",
                epoch_ms(),
                turns - beat_turns,
                frames - beat_frames,
                cbs,
                hz,
                band = if beat_band_n == 0 { 0.0 } else { beat_band / beat_band_n as f64 * 100.0 }
            );
            if std::env::var_os("GALLERY_ALLOC_SITES").is_some() {
                // Collect under the lock, print after releasing it: `eprintln` allocates,
                // and an allocation inside the lock would sample itself into a deadlock.
                // 持锁收集、释放后打印：`eprintln` 会分配，锁内分配会把探针自己采死。
                let mut top: Vec<(u64, String)> = Vec::new();
                SITES_ON.store(false, std::sync::atomic::Ordering::Relaxed);
                if let Ok(mut slot) = SITES.lock() {
                    match slot.as_mut() {
                        None => {
                            *slot = Some(std::collections::HashMap::new());
                        }
                        Some(map) => {
                            top = map.iter().map(|(k, v)| (*v, k.clone())).collect();
                        }
                    }
                }
                SITES_ON.store(true, std::sync::atomic::Ordering::Relaxed);
                top.sort_unstable_by(|a, b| b.0.cmp(&a.0));
                for (n, k) in top.iter().take(18) {
                    eprintln!("[site] {n}: {k}");
                }
            }
            if std::env::var_os("GALLERY_ALLOC_SIZES").is_some() {
                let mut line = String::from("[alloc]");
                for (i, n) in SIZES.iter().enumerate() {
                    let v = n.load(std::sync::atomic::Ordering::Relaxed);
                    if v > 0 {
                        line.push_str(&format!(" b{i}={v}"));
                    }
                }
                eprintln!("{line}");
            }
            beat_allocs = allocs;
            beat_bytes = bytes;
            beat_turns = turns;
            beat_frames = frames;
            beat_commit = 0;
            beat_anim = 0;
            beat_damage = 0;
            beat_idle = 0;
            beat_draws = 0;
            beat_band = 0.0;
            beat_band_n = 0;
        }
        // Jump pages at their frames, to time a switch inside a running app.
        // 在指定帧切页，量运行中的应用内切页的耗时。
        for (n, page) in &switch_at {
            if frames == *n {
                session.lp_mut().app_mut().page = *page;
            }
        }
        // A pressed finger sweeping back and forth: the one shape in which the thumb's
        // wobble exists from frame to frame.
        // 按住的手指来回扫动：滑块颤动逐帧存在的唯一形态。
        if let Some((from, to, ms)) = &sway {
            let button = ui_core::PointerButton::Primary;
            if !sway_pressed {
                // Wait for the first layout: a press before the hit index exists lands nowhere.
                // 等第一帧布局：命中索引还不存在时按下会落空。
                if started.elapsed().as_secs_f32() > 0.3 {
                    sway_pressed = true;
                    let pos = *from;
                    synthetic = Some(pos);
                    session.lp_mut().dispatch(ui_core::Event::PointerMoved { pos });
                    session.lp_mut().dispatch(ui_core::Event::PointerPressed { pos, button });
                }
            } else {
                let cycles = started.elapsed().as_secs_f32() / (*ms as f32 / 1000.0);
                let s = (cycles * std::f32::consts::TAU).sin();
                let pos = Point::new(from.x + (to.x - from.x) * s, from.y);
                synthetic = Some(pos);
                session.lp_mut().dispatch(ui_core::Event::PointerMoved { pos });
            }
        }
        // Tap twice a second at `GALLERY_PRESS`, so a screenshot catches the ink in flight;
        // a held press settles into a flat tint within 225ms and proves nothing.
        // 在 `GALLERY_PRESS` 处每秒点两次，截图才能拍到飞行中的墨迹；
        // 按住不放 225ms 后就成了平涂，什么都证明不了。
        if let Some(at) = tap {
            let down = started.elapsed().as_millis() % 500 < 250;
            if down != holding {
                holding = down;
                let button = ui_core::PointerButton::Primary;
                let pos = at;
                synthetic = Some(pos);
                // The move lands the pointer before the press, as the sway script does; an
                // event built inside the `if` below would be dropped instead of delivered.
                // 与扫动脚本一样，先移动指针再按下；建在下方 `if` 里的那个事件会被丢弃而非送达。
                if down {
                    session.lp_mut().dispatch(ui_core::Event::PointerMoved { pos });
                }
                session.lp_mut().dispatch(if down {
                    ui_core::Event::PointerPressed { pos, button }
                } else {
                    ui_core::Event::PointerReleased { pos, button }
                });
            }
        }
        // A held press has to be re-asserted before the frame is judged, or it becomes the
        // one input that cannot ask for a frame.
        // 按住点必须在判定之前重新压入，否则它就成了唯一无法要求一帧的输入。
        if let Some(at) = hold {
            synthetic = Some(at);
            session.lp_mut().dispatch(ui_core::Event::PointerMoved { pos: at });
        }
        // `GALLERY_CLOSE_AFTER=n` closes the window itself after n seconds, so an exit test
        // needs no hand on the mouse; compare it against a real close.
        // `GALLERY_CLOSE_AFTER=n` 在 n 秒后自己关窗，退出测试因此不必动手；与真实关窗对照。
        if close_after().is_some_and(|secs| started.elapsed().as_secs_f32() >= secs) {
            session.window_mut().request_close();
        }
        route_clipboard(&mut session);
        if let Some(chords) = &key {
            // After the focus knobs have run, and once: a held modifier set is ambient.
            // 等焦点旋钮跑完，且只按一次：按住的修饰键是环境状态。
            if !key_done && started.elapsed().as_secs_f32() > 0.3 {
                key_done = true;
                for (mods, k) in chords {
                    session.lp_mut().dispatch(ui_core::Event::Modifiers(*mods));
                    session.lp_mut().dispatch(ui_core::Event::KeyPressed { key: *k });
                }
                session.lp_mut().dispatch(ui_core::Event::Modifiers(ui_core::Modifiers::default()));
            }
        }
        if let Some(spec) = &clipboard {
            // Retried: the seat announces its offer a few frames after the window maps.
            // 需要重试：窗口映射后，座位要过几帧才宣布它的 offer。
            if !clipboard_done && started.elapsed().as_secs_f32() > 0.3 {
                let ok = if let Some(text) = spec.strip_prefix("copy:") {
                    session.window_mut().write_clipboard(text)
                } else if spec == "paste" {
                    session.window_mut().request_paste()
                } else {
                    true
                };
                if ok {
                    println!("clipboard {}: true", if spec == "paste" { "paste" } else { "copy" });
                    clipboard_done = true;
                } else if started.elapsed().as_secs_f32() > 3.0 {
                    println!("clipboard {}: false", spec);
                    clipboard_done = true;
                }
            }
        }
        // Scripted input is this frame's platform pointer, or the frame snaps back to the seat.
        // 脚本输入就是本帧的平台指针，否则这一帧会弹回座位的真实指针。
        session.set_pointer(synthetic);
        // Intake, demand, pacing and the commit decision are the engine's; a turn either
        // draws or ends here.
        // 摄入、帧需求、配速与提交判定都归引擎；一轮要么画，要么在这里结束。
        let tick = match session.tick() {
            Ok(t) => t,
            Err(e) => {
                eprintln!("{e}");
                std::process::exit(1);
            }
        };
        // A frame wait this long means no callback arrived: the output is stalled.
        // 帧等待这么久说明回调没来：输出停住了。
        if heartbeat && session.last_wait().as_millis() >= 50 {
            eprintln!(
                "[stall] t={} wait={}ms",
                epoch_ms(),
                session.last_wait().as_millis()
            );
        }
        for ev in session.events() {
            // The one event a screenshot cannot show: what the peer actually handed us.
            // 截图无法呈现的那条事件：对方究竟交给了我们什么。
            if let ui_core::Event::Paste(text) = ev {
                println!("clipboard pasted: {text:?}");
            }
        }
        if !tick.drew {
            continue;
        }
        let Some(outcome) = tick.outcome else {
            continue;
        };
        // `GALLERY_BATCHES=1` prints one frame's batches: draw calls are priced per
        // call, so a page that needs 100 of them is paying for its paint order.
        // `GALLERY_BATCHES=1` 打印某一帧的批次：驱动按次计价，
        // 一页要 100 次就说明代价落在绘制顺序上。
        let batches = frames == 3 && std::env::var_os("GALLERY_BATCHES").is_some();
        if batches {
            let all = session.lp().draw_list().plan_batches();
            let mut kinds = [0u32; ui_core::draw::PrimKind::COUNT];
            let mut prims = [0u32; ui_core::draw::PrimKind::COUNT];
            for b in &all {
                kinds[b.kind as usize] += 1;
                prims[b.kind as usize] += b.range.end - b.range.start;
            }
            eprintln!(
                "[batches] total={} rect={}/{} glyph={}/{} shadow={}/{} sector={}/{} image={}/{}",
                all.len(),
                kinds[0], prims[0],
                kinds[2], prims[2],
                kinds[4], prims[4],
                kinds[5], prims[5],
                kinds[3], prims[3],
            );
        }
        if framelog {
            eprintln!(
                "[frame] {frames} {:.1}ms page={:?}",
                frame_at.elapsed().as_secs_f64() * 1000.0,
                session.lp_mut().app_mut().page
            );
        }
        // The engine already decided whether this frame was worth a commit; this only
        // reports it. Without a GPU presenter no frame reaches a target that can dump.
        // 引擎已经判定这一帧是否值得提交，这里只汇报。没有 GPU 呈现器时，
        // 帧到不了能导出的目标。
        if gpu_present {
            if let Some(stats) = tick.presented {
                beat_commit += 1;
                beat_anim += outcome.animating as u32;
                beat_damage += !outcome.damage.is_none() as u32;
                if framelog {
                    // On a host that runs at refresh rate, why each frame commits is the
                    // one fact a screenshot cannot show.
                    // 在跑满刷新率的宿主上，每帧为何提交正是截图看不出的事实。
                    eprintln!(
                        "[present] damage={} animating={}",
                        !outcome.damage.is_none(),
                        outcome.animating
                    );
                }
                beat_draws += stats.draw_calls;
                let (lw, lh) = session.window().logical_size();
                let s = session.window().scale().max(f32::EPSILON);
                let full = (lw as f32 * s) * (lh as f32 * s);
                let band = stats.band.map_or(full, |b| (b[2] * b[3]) as f32);
                beat_band += (band / full.max(1.0)) as f64;
                beat_band_n += 1;
                if batches {
                    eprintln!("[band] {:?} surface={}x{}", stats.band, lw, lh);
                }
                if want_dump() && !dumped && frames >= dump_frame()
                    && let Some(gpu) = session.gpu_mut()
                {
                    let _ = gpu.dump_ppm(
                        std::path::Path::new("/tmp/gallery_frame.ppm"),
                        std::path::Path::new("/tmp/gallery_layer.ppm"),
                    );
                    dumped = true;
                    println!("dumped /tmp/gallery_frame.ppm");
                }
            } else {
                beat_idle += 1;
            }
        } else if want_dump() && !dumped {
            eprintln!("gallery: GALLERY_DUMP needs the GPU presenter");
            dumped = true;
        }
        frames += 1;
    }
    if framelog {
        let (partial, full) = ui_platform_wayland::partial_frames();
        eprintln!("redraw: partial={partial} full={full}");
        // Entries held and lookups (hits, misses): reuse means a still frame rebuilt nothing.
        // 持有的条目与查找次数（命中, 未命中）：复用意味着静止的一帧没有重建任何东西。
        let (kept, hits, misses) = session.lp().decl_cache_stats();
        eprintln!("decl cache: {kept} entries, {hits} hits, {misses} misses");
    }
    let secs = started.elapsed().as_secs_f32();
    let (waited, waited_n) = session.wait_stats();
    println!(
        "frames {frames} in {secs:.1}s ({:.0} fps), frame wait avg {:.2}ms over {waited_n}",
        frames as f32 / secs.max(1e-3),
        waited.as_secs_f64() * 1000.0 / waited_n.max(1) as f64
    );
    let cpu = cpu_seconds() - cpu_start;
    let (partial, full) = ui_platform_wayland::partial_frames();
    println!(
        "cpu {cpu:.3}s over {frames} frames = {:.0}µs/frame (partial {partial}, full {full})",
        cpu * 1e6 / frames.max(1) as f64
    );
    // In-flight dma-bufs at exit: a growing count means the compositor is not releasing them.
    // 退出时仍在途的 dma-buf 数：持续增长说明 compositor 没有释放它们。
    println!(
        "dmabuf: {} inflight, {} released",
        session.window().dmabuf_inflight(),
        session.window().dmabuf_releases()
    );
    // Teardown order is the session's: GPU objects while the surface still exists, then the
    // loop, then the window. Timed because a slow exit is a user-visible bug.
    // 拆除顺序归会话：表面还在时先放 GPU 对象，再放循环，最后放窗口。
    // 计时：退出慢是用户可见的缺陷。
    let t0 = Instant::now();
    ui_platform::exit_probe::stage("loop-end");
    // `EXIT_FINISH=1` drains the GPU before teardown; how long that takes is the backlog
    // the compositor would otherwise inherit.
    // `EXIT_FINISH=1` 在拆除前把 GPU 排空；耗时就是 compositor 否则要接着承担的积压。
    if std::env::var_os("EXIT_FINISH").is_some()
        && let Some(gpu) = session.gpu_mut()
    {
        ui_platform::exit_probe::stage("gpu: finish");
        gpu.finish();
        ui_platform::exit_probe::stage("gpu: finished");
    }
    drop(session);
    let t1 = Instant::now();
    ui_platform::exit_probe::stage("session-dropped");
    if t1.duration_since(t0).as_millis() > 50 || ui_platform::exit_probe::armed() {
        eprintln!("teardown: session {}ms", t1.duration_since(t0).as_millis());
    }
    // Everything is gone; anything slow after this is libc's atexit, not ours.
    // 该放的都放完了；此后若还慢，就属于 libc 的 atexit，不是我们的。
    ui_platform::exit_probe::stage("main-return");
}
