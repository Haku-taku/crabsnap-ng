// Shared gallery scaffolding: page enum, ids, style scopes and shell chrome.
// 画廊共享脚手架：页面枚举、id、样式作用域与外壳。

pub(crate) use std::time::Instant;

pub(crate) use ui_core::draw::{Acrylic, BackdropMaterial, GradientAxis};
pub(crate) use ui_core::geom::{Color, Corners, Insets, Point, Rect};
pub(crate) use ui_core::layout::{AxisSize, Grow, SizeClass};
pub(crate) use ui_core::tree::ImageFit;
pub(crate) use ui_core::{Decl, Id, ModalTarget, NodeKind, Weight};
pub(crate) use ui_platform::view::{App, AppLoop};
pub(crate) use ui_platform::{from_decl, Container, Element};
pub(crate) use ui_platform_wayland::{Session, SessionOptions};
pub(crate) use ui_i18n::Msg;
pub(crate) use ui_style::{Env, SliderSpec, ToggleSpec};
pub(crate) use ui_widgets::{Cx, IconSource, ScaffoldSpec, StyleKit, Widget};
pub(crate) use ui_widgets_fluent::FluentKit;
pub(crate) use ui_widgets_glass::HigKit;
pub(crate) use ui_widgets_md3::Md3Kit;

/// The UI text face: Apple's own pair where the host has it, otherwise Inter for Latin and
/// the system's Chinese face for CJK — the open pairing closest to SF Pro + PingFang SC.
/// 界面文字字面：宿主有 Apple 那一对就用它，否则拉丁用 Inter、中文用系统中文面——
/// 这是最接近 SF Pro + 苹方的开源组合。
pub(crate) const TEXT_FAMILY: &str = "Inter";

/// Faces in the order a glyph is looked up: Latin first, then the Chinese face behind it.
/// 字形查找顺序：先拉丁，再其后的中文面。
pub(crate) const TEXT_STACK: &[&str] = &[
    "SF Pro Text",
    "SF Pro Display",
    TEXT_FAMILY,
    "PingFang SC",
    "Noto Sans SC",
    "Noto Sans CJK SC",
    "MiSans VF",
    "HarmonyOS Sans SC",
];

pub(crate) const NAV_W: f32 = 360.0;
/// The content area's width: the window minus the nav column and the shell's two paddings.
/// 内容区宽度：窗口减去导航列与外壳两侧内边距。
pub(crate) const CONTENT_W: f32 = WIN_W as f32 - NAV_W - 32.0;
pub(crate) const COL_W: f32 = 380.0;
pub(crate) const COL_CTRL_H: f32 = 300.0;
pub(crate) const COL_TALL_H: f32 = 800.0;
// Enough for three stacked bars with their captions, without the tall column's empty half.
// 够放三条叠放的栏及其说明，又不留高列那半截空白。
pub(crate) const COL_MID_H: f32 = 460.0;
pub(crate) const WIN_W: u32 = 1600;
// Tall enough for a `COL_TALL_H` column below the header; shorter squeezes its last rows.
// 高到能在页头之下容纳一条 `COL_TALL_H` 列；再矮就会压缩它最后几行。
// The nav scrolls, so pages may be added without raising this: rows below the window are
// reachable by wheel instead of being clipped away for good.
// 导航可滚动，因此新增页面不必再抬高它：窗口之下的行可以用滚轮够到，而不是被永久裁掉。
pub(crate) const WIN_H: u32 = 1060;

/// The four pages of the acceptance gallery.
// 验收 gallery 的四个页面。
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub(crate) enum Page {
    Switch,
    Checkbox,
    Radio,
    Slider,
    Tabs,
    ToolTip,
    InfoBar,
    Buttons,
    FabMenu,
    MenuFlyout,
    Combo,
    Chips,
    Cards,
    Lists,
    Icons,
    Dialogs,
    ActionSheet,
    Toast,
    ModalSheet,
    Stepper,
    DatePicker,
    TimePicker,
    AppBar,
    Carousel,
    TextField,
    Search,
    Selection,
    Generic,
    Progress,
    Segmented,
    NavBar,
    NavRail,
    NavDrawer,
    NavView,
    Toolbar,
    Snackbar,
    Layouts,
    Grid,
    Inline,
    Positioning,
    Materials,
    Md3System,
    FluentSystem,
    HigSystem,
}

pub(crate) const PAGES: [Page; 44] = [
    Page::Switch,
    Page::Checkbox,
    Page::Radio,
    Page::Slider,
    Page::Tabs,
    Page::ToolTip,
    Page::InfoBar,
    Page::Buttons,
    Page::FabMenu,
    Page::MenuFlyout,
    Page::Combo,
    Page::Chips,
    Page::Cards,
    Page::Lists,
    Page::Icons,
    Page::Dialogs,
    Page::ActionSheet,
    Page::Toast,
    Page::ModalSheet,
    Page::Stepper,
    Page::DatePicker,
    Page::TimePicker,
    Page::AppBar,
    Page::Carousel,
    Page::TextField,
    Page::Search,
    Page::Selection,
    Page::Generic,
    Page::Progress,
    Page::Segmented,
    Page::NavBar,
    Page::NavRail,
    Page::NavDrawer,
    Page::NavView,
    Page::Toolbar,
    Page::Snackbar,
    Page::Layouts,
    Page::Grid,
    Page::Inline,
    Page::Positioning,
    Page::Materials,
    Page::Md3System,
    Page::FluentSystem,
    Page::HigSystem,
];

/// The nav tree: one section per row of pages, each titled by its own key.
// 导航树：每个节一行页面；节标题用各自的 key。
pub(crate) const SECTIONS: [(&str, Msg, &[Page]); 4] = [
    (
        "controls",
        Msg::GALLERY_SECTION_CONTROLS,
        &[
            Page::Switch,
            Page::Checkbox,
            Page::Radio,
            Page::Slider,
            Page::Tabs,
            Page::ToolTip,
            Page::InfoBar,
            Page::Buttons,
            Page::FabMenu,
            Page::MenuFlyout,
            Page::Combo,
            Page::Chips,
            Page::Cards,
            Page::Lists,
            Page::Icons,
            Page::Dialogs,
            Page::ActionSheet,
            Page::Toast,
            Page::ModalSheet,
            Page::Stepper,
            Page::DatePicker,
            Page::TimePicker,
            Page::AppBar,
            Page::Carousel,
            Page::TextField,
            Page::Search,
            Page::Selection,
            Page::Generic,
            Page::Progress,
            Page::Segmented,
            Page::NavBar,
            Page::NavRail,
            Page::NavDrawer,
            Page::NavView,
            Page::Toolbar,
            Page::Snackbar,
        ],
    ),
    (
        "layouts",
        Msg::GALLERY_SECTION_LAYOUTS,
        &[Page::Layouts, Page::Grid, Page::Inline, Page::Positioning],
    ),
    ("materials", Msg::GALLERY_SECTION_MATERIALS, &[Page::Materials]),
    (
        "design-systems",
        Msg::GALLERY_SECTION_DESIGN_SYSTEMS,
        &[Page::Md3System, Page::FluentSystem, Page::HigSystem],
    ),
];

impl Page {
    pub(crate) fn tag(self) -> &'static str {
        match self {
            Page::Switch => "switch",
            Page::Checkbox => "checkbox",
            Page::Radio => "radio",
            Page::Slider => "slider",
            Page::Tabs => "tabs",
            Page::ToolTip => "tooltip",
            Page::InfoBar => "info-bar",
            Page::Buttons => "buttons",
            Page::FabMenu => "fab-menu",
            Page::MenuFlyout => "menu-flyout",
            Page::Combo => "combo",
            Page::Chips => "chips",
            Page::Cards => "cards",
            Page::Lists => "lists",
            Page::Icons => "icons",
            Page::Dialogs => "dialogs",
            Page::ActionSheet => "action-sheet",
            Page::Toast => "toast",
            Page::ModalSheet => "modal-sheet",
            Page::Stepper => "stepper",
            Page::DatePicker => "date-picker",
            Page::TimePicker => "time-picker",
            Page::AppBar => "app-bar",
            Page::Carousel => "carousel",
            Page::TextField => "text-field",
            Page::Search => "search",
            Page::Selection => "selection",
            Page::Generic => "generic",
            Page::Progress => "progress",
            Page::Segmented => "segmented",
            Page::NavBar => "nav-bar",
            Page::NavRail => "nav-rail",
            Page::NavDrawer => "nav-drawer",
            Page::NavView => "nav-view",
            Page::Toolbar => "toolbar",
            Page::Snackbar => "snackbar",
            Page::Layouts => "layouts",
            Page::Grid => "grid",
            Page::Inline => "inline",
            Page::Positioning => "positioning",
            Page::Materials => "materials",
            Page::Md3System => "md3-system",
            Page::FluentSystem => "fluent-system",
            Page::HigSystem => "hig-system",
        }
    }

    /// The page's nav and header title, as a catalog key.
    // 页面在导航与页头的标题，以 catalog key 表示。
    pub(crate) fn title(self) -> Msg {
        match self {
            Page::Switch => Msg::GALLERY_PAGE_SWITCH_TITLE,
            Page::Checkbox => Msg::GALLERY_PAGE_CHECKBOX_TITLE,
            Page::Radio => Msg::GALLERY_PAGE_RADIO_TITLE,
            Page::Slider => Msg::GALLERY_PAGE_SLIDER_TITLE,
            Page::Tabs => Msg::GALLERY_PAGE_TABS_TITLE,
            Page::ToolTip => Msg::GALLERY_PAGE_TOOLTIP_TITLE,
            Page::InfoBar => Msg::GALLERY_PAGE_INFO_BAR_TITLE,
            Page::Buttons => Msg::GALLERY_PAGE_BUTTONS_TITLE,
            Page::FabMenu => Msg::GALLERY_PAGE_FAB_MENU_TITLE,
            Page::MenuFlyout => Msg::GALLERY_PAGE_MENU_FLYOUT_TITLE,
            Page::Combo => Msg::GALLERY_PAGE_COMBO_TITLE,
            Page::Chips => Msg::GALLERY_PAGE_CHIPS_TITLE,
            Page::Cards => Msg::GALLERY_PAGE_CARDS_TITLE,
            Page::Lists => Msg::GALLERY_PAGE_LISTS_TITLE,
            Page::Icons => Msg::GALLERY_PAGE_ICONS_TITLE,
            Page::Dialogs => Msg::GALLERY_PAGE_DIALOGS_TITLE,
            Page::ActionSheet => Msg::GALLERY_PAGE_ACTION_SHEET_TITLE,
            Page::Toast => Msg::GALLERY_PAGE_TOAST_TITLE,
            Page::ModalSheet => Msg::GALLERY_PAGE_MODAL_SHEET_TITLE,
            Page::Stepper => Msg::GALLERY_PAGE_STEPPER_TITLE,
            Page::DatePicker => Msg::GALLERY_PAGE_DATE_PICKER_TITLE,
            Page::TimePicker => Msg::GALLERY_PAGE_TIME_PICKER_TITLE,
            Page::AppBar => Msg::GALLERY_PAGE_APP_BAR_TITLE,
            Page::Carousel => Msg::GALLERY_PAGE_CAROUSEL_TITLE,
            Page::TextField => Msg::GALLERY_PAGE_TEXT_FIELD_TITLE,
            Page::Search => Msg::GALLERY_PAGE_SEARCH_TITLE,
            Page::Selection => Msg::GALLERY_PAGE_SELECTION_TITLE,
            Page::Generic => Msg::GALLERY_PAGE_GENERIC_TITLE,
            Page::Progress => Msg::GALLERY_PAGE_PROGRESS_TITLE,
            Page::Segmented => Msg::GALLERY_PAGE_SEGMENTED_TITLE,
            Page::NavBar => Msg::GALLERY_PAGE_NAV_BAR_TITLE,
            Page::NavRail => Msg::GALLERY_PAGE_NAV_RAIL_TITLE,
            Page::NavDrawer => Msg::GALLERY_PAGE_NAV_DRAWER_TITLE,
            Page::NavView => Msg::GALLERY_PAGE_NAV_VIEW_TITLE,
            Page::Toolbar => Msg::GALLERY_PAGE_TOOLBAR_TITLE,
            Page::Snackbar => Msg::GALLERY_PAGE_SNACKBAR_TITLE,
            Page::Layouts => Msg::GALLERY_PAGE_LAYOUTS_TITLE,
            Page::Grid => Msg::GALLERY_PAGE_GRID_TITLE,
            Page::Inline => Msg::GALLERY_PAGE_INLINE_TITLE,
            Page::Positioning => Msg::GALLERY_PAGE_POSITIONING_TITLE,
            Page::Materials => Msg::GALLERY_PAGE_MATERIALS_TITLE,
            Page::Md3System => Msg::GALLERY_PAGE_MD3_SYSTEM_TITLE,
            Page::FluentSystem => Msg::GALLERY_PAGE_FLUENT_SYSTEM_TITLE,
            Page::HigSystem => Msg::GALLERY_PAGE_HIG_SYSTEM_TITLE,
        }
    }

    pub(crate) fn nav_id(self) -> Id {
        Id::of(("nav", self.tag()))
    }

    pub(crate) fn body_id(self) -> Id {
        Id::of({
            let tag = self.tag();
            format!("page/{tag}")
        })
    }
}

/// Column tags and title keys, in render order.
// 列的标识与标题 key，按渲染顺序。
pub(crate) const STYLES: [(&str, Msg); 3] = [
    ("md3", Msg::GALLERY_STYLE_MD3),
    ("fluent", Msg::GALLERY_STYLE_FLUENT),
    ("glass", Msg::GALLERY_STYLE_GLASS),
];


pub(crate) fn col_id(page: Page, tag: &'static str) -> Id {
    Id::of(("col", tag, page.tag()))
}

pub(crate) fn switch_id(page: Page, tag: &'static str) -> Id {
    Id::of(("switch", tag, page.tag()))
}

/// The Material Symbols glyph `name` as a slot source, resolved by the control's ink.
/// 名为 `name` 的 Material Symbols 字形作为槽位源，由控件按墨色解析。
pub(crate) fn ms(name: &str) -> IconSource {
    IconSource::glyph(name, ui_widgets::IconSet::Outlined)
}

pub(crate) fn label(id: Id, body: impl Into<String>, size: f32, color: Color, max_w: f32) -> Decl {
    ui_widgets::text::leaf(
        id,
        body.into(),
        size,
        color,
        Weight::REGULAR,
        max_w,
        0.0,
        0.0,
    )
}

/// A message as an owned string, for the sinks that take `impl Into<String>`.
// 把消息取成自有字符串，供接收 `impl Into<String>` 的出口使用。
pub(crate) fn tr(cx: &Cx<'_, '_>, msg: Msg) -> String {
    cx.t(msg).to_string()
}

pub(crate) fn tf(cx: &Cx<'_, '_>, msg: Msg, args: &[(&str, ui_i18n::Value<'static>)]) -> String {
    // `Cx` has no `tf`: build the `Args` bag the engine's `t_args` takes.
    // `Cx` 没有 `tf`：构造 `t_args` 所需的 `Args` 参数袋。
    let mut bag = ui_i18n::Args::new();
    for (name, value) in args {
        bag.set(name, value.clone());
    }
    cx.t_args(msg, &bag).to_string()
}

pub(crate) fn arg(value: impl Into<ui_i18n::Value<'static>>) -> ui_i18n::Value<'static> {
    value.into()
}

pub(crate) fn muted() -> Color {
    Color::from_rgba8(150, 158, 176, 255)
}

// Each column's scope: the Fluent one overrides a real metric, the rest stay at defaults.
// 每列的作用域：Fluent 覆盖一个真实度量，其余用默认值。
thread_local! {
    // Theme transition state, readable from `style_env` without threading it through pages.
    // 主题过渡状态，供 style_env 读取，无需逐页传参。
    pub(crate) static THEME_FROM: std::cell::Cell<Option<bool>> = const { std::cell::Cell::new(None) };
    pub(crate) static THEME_T: std::cell::Cell<f32> = const { std::cell::Cell::new(1.0) };
    /// The frame's catalog scope, so a page that builds an `Env` keeps the translations.
    /// 本帧的 catalog 作用域，使页面自建 `Env` 时仍带着译文。
    static I18N_ENV: std::cell::RefCell<Option<std::sync::Arc<Env>>> = const { std::cell::RefCell::new(None) };
    /// The frame's root env (theme scope over the catalog), published per frame.
    /// 本帧的根环境（主题作用域叠在 catalog 上），每帧发布。
    static THEME_ENV: std::cell::RefCell<Option<std::sync::Arc<Env>>> = const { std::cell::RefCell::new(None) };
}

/// Publish the catalog-carrying scope; every `Env` the pages build hangs from it.
// 发布带 catalog 的作用域；页面构建的每个 `Env` 都挂在它下面。
pub(crate) fn set_i18n_env(env: std::sync::Arc<Env>) {
    I18N_ENV.with(|slot| *slot.borrow_mut() = Some(env));
}

/// Build and publish the frame's catalog scope from `GALLERY_LOCALE` (default `en`).
// 按 `GALLERY_LOCALE`（默认 `en`）构建并发布本帧的 catalog 作用域。
pub(crate) fn init_locale() {
    let requested_tag = std::env::var("GALLERY_LOCALE").unwrap_or_else(|_| "en".to_string());
    let requested: ui_i18n::LanguageIdentifier =
        requested_tag.parse().unwrap_or_else(|_| LANGUAGE_EN.clone());
    // English always resolves; an unknown tag falls back to it rather than failing the run.
    // 英文总能解析；未知标签退回英文，而不是让这次运行失败。
    let catalog = ui_i18n::Catalog::builtin(requested, LANGUAGE_EN.clone())
        .or_else(|_| ui_i18n::Catalog::builtin(LANGUAGE_EN.clone(), LANGUAGE_EN.clone()))
        .expect("an English catalog always builds");
    set_i18n_env(Env::with(Some(Env::root()), std::sync::Arc::new(catalog)));
}

/// The always-valid English identifier used as the fallback locale.
// 永远有效的英文标识，作为回退 locale。
static LANGUAGE_EN: std::sync::LazyLock<ui_i18n::LanguageIdentifier> =
    std::sync::LazyLock::new(|| "en".parse().expect("en is a locale"));

/// The published scope, or the bare root before the app sets one.
// 已发布的作用域；应用设置之前是裸根。
pub(crate) fn i18n_env() -> std::sync::Arc<Env> {
    I18N_ENV
        .with(|slot| slot.borrow().clone())
        .unwrap_or_else(Env::root)
}

/// Build the scope one `Env` layer hangs under, carrying the catalog.
// 构造某一 `Env` 层的父作用域，其中带上 catalog。
pub(crate) fn base_env() -> std::sync::Arc<Env> {
    i18n_env()
}

/// Publish the frame's theme env; the app sets it once per frame, before any page builds.
/// 发布本帧的主题环境；应用每帧设置一次，在任何页面构建之前。
pub(crate) fn set_root_env(env: std::sync::Arc<Env>) {
    THEME_ENV.with(|slot| *slot.borrow_mut() = Some(env));
}

/// The frame's theme env, or the catalog scope before the app publishes one.
/// 本帧的主题环境；应用发布之前是 catalog 作用域。
pub(crate) fn root_env() -> std::sync::Arc<Env> {
    THEME_ENV.with(|slot| slot.borrow().clone()).unwrap_or_else(base_env)
}

/// Pending column: a style's placeholder on a page that only MD3 implements yet.
// 占位列：只有 MD3 实现的页面上，某个尚未支持此控件的风格所在列。
pub(crate) fn pending_column(
    page: Page,
    tag: &'static str,
    width: f32,
    height: f32,
    cx: &Cx<'_, '_>,
) -> Box<dyn Element> {
    let body = Container::new(Id::of(("body", tag)), NodeKind::Column).child_decl(label(
        Id::of(("body", tag, "note")),
        tr(cx, Msg::GALLERY_NOT_IMPLEMENTED),
        12.0,
        muted(),
        width - 24.0,
    ));
    column_w(page, tag, style_title(tag), Box::new(body), width, height, cx)
}

/// The two placeholder columns (Fluent, then Glass) every MD3-only page shows.
// 每条只有 MD3 的页面所显示的两条占位列（先 Fluent、后 Glass）。
pub(crate) fn add_pending_pair(
    row: Container,
    page: Page,
    width: f32,
    height: f32,
    cx: &mut Cx<'_, '_>,
) -> Container {
    let mut row = row;
    for tag in ["fluent", "glass"] {
        row = row.child(pending_column(page, tag, width, height, cx));
    }
    row
}

pub(crate) fn theme_from_appearance() -> Option<ui_design::Appearance> {
    THEME_FROM.with(|c| c.get()).map(appearance_of)
}

pub(crate) fn theme_progress() -> f32 {
    THEME_T.with(|c| c.get())
}

/// The context this frame resolves tokens in; the root env carries it, columns inherit.
/// 本帧解析令牌所依据的上下文；根环境携带它，各列从它继承。
pub(crate) fn style_scope(dark: bool) -> ui_style::StyleScope {
    ui_style::StyleScope {
        appearance: appearance_of(dark),
        theme_from: theme_from_appearance(),
        theme_t: theme_progress(),
    }
}

/// Build this frame's theme env: the theme scope over the catalog scope.
/// 构建本帧的主题环境：主题作用域叠在 catalog 作用域之上。
pub(crate) fn theme_env(dark: bool) -> std::sync::Arc<Env> {
    Env::with_scope(Some(base_env()), style_scope(dark), ())
}

/// A column's env: only its kit's options; the theme scope is inherited from the root.
/// 列环境：只挂本风格包的选项；主题作用域从根继承。
pub(crate) fn style_env(tag: &'static str) -> std::sync::Arc<Env> {
    match tag {
        "fluent" => Env::with(
            Some(root_env()),
            ui_widgets_fluent::FluentOptions::default(),
        ),
        "md3" => Env::with(Some(root_env()), ui_widgets_md3::Md3Options::default()),
        // Every style column sits on the same dark card, so Glass resolves its dark pack.
        // 所有风格的列都放在同一块深色卡片上，因此 Glass 取深色包。
        _ => Env::with(Some(root_env()), ui_widgets_glass::HigOptions::default()),
    }
}

/// The title key of the style a column's tag names, for a page that has the tag but not the key.
// 由列标识取出该风格的标题 key，供只有标识、没有 key 的页面使用。
pub(crate) fn style_title(tag: &str) -> Msg {
    match tag {
        "fluent" => Msg::GALLERY_STYLE_FLUENT,
        "glass" => Msg::GALLERY_STYLE_GLASS,
        _ => Msg::GALLERY_STYLE_MD3,
    }
}

/// A section column: style title over a body, all three at the same size.
// 一节的列：风格标题加内容，三列同尺寸。
pub(crate) fn column(
    page: Page,
    tag: &'static str,
    title: Msg,
    body: Box<dyn Element>,
    height: f32,
    cx: &Cx<'_, '_>,
) -> Box<dyn Element> {
    column_text(page, tag, tr(cx, title), body, COL_W, height)
}

/// The same, with a title the caller already formatted.
// 同上，标题由调用方先行格式化。
pub(crate) fn column_text(
    page: Page,
    tag: &'static str,
    title: String,
    body: Box<dyn Element>,
    width: f32,
    height: f32,
) -> Box<dyn Element> {
    card(page, tag, title, body, width, AxisSize::fixed(height))
}

/// The same, hugging its content: a page whose body is already taller than any guessed
/// height gets a card that grows with it instead of letting it spill out.
// 同上，高度贴合内容：内容本就高过任何估计值的页面，卡片随它长高，而不是让内容溢出去。
pub(crate) fn column_hug(
    page: Page,
    tag: &'static str,
    title: Msg,
    body: Box<dyn Element>,
    width: f32,
    cx: &Cx<'_, '_>,
) -> Box<dyn Element> {
    card(page, tag, tr(cx, title), body, width, AxisSize::hug(0.0, 0.0))
}

/// How much of the card's surface colour survives the wallpaper behind it.
/// 卡片表面色在壁纸之上的保留比例。
const CARD_ALPHA: f32 = 0.85;

fn card(
    page: Page,
    tag: &'static str,
    title: String,
    body: Box<dyn Element>,
    width: f32,
    height: AxisSize,
) -> Box<dyn Element> {
    // The column is an MD3 filled card: `surfaceContainerHighest` at elevation 0, so it
    // follows the theme instead of pinning one dark colour.
    // 列是一张 MD3 填充卡片：`surfaceContainerHighest`、高程 0，因此跟随主题而非钉死一种深色。
    let pack = ui_widgets_md3::pack_of(ui_style::StyleScope::of(&root_env()).appearance);
    // Translucent, so the wallpaper reads through the card; the alpha is what keeps the
    // samples legible over a busy photo.
    // 半透明，壁纸因此透得过卡片；这个 alpha 正是样例在繁复照片上仍可读的原因。
    let fill = Color {
        a: CARD_ALPHA,
        ..pack.ink("surfaceContainerHighest").unwrap_or(Color::WHITE)
    };
    let title_ink = pack.ink("onSurfaceVariant").unwrap_or(Color::BLACK);
    Box::new(
        Container::new(col_id(page, tag), NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fixed(width),
                height,
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .padding(Insets::all(12.0))
            .gap(12.0)
            .background(fill, Corners::all(12.0))
            .child_decl(label(
                Id::of(("coltitle", tag, page.tag())),
                title,
                14.0,
                title_ink,
                width - 24.0,
            ))
            .child(body),
    )
}

/// A section column at an explicit width, for a page whose samples need more room than `COL_W`.
// 一节的列，宽度可指定，供样本需要比 `COL_W` 更宽的页面使用。
pub(crate) fn column_w(
    page: Page,
    tag: &'static str,
    title: Msg,
    body: Box<dyn Element>,
    width: f32,
    height: f32,
    cx: &Cx<'_, '_>,
) -> Box<dyn Element> {
    column_text(page, tag, tr(cx, title), body, width, height)
}

pub(crate) fn captioned_row(id: Id, control: Box<dyn Element>, caption: impl Into<String>) -> Container {
    Container::new(id.with("row"), NodeKind::Column)
        .gap(2.0)
        .child_decl(label(id.with("cap"), caption.into(), 11.0, muted(), COL_W - 24.0))
        .child(control)
}

/// A scope whose `disabled` flag is on, for static disabled samples.
// 打开 `disabled` 标志的作用域，供静态禁用样本使用。
pub(crate) fn disabled_env() -> std::sync::Arc<Env> {
    Env::with(
        Some(root_env()),
        ui_widgets_md3::Md3Options { disabled: true, ..Default::default() },
    )
}

pub(crate) const NAV_SCROLL: Id = Id::str("nav/scroll");

/// The left nav tree: a standard MD3 drawer with pages as destinations.
// 左侧导航树：一个标准 MD3 抽屉，页面作为目标。
/// The left nav: its element plus the drawer's content height, so the app can clamp the
/// scroll offset. The element borrows `cx`'s frame only; the height is a plain number.
/// 左侧导航：元素加抽屉内容高，供应用夹取滚动偏移。元素只借用当前帧；高度是普通数字。
pub(crate) fn sidebar(
    page: Page,
    _value: f32,
    cx: &mut Cx<'_, '_>,
) -> Box<dyn Element> {
    use ui_widgets_md3::{DrawerEntry, DrawerItem};

    // Translated labels are owned strings; the entries borrow from them, so they must be
    // fully built before `new_with` takes the borrows.
    // 翻译标签是自有字符串；条目从它们借用，因此必须先完整构建，再让 `new_with` 借用。
    let mut labels: Vec<String> = Vec::new();
    for (_, section_msg, pages) in SECTIONS {
        labels.push(tr(cx, section_msg));
        for p in pages.iter() {
            labels.push(tr(cx, p.title()));
        }
    }
    let mut entries: Vec<DrawerEntry> = Vec::new();
    let mut k = 0;
    for (_, _, pages) in SECTIONS {
        entries.push(DrawerEntry::Headline(labels[k].as_str()));
        k += 1;
        for p in pages.iter() {
            entries.push(DrawerEntry::Item(DrawerItem {
                id: p.nav_id(),
                label: labels[k].as_str(),
                icon: None,
            }));
            k += 1;
        }
    }

    // Resolve through the kit so a running theme transition blends this drawer's colours
    // too; `pack_of` alone would snap to the target scheme.
    // 经 kit 解析，让正在进行的主题过渡也混合本抽屉的颜色；单独 `pack_of` 会硬切到目标方案。
    let drawer_pack = Md3Kit::new().pack_for(cx);
    let drawer = ui_widgets_md3::Md3NavDrawer::new_with(
        ui_widgets_md3::Md3Options::default(),
        ui_widgets_md3::DrawerParams {
            id: Id::str("gallery/drawer"),
            entries: &entries,
            selected: Some(page.nav_id()),
            disabled: false,
        },
        cx,
        &drawer_pack,
    );
    // The drawer paints its own `surface-container`, so the scroll container only clips and
    // scrolls it; any background here would double-paint over the drawer's rounded edge.
    // 抽屉自绘 `surface-container`，因此滚动容器只负责裁切与滚动；
    // 在这里加背景会在抽屉圆角边之外重复上色。
    // The engine owns the offset (`SCROLL_OWNED`); the fill height lets the shell's cross
    // stretch size the viewport, so a window resize needs no recomputed constant.
    // 偏移归引擎管理（`SCROLL_OWNED`）；fill 高度让外壳的交叉拉伸决定视口，
    // 窗口缩放不必重算常量。
    // The drawer stays a `Styled` element: only the element adapter reports its `change`,
    // which is how a nav row tells the app which destination was picked.
    // 抽屉保持为 `Styled` 元素：只有元素适配器会上报它的 `change`，
    // 导航行正是借此告诉应用选中的目标。
    let scoped = cx.at_scope(base_env());
    Box::new(
        Container::new(NAV_SCROLL, NodeKind::Column)
            .size(SizeClass {
                width: AxisSize::fixed(NAV_W),
                height: AxisSize::fill(0.0, 0.0),
                grow_x: Grow::No,
                grow_y: Grow::No,
            })
            .scrollable()
            .sense(ui_core::Sense::SCROLL_OWNED)
            .child(scoped.element(Box::new(drawer))),
    )
}

/// The top app bar: the page's title plus an appearance toggle in the trailing slot.
/// 顶部应用栏：页面标题，加尾部槽里的外观切换。
pub(crate) fn toolbar(title: &str, cx: &mut Cx<'_, '_>) -> Box<dyn Element> {
    let action = ui_widgets_md3::AppBarAction {
        id: Id::str("toolbar/appearance"),
        icon: ms("dark_mode"),
    };
    // Same kit resolution as the drawer: the app bar fades through a theme transition.
    // 与抽屉同一条 kit 解析：应用栏在主题过渡中平滑渐变。
    let bar_pack = Md3Kit::new().pack_for(cx);
    let bar = ui_widgets_md3::Md3AppBar::new_with(
        ui_widgets_md3::Md3Options::default(),
        ui_widgets_md3::AppBarParams {
            id: Id::str("toolbar"),
            variant: ui_widgets_md3::AppBarVariant::Small,
            title,
            subtitle: None,
            leading: ui_widgets_md3::AppBarLeading::None,
            actions: std::slice::from_ref(&action),
            width: CONTENT_W,
        },
        false,
        false,
        cx,
        &bar_pack,
    );
    cx.element(Box::new(bar))
}



/// Map the gallery's `dark` flag to a design appearance.
// 把 gallery 的 dark 标志映射到设计外观。
pub(crate) fn appearance_of(dark: bool) -> ui_design::Appearance {
    if dark {
        ui_design::Appearance::Dark
    } else {
        ui_design::Appearance::Light
    }
}
