# Strings owned by ui-widgets-md3: date and time picker defaults.
# 归 ui-widgets-md3 所有的文案：日期与时间选择器的默认值。

## Date picker
## 日期选择器

md3-date-picker-header = Select date
md3-date-picker-month-january = January
md3-date-picker-month-february = February
md3-date-picker-month-march = March
md3-date-picker-month-april = April
md3-date-picker-month-may = May
md3-date-picker-month-june = June
md3-date-picker-month-july = July
md3-date-picker-month-august = August
md3-date-picker-month-september = September
md3-date-picker-month-october = October
md3-date-picker-month-november = November
md3-date-picker-month-december = December
md3-date-picker-weekday-mon = M
md3-date-picker-weekday-tue = T
md3-date-picker-weekday-wed = W
md3-date-picker-weekday-thu = T
md3-date-picker-weekday-fri = F
md3-date-picker-weekday-sat = S
md3-date-picker-weekday-sun = S

## Time picker
## 时间选择器

md3-time-picker-title = Enter time
md3-time-picker-hour = Hour
md3-time-picker-minute = Minute
md3-time-picker-am = AM
md3-time-picker-pm = PM
