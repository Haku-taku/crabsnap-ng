# Strings owned by ui-widgets: shortcut labels and list counts.
# 归 ui-widgets 所有的文案：快捷键标签与列表计数。

## Shortcuts
## 快捷键

widgets-shortcut-ctrl = Ctrl
widgets-shortcut-alt = Alt
widgets-shortcut-shift = Shift
widgets-shortcut-super = Super
# Separator between held modifiers and the key; spaces belong to the translation.
# 修饰键与键之间的分隔符；空格属于译文。
widgets-shortcut-separator = { " + " }
widgets-shortcut-escape = Esc
widgets-shortcut-enter = Enter
widgets-shortcut-space = Space
widgets-shortcut-tab = Tab
widgets-shortcut-backspace = Backspace
widgets-shortcut-delete = Delete
widgets-shortcut-home = Home
widgets-shortcut-end = End
widgets-shortcut-left = Left
widgets-shortcut-right = Right
widgets-shortcut-up = Up
widgets-shortcut-down = Down

## Lists
## 列表

# CLDR plural categories are variant keys, not a "-plural" suffix.
# CLDR 复数类别是变体 key，不是 "-plural" 后缀。
widgets-list-selected-count =
    { $count ->
        [one] { $count } item selected
       *[other] { $count } items selected
    }

## Menus
## 菜单

# The engine's built-in text rows; an app names them through `set_text_menu_labels`.
# 引擎内建的文本行；应用通过 `set_text_menu_labels` 为它们命名。
widgets-menu-select-all = Select all
widgets-menu-copy = Copy
widgets-menu-cut = Cut
widgets-menu-paste = Paste
