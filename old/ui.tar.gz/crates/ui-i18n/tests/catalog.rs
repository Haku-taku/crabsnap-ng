//! The catalog's three load-bearing contracts: locale parity, arguments, and fallback.
//! catalog 的三条承重契约：locale 完整性、参数、回退。

use unic_langid::{langid, LanguageIdentifier};
use ui_i18n::{Args, Catalog, Msg, ALL};

/// A `Catalog` must cross the `Env` boundary, which requires `Send + Sync`.
/// `Catalog` 必须跨过 `Env` 边界，因此需要 `Send + Sync`。
#[test]
fn a_catalog_is_send_and_sync() {
    fn assert_send_sync<T: Send + Sync>() {}
    assert_send_sync::<Catalog>();
}

/// Missing translations are the core risk this design guards; every locale needs every key.
/// 漏翻是这套设计的核心风险；每个 locale 都必须拥有每一个 key。
#[test]
fn every_locale_defines_every_generated_message() {
    for files in ui_i18n::LOCALES {
        let locale: LanguageIdentifier = files.tag.parse().expect("a locale tag");
        // Only this locale's source: the fallback chain must not hide a missing key.
        // 只放这个 locale 的原文：回退链不得掩盖缺失的 key。
        let catalog = Catalog::from_sources(&locale, &locale, &[(files.tag, files.source)])
            .unwrap_or_else(|error| panic!("{}: {error}", files.tag));
        for (index, spec) in ALL.iter().enumerate() {
            assert!(
                catalog.has(Msg::from_index(index)),
                "{} is missing {} ({:?})",
                files.tag,
                spec.id,
                spec.attr
            );
        }
    }
}

/// A parameterized message proves `text_with` reaches Fluent's CLDR plural branches.
/// 一条带参消息证明 `text_with` 能走到 Fluent 的 CLDR 复数分支。
#[test]
fn a_plural_message_picks_the_cldr_branch() {
    let en = Catalog::builtin(langid!("en"), langid!("en")).expect("en");
    let zh = Catalog::builtin(langid!("zh-CN"), langid!("en")).expect("zh-CN");
    let mut args = Args::new();

    args.set("count", 1);
    assert_eq!(
        &*en.text_with(Msg::WIDGETS_LIST_SELECTED_COUNT, &args),
        "1 item selected"
    );

    args.set("count", 3);
    assert_eq!(
        &*en.text_with(Msg::WIDGETS_LIST_SELECTED_COUNT, &args),
        "3 items selected"
    );
    assert_eq!(
        &*zh.text_with(Msg::WIDGETS_LIST_SELECTED_COUNT, &args),
        "已选择 3 个项目"
    );
}

const EN: &str = r#"
widgets-shortcut-ctrl = Ctrl
widgets-shortcut-enter = Enter
"#;
const ZH: &str = r#"
widgets-shortcut-ctrl = 控制
"#;

/// `zh-CN` must reach `zh`, and a key missing there must reach `en`.
/// `zh-CN` 必须落到 `zh`；`zh` 缺失的 key 必须落到 `en`。
#[test]
fn a_region_falls_back_to_its_language_then_to_english() {
    let requested: LanguageIdentifier = "zh-CN".parse().expect("zh-CN");
    let fallback: LanguageIdentifier = "en".parse().expect("en");
    let catalog =
        Catalog::from_sources(&requested, &fallback, &[("en", EN), ("zh", ZH)]).expect("catalog");

    assert_eq!(&*catalog.text_by_id("widgets-shortcut-ctrl"), "控制");
    assert_eq!(&*catalog.text_by_id("widgets-shortcut-enter"), "Enter");
    assert_eq!(&*catalog.text_by_id("__missing-for-test"), "⟨__missing-for-test⟩");
}
