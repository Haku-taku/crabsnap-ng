//! Locale bundles, the explicit fallback chain, and preformatted static messages.
//! locale bundle、显式回退链，以及预格式化的静态消息。

use std::collections::HashSet;
use std::fmt;
use std::sync::{Arc, Mutex, OnceLock};

use fluent_bundle::concurrent::FluentBundle;
use fluent_bundle::{FluentArgs, FluentResource};
use unic_langid::LanguageIdentifier;

use crate::{Args, Msg, MsgSpec, ALL, LOCALES};

/// A loaded catalog: one bundle per locale, in fallback order.
/// 已加载的 catalog：每个 locale 一个 bundle，按回退顺序排列。
pub struct Catalog {
    chain: Vec<LocaleBundle>,
    /// Messages already logged, so a missing key does not warn on every frame.
    /// 已记录过的消息，避免缺 key 每帧刷日志。
    warned: Mutex<HashSet<(usize, String)>>,
}

struct LocaleBundle {
    locale: LanguageIdentifier,
    bundle: FluentBundle<FluentResource>,
    /// Preformatted no-argument messages, indexed by `Msg`.
    /// 预格式化的无参消息，按 `Msg` 索引。
    static_text: Vec<Option<Arc<str>>>,
}

impl Catalog {
    /// Build from the locales embedded in this crate.
    /// 用本 crate 内嵌的 locale 构建。
    pub fn builtin(
        requested: LanguageIdentifier,
        fallback: LanguageIdentifier,
    ) -> Result<Catalog, LoadError> {
        let mut sources = Vec::with_capacity(LOCALES.len());
        for files in LOCALES {
            let locale: LanguageIdentifier = files
                .tag
                .parse()
                .map_err(|_| LoadError::BadLocale(files.tag.to_string()))?;
            sources.push((locale, files.source));
        }
        build(&requested, &fallback, &sources)
    }

    /// Build from arbitrary FTL sources, keyed by locale tag; tests and apps use this.
    /// 用任意 FTL 原文构建，以 locale 标签为键；测试与应用使用它。
    pub fn from_sources(
        requested: &LanguageIdentifier,
        fallback: &LanguageIdentifier,
        sources: &[(&str, &str)],
    ) -> Result<Catalog, LoadError> {
        let mut parsed = Vec::with_capacity(sources.len());
        for (tag, source) in sources {
            let locale: LanguageIdentifier = tag
                .parse()
                .map_err(|_| LoadError::BadLocale((*tag).to_string()))?;
            parsed.push((locale, *source));
        }
        build(requested, fallback, &parsed)
    }

    /// The read-only English catalog used when an `Env` carries none.
    /// `Env` 未携带 catalog 时使用的只读英文 catalog。
    pub fn english() -> &'static Catalog {
        static ENGLISH: OnceLock<Catalog> = OnceLock::new();
        ENGLISH.get_or_init(|| {
            let en: LanguageIdentifier = "en".parse().expect("en is a locale");
            Catalog::builtin(en.clone(), en).expect("built-in English catalog")
        })
    }

    /// A no-argument message: one array index and one refcount bump.
    /// 无参消息：一次数组索引加一次引用计数。
    pub fn text(&self, msg: Msg) -> Arc<str> {
        let index = msg.index();
        let spec = msg.spec();
        for locale in &self.chain {
            if let Some(Some(text)) = locale.static_text.get(index) {
                return text.clone();
            }
            if locale.contains(spec) {
                self.warn_once(index, &locale.locale);
            }
        }
        self.missing(index, spec)
    }

    /// A parameterized message: format on demand, falling through locales on error.
    /// 带参消息：按需格式化，出错时沿回退链继续。
    pub fn text_with(&self, msg: Msg, args: &Args<'_>) -> Arc<str> {
        let spec = msg.spec();
        for locale in &self.chain {
            if !locale.contains(spec) {
                continue;
            }
            if let Some(text) = format_in(&locale.bundle, spec, Some(args.inner())) {
                return text;
            }
            self.warn_once(msg.index(), &locale.locale);
        }
        self.missing(msg.index(), spec)
    }

    /// The app's own key; built-in keys use `Msg`.
    /// 应用自有 key；内置 key 走 `Msg`。
    pub fn text_by_id(&self, id: &str) -> Arc<str> {
        self.by_id(id, None)
    }

    /// The same, with arguments.
    /// 同上，带参数。
    pub fn text_by_id_with(&self, id: &str, args: &Args<'_>) -> Arc<str> {
        self.by_id(id, Some(args.inner()))
    }

    /// Whether any locale in the chain defines this message.
    /// 回退链上是否有任何 locale 定义了这条消息。
    pub fn has(&self, msg: Msg) -> bool {
        self.chain.iter().any(|locale| locale.contains(msg.spec()))
    }

    fn by_id(&self, id: &str, args: Option<&FluentArgs<'_>>) -> Arc<str> {
        for locale in &self.chain {
            if let Some(text) = format_by_id(&locale.bundle, id, args) {
                return text;
            }
        }
        let key = (usize::MAX, id.to_string());
        if self.remember(key) {
            log::error!("ui-i18n: no locale provides {id}");
        }
        Arc::from(format!("⟨{id}⟩"))
    }

    fn warn_once(&self, index: usize, locale: &LanguageIdentifier) {
        let key = (index, locale.to_string());
        if self.remember(key) {
            let spec = &ALL[index];
            log::warn!(
                "ui-i18n: {locale} cannot format {} ({:?})",
                spec.id,
                spec.attr
            );
        }
    }

    fn missing(&self, index: usize, spec: &MsgSpec) -> Arc<str> {
        let name = match spec.attr {
            Some(attr) => format!("{}.{}", spec.id, attr),
            None => spec.id.to_string(),
        };
        if self.remember((index, String::from("<missing>"))) {
            log::error!("ui-i18n: no locale provides {name}");
        }
        Arc::from(format!("⟨{name}⟩"))
    }

    fn remember(&self, key: (usize, String)) -> bool {
        let mut warned = match self.warned.lock() {
            Ok(warned) => warned,
            Err(poisoned) => poisoned.into_inner(),
        };
        warned.insert(key)
    }
}

impl LocaleBundle {
    fn load(locale: LanguageIdentifier, source: &str) -> Result<Self, LoadError> {
        let resource = FluentResource::try_new(source.to_string()).map_err(|(_, errors)| {
            LoadError::Parse {
                locale: locale.to_string(),
                errors: format!("{errors:?}"),
            }
        })?;
        let mut bundle = FluentBundle::new_concurrent(vec![locale.clone()]);
        bundle.set_use_isolating(false);
        bundle.add_builtins().map_err(|error| LoadError::Build {
            locale: locale.to_string(),
            errors: format!("{error:?}"),
        })?;
        bundle.add_resource(resource).map_err(|errors| LoadError::Build {
            locale: locale.to_string(),
            errors: format!("{errors:?}"),
        })?;
        let static_text = ALL
            .iter()
            .map(|spec| format_in(&bundle, spec, None))
            .collect();
        Ok(Self { locale, bundle, static_text })
    }

    fn contains(&self, spec: &MsgSpec) -> bool {
        let Some(message) = self.bundle.get_message(spec.id) else {
            return false;
        };
        match spec.attr {
            Some(attr) => message.get_attribute(attr).is_some(),
            None => message.value().is_some(),
        }
    }
}

fn build(
    requested: &LanguageIdentifier,
    fallback: &LanguageIdentifier,
    sources: &[(LanguageIdentifier, &str)],
) -> Result<Catalog, LoadError> {
    let mut chain = Vec::new();
    for locale in fallback_chain(requested, fallback) {
        if let Some((_, source)) = sources.iter().find(|(tag, _)| *tag == locale) {
            chain.push(LocaleBundle::load(locale, source)?);
        }
    }
    if chain.is_empty() {
        return Err(LoadError::NoLocales(requested.to_string()));
    }
    Ok(Catalog { chain, warned: Mutex::new(HashSet::new()) })
}

/// Build `zh-Hans-CN -> zh-Hans -> zh -> en` without asking a negotiator.
/// 直接构造 `zh-Hans-CN -> zh-Hans -> zh -> en`，不依赖协商器。
fn fallback_chain(
    requested: &LanguageIdentifier,
    fallback: &LanguageIdentifier,
) -> Vec<LanguageIdentifier> {
    let mut out = vec![requested.clone()];
    if requested.script.is_some() {
        let mut lid = requested.clone();
        lid.region = None;
        lid.clear_variants();
        out.push(lid);
    }
    if requested.region.is_some() {
        let mut lid = requested.clone();
        lid.script = None;
        lid.clear_variants();
        out.push(lid);
    }
    let mut language_only = requested.clone();
    language_only.script = None;
    language_only.region = None;
    language_only.clear_variants();
    out.push(language_only);
    out.push(fallback.clone());
    let mut fallback_language = fallback.clone();
    fallback_language.script = None;
    fallback_language.region = None;
    fallback_language.clear_variants();
    out.push(fallback_language);
    // Stable dedup: when requested == fallback, an earlier tag can repeat later.
    // 稳定去重：当 requested == fallback 时，较早的标签可能在后面重复。
    let mut unique = Vec::with_capacity(out.len());
    for locale in out {
        if !unique.contains(&locale) {
            unique.push(locale);
        }
    }
    unique
}

fn format_in(
    bundle: &FluentBundle<FluentResource>,
    spec: &MsgSpec,
    args: Option<&FluentArgs<'_>>,
) -> Option<Arc<str>> {
    let message = bundle.get_message(spec.id)?;
    let pattern = match spec.attr {
        Some(attr) => message.get_attribute(attr)?.value(),
        None => message.value()?,
    };
    let mut errors = Vec::new();
    let text = bundle.format_pattern(pattern, args, &mut errors);
    errors.is_empty().then(|| Arc::from(text.as_ref()))
}

fn format_by_id(
    bundle: &FluentBundle<FluentResource>,
    id: &str,
    args: Option<&FluentArgs<'_>>,
) -> Option<Arc<str>> {
    let (message_id, attr) = match id.split_once('.') {
        Some((message_id, attr)) => (message_id, Some(attr)),
        None => (id, None),
    };
    let message = bundle.get_message(message_id)?;
    let pattern = match attr {
        Some(attr) => message.get_attribute(attr)?.value(),
        None => message.value()?,
    };
    let mut errors = Vec::new();
    let text = bundle.format_pattern(pattern, args, &mut errors);
    errors.is_empty().then(|| Arc::from(text.as_ref()))
}

/// Why a catalog could not be built.
/// catalog 无法构建的原因。
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum LoadError {
    /// No locale in the chain had an embedded source.
    /// 回退链上没有任何 locale 有内嵌原文。
    NoLocales(String),
    /// A locale tag did not parse.
    /// locale 标签无法解析。
    BadLocale(String),
    /// An FTL source failed to parse.
    /// FTL 原文解析失败。
    Parse { locale: String, errors: String },
    /// Fluent rejected a resource or a builtin.
    /// Fluent 拒绝了某个资源或内置函数。
    Build { locale: String, errors: String },
}

impl fmt::Display for LoadError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            LoadError::NoLocales(locale) => write!(f, "no locale sources for {locale}"),
            LoadError::BadLocale(tag) => write!(f, "invalid locale tag {tag}"),
            LoadError::Parse { locale, errors } => {
                write!(f, "cannot parse {locale}: {errors}")
            }
            LoadError::Build { locale, errors } => {
                write!(f, "cannot build {locale}: {errors}")
            }
        }
    }
}

impl std::error::Error for LoadError {}
