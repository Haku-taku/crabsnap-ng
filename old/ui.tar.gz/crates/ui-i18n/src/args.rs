//! The parameter bag controls pass to a message, without naming Fluent in their signatures.
//! 控件传给消息的参数袋，调用签名里不出现 Fluent 类型。

use fluent_bundle::FluentArgs;

/// A value a message argument accepts: numbers and strings.
/// 消息参数接受的值：数字与字符串。
pub use fluent_bundle::FluentValue as Value;

/// Anything Fluent can read as a value; implemented for the types callers actually pass.
/// 任何 Fluent 能读取的值；已为调用方真正会传的类型实现。
pub trait IntoArg<'a> {
    /// Convert into Fluent's own value type.
    /// 转成 Fluent 自己的值类型。
    #[doc(hidden)]
    fn into_value(self) -> Value<'a>;
}

impl<'a, V: Into<Value<'a>>> IntoArg<'a> for V {
    fn into_value(self) -> Value<'a> {
        self.into()
    }
}

/// Named arguments for one parameterized message.
/// 一条带参消息的具名参数。
pub struct Args<'a> {
    inner: FluentArgs<'a>,
}

impl<'a> Args<'a> {
    pub fn new() -> Self {
        Self { inner: FluentArgs::new() }
    }

    /// Set `name` to `value`; numbers select plural categories, strings feed `select`.
    /// 把 `name` 设为 `value`；数字参与复数类别选择，字符串供 `select` 使用。
    pub fn set<V: IntoArg<'a>>(&mut self, name: &'a str, value: V) {
        self.inner.set(name, value.into_value());
    }

    /// Read an argument back, if it was set.
    /// 若已设置，读回一个参数。
    pub fn get(&self, name: &'a str) -> Option<&Value<'a>> {
        self.inner.get(name)
    }

    pub(crate) fn inner(&self) -> &FluentArgs<'a> {
        &self.inner
    }
}

impl Default for Args<'_> {
    fn default() -> Self {
        Self::new()
    }
}
