//! Fluent-backed catalogs for the workspace's built-in strings.
//! 本 workspace 内置文案的 Fluent catalog。
//!
//! The build script turns `locales/en/**/*.ftl` into `Msg` constants, so a missing key is a
//! compile error. No-argument messages are formatted once per locale and indexed by `Msg`.
//! 构建脚本把 `locales/en/**/*.ftl` 变成 `Msg` 常量，漏 key 即编译错误。
//! 无参消息按 locale 预格式化，并按 `Msg` 索引。

mod args;
mod catalog;

include!(concat!(env!("OUT_DIR"), "/msg.rs"));

pub use args::{Args, IntoArg, Value};
pub use catalog::{Catalog, LoadError};
pub use unic_langid::LanguageIdentifier;
