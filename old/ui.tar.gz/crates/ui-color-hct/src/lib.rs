//! HCT: CAM16 hue and chroma at a CIELAB L\* tone, written from published colour science.
//! HCT：以 CIELAB L\* 为 tone 的 CAM16 色相与彩度，依公开色彩科学自行实现。
//!
//! Tone is deliberately CIELAB L\*, not CAM16 lightness: L\* maps to relative luminance, so
//! tone differences translate directly into contrast ratios.
//! tone 故意取 CIELAB L\* 而非 CAM16 明度：L\* 对应相对亮度，tone 差即对比度差。

pub mod cam;
pub mod contrast;
pub mod lab;
pub mod palette;
pub mod solve;
pub mod viewing;

pub use cam::{argb_from_cam_with, cam_from_argb, cam_from_argb_with, linrgb_from_jch, Cam};
pub use contrast::{
    darker, darker_unsafe, enable_light_foreground, lighter, lighter_unsafe, ratio_of_tones,
    ratio_of_ys, tone_allows_light_foreground, tone_prefers_light_foreground,
};
pub use lab::{
    argb_from_linrgb, argb_from_tone, delinearized, linrgb_from_xyz, lstar_from_y, rgb, tone_of,
    xyz_from_argb, y_from_lstar,
};
pub use palette::{KeyColor, TonalPalette};
pub use solve::{argb_from_hcl, argb_from_hcl_in};
pub use viewing::Viewing;
