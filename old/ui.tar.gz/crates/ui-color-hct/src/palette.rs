//! A tonal palette: one hue and one chroma, any tone; plus the key-colour search.
//! 色调调色板：固定色相与彩度、任意 tone；外加 key colour 搜索。

use crate::cam::cam_from_argb;
use crate::solve::argb_from_hcl;

/// What the search asks for when probing how much chroma a tone can hold.
/// 探测某个 tone 能承载多少彩度时所请求的上限。
const CHROMA_PROBE: f64 = 200.0;

/// Colours that share a hue and a chroma and differ only in tone.
/// 同色相同彩度、只有 tone 不同的颜色集合。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct TonalPalette {
    pub hue: f64,
    pub chroma: f64,
}

impl TonalPalette {
    pub const fn new(hue: f64, chroma: f64) -> Self {
        Self { hue, chroma }
    }

    /// The palette a colour belongs to: its hue and chroma, whatever tone it sits at.
    /// 颜色所属的调色板：取它的色相与彩度，tone 无关。
    pub fn of(argb: u32) -> Self {
        let cam = cam_from_argb(argb);
        Self::new(cam.hue, cam.chroma)
    }

    /// The colour at this tone; chroma shrinks when sRGB has no room for it.
    /// 该 tone 的颜色；sRGB 装不下时彩度会收缩。
    pub fn tone(&self, tone: f64) -> u32 {
        argb_from_hcl(self.hue, self.chroma, tone)
    }

    /// The most chroma this hue can reach at this tone inside sRGB.
    /// 该色相在此 tone 于 sRGB 内可达的最大彩度。
    pub fn max_chroma(&self, tone: f64) -> f64 {
        cam_from_argb(argb_from_hcl(self.hue, CHROMA_PROBE, tone)).chroma
    }
}

/// The representative colour of a palette: tone and chroma where chroma peaks.
/// 调色板的代表色：彩度达到峰值的那个 tone 与彩度。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct KeyColor {
    pub hue: f64,
    pub requested_chroma: f64,
}

impl KeyColor {
    pub const fn new(hue: f64, requested_chroma: f64) -> Self {
        Self { hue, requested_chroma }
    }

    /// Coarse scan for the peak, then refine by halves until the step is under 0.01.
    /// 先粗扫找峰值，再二分细化到步长小于 0.01。
    pub fn pivot_tone(&self) -> f64 {
        let palette = TonalPalette::new(self.hue, self.requested_chroma);
        let mut best_tone = 50.0;
        let mut best = f64::MIN;
        for tone in (0..=100).map(|t| (t as f64) * 2.0 - 100.0).filter(|t| (0.0..=100.0).contains(t)) {
            let c = palette.max_chroma(tone);
            if c > best {
                best = c;
                best_tone = tone;
            }
        }
        let (mut lo, mut hi) = ((best_tone - 2.0).max(0.0), (best_tone + 2.0).min(100.0));
        while hi - lo > 0.01 {
            let m = (lo + hi) * 0.5;
            if palette.max_chroma(m - 0.01) >= palette.max_chroma(m + 0.01) {
                hi = m;
            } else {
                lo = m;
            }
        }
        (lo + hi) * 0.5
    }

    /// The palette's most saturated usable colour, at the chroma the request allows.
    /// 调色板可用的最高饱和色，彩度取请求允许的范围。
    pub fn create(&self) -> u32 {
        let tone = self.pivot_tone();
        let achievable = TonalPalette::new(self.hue, CHROMA_PROBE).max_chroma(tone);
        TonalPalette::new(self.hue, self.requested_chroma.min(achievable)).tone(tone)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::lab::tone_of;

    #[test]
    fn a_palette_steps_tone_without_drifting_hue() {
        let palette = TonalPalette::new(265.0, 36.0);
        let mut previous = f64::MIN;
        for tone in [10.0, 20.0, 40.0, 60.0, 80.0, 90.0] {
            let argb = palette.tone(tone);
            assert!((tone_of(argb) - tone).abs() < 0.8, "tone {tone}");
            assert!((cam_from_argb(argb).hue - 265.0).abs() < 2.0, "hue at {tone}");
            assert!(tone > previous);
            previous = tone;
        }
    }

    #[test]
    fn a_chroma_beyond_the_gamut_is_reported_as_capped() {
        let palette = TonalPalette::new(300.0, 120.0);
        assert!(palette.max_chroma(95.0) < 120.0);
        assert!(palette.max_chroma(50.0) > palette.max_chroma(95.0));
    }

    #[test]
    fn the_key_colour_sits_where_chroma_peaks() {
        let key = KeyColor::new(265.0, 36.0);
        let pivot = key.pivot_tone();
        assert!((10.0..=90.0).contains(&pivot), "pivot {pivot}");
        let at_pivot = TonalPalette::new(265.0, 36.0).max_chroma(pivot);
        for probe in [pivot - 10.0, pivot + 10.0] {
            if (0.0..=100.0).contains(&probe) {
                assert!(at_pivot >= TonalPalette::new(265.0, 36.0).max_chroma(probe) - 0.5);
            }
        }
    }
    // When the gamut has room, a palette must hold both its chroma and the tone asked for.
    // 色域装得下时，调色板必须同时满足请求的彩度与 tone。
    #[test]
    fn a_palette_holds_chroma_and_tone_together_when_the_gamut_allows_it() {
        let palette = TonalPalette::new(299.0, 36.0);
        assert!(palette.max_chroma(40.0) > 36.0, "no room to test this claim");
        let argb = palette.tone(40.0);
        let cam = cam_from_argb(argb);
        assert!((cam.chroma - 36.0).abs() < 1.0, "chroma {}", cam.chroma);
        assert!((tone_of(argb) - 40.0).abs() < 0.6, "tone {}", tone_of(argb));
    }

    #[test]
    fn the_key_colour_meets_the_requested_chroma_when_the_gamut_allows_it() {
        let argb = KeyColor::new(60.0, 20.0).create();
        let cam = cam_from_argb(argb);
        assert!((cam.chroma - 20.0).abs() < 1.0, "chroma {}", cam.chroma);
    }
}
