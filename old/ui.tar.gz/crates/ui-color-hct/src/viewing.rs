//! CAM16 viewing conditions, derived from the surround/luminance inputs.
//! CAM16 观看条件，由环境光与背景等输入推导。

use crate::lab::{WHITE_D65, y_from_lstar};

/// The parameters CAM16 needs beyond the stimulus itself.
/// CAM16 除刺激值之外还需要的那些参数。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct Viewing {
    pub adapting_luminance: f64,
    pub background_lstar: f64,
    pub surround: f64,
    pub discounting_illuminant: bool,
    /// Background Y relative to the white point Y.
    /// 背景 Y 相对白点 Y 的比。
    pub n: f64,
    pub aw: f64,
    pub nbb: f64,
    pub ncb: f64,
    pub c: f64,
    pub n_c: f64,
    pub fl: f64,
    pub fl_root: f64,
    pub z: f64,
    pub white: [f64; 3],
    pub rgb_d: [f64; 3],
}

fn lerp(start: f64, stop: f64, amount: f64) -> f64 {
    (1.0 - amount) * start + amount * stop
}

/// CAT02-like LMS transform of the white point, used for the adaptation factors.
/// 白点的类 CAT02 LMS 变换，用于求适应系数。
fn cone_response(xyz: [f64; 3]) -> [f64; 3] {
    [
        0.401288 * xyz[0] + 0.650173 * xyz[1] - 0.051461 * xyz[2],
        -0.250268 * xyz[0] + 1.204414 * xyz[1] + 0.045854 * xyz[2],
        -0.002079 * xyz[0] + 0.048952 * xyz[1] + 0.953127 * xyz[2],
    ]
}

impl Viewing {
    /// Derive every constant; a background below L\* 30 is lifted to 30, as the model requires.
    /// 推导全部常数；低于 L\* 30 的背景按模型要求抬到 30。
    pub fn create(
        white: [f64; 3],
        adapting_luminance: f64,
        background_lstar: f64,
        surround: f64,
        discounting_illuminant: bool,
    ) -> Self {
        let bg = background_lstar.max(30.0);
        let rgb_w = cone_response(white);
        let f = 0.8 + surround / 10.0;
        let c = if f >= 0.9 {
            lerp(0.59, 0.69, (f - 0.9) * 10.0)
        } else {
            lerp(0.525, 0.59, (f - 0.8) * 10.0)
        };
        let d = if discounting_illuminant {
            1.0
        } else {
            f * (1.0 - (1.0 / 3.6) * ((-adapting_luminance - 42.0) / 92.0).exp())
        }
        .clamp(0.0, 1.0);
        let rgb_d = [
            d * (100.0 / rgb_w[0]) + 1.0 - d,
            d * (100.0 / rgb_w[1]) + 1.0 - d,
            d * (100.0 / rgb_w[2]) + 1.0 - d,
        ];
        let k = 1.0 / (5.0 * adapting_luminance + 1.0);
        let k4 = k * k * k * k;
        let k4f = 1.0 - k4;
        let fl = k4 * adapting_luminance
            + 0.1 * k4f * k4f * (5.0 * adapting_luminance).powf(1.0 / 3.0);
        let fl_root = fl.powf(0.25);
        let n = y_from_lstar(bg) / white[1];
        let z = 1.48 + n.sqrt();
        let nbb = 0.725 / n.powf(0.2);
        let factors = [
            (fl * rgb_d[0] * rgb_w[0] / 100.0).powf(0.42),
            (fl * rgb_d[1] * rgb_w[1] / 100.0).powf(0.42),
            (fl * rgb_d[2] * rgb_w[2] / 100.0).powf(0.42),
        ];
        let rgb_a = [
            400.0 * factors[0] / (factors[0] + 27.13),
            400.0 * factors[1] / (factors[1] + 27.13),
            400.0 * factors[2] / (factors[2] + 27.13),
        ];
        let aw = (40.0 * rgb_a[0] + 20.0 * rgb_a[1] + rgb_a[2]) / 20.0 * nbb;
        Self {
            adapting_luminance,
            background_lstar: bg,
            surround,
            discounting_illuminant,
            n,
            aw,
            nbb,
            ncb: nbb,
            c,
            n_c: f,
            fl,
            fl_root,
            z,
            white,
            rgb_d,
        }
    }

    /// sRGB on D65, average surround, dim adapting field: the conditions HCT defines itself under.
    /// D65 上的 sRGB、平均环境、弱适应场：HCT 自述所采用的观看条件。
    pub fn srgb() -> Self {
        Self::create(WHITE_D65, 11.725676537, 50.0, 2.0, false)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // These are the published default constants; deriving them proves the formulae.
    // 这些是公开的默认常数；由公式推出它们即证明实现忠实。
    #[test]
    fn derived_constants_match_the_published_defaults() {
        let v = Viewing::srgb();
        for (name, got, want) in [
            ("n", v.n, 0.184186503),
            ("aw", v.aw, 29.981000900),
            ("nbb", v.nbb, 1.016919255),
            ("c", v.c, 0.689999998),
            ("fl", v.fl, 0.388481468),
            ("fl_root", v.fl_root, 0.789482653),
            ("z", v.z, 1.909169555),
        ] {
            assert!((got - want).abs() < 1e-5, "{name}: got {got}, want {want}");
        }
        assert!((v.n_c - 1.0).abs() < 1e-5, "n_c: {}", v.n_c);
    }
}
