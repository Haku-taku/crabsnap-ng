//! Measure glyph position error with and without subpixel phases.
//! 测量有/无亚像素相位时的字形位置误差。
//!
//! Run: `cargo run -p ui-text-fontique --example jitter_probe --features system`

use ui_text::{Script, SubpixelBin};
use ui_text_fontique::{place_run, Shaper};

fn main() {
    let out = std::process::Command::new("fc-match")
        .args(["-f", "%{file}", "sans"])
        .output()
        .expect("fc-match");
    let path = String::from_utf8_lossy(&out.stdout).trim().to_string();
    let data: std::sync::Arc<[u8]> =
        std::sync::Arc::from(std::fs::read(&path).expect("read font").into_boxed_slice());
    let mut shaper = Shaper::new(data, 0).expect("font parses");

    let size = 13.0f32; // the small size used by window_typing
    let origin = 18.0f32;

    println!("font: {path}");
    println!("size {size}px, pen origin {origin}\n");
    println!(
        "{:>10}  {:>9}  {:>8}  {:>9}  {:>9}",
        "text", "true x", "int x", "err int", "err sub"
    );

    let mut rows: Vec<(f32, f32)> = Vec::new();
    for n in 0..12 {
        let label = format!("{n} chars");
        let run = shaper.shape(&label, size, Script::LATIN);

        // Find where the word "chars" begins: the first glyph whose cluster is a 'c'.
        // 找到 "chars" 的起点：第一个字簇为 'c' 的字形。
        let mut pen = origin;
        let mut first_word: Option<(usize, f32)> = None;
        for (i, g) in run.glyphs.iter().enumerate() {
            if label.as_bytes().get(g.cluster as usize) == Some(&b'c') && first_word.is_none() {
                first_word = Some((i, pen));
            }
            pen += g.advance;
        }
        let (idx, true_x) = first_word.expect("found 'c'");

        let flat = place_run(&run, origin, 40.0, false);
        let sub = place_run(&run, origin, 40.0, true);
        let err_int = flat[idx].origin_x as f32 - true_x;
        let err_sub =
            (sub[idx].origin_x as f32 + sub[idx].bin.as_float()) - true_x;
        println!(
            "{label:>10}  {true_x:>9.3}  {:>8}  {err_int:>+9.3}  {err_sub:>+9.3}",
            flat[idx].origin_x
        );
        rows.push((err_int, err_sub));
    }

    let max_int = rows.iter().map(|r| r.0.abs()).fold(0.0f32, f32::max);
    let max_sub = rows.iter().map(|r| r.1.abs()).fold(0.0f32, f32::max);
    println!("\nmax error: integer {max_int:.3}px -> subpixel {max_sub:.3}px");
    println!(
        "improvement: {:.1}x",
        if max_sub > 0.0 {
            max_int / max_sub
        } else {
            f32::INFINITY
        }
    );

    // Phase distribution: real text should use all four phases.
    // 相位分布：真实文本应使用全部四个相位。
    let mut counts = [0u32; 4];
    let run = shaper.shape("the quick brown fox jumps", size, Script::LATIN);
    for placed in place_run(&run, origin, 40.0, true) {
        counts[placed.bin.index() as usize] += 1;
    }
    println!("\nphase distribution (0, 1/4, 1/2, 3/4): {counts:?}");

    let _ = SubpixelBin::Zero;
}
