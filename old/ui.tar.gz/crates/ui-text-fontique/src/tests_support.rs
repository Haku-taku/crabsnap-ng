//! Font fixtures for tests, resolved through the platform provider.
//! 测试用的字体样本，通过平台 provider 解析。
//!
//! `fc-match` is a Linux tool; using the provider keeps the same tests meaningful
//! on DirectWrite and CoreText.
//! `fc-match` 是 Linux 工具；改用 provider 后，同一批测试在 DirectWrite 与 CoreText 上仍然有效。


use ui_text::{FontProvider, FontRequest, GenericFamily, Script};

/// A resolvable sans face.
/// 一个可解析的无衬线字面。
pub(crate) fn sans_face() -> Option<ui_text::FontBlob> {
    let provider = crate::system_or_isolated();
    let face = provider.resolve(&FontRequest::new(GenericFamily::SansSerif))?;
    provider.face_data(face)
}

/// A face that can render right-to-left script.
/// 一个能排从右到左文字的字面。
pub(crate) fn rtl_face() -> Option<ui_text::FontBlob> {
    let provider = crate::system_or_isolated();
    let face = *provider.fallback_chain(Script::ARABIC).first()?;
    provider.face_data(face)
}

/// Any installed colour emoji face, found by family name rather than a fixed name.
/// 任意已安装的颜色 emoji 字面，按族名查找而不是写死名字。
pub(crate) fn emoji_face() -> Option<ui_text::FontBlob> {
    let provider = crate::system_or_isolated();
    let name = provider
        .family_names()
        .into_iter()
        .find(|name| name.to_ascii_lowercase().contains("emoji"))?;
    let face = provider.resolve(&FontRequest::new(GenericFamily::SansSerif).family(name))?;
    provider.face_data(face)
}

#[cfg(test)]
mod tests {
    use super::*;

    // Without the `system` feature there is no platform font access by design, so
    // "no fixture" is expected rather than a defect.
    // 不带 `system` feature 时按设计没有平台字体访问，因此"取不到样本"是预期而非缺陷。
    #[cfg(feature = "system")]
    #[test]
    fn platform_provider_supplies_a_sans_fixture() {
        // Guards the fixtures above: without this, every font-dependent test would
        // pass vacuously by returning early.
        // 守护上面的样本：没有这条，所有依赖字体的测试都会提前返回而空跑通过。
        assert!(
            sans_face().is_some(),
            "no sans face resolved; font-dependent tests are vacuous on this platform"
        );
    }
}
