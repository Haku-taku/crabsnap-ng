//! Font bytes with the `FontRef` over them parsed once.
//! 字体字节，以及在其上只解析一次的 `FontRef`。

use swash::FontRef;
use ui_text::FontBlob;

// swash keys its shaping and scaling plan caches on a per-`FontRef` id minted from a
// global counter, so parsing the font again on every call misses every cache entry and
// rebuilds the plan each time. This cell keeps one `FontRef` alive for the face.
// swash 的整形与缩放计划缓存以每次 `FontRef` 新建的全局计数 id 为键；每调用一次就重新解析
// 会全部落空并重建计划。这个 cell 为每个字面保住同一个 `FontRef`。
self_cell::self_cell!(
    /// One font file, parsed once by both shaping and outline libraries.
    /// 一个字体文件，由整形与轮廓两套库各解析一次并保留。
    pub struct FaceData {
        owner: FontBlob,
        #[covariant]
        dependent: Faces,
    }
);

/// The two parsed views of one font file.
/// 同一个字体文件的两种解析视图。
pub struct Faces<'a> {
    pub swash: FontRef<'a>,
    pub skrifa: skrifa::FontRef<'a>,
}

impl FaceData {
    /// Parse `data` at `index`, once per face.
    /// 在 `index` 处解析 `data`，每个字面只解析一次。
    pub fn parse(data: impl Into<FontBlob>, index: usize) -> Option<Self> {
        Self::try_new(data.into(), |bytes| {
            let swash = FontRef::from_index(bytes, index).ok_or(())?;
            let skrifa = skrifa::FontRef::from_index(bytes, index as u32).map_err(|_| ())?;
            Ok::<_, ()>(Faces { swash, skrifa })
        })
        .ok()
    }

    /// The swash view; cheap, because nothing is re-parsed.
    /// swash 视图；开销很小，因为不会重新解析。
    pub fn font(&self) -> FontRef<'_> {
        self.borrow_dependent().swash
    }

    /// The skrifa view, for outlines and metrics.
    /// 供轮廓与度量使用的 skrifa 视图。
    pub fn outline_font(&self) -> &skrifa::FontRef<'_> {
        &self.borrow_dependent().skrifa
    }

    /// The bytes the fonts borrow from.
    /// 字体所借用的字节。
    pub fn bytes(&self) -> &FontBlob {
        self.borrow_owner()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn one_face_keeps_one_font_key_so_the_plan_cache_holds() {
        // swash keys its plan caches on the `FontRef` key, minted per parse: a second parse
        // misses them all and rebuilds the plan, which made shaping ~100x slower.
        // swash 的计划缓存以每次解析铸出的 `FontRef` key 为键：重新解析会全部落空并重建计划，
        // 这正是整形慢两个数量级的原因。
        let Some(data) = crate::tests_support::sans_face() else {
            return;
        };
        let face = FaceData::parse(data, 0).expect("a system face parses");
        assert_eq!(
            face.font().key.value(),
            face.font().key.value(),
            "every call must hand swash the same key"
        );
        assert_eq!(face.font().data.as_ptr(), face.bytes().as_ptr());
    }
}
