//! Text shaping: turns a run of text into positioned glyphs.
//! 文本整形：把一段文本变成带位置的字形。


use swash::shape::{Direction as SwashDirection, ShapeContext};
use swash::text::Script as SwashScript;

use ui_text::{Features, Script, SubpixelBin, Variations};

/// One positioned glyph produced by shaping.
/// 整形产出的一个带位置字形。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct ShapedGlyph {
    pub glyph_id: u16,
    /// Horizontal offset from the pen, in pixels (combining marks, mkmk).
    /// 相对笔位的水平偏移，像素单位（组合标记、mkmk）。
    pub x: f32,
    /// Vertical offset from the baseline, in pixels, positive down.
    /// 相对基线的垂直偏移，像素单位，向下为正。
    pub y: f32,
    /// Advance in pixels, after kerning and ligatures.
    /// 像素单位的前进宽度，已含 kerning 与连字。
    pub advance: f32,
    /// Byte offset of the cluster this glyph belongs to.
    /// 该字形所属字簇的字节偏移。
    pub cluster: u32,
}

/// A shaped run: glyphs plus the total advance.
/// 已整形的文本段：字形与总前进宽度。
#[derive(Clone, Debug, Default, PartialEq)]
pub struct ShapedRun {
    pub glyphs: Vec<ShapedGlyph>,
    pub width: f32,
}

impl ShapedRun {
    pub fn is_empty(&self) -> bool {
        self.glyphs.is_empty()
    }
}

/// One directional run, in visual order, with glyphs in visual order.
/// 一个方向性文本段，位于视觉顺序，字形亦为视觉序。
#[derive(Clone, Debug, PartialEq)]
pub struct VisualRun {
    /// Byte range in the original text.
    /// 原文本中的字节区间。
    pub range: std::ops::Range<usize>,
    /// Whether this run reads right to left.
    /// 该段是否从右到左阅读。
    pub is_rtl: bool,
    pub run: ShapedRun,
}

impl VisualRun {
    pub fn is_rtl(&self) -> bool {
        self.is_rtl
    }

    pub fn width(&self) -> f32 {
        self.run.width
    }
}

/// A glyph placed at a quantized origin, ready to blit.
/// 已量化落位、可直接贴图的一个字形。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct PlacedGlyph {
    pub glyph_id: u16,
    /// Integer horizontal origin, in **device** pixels.
    /// 整数水平原点，**设备**像素。
    pub origin_x: i32,
    /// Integer baseline for this glyph, in device pixels, including the glyph's
    /// own vertical offset (combining marks sit above the baseline).
    /// 该字形的整数基线，设备像素，已含字形自身的垂直偏移（组合标记在基线上方）。
    pub baseline_y: i32,
    /// Which subpixel variant to fetch from the atlas.
    /// 从图集取哪个亚像素变体。
    pub bin: SubpixelBin,
}

/// Place a shaped run at `pen_x` / `baseline_y`, quantizing to whole pixels.
/// 把整形结果放在 `pen_x` / `baseline_y`，并量化到整像素。
///
/// Horizontal positions keep a quarter-pixel phase so a run does not jitter when an
/// earlier character changes width; vertical stays integral, matching egui and GPUI.
/// 水平位置保留 1/4 像素相位，使前面字符变宽时文本不抖动；垂直保持整数，与 egui、GPUI 一致。
pub fn place_run(
    run: &ShapedRun,
    pen_x: f32,
    baseline_y: f32,
    use_subpixel: bool,
) -> Vec<PlacedGlyph> {
    place_run_scaled(run, pen_x, baseline_y, use_subpixel, 1.0)
}

/// Place a run for a device scale of `scale` device pixels per logical point.
/// 按 `scale`（每逻辑点对应的设备像素数）放置一段文本。
///
/// Quantization happens in *device* space: at a fractional scale the same logical
/// origin maps to a different fractional device position, so quantizing in logical
/// space would leave up to one device pixel of jitter.
/// 量化发生在**设备**空间：分数缩放下同一逻辑原点对应不同的设备小数位，
/// 若在逻辑空间量化，会残留最多一个设备像素的抖动。
pub fn place_run_scaled(
    run: &ShapedRun,
    pen_x: f32,
    baseline_y: f32,
    use_subpixel: bool,
    scale: f32,
) -> Vec<PlacedGlyph> {
    let scale = if scale.is_finite() && scale > 0.0 {
        scale
    } else {
        1.0
    };
    let mut pen = pen_x;
    let mut out = Vec::with_capacity(run.glyphs.len());
    for glyph in &run.glyphs {
        let x = (pen + glyph.x) * scale;
        let (device_x, bin) = if use_subpixel {
            SubpixelBin::split(x)
        } else {
            (x.round() as i32, SubpixelBin::Zero)
        };
        let origin_x = device_x;
        out.push(PlacedGlyph {
            glyph_id: glyph.glyph_id,
            origin_x,
            baseline_y: ((baseline_y - glyph.y) * scale).round() as i32,
            bin,
        });
        pen += glyph.advance;
    }
    out
}

fn to_swash_script(script: Script) -> SwashScript {
    match &script.0 {
        b"Latn" => SwashScript::Latin,
        b"Hani" => SwashScript::Han,
        b"Arab" => SwashScript::Arabic,
        b"Hebr" => SwashScript::Hebrew,
        b"Cyrl" => SwashScript::Cyrillic,
        b"Grek" => SwashScript::Greek,
        b"Hira" => SwashScript::Hiragana,
        b"Hang" => SwashScript::Hangul,
        b"Thai" => SwashScript::Thai,
        b"Deva" => SwashScript::Devanagari,
        _ => SwashScript::Latin,
    }
}

/// A shaper for one face. `ShapeContext` is reusable; a `Shaper` is not.
/// 单个字面的整形器。`ShapeContext` 可复用；`Shaper` 不可。
pub struct Shaper {
    context: ShapeContext,
    font: crate::face::FaceData,
    /// Variable-font weight instance; `None` for a static face.
    /// 可变字体的字重实例；静态字面为 `None`。
    weight: Option<f32>,
    /// Axes beyond weight this instance sits at.
    /// 该实例字重之外所处的轴位置。
    axes: Variations,
}

impl Shaper {
    pub fn new(data: impl Into<ui_text::FontBlob>, font_index: usize) -> Option<Self> {
        Self::new_with_weight(data, font_index, None)
    }

    /// A shaper for a variable-font instance at `weight`.
    /// 针对 `weight` 处可变字体实例的整形器。
    pub fn new_with_weight(data: impl Into<ui_text::FontBlob>, font_index: usize, weight: Option<f32>) -> Option<Self> {
        Self::new_with_axes(data, font_index, weight, Variations::NONE)
    }

    /// A shaper for a variable-font instance at `weight` and the extra `axes`.
    /// 针对 `weight` 与额外 `axes` 处可变字体实例的整形器。
    pub fn new_with_axes(
        data: impl Into<ui_text::FontBlob>,
        font_index: usize,
        weight: Option<f32>,
        axes: Variations,
    ) -> Option<Self> {
        // Fail early if the bytes are not a font, and keep the parse for every later call.
        // 若字节不是字体则尽早失败，并把这次解析留给之后的每次调用。
        let font = crate::face::FaceData::parse(data, font_index)?;
        Some(Self {
            context: ShapeContext::new(),
            font,
            weight,
            axes,
        })
    }

    /// Shape `text` at `size`, with kerning and ligatures applied.
    /// 在 `size` 字号下整形 `text`，应用 kerning 与连字。
    pub fn shape(&mut self, text: &str, size: f32, script: Script) -> ShapedRun {
        self.shape_directed(text, size, script, ui_text::Direction::LeftToRight, Features::NONE)
    }

    /// Shape `text` with an explicit direction and feature switches.
    /// 用显式方向与特性开关整形 `text`。
    ///
    /// Direction selects contextual forms; it does **not** reorder glyphs, so an RTL
    /// run still comes back in logical order and must be reversed by the caller.
    /// 方向决定上下文形态，**不**重排字形；RTL 段仍以逻辑序返回，需调用方反转。
    pub fn shape_directed(
        &mut self,
        text: &str,
        size: f32,
        script: Script,
        direction: ui_text::Direction,
        features: Features,
    ) -> ShapedRun {
        // A shaper consumes itself when run, so build a fresh one per call.
        // shaper 运行时消耗自身，所以每次调用新建一个。
        let mut builder = self.context.builder(self.font.font());
        // The axis must be set before shaping, or advances come from the default instance.
        // 轴必须在整形前设定，否则前进宽度来自默认实例。
        let mut settings: Vec<(swash::Tag, f32)> = Vec::with_capacity(4);
        if let Some(w) = self.weight {
            settings.push((swash::tag_from_bytes(b"wght"), w));
        }
        for (tag, value) in [
            (b"opsz", self.axes.optical_size),
            (b"FILL", self.axes.fill),
            (b"GRAD", self.axes.grade),
        ] {
            if let Some(value) = value {
                settings.push((swash::tag_from_bytes(tag), value));
            }
        }
        if !settings.is_empty() {
            builder = builder.variations(settings);
        }
        let switches: Vec<(swash::Tag, u16)> = features
            .iter()
            .map(|(tag, value)| (swash::tag_from_bytes(&tag), value.min(u16::MAX as u32) as u16))
            .collect();
        if !switches.is_empty() {
            builder = builder.features(switches);
        }
        let mut shaper = builder
            .script(to_swash_script(script))
            .size(size)
            .direction(match direction {
                ui_text::Direction::LeftToRight => SwashDirection::LeftToRight,
                ui_text::Direction::RightToLeft => SwashDirection::RightToLeft,
            })
            .build();
        shaper.add_str(text);

        let mut glyphs = Vec::new();
        shaper.shape_with(|cluster| {
            let start = cluster.source.start;
            for glyph in cluster.glyphs {
                glyphs.push(ShapedGlyph {
                    glyph_id: glyph.id,
                    x: glyph.x,
                    y: glyph.y,
                    advance: glyph.advance,
                    cluster: start,
                });
            }
        });
        let width = glyphs.iter().map(|g| g.advance).sum();
        ShapedRun { glyphs, width }
    }

    /// Shape a whole paragraph: itemize by direction, shape each run, reorder.
    /// 整形整个段落：按方向分段、逐段整形、再重排。
    ///
    /// Returns runs in **visual** order, each with its glyphs already in visual order,
    /// so a caller can lay them out left to right with a single pen.
    /// 返回**视觉**顺序的段，每段字形也已按视觉序排列，调用方只需一个笔位从左到右排。
    /// Shape one logical run, applying RTL reversal and UAX#9 L4 bracketing.
    /// 整形单个逻辑段，并做 RTL 反转与 UAX#9 L4 括号镜像。
    ///
    /// `TextPass` needs this per face: it picks a covering face per run, so it cannot
    /// use `shape_bidi`, which assumes one face for the whole string.
    /// `TextPass` 需要按字面调用：它按段选择覆盖字面，因此不能用
    /// `shape_bidi`——后者假定整串只有一个字面。
    pub fn shape_run(
        &mut self,
        whole: &str,
        range: std::ops::Range<usize>,
        size: f32,
        script: Script,
        direction: ui_text::Direction,
        features: Features,
    ) -> ShapedRun {
        let slice = whole.get(range.clone()).unwrap_or("");
        let mut run = self.shape_directed(slice, size, script, direction, features);
        // swash returns logical order even for RTL, so flip here.
        // swash 即使 RTL 也返回逻辑序，因此在此反转。
        if direction.is_rtl() {
            run.glyphs.reverse();
            self.mirror_brackets(&mut run, whole, range.start);
        }
        run
    }

    pub fn shape_bidi(
        &mut self,
        text: &str,
        size: f32,
        base: Option<ui_text::Direction>,
    ) -> Vec<VisualRun> {
        let logical = ui_text::itemize(text, base);
        if logical.is_empty() {
            return Vec::new();
        }

        let mut shaped: Vec<VisualRun> = logical
            .iter()
            .map(|run| {
                let slice = text.get(run.range.clone()).unwrap_or("");
                let direction = run.direction();
                let shaped_run = self.shape_run(
                    text,
                    run.range.clone(),
                    size,
                    Script::dominant(slice),
                    direction,
                    Features::NONE,
                );
                VisualRun {
                    range: run.range.clone(),
                    is_rtl: direction.is_rtl(),
                    run: shaped_run,
                }
            })
            .collect();

        let order = ui_text::visual_order(&logical);
        let mut reordered = Vec::with_capacity(order.len());
        for index in order {
            if let Some(run) = shaped.get(index) {
                reordered.push(run.clone());
            }
        }
        shaped
            .clear();
        reordered
    }

    /// Glyph id for a character through the font's cmap.
    /// 通过字体 cmap 取字符的字形 id。
    pub fn glyph_id(&self, c: char) -> Option<u16> {
        let gid = self.font.font().charmap().map(c);
        if gid == 0 {
            None
        } else {
            Some(gid)
        }
    }

    /// Apply UAX#9 rule L4: swap brackets for their mirror image.
    /// 应用 UAX#9 L4：把括号换成镜像字形。
    ///
    /// `unicode-bidi` hands this rule to the engine; without it an RTL run shows
    /// `)text(` instead of `(text)`.
    /// `unicode-bidi` 把这条规则交给引擎；不做的话 RTL 段会显示成 `)文本(`。
    fn mirror_brackets(&self, run: &mut ShapedRun, text: &str, start: usize) {
        for glyph in &mut run.glyphs {
            let offset = start + glyph.cluster as usize;
            let Some(ch) = text.get(offset..).and_then(|s| s.chars().next()) else {
                continue;
            };
            let Some(mirrored) = unicode_bidi_mirroring::get_mirrored(ch) else {
                continue;
            };
            if let Some(gid) = self.glyph_id(mirrored) {
                glyph.glyph_id = gid;
            }
        }
    }

    /// Advance for a single glyph id, without shaping context.
    /// 单个字形 id 的前进宽度，无整形上下文。
    pub fn glyph_advance(&self, glyph_id: u16, size: f32) -> f32 {
        let font = self.font.font();
        let metrics = font.metrics(&[]);
        let upem = metrics.units_per_em.max(1) as f32;
        let advance = font.glyph_metrics(&[]).advance_width(glyph_id);
        advance / upem * size
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// A font that actually covers Arabic, for bidi tests.
    /// 真正覆盖阿拉伯文的字体，供 bidi 测试使用。
    fn arabic_font() -> Option<ui_text::FontBlob> {
        crate::tests_support::rtl_face()
    }

    fn system_font() -> Option<ui_text::FontBlob> {
        crate::tests_support::sans_face()
    }

    #[test]
    fn shaping_produces_one_glyph_per_visible_char_for_latin() {
        let Some(data) = system_font() else { return };
        let mut s = Shaper::new(data, 0).expect("font");
        let run = s.shape("Hello", 32.0, Script::LATIN);
        assert!(!run.is_empty());
        // "Hello" has no ligature candidates here, so 5 glyphs.
        // "Hello" 无连字候选，应为 5 个字形。
        assert_eq!(run.glyphs.len(), 5, "got {:?}", run.glyphs);
        assert!(run.width > 0.0);
    }

    #[test]
    fn kerning_makes_av_narrower_than_the_sum_of_advances() {
        let Some(data) = system_font() else { return };
        let mut s = Shaper::new(data, 0).expect("font");
        let run = s.shape("AV", 32.0, Script::LATIN);
        assert_eq!(run.glyphs.len(), 2);
        let unkerned = s.glyph_advance(run.glyphs[0].glyph_id, 32.0)
            + s.glyph_advance(run.glyphs[1].glyph_id, 32.0);
        assert!(
            run.width < unkerned,
            "kerning must shrink AV: shaped {} vs unkerned {}",
            run.width,
            unkerned
        );
    }

    #[test]
    fn cjk_text_shapes_to_the_cjk_glyph_count() {
        let Some(data) = system_font() else { return };
        let mut s = Shaper::new(data, 0).expect("font");
        let text = "中文字体";
        let run = s.shape(text, 32.0, Script::HAN);
        assert_eq!(run.glyphs.len(), text.chars().count());
        assert!(run.width > 0.0);
    }

    #[test]
    fn width_scales_linearly_with_font_size() {
        let Some(data) = system_font() else { return };
        let mut s = Shaper::new(data, 0).expect("font");
        let small = s.shape("Measure me", 16.0, Script::LATIN).width;
        let large = s.shape("Measure me", 32.0, Script::LATIN).width;
        assert!(
            (large / small - 2.0).abs() < 0.05,
            "doubling size must double width: {small} -> {large}"
        );
    }

    #[test]
    fn place_run_keeps_subpixel_phases_on_x_only() {
        let Some(data) = system_font() else { return };
        let mut s = Shaper::new(data, 0).expect("font");
        let run = s.shape("mmmm", 16.0, Script::LATIN);
        let placed = place_run(&run, 10.3, 20.7, true);
        assert_eq!(placed.len(), run.glyphs.len());
        // Vertical is always integral.
        // 垂直恒为整数。
        assert!(placed.iter().all(|p| p.baseline_y == 21));
        // At least one glyph must carry a non-zero phase for a fractional origin.
        // 分数原点下至少有一个字形带非零相位。
        assert!(
            placed.iter().any(|p| p.bin != SubpixelBin::Zero),
            "fractional pen must produce a phase"
        );
    }

    #[test]
    fn place_run_without_subpixel_snaps_every_glyph_to_whole_pixels() {
        let Some(data) = system_font() else { return };
        let mut s = Shaper::new(data, 0).expect("font");
        let run = s.shape("mmmm", 16.0, Script::LATIN);
        let placed = place_run(&run, 10.3, 20.0, false);
        assert!(placed.iter().all(|p| p.bin == SubpixelBin::Zero));
    }

    #[test]
    fn place_run_advances_by_the_shaped_width() {
        let Some(data) = system_font() else { return };
        let mut s = Shaper::new(data, 0).expect("font");
        let run = s.shape("abc", 16.0, Script::LATIN);
        let placed = place_run(&run, 0.0, 0.0, false);
        let last = placed.last().expect("glyphs");
        assert!(
            (last.origin_x as f32) < run.width + 1.0,
            "last glyph must start before the run ends"
        );
    }

    #[test]
    fn scaled_placement_lands_on_whole_device_pixels() {
        let Some(data) = system_font() else { return };
        let mut s = Shaper::new(data, 0).expect("font");
        let run = s.shape("mmmmmm", 13.0, Script::LATIN);
        // A fractional scale is where logical-space quantization would leak error.
        // 分数缩放下，逻辑空间量化才会泄漏误差。
        for scale in [1.0f32, 1.25, 1.5, 1.6, 2.0] {
            for placed in place_run_scaled(&run, 18.3, 40.7, true, scale) {
                // Reconstructing the device origin the renderer would use must be exact.
                // 重建渲染器会用的设备原点必须精确。
                let logical = placed.origin_x as f32 / scale;
                let device_again = logical * scale;
                assert!(
                    (device_again - placed.origin_x as f32).abs() < 0.01,
                    "scale {scale}: device origin {} round-trips to {device_again}",
                    placed.origin_x
                );
            }
        }
    }

    #[test]
    fn scaled_placement_keeps_quarter_pixel_phases() {
        let Some(data) = system_font() else { return };
        let mut s = Shaper::new(data, 0).expect("font");
        let run = s.shape("the quick brown", 13.0, Script::LATIN);
        let mut counts = [0u32; 4];
        for placed in place_run_scaled(&run, 18.0, 40.0, true, 1.6) {
            counts[placed.bin.index() as usize] += 1;
        }
        assert!(
            counts.iter().filter(|c| **c > 0).count() >= 3,
            "fractional scale must still spread across phases, got {counts:?}"
        );
    }

    #[test]
    fn bidi_latin_text_stays_one_ltr_run() {
        let Some(data) = system_font() else { return };
        let mut s = Shaper::new(data, 0).expect("font");
        let runs = s.shape_bidi("hello world", 16.0, None);
        assert_eq!(runs.len(), 1);
        assert!(!runs[0].is_rtl());
        assert_eq!(runs[0].range, 0..11);
    }

    #[test]
    fn bidi_rtl_run_has_its_glyphs_reversed() {
        let Some(data) = arabic_font() else { return };
        let mut s = Shaper::new(data, 0).expect("font");
        let text = "مرحبا";
        let runs = s.shape_bidi(text, 32.0, None);
        assert_eq!(runs.len(), 1);
        assert!(runs[0].is_rtl(), "Arabic must be an RTL run");

        // In visual order the first glyph must come from the last logical cluster.
        // 视觉序下第一个字形必须来自最后一个逻辑字簇。
        let glyphs = &runs[0].run.glyphs;
        assert!(glyphs.len() >= 2);
        let first = glyphs.first().expect("glyph").cluster;
        let last = glyphs.last().expect("glyph").cluster;
        assert!(
            first > last,
            "RTL glyphs must be reversed: first cluster {first} should exceed last {last}"
        );
    }

    #[test]
    fn bidi_mixed_text_yields_several_runs_covering_the_text() {
        let Some(data) = arabic_font() else { return };
        let mut s = Shaper::new(data, 0).expect("font");
        let text = "abc مرحبا xyz";
        let runs = s.shape_bidi(text, 16.0, None);
        assert!(runs.len() >= 3, "expected at least 3 runs, got {}", runs.len());
        assert!(runs.iter().any(|r| r.is_rtl()));
        assert!(runs.iter().any(|r| !r.is_rtl()));

        // Every byte of the text must belong to exactly one run.
        // 文本的每个字节必须恰好属于一个段。
        let mut covered = vec![false; text.len()];
        for run in &runs {
            for flag in &mut covered[run.range.clone()] {
                assert!(!*flag, "byte covered twice");
                *flag = true;
            }
        }
        assert!(covered.iter().all(|c| *c), "all bytes must be covered");
    }

    #[test]
    fn bidi_base_direction_changes_visual_run_order() {
        let Some(data) = arabic_font() else { return };
        let mut s = Shaper::new(data.clone(), 0).expect("font");
        let text = "abc مرحبا";
        let ltr = s.shape_bidi(text, 16.0, Some(ui_text::Direction::LeftToRight));
        let mut s2 = Shaper::new(data, 0).expect("font");
        let rtl = s2.shape_bidi(text, 16.0, Some(ui_text::Direction::RightToLeft));
        let ltr_ranges: Vec<_> = ltr.iter().map(|r| r.range.clone()).collect();
        let rtl_ranges: Vec<_> = rtl.iter().map(|r| r.range.clone()).collect();
        assert_ne!(
            ltr_ranges, rtl_ranges,
            "base direction must reorder runs: {ltr_ranges:?} vs {rtl_ranges:?}"
        );
    }

    #[test]
    fn bidi_total_width_is_the_sum_of_visual_runs() {
        let Some(data) = arabic_font() else { return };
        let mut s = Shaper::new(data, 0).expect("font");
        let runs = s.shape_bidi("abc مرحبا xyz", 16.0, None);
        let total: f32 = runs.iter().map(|r| r.run.width).sum();
        assert!(total > 0.0);
        for run in &runs {
            assert!(run.run.width > 0.0, "every run contributes width");
        }
    }

    #[test]
    fn bidi_rtl_brackets_are_mirrored() {
        let Some(data) = arabic_font() else { return };
        let mut s = Shaper::new(data.clone(), 0).expect("font");
        let open = s.glyph_id('(').expect("( in font");
        let close = s.glyph_id(')').expect(") in font");
        assert_ne!(open, close, "the font must have distinct bracket glyphs");

        // UAX#9 L4: in an RTL run the opening bracket must be drawn leftmost.
        // UAX#9 L4：RTL 段中左括号必须画在最左。
        let runs = s.shape_bidi("(مرحبا)", 32.0, None);
        assert_eq!(runs.len(), 1);
        let glyphs = &runs[0].run.glyphs;
        assert_eq!(
            glyphs.first().map(|g| g.glyph_id),
            Some(open),
            "leftmost glyph must be the opening bracket"
        );
        assert_eq!(
            glyphs.last().map(|g| g.glyph_id),
            Some(close),
            "rightmost glyph must be the closing bracket"
        );
    }

    #[test]
    fn bidi_ltr_brackets_are_left_alone() {
        let Some(data) = arabic_font() else { return };
        let mut s = Shaper::new(data.clone(), 0).expect("font");
        let open = s.glyph_id('(').expect("(");
        let close = s.glyph_id(')').expect(")");
        let runs = s.shape_bidi("(abc)", 32.0, Some(ui_text::Direction::LeftToRight));
        let glyphs = &runs[0].run.glyphs;
        assert_eq!(glyphs.first().map(|g| g.glyph_id), Some(open));
        assert_eq!(glyphs.last().map(|g| g.glyph_id), Some(close));
    }

    #[test]
    fn bidi_empty_text_yields_no_runs() {
        let Some(data) = system_font() else { return };
        let mut s = Shaper::new(data, 0).expect("font");
        assert!(s.shape_bidi("", 16.0, None).is_empty());
    }

    #[test]
    fn empty_text_shapes_to_nothing() {
        let Some(data) = system_font() else { return };
        let mut s = Shaper::new(data, 0).expect("font");
        let run = s.shape("", 16.0, Script::LATIN);
        assert!(run.is_empty());
        assert_eq!(run.width, 0.0);
    }
}
