//! Glyph rasterization and a packed atlas.
//! 字形光栅化与紧凑图集。

use std::collections::HashMap;

use skrifa::instance::{LocationRef, Size};
use skrifa::outline::{DrawSettings, OutlinePen};
use skrifa::raw::TableProvider;
use skrifa::{FontRef, MetadataProvider};

use ui_core::draw::GlyphKind;
use ui_text::{FaceId, Variations};

/// A rasterized glyph: coverage bytes plus placement relative to the pen origin.
/// 已光栅化的字形：覆盖率字节，以及相对笔原点的放置。
#[derive(Clone, Debug)]
pub struct GlyphBitmap {
    pub width: u32,
    pub height: u32,
    /// Left edge relative to the pen origin, in pixels.
    /// 相对笔原点的左边界，单位像素。
    pub left: i32,
    /// Top edge relative to the baseline, in pixels (positive is up).
    /// 相对基线的上边界，单位像素（向上为正）。
    pub top: i32,
    /// One byte of coverage per pixel, row-major, `width * height` long.
    /// 每像素一字节覆盖率，行优先，长度 `width * height`。
    pub coverage: Vec<u8>,
}

impl GlyphBitmap {
    pub fn is_empty(&self) -> bool {
        self.width == 0 || self.height == 0
    }
}

/// A rasterized colour glyph: premultiplied RGBA plus placement relative to the pen.
/// 已光栅化的颜色字形：预乘 RGBA，以及相对笔原点的放置。
#[derive(Clone, Debug)]
pub struct ColorBitmap {
    pub width: u32,
    pub height: u32,
    /// Left edge relative to the pen origin, in pixels.
    /// 相对笔原点的左边界，单位像素。
    pub left: i32,
    /// Top edge relative to the baseline, in pixels (positive is up).
    /// 相对基线的上边界，单位像素（向上为正）。
    pub top: i32,
    /// Four bytes of premultiplied RGBA per pixel, row-major.
    /// 每像素四字节预乘 RGBA，行优先。
    pub rgba: Vec<u8>,
}

/// Metrics read from the font's own tables, not guessed.
/// 从字体自身的表读出的度量，不是猜的。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct RealMetrics {
    pub units_per_em: f32,
    pub ascent: f32,
    pub descent: f32,
    pub line_gap: f32,
}

impl Default for RealMetrics {
    /// Metrics of a typical sans-serif, used when no font is loaded.
    /// 典型无衬线字体的度量，无字体时使用。
    fn default() -> Self {
        Self {
            units_per_em: 1000.0,
            ascent: 0.8,
            descent: -0.2,
            line_gap: 0.0,
        }
    }
}

/// Parsed font plus a glyph outline collector.
/// 已解析的字体，以及一个轮廓收集器。
pub struct ParsedFace {
    /// Parsed once: a collection packs several faces into one blob, so the index matters
    /// and re-parsing per glyph would drop every swash scale-cache entry.
    /// 只解析一次：集合字体把多个字面打进同一个 blob，下标因此有意义；
    /// 每字形重新解析会让 swash 的缩放缓存全部落空。
    font: crate::face::FaceData,
    /// Weight instance for a variable font; `None` for a static face.
    /// 可变字体的字重实例；静态字面为 `None`。
    weight: Option<f32>,
    /// Axes beyond weight this instance sits at.
    /// 该实例字重之外所处的轴位置。
    axes: Variations,
    metrics: RealMetrics,
    /// Kept for the colour path: its plan cache is keyed by the font and the context.
    /// 供颜色路径保留：其计划缓存以字体与上下文为键。
    scale: swash::scale::ScaleContext,
}

impl ParsedFace {
    /// Parse `data`, reading `head`/`hhea` for real metrics.
    /// 解析 `data`，从 `head`/`hhea` 读出真实度量。
    pub fn new(data: impl Into<ui_text::FontBlob>) -> Option<Self> {
        Self::new_at(data, 0)
    }

    /// Parse `data` at a specific face index inside the file.
    /// 在文件内指定字面下标处解析 `data`。
    pub fn new_at(data: impl Into<ui_text::FontBlob>, font_index: u32) -> Option<Self> {
        Self::new_instance(data, font_index, None)
    }

    /// Parse a variable-font instance at `weight`.
    /// 解析 `weight` 处的可变字体实例。
    pub fn new_instance(
        data: impl Into<ui_text::FontBlob>,
        font_index: u32,
        weight: Option<f32>,
    ) -> Option<Self> {
        Self::new_axes(data, font_index, weight, Variations::NONE)
    }

    /// Parse a variable-font instance at `weight` and the extra `axes`.
    /// 解析 `weight` 与额外 `axes` 处的可变字体实例。
    pub fn new_axes(
        data: impl Into<ui_text::FontBlob>,
        font_index: u32,
        weight: Option<f32>,
        axes: Variations,
    ) -> Option<Self> {
        let font = crate::face::FaceData::parse(data, font_index as usize)?;
        let view = font.outline_font();
        let upem = view.head().map(|h| h.units_per_em()).unwrap_or(1000) as f32;
        let hhea = view.hhea().ok()?;
        let metrics = RealMetrics {
            units_per_em: upem,
            ascent: hhea.ascender().to_i16() as f32 / upem,
            descent: hhea.descender().to_i16() as f32 / upem,
            line_gap: hhea.line_gap().to_i16() as f32 / upem,
        };
        Some(Self {
            font,
            weight,
            axes,
            metrics,
            scale: swash::scale::ScaleContext::new(),
        })
    }

    /// Metrics normalised so the em maps to 1.0.
    /// 归一化后的度量，使一个 em 对应 1.0。
    pub fn metrics(&self) -> RealMetrics {
        self.metrics
    }

    /// Advance width of `gid` in em units, from `hmtx`.
    /// 从 `hmtx` 取 `gid` 的前进宽度，单位为 em。
    pub fn advance_em(&self, gid: u32) -> f32 {
        let font = self.font.outline_font();
        match font.hmtx() {
            Ok(hmtx) => {
                let upem = self.metrics.units_per_em;
                hmtx.advance(skrifa::GlyphId::new(gid))
                    .map(|a| a as f32 / upem)
                    .unwrap_or(0.6)
            }
            Err(_) => 0.6,
        }
    }

    /// Map a character to a glyph id through `cmap`.
    /// 通过 `cmap` 把字符映射到字形 id。
    pub fn glyph_id(&self, c: char) -> Option<u32> {
        let gid = self.font.outline_font().charmap().map(c)?;
        if gid.to_u32() == 0 {
            None
        } else {
            Some(gid.to_u32())
        }
    }

    /// Normalized coordinates for this instance, empty for a static face.
    /// 该实例的归一化坐标；静态字面为空。
    fn instance_coords(&self, font: &FontRef<'_>) -> Vec<skrifa::instance::NormalizedCoord> {
        use skrifa::MetadataProvider as _;
        let axes = font.axes();
        if axes.is_empty() {
            return Vec::new();
        }
        let mut settings: Vec<(skrifa::Tag, f32)> = Vec::with_capacity(4);
        if let Some(weight) = self.weight {
            settings.push((skrifa::Tag::new(b"wght"), weight));
        }
        for (tag, value) in [
            (b"opsz", self.axes.optical_size),
            (b"FILL", self.axes.fill),
            (b"GRAD", self.axes.grade),
        ] {
            if let Some(value) = value {
                settings.push((skrifa::Tag::new(tag), value));
            }
        }
        if settings.is_empty() {
            return Vec::new();
        }
        let location = axes.location(settings);
        location.coords().to_vec()
    }

    /// Rasterize `gid` at `px` size into a coverage bitmap.
    /// 把 `gid` 在 `px` 字号下光栅成覆盖率位图。
    pub fn rasterize(&self, gid: u32, px: f32) -> Option<GlyphBitmap> {
        self.rasterize_subpixel(gid, px, 0.0)
    }

    /// Rasterize `gid` shifted right by `dx` pixels, `dx` in `[0, 1)`.
    /// 把 `gid` 右移 `dx` 像素后光栅，`dx` 取值 `[0, 1)`。
    ///
    /// Four phases per glyph is what makes text stop jittering when an earlier
    /// character changes width; see docs/font-stack.md.
    /// 每个字形四个相位，这是前面的字符变宽时文本不再抖动的原因。
    pub fn rasterize_subpixel(&self, gid: u32, px: f32, dx: f32) -> Option<GlyphBitmap> {
        let font = self.font.outline_font();
        let outlines = font.outline_glyphs();
        let glyph = outlines.get(skrifa::GlyphId::new(gid))?;

        let mut pen = ContourPen::new(self.metrics.units_per_em, px);
        pen.dx = dx;
        // The instance's coordinates, not the default one: a variable font's Bold
        // outlines only exist at `wght=700`, so `LocationRef::default()` draws Regular.
        // 用实例的坐标而不是默认坐标：可变字体的粗体轮廓只存在于 `wght=700` 处，
        // 因此 `LocationRef::default()` 画出来的是 Regular。
        let coords = self.instance_coords(font);
        glyph
            .draw(
                DrawSettings::unhinted(Size::new(px), LocationRef::new(&coords)),
                &mut pen,
            )
            .ok()?;

        pen.finish()
    }

    /// Rasterize `gid` through the font's colour layers as premultiplied RGBA.
    /// 通过字体的颜色层把 `gid` 光栅成预乘 RGBA。
    ///
    /// `None` for monochrome glyphs, so they keep the coverage path even inside a
    /// colour font. Colour sources are COLR v0 outlines and CBDT/sbix bitmaps.
    /// 单色字形返回 `None`，因此即使在颜色字体里也走覆盖率路径。
    /// 颜色来源是 COLR v0 轮廓与 CBDT/sbix 位图。
    pub fn rasterize_color(&mut self, gid: u32, px: f32) -> Option<ColorBitmap> {
        let settings = self.swash_settings();
        let mut builder = self.scale.builder(self.font.font()).size(px);
        if !settings.is_empty() {
            builder = builder.variations(settings);
        }
        let mut scaler = builder.build();
        let render = swash::scale::Render::new(&[
            swash::scale::Source::ColorOutline(0),
            swash::scale::Source::ColorBitmap(swash::scale::StrikeWith::BestFit),
        ]);
        let image = render.render(&mut scaler, gid as u16)?;
        if image.content != swash::scale::image::Content::Color {
            return None;
        }
        let width = image.placement.width;
        let height = image.placement.height;
        if width == 0 || height == 0 {
            return None;
        }
        let len = (width * height * 4) as usize;
        let mut rgba = image.data;
        if rgba.len() < len {
            return None;
        }
        rgba.truncate(len);
        // swash composites colour layers with straight alpha; the atlas stores premultiplied.
        // swash 用直通 alpha 合成颜色层；图集存的是预乘值。
        for pixel in rgba.as_chunks_mut::<4>().0 {
            let a = pixel[3] as u32;
            pixel[0] = (pixel[0] as u32 * a / 255) as u8;
            pixel[1] = (pixel[1] as u32 * a / 255) as u8;
            pixel[2] = (pixel[2] as u32 * a / 255) as u8;
        }
        Some(ColorBitmap {
            width,
            height,
            left: image.placement.left,
            top: image.placement.top,
            rgba,
        })
    }

    /// Variation settings in swash's form, mirroring `instance_coords`.
    /// swash 形式的变体设置，与 `instance_coords` 对应。
    fn swash_settings(&self) -> Vec<(swash::Tag, f32)> {
        let mut settings: Vec<(swash::Tag, f32)> = Vec::with_capacity(4);
        if let Some(weight) = self.weight {
            settings.push((swash::tag_from_bytes(b"wght"), weight));
        }
        for (tag, value) in [
            (b"opsz", self.axes.optical_size),
            (b"FILL", self.axes.fill),
            (b"GRAD", self.axes.grade),
        ] {
            if let Some(value) = value {
                settings.push((swash::tag_from_bytes(tag), value));
            }
        }
        settings
    }
}

/// Collects outline contours and rasterizes them with `zeno`.
/// 收集轮廓路径，并用 `zeno` 光栅化。
struct ContourPen {
    /// Scale from font units to pixels.
    /// 从字体单位到像素的缩放。
    scale: f32,
    /// Horizontal subpixel shift, in pixels.
    /// 水平亚像素偏移，像素单位。
    dx: f32,
    /// Display-scale (font units are y-up; screen is y-down).
    /// 显示比例（字体单位 y 向上；屏幕 y 向下）。
    path: String,
    bounds: Option<(f32, f32, f32, f32)>,
}

impl ContourPen {
    fn new(_units_per_em: f32, _px: f32) -> Self {
        // skrifa already applies `Size` when it hands coordinates to the pen, so no
        // extra scaling belongs here; the pen receives pixels.
        // skrifa 在把坐标交给 pen 前已应用 `Size`，所以这里不能再缩放；pen 收到的是像素。
        Self {
            scale: 1.0,
            dx: 0.0,
            path: String::new(),
            bounds: None,
        }
    }

    fn track(&mut self, x: f32, y: f32) {
        self.bounds = Some(match self.bounds {
            None => (x, y, x, y),
            Some((x0, y0, x1, y1)) => (x0.min(x), y0.min(y), x1.max(x), y1.max(y)),
        });
    }

    fn finish(self) -> Option<GlyphBitmap> {
        let (x0, y0, x1, y1) = self.bounds?;
        // `bounds` is in screen space (y grows down, baseline at y = 0), so the
        // glyph's top is the smallest y and its bottom the largest.
        // `bounds` 在屏幕空间（y 向下增长，基线在 y = 0），所以顶是最小的 y、底是最大的 y。
        let pad = 1.0;
        let left = (x0 - pad).floor();
        let right = (x1 + pad).ceil();
        // Distance from the baseline up to the bitmap's top edge; this is what a
        // renderer subtracts from the baseline to place the glyph.
        // 从基线到比特图顶边的距离；渲染器用它从基线减去来放置字形。
        let top = -((y0 - pad).floor());
        let bottom = (y1 + pad).ceil();
        let w = (right - left).max(0.0) as u32;
        let h = (bottom - (y0 - pad).floor()).max(0.0) as u32;
        if w == 0 || h == 0 {
            return None;
        }
        let mut coverage = vec![0u8; (w * h) as usize];

        // zeno renders in the path's own space; shift so the glyph fills the bitmap.
        // zeno 在路径自身空间渲染；平移使字形填满比特图。
        zeno::Mask::new(self.path.as_str())
            .offset(zeno::Vector::new(-left, -((y0 - pad).floor())))
            .size(w, h)
            .render_into(&mut coverage, None);

        Some(GlyphBitmap {
            width: w,
            height: h,
            left: left as i32,
            top: top as i32,
            coverage,
        })
    }
}

impl OutlinePen for ContourPen {
    fn move_to(&mut self, x: f32, y: f32) {
        let (px, py) = (x * self.scale + self.dx, -y * self.scale);
        self.track(px, py);
        self.path.push_str(&format!("M {px},{py} "));
    }

    fn line_to(&mut self, x: f32, y: f32) {
        let (px, py) = (x * self.scale + self.dx, -y * self.scale);
        self.track(px, py);
        self.path.push_str(&format!("L {px},{py} "));
    }

    fn quad_to(&mut self, cx: f32, cy: f32, x: f32, y: f32) {
        let (qx, qy) = (cx * self.scale, -cy * self.scale);
        let (px, py) = (x * self.scale + self.dx, -y * self.scale);
        self.track(qx, qy);
        self.track(px, py);
        self.path.push_str(&format!("Q {qx},{qy} {px},{py} "));
    }

    fn curve_to(&mut self, cx1: f32, cy1: f32, cx2: f32, cy2: f32, x: f32, y: f32) {
        let (a, b) = (cx1 * self.scale, -cy1 * self.scale);
        let (c, d) = (cx2 * self.scale, -cy2 * self.scale);
        let (px, py) = (x * self.scale + self.dx, -y * self.scale);
        self.track(a, b);
        self.track(c, d);
        self.track(px, py);
        self.path
            .push_str(&format!("C {a},{b} {c},{d} {px},{py} "));
    }

    fn close(&mut self) {
        self.path.push_str("Z ");
    }
}

/// One glyph ready to composite: atlas tile and destination, both in device pixels.
/// 可合成的单个字形：图集图块与目标矩形，均为设备像素。
#[derive(Clone, Copy, Debug, PartialEq)]
pub struct GlyphBlit {
    /// Tile in atlas texture coordinates, never scaled.
    /// 图集中的图块，图集纹理坐标，从不缩放。
    pub atlas: ui_core::geom::Rect,
    /// Destination in device pixels.
    /// 目标矩形，设备像素。
    pub dest: ui_core::geom::Rect,
    /// Which atlas `atlas` refers to.
    /// `atlas` 指向哪张图集。
    pub kind: GlyphKind,
}

impl GlyphBlit {
    /// Destination in logical units, for primitives authored in logical space.
    /// 逻辑单位的目标矩形，供按逻辑单位编写的图元使用。
    pub fn dest_logical(&self, scale: f32) -> ui_core::geom::Rect {
        let scale = if scale.is_finite() && scale > 0.0 {
            scale
        } else {
            1.0
        };
        if (scale - 1.0).abs() < f32::EPSILON {
            return self.dest;
        }
        ui_core::geom::Rect::new(
            self.dest.origin.x / scale,
            self.dest.origin.y / scale,
            self.dest.size.w / scale,
            self.dest.size.h / scale,
        )
    }
}

/// A glyph atlas slot.
/// 图集中的一个槽位。
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct Slot {
    pub x: u32,
    pub y: u32,
    pub width: u32,
    pub height: u32,
    pub left: i32,
    pub top: i32,
}

/// One atlas page grown by shelf packing, one or four bytes per pixel.
/// 单页图集，用货架算法增长，每像素一或四字节。
struct Shelf {
    width: u32,
    height: u32,
    bytes_per_pixel: u32,
    pixels: Vec<u8>,
    /// Current shelf cursor and row height.
    /// 当前货架游标与行高。
    cursor_x: u32,
    cursor_y: u32,
    row_height: u32,
}

impl Shelf {
    fn new(width: u32, height: u32, bytes_per_pixel: u32, eager: bool) -> Self {
        let pixels = if eager {
            vec![0u8; (width * height * bytes_per_pixel) as usize]
        } else {
            Vec::new()
        };
        Self {
            width,
            height,
            bytes_per_pixel,
            pixels,
            cursor_x: 0,
            cursor_y: 0,
            row_height: 0,
        }
    }

    /// Allocate the page on first use; the colour page stays absent until an emoji arrives.
    /// 首次使用时才分配页面；颜色页在有 emoji 之前不占内存。
    fn ensure(&mut self) {
        if self.pixels.is_empty() {
            self.pixels
                .resize((self.width * self.height * self.bytes_per_pixel) as usize, 0);
        }
    }

    /// Double the page height (and width once), preserving row contents.
    /// 把页面高度翻倍（宽度也翻一次），保留每行内容。
    ///
    /// Rows are left-aligned, so widening never moves existing slots; growing the
    /// height adds blank rows underneath.
    /// 每行左对齐，所以加宽不会移动已有槽位；加高只是在下方补空白行。
    fn grow(&mut self) -> bool {
        const MAX_SIDE: u32 = 4096;
        let new_height = (self.height * 2).min(MAX_SIDE);
        if new_height == self.height && self.width >= MAX_SIDE {
            return false;
        }
        let new_width = (self.width * 2).min(MAX_SIDE);
        if !self.pixels.is_empty() {
            let bpp = self.bytes_per_pixel as usize;
            let mut grown = vec![0u8; (new_width * new_height) as usize * bpp];
            let row_bytes = self.width as usize * bpp;
            for row in 0..self.height as usize {
                let src = row * row_bytes;
                let dst = row * new_width as usize * bpp;
                grown[dst..dst + row_bytes].copy_from_slice(&self.pixels[src..src + row_bytes]);
            }
            self.pixels = grown;
        }
        self.width = new_width;
        self.height = new_height;
        true
    }

    /// Shelf allocator: fill a row, then start a new one. The flag says the page
    /// was cleared, so the caller must drop the matching index.
    /// 货架分配：填满一行再开新行。布尔值表示页面被清空，调用方必须丢弃对应索引。
    fn alloc(&mut self, w: u32, h: u32) -> Option<(Slot, bool)> {
        self.ensure();
        let mut cleared = false;
        loop {
            if w > self.width || h > self.height {
                return None;
            }
            if self.cursor_x + w > self.width {
                self.cursor_x = 0;
                self.cursor_y += self.row_height;
                self.row_height = 0;
            }
            if self.cursor_y + h <= self.height {
                break;
            }
            // Grow once before ever evicting; only a second overflow drops the page.
            // 先扩容再考虑淘汰；只有第二次溢出才丢弃页面。
            if self.grow() {
                continue;
            }
            self.pixels.fill(0);
            self.cursor_x = 0;
            self.cursor_y = 0;
            self.row_height = 0;
            cleared = true;
        }
        let slot = Slot {
            x: self.cursor_x,
            y: self.cursor_y,
            width: w,
            height: h,
            left: 0,
            top: 0,
        };
        self.cursor_x += w;
        self.row_height = self.row_height.max(h);
        Some((slot, cleared))
    }

    fn write(&mut self, slot: Slot, src: &[u8]) {
        self.ensure();
        let bpp = self.bytes_per_pixel as usize;
        let n = slot.width as usize * bpp;
        for row in 0..slot.height {
            let from = (row * slot.width) as usize * bpp;
            let to = ((slot.y + row) * self.width + slot.x) as usize * bpp;
            self.pixels[to..to + n].copy_from_slice(&src[from..from + n]);
        }
    }

    fn region(&self, slot: Slot) -> Vec<u8> {
        let bpp = self.bytes_per_pixel as usize;
        let mut out = Vec::with_capacity((slot.width * slot.height) as usize * bpp);
        for row in 0..slot.height {
            let start = ((slot.y + row) * self.width + slot.x) as usize * bpp;
            out.extend_from_slice(&self.pixels[start..start + slot.width as usize * bpp]);
        }
        out
    }

    fn dimensions(&self) -> (u32, u32) {
        (self.width, self.height)
    }
}

/// Coverage and colour pages, plus the slots indexed into them.
/// 覆盖率页与颜色页，以及指向它们的槽位索引。
pub struct GlyphCache {
    faces: HashMap<FaceId, ParsedFace>,
    /// Keyed by face, glyph, quarter-pixel size bucket and subpixel phase. `None` records a
    /// glyph with no pixels at all (spaces, `.notdef`), so it is not re-rasterized every frame.
    /// 键为字面、字形、1/4 像素字号桶与亚像素相位。`None` 记下完全没有像素的字形
    /// （空格、`.notdef`），免得它每帧被重新光栅一遍。
    entries: HashMap<(FaceId, u32, u32, u8), Option<Slot>>,
    /// Colour entries ignore the phase: emoji do not need quarter-pixel positioning.
    /// 颜色条目忽略相位：emoji 不需要 1/4 像素定位。
    color_entries: HashMap<(FaceId, u32, u32, u8), Slot>,
    coverage: Shelf,
    color: Shelf,
    pub stats: CacheStats,
    /// Changes whenever a colour entry is added or the colour page moves.
    /// 颜色条目新增或颜色页变化时推进。
    pub color_version: u64,
}

/// Cache hit/miss counters.
/// 缓存命中/未命中计数。
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct CacheStats {
    pub hits: u64,
    pub misses: u64,
    pub rasterized: u64,
    pub evictions: u64,
    /// How many times the atlas widened instead of evicting.
    /// 图集扩宽而非淘汰的次数。
    pub grows: u64,
}

impl GlyphCache {
    pub fn new(width: u32, height: u32) -> Self {
        Self {
            faces: HashMap::new(),
            entries: HashMap::new(),
            color_entries: HashMap::new(),
            coverage: Shelf::new(width, height, 1, true),
            color: Shelf::new(width, height, 4, false),
            stats: CacheStats::default(),
            color_version: 0,
        }
    }

    /// Register a face's bytes; returns whether it parsed.
    /// 注册字面的字节；返回是否解析成功。
    pub fn add_face(&mut self, face: FaceId, data: impl Into<ui_text::FontBlob>) -> bool {
        self.add_face_at(face, data, 0)
    }

    /// Add a face that lives at `font_index` inside a collection file.
    /// 添加位于集合文件内 `font_index` 处的字面。
    pub fn add_face_at(
        &mut self,
        face: FaceId,
        data: impl Into<ui_text::FontBlob>,
        font_index: u32,
    ) -> bool {
        self.add_face_instance(face, data, font_index, None)
    }

    /// Add a variable-font instance, so its rasterised glyphs use the instance's axis.
    /// 添加可变字体实例，使其光栅出的字形使用该实例的轴值。
    pub fn add_face_instance(
        &mut self,
        face: FaceId,
        data: impl Into<ui_text::FontBlob>,
        font_index: u32,
        weight: Option<f32>,
    ) -> bool {
        self.add_face_axes(face, data, font_index, weight, Variations::NONE)
    }

    /// Add an instance at `weight` and the extra `axes`.
    /// 添加位于 `weight` 与额外 `axes` 处的实例。
    pub fn add_face_axes(
        &mut self,
        face: FaceId,
        data: impl Into<ui_text::FontBlob>,
        font_index: u32,
        weight: Option<f32>,
        axes: Variations,
    ) -> bool {
        match ParsedFace::new_axes(data, font_index, weight, axes) {
            Some(parsed) => {
                self.faces.insert(face, parsed);
                true
            }
            None => false,
        }
    }

    pub fn face_metrics(&self, face: FaceId) -> Option<RealMetrics> {
        self.faces.get(&face).map(|f| f.metrics())
    }

    /// Advance width of `gid` at `px`.
    /// `gid` 在 `px` 字号下的前进宽度。
    pub fn advance_px(&self, face: FaceId, gid: u32, px: f32) -> Option<f32> {
        self.faces.get(&face).map(|f| f.advance_em(gid) * px)
    }

    pub fn glyph_id(&self, face: FaceId, c: char) -> Option<u32> {
        self.faces.get(&face)?.glyph_id(c)
    }

    /// Coverage bitmap for `c`, rasterizing once. Returns the slot plus the
    /// underlying coverage bytes so the caller can composite.
    /// `c` 的覆盖率位图，只光栅一次。返回槽位与覆盖率字节供合成。
    pub fn glyph(&mut self, face: FaceId, c: char, px: f32) -> Option<(Slot, Vec<u8>)> {
        let gid = self.glyph_id(face, c)?;
        self.glyph_by_id(face, gid, px)
    }

    /// Coverage bitmap for a shaped glyph id at `px`.
    /// 为整形后的字形 id 在 `px` 下取覆盖率位图。
    pub fn glyph_for_id(&mut self, face: FaceId, gid: u16, px: f32) -> Option<(Slot, Vec<u8>)> {
        self.glyph_by_id(face, gid as u32, px)
    }

    /// Rasterize a placed run at device resolution and return 1:1 blits.
    /// 按设备分辨率光栅已落位的文本，返回 1:1 贴图。
    ///
    /// Rasterizing at `size` instead of `size * scale` yields glyphs that are too
    /// small; leaving the destination in logical units makes the renderer rescale
    /// the tile, which is what looks like blur.
    /// 若按 `size` 而非 `size * scale` 光栅，字形会偏小；若目标矩形留在逻辑单位，
    /// 渲染器会重新缩放图块，那就是"糊"的来源。
    pub fn blit_run(
        &mut self,
        face: FaceId,
        placed: &[crate::PlacedGlyph],
        size: f32,
        scale: f32,
    ) -> Vec<GlyphBlit> {
        let scale = if scale.is_finite() && scale > 0.0 {
            scale
        } else {
            1.0
        };
        let device_px = size * scale;
        let mut out = Vec::with_capacity(placed.len());
        for glyph in placed {
            let Some((slot, kind)) =
                self.entry_by_id_phased(face, glyph.glyph_id as u32, device_px, glyph.bin)
            else {
                continue;
            };
            out.push(GlyphBlit {
                atlas: ui_core::geom::Rect::new(
                    slot.x as f32,
                    slot.y as f32,
                    slot.width as f32,
                    slot.height as f32,
                ),
                dest: ui_core::geom::Rect::new(
                    (glyph.origin_x + slot.left) as f32,
                    (glyph.baseline_y - slot.top) as f32,
                    slot.width as f32,
                    slot.height as f32,
                ),
                kind,
            });
        }
        out
    }

    /// Coverage for a shaped glyph id at a subpixel phase.
    /// 取整形后字形在亚像素相位下的覆盖率。
    pub fn glyph_for_id_phased(
        &mut self,
        face: FaceId,
        gid: u16,
        px: f32,
        bin: ui_text::SubpixelBin,
    ) -> Option<(Slot, Vec<u8>)> {
        self.glyph_by_id_phased(face, gid as u32, px, bin)
    }

    /// Coverage bitmap by glyph id.
    /// 按字形 id 取覆盖率位图。
    pub fn glyph_by_id(&mut self, face: FaceId, gid: u32, px: f32) -> Option<(Slot, Vec<u8>)> {
        self.glyph_by_id_phased(face, gid, px, ui_text::SubpixelBin::Zero)
    }

    /// Pixels for a glyph at one of four horizontal phases: one coverage byte or
    /// four premultiplied RGBA bytes per pixel, depending on which atlas it landed in.
    /// 取字形在四个水平相位之一的像素：每像素一字节覆盖率或四字节预乘 RGBA，
    /// 取决于它落在哪张图集。
    pub fn glyph_by_id_phased(
        &mut self,
        face: FaceId,
        gid: u32,
        px: f32,
        bin: ui_text::SubpixelBin,
    ) -> Option<(Slot, Vec<u8>)> {
        let (slot, kind) = self.entry_by_id_phased(face, gid, px, bin)?;
        let region = match kind {
            GlyphKind::Coverage => self.coverage.region(slot),
            GlyphKind::Color => self.color.region(slot),
        };
        Some((slot, region))
    }

    /// Which atlas holds `gid`, rasterizing on a miss.
    /// `gid` 落在哪张图集，未命中时先光栅。
    pub fn entry_kind(
        &mut self,
        face: FaceId,
        gid: u32,
        px: f32,
        bin: ui_text::SubpixelBin,
    ) -> Option<GlyphKind> {
        self.entry_by_id_phased(face, gid, px, bin)
            .map(|(_, kind)| kind)
    }

    /// Resolve a glyph to an atlas slot, rasterizing and caching it on a miss.
    /// 把字形解析成图集槽位，未命中时光栅并缓存。
    fn entry_by_id_phased(
        &mut self,
        face: FaceId,
        gid: u32,
        px: f32,
        bin: ui_text::SubpixelBin,
    ) -> Option<(Slot, GlyphKind)> {
        let size_key = (px * 4.0).round() as u32; // quarter-pixel buckets
        let key = (face, gid, size_key, bin.index());
        if let Some(cached) = self.entries.get(&key) {
            self.stats.hits += 1;
            return cached.map(|slot| (slot, GlyphKind::Coverage));
        }
        // Colour entries are phase-independent, so every phase shares the zero bucket.
        // 颜色条目与相位无关，因此所有相位共用零桶。
        let color_key = (face, gid, size_key, 0);
        if let Some(slot) = self.color_entries.get(&color_key) {
            self.stats.hits += 1;
            return Some((*slot, GlyphKind::Color));
        }
        self.stats.misses += 1;

        // A colour source wins when the glyph has one; monochrome glyphs fall through.
        // 字形有颜色来源时优先走它；单色字形继续往下走。
        let color = {
            let parsed = self.faces.get_mut(&face)?;
            parsed.rasterize_color(gid, px)
        };
        if let Some(bitmap) = color {
            self.stats.rasterized += 1;
            let slot = self.alloc_in(GlyphKind::Color, bitmap.width, bitmap.height)?;
            self.color.write(slot, &bitmap.rgba);
            let slot = Slot {
                left: bitmap.left,
                top: bitmap.top,
                ..slot
            };
            self.color_entries.insert(color_key, slot);
            self.color_version += 1;
            return Some((slot, GlyphKind::Color));
        }

        let bitmap = self
            .faces
            .get(&face)
            .and_then(|parsed| parsed.rasterize_subpixel(gid, px, bin.as_float()));
        let Some(bitmap) = bitmap else {
            // A space or `.notdef` has no pixels at all. Remember that, or every frame rebuilds
            // a swash scaler just to discover it again.
            // 空格或 `.notdef` 根本没有像素。记住这点，否则每帧都要重建一次 swash scaler
            // 才能再发现一遍。
            self.entries.insert(key, None);
            return None;
        };
        self.stats.rasterized += 1;

        let slot = self.alloc_in(GlyphKind::Coverage, bitmap.width, bitmap.height)?;
        self.coverage.write(slot, &bitmap.coverage);
        let slot = Slot {
            left: bitmap.left,
            top: bitmap.top,
            ..slot
        };
        self.entries.insert(key, Some(slot));
        Some((slot, GlyphKind::Coverage))
    }

    /// Allocate a tile in the requested page, dropping its index on eviction.
    /// 在指定页面分配图块，淘汰时丢弃该页索引。
    fn alloc_in(&mut self, kind: GlyphKind, w: u32, h: u32) -> Option<Slot> {
        let (before, slot, cleared, after) = {
            let shelf = match kind {
                GlyphKind::Coverage => &mut self.coverage,
                GlyphKind::Color => &mut self.color,
            };
            let before = shelf.dimensions();
            let allocated = shelf.alloc(w, h);
            let after = shelf.dimensions();
            let (slot, cleared) = allocated?;
            (before, slot, cleared, after)
        };
        if after != before {
            self.stats.grows += 1;
            if kind == GlyphKind::Color {
                self.color_version += 1;
            }
        }
        if cleared {
            match kind {
                GlyphKind::Coverage => self.entries.clear(),
                GlyphKind::Color => self.color_entries.clear(),
            }
            self.stats.evictions += 1;
            if kind == GlyphKind::Color {
                self.color_version += 1;
            }
        }
        Some(slot)
    }

    /// Full coverage atlas, for debugging or uploading as a texture.
    /// 完整覆盖率图集，供调试或作为纹理上传。
    pub fn atlas(&self) -> &[u8] {
        &self.coverage.pixels
    }

    /// Full colour atlas: premultiplied RGBA, empty until a colour glyph is rasterized.
    /// 完整颜色图集：预乘 RGBA，在光栅出颜色字形前为空。
    pub fn color_atlas(&self) -> &[u8] {
        &self.color.pixels
    }

    pub fn dimensions(&self) -> (u32, u32) {
        self.coverage.dimensions()
    }

    pub fn color_dimensions(&self) -> (u32, u32) {
        self.color.dimensions()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// Any resolvable sans face, via the platform provider rather than `fc-match`,
    /// so the same tests work on fontconfig and DirectWrite.
    /// 通过平台 provider 取任意可解析的无衬线字面，而不是 `fc-match`，
    /// 使同一批测试在 fontconfig 与 DirectWrite 上都有效。
    fn any_system_font() -> Option<ui_text::FontBlob> {
        crate::tests_support::sans_face()
    }

    #[test]
    fn real_metrics_come_from_the_font_tables() {
        let Some(data) = any_system_font() else {
            return;
        };
        let face = ParsedFace::new(data).expect("parse");
        let m = face.metrics();
        assert!(m.units_per_em >= 16.0, "upem must be a real value");
        assert!(m.ascent > 0.5 && m.ascent < 1.5, "ascent em ratio");
        assert!(m.descent < 0.0, "descent is negative in font units");
    }

    /// A glyph with no pixels is resolved once, then served from the cache like any other.
    /// 没有像素的字形只解析一次，之后像其他字形一样由缓存供应。
    ///
    /// Otherwise every frame rebuilds a swash scaler for every space on the page, and the
    /// CFF table parse that comes with it costs more than drawing the text.
    /// 否则每帧都要为页面上的每个空格重建一次 swash scaler，随之而来的 CFF 表解析
    /// 比画这段文字还贵。
    #[test]
    fn a_glyph_with_no_pixels_is_remembered_instead_of_retried() {
        let Some(data) = any_system_font() else {
            return;
        };
        let mut cache = GlyphCache::new(64, 64);
        let face = FaceId(0);
        assert!(cache.add_face(face, data));
        let gid = cache.glyph_id(face, ' ').expect("a space has a glyph id");
        assert!(cache.glyph_by_id(face, gid, 12.0).is_none(), "a space has no pixels");
        let missed = cache.stats.misses;
        assert!(cache.glyph_by_id(face, gid, 12.0).is_none());
        assert_eq!(cache.stats.misses, missed, "the second look-up must not reach the font");
    }

    #[test]
    fn glyph_id_is_found_for_a_common_character() {
        let Some(data) = any_system_font() else {
            return;
        };
        let face = ParsedFace::new(data).expect("parse");
        assert!(face.glyph_id('a').is_some(), "sans-serif covers 'a'");
        assert!(face.glyph_id('\u{10FFF0}').is_none(), "unassigned has no glyph");
    }

    #[test]
    fn rasterize_produces_non_empty_coverage() {
        let Some(data) = any_system_font() else {
            return;
        };
        let face = ParsedFace::new(data).expect("parse");
        let gid = face.glyph_id('A').expect("glyph");
        let bitmap = face.rasterize(gid, 32.0).expect("raster");
        assert!(bitmap.width > 4 && bitmap.height > 4, "glyph has size");
        let lit = bitmap.coverage.iter().filter(|b| **b > 0).count();
        assert!(lit > 20, "a glyph must cover some pixels, got {lit}");
        assert!(
            bitmap.coverage.iter().any(|b| *b > 200),
            "glyph core must be near-opaque somewhere"
        );
    }

    #[test]
    fn larger_size_rasterizes_larger_glyph() {
        let Some(data) = any_system_font() else {
            return;
        };
        let face = ParsedFace::new(data).expect("parse");
        let gid = face.glyph_id('A').expect("glyph");
        let small = face.rasterize(gid, 12.0).expect("small");
        let large = face.rasterize(gid, 48.0).expect("large");
        assert!(
            large.width > small.width * 2,
            "4x size must roughly quadruple width ({} vs {})",
            large.width,
            small.width
        );
    }

    #[test]
    fn atlas_returns_the_same_slot_on_second_request() {
        let Some(data) = any_system_font() else {
            return;
        };
        let mut cache = GlyphCache::new(256, 256);
        let face = FaceId(0);
        assert!(cache.add_face(face, data));
        let (a, _) = cache.glyph(face, 'B', 20.0).expect("first");
        let (b, _) = cache.glyph(face, 'B', 20.0).expect("second");
        assert_eq!(a, b, "second request must hit the cache");
        assert_eq!(cache.stats.hits, 1);
        assert_eq!(cache.stats.rasterized, 1);
    }

    #[test]
    fn different_sizes_get_different_slots() {
        let Some(data) = any_system_font() else {
            return;
        };
        let mut cache = GlyphCache::new(256, 256);
        let face = FaceId(0);
        cache.add_face(face, data);
        let (a, _) = cache.glyph(face, 'C', 16.0).expect("16px");
        let (b, _) = cache.glyph(face, 'C', 32.0).expect("32px");
        assert_ne!(a, b);
        assert!(b.height > a.height);
    }

    #[test]
    fn cap_letters_sit_on_the_baseline() {
        let Some(data) = any_system_font() else {
            return;
        };
        let mut cache = GlyphCache::new(256, 256);
        let face = FaceId(0);
        cache.add_face(face, data);
        let size = 40.0;
        let (slot, _) = cache.glyph(face, 'H', size).expect("H");

        // The bitmap's bottom edge must land within a couple of pixels of the
        // baseline: a capital letter has no descender.
        // 比特图底边必须落在基线上下几像素内：大写字母没有降部。
        let bottom_below_baseline = slot.height as f32 - slot.top as f32;
        assert!(
            bottom_below_baseline.abs() <= 2.0,
            "H must sit on the baseline, bottom is {bottom_below_baseline} px below it"
        );
        // And its top must be near the cap height, roughly 0.7 em.
        // 顶部应接近大写高度，约 0.7 em。
        let cap_em = slot.top as f32 / size;
        assert!(
            (0.6..=0.8).contains(&cap_em),
            "cap height should be ~0.7em, got {cap_em}"
        );
    }

    #[test]
    fn descenders_hang_below_the_baseline() {
        let Some(data) = any_system_font() else {
            return;
        };
        let mut cache = GlyphCache::new(256, 256);
        let face = FaceId(0);
        cache.add_face(face, data);
        let (slot, _) = cache.glyph(face, 'j', 40.0).expect("j");
        let bottom_below_baseline = slot.height as f32 - slot.top as f32;
        assert!(
            bottom_below_baseline > 5.0,
            "'j' must hang below the baseline, got {bottom_below_baseline} px"
        );
    }

    #[test]
    fn taller_size_gives_larger_cap_height() {
        let Some(data) = any_system_font() else {
            return;
        };
        let mut cache = GlyphCache::new(512, 512);
        let face = FaceId(0);
        cache.add_face(face, data);
        let (small, _) = cache.glyph(face, 'H', 20.0).expect("20px");
        let (large, _) = cache.glyph(face, 'H', 40.0).expect("40px");
        let ratio = large.top as f32 / small.top as f32;
        assert!(
            (ratio - 2.0).abs() < 0.25,
            "doubling size must roughly double cap height, got {ratio}"
        );
    }

    #[test]
    fn different_phases_rasterize_different_bitmaps() {
        let Some(data) = any_system_font() else {
            return;
        };
        let face = ParsedFace::new(data).expect("font");
        let gid = face.glyph_id('l').expect("glyph");
        let phases: Vec<Vec<u8>> = (0..4)
            .map(|i| {
                face.rasterize_subpixel(gid, 32.0, i as f32 * 0.25)
                    .expect("raster")
                    .coverage
            })
            .collect();
        // Every phase must differ from the next: identical bitmaps would mean the
        // offset never reached the rasterizer.
        // 每个相位都必须与下一个不同：位图相同说明偏移根本没进入光栅器。
        for i in 0..3 {
            assert_ne!(
                phases[i], phases[i + 1],
                "phase {i} and {} produced identical coverage",
                i + 1
            );
        }
    }

    #[test]
    fn each_phase_gets_its_own_cache_entry() {
        let Some(data) = any_system_font() else {
            return;
        };
        let mut cache = GlyphCache::new(512, 512);
        let face = FaceId(0);
        cache.add_face(face, data);
        let gid = cache.glyph_id(face, 'm').expect("glyph");

        let mut slots = Vec::new();
        for i in 0..4 {
            let bin = ui_text::SubpixelBin::from_index(i);
            let (slot, _) = cache
                .glyph_by_id_phased(face, gid, 32.0, bin)
                .expect("glyph");
            slots.push(slot);
        }
        // Four distinct atlas slots, one per phase.
        // 四个不同的图集槽位，每个相位一个。
        for i in 0..4 {
            for j in (i + 1)..4 {
                assert_ne!(slots[i], slots[j], "phases {i} and {j} share a slot");
            }
        }
        assert_eq!(cache.stats.rasterized, 4);
    }

    #[test]
    fn phase_zero_matches_the_unphased_bitmap() {
        let Some(data) = any_system_font() else {
            return;
        };
        let face = ParsedFace::new(data).expect("font");
        let gid = face.glyph_id('k').expect("glyph");
        let plain = face.rasterize(gid, 24.0).expect("plain");
        let zero = face
            .rasterize_subpixel(gid, 24.0, ui_text::SubpixelBin::Zero.as_float())
            .expect("zero");
        assert_eq!(plain.coverage, zero.coverage);
        assert_eq!(plain.width, zero.width);
    }

    #[test]
    fn blit_run_is_one_to_one_at_any_scale() {
        let Some(data) = any_system_font() else {
            return;
        };
        let mut cache = GlyphCache::new(1024, 1024);
        let face = FaceId(0);
        cache.add_face(face, data.clone());
        let shaper = crate::Shaper::new(data, 0).expect("font");
        let mut shaper = shaper;
        let run = shaper.shape("Hamburgefonstiv", 13.0, ui_text::Script::LATIN);

        for scale in [1.0f32, 1.25, 1.5, 1.6, 2.0] {
            let placed = crate::place_run_scaled(&run, 18.3, 40.7, true, scale);
            let blits = cache.blit_run(face, &placed, 13.0, scale);
            assert_eq!(blits.len(), placed.len());
            for blit in &blits {
                // A mismatch here is exactly what makes the renderer resample.
                // 这里不相等，正是渲染器重新采样的原因。
                assert!(
                    (blit.dest.size.w - blit.atlas.size.w).abs() < 0.01
                        && (blit.dest.size.h - blit.atlas.size.h).abs() < 0.01,
                    "scale {scale}: dest {:?} must match atlas {:?}",
                    blit.dest.size,
                    blit.atlas.size
                );
            }
        }
    }

    #[test]
    fn blit_run_rasterizes_at_device_resolution() {
        let Some(data) = any_system_font() else {
            return;
        };
        let face = FaceId(0);
        let shaper = crate::Shaper::new(data.clone(), 0).expect("font");
        let mut shaper = shaper;
        // Large enough that integer pixel rounding on the glyph outline is a small
        // fraction of the height; at 13px it dominates and the ratio is font-specific.
        // 选足够大的字号，使轮廓整数取整只占高度的一小部分；
        // 13px 时取整占主导，比例会变成字体特有的。
        const SIZE: f32 = 64.0;
        let run = shaper.shape("H", SIZE, ui_text::Script::LATIN);

        let mut small = GlyphCache::new(512, 512);
        small.add_face(face, data.clone());
        let placed_1x = crate::place_run_scaled(&run, 0.0, 100.0, false, 1.0);
        let one_x = small.blit_run(face, &placed_1x, SIZE, 1.0);

        let mut large = GlyphCache::new(512, 512);
        large.add_face(face, data);
        let placed_2x = crate::place_run_scaled(&run, 0.0, 200.0, false, 2.0);
        let two_x = large.blit_run(face, &placed_2x, SIZE, 2.0);

        let h1 = one_x[0].dest.size.h;
        let h2 = two_x[0].dest.size.h;
        assert!(
            (h2 / h1 - 2.0).abs() < 0.1,
            "2x must rasterize twice as tall: {h1} -> {h2}"
        );
    }

    #[test]
    fn atlas_grows_instead_of_evicting_when_a_page_fills() {
        let Some(data) = any_system_font() else {
            return;
        };
        // A page far too small for a full alphabet forces growth.
        // 一页远小于整套字母，必然触发扩容。
        let mut cache = GlyphCache::new(64, 64);
        let face = FaceId(0);
        cache.add_face(face, data);
        for c in 'a'..='z' {
            cache.glyph(face, c, 32.0);
        }
        assert_eq!(
            cache.stats.evictions, 0,
            "growth must happen before any eviction"
        );
        assert!(cache.stats.grows > 0, "the page must have widened");
        assert!(cache.dimensions().0 > 64);
    }

    #[test]
    fn grow_preserves_existing_glyph_content() {
        let Some(data) = any_system_font() else {
            return;
        };
        let mut cache = GlyphCache::new(64, 64);
        let face = FaceId(0);
        cache.add_face(face, data);
        let (first, before) = cache.glyph(face, 'W', 32.0).expect("W");
        // Force several growths.
        // 强制多次扩容。
        for c in 'a'..='z' {
            cache.glyph(face, c, 32.0);
        }
        assert!(cache.stats.grows > 0);
        // The same slot must still hold the same pixels.
        // 同一槽位必须仍是同样的像素。
        let (again, after) = cache.glyph(face, 'W', 32.0).expect("W again");
        assert_eq!(first, again, "slot is stable across growth");
        assert_eq!(before, after, "coverage is preserved across growth");
    }

    #[test]
    fn advance_is_read_from_hmtx() {
        let Some(data) = any_system_font() else {
            return;
        };
        let face = ParsedFace::new(data).expect("parse");
        let gid = face.glyph_id('M').expect("glyph");
        let adv = face.advance_em(gid);
        assert!(adv > 0.2 && adv < 1.5, "advance em must be plausible: {adv}");
    }

    #[test]
    fn a_colour_glyph_lands_in_the_rgba_page_instead_of_coverage() {
        let Some(data) = crate::tests_support::emoji_face() else {
            eprintln!("skipped: no colour emoji face is installed");
            return;
        };
        let mut cache = GlyphCache::new(256, 256);
        let face = FaceId(0);
        assert!(cache.add_face(face, data));
        let Some(gid) = cache.glyph_id(face, '\u{1F600}') else {
            eprintln!("skipped: the emoji face has no U+1F600");
            return;
        };
        let bin = ui_text::SubpixelBin::Zero;
        assert_eq!(
            cache.entry_kind(face, gid, 32.0, bin),
            Some(GlyphKind::Color),
            "a glyph with colour layers must not take the coverage path"
        );
        let (slot, pixels) = cache
            .glyph_by_id_phased(face, gid, 32.0, bin)
            .expect("colour glyph");
        assert!(slot.width > 0 && slot.height > 0);
        assert_eq!(
            pixels.len(),
            (slot.width * slot.height * 4) as usize,
            "the colour page stores four bytes per pixel"
        );
        assert!(
            pixels.as_chunks::<4>().0.iter().any(|p| p[0] > 0 || p[1] > 0 || p[2] > 0),
            "the colour entry must contain ink"
        );
        assert!(
            !cache.color_atlas().is_empty(),
            "the colour page must have been allocated"
        );
        assert_eq!(cache.color_version, 1, "one colour entry bumps the version");
    }

    #[test]
    fn a_monochrome_glyph_stays_on_the_coverage_path() {
        let Some(data) = any_system_font() else {
            return;
        };
        let mut cache = GlyphCache::new(256, 256);
        let face = FaceId(0);
        cache.add_face(face, data);
        let gid = cache.glyph_id(face, 'A').expect("A");
        let bin = ui_text::SubpixelBin::Zero;
        assert_eq!(
            cache.entry_kind(face, gid, 32.0, bin),
            Some(GlyphKind::Coverage),
            "a plain outline must not be mistaken for a colour glyph"
        );
        let (slot, pixels) = cache.glyph_by_id_phased(face, gid, 32.0, bin).expect("A");
        assert_eq!(pixels.len(), (slot.width * slot.height) as usize);
        assert!(
            cache.color_atlas().is_empty(),
            "no colour page may be allocated for monochrome text"
        );
        assert_eq!(cache.color_version, 0);
    }
}
