//! Platform-native font provider backed by `fontique`.
//! 由 `fontique` 支撑的平台原生字体提供者。
//!
//! `fontique` owns the per-OS calls (fontconfig on Linux, DirectWrite on Windows,
//! CoreText on macOS); this crate only translates its shapes into our
//! `FontProvider` trait, so replacing `fontique` touches one file.
//! `fontique` 负责各操作系统的原生调用（Linux 的 fontconfig、Windows 的 DirectWrite、
//! macOS 的 CoreText）；本 crate 只把它的形状翻译成我们的 `FontProvider`，
//! 因此替换 `fontique` 只改一个文件。

pub mod face;
pub mod glyph;
pub mod shape;

#[cfg(test)]
mod tests_support;

pub use face::FaceData;
pub use glyph::{ColorBitmap, GlyphBitmap, GlyphBlit, GlyphCache, ParsedFace, RealMetrics, Slot};
pub use shape::{
    place_run, place_run_scaled, PlacedGlyph, ShapedGlyph, ShapedRun, Shaper, VisualRun,
};

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

use fontique::{Collection, CollectionOptions, FallbackKey, FamilyId, Script as FqScript};
use ui_text::{
    FaceId, FaceMetrics, FontBlob, FontProvider, FontRequest, GenericFamily, Script, Variations,
};

/// A provider that enumerates the OS font stack through `fontique`.
/// 通过 `fontique` 枚举操作系统字体栈的提供者。
pub struct FontiqueProvider {
    inner: Mutex<Collection>,
    /// `FaceId` -> what fontique needs to look the face up again.
    /// `FaceId` -> fontique 再次查找该字面所需的信息。
    faces: Vec<FaceSlot>,
    /// Family name -> slot index, for exact name lookup.
    /// 族名 -> 槽位下标，用于精确查名。
    by_name: HashMap<String, u32>,
    /// Cached raw font bytes; loading hits the disk otherwise.
    /// 缓存的原始字体字节；否则每次加载都会读盘。
    blobs: Mutex<HashMap<FaceId, FontBlob>>,
    /// Cached family name -> FamilyId, rebuilt on first use.
    /// 缓存的族名 -> FamilyId，首次使用时建立。
    family_ids: Mutex<HashMap<String, FamilyId>>,
    /// (family, index within the family) -> the face's default slot.
    /// （族，族内下标）-> 该字面的默认槽位。
    by_family_index: HashMap<(FamilyId, usize), u32>,
    /// (family, index, weight) -> the variable-font instance slot for that weight.
    /// （族，族内下标，字重）-> 该字重对应的可变字体实例槽位。
    by_variation: HashMap<(FamilyId, usize, u16), u32>,
    /// (family, index, weight, extra axes at 1/64) -> the instance slot for that position.
    /// （族，族内下标，字重，1/64 量化的其余轴）-> 该位置对应的实例槽位。
    by_axes: HashMap<(FamilyId, usize, u16, [Option<i32>; 3]), u32>,
    /// Whether the OS font stack was actually available.
    /// 操作系统字体栈是否真的可用。
    system: bool,
}

#[derive(Clone, Debug)]
struct FaceSlot {
    family: FamilyId,
    family_name: String,
    /// Which font of the family this face is. A family holds Regular, Bold, Italic...
    /// 该字面是族里的哪一个字体。一个族含 Regular、Bold、Italic……
    font_index: usize,
    /// Weight instance for a variable font; `None` for a static face.
    /// 可变字体的字重实例；静态字面为 `None`。
    ///
    /// A variable font is one face with a continuous axis, so "Bold" is not a different
    /// font — it is the same file at a different `wght`. Encoding the instance in
    /// `FaceId` keeps every downstream cache correct without new key dimensions.
    /// 可变字体是一个带连续轴的字面，因此「粗体」不是另一个字体，
    /// 而是同一文件在另一个 `wght` 上。把实例编码进 `FaceId`，
    /// 下游所有缓存无需增加键维度就自动正确。
    variation: Option<f32>,
    /// The axes beyond weight this instance sits at; `NONE` for a face's own defaults.
    /// 该实例字重之外的轴位置；字面默认位置为 `NONE`。
    axes: Variations,
}

/// `wght` axis tag, the only axis a weight request can drive.
/// `wght` 轴标签，字重请求唯一能驱动的轴。
const VARIATION_WEIGHT_TAG: skrifa::Tag = skrifa::Tag::new(b"wght");

/// Weight instances to register for a variable font, clamped to the axis range.
/// 为可变字体注册的字重实例，钳制在轴范围内。
///
/// A ladder rather than a single value: a request for 600 must land on something
/// between Regular and Bold instead of snapping to one end.
/// 用阶梯而不是单值：请求 600 必须落在 Regular 与 Bold 之间的某处，
/// 而不是被吸到某一端。
fn weight_ladder(min: f32, max: f32) -> Vec<u16> {
    let mut out = Vec::new();
    for w in (100..=900).step_by(100) {
        let w = w as f32;
        if w >= min && w <= max {
            out.push(w as u16);
        }
    }
    // Always include the axis ends so an extreme request still has a target.
    // 总是包含轴的两端，使极端请求也有落点。
    for w in [min, max] {
        let w = w.round();
        if (100.0..=900.0).contains(&w) && !out.contains(&(w as u16)) {
            out.push(w as u16);
        }
    }
    out.sort_unstable();
    out
}

/// Generic family mapping, kept separate so tests can pin it.
/// 通用族映射，独立存放以便测试固定它。
/// A sized wrapper, because `Arc<[u8]>` cannot coerce straight to a trait object.
/// 一个定长包装：`Arc<[u8]>` 无法直接强制转换成 trait 对象。
struct FontBytes(Arc<[u8]>);

impl AsRef<[u8]> for FontBytes {
    fn as_ref(&self) -> &[u8] {
        &self.0
    }
}

/// Snapshot one family's faces, plus a weight-instance ladder for each variable font.
/// 快照一个族的字面，并为每个可变字面登记一条字重实例阶梯。
///
/// A variable font is one face with a continuous weight axis. Registering a ladder of
/// instances makes "Bold" a distinct `FaceId`, which keeps the shaper, rasterizer and
/// atlas keyed correctly with no new key dimension.
/// 可变字体是一个带连续字重轴的字面。预注册实例阶梯使「粗体」成为独立的 `FaceId`，
/// 整形器、光栅器与图集因此无需新增键维度就是对的。
fn admit_faces(
    faces: &mut Vec<FaceSlot>,
    by_name: &mut HashMap<String, u32>,
    by_family_index: &mut HashMap<(FamilyId, usize), u32>,
    by_variation: &mut HashMap<(FamilyId, usize, u16), u32>,
    family: FamilyId,
    name: &str,
    fonts: &[fontique::FontInfo],
    default: usize,
) {
    for (index, font) in fonts.iter().enumerate() {
        let slot = faces.len() as u32;
        by_family_index.insert((family, index), slot);
        if index == default {
            // The name resolves to the family's own default face.
            // 族名解析到该族自己的默认字面。
            by_name.entry(name.to_string()).or_insert(slot);
        }
        faces.push(FaceSlot {
            family,
            family_name: name.to_string(),
            font_index: index,
            variation: None,
            axes: Variations::NONE,
        });
        if !font.has_weight_axis() {
            continue;
        }
        let Some(axis) = font.axes().iter().find(|a| a.tag == VARIATION_WEIGHT_TAG) else {
            continue;
        };
        for weight in weight_ladder(axis.min, axis.max) {
            let slot = faces.len() as u32;
            by_variation.insert((family, index, weight), slot);
            faces.push(FaceSlot {
                family,
                family_name: name.to_string(),
                font_index: index,
                variation: Some(weight as f32),
                axes: Variations::NONE,
            });
        }
    }
}

fn generic_of(g: GenericFamily) -> fontique::GenericFamily {
    match g {
        GenericFamily::SansSerif | GenericFamily::SystemUi => fontique::GenericFamily::SansSerif,
        GenericFamily::Serif => fontique::GenericFamily::Serif,
        GenericFamily::Monospace => fontique::GenericFamily::Monospace,
    }
}

fn fq_script(s: Script) -> FqScript {
    FqScript::from_bytes(s.0)
}

impl FontiqueProvider {
    /// Build a provider over the OS font stack.
    /// 在操作系统字体栈上构建提供者。
    pub fn new_system() -> Self {
        let collection = Collection::new(CollectionOptions {
            shared: false,
            system_fonts: true,
        });
        Self::from_collection(collection)
    }

    /// Build a provider with no system fonts (for deterministic tests).
    /// 构建不含系统字体的提供者（用于确定性测试）。
    pub fn new_isolated() -> Self {
        let collection = Collection::new(CollectionOptions {
            shared: false,
            system_fonts: false,
        });
        Self::from_collection(collection)
    }

    fn from_collection(mut collection: Collection) -> Self {
        let mut faces = Vec::new();
        let mut by_name = HashMap::new();
        let mut by_variation: HashMap<(FamilyId, usize, u16), u32> = HashMap::new();
        let mut names = HashMap::new();

        // Snapshot every *face*, not one per family: `FaceId` must identify a face, or
        // bold and regular share an id and the loader can only guess.
        // 快照每个**字面**，而不是每族一个：`FaceId` 必须标识字面，
        // 否则粗体与常规共用同一个 id，加载器只能靠猜。
        let ids: Vec<FamilyId> = collection.family_ids().collect();
        let mut by_family_index: HashMap<(FamilyId, usize), u32> = HashMap::new();
        for id in ids {
            let Some(name) = collection.family_name(id).map(|s| s.to_string()) else {
                continue;
            };
            names.entry(name.clone()).or_insert(id);
            let Some(info) = collection.family(id) else {
                continue;
            };
            let default = info.default_font_index();
            admit_faces(
                &mut faces,
                &mut by_name,
                &mut by_family_index,
                &mut by_variation,
                id,
                &name,
                info.fonts(),
                default,
            );
        }

        let system = !faces.is_empty();
        Self {
            inner: Mutex::new(collection),
            faces,
            by_name,
            by_family_index,
            by_variation,
            by_axes: HashMap::new(),
            blobs: Mutex::new(HashMap::new()),
            family_ids: Mutex::new(names),
            system,
        }
    }

    /// Whether any family was found at all.
    /// 是否找到了任何族。
    pub fn has_system_fonts(&self) -> bool {
        self.system
    }

    /// Display name of the face, for diagnostics.
    /// 字面的显示名，供诊断使用。
    pub fn face_family_name(&self, face: FaceId) -> Option<&str> {
        self.faces
            .get(face.0 as usize)
            .map(|s| s.family_name.as_str())
    }

    fn slot(&self, face: FaceId) -> Option<&FaceSlot> {
        self.faces.get(face.0 as usize)
    }

    /// A handle to `face` at `axes`, interning a slot the first time that position is asked
    /// for. The axes are quantised to 1/64 first, so an animated `FILL` yields at most 65
    /// instances rather than one per frame.
    /// 取 `axes` 处的 `face` 句柄，该位置首次被请求时登记槽位。轴先量化到 1/64，
    /// 因此动画中的 `FILL` 至多产生 65 个实例，而不是每帧一个。
    pub fn instance_axes(&mut self, face: FaceId, axes: Variations) -> FaceId {
        if axes == Variations::NONE {
            return face;
        }
        let Some(slot) = self.faces.get(face.0 as usize).cloned() else {
            return face;
        };
        let weight = slot.variation.map(|w| w as u16).unwrap_or(0);
        let quantized = axes.quantized();
        let key = (slot.family, slot.font_index, weight, quantized);
        if let Some(&existing) = self.by_axes.get(&key) {
            return FaceId(existing);
        }
        let merged = Variations {
            optical_size: quantized[0].map(|q| q as f32 / 64.0),
            fill: quantized[1].map(|q| q as f32 / 64.0),
            grade: quantized[2].map(|q| q as f32 / 64.0),
        };
        let id = FaceId(self.faces.len() as u32);
        self.faces.push(FaceSlot {
            family: slot.family,
            family_name: slot.family_name,
            font_index: slot.font_index,
            variation: slot.variation,
            axes: merged,
        });
        self.by_axes.insert(key, id.0);
        // The instance is the base face's own file, so prime the byte cache: a registered
        // family has no fontique family entry to load from later.
        // 实例就是基础字面的同一个文件，直接写入字节缓存：注册族没有可供后续加载的族条目。
        if let Some(data) = self.face_data(face)
            && let Ok(mut blobs) = self.blobs.lock() {
                blobs.insert(id, data);
            }
        id
    }

    /// Register font bytes under `name`; the family then resolves like a system one.
    /// 把字体字节注册到 `name` 下；此后该族与系统族一样可解析。
    pub fn register(&mut self, name: &str, data: Arc<[u8]>) -> bool {
        let blob: Arc<dyn AsRef<[u8]> + Send + Sync> = Arc::new(FontBytes(Arc::clone(&data)));
        let added = {
            let Ok(mut inner) = self.inner.lock() else {
                return false;
            };
            inner.register_fonts(
                fontique::Blob::new(blob),
                Some(fontique::FontInfoOverride {
                    family_name: Some(name),
                    ..Default::default()
                }),
            )
        };
        let Some((family, fonts)) = added.into_iter().next() else {
            return false;
        };
        let first = self.faces.len() as u32;
        let before = self.faces.len();
        admit_faces(
            &mut self.faces,
            &mut self.by_name,
            &mut self.by_family_index,
            &mut self.by_variation,
            family,
            name,
            &fonts,
            0,
        );
        // A registered family must win over a system family of the same name.
        // 注册族必须优先于同名系统族。
        self.by_name.insert(name.to_string(), first);
        if let Ok(mut ids) = self.family_ids.lock() {
            ids.insert(name.to_string(), family);
        }
        if let Ok(mut blobs) = self.blobs.lock() {
            let data = FontBlob::from(data);
            for slot in before..self.faces.len() {
                blobs.insert(FaceId(slot as u32), data.clone());
            }
        }
        self.system = true;
        true
    }

    /// Exact family lookup, with no alias substitution.
    /// 精确族名查找，不做别名替换。
    fn exact_family(&self, name: &str) -> Option<FamilyId> {
        let cache = self.family_ids.lock().ok()?;
        cache.get(name).copied()
    }

    /// The face of a family closest to the request, as a stable `FaceId`.
    /// 族中最接近该请求的字面，返回稳定的 `FaceId`。
    ///
    /// Matching is fontique's, not ours: it scores width, style and weight across the
    /// family's faces, which is what a hand-written "first face" lookup silently dropped.
    /// 匹配交给 fontique：它对族内各字面按宽度、样式、字重打分。
    /// 之前手写的"取第一个字面"正是把这个静默丢掉了。
    fn pick_face(&self, family: FamilyId, request: &FontRequest) -> Option<FaceId> {
        let mut inner = self.inner.lock().ok()?;
        let info = inner.family(family)?;
        if info.fonts().is_empty() {
            return None;
        }
        let weight = fontique::FontWeight::new(request.weight.0.clamp(1, 1000) as f32);
        let style = if request.italic {
            fontique::FontStyle::Italic
        } else {
            fontique::FontStyle::Normal
        };
        // `FontRequest` carries no width, so match on the normal width.
        // `FontRequest` 不带宽度轴，因此按常规宽度匹配。
        let index = info.match_index(fontique::FontWidth::NORMAL, style, weight, false)?;
        // A variable font answers with the same face for every weight; the instance
        // ladder is what actually makes Bold different.
        // 可变字体对每个字重都返回同一个字面；真正让粗体不同的是实例阶梯。
        let requested = (request.weight.0).clamp(1, 1000);
        if let Some(slot) = self.by_variation.get(&(family, index, requested)) {
            return Some(FaceId(*slot));
        }
        // Nearest ladder rung, so 550 still lands on 500 or 600 instead of Regular.
        // 取最近的阶梯档位，使 550 落在 500 或 600 上，而不是退回 Regular。
        let mut best: Option<(u16, u32)> = None;
        for ((fam, idx, w), slot) in self.by_variation.iter() {
            if *fam != family || *idx != index {
                continue;
            }
            let distance = w.abs_diff(requested);
            if best.map(|(bw, _)| distance < bw.abs_diff(requested)).unwrap_or(true) {
                best = Some((*w, *slot));
            }
        }
        if let Some((_, slot)) = best {
            return Some(FaceId(slot));
        }
        self.by_family_index.get(&(family, index)).map(|i| FaceId(*i))
    }

    /// The platform's face for a generic family, matched against the request.
    /// 平台对通用族给出的字面，按请求匹配。
    ///
    /// This path carries the weight too: a request with no named family is the common
    /// case, so ignoring attributes here would make bold text impossible by default.
    /// 这条路径也要带上字重：不带具名族是最常见的情形，
    /// 这里忽略属性会让粗体在默认情况下根本无法出现。
    fn generic_face(&self, generic: GenericFamily, request: &FontRequest) -> Option<FaceId> {
        let family = {
            let Ok(mut inner) = self.inner.lock() else {
                return None;
            };
            // The block ends the borrow: the iterator borrows `inner` mutably.
            // 块负责结束借用：迭代器可变借用了 `inner`。
            inner.generic_families(generic_of(generic)).next()
        };
        if let Some(id) = family
            && let Some(face) = self.pick_face(id, request) {
                return Some(face);
            }
        self.fallback_for_script(Script::LATIN).first().copied()
    }

    fn fallback_for_script(&self, script: Script) -> Vec<FaceId> {
        let Ok(mut inner) = self.inner.lock() else {
            return Vec::new();
        };
        // Collect ids first: the iterator borrows the collection mutably.
        // 先收集 id：迭代器可变借用了 collection。
        let ids: Vec<FamilyId> = inner
            .fallback_families(FallbackKey::new(fq_script(script), None))
            .take(16)
            .collect();
        let names: Vec<String> = ids
            .into_iter()
            .filter_map(|id| inner.family_name(id).map(|s| s.to_string()))
            .collect();
        names
            .into_iter()
            .filter_map(|n| self.by_name.get(&n).copied().map(FaceId))
            .collect()
    }
}

impl FontProvider for FontiqueProvider {
    fn name(&self) -> &'static str {
        if self.system {
            "fontique-system"
        } else {
            "fontique-isolated"
        }
    }

    fn family_names(&self) -> Vec<String> {
        let mut v: Vec<String> = self.faces.iter().map(|f| f.family_name.clone()).collect();
        v.sort();
        v.dedup();
        v
    }

    fn resolve(&self, request: &FontRequest) -> Option<FaceId> {
        // Named families are an exact query: if none match, report absence rather
        // than silently substituting the generic face, which would hide typos.
        // 具名族是精确查询：一个都不匹配时返回"没有"，而不是静默换成通用族，
        // 否则拼错的族名会被掩盖。
        if !request.families.is_empty() {
            for wanted in &request.families {
                if let Some(id) = self.exact_family(wanted)
                    && let Some(face) = self.pick_face(id, request) {
                        return Some(face);
                    }
            }
            return None;
        }
        // The platform's own choice for the generic family.
        // 平台对通用族自己的选择。
        self.generic_face(request.generic, request)
    }

    fn fallback_chain(&self, script: Script) -> Vec<FaceId> {
        self.fallback_for_script(script)
    }

    fn has_glyph(&self, face: FaceId, c: char) -> bool {
        // Probe the face's actual font bytes; a family can hold several faces and
        // only some cover the character.
        // 探测字面实际的字体字节；一个族可能含多个字面，只有部分覆盖该字符。
        match self.face_data(face) {
            Some(data) => charmap_has_glyph(&data, c),
            None => false,
        }
    }

    fn metrics(&self, face: FaceId) -> FaceMetrics {
        // Until a rasterizer parses the real font, report representative metrics.
        // 在光栅器解析真实字体之前，报告代表性度量。
        let _ = self.slot(face);
        FaceMetrics {
            ascent: 0.8,
            descent: -0.2,
            line_gap: 0.0,
        }
    }

    fn advance(&self, face: FaceId, text: &str, size: f32) -> f32 {
        // Approximation: average advance of a system UI face. Replaced once the
        // shaper lands; the signature does not change.
        // 近似：系统 UI 字面的平均前进宽度。整形器落地后替换；签名不变。
        let _ = self.slot(face);
        let ratio = match self.slot(face) {
            Some(_) => 0.6,
            None => 0.6,
        };
        ratio * size * text.chars().count() as f32
    }

    fn face_variation(&self, face: FaceId) -> Option<f32> {
        self.slot(face).and_then(|s| s.variation)
    }

    fn face_axes(&self, face: FaceId) -> Variations {
        self.slot(face).map_or(Variations::NONE, |s| s.axes)
    }

    fn instance(&mut self, face: FaceId, axes: Variations) -> FaceId {
        self.instance_axes(face, axes)
    }

    fn register_family(&mut self, name: &str, data: Arc<[u8]>) -> bool {
        self.register(name, data)
    }

    fn face_index(&self, face: FaceId) -> usize {
        // Two different indices, and they are not interchangeable: the slot holds the
        // face's position *within its family*, while a parser needs its position *within
        // the file* (a TTC packs several faces into one blob). Confusing them silently
        // loads the wrong face.
        // 两个不同的下标不可互换：槽位记的是字面**在族内的位置**，
        // 而解析器需要的是它**在文件内的位置**（TTC 会把多个字面打进同一个 blob）。
        // 混用会静默加载错误的字面。
        let Some(slot) = self.slot(face) else {
            return 0;
        };
        let Ok(mut inner) = self.inner.lock() else {
            return 0;
        };
        let Some(info) = inner.family(slot.family) else {
            return 0;
        };
        info.fonts().get(slot.font_index).map_or(0, |font| font.index() as usize)
    }

    fn face_data(&self, face: FaceId) -> Option<FontBlob> {
        if let Ok(cache) = self.blobs.lock()
            && let Some(hit) = cache.get(&face) {
                return Some(hit.clone());
            }
        let slot = self.slot(face)?.clone();
        let blob = {
            let mut inner = self.inner.lock().ok()?;
            let info = inner.family(slot.family)?;
            // The face's own index: `first()` would hand back Regular for every id,
            // so a resolved Bold would still rasterise Regular outlines.
            // 取该字面自己的下标：用 `first()` 会对每个 id 都返回 Regular，
            // 于是解析出的 Bold 仍然按 Regular 的轮廓光栅化。
            let font = info.fonts().get(slot.font_index)?;
            let mut cache = fontique::SourceCache::new_shared();
            // fontique maps a file source; keeping its blob avoids copying the whole file.
            // fontique 对文件来源做映射；保留它的 blob 就不必把整个文件拷进堆。
            font.load(Some(&mut cache))?
        };
        let blob = FontBlob::new(blob);
        if let Ok(mut cache) = self.blobs.lock() {
            cache.insert(face, blob.clone());
        }
        Some(blob)
    }
}

/// Minimal `cmap` probe: does this font cover `c`?
/// 最小 `cmap` 探测：该字体是否覆盖 `c`？
///
/// Scans the table directory for `cmap` and checks format 4 / 12 subtables.
/// 扫描表目录找到 `cmap`，检查 format 4 / 12 子表。
fn charmap_has_glyph(data: &[u8], c: char) -> bool {
    let Some(cmap) = find_table(data, b"cmap") else {
        return false;
    };
    let num = get_u16(cmap, 2).unwrap_or(0) as usize;
    let mut best: Option<usize> = None;
    for i in 0..num.min(64) {
        let base = 4 + i * 8;
        let (Some(pid), Some(eid), Some(off)) = (
            get_u16(cmap, base),
            get_u16(cmap, base + 2),
            get_u32(cmap, base + 4),
        ) else {
            continue;
        };
        // Prefer Unicode subtables: platform 0, or Windows (3) with UCS-4/UCS-2.
        // 优先 Unicode 子表：平台 0，或 Windows(3) 的 UCS-4/UCS-2。
        if pid == 0 || (pid == 3 && (eid == 1 || eid == 10)) {
            best = Some(off as usize);
        }
    }
    let Some(offset) = best else {
        return false;
    };
    let Some(format) = get_u16(cmap, offset) else {
        return false;
    };
    let cp = c as u32;
    match format {
        4 => {
            if cp > 0xFFFF {
                return false;
            }
            let Some(seg_count) = get_u16(cmap, offset + 6).map(|v| (v / 2) as usize) else {
                return false;
            };
            let end_base = offset + 14;
            let start_base = end_base + seg_count * 2 + 2;
            for i in 0..seg_count {
                let (Some(end), Some(start)) =
                    (get_u16(cmap, end_base + i * 2), get_u16(cmap, start_base + i * 2))
                else {
                    continue;
                };
                if cp >= start as u32 && cp <= end as u32 {
                    return true;
                }
            }
            false
        }
        12 => {
            let Some(ngroups) = get_u32(cmap, offset + 12) else {
                return false;
            };
            let groups_start = offset + 16;
            for i in 0..(ngroups.min(4096) as usize) {
                let base = groups_start + i * 12;
                let (Some(start), Some(end)) = (get_u32(cmap, base), get_u32(cmap, base + 4)) else {
                    break;
                };
                if cp >= start && cp <= end {
                    return true;
                }
            }
            false
        }
        _ => false,
    }
}

fn get_u16(data: &[u8], at: usize) -> Option<u16> {
    let b = data.get(at..at + 2)?;
    Some(u16::from_be_bytes([b[0], b[1]]))
}

fn get_u32(data: &[u8], at: usize) -> Option<u32> {
    let b = data.get(at..at + 4)?;
    Some(u32::from_be_bytes([b[0], b[1], b[2], b[3]]))
}

/// Locate an OpenType table by tag.
/// 按标签定位 OpenType 表。
fn find_table<'a>(data: &'a [u8], tag: &[u8; 4]) -> Option<&'a [u8]> {
    let num_tables = get_u16(data, 4)? as usize;
    for i in 0..num_tables.min(64) {
        let rec = 12 + i * 16;
        if data.get(rec..rec + 4)? != tag {
            continue;
        }
        let offset = get_u32(data, rec + 8)? as usize;
        let len = get_u32(data, rec + 12)? as usize;
        return data.get(offset..offset.checked_add(len)?);
    }
    None
}

/// Convenience: a provider over the OS stack, falling back to isolated mode.
/// 便捷：操作系统栈上的提供者，不可用时退回隔离模式。
pub fn system_or_isolated() -> FontiqueProvider {
    let p = FontiqueProvider::new_system();
    if p.has_system_fonts() {
        p
    } else {
        FontiqueProvider::new_isolated()
    }
}

/// Report which generic family maps to which name, for diagnostics.
/// 报告通用族映射到哪个名字，供诊断。
pub fn describe_generics(p: &FontiqueProvider) -> Vec<(GenericFamily, Option<String>)> {
    [
        GenericFamily::SansSerif,
        GenericFamily::Serif,
        GenericFamily::Monospace,
        GenericFamily::SystemUi,
    ]
    .into_iter()
    .map(|g| {
        let name = p
            .generic_face(g, &FontRequest::new(g))
            .and_then(|face| p.face_family_name(face).map(|s| s.to_string()));
        (g, name)
    })
    .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn isolated_provider_reports_no_system_fonts() {
        let p = FontiqueProvider::new_isolated();
        assert!(!p.has_system_fonts());
        assert!(p.family_names().is_empty());
        assert_eq!(p.name(), "fontique-isolated");
    }

    #[test]
    fn isolated_provider_resolves_nothing() {
        let p = FontiqueProvider::new_isolated();
        assert!(p.resolve(&FontRequest::new(GenericFamily::SansSerif)).is_none());
        assert!(p.fallback_chain(Script::LATIN).is_empty());
        assert!(p.face_data(FaceId(0)).is_none());
    }

    #[test]
    fn missing_face_reports_no_glyph() {
        let p = FontiqueProvider::new_isolated();
        assert!(!p.has_glyph(FaceId(0), 'a'));
    }

    /// Skip loudly: a silently skipped test looks identical to a passing one.
    /// 显式跳过：静默跳过的测试与通过的测试看起来一模一样。
    fn require_system(p: &FontiqueProvider) -> bool {
        if p.has_system_fonts() {
            return true;
        }
        eprintln!(
            "skipped: no system fonts (build with `--features system` to run this test)"
        );
        false
    }

    #[test]
    fn a_face_reports_the_file_index_of_the_font_it_matched() {
        // The invariant is the mapping itself: the slot's family position and the file
        // index are different numbers, and a rasterizer fed the former draws another face.
        // 不变量就是这个映射：槽位的族内位置与文件内下标是两个不同的数，
        // 把前者喂给光栅器就会画出别的字面。
        let p = system_or_isolated();
        if !require_system(&p) {
            return;
        }
        let mut checked = 0;
        let mut non_zero = 0;
        for family in p.family_names() {
            let Some(face) = p.resolve(&FontRequest::new(GenericFamily::SansSerif).family(&family))
            else {
                continue;
            };
            let Some(slot) = p.slot(face).cloned() else {
                continue;
            };
            let expected = {
                let Ok(mut inner) = p.inner.lock() else {
                    return;
                };
                let Some(info) = inner.family(slot.family) else {
                    continue;
                };
                let Some(font) = info.fonts().get(slot.font_index) else {
                    continue;
                };
                font.index()
            };
            assert_eq!(
                p.face_index(face) as u32,
                expected,
                "{family}: face_index must be the file index of the matched font"
            );
            checked += 1;
            if expected != 0 {
                non_zero += 1;
            }
        }
        assert!(checked > 0, "no family resolved; the test proved nothing");
        // Record whether the distinction was actually exercised on this system.
        eprintln!("checked {checked} families, {non_zero} with a non-zero file index");
    }

    #[test]
    fn bold_and_regular_resolve_to_different_faces_and_bytes() {
        // The failure this pins: one slot per *family* meant every weight returned the
        // same id, and `fonts().first()` loaded Regular bytes for it.
        // 这条钉住的失效：过去每个**族**只有一个槽位，任何字重都返回同一个 id，
        // 而 `fonts().first()` 为它加载 Regular 的字节。
        let p = system_or_isolated();
        if !require_system(&p) {
            return;
        }
        let regular = p.resolve(&FontRequest::new(GenericFamily::SansSerif));
        let bold = p.resolve(&FontRequest::new(GenericFamily::SansSerif).weight(ui_core::Weight::BOLD));
        let (Some(regular), Some(bold)) = (regular, bold) else {
            return;
        };
        assert_ne!(
            regular, bold,
            "bold must not resolve to the same face as regular"
        );
        // Both must load. Lengths can be equal on purpose: a variable font is a single
        // file whose faces differ by index, so "different bytes" is not the invariant.
        // 两者都必须能加载。长度相同是合理的：可变字体是同一个文件靠下标区分字面，
        // 因此「字节不同」并不是这里的不变量。
        assert!(p.face_data(regular).is_some(), "regular bytes must load");
        assert!(p.face_data(bold).is_some(), "bold bytes must load");
    }

    /// A family that actually ships an italic face, if the system has one.
    /// 系统里确实带斜体字面的族（若有）。
    fn family_with_italic(p: &FontiqueProvider) -> Option<String> {
        let mut inner = p.inner.lock().ok()?;
        let ids: Vec<FamilyId> = inner.family_ids().collect();
        let mut found: Vec<String> = Vec::new();
        for id in ids {
            let Some(name) = inner.family_name(id).map(|s| s.to_string()) else {
                continue;
            };
            let Some(info) = inner.family(id) else {
                continue;
            };
            if info
                .fonts()
                .iter()
                .any(|f| !matches!(f.style(), fontique::FontStyle::Normal))
            {
                found.push(name);
            }
        }
        // Sorted, because the collection's iteration order is not a contract: an
        // unsorted pick made this test pass or fail depending on which family came first.
        // 排序：集合的迭代顺序不是契约，
        // 不排序会让这个测试的结果取决于哪个族先被遍历到。
        found.sort();
        found.into_iter().next()
    }

    #[test]
    fn italic_resolves_to_an_italic_face_when_the_family_has_one() {
        // The failure this pins: italic was ignored entirely, so every run came back
        // upright. Families without an italic face still return upright on purpose —
        // we do not synthesise a slant.
        // 这条钉住的失效：斜体被完全忽略，任何 run 都返回正体。
        // 没有斜体字面的族仍然返回正体，这是有意的——我们不做仿斜。
        let p = system_or_isolated();
        if !require_system(&p) {
            return;
        }
        let Some(family) = family_with_italic(&p) else {
            eprintln!("skipped: no family with an italic face on this system");
            return;
        };
        let upright = p.resolve(&FontRequest::new(GenericFamily::SansSerif).family(&family));
        let mut want_italic = FontRequest::new(GenericFamily::SansSerif).family(&family);
        want_italic.italic = true;
        let slanted = p.resolve(&want_italic);
        // No silent early return: if either side fails to resolve, that is the finding.
        // 不静默早退：任一侧解析失败本身就是结论。
        let (upright, slanted) = (
            upright.expect("upright face resolves"),
            slanted.expect("italic face resolves"),
        );
        assert_ne!(
            upright, slanted,
            "family {family} ships an italic face, so the request must reach it"
        );
    }

    #[test]
    fn cmap_probe_finds_latin_coverage_in_a_real_font() {
        // Any system font must cover 'a'; this also exercises the cmap walker.
        // 任何系统字体都应覆盖 'a'；这同时锻炼 cmap 遍历。
        let p = system_or_isolated();
        if !p.has_system_fonts() {
            return;
        }
        let face = p
            .resolve(&FontRequest::new(GenericFamily::SansSerif))
            .expect("a sans-serif face");
        let data = p.face_data(face).expect("font bytes");
        assert!(
            charmap_has_glyph(&data, 'a'),
            "sans-serif face must cover 'a'"
        );
    }

    #[test]
    fn cmap_probe_rejects_an_absurd_codepoint() {
        let p = system_or_isolated();
        if !p.has_system_fonts() {
            return;
        }
        let face = p
            .resolve(&FontRequest::new(GenericFamily::SansSerif))
            .expect("face");
        let data = p.face_data(face).expect("bytes");
        // U+10FFF0 is unassigned; no font should claim it.
        // U+10FFF0 未分配；不该有字体声称覆盖它。
        let c = char::from_u32(0x10FFF0).unwrap_or('\u{10FFFF}');
        assert!(!charmap_has_glyph(&data, c));
    }

    #[test]
    fn system_provider_enumerates_families_when_available() {
        let p = system_or_isolated();
        if !p.has_system_fonts() {
            return;
        }
        assert!(
            p.family_names().len() > 1,
            "a real desktop has more than one font family"
        );
    }

    #[test]
    fn a_registered_family_resolves_on_an_isolated_provider() {
        // A bundled icon font must resolve without any system font, and win under its own
        // name; otherwise an app renders `.notdef` on a machine with a different font set.
        // 自带的图标字体必须不依赖任何系统字体即可解析，并在自己的名字下胜出；
        // 否则换一台字体集不同的机器，应用就画出 `.notdef`。
        let system = system_or_isolated();
        if !require_system(&system) {
            return;
        }
        let request = FontRequest::new(GenericFamily::SansSerif).family("Material Symbols Outlined");
        let Some(base) = system.resolve(&request) else {
            eprintln!("skipped: Material Symbols Outlined is not installed");
            return;
        };
        let Some(bytes) = system.face_data(base) else {
            eprintln!("skipped: Material Symbols Outlined has no loadable bytes");
            return;
        };
        let len = bytes.len();

        let mut p = FontiqueProvider::new_isolated();
        assert!(!p.has_system_fonts());
        let owned: std::sync::Arc<[u8]> = std::sync::Arc::from(bytes.bytes());
        assert!(p.register("Bundled Icons", owned), "registration must succeed");
        let face = p
            .resolve(&FontRequest::new(GenericFamily::SansSerif).family("Bundled Icons"))
            .expect("a registered family must resolve without system fonts");
        assert_eq!(p.face_family_name(face), Some("Bundled Icons"));
        assert!(p.has_glyph(face, '\u{e88a}'), "the registered bytes must carry the glyph");
        assert_eq!(p.face_data(face).map(|d| d.len()), Some(len));
    }

    #[test]
    fn an_axis_position_gets_its_own_face_handle() {
        // An animated `FILL` asks for the same glyph at many positions; sharing one handle
        // would rasterise the first position and paint it for every later frame.
        // 动画中的 `FILL` 会在多个位置请求同一个字形；共用一个句柄就会光栅化第一个位置，
        // 之后每一帧都画它。
        let mut p = system_or_isolated();
        if !require_system(&p) {
            return;
        }
        let request = FontRequest::new(GenericFamily::SansSerif).family("Material Symbols Outlined");
        let Some(base) = p.resolve(&request) else {
            eprintln!("skipped: Material Symbols Outlined is not installed");
            return;
        };
        let outlined = p.instance_axes(base, Variations::NONE.fill(0.0));
        let filled = p.instance_axes(base, Variations::NONE.fill(1.0));
        assert_ne!(outlined, filled, "two FILL positions must be two faces");
        assert_eq!(
            outlined,
            p.instance_axes(base, Variations::NONE.fill(0.0)),
            "the same position must reuse its handle"
        );
        assert_eq!(p.face_axes(outlined).fill, Some(0.0));
        assert_eq!(p.face_axes(filled).fill, Some(1.0));
    }
}
